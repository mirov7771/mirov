package ru.sberx.partner.integration.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Value("${springdoc.name:default}")
    private String appName;
    @Value("${springdoc.author:default}")
    private String docAuthor;
    @Value("${springdoc.version:1}")
    private String docVersion;

    @Bean
    public OpenAPI configure() {
        return new OpenAPI()
                .components(new Components())
                .info(new Info()
                        .title(appName)
                        .description(docAuthor)
                        .version(docVersion));
    }
}
