package ru.sberx.partner.integration.validator;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.sberx.partner.integration.controller.dto.res.ErrorRes;
import ru.sberx.partner.integration.exception.SberException;

@ControllerAdvice
@Slf4j
public class ValidationHandler {

    @ExceptionHandler({MethodArgumentNotValidException.class, Exception.class})
    protected ResponseEntity<ErrorRes> handleException(Exception ex){
        log.error("error in service", ex);
        if (ex instanceof SberException){
            SberException e = (SberException) ex;
            return ResponseEntity.status(e.getStatus()).body(new ErrorRes(e.getCode(), e.getMessage(), e.getDetails()));
        } else if (ex instanceof MissingServletRequestParameterException) {
            MissingServletRequestParameterException e = (MissingServletRequestParameterException) ex;
            return ResponseEntity.status(406).body(new ErrorRes(1004, "Не переданы обязательные параметры", ex.getMessage()));
        } else if (ex instanceof MissingRequestHeaderException) {
            MissingRequestHeaderException e = (MissingRequestHeaderException) ex;
            return ResponseEntity.status(406).body(new ErrorRes(1004, "Не переданы обязательные параметры", ex.getMessage()));
        } else if (ex instanceof MethodArgumentNotValidException) {
            StringBuilder details = new StringBuilder("Required params: ");
            MethodArgumentNotValidException e = (MethodArgumentNotValidException) ex;
            for(FieldError item : e.getBindingResult().getFieldErrors()){
                details.append(item.getField()).append("; ");
            }
            return ResponseEntity.status(406).body(new ErrorRes(1004, "Не переданы обязательные параметры", details.toString()));
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorRes(1000, "Сервис временно недоступен", ex.getMessage()));
        }
    }

}
