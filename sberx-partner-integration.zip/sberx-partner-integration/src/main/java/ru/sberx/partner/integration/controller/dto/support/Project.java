package ru.sberx.partner.integration.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Project {
    @NotNull
    private String name;
    @NotNull
    private String note;
    private List<Long> industry;
    private List<Long> interactionType;
    private List<Long> businessModel;
    private String problem;
    private String auditory;
    private List<Long> geography;
    private List<Long> sales;
    private String demoSite;
    private String demoFile;
    private String competitor;
    private String upSide;
    private String downSide;
    private Integer hiringStaff;
    private List<Long> expansion;
    private String demoVideo;
    private String pitchVideo;
    private List<Long> mvpCode;
    private List<Long> technology;
    private File businessPlan;
    private List<Guide> interactionTypes;
    @NotNull
    private List<Guide> businessModels;
    @NotNull
    private List<Guide> industries;
    @NotNull
    private List<Guide> technologies;
    private List<Guide> mvpCodes;
    @NotNull
    private List<Guide> geographies;
    private List<Guide> expansions;
    private List<Guide> salesGuide;
    @NotNull
    private Long projectId;
}
