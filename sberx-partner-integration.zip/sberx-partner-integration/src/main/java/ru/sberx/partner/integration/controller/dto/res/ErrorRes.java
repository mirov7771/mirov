package ru.sberx.partner.integration.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
public class ErrorRes {

    private Integer code;
    private String message;
    private String details;

    public ErrorRes(Integer code, String message, String details)
    {
        this.code = code;
        this.message = message;
        this.details = details;
    }
}
