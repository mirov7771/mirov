package ru.sberx.partner.integration.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import ru.sberx.partner.integration.controller.dto.support.*;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@RequiredArgsConstructor
public class CompaniesListRes {

    private Integer totalCount;
    private Integer totalPages;
    private Integer pageNumber;
    private Integer pageSize;
    private List<Item> items;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Item {
        @NotNull
        private Long id;
        @NotNull
        private Date created;
        private Date modified;
        @NotNull
        private Guide state;
        @NotNull
        private Integer type;
        @NotNull
        private String name;
        private String fullName;
        @NotNull
        private String inn;
        private Guide registrationCountry;
        private Guide locationCountry;
        private String locationCity;
        private Date birthDate;
        private String site;
        private File logoFile;
        private String inviteFio;
        private String email;
        private String phoneNumber;
        private List<Contact> contacts;
        private Boolean hasSuccessPilots;
        private List<SuccessPilot> successPilotsList;
        private Boolean ecoPilot;
        private Boolean ecoExperience;
        private Boolean needInvestment;
        private List<Guide> accelerators;
        private Boolean community;
        @NotNull
        private Project project;
        private Integer staff;
        @JsonIgnore
        private Long stateCode;
        @JsonIgnore
        private Long registrationCountryCode;
        @JsonIgnore
        private Long locationCountryCode;
        @JsonIgnore
        private List<Long> acceleratorCode;
        @JsonIgnore
        private List<Long> interactionTypeCode;
        @JsonIgnore
        private List<Long> businessModelCode;
        @JsonIgnore
        private List<Long> industryCode;
        @JsonIgnore
        private List<Long> technologyCode;
        @JsonIgnore
        private List<Long> mvpCode;
        @JsonIgnore
        private List<Long> geographyCode;
        @JsonIgnore
        private List<Long> expansionCode;
        @JsonIgnore
        private List<Long> salesCode;
        @JsonIgnore
        private String demoFile;
        @JsonIgnore
        private String logo;
    }

}
