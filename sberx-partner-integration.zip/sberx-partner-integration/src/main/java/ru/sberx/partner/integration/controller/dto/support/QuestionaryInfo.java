package ru.sberx.partner.integration.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuestionaryInfo {
    private String name;
    private String fullName;
    private Date birthDay;
    private String location;
    private String logoFile;
    private String site;
    private String note;
    @JsonProperty("modified")
    private Date modified;
    @JsonProperty("created")
    private Date created;
    private List<String> tags;
    private String phoneNumber;
    private String email;
    private String inviteFio;
    private Long questionnaireId;
    private Integer staff;
    private Long state;
    private Long registrationCountry;
    private Long locationCountry;
    private Boolean community;
    private Boolean successPilots;
    private Boolean pilot;
    private List<Long> acceleratorCode;
    private String inn;
    private Project project;
    private List<Contact> contacts;
    private Boolean ecoSystem;
    private Boolean investment;
    private List<SuccessPilot> successPilotsList;
    private Investment qInvestment;
    private String businessPlan;
}
