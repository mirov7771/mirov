package ru.sberx.partner.integration.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class File {
    @NotNull
    private String id;
    private String name;
    private Integer fileSize;
    private String mimeType;
    private String fileType;
}
