package ru.sberx.partner.integration.service;

import ru.sberx.partner.integration.controller.dto.req.AuthPostReq;
import ru.sberx.partner.integration.controller.dto.req.CompaniesListReq;
import ru.sberx.partner.integration.controller.dto.res.AuthPostRes;
import ru.sberx.partner.integration.controller.dto.res.CompaniesListRes;

public interface Service {

    CompaniesListRes getCompaniesList(CompaniesListReq req);
    byte[] getFileById(String fileId);
    AuthPostRes getAuthResponse(AuthPostReq req);

}
