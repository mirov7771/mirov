package ru.sberx.partner.integration.service.impl.manager;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sberx.partner.integration.controller.dto.req.CompaniesListReq;
import ru.sberx.partner.integration.controller.dto.res.CompaniesListRes;
import ru.sberx.partner.integration.controller.dto.support.*;
import ru.sberx.partner.integration.exception.SberException;
import ru.sberx.partner.integration.gate.client.RestGate;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceManager {

    private final RestGate restGate;

    @Value("${resources.data-store.url}")
    private String dataStoreUrl;
    @Value("${resources.data-store.meta}")
    private String dataStoreMeta;
    @Value("${resources.questionary.url}")
    private String questionaryUrl;
    @Value("${resources.questionary.list}")
    private String listUri;
    @Value("${resources.guide.url}")
    private String guideUrl;
    @Value("${resources.guide.values}")
    private String guideUri;

    public byte[] getFileById(String fileId) {
        UriComponents uriComponents =
                UriComponentsBuilder.fromHttpUrl(dataStoreUrl)
                        .path("/file/" + fileId)
                        .build();
        return restGate.call(byte[].class,
                uriComponents,
                null,
                HttpMethod.GET,
                setHeaders(),
                MediaType.APPLICATION_OCTET_STREAM);
    }

    public CompaniesListRes execute(CompaniesListReq req) {
        CompaniesListRes res = new CompaniesListRes();
        List<Long> guideIds = new ArrayList<>();
        if (req.getFromDateTime() == null)
            throw new SberException(1004, 400, "Не переданы обязательные параметры", "список не переданных обязательных параметров FromDateTime");

        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("type", 0);
        queryParams.put("state", 20004);
        queryParams.put("fromDateTime", req.getFromDateTime().replace(" ", "+"));
        if (req.getToDateTime() != null)
            queryParams.put("toDateTime", req.getToDateTime().replace(" ", "+"));
        List<QuestionaryInfo> questionaryInfos = restGate.call(new ParameterizedTypeReference<List<QuestionaryInfo>>() {},
                questionaryUrl,
                listUri,
                queryParams,
                null,
                HttpMethod.GET,
                setHeaders(),
                MediaType.APPLICATION_JSON);

        if (questionaryInfos == null || questionaryInfos.size() == 0)
            return new CompaniesListRes();

        if (req.getPageSize() != null) {
            res.setTotalCount(questionaryInfos.size());
            int rowCount = req.getPageSize() != null && questionaryInfos.size() > req.getPageSize() ? req.getPageSize() : questionaryInfos.size();
            int pageToken = req.getPageNumber() != null ? req.getPageNumber() : 0;
            res.setPageSize(rowCount);
            Pair<List<QuestionaryInfo>, Integer> shortenList = pagination(questionaryInfos, rowCount, pageToken);
            questionaryInfos = shortenList.getFirst();
            res.setTotalPages((int) Math.ceil(res.getTotalCount() / res.getPageSize().floatValue()));
            res.setPageNumber(shortenList.getSecond() > 0 ? shortenList.getSecond() : null);
        }

        res.setItems(new ArrayList<>());
        List<String> fileNames = new ArrayList<>();
        for(QuestionaryInfo info : questionaryInfos) {
            CompaniesListRes.Item item = new CompaniesListRes.Item();

            if (info.getLogoFile() != null) {
                info.setLogoFile(getLogo(info.getLogoFile()));
                if (!fileNames.contains(info.getLogoFile()))
                    fileNames.add(info.getLogoFile());
                item.setLogo(info.getLogoFile());
            }

            if (info.getProject() != null) {
                Project project = new Project();
                project.setProjectId(info.getProject().getProjectId());
                project.setName(info.getProject().getName());
                project.setNote(info.getProject().getNote());
                project.setDemoSite(info.getProject().getDemoSite());
                project.setDemoVideo(info.getProject().getDemoVideo());
                project.setPitchVideo(info.getProject().getPitchVideo());
                project.setProblem(info.getProject().getProblem());
                project.setAuditory(info.getProject().getAuditory());
                project.setCompetitor(info.getProject().getCompetitor());
                project.setUpSide(info.getProject().getUpSide());
                project.setDownSide(info.getProject().getDownSide());
                project.setHiringStaff(info.getProject().getHiringStaff());
                project.setProjectId(info.getProject().getProjectId());

                item.setInteractionTypeCode(info.getProject().getInteractionType());
                item.setBusinessModelCode(info.getProject().getBusinessModel());
                item.setIndustryCode(info.getProject().getIndustry());
                item.setTechnologyCode(info.getProject().getTechnology());
                item.setMvpCode(info.getProject().getMvpCode());
                item.setGeographyCode(info.getProject().getGeography());
                item.setExpansionCode(info.getProject().getExpansion());
                item.setSalesCode(info.getProject().getSales());

                item.setProject(project);
            }

            if (StringUtils.hasText(info.getBusinessPlan())){
                info.setBusinessPlan(getLogo(info.getBusinessPlan()));
                fileNames.add(info.getBusinessPlan());
                item.setDemoFile(info.getBusinessPlan());
            }

            if (info.getQInvestment() != null && info.getQInvestment().getBusinessPlan() != null) {
                info.getQInvestment().setBusinessPlan(getLogo(info.getQInvestment().getBusinessPlan()));
                if (!fileNames.contains(info.getQInvestment().getBusinessPlan()))
                    fileNames.add(info.getQInvestment().getBusinessPlan());
                item.setDemoFile(info.getQInvestment().getBusinessPlan());
            } else if (info.getProject() != null && info.getProject().getDemoFile() != null) {
                info.getProject().setDemoFile(getLogo(info.getProject().getDemoFile()));
                if (!fileNames.contains(info.getProject().getDemoFile()))
                    fileNames.add(info.getProject().getDemoFile());
                item.setDemoFile(info.getProject().getDemoFile());
            }

            item.setId(info.getQuestionnaireId());
            item.setCreated(info.getCreated());
            item.setModified(info.getModified());
            item.setType(0);
            item.setName((info.getName() == null || "".equals(info.getName())) ? info.getFullName() : info.getName());
            item.setInn(info.getInn());
            item.setLocationCity(info.getLocation());
            item.setBirthDate(info.getBirthDay());
            item.setSite(info.getSite());
            item.setInviteFio(info.getInviteFio());
            item.setEmail(info.getEmail());
            item.setPhoneNumber(info.getPhoneNumber());
            item.setHasSuccessPilots(info.getSuccessPilots());
            item.setEcoPilot(info.getPilot());
            item.setEcoExperience(info.getEcoSystem());
            item.setNeedInvestment(info.getInvestment());
            item.setCommunity(info.getCommunity());
            item.setStaff(info.getStaff());
            item.setFullName(info.getFullName());

            setGuideIdsList(guideIds, info);

            item.setStateCode(info.getState());
            item.setRegistrationCountryCode(info.getRegistrationCountry());
            item.setLocationCountryCode(info.getLocationCountry());
            item.setAcceleratorCode(info.getAcceleratorCode());

            if (info.getContacts() != null && info.getContacts().size() > 0)
                item.setContacts(info.getContacts());

            if (info.getSuccessPilotsList() != null && info.getSuccessPilotsList().size() > 0)
                item.setSuccessPilotsList(info.getSuccessPilotsList());

            res.getItems().add(item);
        }

        Map<String, Object> guideQueryParams = Map.of("code", guideIds);

        List<Guide> guideList = restGate.call(new ParameterizedTypeReference<List<Guide>>() {},
                guideUrl,
                guideUri,
                guideQueryParams,
                null,
                HttpMethod.GET,
                setHeaders(),
                MediaType.APPLICATION_JSON);

        if (guideList != null
                && guideList.size() > 0
                && res.getItems() != null
                && res.getItems().size() > 0) {
            for(CompaniesListRes.Item i : res.getItems()){
                setGuideField(i, guideList);
            }
        }

        if (!CollectionUtils.isEmpty(fileNames)) {
            List<File> file = new ArrayList<>();
            for(int i = 0; i < fileNames.size(); i += 20){
                List<File> list = getFile(fileNames.stream().skip(i).limit(20).collect(Collectors.toList()));
                if (!CollectionUtils.isEmpty(list))
                    file.addAll(list);
            }
            if (!CollectionUtils.isEmpty(file)){
                for(CompaniesListRes.Item item : res.getItems()){
                    for(File f : file){
                        if (f.getName().equalsIgnoreCase(item.getLogo())){
                            item.setLogoFile(f);
                        }
                        if (f.getName().equalsIgnoreCase(item.getDemoFile())){
                            if (item.getProject() == null) {
                                Project project = new Project();
                                project.setProjectId(item.getId());
                                item.setProject(project);
                            }
                            if ("pdf".equalsIgnoreCase(f.getFileType()))
                                f.setMimeType("application/pdf");
                            item.getProject().setBusinessPlan(f);
                        }
                    }
                }
            }
        }
        if (res.getItems() != null) {
            res.getItems().sort((q1, q2) -> {
                Date dt2 = q2.getModified() == null ? q2.getCreated() : q2.getModified();
                Date dt1 = q1.getModified() == null ? q1.getCreated() : q1.getModified();
                if (dt2 != null && dt1 != null) {
                    return dt1.compareTo(dt2);
                } else if (dt2 != null) {
                    return 1;
                } else if (dt1 != null) {
                    return -1;
                }
                return 0;
            });
            if (req.getPageSize() == null) {
                res.setPageNumber(1);
                res.setPageSize(1);
                res.setTotalPages(1);
                res.setTotalCount(res.getItems().size());
            }
        }
        if (!CollectionUtils.isEmpty(res.getItems())) {
            res.setItems(res.
                    getItems().
                    stream().
                    filter(i -> i.getId() != null &&
                            i.getCreated() != null &&
                            i.getState() != null &&
                            Boolean.TRUE.equals(i.getState().notEmpty()) &&
                            i.getType() != null &&
                            StringUtils.hasText(i.getName()) &&
                            StringUtils.hasText(i.getInn()) &&
                            i.getProject() != null &&
                            i.getProject().getProjectId() != null).
                    collect(Collectors.toList()));
        }
        return res;
    }

    private void setGuideField(CompaniesListRes.Item item, List<Guide> guideList) {
        for (Guide guide : guideList) {
            if (item.getStateCode() != null && item.getStateCode().equals(guide.getCode()))
                item.setState(guide);
            if (item.getRegistrationCountryCode() != null && item.getRegistrationCountryCode().equals(guide.getCode()))
                item.setRegistrationCountry(guide);
            if (item.getLocationCountryCode() != null && item.getLocationCountryCode().equals(guide.getCode()))
                item.setLocationCountry(guide);
            if (item.getAcceleratorCode() != null && item.getAcceleratorCode().size() > 0 && item.getAcceleratorCode().contains(guide.getCode())) {
                if (item.getAccelerators() == null)
                    item.setAccelerators(new ArrayList<>());
                item.getAccelerators().add(guide);
            }
            if (item.getProject() != null) {
                if (item.getInteractionTypeCode() != null && item.getInteractionTypeCode().size() > 0 && item.getInteractionTypeCode().contains(guide.getCode())) {
                    if (item.getProject().getInteractionTypes() == null)
                        item.getProject().setInteractionTypes(new ArrayList<>());
                    item.getProject().getInteractionTypes().add(guide);
                }
                if (item.getBusinessModelCode() != null && item.getBusinessModelCode().size() > 0 && item.getBusinessModelCode().contains(guide.getCode())) {
                    if (item.getProject().getBusinessModels() == null)
                        item.getProject().setBusinessModels(new ArrayList<>());
                    item.getProject().getBusinessModels().add(guide);
                }
                if (item.getIndustryCode() != null && item.getIndustryCode().size() > 0 && item.getIndustryCode().contains(guide.getCode())) {
                    if (item.getProject().getIndustries() == null)
                        item.getProject().setIndustries(new ArrayList<>());
                    item.getProject().getIndustries().add(guide);
                }
                if (item.getTechnologyCode() != null && item.getTechnologyCode().size() > 0 && item.getTechnologyCode().contains(guide.getCode())) {
                    if (item.getProject().getTechnologies() == null)
                        item.getProject().setTechnologies(new ArrayList<>());
                    item.getProject().getTechnologies().add(guide);
                }
                if (item.getMvpCode() != null && item.getMvpCode().size() > 0 && item.getMvpCode().contains(guide.getCode())) {
                    if (item.getProject().getMvpCodes() == null)
                        item.getProject().setMvpCodes(new ArrayList<>());
                    item.getProject().getMvpCodes().add(guide);
                }
                if (item.getGeographyCode() != null && item.getGeographyCode().size() > 0 && item.getGeographyCode().contains(guide.getCode())) {
                    if (item.getProject().getGeographies() == null)
                        item.getProject().setGeographies(new ArrayList<>());
                    item.getProject().getGeographies().add(guide);
                }
                if (item.getExpansionCode() != null && item.getExpansionCode().size() > 0 && item.getExpansionCode().contains(guide.getCode())) {
                    if (item.getProject().getExpansions() == null)
                        item.getProject().setExpansions(new ArrayList<>());
                    item.getProject().getExpansions().add(guide);
                }
                if (item.getSalesCode() != null && item.getSalesCode().size() > 0 && item.getSalesCode().contains(guide.getCode())) {
                    if (item.getProject().getSalesGuide() == null)
                        item.getProject().setSalesGuide(new ArrayList<>());
                    item.getProject().getSalesGuide().add(guide);
                }
            }
        }
    }

    private void setGuideIdsList(List<Long> guideIds, QuestionaryInfo info) {
        setGuideId(guideIds, info.getState());
        setGuideId(guideIds, info.getRegistrationCountry());
        setGuideId(guideIds, info.getLocationCountry());
        setGuideIdForArray(guideIds, info.getAcceleratorCode());

        if (info.getProject() != null) {
            setGuideIdForArray(guideIds, info.getProject().getInteractionType());
            setGuideIdForArray(guideIds, info.getProject().getBusinessModel());
            setGuideIdForArray(guideIds, info.getProject().getIndustry());
            setGuideIdForArray(guideIds, info.getProject().getTechnology());
            setGuideIdForArray(guideIds, info.getProject().getMvpCode());
            setGuideIdForArray(guideIds, info.getProject().getGeography());
            setGuideIdForArray(guideIds, info.getProject().getExpansion());
            setGuideIdForArray(guideIds, info.getProject().getSales());
        }
    }

    private void setGuideIdForArray(List<Long> guideIds, List<Long> ids) {
        if (ids != null && ids.size() > 0) {
            for (Long id : ids) {
                setGuideId(guideIds, id);
            }
        }
    }

    private void setGuideId(List<Long> guideIds, Long id) {
        if (id != null && !guideIds.contains(id))
            guideIds.add(id);
    }

    private List<File> getFile(List<String> sysName) {
        return restGate.call(new ParameterizedTypeReference<List<File>>() {},
                dataStoreUrl,
                dataStoreMeta,
                null,
                sysName,
                HttpMethod.POST,
                setHeaders(),
                MediaType.APPLICATION_JSON);
    }

    private HttpHeaders setHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("requestId", ThreadContext.get("requestId"));
        httpHeaders.set("client-id", ThreadContext.get("client-id"));
        return httpHeaders;
    }

    private String getLogo(String logo) {
        String retLogo = logo != null && logo.contains("|") ? logo.split("\\|")[0] : logo;
        if (StringUtils.hasText(retLogo))
            return retLogo.replace("/sberx-gateway", "").replace("/file/", "");
        return null;
    }

    private Pair<List<QuestionaryInfo>, Integer> pagination(List<QuestionaryInfo> collection, int rowCount, Integer pageToken) {
        int offset = pageToken != null ? pageToken : 0;
        int from = rowCount * offset;
        int to = from + rowCount;
        int nextPageToken;
        if (to >= collection.size()) {
            nextPageToken = -1;
            to = collection.size();
        } else {
            nextPageToken = offset + 1;
        }
        log.debug("Limiting list, getting sublist from {} to {}", from, to);
        return Pair.of(collection.subList(from, to), nextPageToken);
    }

}
