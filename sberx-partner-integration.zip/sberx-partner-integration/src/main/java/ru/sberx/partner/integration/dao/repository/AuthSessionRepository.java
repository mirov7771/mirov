package ru.sberx.partner.integration.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.sberx.partner.integration.dao.model.AuthSession;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.Optional;

public interface AuthSessionRepository extends CrudRepository<AuthSession, String> {
    AuthSession findBySessionIdAndClientIdAndExpiryDateAfter(String sessionId, Long clientId, Date expiryDate);
    AuthSession findByClientIdAndExpiryDateAfter(Long clientId, Date expiryDate);

    @Transactional
    @Modifying
    @Query(value = "delete from AUTH_SESSION where client_id = :clientId", nativeQuery = true)
    void deleteByClientId(@Param("clientId") Long clientId);
}
