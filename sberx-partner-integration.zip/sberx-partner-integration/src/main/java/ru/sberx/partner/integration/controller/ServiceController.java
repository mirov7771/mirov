package ru.sberx.partner.integration.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.partner.integration.builder.ResponseBuilder;
import ru.sberx.partner.integration.controller.dto.req.AuthPostReq;
import ru.sberx.partner.integration.controller.dto.req.CompaniesListReq;
import ru.sberx.partner.integration.controller.dto.res.AuthPostRes;
import ru.sberx.partner.integration.controller.dto.res.CompaniesListRes;
import ru.sberx.partner.integration.controller.dto.res.ErrorRes;
import ru.sberx.partner.integration.service.Service;
import ru.sberx.partner.integration.service.SessionService;

@RestController
@RequestMapping("sberx-partner-integration")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Partner-Integration")
public class ServiceController {

    private static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";
    private static final String APPLICATION_OCTET_STREAM_VALUE = "application/octet-stream";
    private final Service service;
    private final SessionService sessionService;

    @GetMapping(value = "files/{id}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    @Operation(summary = "Метод получения файла по уникальному идентификатору", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_OCTET_STREAM_VALUE, schema = @Schema(implementation = byte[].class))
            }),
            @ApiResponse(responseCode = "401", description = "Не передан или передан невалидный авторизационный токен", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1002,\n" +
                                    "  \"message\": \"Invalid session\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Файл не найден", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1005,\n" +
                                    "  \"message\": \"Файл не найден\"\n" +
                                    "}"))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = "client-id", in = ParameterIn.HEADER, description = "Идентификатор вызывающей системы", required = true),
                    @Parameter(name = "requestId", in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true),
                    @Parameter(name = "authorization", in = ParameterIn.HEADER, description = "Сессионный токен из выдачи /auth POST", required = true),
                    @Parameter(name = "id", in = ParameterIn.PATH, description = "Уникальный идентификатор файла", required = true)
            }
    )
    public ResponseEntity<?> file(@RequestHeader(value = "requestId") String requestId,
                                  @RequestHeader("client-id") String clientId,
                                  @PathVariable(value = "id") String fileId,
                                  @RequestHeader("authorization") String accessToken) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", clientId);
        sessionService.checkSession(accessToken, clientId);
        return ResponseBuilder.build(service.getFileById(fileId));
    }

    @GetMapping(value = "companies/list", produces = APPLICATION_JSON_VALUE)
    @Operation(summary = "Метод получения списка компаний по параметрам", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(
                            schema = @Schema(implementation = CompaniesListRes.class, type = "array")
                    ))
            }),
            @ApiResponse(responseCode = "401", description = "Не переданы authorization и/или client-id", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1002,\n" +
                                    "  \"message\": \"Invalid session\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "400", description = "Не переданы обязательные параметры", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1004,\n" +
                                    "  \"message\": \"Не переданы обязательные параметры\",\n" +
                                    "  \"details\": \"список не переданных обязательных параметров FromDateTime\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "400", description = "Неправильный формат запроса", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1018,\n" +
                                    "  \"message\": \"Неправильный формат запроса\",\n" +
                                    "  \"details\": \"Неправильный формат запроса (fromDateTime > toDateTime)\"\n" +
                                    "}"))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = "client-id", in = ParameterIn.HEADER, description = "Идентификатор вызывающей системы", required = true),
                    @Parameter(name = "requestId", in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true),
                    @Parameter(name = "authorization", in = ParameterIn.HEADER, description = "Сессионный токен из выдачи /auth POST", required = true),
                    @Parameter(name = "type", in = ParameterIn.QUERY, description = "Тип компании"),
                    @Parameter(name = "fromDateTime", in = ParameterIn.QUERY, description = "Дата и время нижнего диапазона поиска", required = true),
                    @Parameter(name = "toDateTime", in = ParameterIn.QUERY, description = "Дата и время верхнего диапазона поиска в формате"),
                    @Parameter(name = "pageSize", in = ParameterIn.QUERY, description = "Максимальное количество анкет в ответе"),
                    @Parameter(name = "pageNumber", in = ParameterIn.QUERY, description = "Номер пакета с анкетами"),
                    @Parameter(name = "req", in = ParameterIn.QUERY, hidden = true),
            }
    )
    public ResponseEntity<?> getCompaniesList(@RequestHeader("requestId") String requestId,
                                              @RequestHeader("client-id") String clientId,
                                              @RequestHeader("authorization") String accessToken,
                                              CompaniesListReq req) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", clientId);
        sessionService.checkSession(accessToken, clientId);
        return ResponseBuilder.build(service.getCompaniesList(req));
    }

    @PostMapping(value = "auth", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(summary = "Метод авторизации партнера", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthPostRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"accessToken\": \"19d7e392-ee5c-4468-93a5-d74a166df452\",\n" +
                                    "  \"accessTokenExpireDate\": \"2021-10-06T12:32:53.490+03:00\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Не найден объект", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1020,\n" +
                                    "  \"message\": \"Ошибка доступа: не найден объект\"\n" +
                                    "}"))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = "client-id", in = ParameterIn.HEADER, description = "Идентификатор приложения", required = true),
                    @Parameter(name = "requestId", in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true),
            }
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода auth",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthPostReq.class))
            }
    )
    public ResponseEntity<?> auth(@RequestHeader("requestId") String requestId,
                                  @RequestHeader("client-id") String clientId,
                                  @RequestBody AuthPostReq req) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", clientId);
        req.setClientId(Long.valueOf(clientId));
        return ResponseBuilder.build(service.getAuthResponse(req));
    }

}
