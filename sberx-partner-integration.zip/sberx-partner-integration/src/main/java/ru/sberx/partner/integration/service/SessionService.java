package ru.sberx.partner.integration.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.partner.integration.dao.model.AuthSession;
import ru.sberx.partner.integration.dao.repository.AuthSessionRepository;
import ru.sberx.partner.integration.exception.SberException;

import java.util.Calendar;
import java.util.Date;

@Component
@RequiredArgsConstructor
public class SessionService {

    private final AuthSessionRepository authSessionRepository;

    public void checkSession(String token, String clientId){
        AuthSession session = authSessionRepository
                .findBySessionIdAndClientIdAndExpiryDateAfter(token,
                        Long.parseLong(clientId),
                        new Date());
        if (session == null)
            throw new SberException(1002, 401, "Invalid session", null);
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.MINUTE, 60);
        session.setExpiryDate(cal.getTime());
        authSessionRepository.save(session);
    }

}
