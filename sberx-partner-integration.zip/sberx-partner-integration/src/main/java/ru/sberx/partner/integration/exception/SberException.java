package ru.sberx.partner.integration.exception;

import lombok.Getter;
import ru.sberx.partner.integration.controller.dto.res.ErrorRes;

@Getter
public class SberException extends RuntimeException {

    private static final long serialVersionUID = 8359430630502179416L;

    private final Integer code;
    private final Integer status;
    private final String message;
    private final String details;

    public SberException(Integer code, Integer status, String message, String details){
        super(message);
        this.details = details;
        this.code = code;
        this.status = status;
        this.message = message;
    }

    public SberException(ErrorRes res, Integer status){
        super(res.getMessage());
        this.details = res.getDetails();
        this.code = res.getCode();
        this.status = status;
        this.message = res.getMessage();
    }
}
