package ru.sberx.partner.integration.dao.repository;

import org.springframework.data.repository.CrudRepository;
import ru.sberx.partner.integration.dao.model.AuthConfig;

import java.util.Optional;

public interface AuthConfigRepository extends CrudRepository<AuthConfig, Long> {
    Optional<AuthConfig> findAuthConfigByClientIdAndClientSecret(Long clientId, String clientSecret);
}
