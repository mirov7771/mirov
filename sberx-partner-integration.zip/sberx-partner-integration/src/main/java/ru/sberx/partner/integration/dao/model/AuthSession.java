package ru.sberx.partner.integration.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@Table(name = "AUTH_SESSION")
public class AuthSession {

    @Id
    @Column(name = "session_id")
    private String sessionId;

    @Column(name = "client_id")
    private Long clientId;

    @Column(name = "expiry_date")
    private Date expiryDate;

    public AuthSession(Long clientId, Date expiryDate){
        this.clientId = clientId;
        this.expiryDate = expiryDate;
        this.sessionId = UUID.randomUUID().toString();
    }
}
