package ru.sberx.partner.integration.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class AuthPostReq {
    @JsonIgnore
    private Long clientId;
    private String clientSecret;
}
