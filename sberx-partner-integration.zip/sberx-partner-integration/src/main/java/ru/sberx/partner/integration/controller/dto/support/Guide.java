package ru.sberx.partner.integration.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.util.StringUtils;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Guide {
    private Long guideId;
    private Long code;
    private String name;

    @JsonIgnore
    public boolean notEmpty(){
        return this.guideId != null &&
                this.code != null &&
                StringUtils.hasText(this.name);
    }
}

