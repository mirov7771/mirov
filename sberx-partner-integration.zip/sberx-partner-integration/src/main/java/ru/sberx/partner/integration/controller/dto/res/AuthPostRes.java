package ru.sberx.partner.integration.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class AuthPostRes {
    private String accessToken;
    @JsonFormat(timezone = "GMT+3")
    private Date accessTokenExpireDate;
}
