package ru.sberx.partner.integration.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.partner.integration.controller.dto.req.AuthPostReq;
import ru.sberx.partner.integration.controller.dto.req.CompaniesListReq;
import ru.sberx.partner.integration.controller.dto.res.AuthPostRes;
import ru.sberx.partner.integration.controller.dto.res.CompaniesListRes;
import ru.sberx.partner.integration.dao.model.AuthConfig;
import ru.sberx.partner.integration.dao.model.AuthSession;
import ru.sberx.partner.integration.dao.repository.AuthConfigRepository;
import ru.sberx.partner.integration.dao.repository.AuthSessionRepository;
import ru.sberx.partner.integration.exception.SberException;
import ru.sberx.partner.integration.service.Service;
import ru.sberx.partner.integration.service.impl.manager.ServiceManager;

import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

@Component
@RequiredArgsConstructor
public class ServiceImpl implements Service {

    private final ServiceManager serviceManager;
    private final AuthConfigRepository authConfigRepository;
    private final AuthSessionRepository authSessionRepository;

    @Override
    public CompaniesListRes getCompaniesList(CompaniesListReq req) {
        return serviceManager.execute(req);
    }

    @Override
    public byte[] getFileById(String fileId) {
        return serviceManager.getFileById(fileId);
    }

    @Override
    public AuthPostRes getAuthResponse(AuthPostReq req) {
        Optional<AuthConfig> authConfigOptional = authConfigRepository.findAuthConfigByClientIdAndClientSecret(req.getClientId(), req.getClientSecret());
        AuthConfig authConfig = authConfigOptional.orElseThrow(() -> new SberException(1020, 404, "Ошибка доступа: не найден объект", null));
        AuthSession authSession = authSessionRepository.findByClientIdAndExpiryDateAfter(req.getClientId(), new Date());
        if (authSession == null){
            authSessionRepository.deleteByClientId(req.getClientId());
            authSession = new AuthSession(req.getClientId(), getExpiryDate(authConfig.getSessionExpiry()));
        } else {
            authSession.setExpiryDate(getExpiryDate(authConfig.getSessionExpiry()));
        }
        authSessionRepository.save(authSession);
        return new AuthPostRes(authSession.getSessionId(), authSession.getExpiryDate());
    }

    private static Date getExpiryDate(Integer min){
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.MINUTE,  min);
        return c.getTime();
    }


}

