package ru.sberx.partner.integration.controller.dto.req;

import lombok.Data;

@Data
public class CompaniesListReq {

    private String fromDateTime;
    private String toDateTime;
    private Integer pageSize;
    private Integer pageNumber;
    private String accessToken;
    private String clientId;

}
