package ru.sberx.partner.integration.controller;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.partner.integration.controller.health.LivenessIndicator;
import ru.sberx.partner.integration.controller.health.ReadinessIndicator;

@RestController
@RequestMapping("sberx-partner-integration")
@RequiredArgsConstructor
public class HealthController {

    private final ReadinessIndicator readinessIndicator;
    private final LivenessIndicator livenessIndicator;

    @GetMapping("/read")
    @Operation(hidden = true)
    public Health readiness(){
        return readinessIndicator.health();
    }

    @GetMapping("/live")
    @Operation(hidden = true)
    public Health liveness(){
        return livenessIndicator.health();
    }

}
