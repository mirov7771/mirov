package ru.sberx.partner.integration.dao.model;


import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "AUTH_CONFIG")
public class AuthConfig {

    @Id
    @Column(name = "client_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long clientId;

    @Column(name = "client_secret")
    private String clientSecret;

    @Column(name = "session_expiry")
    private Integer sessionExpiry;
}
