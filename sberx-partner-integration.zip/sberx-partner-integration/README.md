# Сервис интеграции с партнерами

### sberx-partner-integration

Confluence: https://confluence.sberbank.ru/pages/viewpage.action?pageId=5673618139

