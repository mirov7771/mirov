package ru.sberx.logs.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class SberException extends RuntimeException {

    private static final long serialVersionUID = 8359430630502179416L;

    private final Integer code;
    private final HttpStatus httpStatus;
    private final String message;
    private final String details;

    public SberException(Integer code, HttpStatus status, String message, String details) {
        super(message);
        this.details = details;
        this.code = code;
        this.httpStatus = status;
        this.message = message;
    }

}
