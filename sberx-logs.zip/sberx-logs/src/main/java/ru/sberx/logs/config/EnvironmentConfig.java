package ru.sberx.logs.config;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import ru.sberx.logs.exception.SberException;

import javax.annotation.PostConstruct;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

@Configuration
@Slf4j
public class EnvironmentConfig {
    private final String topic;
    private final String servers;
    private final String keyPassword;
    private final String keyStoreLocation;
    private final String trustStoreLocation;
    private final String trustStorePassword;
    private final String receiverTemplate;
    private final Map<String, String> receiverHosts;

    public EnvironmentConfig(@Value("${spring.kafka.topic}") String topic,
                             @Value("${spring.kafka.producer.bootstrap-servers}") String servers,
                             @Value("${spring.kafka.producer.ssl.key-password}") String keyPassword,
                             @Value("${spring.kafka.producer.ssl.key-store-location}") String keyStoreLocation,
                             @Value("${spring.kafka.producer.ssl.trust-store-location}") String trustStoreLocation,
                             @Value("${spring.kafka.producer.ssl.trust-store-password}") String trustStorePassword,
                             @Value("${receivers.template}") String receiverTemplate,
                             ObjectMapper objectMapper,
                             @Value("${receivers.hosts}") String receiverHosts) throws JsonProcessingException {
        this.topic = topic;
        this.servers = servers;
        this.keyPassword = keyPassword;
        this.keyStoreLocation = keyStoreLocation;
        this.trustStoreLocation = trustStoreLocation;
        this.trustStorePassword = trustStorePassword;
        this.receiverTemplate = receiverTemplate;
        this.receiverHosts = objectMapper.readValue(receiverHosts, new TypeReference<>() {
        });
    }

    private static final URL logbackFile = EnvironmentConfig.class.getResource("/spring-logback.xml");

    @PostConstruct
    public void doPostConstruct() throws JoranException, IOException {
        overrideLoggingConfig();
    }

    private void overrideLoggingConfig() throws IOException, JoranException {
        String initialString = getText();
        initialString = initialString.replace("{topic}", topic)
                .replace("{servers}", servers)
                .replace("{keyPassword}", keyPassword)
                .replace("{keyStoreLocation}", keyStoreLocation)
                .replace("{trustStorePassword}", trustStorePassword)
                .replace("{trustStoreLocation}", trustStoreLocation);
        if (!receiverHosts.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();
            for (Map.Entry<String, String> m : receiverHosts.entrySet()) {
                stringBuilder.append(receiverTemplate.replace("{host}", m.getKey()).replace("{port}", m.getValue()));
            }
            initialString = initialString.replace("{receivers}", stringBuilder.toString());
        }
        InputStream targetStream = new ByteArrayInputStream(initialString.getBytes());
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(context);
        context.reset();
        configurator.doConfigure(targetStream);
    }

    private String getText() throws IOException {
        if (logbackFile != null) {
            URLConnection connection = EnvironmentConfig.logbackFile.openConnection();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                response.append(inputLine);
            in.close();
            return response.toString();
        }
        log.error("logback configuration not found");
        throw new SberException(500, HttpStatus.INTERNAL_SERVER_ERROR, "logback configuration not found", null);
    }

}