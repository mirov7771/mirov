package ru.sberx.logs;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import ru.sberx.logs.service.KafkaProducer;


@Slf4j
@SpringBootTest
public class Tests {

    @Autowired
    private KafkaProducer kafkaProducer;

    @Test
    void contextLoads() {
        kafkaProducer.sendMessage("Test");
    }
}
