# sberx-logs

### Jira: https://sbtatlas.sigma.sbrf.ru/jira/browse/STARTUPHUB-123
