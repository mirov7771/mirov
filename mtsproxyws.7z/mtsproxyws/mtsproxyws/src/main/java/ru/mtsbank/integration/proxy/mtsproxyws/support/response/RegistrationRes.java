package ru.mtsbank.integration.proxy.mtsproxyws.support.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.mtsbank.integration.proxy.mtsproxyws.support.AbstractObject;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
         "status"
        ,"errorCode"
        ,"errorMessage"
        ,"sessionID"
})
@XmlRootElement(name = "FDX")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegistrationRes extends AbstractObject {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "status", required = true)
    @JsonProperty("status")
    private int status;
    @XmlElement(name = "errorCode", required = false)
    @JsonProperty("errorCode")
    private String errorCode;
    @XmlElement(name = "errorMessage", required = false)
    @JsonProperty("errorMessage")
    private String errorMessage;
    @XmlElement(name = "sessionID", required = false)
    @JsonProperty("sessionID")
    private String sessionID;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSessionID() {
        return sessionID;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

}
