package ru.mtsbank.integration.proxy.mtsproxyws.utils;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Component
public class MtsUtils {

    public Map<String, Object> buildStartProcessParams(){
        Map<String, Object> inputParams = new HashMap<>();
        inputParams.put("BackOfficeType", MtsConstants.backOfficeType);
        inputParams.put("STARTIMMEDIATLY", MtsConstants.STARTIMMEDIATLY);
        inputParams.put("LIGHTPROCESS", MtsConstants.LIGHTPROCESS);
        inputParams.put("ForMobileDeviceFlag", MtsConstants.forMobileDeviceFlag);
        inputParams.put("ChannelSysName", MtsConstants.channelSysName);
        inputParams.put("Channel", MtsConstants.channelSysName);
        return inputParams;
    }

    public Boolean checkAnswerStatus(String checkStatus){
        return (checkStatus.equalsIgnoreCase("false") || checkStatus.equalsIgnoreCase("WRONG_CODE"));
    }

    public String decondeString(String val){
        byte[] b = Base64.getDecoder().decode(val);
        return new String(b);
    }

    public String encodeString(String val){
        return Base64.getEncoder().encodeToString(val.getBytes());
    }

}
