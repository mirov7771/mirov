package ru.mtsbank.integration.proxy.mtsproxyws.support;

public class MtsConstants {

    public static final String registrationProcess = "FTDBO/passwordRestore";
    public static final String authorizationProcess = "FTDBO/checkLoginPassword";
    public static final String authorizationEkProcess = "FTDBO/checkAuthorizationEk";
    public static final String smsSendProcess = "FTDBO/dsMtsSmsSend";

    public static final boolean LIGHTPROCESS = true;
    public static final boolean STARTIMMEDIATLY = true;

    public static final String backOfficeType = "FLEX";
    public static final int forMobileDeviceFlag = 1;
    public static final String channelSysName = "Mobile";
    public static final String clientNotFound = "По введеным параметрам клиент не найден";
    public static final String wrongSmsCode = "Одноразовый пароль не подтвержден";
    public static final String wrongNewLogin = "Введен неверный новый логин";
    public static final String wrongNewPassword = "Введен неверный новый пароль";
    public static final String wrongLoginOrPassword = "Неверный логин/пароль";
    public static final String addSlavesError = "Ошибка привязки учетной записи";
    public static final String checkClientPhoneError = "Номера телефонов в Банке и в приложении МТС Деньги не совпадают";

    public static final String HTTP_ENCODING = "gzip,deflate";
    public static final String HTTP_CONTENT = "application/json";
    public static final String HTTP_CONNECTION = "Keep-Alive";
    public static final String HTTP_CONTENT_LENGTH = "27";


    public static final String ADD_SLAVES_KEY = "rbo_id";

}
