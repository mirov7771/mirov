package ru.mtsbank.integration.proxy.mtsproxyws.flextera;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.proxy.mtsproxyws.config.MtsAppConfig;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;

import java.io.IOException;
import java.util.Base64;
import java.util.Map;

@Component
@Slf4j
public class MtsGate {

    @Autowired
    private MtsAppConfig mtsAppConfig;

    private final OkHttpClient httpClient = new OkHttpClient();
    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    public String addSlaves(String key, String token, String login, String phone, String rboId, String uid) throws Exception {
        log.debug("{} : start calling add slaves with token {} , login {}, phone {}, rboId {}",uid, token, login, phone, rboId);
        String retVal;
        String uri = mtsAppConfig.getMtsservice();
        String jsonReq = "{\""+key+"\":\""+rboId+"\"}";

        String basic = "Basic "+encodeAuth()+";";
        String bearer = "Bearer "+token;
        String authorization = basic+bearer;

        RequestBody formBody = RequestBody.create(JSON,jsonReq);
        Request request = new Request.Builder()
                .url(uri)
                .addHeader("Accept-Encoding", MtsConstants.HTTP_ENCODING)
                .addHeader("Content-Type", MtsConstants.HTTP_CONTENT)
                .addHeader("Authorization", authorization)
                .addHeader("Content-Length", MtsConstants.HTTP_CONTENT_LENGTH)
                .addHeader("Connection", MtsConstants.HTTP_CONNECTION)
                .addHeader("Host", mtsAppConfig.getMtshost())
                .put(formBody)
                .build();
        log.debug("{} : Send {} request {} with body {}, json string {}",uid,request.method(),request.toString(),request.body().toString(),jsonReq);
        log.debug("{} Header: \rAccept-Encoding: {} \rContent-Type: {} \rAuthorization: {} \rContent-Length: {} \rConnection: {} \rHost: {} ",uid,
                MtsConstants.HTTP_ENCODING,
                MtsConstants.HTTP_CONTENT,
                authorization,
                MtsConstants.HTTP_CONTENT_LENGTH,
                MtsConstants.HTTP_CONNECTION,
                mtsAppConfig.getMtshost());
        log.debug("{} : Body: {}",uid,jsonReq);
        try(Response response = httpClient.newCall(request).execute()){
            log.debug("{} : Response string {}",uid,response.toString());
            log.debug("{} : Response code {}",uid,response.code());
            log.debug("{} : Response message {}",uid,response.message());
            if (response.headers() != null)
                log.debug("{} : {}",uid,response.headers().toString());
            if (!response.isSuccessful()) {
                retVal = "ERROR";
                log.debug("{} : Error response is {}",uid,response.message());
            } else {
                retVal = response.body().string();
            }
        }
        log.debug("{} : End addSlaves with respone {}",uid,retVal);
        return retVal;
    }

    public String getClientInfo(String token) throws IOException {
        String phone = null;
        String authorization = "Bearer "+token;
        Request request =new Request.Builder()
                .url(mtsAppConfig.getOauth())
                .addHeader("Host",mtsAppConfig.getMtshost())
                .addHeader("Accept-Encoding",MtsConstants.HTTP_CONTENT)
                .addHeader("Authorization",authorization)
                .get()
                .build();
        try(Response response = httpClient.newCall(request).execute()){
            if (response.isSuccessful() && response.body() != null){
                Map<String, Object> map;
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
                map = objectMapper.readValue(response.body().string(), Map.class);
                if (!map.isEmpty()) {
                    if (map.get("mobile:phone") != null)
                        phone = getString(map.get("mobile:phone"));
                    else if (map.get("phone_number") != null)
                        phone = getString(map.get("phone_number"));
                }
            }
        }
        return phone;
    }

    private String encodeAuth(){
        String val = mtsAppConfig.getClientId()+":"+mtsAppConfig.getClientPwd();
        return Base64.getEncoder().encodeToString(val.getBytes());
    }

    public static String getString(Object value) {
        if (value instanceof String)
            return (String) value;
        if (value instanceof Long){
            Long val = (Long) value;
            return val.toString();
        }
        if (value instanceof Integer){
            Integer val = (Integer) value;
            return val.toString();
        }
        return null;
    }

}
