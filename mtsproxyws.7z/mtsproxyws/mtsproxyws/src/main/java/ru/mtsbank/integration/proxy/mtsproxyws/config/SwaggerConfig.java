package ru.mtsbank.integration.proxy.mtsproxyws.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    private static final String BASE_PACKAGE = "ru.mtsbank.integration.proxy.mtsproxyws.documentation";
    private static final String PATH_URL = "/.*";

    @Autowired
    private MtsAppConfig mtsAppConfig;

    @Bean
    public Docket api() {
        Docket doc = new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage(BASE_PACKAGE))
                .paths(PathSelectors.regex(PATH_URL))
                .build().apiInfo(apiEndPointsInfo());;
        if (mtsAppConfig.getDocumentation().equalsIgnoreCase("1")) {
            doc.enable(true);
        } else {
            doc.enable(false);
        }
        return doc;
    }

    private ApiInfo apiEndPointsInfo() {
        return new ApiInfoBuilder().title("MTS BANK REST API SERVICE")
                .version("22.10.2019.01")
                .build();
    }

}
