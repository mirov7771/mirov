package ru.mtsbank.integration.proxy.mtsproxyws.service.authorization;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.diasoft.utils.text.StringUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.FlexteraGate;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.ExtraUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.RegistrationReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.response.RegistrationRes;
import ru.mtsbank.integration.proxy.mtsproxyws.utils.MtsUtils;

import java.util.Map;

@Component("sendCodeAuth")
@Slf4j
public class SendCodeAuth implements DboService {

    @Autowired
    private FlexteraGate flexteraGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private MtsUtils mtsUtils;

    @Autowired
    private ExtraUtils extraUtils;

    @Override
    public String handleRequest(String xmlRequest, String auth, String uid) throws MtsException {
        String xmlResponse = null;
        RegistrationReq req = xmlUnmarshaler.parse(RegistrationReq.class, xmlRequest);
        String login = req.getLogin();
        String pwd = req.getPassword();
        Map<String, Object> inputParams = mtsUtils.buildStartProcessParams();
        inputParams.put("PROCESSNAME", MtsConstants.authorizationEkProcess);
        inputParams.put("LOGIN", login);
        inputParams.put("PasswordHash1", pwd);
        inputParams.put("MobileOS", req.getMobileOS());
        Map<String, Object> outputParams = flexteraGate.startProcess(inputParams, uid);
        if (outputParams != null) {
            RegistrationRes res = new RegistrationRes();
            String resultStatus = (String) outputParams.get("ResultStatus");
            String errorMessage = (String) outputParams.get("ErrorMessage");
            if (StringUtils.isEmpty(errorMessage))
                errorMessage = MtsConstants.wrongLoginOrPassword;
            if (!StringUtils.isEmpty(resultStatus) && (resultStatus.equalsIgnoreCase("OK") || resultStatus.equalsIgnoreCase("true"))){
                res.setStatus(0);
            } else {
                Map<String, String> errorMap = extraUtils.createErrorAnswer(outputParams, errorMessage);
                res.setStatus(1);
                res.setErrorCode(errorMap.get("errorCode"));
                res.setErrorMessage(errorMap.get("errorMessage"));
            }
            xmlResponse = xmlUnmarshaler.createXml(res);
        }
        return xmlResponse;
    }

}
