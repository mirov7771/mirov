package ru.mtsbank.integration.proxy.mtsproxyws.support.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.mtsbank.integration.proxy.mtsproxyws.support.AbstractObject;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
         "sendStatus"
        ,"errorMsg"
})
@XmlRootElement(name = "FDX")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmsSendRes extends AbstractObject {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "sendStatus", required = true)
    @JsonProperty("sendStatus")
    private String sendStatus;
    @XmlElement(name = "errorMsg", required = false)
    @JsonProperty("errorMsg")
    private String errorMsg;

    public String getSendStatus() {
        return sendStatus;
    }

    public void setSendStatus(String sendStatus) {
        this.sendStatus = sendStatus;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
