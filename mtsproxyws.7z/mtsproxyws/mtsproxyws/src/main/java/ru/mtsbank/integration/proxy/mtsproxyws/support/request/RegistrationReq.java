package ru.mtsbank.integration.proxy.mtsproxyws.support.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import ru.mtsbank.integration.proxy.mtsproxyws.support.AbstractObject;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
         "cardNumber"
        ,"accNumber"
        ,"birthDay"
        ,"phoneNumber"
        ,"code"
        ,"login"
        ,"password"
        ,"mobileOS"
        ,"accessToken"
})
@XmlRootElement(name = "FDX")
public class RegistrationReq extends AbstractObject {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "CardNumber", required = false)
    @JsonProperty("CardNumber")
    private String cardNumber;
    @XmlElement(name = "AccNumber", required = false)
    @JsonProperty("AccNumber")
    private String accNumber;
    @XmlElement(name = "BirthDay", required = false)
    @JsonProperty("BirthDay")
    private String birthDay;
    @XmlElement(name = "PhoneNumber", required = false)
    @JsonProperty("PhoneNumber")
    private String phoneNumber;
    @XmlElement(name = "Code", required = false)
    @JsonProperty("Code")
    private String code;
    @XmlElement(name = "Login", required = false)
    @JsonProperty("Login")
    private String login;
    @XmlElement(name = "Password", required = false)
    @JsonProperty("Password")
    private String password;
    @XmlElement(name = "MobileOS", required = false)
    @JsonProperty("MobileOS")
    private String mobileOS;
    @XmlElement(name = "AccessToken", required = false)
    @JsonProperty("AccessToken")
    private String accessToken;

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getAccNumber() {
        return accNumber;
    }

    public void setAccNumber(String accNumber) {
        this.accNumber = accNumber;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobileOS() {
        return mobileOS;
    }

    public void setMobileOS(String mobileOS) {
        this.mobileOS = mobileOS;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
}
