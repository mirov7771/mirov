package ru.mtsbank.integration.proxy.mtsproxyws.service.registration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.diasoft.utils.text.StringUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.FlexteraGate;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.ExtraUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.RegistrationReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.response.RegistrationRes;
import ru.mtsbank.integration.proxy.mtsproxyws.utils.MtsUtils;

import java.util.Map;

@Component("checkCode")
@Slf4j
public class CheckCode implements DboService {

    @Autowired
    private FlexteraGate flexteraGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private MtsUtils mtsUtils;

    @Autowired
    private ExtraUtils extraUtils;

    @Override
    public String handleRequest(String xmlRequest, String auth, String uid) throws MtsException {
        String xmlResponse = null;
        RegistrationReq req = xmlUnmarshaler.parse(RegistrationReq.class, xmlRequest);
        Map<String, Object> inputParams = mtsUtils.buildStartProcessParams();
        inputParams.put("PROCESSNAME", MtsConstants.registrationProcess);
        inputParams.put("accNumber", req.getAccNumber());
        inputParams.put("cardNumber", req.getCardNumber());
        inputParams.put("birthDay", req.getBirthDay());
        inputParams.put("LOGIN", req.getPhoneNumber());
        inputParams.put("MobileOS", req.getMobileOS());
        inputParams.put("CODE", req.getCode());
        Map<String, Object> outputParams = flexteraGate.startProcess(inputParams, uid);
        if (outputParams != null) {
            String result = (String) outputParams.get("Result");
            String checkStatus = (String) outputParams.get("checkStatus");
            String errorMessage = (String) outputParams.get("ErrorMessage");
            if (StringUtils.isEmpty(errorMessage))
                errorMessage = MtsConstants.wrongSmsCode;
            RegistrationRes res = new RegistrationRes();
            if (result.equalsIgnoreCase("Ok") && !mtsUtils.checkAnswerStatus(checkStatus)) {
                res.setStatus(0);
            } else {
                Map<String, String> errorMap = extraUtils.createErrorAnswer(outputParams, errorMessage);
                res.setStatus(1);
                res.setErrorCode(errorMap.get("errorCode"));
                res.setErrorMessage(errorMap.get("errorMessage"));
            }
            xmlResponse = xmlUnmarshaler.createXml(res);
        }
        return xmlResponse;
    }

}
