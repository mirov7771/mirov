package ru.mtsbank.integration.proxy.mtsproxyws.support.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import ru.mtsbank.integration.proxy.mtsproxyws.support.AbstractObject;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "rbo_id"
})
@XmlRootElement(name = "FDX")
public class AddSlavesRes extends AbstractObject {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "rbo_id", required = false)
    @JsonProperty("rbo_id")
    private String rboid;

    public String getRboid() {
        return rboid;
    }

    public void setRboid(String rboid) {
        this.rboid = rboid;
    }
}
