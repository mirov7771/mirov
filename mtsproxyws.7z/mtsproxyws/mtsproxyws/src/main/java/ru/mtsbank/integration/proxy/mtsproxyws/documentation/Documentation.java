package ru.mtsbank.integration.proxy.mtsproxyws.documentation;

public class Documentation{

}