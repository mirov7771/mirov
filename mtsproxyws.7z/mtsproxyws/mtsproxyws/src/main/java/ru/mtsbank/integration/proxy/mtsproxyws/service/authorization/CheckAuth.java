package ru.mtsbank.integration.proxy.mtsproxyws.service.authorization;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.diasoft.utils.text.StringUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.FlexteraGate;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.MtsGate;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.ExtraUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.RegistrationReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.response.RegistrationRes;
import ru.mtsbank.integration.proxy.mtsproxyws.utils.MtsUtils;

import java.util.Map;

@Component("checkAuth")
@Slf4j
public class CheckAuth implements DboService {

    @Autowired
    private FlexteraGate flexteraGate;

    @Autowired
    private MtsGate mtsGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private MtsUtils mtsUtils;

    @Autowired
    private ExtraUtils extraUtils;

    @Override
    public String handleRequest(String xmlRequest, String auth, String uid) throws MtsException {
        String xmlResponse = null;
        RegistrationReq req = xmlUnmarshaler.parse(RegistrationReq.class, xmlRequest);
        Map<String, Object> inputParams = mtsUtils.buildStartProcessParams();
        inputParams.put("PROCESSNAME", MtsConstants.authorizationEkProcess);
        inputParams.put("CODE", req.getCode());
        inputParams.put("LOGIN", req.getLogin());
        inputParams.put("PasswordHash1", req.getPassword());
        inputParams.put("MobileOS", req.getMobileOS());
        Map<String, Object> outputParams;
        outputParams = flexteraGate.startProcess(inputParams, uid);
        if (!outputParams.isEmpty()) {
            RegistrationRes res = new RegistrationRes();
            String resultStatus = (String) outputParams.get("ResultStatus");
            String errorMessage = (String) outputParams.get("ErrorMessage");
            if (StringUtils.isEmpty(errorMessage))
                errorMessage = MtsConstants.wrongSmsCode;
            if (!StringUtils.isEmpty(resultStatus) && (resultStatus.equalsIgnoreCase("OK") || resultStatus.equalsIgnoreCase("true"))){
                String addSlaveResult = "";
                boolean badPhones = false;
                try {
                    String phone = (String) outputParams.get("ClientPhone");
                    String rboid = (String) outputParams.get("ClientRboId");
                    String clientPhone = mtsGate.getClientInfo(req.getAccessToken());
                    if (StringUtils.isEmpty(phone) || StringUtils.isEmpty(clientPhone)) {
                        log.debug("{} : CheckAuth Bank And Mts Phone is empty for rboId {}",uid,rboid);
                        addSlaveResult = "ERROR";
                    } else if (!clientPhone.equals(phone)) {
                        log.debug("{} : CheckAuth Bank phone {} not equals Mts phone {} for RboId {}",uid, phone, clientPhone, rboid);
                        badPhones = true;
                        addSlaveResult = "ERROR";
                    } else if (!StringUtils.isEmpty(phone) && !StringUtils.isEmpty(rboid)) {
                        log.debug("{} : CheckAuth Start addslaves for rboId {} , bank phone {}, mts phone {}",uid, rboid, phone, clientPhone);
                        addSlaveResult = mtsGate.addSlaves(MtsConstants.ADD_SLAVES_KEY, req.getAccessToken(), req.getLogin(), phone, rboid, uid);
                    }
                } catch (Exception e) {
                    log.error("{} : ERROR: {}",uid,e);
                    e.printStackTrace();
                }
                if (addSlaveResult.equalsIgnoreCase("ERROR")){
                    res.setStatus(1);
                    res.setErrorCode(badPhones ? "500" : "509");
                    res.setErrorMessage(badPhones ? MtsConstants.checkClientPhoneError : MtsConstants.addSlavesError);
                } else {
                    res.setStatus(0);
                }
            } else {
                Map<String, String> errorMap = extraUtils.createErrorAnswer(outputParams, errorMessage);
                res.setStatus(1);
                res.setErrorCode(errorMap.get("errorCode"));
                res.setErrorMessage(errorMap.get("errorMessage"));
            }
            xmlResponse = xmlUnmarshaler.createXml(res);
        }
        return xmlResponse;
    }

}
