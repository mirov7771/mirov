package ru.mtsbank.integration.proxy.mtsproxyws;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import ru.diasoft.services.config.Log4jConfigurer;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.io.File;
import java.util.Arrays;


@SpringBootApplication
@EnableCaching
public class MtsproxywsApplication extends SpringBootServletInitializer {

	private static Logger LOG = Logger.getLogger(MtsproxywsApplication.class);

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(MtsproxywsApplication.class);
	}

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(MtsproxywsApplication.class, args);
	}

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		LogManager.resetConfiguration();
		Log4jConfigurer.deactivateInit();//отключаем безусловную инициализацию по log4j.properties
		File file = new File("mtsproxyws-log4j.properties");
		if (file.exists()) {
			PropertyConfigurator.configureAndWatch("mtsproxyws-log4j.properties");
		} else {
			PropertyConfigurator.configureAndWatch("log4j.properties");
		}
		Runtime.getRuntime().addShutdownHook(new Thread(LogManager::shutdown));
		LOG.info("ru.mtsbank.integration.proxy.mtsproxyws.MtsproxywsApplication.onStartup(1): servletContext=" + servletContext);
		System.out.println("ru.mtsbank.integration.proxy.mtsproxyws.MtsproxywsApplication.onStartup(2): servletContext=" + servletContext);
		super.onStartup(servletContext);
	}

	public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
		return args -> {
			String[] beanNames = ctx.getBeanDefinitionNames();
			Arrays.sort(beanNames);
			String beanNamesString = String.join("\n", beanNames);
			LOG.info("Let's inspect the beans provided by Spring Boot:\n" + beanNamesString);
		};
	}
}
