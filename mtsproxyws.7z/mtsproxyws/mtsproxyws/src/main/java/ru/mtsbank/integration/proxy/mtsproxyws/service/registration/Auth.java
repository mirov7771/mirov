package ru.mtsbank.integration.proxy.mtsproxyws.service.registration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.diasoft.utils.text.StringUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.FlexteraGate;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.MtsGate;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.ExtraUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.RegistrationReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.response.RegistrationRes;
import ru.mtsbank.integration.proxy.mtsproxyws.utils.MtsUtils;

import java.util.Map;

@Component("auth")
@Slf4j
public class Auth implements DboService {

    @Autowired
    private FlexteraGate flexteraGate;

    @Autowired
    private MtsGate mtsGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private MtsUtils mtsUtils;

    @Autowired
    private ExtraUtils extraUtils;

    @Override
    public String handleRequest(String xmlRequest, String auth, String uid)  throws MtsException{
        String xmlResponse = null;
        RegistrationReq req = xmlUnmarshaler.parse(RegistrationReq.class, xmlRequest);
        String login = req.getLogin();
        String pwd = req.getPassword();
        Map<String, Object> inputParams = mtsUtils.buildStartProcessParams();
        inputParams.put("PROCESSNAME", MtsConstants.authorizationProcess);
        inputParams.put("isEK", true);
        inputParams.put("needChangePass", true);
        inputParams.put("LoginPasswordCheckFlag", false);
        inputParams.put("LOGIN", login);
        inputParams.put("PasswordHash1", pwd);

        Map<String, Object> outputParams = flexteraGate.startProcess(inputParams, uid);
        if (outputParams != null) {
            String resultStatus = (String) outputParams.get("ResultStatus");
            String errorMessage = (String) outputParams.get("ErrorMessage");
            boolean badPhones = false;
            if (StringUtils.isEmpty(errorMessage))
                errorMessage = MtsConstants.wrongLoginOrPassword;
            RegistrationRes res = new RegistrationRes();
            if (!StringUtils.isEmpty(resultStatus) && resultStatus.equalsIgnoreCase("true")){
                String addSlaveResult = "";
                try {
                    String phone = (String) outputParams.get("ClientPhone");
                    String rboid = (String) outputParams.get("ClientRboId");
                    String clientPhone = mtsGate.getClientInfo(req.getAccessToken());
                    if (StringUtils.isEmpty(phone) || StringUtils.isEmpty(clientPhone)) {
                        log.debug("{} : Auth Bank And Mts Phone is empty for rboId {}",uid,rboid);
                        addSlaveResult = "ERROR";
                    } else if (!clientPhone.equals(phone)) {
                        log.debug("{} : Auth Bank phone {} not equals Mts phone {} for RboId {}",uid, phone, clientPhone, rboid);
                        badPhones = true;
                        addSlaveResult = "ERROR";
                    } else if (!StringUtils.isEmpty(phone) && !StringUtils.isEmpty(rboid)) {
                        log.debug("{} : Auth Start addslaves for rboId {} , bank phone {}, mts phone {}",uid, rboid, phone, clientPhone);
                        addSlaveResult = mtsGate.addSlaves(MtsConstants.ADD_SLAVES_KEY, req.getAccessToken(), req.getLogin(), phone, rboid, uid);
                    }
                } catch (Exception e) {
                    log.error("ERROR:"+e);
                    e.printStackTrace();
                }
                if (addSlaveResult.equalsIgnoreCase("ERROR")){
                    res.setStatus(1);
                    res.setErrorCode(badPhones ? "500" : "509");
                    res.setErrorMessage(badPhones ? MtsConstants.checkClientPhoneError : MtsConstants.addSlavesError);
                } else {
                    res.setStatus(0);
                }
            } else {
                Map<String, String> errorMap = extraUtils.createErrorAnswer(outputParams, errorMessage);
                res.setStatus(1);
                res.setErrorCode(errorMap.get("errorCode"));
                res.setErrorMessage(errorMap.get("errorMessage"));
            }
            xmlResponse = xmlUnmarshaler.createXml(res);
        }
        return xmlResponse;
    }

}
