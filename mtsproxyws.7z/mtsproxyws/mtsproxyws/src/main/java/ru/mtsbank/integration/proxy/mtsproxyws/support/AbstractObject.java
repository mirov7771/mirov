package ru.mtsbank.integration.proxy.mtsproxyws.support;

public abstract class AbstractObject implements ReqResObject {

    private static final long serialVersionUID = -4909851063709879518L;

}
