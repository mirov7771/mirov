package ru.mtsbank.integration.proxy.mtsproxyws.support;

import java.io.Serializable;

public interface ReqResObject extends Serializable {

}
