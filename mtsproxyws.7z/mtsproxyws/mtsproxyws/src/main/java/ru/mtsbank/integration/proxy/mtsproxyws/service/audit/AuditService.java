package ru.mtsbank.integration.proxy.mtsproxyws.service.audit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.FlexteraGate;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.AuditReq;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

@Component("auditService")
public class AuditService implements DboService {

    @Autowired
    private FlexteraGate flexteraGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Override
    public String handleRequest(String xmlRequest, String auth, String uid) throws MtsException {
        AuditReq req = xmlUnmarshaler.parse(AuditReq.class, xmlRequest);
        Map<String, Object> params = new HashMap<>();
        String login = req.getUserLogin();
        String operSysName = req.getOperationSysName();
        params.put("UserHostIP",auth);
        params.put("EventType","INFORMATION");
        params.put("EventGroup","Application");
        params.put("ModuleName", "FTONLINE");
        params.put("ServiceName", req.getServiceName());
        params.put("UserLogin", login);
        Map<String, Object> admin = flexteraGate.dsAccountFindById(login);
        params.put("UserAccountID", admin.get("USERACCOUNTID"));
        String descr = null;
        if (operSysName.equalsIgnoreCase("FTOSMSSend")){
            descr = String.format("Пользователю %s отправлена СМС", login);
        } else if (operSysName.equalsIgnoreCase("FTOClientLogin")){
            descr = String.format("Пользователь %s осуществил вход в систему", login);
        } else if (operSysName.equalsIgnoreCase("FTOClientRegistration")){
            descr = String.format("Пользователь %s осуществил восстановление логина/пароля", login);
        }
        operSysName = operSysName.replace("FTO", "Mts");
        params.put("OperationSysName", operSysName);
        descr = "IB "+descr;
        if (admin.get("EXTERNALID") != null)
            descr += " PersonID: "+admin.get("EXTERNALID");
        params.put("Description", descr);
        flexteraGate.dsAuditInsert(params);
        return null;
    }
}
