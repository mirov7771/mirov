package ru.mtsbank.integration.proxy.mtsproxyws.support.methods;

import java.util.HashSet;
import java.util.Set;

public class MethodType {

    private static final Set<String> METHOD_TYPES = new HashSet<>();

    private static final String sendCode = "sendCode";
    private static final String checkCode = "checkCode";
    private static final String changeLogin = "changeLogin";
    private static final String changePassword = "changePassword";
    private static final String auth = "auth";
    private static final String sendCodeAuth = "sendCodeAuth";
    private static final String checkAuth = "checkAuth";

    static {
        METHOD_TYPES.add(sendCode);
        METHOD_TYPES.add(checkCode);
        METHOD_TYPES.add(changeLogin);
        METHOD_TYPES.add(changePassword);
        METHOD_TYPES.add(auth);
        METHOD_TYPES.add(sendCodeAuth);
        METHOD_TYPES.add(checkAuth);
    }

    public static Set<String> getMethodTypes() {
        return METHOD_TYPES;
    }

    public static String getSendCode() {
        return sendCode;
    }

    public static String getCheckCode() {
        return checkCode;
    }

    public static String getChangeLogin() {
        return changeLogin;
    }

    public static String getChangePassword() {
        return changePassword;
    }

    public static String getAuth() {
        return auth;
    }
}
