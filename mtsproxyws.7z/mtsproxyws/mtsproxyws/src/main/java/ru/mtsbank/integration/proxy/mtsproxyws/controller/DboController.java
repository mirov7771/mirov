package ru.mtsbank.integration.proxy.mtsproxyws.controller;

import com.sun.xml.bind.v2.TODO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.ws.client.WebServiceFaultException;
import ru.diasoft.utils.text.StringUtils;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.methods.MethodType;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.AuditReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.RegistrationReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.response.RegistrationRes;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@RestController
@Slf4j
public class DboController {

    @Autowired
    private Map<String, DboService> dboServices;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @RequestMapping(value="/AuthDBO", method = RequestMethod.PUT)
    @ResponseBody
    public RegistrationRes authDBO(@RequestParam(value="method", defaultValue = "") String method,
                                   @RequestBody RegistrationReq req,
                                   @RequestHeader(value = "Authorization", defaultValue = "") String authorization){
        String uid = UUID.randomUUID().toString();
        log.debug("{} : start method {} , start time {}",uid, method, new Date());
        RegistrationRes res = new RegistrationRes();
        String xmlResponse;
        if (!MethodType.getMethodTypes().contains(method)) {
            res.setStatus(1);
            res.setErrorCode("504");
            res.setErrorMessage("Techincal Error");
        } else {
            String xmlRequest = xmlUnmarshaler.createXml(req);
            log.debug("{} : proccess method {} with params {}",uid, method, xmlRequest);
            xmlResponse = callMethod(method, xmlRequest, authorization, uid);
            log.debug("{} : end proccess method {} with params {}",uid, method, xmlResponse);
            if (!StringUtils.isEmpty(xmlResponse)) {
                res = xmlUnmarshaler.parse(RegistrationRes.class, xmlResponse);
            }
        }
        log.debug("{} : end method {} , end time {}",uid, method, new Date());
        return res;
    }

    @RequestMapping(value="/", method = RequestMethod.GET)
    public String test(){
        return "Application is running";
    }

    private String callMethod(String method, String xmlRequest, String auth, String uid){
        String xmlResponse;
        DboService service = dboServices.get(method);
        try {
            log.debug("{} : Calling service handler {}",uid,service.getClass());
            xmlResponse = service.handleRequest(xmlRequest, auth, uid);
        } catch (Exception e) {
            log.error("{} : Couldn't deliver message {}",uid, e);
            throw new WebServiceFaultException("Couldn't deliver message");
        }
        return xmlResponse;
    }

    @RequestMapping(value="audit", method = RequestMethod.POST)
    public void audit(@Context HttpServletRequest context, @RequestBody AuditReq req){
        String xmlRequest = xmlUnmarshaler.createXml(req);
        String remoteAddr = context.getHeader("X-FORWARDED-FOR");
        callMethod("auditService", xmlRequest, remoteAddr, "");
    }

}
