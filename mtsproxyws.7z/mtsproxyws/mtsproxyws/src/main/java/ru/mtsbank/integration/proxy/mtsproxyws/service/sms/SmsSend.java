package ru.mtsbank.integration.proxy.mtsproxyws.service.sms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.proxy.mtsproxyws.flextera.FlexteraGate;
import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.service.DboService;
import ru.mtsbank.integration.proxy.mtsproxyws.support.MtsConstants;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;
import ru.mtsbank.integration.proxy.mtsproxyws.support.request.SmsSendReq;
import ru.mtsbank.integration.proxy.mtsproxyws.support.response.SmsSendRes;
import ru.mtsbank.integration.proxy.mtsproxyws.utils.MtsUtils;

import java.math.BigDecimal;
import java.util.Map;

@Component("smsSend")
public class SmsSend implements DboService {

    @Autowired
    private FlexteraGate flexteraGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private MtsUtils mtsUtils;

    @Override
    public String handleRequest(String xmlRequest, String auth, String uid) throws MtsException {
        String xmlResponse = null;
        SmsSendReq req = xmlUnmarshaler.parse(SmsSendReq.class, xmlRequest);
        Map<String, Object> inputParams = mtsUtils.buildStartProcessParams();
        inputParams.put("PROCESSNAME", MtsConstants.smsSendProcess);
        inputParams.put("RboID", req.getRboID());
        if (req.getCode() != null) {
            inputParams.put("Code", req.getCode());
            inputParams.put("skipGetData", new BigDecimal(1));
        }
        inputParams.put("OperType", req.getOperType());
        Map<String, Object> outputParams = flexteraGate.startProcess(inputParams, uid);
        if (outputParams != null) {
            SmsSendRes res = new SmsSendRes();
            res.setSendStatus((String) outputParams.get("sendStatus"));
            res.setErrorMsg((String) outputParams.get("errorMsg"));
            xmlResponse = xmlUnmarshaler.createXml(res);
        }
        return xmlResponse;
    }

}
