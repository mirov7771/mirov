package ru.mtsbank.integration.proxy.mtsproxyws.service;

import ru.mtsbank.integration.proxy.mtsproxyws.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;

public interface DboService {

    String handleRequest(String xmlRequest, String auth, String uid)  throws MtsException;

}
