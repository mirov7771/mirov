package ru.mtsbank.integration.proxy.mtsproxyws.flextera;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.diasoft.utils.XMLUtil;
import ru.diasoft.utils.exception.XMLUtilException;
import ru.mtsbank.integration.proxy.mtsproxyws.config.MtsAppConfig;
import ru.mtsbank.integration.proxy.mtsproxyws.support.exception.MtsException;

import java.util.HashMap;
import java.util.Map;

import static ru.diasoft.utils.log.ParamFormatting.ValueForLog;

@Component
@Slf4j
public class FlexteraGate {

    private static final Long RETURN_CODE_TECHNICAL_ERROR = 1001L;
    private static final String RETURN_MESSAGE_TECHNICAL_ERROR = "Technical error. ";

    @Autowired
    private MtsAppConfig mtsAppConfig;

    private Map<String, Object> callSync(String urlString, String methodName, Map<String, Object> parameters, XMLUtil utilAuthorized, String uid)
            throws MtsException {

        try {
            log.debug("{} : dscall: [{}",uid, methodName + "]\r\n" + ValueForLog(parameters));
            final Map<String, Object> stringObjectMap = utilAuthorized.callService(urlString, methodName, parameters);
            if (log.isDebugEnabled()) {
                log.debug("{} : callSync.result: {}",uid, ValueForLog(stringObjectMap));
            }
            return stringObjectMap;
        } catch (XMLUtilException e) {
            log.error("{} : Error in calling {} , {}:",uid, methodName, e);
            throw new MtsException(RETURN_CODE_TECHNICAL_ERROR, RETURN_MESSAGE_TECHNICAL_ERROR);
        }
    }

    private void callAsync(String urlString, String methodName, Map<String, Object> parameters, XMLUtil utilAuthorized)
        throws MtsException {
        try{
            log.debug("dscall async: ["+methodName+"]\r\n"+ValueForLog(parameters));
            utilAuthorized.callServiceAsync(urlString, methodName, parameters);
        } catch (XMLUtilException e) {
            throw new MtsException(RETURN_CODE_TECHNICAL_ERROR, RETURN_MESSAGE_TECHNICAL_ERROR);
        }
    }


    public Map<String, Object> startProcess(Map<String, Object> inputParams, String uid) throws MtsException {
        XMLUtil util = new XMLUtil(mtsAppConfig.getTechUser(), mtsAppConfig.getTechPwd());
        return callSync(mtsAppConfig.getCorews(), "startprocess", inputParams, util, uid);
    }

    public Map<String, Object> startProcessAdmin(Map<String, Object> inputParams, String uid) throws MtsException {
        XMLUtil util = new XMLUtil(mtsAppConfig.getDsaUser(), mtsAppConfig.getDsaPwd());
        return callSync(mtsAppConfig.getCorews(), "startprocess", inputParams, util, uid);
    }

    public void dsAuditInsert(Map<String, Object> params) throws MtsException {
        XMLUtil util = new XMLUtil(mtsAppConfig.getTechUser(), mtsAppConfig.getTechPwd());
        callAsync(mtsAppConfig.getAuditws(), "dsAuditInsert", params, util);
    }

    public Map<String, Object> dsAccountFindById(String login) throws MtsException{
        XMLUtil util = new XMLUtil(mtsAppConfig.getTechUser(), mtsAppConfig.getTechPwd());
        Map<String, Object> params = new HashMap<>();
        params.put("LOGIN", login);
        return callSync(mtsAppConfig.getCorews(), "dsAccountFindById", params, util, "");
    }

}
