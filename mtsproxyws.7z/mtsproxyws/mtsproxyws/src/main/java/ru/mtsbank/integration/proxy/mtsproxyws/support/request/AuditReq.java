package ru.mtsbank.integration.proxy.mtsproxyws.support.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import ru.mtsbank.integration.proxy.mtsproxyws.support.AbstractObject;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
         "serviceName"
        ,"userLogin"
        ,"operationSysName"
})
@XmlRootElement(name = "FDX")
public class AuditReq extends AbstractObject {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "ServiceName", required = false)
    @JsonProperty("ServiceName")
    private String serviceName;
    @XmlElement(name = "UserLogin", required = true)
    @JsonProperty("UserLogin")
    private String userLogin;
    @XmlElement(name = "OperationSysName", required = true)
    @JsonProperty("OperationSysName")
    private String operationSysName;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public String getOperationSysName() {
        return operationSysName;
    }

    public void setOperationSysName(String operationSysName) {
        this.operationSysName = operationSysName;
    }
}
