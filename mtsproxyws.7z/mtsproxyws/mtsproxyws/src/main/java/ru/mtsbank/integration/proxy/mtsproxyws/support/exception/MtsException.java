package ru.mtsbank.integration.proxy.mtsproxyws.support.exception;

public class MtsException extends Exception {

    private Long errorCode;

    public MtsException(Long errorCode, String errorMessage) {

        super(errorMessage);
        this.errorCode = errorCode;
    }

    public MtsException(Long errorCode, String errorMessage, Exception e) {

        super(errorMessage, e);
        this.errorCode = errorCode;
    }

    public Long getErrorCode() {

        return errorCode;
    }
}

