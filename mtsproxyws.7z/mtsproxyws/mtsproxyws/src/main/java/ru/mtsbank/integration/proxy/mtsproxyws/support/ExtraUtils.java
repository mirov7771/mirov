package ru.mtsbank.integration.proxy.mtsproxyws.support;

import org.springframework.stereotype.Component;
import ru.diasoft.utils.text.StringUtils;

import java.util.HashMap;
import java.util.Map;

@Component
public class ExtraUtils {

    public Map<String, String> createErrorAnswer(Map<String, Object> params, String defValue){
        Map<String, String> outputParams = new HashMap<>();
        Object objErrorMessage = params.get("FaultMessage");
        Object objErrorCode = params.get("FaultCode");
        if (objErrorMessage == null){
            objErrorMessage = params.get("lastErrorMessage");
        }
        if (objErrorMessage == null){
            objErrorMessage = params.get("ErrorMessage");
        }
        if (objErrorCode == null){
            objErrorCode = params.get("lastErrorCode");
        }
        String errorMessage = getStringValue(objErrorMessage);
        String errorCode = getStringValue(objErrorCode);
        if (errorMessage != null) {
            errorMessage = errorMessage.contains("dsAccountFindById") ? "Учетная запись пользователя не найдена" : errorMessage;
            errorCode = "500";
        }
        errorMessage = getSubstring(errorMessage, "FaultMessage=\"", "\"\n");
        outputParams.put("errorMessage", errorMessage);
        if (StringUtils.isEmpty(outputParams.get("errorMessage")))
            outputParams.put("errorMessage",defValue);
        outputParams.put("errorCode", errorCode);
        return outputParams;
    }

    private String getSubstring(String str, String startVal, String endVal){
        if (StringUtils.isEmpty(str))
            return null;
        if (!str.contains(startVal))
            return str;
        int start = str.indexOf(startVal)+startVal.length();
        int end = str.indexOf(endVal);
        return str.substring(start, end);
    }

    private String getStringValue(Object value){
        if (value instanceof String) {
            return (String) value;
        } else if (value instanceof Long){
            Long id = (Long) value;
            return Long.toString(id);
        } else if (value instanceof Integer){
            Integer i = (Integer) value;
            return Integer.toString(i);
        }
        return null;
    }

}
