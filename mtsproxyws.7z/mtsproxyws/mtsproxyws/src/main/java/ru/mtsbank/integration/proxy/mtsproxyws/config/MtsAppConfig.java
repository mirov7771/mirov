package ru.mtsbank.integration.proxy.mtsproxyws.config;

import lombok.Getter;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

@Configuration
@Getter
public class MtsAppConfig {

    @Value("${application.validateCharset}")
    private String validateCharset;
    @Value("${application.corews}")
    private String corews;
    @Value("${application.auditws}")
    private String auditws;
    @Value("${application.techUser}")
    private String techUser;
    @Value("${application.techPwd}")
    private String techPwd;
    @Value("${application.dsaUser}")
    private String dsaUser;
    @Value("${application.dsaPwd}")
    private String dsaPwd;
    @Value("${application.clientId}")
    private String clientId;
    @Value("${application.clientPwd}")
    private String clientPwd;
    @Value("${application.mtsservice}")
    private String mtsservice;
    @Value("${application.mtshost}")
    private String mtshost;
    @Value("${application.documentation}")
    private String documentation;
    @Value("${application.oauth}")
    private String oauth;

}
