package ru.mtsbank.integration.proxy.mtsproxyws.support.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import ru.mtsbank.integration.proxy.mtsproxyws.support.AbstractObject;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
         "operType"
        ,"code"
        ,"rboID"
})
@XmlRootElement(name = "FDX")
public class SmsSendReq extends AbstractObject {

    private static final long serialVersionUID = 1L;

    @XmlElement(name = "OperType", required = true)
    @JsonProperty("OperType")
    private String operType;
    @XmlElement(name = "Code", required = false)
    @JsonProperty("Code")
    private String code;
    @XmlElement(name = "RboID", required = true)
    @JsonProperty("RboID")
    private String rboID;

    public String getOperType() {
        return operType;
    }

    public void setOperType(String operType) {
        this.operType = operType;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRboID() {
        return rboID;
    }

    public void setRboID(String rboID) {
        this.rboID = rboID;
    }
}
