package ru.sberx.report.dao.model;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "REPORTDICT")
@TypeDef(
        name = "string-array",
        typeClass = StringArrayType.class
)
public class ReportDictDao {

    @Id
    @Column(name = "REPORTID")
    private String reportId;
    @Column(name = "REQUIREDPARAMS")
    @Type(type = "string-array")
    private String[] requiredParams;
    @Column(name = "TEMPLATENAME")
    private String templateName;
}
