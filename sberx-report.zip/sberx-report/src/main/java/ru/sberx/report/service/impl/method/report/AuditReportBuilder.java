package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.report.service.impl.method.audit.AuditMethod;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Date;
import java.util.List;

@Slf4j
@Component
public class AuditReportBuilder extends ReportBuilder {

    private final AuditMethod auditMethod;

    public AuditReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                              ReportRepository reportRepository,
                              ReportDictRepository reportDictRepository,
                              ObjectMapper objectMapper,
                              UserAuthService userAuthService,
                              SberIRMService sberIRMService, AuditMethod auditMethod) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.auditMethod = auditMethod;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for Audit");
        InputStream template = getTemplate(req);
        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
        List<AuditRes> auditList = auditMethod.getV2(false);
        if (!CollectionUtils.isEmpty(auditList)) {
            ByteArrayOutputStream report = xlsxBuilder.buildAudit(auditList);
            return saveReport("Audit_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("Audit_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }
}
