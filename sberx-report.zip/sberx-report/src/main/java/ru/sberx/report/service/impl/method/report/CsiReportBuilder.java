package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.questionary.csi.res.CsiListRes;
import ru.sberx.dto.questionary.csi.support.CsiDto;
import ru.sberx.dto.questionary.questionary.questionary.req.TypeListReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class CsiReportBuilder extends ReportBuilder {

    private final QuestionaryService questionaryService;

    public CsiReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                            ReportRepository reportRepository,
                            ReportDictRepository reportDictRepository,
                            ObjectMapper objectMapper,
                            UserAuthService userAuthService,
                            SberIRMService sberIRMService, QuestionaryService questionaryService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.questionaryService = questionaryService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for CSI");
        InputStream template = getTemplate(req);
        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
        CsiListRes csiListRes = questionaryService.getCsiList();
        List<CsiDto> csiList = csiListRes.getValues();
        if (!CollectionUtils.isEmpty(csiList)) {
            List<Long> userIds = csiList.stream().map(CsiDto::getUserId).collect(Collectors.toList());
            TypeListReq typeListReq = new TypeListReq();
            typeListReq.setUserId(userIds);
            List<TypeRes> typeList = questionaryService.getTypeList(typeListReq);

            Map<Long, TypeRes> typeMap = typeList.stream().collect(Collectors.toMap(TypeRes::getQuestionnaireId, t -> t));
            ByteArrayOutputStream report = xlsxBuilder.buildCsi(csiList, typeMap);
            return saveReport("CSI_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("CSI_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }
}
