package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ibm.icu.text.Transliterator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.data.store.req.FileReq;
import ru.sberx.dto.data.store.res.FileRes;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.model.ReportDao;
import ru.sberx.report.dao.model.ReportDictDao;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

@Slf4j
public abstract class ReportBuilder {

    protected static final Base64.Encoder encoder = Base64.getEncoder();
    protected static final Transliterator toLatinTrans = Transliterator.getInstance("Russian-Latin/BGN");
    protected static final DateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
    private final DataStoreService dataStoreService;
    private final ReportRepository reportRepository;
    private final ReportDictRepository reportDictRepository;
    private final ObjectMapper objectMapper;
    private final UserAuthService userAuthService;
    private final SberIRMService sberIRMService;

    @Value("${application.external.sberirm.operationrole:0}")
    private String operationRole;
    @Value("${application.external.sberirm.templateid:0}")
    private String templateId;
    @Value("${application.external.sberirm.enable:false}")
    private Boolean enableSberIRM;

    public ReportBuilder(DataStoreService dataStoreServiceV1,
                         ReportRepository reportRepository,
                         ReportDictRepository reportDictRepository,
                         ObjectMapper objectMapper, UserAuthService userAuthService, SberIRMService sberIRMService) {
        this.dataStoreService = dataStoreServiceV1;
        this.reportRepository = reportRepository;
        this.reportDictRepository = reportDictRepository;
        this.objectMapper = objectMapper;
        this.userAuthService = userAuthService;
        this.sberIRMService = sberIRMService;
    }

    abstract String build(ReportReq req);

    public InputStream getTemplate(ReportReq req) {
        ReportDictDao reportDictDao = reportDictRepository.findById(req.getReportId())
                .orElseThrow(() -> new SberxException(SberxErrors.REPORT_NOT_FOUND));
        log.debug("Found report info: {}", reportDictDao);
        validateParams(reportDictDao, req);
        InputStream template = dataStoreService.getFile(reportDictDao.getTemplateName(), null);
        log.debug("Downloaded report template {}", reportDictDao.getTemplateName());
        return template;
    }

    protected String saveReport(String name, ReportReq req, ByteArrayOutputStream report) {
        FileReq fileReq  = new FileReq();
        if (enableSberIRM) {
            byte[] encryptedReport;
            try {
                encryptedReport = sberIRMService.encrypt(operationRole, templateId, name, report.toByteArray(), getUserLogin(req.getUserId()));
            } catch (Exception e) {
                throw new SberxException(SberxErrors.ERROR_CALL_ADJACENT_SYSTEM);
            }
            fileReq.setContentType("application/octet-stream");
            fileReq.setData(encoder.encodeToString(encryptedReport));
        } else {
            fileReq.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            fileReq.setData(encoder.encodeToString(report.toByteArray()));
        }
        fileReq.setName(name);
        fileReq.setSaveName(true);
        FileRes savedReport = dataStoreService.createFile(fileReq);
        log.debug("Report successfully saved: {}", savedReport);
        ReportDao reportDao = new ReportDao();
        reportDao.setReportId(req.getReportId());
        reportDao.setFileName(savedReport.getFileName());
        reportDao.setUserId(req.getUserId());
        reportDao.setDate(Date.from(Instant.now()));
        reportDao.setParams(req.toString());
        reportRepository.save(reportDao);
        log.debug("Report info successfully saved: {}", reportDao);
        return savedReport.getFileUrl();
    }

    private void validateParams(ReportDictDao reportDictDao, ReportReq req) {
        if (reportDictDao.getRequiredParams() != null && reportDictDao.getRequiredParams().length > 0) {
            Map<String, Object> reqMap = objectMapper.convertValue(req, new TypeReference<>() {
            });
            Map<String, Object> params = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            params.putAll(reqMap);
            List<String> missingParams = new ArrayList<>();
            for (String p : reportDictDao.getRequiredParams()) {
                if (params.get(p) == null) {
                    missingParams.add(p);
                }
            }
            if (!missingParams.isEmpty()) {
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: " + missingParams);
            }
        }
        log.debug("Report request has all necessary params");
    }

    private String getUserLogin(Long userId) {
        AuthReq authReq = new AuthReq();
        authReq.setUserId(userId);
        AuthRes userInfo = userAuthService.getUserInfo(authReq);
        if (!StringUtils.hasText(userInfo.getLogin())) {
            throw new SberxException(SberxErrors.USER_NOT_FOUND);
        }
        return userInfo.getLogin();
    }
}
