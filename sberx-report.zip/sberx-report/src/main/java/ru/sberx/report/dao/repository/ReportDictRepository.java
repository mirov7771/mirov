package ru.sberx.report.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.report.dao.model.ReportDictDao;

@Repository
public interface ReportDictRepository extends CrudRepository<ReportDictDao, String> {
}
