package ru.sberx.report.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.report.dao.model.ReportDao;

@Repository
public interface ReportRepository extends CrudRepository<ReportDao, Long> {
}
