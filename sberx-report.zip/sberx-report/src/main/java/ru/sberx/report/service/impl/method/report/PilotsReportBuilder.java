package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.guide.guide.res.GuideV2Res;
import ru.sberx.dto.guide.guide.res.ReferenceRes;
import ru.sberx.dto.questionary.questionary.pilot.req.PilotListReq;
import ru.sberx.dto.questionary.questionary.pilot.res.PilotListRes;
import ru.sberx.dto.questionary.questionary.pilot.support.PilotDto;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.guide.GuideService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
@Component
public class PilotsReportBuilder extends ReportBuilder {

    private final QuestionaryService questionaryService;
    private final GuideService guideService;

    public PilotsReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                               ReportRepository reportRepository,
                               ReportDictRepository reportDictRepository,
                               ObjectMapper objectMapper,
                               UserAuthService userAuthService,
                               SberIRMService sberIRMService,
                               QuestionaryService questionaryService, GuideService guideService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.questionaryService = questionaryService;
        this.guideService = guideService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for Pilots");
        InputStream template = getTemplate(req);
        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);

        List<GuideV2Res> guides = guideService.getGuideV2(List.of(3000L), null);
        Map<Long, String> industryMap = guides.stream()
                .flatMap(g -> g.getValues().stream())
                .collect(Collectors.toMap(ReferenceRes::getCode, ReferenceRes::getName));

        PilotListReq pilotListReq = new PilotListReq();
        pilotListReq.setState(List.of(20002L, 20003L, 20004L, 20005L, 20007L, 20008L, 20011L, 20012L, 20009L));
        PilotListRes pilotListRes = questionaryService.getPilotsList(pilotListReq);

        Predicate<PilotDto> filterDate = pilot -> (req.getDateFrom() == null || pilot.getCreated().getTime() > req.getDateFrom())
                && (req.getDateTo() == null || pilot.getCreated().getTime() < req.getDateTo());
        List<PilotDto> pilots = pilotListRes.getList().stream()
                .filter(filterDate)
                .sorted(Comparator.comparing(PilotDto::getCreated))
                .collect(Collectors.toList());

        if (!CollectionUtils.isEmpty(pilots)) {
            ByteArrayOutputStream report = xlsxBuilder.buildPilots(pilots, industryMap);
            return saveReport("Pilots_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("Pilots_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }

}
