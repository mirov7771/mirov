package ru.sberx.report.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "REPORTS")
public class ReportDao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "REPORTID")
    private String reportId;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "PARAMS")
    private String params;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "FILENAME")
    private String fileName;

}
