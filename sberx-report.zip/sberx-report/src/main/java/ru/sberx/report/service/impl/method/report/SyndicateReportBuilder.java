package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import ru.sberx.dto.guide.guide.res.ReferenceRes;
import ru.sberx.dto.questionary.syndicate.req.SyndicateReq;
import ru.sberx.dto.questionary.syndicate.res.SyndicateRes;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.guide.GuideService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
public class SyndicateReportBuilder extends ReportBuilder {

    private final QuestionaryService questionaryService;
    private final GuideService guideService;

    public SyndicateReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                                  ReportRepository reportRepository,
                                  ReportDictRepository reportDictRepository,
                                  ObjectMapper objectMapper,
                                  QuestionaryService questionaryService,
                                  GuideService guideService,
                                  UserAuthService userAuthService,
                                  SberIRMService sberIRMService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.questionaryService = questionaryService;
        this.guideService = guideService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for Syndicates");
        InputStream template = getTemplate(req);
        Map<String, List<ReferenceRes>> stateValues = guideService.getGuide(List.of(20000L, 39000L));
        List<Long> states = stateValues.get("State")
                .stream()
                .map(ReferenceRes::getCode)
                .distinct()
                .filter(code -> !code.equals(20009L))
                .collect(Collectors.toList());
        SyndicateReq syndicateReq = new SyndicateReq();
        syndicateReq.setState(states);
        syndicateReq.setDateFrom(req.getDateFrom());
        if (req.getDateTo() != null)
            syndicateReq.setDateTo(req.getDateTo() + 97190L);
        SyndicateRes syndicateList = questionaryService.getSyndicateList(syndicateReq);
        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
        if (!CollectionUtils.isEmpty(syndicateList.getList())) {
            Map<Long, String> guideValues = new HashMap<>();
            stateValues.get("SumInvestment").forEach(value -> guideValues.put(value.getCode(), value.getName()));
            ByteArrayOutputStream report = xlsxBuilder.buildSyndicate(syndicateList.getList(), guideValues);
            return saveReport("Syndicates_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("Syndicates_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }
}
