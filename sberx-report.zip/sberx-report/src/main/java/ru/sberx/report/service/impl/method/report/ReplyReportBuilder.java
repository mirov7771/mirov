package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.questionary.reply.req.ReplyListReq;
import ru.sberx.dto.questionary.reply.support.ReplyDTO;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ReplyReportBuilder extends ReportBuilder {

    private final QuestionaryService questionaryService;

    public ReplyReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                              ReportRepository reportRepository,
                              ReportDictRepository reportDictRepository,
                              ObjectMapper objectMapper,
                              UserAuthService userAuthService,
                              SberIRMService sberIRMService,
                              QuestionaryService questionaryService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.questionaryService = questionaryService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for replies");
        InputStream template = getTemplate(req);
        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
        ReplyListReq replyListReq = new ReplyListReq();
        replyListReq.setSchema("reply_report_mode");

        Predicate<ReplyDTO> filterDate = reply ->
                (req.getDateFrom() == null || TimeUnit.MILLISECONDS.toSeconds(reply.getDate().getTime()) >= req.getDateFrom())
                && (req.getDateTo() == null || TimeUnit.MILLISECONDS.toSeconds(reply.getDate().getTime()) <= req.getDateTo());

        List<ReplyDTO> replies = questionaryService.getReplyList(replyListReq).getList().stream()
                .filter(filterDate)
                .sorted(Comparator.comparing(ReplyDTO::getDate))
                .collect(Collectors.toList());

        if (!CollectionUtils.isEmpty(replies)) {
            ByteArrayOutputStream report = xlsxBuilder.buildReplies(replies);
            return saveReport("Replies_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("Replies_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }
}
