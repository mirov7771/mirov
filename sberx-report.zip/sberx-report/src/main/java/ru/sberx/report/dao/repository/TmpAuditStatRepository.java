package ru.sberx.report.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.report.dao.model.TmpAuditStat;

import javax.annotation.Nonnull;
import java.util.Date;
import java.util.List;

@Repository
public interface TmpAuditStatRepository extends CrudRepository<TmpAuditStat, Long> {
    @Nonnull
    @Override
    List<TmpAuditStat> findAll();
}
