package ru.sberx.report.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.dto.report.res.ReportRes;
import ru.sberx.report.service.Service;
import ru.sberx.utils.builder.ResponseBuilder;

import java.util.List;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class ServiceController {

    private final Service service;

    @GetMapping(value = "report")
    public ResponseEntity<ReportRes> getReport(@RequestHeader(value = "user-id", required = false) Long userId,
                                               ReportReq req) {
        req.setUserId(userId);
        return ResponseBuilder.ok(service.getReport(req));
    }

    @GetMapping(value = "audit")
    public ResponseEntity<List<AuditRes>> getAudit() {
        return ResponseBuilder.ok(service.getAudit());
    }
}