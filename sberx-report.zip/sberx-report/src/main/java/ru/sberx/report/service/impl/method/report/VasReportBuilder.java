package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.activity.req.GetReq;
import ru.sberx.dto.activity.res.ActivityGetRes;
import ru.sberx.dto.activity.support.ActivityInfoDto;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.dto.services.company.req.GetCompanyReq;
import ru.sberx.dto.services.company.support.CompanyDto;
import ru.sberx.dto.services.service.support.ServiceDto;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.activity.ActivityService;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.services.companies.CompaniesService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class VasReportBuilder extends ReportBuilder {

    private final ActivityService activityService;
    private final CompaniesService companiesService;

    public VasReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                            ReportRepository reportRepository,
                            ReportDictRepository reportDictRepository,
                            ObjectMapper objectMapper,
                            ActivityService activityService,
                            CompaniesService companiesService,
                            UserAuthService userAuthService,
                            SberIRMService sberIRMService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.activityService = activityService;
        this.companiesService = companiesService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for VAS");
        InputStream template = getTemplate(req);
        GetCompanyReq companyReq = new GetCompanyReq();
        companyReq.setCompanyId(req.getCompanyId());
        CompanyDto company = companiesService.getCompany(companyReq);
        if (company != null) {
            log.debug("Creating report for company {}", company.getName());
            List<ServiceDto> services = company.getServices();
            Map<Long, Long[]> clicksAndViews = new HashMap<>();
            if (!CollectionUtils.isEmpty(services)) {
                services.forEach(s -> {
                    GetReq activityReq = new GetReq();
                    activityReq.setName("Service");
                    activityReq.setId(List.of(s.getVasId()));
                    activityReq.setAction("clickLink");
                    List<ActivityGetRes> clicks = activityService.getActivities(activityReq);
                    long clickSize = clicks.stream()
                            .flatMap(c -> c.getActivity().stream())
                            .mapToLong(ActivityInfoDto::getUserId)
                            .distinct()
                            .count();
                    activityReq.setAction("view");
                    List<ActivityGetRes> views = activityService.getActivities(activityReq);
                    long viewSize = views.stream()
                            .flatMap(c -> c.getActivity().stream())
                            .mapToLong(ActivityInfoDto::getUserId)
                            .distinct()
                            .count();
                    clicksAndViews.put(s.getVasId(), new Long[]{clickSize, viewSize});
                });
            } else {
                services = List.of();
            }
            XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
            log.debug("Creating report with params: name - {}, dateFrom - {}, dateTo - {}, services - {}",
                    company.getName(), req.getDateFrom(), req.getDateTo(), services);
            ByteArrayOutputStream report = xlsxBuilder.buildVas(company.getName(), req.getDateFrom(), req.getDateTo(), services, clicksAndViews);
            String name;
            if (company.getName().matches("([а-яА-Я .,])+")) {
                name = (toLatinTrans.transform(company.getName()) + ".Report.xlsx").replace(" ", "_");
            } else {
                name = (company.getName() + ".Report.xlsx").replace(" ", "_");
            }
            return saveReport(name, req, report);
        }
        return null;
    }
}
