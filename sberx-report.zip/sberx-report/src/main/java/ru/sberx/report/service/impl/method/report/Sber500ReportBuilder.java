package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import ru.sberx.dto.guide.guide.res.GuideV2Res;
import ru.sberx.dto.questionary.questionary.questionary.req.QuestionnaireListReq;
import ru.sberx.dto.questionary.questionary.questionary.support.QuestionnaireDto;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.guide.GuideService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class Sber500ReportBuilder extends ReportBuilder {

    private final QuestionaryService questionaryService;
    private final GuideService guideService;

    @Value("${application.logo.url:https://bran.sber.ru/sberx-gateway}")
    private String logoUrl;

    public Sber500ReportBuilder(@Qualifier("dataStoreServiceV1") DataStoreService dataStoreServiceV1,
                                ReportRepository reportRepository,
                                GuideService guideService,
                                ReportDictRepository reportDictRepository,
                                ObjectMapper objectMapper,
                                QuestionaryService questionaryService1,
                                UserAuthService userAuthService,
                                SberIRMService sberIRMService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.questionaryService = questionaryService1;
        this.guideService = guideService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for Sber500");
        InputStream template = getTemplate(req);
        QuestionnaireListReq questionnaireListReq = new QuestionnaireListReq();
        questionnaireListReq.setType(0);
        questionnaireListReq.setSber500(true);
        questionnaireListReq.setState(List.of(20002L, 20003L, 20004L, 20005L, 20007L, 20008L, 20011L, 20012L, 20009L));
        List<QuestionnaireDto> questionnaires = questionaryService.getQuestionnaireList(questionnaireListReq);

        Set<Long> ids = new HashSet<>();
        for(QuestionnaireDto q : questionnaires){
            if (q.getParentId() != null) {
                if (!ids.contains(q.getParentId()))
                    ids.add(q.getParentId());
                q.setQuestionnaireId(q.getParentId());
            }
        }

        List<QuestionnaireDto> formattedQuestionnaires
                = questionnaires.stream()
                .filter(i -> i.getParentId() == null && ids.contains(i.getQuestionnaireId()))
                .collect(Collectors.toList());

        questionnaires.removeAll(formattedQuestionnaires);

        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
        if (!CollectionUtils.isEmpty(questionnaires)) {
            List<GuideV2Res> guides = guideService.getGuideV2(
                    List.of(
                            2000L, // Страна
                            8000L, // Модели продаж
                            3000L, // Индустрии
                            13000L, // Технологии
                            24000L, // Бизнес-модель
                            27000L, // Стадия продукта
                            5000L, // Продажи
                            38000L // Потребности
                    ),
                    null);
            Map<Long, String> guideValues = new HashMap<>();
            guides.stream().flatMap(g -> g.getValues().stream()).forEach(value -> {
                guideValues.put(value.getCode(), value.getName());
            });
            questionnaires.sort(Comparator.comparing(QuestionnaireDto::getCreated));
            ByteArrayOutputStream report = xlsxBuilder.buildSber500(questionnaires, guideValues, logoUrl);
            return saveReport("Applications_Sber500_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("Applications_Sber500_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }
}
