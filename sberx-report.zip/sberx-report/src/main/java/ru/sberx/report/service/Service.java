package ru.sberx.report.service;

import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.dto.report.res.ReportRes;

import java.util.List;

public interface Service {
    ReportRes getReport(ReportReq req);
    List<AuditRes> getAudit();
}
