package ru.sberx.report.service.impl.method;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.CollectionUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.csi.support.CsiDto;
import ru.sberx.dto.questionary.questionary.pilot.support.PilotDto;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.questionary.questionary.questionary.support.*;
import ru.sberx.dto.questionary.reply.support.ReplyDTO;
import ru.sberx.dto.questionary.statistic.support.StatisticDto;
import ru.sberx.dto.questionary.syndicate.support.SyndicateDto;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.dto.services.service.support.ServiceDto;
import ru.sberx.utils.util.ObjectUtils;
import ru.sberx.utils.util.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class XlsxBuilder {

    private final Workbook template;

    private final DateFormat year = new SimpleDateFormat("yyyy");
    private final DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
    private final DateFormat dateTimeWithTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public XlsxBuilder(InputStream template) {
        try {
            this.template = new XSSFWorkbook(template);
        } catch (IOException e) {
            log.error("Could not read xlsx", e);
            throw new SberxException(SberxErrors.INTERNAL_ERROR, e.getMessage());
        }
    }

    public ByteArrayOutputStream buildVas(String companyName, Long dateFrom, Long dateTo, List<ServiceDto> reports, Map<Long, Long[]> clicksAndViews) {
        Sheet main = template.getSheetAt(0);
        Row header = main.getRow(1);
        header.createCell(0).setCellValue(companyName);
        if (dateFrom != null) {
            header.createCell(5).setCellValue(dateTimeWithTime.format(Date.from(Instant.ofEpochSecond(dateFrom))));
        }
        if (dateTo != null) {
            header.createCell(6).setCellValue(dateTimeWithTime.format(Date.from(Instant.ofEpochSecond(dateTo))));
        }
        for (int i = 0; i < reports.size(); i++) {
            Row row = main.createRow(i + 3);
            ServiceDto vas = reports.get(i);
            row.createCell(0).setCellValue(i + 1D);
            row.createCell(1).setCellValue(vas.getSmallNote());
            row.createCell(2).setCellValue(vas.getDiscount());
            if (clicksAndViews.containsKey(vas.getVasId())) {
                row.createCell(4).setCellValue(clicksAndViews.get(vas.getVasId())[0]);
                row.createCell(3).setCellValue(clicksAndViews.get(vas.getVasId())[1]);
            }
            if (vas.getDateFrom() != null) {
                row.createCell(5).setCellValue(dateTimeWithTime.format(vas.getDateFrom()));
            } else {
                row.createCell(5).setBlank();
            }
            if (vas.getDateTo() != null) {
                row.createCell(6).setCellValue(dateTimeWithTime.format(vas.getDateTo()));
            } else {
                row.createCell(6).setBlank();
            }
        }
        return writeWorksheet();
    }

    public ByteArrayOutputStream buildStats(List<StatisticDto> statistics) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < statistics.size(); i++) {
            Row row = main.createRow(i + 1);
            StatisticDto s = statistics.get(i);
            row.createCell(0).setCellValue(s.getId());
            if (s.getUid() != null)
                row.createCell(1).setCellValue(s.getUid());
            if (s.getType() != null)
                row.createCell(2).setCellValue(s.getType());
            if (s.getInvestorType() != null)
                row.createCell(3).setCellValue(s.getInvestorType());
            if (s.getFullName() != null)
                row.createCell(4).setCellValue(s.getFullName());
            if (s.getName() != null)
                row.createCell(5).setCellValue(s.getName());
            row.createCell(6).setCellValue(s.getCreated());
            if (s.getModified() != null)
                row.createCell(7).setCellValue(s.getModified());
            if (s.getState() != null)
                row.createCell(8).setCellValue(s.getState());
            if (s.getSber500() != null)
                row.createCell(9).setCellValue(s.getSber500());
            if (s.getParenId() != null)
                row.createCell(10).setCellValue(s.getParenId());
            if (s.getInn() != null)
                row.createCell(11).setCellValue(s.getInn());
            if (s.getBirthday() != null)
                row.createCell(12).setCellValue(s.getBirthday());
            if (s.getSite() != null)
                row.createCell(13).setCellValue(s.getSite());
            if (s.getRegistrationCountry() != null)
                row.createCell(14).setCellValue(s.getRegistrationCountry());
            if (s.getEmail() != null)
                row.createCell(15).setCellValue(s.getEmail());

            if (s.getPhoneNumber() != null)
                row.createCell(16).setCellValue(s.getPhoneNumber());
            if (s.getContact() != null)
                row.createCell(17).setCellValue(s.getContact());
            if (s.getNote() != null)
                row.createCell(18).setCellValue(s.getNote());
            if (s.getInvestorType() != null)
                row.createCell(19).setCellValue(s.getInvestorType());
            if (!CollectionUtils.isEmpty(s.getBusinessModel()))
                row.createCell(20).setCellValue(Arrays.toString(s.getBusinessModel().toArray()));
            if (s.getLocationCountry() != null)
                row.createCell(21).setCellValue(s.getLocationCountry());
            if (s.getLocation() != null)
                row.createCell(22).setCellValue(s.getLocation());
            if (!CollectionUtils.isEmpty(s.getIndustry()))
                row.createCell(23).setCellValue(Arrays.toString(s.getIndustry().toArray()));
            if (!CollectionUtils.isEmpty(s.getTechnology()))
                row.createCell(24).setCellValue(Arrays.toString(s.getTechnology().toArray()));
            if (s.getLogo() != null)
            row.createCell(25).setCellValue(s.getLogo());
            if (!CollectionUtils.isEmpty(s.getMvpCode()))
                row.createCell(26).setCellValue(Arrays.toString(s.getMvpCode().toArray()));
            if (s.getDemoVideo() != null)
                row.createCell(27).setCellValue(s.getDemoVideo());
            row.createCell(28).setCellValue(s.getProblem());
            row.createCell(29).setCellValue(s.getAuditory());
            row.createCell(30).setCellValue(s.getPresent());
            if (!CollectionUtils.isEmpty(s.getGeography()))
                row.createCell(31).setCellValue(Arrays.toString(s.getGeography().toArray()));
            if (!CollectionUtils.isEmpty(s.getSales()))
                row.createCell(32).setCellValue(Arrays.toString(s.getSales().toArray()));
            if (s.getTurnover() != null)
                row.createCell(33).setCellValue(s.getTurnover());
            if (s.getCompetitor() != null)
                row.createCell(34).setCellValue(s.getCompetitor());
            if (s.getUpside() != null)
                row.createCell(35).setCellValue(s.getUpside());
            if (s.getStaff() != null)
                row.createCell(36).setCellValue(s.getStaff());
            if (s.getRoleNote() != null)
                row.createCell(37).setCellValue(s.getRoleNote());
            if (s.getSuccessPilots() != null)
                row.createCell(38).setCellValue(s.getSuccessPilots());
            if (s.getReference() != null)
                row.createCell(39).setCellValue(s.getReference());
            if (s.getPilot() != null)
                row.createCell(40).setCellValue(s.getPilot());
            if (s.getSuggestCase() != null)
                row.createCell(41).setCellValue(s.getSuggestCase());
            if (s.getExperience() != null)
                row.createCell(42).setCellValue(s.getExperience());
            if (s.getLastInvestment() != null)
                row.createCell(43).setCellValue(s.getLastInvestment());
            if (s.getCoInvestment() != null)
                row.createCell(44).setCellValue(s.getCoInvestment());
            if (!CollectionUtils.isEmpty(s.getEcoRequirement()))
                row.createCell(45).setCellValue(Arrays.toString(s.getEcoRequirement().toArray()));
            if (s.getFirstTime() != null)
                row.createCell(46).setCellValue(s.getFirstTime());
            if (s.getMonthRevenue() != null)
                row.createCell(47).setCellValue(s.getMonthRevenue());
            if (s.getQuarterRevenue() != null)
                row.createCell(48).setCellValue(s.getQuarterRevenue());
            if (s.getClients() != null)
                row.createCell(49).setCellValue(s.getClients());
            if (s.getIsImport() != null)
                row.createCell(50).setCellValue(s.getIsImport());
            if (s.getIrName() != null)
                row.createCell(51).setCellValue(s.getIrName());
            if (s.getIrNote() != null)
                row.createCell(52).setCellValue(s.getIrNote());
            if (s.getIrBenefits() != null)
                row.createCell(53).setCellValue(s.getIrBenefits());
        }
        return writeWorksheet();
    }

    public ByteArrayOutputStream buildSber500(List<QuestionnaireDto> questionnaires, Map<Long, String> guideValues, String logoUrl) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < questionnaires.size(); i++) {
            Row row = main.createRow(i + 1);
            QuestionnaireDto questionnaire = questionnaires.get(i);
            row.createCell(0).setCellValue(i + 1);
            row.createCell(1).setCellValue(questionnaire.getQuestionnaireId());
            row.createCell(2).setCellValue(questionnaire.getFullName());
            row.createCell(3).setCellValue(questionnaire.getName());
            row.createCell(4).setCellValue(questionnaire.getInn());
            row.createCell(5).setCellValue(year.format(questionnaire.getBirthDay()));
            row.createCell(6).setCellValue(questionnaire.getSite());
            row.createCell(7).setCellValue(guideValues.get(questionnaire.getRegistrationCountry()));
            row.createCell(8).setCellValue(questionnaire.getEmail());
            row.createCell(9).setCellValue(questionnaire.getPhoneNumber());
            if (questionnaire.getBusinessModel() != null) {
                row.createCell(13).setCellValue(convertCodeToNames(guideValues, questionnaire.getBusinessModel()));
            }
            row.createCell(14).setCellValue(guideValues.get(questionnaire.getLocationCountry()));
            row.createCell(15).setCellValue(questionnaire.getLocation());
            row.createCell(18).setCellValue(prepareFileUrl(questionnaire.getLogoFile(), logoUrl));
            row.createCell(31).setCellValue(Boolean.TRUE.equals(questionnaire.getSuccessPilots()));
            row.createCell(33).setCellValue(Boolean.TRUE.equals(questionnaire.getPilot()));

            ProjectDto project = questionnaire.getProject();
            if (project != null) {
                row.createCell(11).setCellValue(project.getNote()); //project_note
                if (project.getInteractionType() != null) {
                    row.createCell(12).setCellValue(convertCodeToNames(guideValues, project.getInteractionType())); //project_interactionType
                }
                if (project.getIndustry() != null) {
                    row.createCell(16).setCellValue(convertCodeToNames(guideValues, project.getIndustry())); //project_industry
                }
                if (project.getTechnology() != null) {
                    row.createCell(17).setCellValue(convertCodeToNames(guideValues, project.getTechnology())); //project_technology
                }
                if (project.getMvpCode() != null) {
                    row.createCell(19).setCellValue(convertCodeToNames(guideValues, project.getMvpCode())); //project_mvpCode
                }
                row.createCell(20).setCellValue(project.getDemoVideo()); //project_demoVideo
                row.createCell(21).setCellValue(project.getProblem()); //project_problem
                row.createCell(22).setCellValue(project.getAuditory()); //project_auditory
                if (project.getGeography() != null) {
                    row.createCell(24).setCellValue(convertCodeToNames(guideValues, project.getGeography())); //project_geography
                }
                if (project.getSales() != null) {
                    row.createCell(25).setCellValue(convertCodeToNames(guideValues, project.getSales())); //project_sales
                }
                row.createCell(27).setCellValue(project.getCompetitor()); //project_competitor
                row.createCell(28).setCellValue(project.getUpSide()); //project_upSide
                row.createCell(29).setCellValue(ObjectUtils.nvl(project.getStaff(), 0)); //project_staff
            }

            InvestmentDto investment = questionnaire.getQInvestment();
            if (investment != null) {

                row.createCell(23).setCellValue(prepareFileUrl(investment.getBusinessPlan(), logoUrl)); //investment_businessPlan
                row.createCell(26).setCellValue(investment.getTurnover()); //investment_turnover
                row.createCell(36).setCellValue(investment.getLastInvestment()); //investment_lastInvestment
                row.createCell(37).setCellValue(investment.getCoInvestment()); //investment_coInvestment
            }

            List<ContactDto> contacts = questionnaire.getContacts();
            if (!CollectionUtils.isEmpty(contacts)) {
                StringBuilder contactsString = new StringBuilder();
                for (ContactDto contact : contacts) {
                    contactsString.append(contact.getName()).append(";");
                }
                row.createCell(10).setCellValue(contactsString.toString()); //contacts[]_name
            }

            List<WorkerDto> workers = questionnaire.getWorker();
            if (!CollectionUtils.isEmpty(workers)) {
                StringBuilder workersString = new StringBuilder();
                for (WorkerDto worker : workers) {
                    workersString.append("(")
                            .append(ObjectUtils.nvl(worker.getRole(), ""))
                            .append(",")
                            .append(ObjectUtils.nvl(worker.getNote(), ""))
                            .append("),");
                }
                if (workersString.length() > 0) {
                    workersString.deleteCharAt(workersString.length() - 1);
                }
                row.createCell(30).setCellValue(workersString.toString()); //worker_role, worker_note
            }

            List<PilotDto> pilots = questionnaire.getSuccessPilotsList();
            if (!CollectionUtils.isEmpty(pilots)) {
                pilots.stream()
                        .filter(p -> Boolean.TRUE.equals(p.getIsB2B()))
                        .map(p -> "(" + p.getReference() + "," + p.getSuggestCase() + ")")
                        .reduce((p1, p2) -> p1 + "," + p2)
                        .ifPresent(s -> row.createCell(32).setCellValue(s)); //Pilot_reference, Pilot_suggestCas);

                pilots.stream()
                        .filter(p -> Boolean.TRUE.equals(p.getEcoSystem()))
                        .findAny()
                        .ifPresent(p -> {
                            row.createCell(34).setCellValue(p.getSuggestCase()); //Pilot_suggestCase
                            row.createCell(35).setCellValue(Boolean.TRUE.equals(p.getExperience())); //Pilot_experience
                        });
            }

            if (questionnaire.getEcosystemPilot() != null
                    && questionnaire.getEcosystemPilot().getSuggestCase() != null
                    && !"".equals(questionnaire.getEcosystemPilot().getSuggestCase())) {
                row.createCell(34).setCellValue(questionnaire.getEcosystemPilot().getSuggestCase());
                row.createCell(35).setCellValue(true);
            } else {
                row.createCell(35).setCellValue(false);
            }

            SberFiveHundredDto sber500 = questionnaire.getSberFiveHundred();
            if (sber500 != null) {
                if (sber500.getEcoRequirement() != null) {
                    List<Long> codes = Arrays.stream(sber500.getEcoRequirement()).map(Integer::longValue).collect(Collectors.toList());
                    row.createCell(38).setCellValue(convertCodeToNames(guideValues, codes)); //sberFiveHundred_ecorequirement
                }
                row.createCell(39).setCellValue(Boolean.TRUE.equals(sber500.getFirstTime())); //sberFiveHundred_firsttime
                row.createCell(40).setCellValue(ObjectUtils.nvl(sber500.getMonthRevenue(), "0")); //sberFiveHundred_monthrevenue
                row.createCell(41).setCellValue(ObjectUtils.nvl(sber500.getQuarterRevenue(), "0")); //sberFiveHundred_quarterrevenue
                row.createCell(42).setCellValue(ObjectUtils.nvl(sber500.getClients(), 0)); //sberFiveHundred_clients
            }

            row.createCell(43).setCellValue(Boolean.TRUE.equals(questionnaire.getMailingConsent()));
        }
        return writeWorksheet();
    }

    private String prepareFileUrl(String url, String logoUrl) {
        if (url == null || "".equals(url))
            return "";
        String formattedUrl = StringUtils.getLogo(url);
        if (formattedUrl.contains("/sberx-gateway"))
            formattedUrl = formattedUrl.replace("/sberx-gateway", "");
        if (formattedUrl.contains("sberx-gateway"))
            formattedUrl = formattedUrl.replace("sberx-gateway", "");
        return logoUrl + formattedUrl;
    }

    public ByteArrayOutputStream buildSyndicate(List<SyndicateDto> syndicates, Map<Long, String> guideValues) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < syndicates.size(); i++) {
            SyndicateDto syndicate = syndicates.get(i);
            Row row = main.createRow(i + 1);
            row.createCell(0).setCellValue(dateTimeWithTime.format(syndicate.getCreated()));
            row.createCell(1).setCellValue(syndicate.getLastName());
            row.createCell(2).setCellValue(syndicate.getFirstName());
            row.createCell(3).setCellValue(syndicate.getEmail());
            row.createCell(4).setCellValue(syndicate.getPhone());
            row.createCell(5).setCellValue(syndicate.getTelegramLink());
            row.createCell(6).setCellValue(syndicate.getOrgFullName());
            row.createCell(7).setCellValue(syndicate.getVentureExperience());
            row.createCell(8).setCellValue(guideValues.get(syndicate.getSumInvestment()));
        }
        return writeWorksheet();
    }

    public ByteArrayOutputStream buildPilots(List<PilotDto> pilots, Map<Long, String> industryMap) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < pilots.size(); i++) {
            PilotDto pilot = pilots.get(i);
            QuestionnaireDto questionnaire = pilot.getQuestionnaire();
            Row row = main.createRow(i + 1);
            row.createCell(0).setCellValue(pilot.getPilotId());
            row.createCell(1).setCellValue(pilot.getStateName());
            if (questionnaire != null) {
                row.createCell(2).setCellValue(questionnaire.getQuestionnaireId());
                if (questionnaire.getUuid() != null)
                    row.createCell(3).setCellValue(questionnaire.getUuid());
                if (questionnaire.getName() != null)
                    row.createCell(4).setCellValue(questionnaire.getName());
            }
            if (pilot.getName() != null)
                row.createCell(5).setCellValue(pilot.getName());
            if (pilot.getIndustry() != null && pilot.getIndustry().length > 0) {
                String namesIndustry = Arrays.stream(pilot.getIndustry())
                        .map(industryMap::get)
                        .filter(org.springframework.util.StringUtils::hasText)
                        .collect(Collectors.joining(", "));
                row.createCell(6).setCellValue(namesIndustry);
            }
        }
        return writeWorksheet();
    }

    public ByteArrayOutputStream buildReplies(List<ReplyDTO> replies) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < replies.size(); i++) {
            ReplyDTO reply = replies.get(i);
            Row row = main.createRow(i + 1);
            row.createCell(0).setCellValue(reply.getReplyId());
            row.createCell(1).setCellValue(dateTimeWithTime.format(reply.getDate()));
            row.createCell(2).setCellValue(reply.getState());
            row.createCell(3).setCellValue(reply.getOfferName());
            row.createCell(4).setCellValue(reply.getQuestionnaireName());
            row.createCell(5).setCellValue(reply.getStartupUID());
            row.createCell(6).setCellValue(reply.getEMail());
            row.createCell(7).setCellValue(reply.getStartupSite());
            row.createCell(8).setCellValue(reply.getOfferDescription());
            row.createCell(9).setCellValue(reply.getFileUrl());
            row.createCell(10).setCellValue(reply.getCorporateFullName());
            row.createCell(11).setCellValue(reply.getCorporateUID());
        }
        return writeWorksheet();
    }

    public ByteArrayOutputStream buildAudit(List<AuditRes> auditList) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < auditList.size(); i++) {
            AuditRes audit = auditList.get(i);
            Row row = main.createRow(i + 1);
            if (audit.getDate() != null)
                row.createCell(0).setCellValue(date.format(audit.getDate()));
            row.createCell(1).setCellValue(audit.getUserId());
            row.createCell(2).setCellValue(audit.getType());
            if (audit.getQuestionnaireId() != null)
                row.createCell(3).setCellValue(audit.getQuestionnaireId());
            if (audit.getQuestionnaireUUID() != null)
                row.createCell(4).setCellValue(audit.getQuestionnaireUUID().toString());
            row.createCell(5).setCellValue(audit.getAmount());
        }
        return writeWorksheet();
    }

    public ByteArrayOutputStream buildCsi(List<CsiDto> csiList, Map<Long, TypeRes> typeMap) {
        Sheet main = template.getSheetAt(0);
        for (int i = 0; i < csiList.size(); i++) {
            CsiDto csiDto = csiList.get(i);
            Row row = main.createRow(i + 1);
            row.createCell(0).setCellValue(date.format(csiDto.getDate()));
            row.createCell(1).setCellValue(csiDto.getUserId());
            row.createCell(2).setCellValue(csiDto.getQuestionnaireId());
            TypeRes typeRes = typeMap.get(csiDto.getQuestionnaireId());
            if (typeRes != null) {
                row.createCell(3).setCellValue(typeRes.getName());
                row.createCell(4).setCellValue(getTypeNameOfQuestionnaire(typeRes.getType()));
                row.createCell(5).setCellValue(typeRes.getStateName());
            }
            row.createCell(6).setCellValue(csiDto.getValue());
        }
        return writeWorksheet();
    }

    private String getTypeNameOfQuestionnaire(Integer type) {
        if (Integer.valueOf(0).equals(type))
            return "Стартап";
        if (Integer.valueOf(1).equals(type))
            return "Корпорация";
        if (Integer.valueOf(2).equals(type))
            return "Инвестор";
        return null;
    }

    public ByteArrayOutputStream buildEmptyReport() {
        return writeWorksheet();
    }

    private String convertCodeToNames(Map<Long, String> guideValues, Long[] codes) {
        return convertCodeToNames(guideValues, new ArrayList<>(Arrays.asList(codes)));
    }

    private String convertCodeToNames(Map<Long, String> guideValues, List<Long> codes) {
        StringBuilder names = new StringBuilder();
        for (Long code : codes) {
            if (guideValues.get(code) != null)
                names.append(guideValues.get(code)).append("; ");
        }
        int length = names.length();
        if (length > 0) {
            names.delete(length - 2, length);
        }
        return names.toString();
    }

    private ByteArrayOutputStream writeWorksheet() {
        try (ByteArrayOutputStream res = new ByteArrayOutputStream()) {
            for (int i = 0; i < template.getNumberOfSheets(); i++) {
                Sheet sheet = template.getSheetAt(i);
                int firstCellNum = sheet.getRow(0).getFirstCellNum();
                int lastCellNum = sheet.getRow(0).getLastCellNum();
                for (int j = firstCellNum; j < lastCellNum; j++) {
                    sheet.autoSizeColumn(j);
                }
            }
            template.write(res);
            template.close();
            res.close();
            log.debug("Report successfully created");
            return res;
        } catch (IOException e) {
            log.error("Could not write xlsx", e);
            throw new SberxException(SberxErrors.INTERNAL_ERROR, e.getMessage());
        }
    }
}
