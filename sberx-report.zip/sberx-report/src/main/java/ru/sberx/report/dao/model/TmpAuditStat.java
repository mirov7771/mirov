package ru.sberx.report.dao.model;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.dto.report.res.AuditRes;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Table(name = "TMP_AUDIT_STAT")
@Entity
@Getter
@Setter
public class TmpAuditStat implements Serializable {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "Q_ID")
    private Long qId;
    @Column(name = "Q_UUID")
    private UUID qUUID;
    @Column(name = "ENTERS")
    private Integer enters;

    public AuditRes toDto() {
        AuditRes dto = new AuditRes();
        dto.setType(this.type);
        dto.setUserId(this.userId);
        dto.setQuestionnaireId(this.qId);
        dto.setQuestionnaireUUID(this.qUUID);
        dto.setDate(this.date);
        dto.setAmount(this.enters);
        return dto;
    }
}
