package ru.sberx.report.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.dto.report.res.ReportRes;
import ru.sberx.report.service.Service;
import ru.sberx.report.service.impl.method.audit.AuditMethod;
import ru.sberx.report.service.impl.method.report.*;

import java.util.List;
import java.util.Locale;
import java.util.Set;

import static ru.sberx.constants.Constants.Header.CLIENT_ID;

@Component
@Slf4j
@RequiredArgsConstructor
public class ServiceImpl implements Service {

    private final static Set<String> reportsWithAccess = Set.of("sber500", "syndicate");

    private final VasReportBuilder vasReportBuilder;
    private final StatsReportBuilder statsReportBuilder;
    private final Sber500ReportBuilder sber500ReportBuilder;
    private final SyndicateReportBuilder syndicateReportBuilder;
    private final PilotsReportBuilder pilotsReportBuilder;
    private final ReplyReportBuilder replyReportBuilder;
    private final AuditReportBuilder auditReportBuilder;
    private final AuditMethod auditMethod;
    private final CsiReportBuilder csiReportBuilder;

    @Override
    public ReportRes getReport(ReportReq req) {
        log.info("Getting report");
        log.debug("Get report request: {}", req);
        if (req.getUserId() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        validateAccess(req);
        ReportRes res = new ReportRes();
        res.setUserId(req.getUserId());
        if ("VAS".equalsIgnoreCase(req.getReportId())) {
            res.setFileLink(vasReportBuilder.build(req));
        } else if ("STATS".equalsIgnoreCase(req.getReportId())) {
            res.setFileLink(statsReportBuilder.build(req));
        } else if ("Sber500".equalsIgnoreCase(req.getReportId())) {
            setReportClientId();
            res.setFileLink(sber500ReportBuilder.build(req));
        } else if ("Syndicate".equalsIgnoreCase(req.getReportId())) {
            setReportClientId();
            res.setFileLink(syndicateReportBuilder.build(req));
        } else if ("Pilots".equalsIgnoreCase(req.getReportId())) {
            res.setFileLink(pilotsReportBuilder.build(req));
        } else if ("Reply".equalsIgnoreCase(req.getReportId())) {
            res.setFileLink(replyReportBuilder.build(req));
        } else if ("Audit".equalsIgnoreCase(req.getReportId())) {
            res.setFileLink(auditReportBuilder.build(req));
        } else if ("CSI".equalsIgnoreCase(req.getReportId())) {
            res.setFileLink(csiReportBuilder.build(req));
        }
        if (res.getFileLink() != null && res.getFileLink().contains("/sberx-gateway"))
            res.setFileLink(res.getFileLink().replace("/sberx-gateway", ""));
        log.debug("Report Response: {}", res);
        log.info("Report returned");
        return res;
    }

    @Override
    public List<AuditRes> getAudit() {
        return auditMethod.get(true);
    }

    private void setReportClientId() {
        ThreadContext.put(CLIENT_ID, "111261");
    }

    private void validateAccess(ReportReq req) {
        if (reportsWithAccess.contains(req.getReportId().toLowerCase(Locale.ROOT))
                && !Boolean.TRUE.equals(req.getReportsUse())) {
            throw new SberxException(SberxErrors.THE_REPORT_IS_UNAVAILABLE);
        }
    }
}
