package ru.sberx.report.service.impl.method.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.questionary.statistic.req.StatisticReq;
import ru.sberx.dto.questionary.statistic.support.StatisticDto;
import ru.sberx.dto.report.req.ReportReq;
import ru.sberx.external.gate.SberIRMService;
import ru.sberx.report.dao.repository.ReportDictRepository;
import ru.sberx.report.dao.repository.ReportRepository;
import ru.sberx.report.service.impl.method.XlsxBuilder;
import ru.sberx.unity.gate.data.store.DataStoreService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.Instant;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

@Slf4j
@Component
public class StatsReportBuilder extends ReportBuilder {

    private final QuestionaryService questionaryService;

    public StatsReportBuilder(@Qualifier("dataStoreServiceV1")DataStoreService dataStoreServiceV1,
                              ReportRepository reportRepository,
                              ReportDictRepository reportDictRepository,
                              ObjectMapper objectMapper,
                              QuestionaryService questionaryService,
                              UserAuthService userAuthService,
                              SberIRMService sberIRMService) {
        super(dataStoreServiceV1, reportRepository, reportDictRepository, objectMapper, userAuthService, sberIRMService);
        this.questionaryService = questionaryService;
    }

    @Override
    public String build(ReportReq req) {
        log.debug("Creating report for STATS");
        InputStream template = getTemplate(req);
        StatisticReq statisticReq = new StatisticReq();
        statisticReq.setUserId(req.getUserId());
        statisticReq.setDateFrom(req.getDateFrom());
        if (req.getDateTo() != null)
            statisticReq.setDateTo(req.getDateTo() + 97190L);

        statisticReq.setType(req.getType());
        List<StatisticDto> statistics = questionaryService.getStatistic(statisticReq);

        log.debug("statistics {}", statistics);
        XlsxBuilder xlsxBuilder = new XlsxBuilder(template);
        if (!CollectionUtils.isEmpty(statistics)) {
            ByteArrayOutputStream report = xlsxBuilder.buildStats(statistics);
            return saveReport("sber_unity_stats_" + dateTimeFormat.format(Date.from(Instant.now())), req, report);
        }
        return saveReport("sber_unity_stats_" + dateTimeFormat.format(Date.from(Instant.now())), req, xlsxBuilder.buildEmptyReport());
    }
}
