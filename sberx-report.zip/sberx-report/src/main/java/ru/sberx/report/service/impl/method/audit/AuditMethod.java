package ru.sberx.report.service.impl.method.audit;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.dto.audit.req.AuditStatisticReq;
import ru.sberx.dto.audit.res.AuditStatisticRes;
import ru.sberx.dto.questionary.questionary.questionary.req.TypeListReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.dto.user.auth.req.UserInfoListReq;
import ru.sberx.dto.user.auth.support.UserInfoDto;
import ru.sberx.report.dao.model.TmpAuditStat;
import ru.sberx.report.dao.repository.TmpAuditStatRepository;
import ru.sberx.unity.gate.audit.AuditService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.user.auth.UserAuthService;
import ru.sberx.utils.util.ObjectUtils;

import javax.annotation.PostConstruct;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Component
@RequiredArgsConstructor
public class AuditMethod {

    private final AuditService auditService;
    private final UserAuthService userAuthService;
    private final QuestionaryService questionaryService;
    private final TmpAuditStatRepository tmpAuditStatRepository;

    private final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private static final Map<Long, String> investorTypeMap = Map.of(
            11001L, "Венчурный фонд",
            11002L, "Бизнес-ангел",
            11004L, "Family Office"
    );

    @Getter @Setter
    @AllArgsConstructor
    private static class UniqueRow {
        Long userId;
        Date date;
    }

    @PostConstruct
    private void init() {
        CompletableFuture.supplyAsync(() -> getV2(false));
    }

    public List<AuditRes> getV2(Boolean oneDayAgo) {
        List<AuditRes> res = new ArrayList<>();
        List<TmpAuditStat> audit = tmpAuditStatRepository.findAll();
        AuditStatisticRes auditStatistic;
        if (CollectionUtils.isEmpty(audit))
            auditStatistic = getAuditStatistic(oneDayAgo);
        else {
            Date maxDate = audit.stream().max(Comparator.comparing(TmpAuditStat::getDate)).orElse(new TmpAuditStat()).getDate();
            if (maxDate == null) {
                auditStatistic = getAuditStatistic(oneDayAgo);
            } else if (maxDate.before(new Date())) {
                auditStatistic = getAuditStatisticByDates(maxDate);
            } else {
                return audit.stream().map(TmpAuditStat::toDto).collect(Collectors.toList());
            }
        }
        if (auditStatistic != null && !CollectionUtils.isEmpty(auditStatistic.getRows())) {
            List<UniqueRow> uniqueRows = new ArrayList<>();
            auditStatistic.getRows().forEach(i -> {
                if (i.getDate() != null && uniqueRows.stream().noneMatch(uniqueRow -> i.getUserId().equals(uniqueRow.getUserId())
                        && i.getDate().equals(uniqueRow.getDate())))
                    uniqueRows.add(new UniqueRow(i.getUserId(), i.getDate()));
            });
            List<Long> userIds = uniqueRows.stream().map(UniqueRow::getUserId).collect(Collectors.toList());
            List<UserInfoDto> userInfoList = getUserInfoList(userIds);
            if (!CollectionUtils.isEmpty(userInfoList)) {
                List<Long> externalIds = userInfoList.stream().map(UserInfoDto::getExternalId).filter(Objects::nonNull).collect(Collectors.toList());
                List<TypeRes> typeList = new ArrayList<>();
                for(int i = 0; i < externalIds.size(); i += 500) {
                    List<TypeRes> list = getTypeList(externalIds.stream().skip(i).limit(500).collect(Collectors.toList()));
                    if (!CollectionUtils.isEmpty(list))
                        typeList.addAll(list);
                }
                for (UniqueRow i : uniqueRows) {
                    AuditRes a = new AuditRes();
                    a.setUserId(i.userId);
                    Stream<AuditStatisticRes.Row> rowStream = auditStatistic.getRows().stream().filter(as -> i.getUserId().equals(as.getUserId())
                            && i.getDate() != null && as.getDate().equals(i.getDate()));
                    a.setAmount((int) rowStream.count());
                    a.setDate(i.getDate());
                    a.setUserId(i.getUserId());
                    Optional<UserInfoDto> external = userInfoList.stream().filter(u -> u.getExternalId() != null && i.getUserId().equals(u.getUserId())).max(Comparator.comparing(UserInfoDto::getExternalId));
                    if (external.isPresent()) {
                        UserInfoDto userInfoDto = external.get();
                        Long externalId = userInfoDto.getExternalId();
                        Optional<TypeRes> type = typeList.stream().filter(t -> externalId.equals(t.getUserId())).findFirst();
                        if (type.isPresent()) {
                            TypeRes typeRes = type.get();
                            a.setQuestionnaireId(typeRes.getQuestionnaireId());
                            a.setQuestionnaireUUID(typeRes.getQuestionnaireUUID());
                            a.setType(getType(typeRes.getType(), typeRes.getStateName(), typeRes.getInvestorType()));
                        }
                    }
                    if (!StringUtils.hasText(a.getType()))
                        a.setType("Администратор");
                    res.add(a);
                }
            }
        }
        if (!CollectionUtils.isEmpty(res)) {
            tmpAuditStatRepository.saveAll(res.stream().map(i -> {
                TmpAuditStat stat = new TmpAuditStat();
                stat.setEnters(i.getAmount());
                stat.setQUUID(i.getQuestionnaireUUID());
                stat.setQId(i.getQuestionnaireId());
                stat.setType(i.getType());
                stat.setDate(i.getDate());
                stat.setUserId(i.getUserId());
                return stat;
            }).collect(Collectors.toList()));
            res.sort(Comparator.comparing(AuditRes::getDate).thenComparing(AuditRes::getType).thenComparing(AuditRes::getUserId));
            return tmpAuditStatRepository.findAll().stream().map(TmpAuditStat::toDto).collect(Collectors.toList());
        }
        return res;
    }

    private String getType(Integer type, String state, String investorType) {
        if (Integer.valueOf(0).equals(type) && "active".equals(state))
            return "Стартап, опубликован";
        else if (Integer.valueOf(0).equals(type) && !"active".equals(state))
            return "Стартап, прочие статусы";
        else if (Integer.valueOf(1).equals(type) && "active".equals(state))
            return "Корпорация, опубликован";
        else if (Integer.valueOf(1).equals(type) && !"active".equals(state))
            return "Корпорация, прочие статусы";
        else if (Integer.valueOf(2).equals(type) && "active".equals(state) && investorTypeMap.get(11001L).equals(investorType))
            return "Венчурный фонд, опубликован";
        else if (Integer.valueOf(2).equals(type) && !"active".equals(state) && investorTypeMap.get(11001L).equals(investorType))
            return "Венчурный фонд, прочие статусы";
        else if (Integer.valueOf(2).equals(type) && "active".equals(state) && investorTypeMap.get(11002L).equals(investorType))
            return "Бизнес ангел, опубликован";
        else if (Integer.valueOf(2).equals(type) && !"active".equals(state) && investorTypeMap.get(11002L).equals(investorType))
            return "Бизнес ангел, прочие статусы";
        else if (Integer.valueOf(2).equals(type) && "active".equals(state) && investorTypeMap.get(11004L).equals(investorType))
            return "Family Office, опубликован";
        else if (Integer.valueOf(2).equals(type) && !"active".equals(state) && investorTypeMap.get(11004L).equals(investorType))
            return "Family Office, прочие статусы";
        else if (Integer.valueOf(2).equals(type) && "active".equals(state)
                && StringUtils.hasText(investorType) && !investorTypeMap.containsValue(investorType))
            return "Прочий инвестор, опубликован";
        else if (Integer.valueOf(2).equals(type) && !"active".equals(state)
                && StringUtils.hasText(investorType) && !investorTypeMap.containsValue(investorType))
            return "Прочий инвестор, прочие статусы";
        else if (Integer.valueOf(2).equals(type))
            return "Инвестор, прочие статусы";
        else if (Integer.valueOf(1).equals(type))
            return "Корпорация, прочие статусы";
        else if (Integer.valueOf(0).equals(type))
            return "Стартап, прочие статусы";
        return null;
    }

    public List<AuditRes> get(Boolean oneDayAgo) {
        List<AuditRes> res = new ArrayList<>();
        Map<Long, List<Date>> userIdToListDateMap = new HashMap<>();
        AuditStatisticRes auditStatisticRes = getAuditStatistic(oneDayAgo);
        if (!CollectionUtils.isEmpty(auditStatisticRes.getRows())) {
            List<AuditStatisticRes.Row> rows = auditStatisticRes.getRows().stream().distinct().collect(Collectors.toList());
            List<Long> userIdsDistinct = rows.stream()
                    .peek(row -> {
                        if (userIdToListDateMap.get(row.getUserId()) == null) {
                            List<Date> dateList = new ArrayList<>();
                            dateList.add(row.getDate());
                            userIdToListDateMap.put(row.getUserId(), dateList);
                        } else {
                            userIdToListDateMap.get(row.getUserId()).add(row.getDate());
                        }
                    })
                    .map(AuditStatisticRes.Row::getUserId)
                    .distinct()
                    .collect(Collectors.toList());

            List<UserInfoDto> userInfoList = getUserInfoList(userIdsDistinct);
            Map<Date, Map<String, Integer>> resMap = new HashMap<>();
            Map<Long, List<Date>> externalIdToListDateMap = new HashMap<>();
            List<Long> externalIdList = userInfoList.stream()
                    .peek(userInfoDto -> {
                        List<Date> dates = userIdToListDateMap.get(userInfoDto.getUserId());
                        if (userInfoDto.getExternalId() == null) {
                            dates.forEach(date -> {
                                Map<String, Integer> typeToCountMap = resMap.get(date);
                                if (typeToCountMap == null)
                                    typeToCountMap = new HashMap<>();
                                typeToCountMap.merge("Администратор", 1, Integer::sum);
                                resMap.put(date, typeToCountMap);
                            });
                        } else {
                            externalIdToListDateMap.put(userInfoDto.getExternalId(), dates);
                        }
                    })
                    .map(UserInfoDto::getExternalId)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

            List<TypeRes> typeList = getTypeList(externalIdList);
            typeList.forEach(t -> {
                String typeName = getType(t.getType(), t.getStateName(), t.getInvestorType());
                if (typeName != null) {
                    List<Date> dates = externalIdToListDateMap.get(t.getUserId());
                    if (dates != null) {
                        dates.forEach(d -> {
                            Map<String, Integer> typeToCountMap = resMap.get(d);
                            if (typeToCountMap == null)
                                typeToCountMap = new HashMap<>();
                            typeToCountMap.merge(typeName, 1, Integer::sum);
                            resMap.put(d, typeToCountMap);
                        });
                    }
                }
            });
            if (CollectionUtils.isEmpty(resMap) && Boolean.TRUE.equals(oneDayAgo)) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(new Date());
                cal.add(Calendar.DAY_OF_MONTH, -1);
                resMap.put(cal.getTime(), new HashMap<>());
            }
            resMap.forEach((date, typeCountMap) -> {
                Map<String, Integer> map = fillEmptyFields(typeCountMap);
                map.forEach((type, count) -> {
                    AuditRes audit = new AuditRes();
                    audit.setType(type);
                    audit.setAmount(count);
                    audit.setDate(date);
                    res.add(audit);
                });
            });
            if (!Boolean.TRUE.equals(oneDayAgo))
                res.sort(Comparator.comparing(AuditRes::getDate).reversed());
        }
        return res;
    }

    private Map<String,Integer> fillEmptyFields(Map<String, Integer> typeCountMap) {
        Map<String, Integer> map = new LinkedHashMap<>();
        map.put("Администратор", ObjectUtils.nvl(typeCountMap.get("Администратор"), 0));
        map.put("Стартап, опубликован", ObjectUtils.nvl(typeCountMap.get("Стартап, опубликован"), 0));
        map.put("Стартап, прочие статусы", ObjectUtils.nvl(typeCountMap.get("Стартап, прочие статусы"), 0));
        map.put("Корпорация, опубликован", ObjectUtils.nvl(typeCountMap.get("Корпорация, опубликован"), 0));
        map.put("Корпорация, прочие статусы", ObjectUtils.nvl(typeCountMap.get("Корпорация, прочие статусы"), 0));
        map.put("Венчурный фонд, опубликован", ObjectUtils.nvl(typeCountMap.get("Венчурный фонд, опубликован"), 0));
        map.put("Венчурный фонд, прочие статусы", ObjectUtils.nvl(typeCountMap.get("Венчурный фонд, прочие статусы"), 0));
        map.put("Бизнес ангел, опубликован", ObjectUtils.nvl(typeCountMap.get("Бизнес ангел, опубликован"), 0));
        map.put("Бизнес ангел, прочие статусы", ObjectUtils.nvl(typeCountMap.get("Бизнес ангел, прочие статусы"), 0));
        map.put("Family Office, опубликован", ObjectUtils.nvl(typeCountMap.get("Family Office, опубликован"), 0));
        map.put("Family Office, прочие статусы", ObjectUtils.nvl(typeCountMap.get("Family Office, прочие статусы"), 0));
        map.put("Прочий инвестор, опубликован", ObjectUtils.nvl(typeCountMap.get("Прочий инвестор, опубликован"), 0));
        map.put("Прочий инвестор, прочие статусы", ObjectUtils.nvl(typeCountMap.get("Прочий инвестор, прочие статусы"), 0));
        return map;
    }

    private AuditStatisticRes getAuditStatistic(Boolean oneDayAgo) {
        AuditStatisticReq req = new AuditStatisticReq();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DAY_OF_MONTH, -1);
        String dayAgo = dateFormat.format(cal.getTime());

        req.setDateBegin(Boolean.TRUE.equals(oneDayAgo) ? dayAgo : null);
        req.setDateEnd(Boolean.TRUE.equals(oneDayAgo) ? dayAgo : null);
        log.debug("get audit/statistic with param: {}", req);
        return auditService.getAuditStatistic(req);
    }

    private AuditStatisticRes getAuditStatisticByDates(Date startDate) {
        AuditStatisticReq req = new AuditStatisticReq();
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);
        cal.add(Calendar.DAY_OF_MONTH, 1);
        String dayAgo = dateFormat.format(cal.getTime());
        req.setDateBegin(dayAgo);

        cal.setTime(new Date());
        String day = dateFormat.format(cal.getTime());
        req.setDateEnd(day);
        log.debug("get audit/statistic with param: {}", req);
        return auditService.getAuditStatistic(req);
    }

    private List<UserInfoDto> getUserInfoList(List<Long> userIds) {
        List<UserInfoDto> userInfoList;
        UserInfoListReq req = new UserInfoListReq();
        req.setUserId(userIds);
        userInfoList = userAuthService.getUserInfoList(req);
        return userInfoList;
    }

    private List<TypeRes> getTypeList(List<Long> externalIds) {
        TypeListReq req = new TypeListReq();
        List<TypeRes> typeList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(externalIds)) {
            req.setUserId(externalIds);
            log.debug("get type/list with param: {}", req);
            typeList = questionaryService.getTypeList(req);
        }
        return typeList;
    }

}
