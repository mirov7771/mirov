CREATE TABLE reportDict
(
    reportId       varchar(50) PRIMARY KEY,
    requiredParams varchar(50)[],
    templateName   varchar
);

CREATE TABLE reports
(
    id       bigint    NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    reportId varchar(50),
    date     timestamp null,
    params   varchar(255),
    userId   bigint,
    fileName varchar
);

CREATE INDEX x1_reports ON reports (reportId);
CREATE INDEX x2_reports ON reports (userId);