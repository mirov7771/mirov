--liquibase formatted sql
--changeset Timoshkin M:insert dict
update reportdict
set templatename = 'report_template'
where reportid = 'VAS';