--liquibase formatted sql
--changeset Zakutskiy MY:insert_pilots
delete from reportdict where reportid = 'Pilots';
insert into reportdict (reportid, templatename)
values ('Pilots', 'pilots_template');