--liquibase formatted sql
--changeset Zakutskiy MY:insert_csi
delete from reportdict where reportid = 'CSI';
insert into reportdict (reportid, templatename)
values ('CSI', 'csi_template');