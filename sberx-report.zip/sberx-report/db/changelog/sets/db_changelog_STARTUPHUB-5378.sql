--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5378
drop table if exists TMP_AUDIT_STAT;

create table TMP_AUDIT_STAT (
    id bigserial,
    date timestamp,
    user_id bigint,
    type varchar,
    q_id bigint,
    q_uuid uuid,
    enters bigint
);


create index x1_tmp_audit_stat on TMP_AUDIT_STAT(date);
