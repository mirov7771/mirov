--liquibase formatted sql
--changeset Timoshkin M:create table
CREATE TABLE reportdict
(
    reportid       varchar(50) PRIMARY KEY,
    requiredparams varchar(50)[],
    templatename   varchar
);

CREATE TABLE reports
(
    id       bigint    NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    reportid varchar(50),
    date     timestamp null,
    params   varchar(255),
    userid   bigint,
    filename varchar
);

CREATE INDEX x1_reports ON reports (reportId);
CREATE INDEX x2_reports ON reports (userId);