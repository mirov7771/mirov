--liquibase formatted sql
--changeset Timoshkin M:insert_statistics
insert into reportdict (reportid, templatename)
values ('Sber500', 'sber500_template');