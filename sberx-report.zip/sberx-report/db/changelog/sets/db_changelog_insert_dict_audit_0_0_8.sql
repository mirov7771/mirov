--liquibase formatted sql
--changeset Zakutskiy MY:insert_audit
delete from reportdict where reportid = 'Audit';
insert into reportdict (reportid, templatename)
values ('Audit', 'audit_template');