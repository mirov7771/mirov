--liquibase formatted sql
--changeset Timoshkin M:insert_statistics
insert into reportdict (reportid, templatename)
values ('STATS', 'stats_template');