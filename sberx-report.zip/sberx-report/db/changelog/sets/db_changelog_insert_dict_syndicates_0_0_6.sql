--liquibase formatted sql
--changeset Timoshkin M:insert_syndicates
insert into reportdict (reportid, templatename)
values ('Syndicate', 'syndicate_template');