--liquibase formatted sql
--changeset Konovalenko VI:insert_reply
delete from reportdict where reportid = 'Reply';
insert into reportdict (reportid, templatename)
values ('Reply', 'reply_template');