--liquibase formatted sql
--changeset Timoshkin M:insert dict
insert into reportdict (reportid, requiredparams, templatename)
values ('VAS', '{companyId}', 'Шаблон отчетов');