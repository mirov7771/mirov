# Сервис отчетов

### sberx-report

Confluence: https://sbtatlas.sigma.sbrf.ru/wiki/pages/viewpage.action?pageId=5007672607