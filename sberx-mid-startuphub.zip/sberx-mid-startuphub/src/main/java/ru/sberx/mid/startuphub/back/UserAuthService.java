package ru.sberx.mid.startuphub.back;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import ru.sberx.configs.web.WebConfig;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;

@Service
public class UserAuthService {
    private final WebClient webClient;
    private final String checkSessionMethod;
    private final String getUrlMethod;
    private final String getLastSessionMethod;

    public UserAuthService(WebClient webClient,
                           @Value("${application.sberx.user.auth.uri}") String uri,
                           @Value("${application.sberx.user.auth.checksession}") String checkSessionMethod,
                           @Value("${application.sberx.user.auth.url.get}") String getUrlMethod,
                           @Value("${application.sberx.user.auth.lastsession}") String getLastSessionMethod) throws URISyntaxException {
        this.webClient = webClient;
        this.checkSessionMethod = new URI(uri + checkSessionMethod).normalize().toString();
        this.getUrlMethod = new URI(uri + getUrlMethod).normalize().toString();
        this.getLastSessionMethod = new URI(uri + getLastSessionMethod).normalize().toString();
    }

    public SessionInfo checkSession(String sessionId) {
        WebConfig.logSending(checkSessionMethod, "sessionId", sessionId);
        SessionInfo sessionInfo = webClient.get()
                .uri(checkSessionMethod, uriBuilder -> uriBuilder.pathSegment("{id}").build(sessionId))
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(SessionInfo.class)
                .block();
        WebConfig.logReceiving(checkSessionMethod, sessionInfo);
        return sessionInfo;
    }

    public Urls getUrls(Boolean termsOfUse,
                        Boolean privacyPolicy,
                        Boolean sber500PrivacyPolicy,
                        Boolean sber500Consent,
                        Boolean sber500TermOfUse,
                        Boolean sber500PersonaDataConsent,
                        Boolean mailingConsent)
    {
        WebConfig.logSending(getUrlMethod, "termsOfUse", termsOfUse,
                "privacyPolicy", privacyPolicy,
                "sber500PrivacyPolicy", sber500PrivacyPolicy,
                "sber500Consent", sber500Consent,
                "sber500TermOfUse", sber500TermOfUse,
                "sber500PersonaDataConsent", sber500PersonaDataConsent,
                "mailingConsent", mailingConsent);
        Urls u = webClient.get()
                .uri(getUrlMethod, uriBuilder -> uriBuilder
                        .queryParam("termsOfUse", termsOfUse)
                        .queryParam("privacyPolicy", privacyPolicy)
                        .queryParam("sber500PrivacyPolicy", sber500PrivacyPolicy)
                        .queryParam("sber500Consent", sber500Consent)
                        .queryParam("sber500TermOfUse", sber500TermOfUse)
                        .queryParam("sber500PersonaDataConsent", sber500PersonaDataConsent)
                        .queryParam("mailingConsent", mailingConsent)
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Urls.class)
                .block();
        WebConfig.logReceiving(getUrlMethod, u);
        if (u == null)
            u = new Urls();
        if (u.getTermsURL() == null) {
            u.setTermsURL("");
        }
        if (u.getPolicyURL() == null) {
            u.setPolicyURL("");
        }
        if (u.getSber500ConsentURL() == null) {
            u.setSber500ConsentURL("");
        }
        if (u.getSber500PersonaDataConsentURL() == null) {
            u.setSber500PersonaDataConsentURL("");
        }
        if (u.getSber500PrivacyPolicyURL() == null) {
            u.setSber500PrivacyPolicyURL("");
        }
        if (u.getSber500TermOfUseURL() == null) {
            u.setSber500TermOfUseURL("");
        }
        if (u.getMailingConsentURL() == null) {
            u.setMailingConsentURL("");
        }
        return u;
    }

    public LastSessionDto getLastSession(Long externalId) {
        WebConfig.logSending(getLastSessionMethod, "externalId", externalId);
        LastSessionDto lastSessionDto = webClient.get()
                .uri(getLastSessionMethod, uriBuilder -> uriBuilder.queryParam("externalId", externalId).build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(LastSessionDto.class)
                .block();
        WebConfig.logReceiving(getLastSessionMethod, lastSessionDto);
        return lastSessionDto;
    }

    @Data
    public static class SessionInfo {
        private String login;
        private String role;
        private Long externalId;
        private String departmentId;
        private Long userId;
        private Integer userRole;
        private String sbid;
        private String email;
        private String name;
        private String orgName;
        private String phoneNumber;
        private String position;
    }

    @Data
    public static class Urls {
        private String termsURL;
        private String policyURL;
        private String sber500PrivacyPolicyURL;
        private String sber500ConsentURL;
        private String sber500TermOfUseURL;
        private String sber500PersonaDataConsentURL;
        private String mailingConsentURL;
    }

    @Data
    public static class LastSessionDto {
        private Date lastSession;
    }
}
