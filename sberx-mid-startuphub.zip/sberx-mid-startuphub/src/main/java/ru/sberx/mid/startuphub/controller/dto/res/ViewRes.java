package ru.sberx.mid.startuphub.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.mid.startuphub.back.QuestionnaireService;
import ru.sberx.mid.startuphub.back.ScreenBuilderService;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ViewRes {
    private Object id;
    private String uid;
    private Integer type;
    private String name;
    private String fullName;
    private String logoFile;
    private Double rating;
    private Boolean isControlShow;
    private List<ScreenBuilderService.Form> forms;
    private QuestionnaireService.QuestionnaireInfo questionnaire;
    private List<ScreenBuilderService.ButtonRes.ButtonDto> buttons;
    private State state;
    private String offerDescription;
    private String secondOfferDescription;
    private String clickAction;
    private String clickMethod;
    private Long stateCode;
    private String stateName;
    private Long questionnaireId;
    private String comment;
    private String email;
    private String date;
    private Boolean favorite;
    private String description;
    private String info;
    private String phone;
    private String viewCount;
    private Integer abuseState;
    private Long questionnaireStateCode;
    private String questionnaireStateName;
    private PopupFooter popupFooter;
    private String tariff;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class State{
        private String logoFile;
        private String title;
        private String description;
        private String comment;
        private Long stateCode;
        private String stateName;

        public State(Long stateCode, String stateName) {
            this.stateCode = stateCode;
            this.stateName = stateName;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class PopupFooter{
        private String title;
        private String caption;
        private String mainButtonText;
        private String secondButtonText;
    }
}
