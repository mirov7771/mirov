package ru.sberx.mid.startuphub.back;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.WebClient;
import ru.sberx.configs.web.WebConfig;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.req.AuthReq;

import javax.annotation.PostConstruct;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class GuideService {
    private final WebClient webClient;
    private final String getGuideV2Method;
    private final String getGuideMethod;
    private final String getGuideFilterMethod;
    private final String abuseMethod;
    private final Intervals staffMapping;
    private final String searchMethod;

    public static final Map<Integer, String> INVESTOR_NAMES = new HashMap<>();
    public static final Map<Long, String> STATES = new HashMap<>();

    public GuideService(WebClient webClient,
                        @Value("${application.sberx.guide.uri}") String uri,
                        @Value("${application.sberx.guide.guide}") String getGuideMethod,
                        @Value("${application.sberx.guide.guide-v2}") String getGuideV2Method,
                        @Value("${application.sberx.guide.filter}") String getGuideFilterMethod,
                        @Value("${application.sberx.guide.search}") String searchMethod) throws URISyntaxException {
        this.webClient = webClient;
        this.getGuideV2Method = new URI(uri + getGuideV2Method).normalize().toString();
        this.getGuideMethod = new URI(uri + getGuideMethod).normalize().toString();
        this.staffMapping = new Intervals();
        this.getGuideFilterMethod = new URI(uri + getGuideFilterMethod).normalize().toString();
        this.abuseMethod = new URI(uri + "/abuse").toString();
        this.searchMethod = new URI(uri + searchMethod).normalize().toString();
    }

    @PostConstruct
    void setGuides() {
        try {
            Staff s = getStaffGuide();
            if (s != null) {
                for (Values g : s.getStaff()) {
                    String[] bounds = g.getName().split("-");
                    int lowerBound = Integer.parseInt(bounds[0]);
                    int upperBound = Integer.parseInt(bounds[1]);
                    staffMapping.add(g.getCode(), lowerBound, upperBound);
                }
            }

            getInvestorNames();
            getStates();
        } catch (Exception e) {
            log.error("Error while getting staff ", e);
        }
    }

    private Staff getStaffGuide() {
        WebConfig.logSending(getGuideMethod, "guideId", 9000);
        Staff staff = webClient.get()
                .uri(getGuideMethod, uriBuilder -> uriBuilder.queryParam("guideId", 9000).build())
                .header("requestId", "mid-startubhub-init-" + UUID.randomUUID())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Staff.class)
                .block();
        WebConfig.logReceiving(getGuideMethod, staff);
        return staff;
    }

    private void getInvestorNames() {
        ThreadContext.put("requestId", "mid-startubhub-init-" + UUID.randomUUID());
        List<GuideService.Guide> guideV2 = getGuideV2(null, null, List.of(11_000L), null, "ru", null);
        if (guideV2 == null || guideV2.size() != 1 || guideV2.get(0).getValues() == null || guideV2.get(0).getValues().isEmpty()) {
            log.error("Wrong response from guideService for guideId = 20 000: {}", guideV2);
            throw new SberxException(SberxErrors.INTERNAL_ERROR, "Wrong response from guideService");
        } else {
            for (GuideService.Values v : guideV2.get(0).getValues()) {
                INVESTOR_NAMES.put(Integer.parseInt(v.getCode()), v.getName());
            }
        }
    }

    private void getStates() {
        ThreadContext.put("requestId", "mid-startubhub-init-" + UUID.randomUUID());
        List<GuideService.Guide> guideV2 = getGuideV2(null, null, List.of(20_000L), null, "ru", null);
        if (guideV2 == null || guideV2.size() != 1 || guideV2.get(0).getValues() == null || guideV2.get(0).getValues().isEmpty()) {
            log.error("Wrong response from guideService for guideId = 20 000: {}", guideV2);
            throw new SberxException(SberxErrors.INTERNAL_ERROR, "Wrong response from guideService");
        } else {
            for (GuideService.Values v : guideV2.get(0).getValues()) {
                STATES.put(Long.parseLong(v.getCode()), v.getName());
            }
        }
    }

    public List<Guide> getGuideV2(List<String> names,
                                  List<String> parentNames,
                                  List<Long> guideIds,
                                  List<Long> parentIds,
                                  String locale,
                                  Boolean isFilter) {
        WebConfig.logSending(getGuideV2Method, "name", names,
                "parentName", parentNames,
                "guideId", guideIds,
                "parentId", parentIds,
                "isFilter", isFilter);
        if (!CollectionUtils.isEmpty(names) && names.stream().anyMatch(i -> i.contains("#level=2"))){
            if (CollectionUtils.isEmpty(parentNames))
                parentNames = new ArrayList<>();
            parentNames.addAll(names.
                    stream().
                    filter(i -> i.contains("#level=2")).
                    map(i -> i.replace("#level=2", "")).
                    collect(Collectors.toList()));
            List<String> finalParentNames = parentNames;
            names = names.stream().distinct().filter(i -> !finalParentNames.contains(i.replace("#level=2", ""))).collect(Collectors.toList());
        }
        List<String> finalNames = names;
        List<String> finalParentNames1 = parentNames;
        List<Guide> guide = webClient.get()
                .uri(getGuideV2Method, uriBuilder -> uriBuilder
                        .queryParamIfPresent("name", Optional.ofNullable(finalNames))
                        .queryParamIfPresent("parentName", Optional.ofNullable(finalParentNames1))
                        .queryParamIfPresent("guideId", Optional.ofNullable(guideIds))
                        .queryParamIfPresent("parentId", Optional.ofNullable(parentIds))
                        .queryParamIfPresent("isFilter", Optional.ofNullable(isFilter))
                        .build())
                .header("requestId", ThreadContext.get("requestId"))
                .header("client-id", ThreadContext.get("client-id"))
                .header("locale", locale)
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(new ParameterizedTypeReference<List<Guide>>() {
                })
                .block();
        WebConfig.logReceiving(getGuideV2Method, guide);
        return guide;
    }

    public List<Long> filterGuideCodes(List<Long> codes){
        try {
            WebConfig.logSending(getGuideFilterMethod, "codes", codes);
            List<Long> res = webClient.get()
                    .uri(getGuideFilterMethod, uriBuilder -> uriBuilder
                            .queryParamIfPresent("code", Optional.ofNullable(codes))
                            .build())
                    .header("requestId", ThreadContext.get("requestId"))
                    .header("client-id", ThreadContext.get("client-id"))
                    .retrieve()
                    .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                    .bodyToMono(new ParameterizedTypeReference<List<Long>>() {
                    })
                    .block();
            WebConfig.logReceiving(getGuideFilterMethod, res);
            return res;
        } catch (Exception e){
            log.error("Error filtering list: ", e);
            return codes;
        }
    }

    public AbuseRes abuse(Long id, String type, Map<String, Object> fields){
        try {
            AbuseReq req = new AbuseReq();
            req.setObjectId(id);
            req.setObjectType(type);
            req.setFields(fields);
            WebConfig.logSending(abuseMethod, "request", req);
            return webClient.post()
                    .uri(abuseMethod)
                    .bodyValue(req)
                    .headers(WebConfig.defaultHeaders())
                    .retrieve()
                    .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                    .bodyToMono(new ParameterizedTypeReference<AbuseRes>() {
                    })
                    .block();
        } catch (Exception e){
            log.error("Error: ", e);
        }
        return null;
    }

    public SearchDto search(List<String> text) {
        WebConfig.logSending(searchMethod, "text", text);
        SearchDto searchDto = webClient.get()
                .uri(searchMethod, uriBuilder -> uriBuilder
                        .queryParamIfPresent("text", Optional.ofNullable(text))
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(SearchDto.class)
                .block();
        WebConfig.logReceiving(searchMethod, searchDto);
        return searchDto;
    }

    public String getStaffCode(int staffCount) {
        return staffMapping.findInterval(staffCount);
    }


    @Data
    private static class Staff {
        @JsonProperty("Staff")
        List<Values> staff;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    @NoArgsConstructor
    public static class Values {
        private String name;
        private String code;
        private String extra;
        private Integer count;
        private String logoFile;
        private String icon;
        private String sysName;
        private List<Values> linked;
        private String description;
        private String value;

        public Values(String name, String code, String extra) {
            this.name = name;
            this.code = code;
            this.extra = extra;
        }
    }

    private static class Intervals {

        private final List<Range> ranges = new ArrayList<>();

        void add(String value, int lowerBound, int upperBound) {
            add(new Range(value, lowerBound, upperBound));
        }

        void add(Range range) {
            this.ranges.add(range);
        }

        String findInterval(int givenValue) {
            for (Range range : ranges) {
                if (range.includes(givenValue)) {
                    return range.getValue();
                }
            }
            return null;
        }

        private static class Range {
            private final String value;
            private final int lowerBound;
            private final int upperBound;

            Range(String value, int lowerBound, int upperBound) {
                this.value = value;
                this.lowerBound = lowerBound;
                this.upperBound = upperBound;
            }

            boolean includes(int givenValue) {
                return givenValue >= lowerBound && givenValue <= upperBound;

            }

            public String getValue() {
                return value;
            }
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Guide {
        List<Values> values;
        private String name;
        private String sysname;
        private String lock;
        private String lockText;
        private Integer startBirthDate;
        private Integer endBirthDate;
        private Integer step;
    }

    @Data
    public static class AbuseReq {
        private Map<String, Object> fields;
        private String objectType;
        private Long objectId;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class AbuseRes {
        private Integer state;
        private Map<String, String> fields;
        private Long objectId;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class SearchDto {
        List<Values> values;
    }
}
