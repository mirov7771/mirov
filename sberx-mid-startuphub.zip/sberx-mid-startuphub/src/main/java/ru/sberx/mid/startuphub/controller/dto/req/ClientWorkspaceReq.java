package ru.sberx.mid.startuphub.controller.dto.req;

import lombok.Data;

@Data
public class ClientWorkspaceReq {
    private Integer type;
    private String locale;
    private Long userId;
    private String role;
    private String login;
}
