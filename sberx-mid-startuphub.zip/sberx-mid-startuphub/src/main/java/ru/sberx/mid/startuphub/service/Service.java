package ru.sberx.mid.startuphub.service;

import ru.sberx.mid.startuphub.controller.dto.req.*;
import ru.sberx.mid.startuphub.controller.dto.res.ListV2Res;
import ru.sberx.mid.startuphub.controller.dto.res.ViewRes;
import ru.sberx.mid.startuphub.controller.dto.res.workspace.ClientWorkspaceRes;

import java.awt.image.BufferedImage;

public interface Service {
    ListV2Res listV2(ListReq req);
    ViewRes getView(ViewReq req);
    ClientWorkspaceRes getClientWorkspace(ClientWorkspaceReq req);
    BufferedImage link(String uid);
    void successStory(SuccessStoryReq req);
}
