package ru.sberx.mid.startuphub.service.impl.method.list;

import org.springframework.web.util.UriBuilder;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.mid.startuphub.back.QuestionnaireService;
import ru.sberx.mid.startuphub.controller.dto.req.ListReq;
import ru.sberx.mid.startuphub.utils.Constants;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public abstract class AbstractList {

    public static String getListMethod(Integer type) {
        String method;
        switch (type) {
            case 0:
            case 1:
            case 2:
                method = "questionnaire";
                break;
            case 3:
                method = "company";
                break;
            default:
                method = null;
        }
        if (method == null)
            throw new SberxException(SberxErrors.METHOD_DOES_NOT_EXIST);
        return method;
    }

    public static String getClickAction(Integer type,
                                        Map<String, Object> map,
                                        String role,
                                        Boolean pa,
                                        String formName,
                                        Boolean isImport,
                                        Long userId)
    {
        UriBuilder clickActionUriBuilder = UriComponentsBuilder.fromUriString("/view");
        String name = null;
        String idKey = "";
        Boolean preauhorize = null;
        Long state;
        switch (type) {
            case 0:
                name = "startup";
                idKey = "questionnaireId";
                break;
            case 1:
                state = getState(map.get("state"));
                name = "corporate" + (Boolean.TRUE.equals(pa) ? "_preauth" : "") + ((state != null && state.equals(20010L)) ? "_short" : "");
                idKey = "questionnaireId";
                break;
            case 2:
                state = getState(map.get("state"));
                name = "investor" + (Boolean.TRUE.equals(pa) ? "_preauth" : "") + ((state != null && state.equals(20010L)) ? "_short" : "");
                idKey = "questionnaireId";
                break;
            case 3:
                name = "serviceCompany";
                idKey = "companyId";
                break;
        }
        if (role != null && !role.isEmpty() && name != null) {
            name = name + "_" + role;
        } else {
            preauhorize = true;
        }
        if (formName != null && !formName.isEmpty() && name != null) {
            name += "_" + formName;
        }
        if (Boolean.TRUE.equals(isImport) && userId == null)
            name += "_import";
        return clickActionUriBuilder
                .queryParamIfPresent("type", Optional.of(type))
                .queryParamIfPresent("name", Optional.ofNullable(name))
                .queryParamIfPresent("id", Optional.ofNullable(map.get(idKey)))
                .queryParamIfPresent("preauthorize", Optional.ofNullable(preauhorize))
                .queryParam("action", 1)
                .build()
                .toString();
    }

    public abstract List<?> getList(int type, ListReq req);

    public Integer getFavoritesCount(ListReq req) {
        return  null;
    }

    private static Long getState(Object state){
        if (state instanceof Long)
            return (Long) state;
        if (state instanceof Integer){
            Integer val = (Integer) state;
            return Long.valueOf(val);
        }
        if (state instanceof String){
            String val = (String) state;
            return Long.valueOf(val);
        }
        return null;
    }

    public List<QuestionnaireService.QuestionnaireInfo> getRecommended(ListReq req) {
        return null;
    }

}
