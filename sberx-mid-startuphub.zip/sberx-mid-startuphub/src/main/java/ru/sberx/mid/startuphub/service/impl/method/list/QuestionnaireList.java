package ru.sberx.mid.startuphub.service.impl.method.list;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.mid.startuphub.back.GuideService;
import ru.sberx.mid.startuphub.back.QuestionnaireService;
import ru.sberx.mid.startuphub.controller.dto.req.ListReq;

import java.util.ArrayList;
import java.util.List;

@Component("questionnaire")
@Slf4j
@RequiredArgsConstructor
public class QuestionnaireList extends AbstractList {

    private final QuestionnaireService questionnaireService;
    private final GuideService guideService;

    @Override
    public List<?> getList(int type, ListReq req) {
        List<QuestionnaireService.QuestionnaireInfo> questionnaireInfos = questionnaireService.getQuestionnaireList(type, req);
        questionnaireInfos.forEach(questionnaireInfo -> {
            if (questionnaireInfo.getStaff() != null) {
                String staffCode = guideService.getStaffCode(questionnaireInfo.getStaff());
                if (staffCode != null
                        && !"".equals(staffCode)
                        && StringUtils.isNumeric(staffCode))
                {
                    Integer i = Integer.valueOf(staffCode);
                    questionnaireInfo.setStaff(i);
                }
            }
        });
        return questionnaireInfos;
    }

    @Override
    public Integer getFavoritesCount(ListReq req) {
        ListReq favoriteReq = new ListReq();
        favoriteReq.setFavorite(true);
        favoriteReq.setSessionId(req.getSessionId());
        favoriteReq.setState(List.of(20004L));
        if (Boolean.TRUE.equals(req.getIsImport()))
            favoriteReq.setIsImport(req.getIsImport());
        List<QuestionnaireService.QuestionnaireInfo> questionnaireInfos = questionnaireService.getQuestionnaireList(req.getType().get(0), favoriteReq);
        if (!CollectionUtils.isEmpty(questionnaireInfos)) {
            return questionnaireInfos.size();
        } else {
            return 0;
        }
    }

    @Override
    public List<QuestionnaireService.QuestionnaireInfo> getRecommended(ListReq req) {
        ListReq reqR = new ListReq();
        reqR.setUserId(req.getUserId());
        reqR.setRecommend(true);
        if (Boolean.TRUE.equals(req.getIsImport()))
            reqR.setIsImport(req.getIsImport());
        reqR.setSessionId(req.getSessionId());
        reqR.setState(req.getState());
        reqR.setType(List.of(0));
        List<QuestionnaireService.QuestionnaireInfo> res = new ArrayList<>();
        for(Integer i : req.getType())
            res.addAll(questionnaireService.getQuestionnaireList(i, reqR));
        return res;
    }
}
