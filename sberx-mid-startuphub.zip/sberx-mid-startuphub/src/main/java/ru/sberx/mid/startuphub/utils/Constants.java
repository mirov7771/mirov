package ru.sberx.mid.startuphub.utils;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Constants {

    public static final Integer STARTUP_TYPE = 0;
    public static final Integer CORPORATE_TYPE = 1;
    public static final Integer INVESTOR_TYPE = 2;
    public static final Integer PILOT_TYPE = 4;

    public static final Long BUSINESS_ANGEL_CODE = 11002L;

    public static final String QUESTIONNAIRE = "Questionnaire";
    public static final String PILOT = "Pilot";

    public static final String OFFER_SEARCH = "offer_search";
    public static final String REPLY_SEARCH = "reply_search";
    public static final String OFFER_SEARCH_STARTUP = "offer_search_startup";
    public static final String OFFER_SEARCH_CORP = "offer_search_corp";

    public static final String CORP_OWNER_FILTER = "corp_owner";
    public static final String STARTUP_UNITY_FILTER = "startup_unity";
    public static final String CORP_UNITY_FILTER = "corp_unity";
    public static final String INVEST_UNITY_FILTER = "invest_unity";

    public static final String CORP_LIGHT_ROLE = "CorpLight";
    public static final String INVEST_LIGHT_ROLE = "InvestLight";

    public static final String PAY_LOCK_MESSAGE_RU = "Данный фильтр доступен только на тарифах Pro";
    public static final String PAY_LOCK_MESSAGE_EN = "This filter is only available on Pro plans";

    public static final Set<String> PAID_STARTUP_FILTERS = new HashSet<>(Arrays.asList(
            "Stady", "Round", "Geography", "SalesValue", "Staff", "InteractionType"
    ));
    public static final Set<String> PAID_CORP_FILTERS = new HashSet<>(Arrays.asList(
            "Geography", "Stady", "Round", "WorkMethod"
    ));
    public static final Set<String> PAID_INVEST_FILTERS = new HashSet<>(Arrays.asList(
            "Geography", "Stady", "Round", "WorkMethod"
    ));
}
