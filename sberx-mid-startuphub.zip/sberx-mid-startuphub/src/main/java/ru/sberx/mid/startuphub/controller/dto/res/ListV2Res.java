package ru.sberx.mid.startuphub.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.mid.startuphub.back.GuideService;
import ru.sberx.mid.startuphub.back.QuestionnaireService;

import java.util.List;
import java.util.Map;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ListV2Res {
    Integer nextPageToken;
    List<?> list;
    List<GuideService.Guide> filters;
    Map<String, Object> schema;
    private Integer totalRowCount;
    private Integer rowCount;
    List<GuideService.Values> categories;
    private Integer favoriteCount;
    private Integer limitCount;
    private Integer newReply;
    private Integer recommendCount;
    private String recommendTitle;
    private String recommendViewAll;
    private String recommendDescription;
    private List<QuestionnaireService.QuestionnaireInfo> recommend;
    private List<Button> buttons;
    private Boolean needPopup;
    private Integer visibleRowCount;

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Button {
        Long code;
        String text;
        String description;
        String format;
        Boolean value;
        String clickAction;
        String clickMethod;
    }
}
