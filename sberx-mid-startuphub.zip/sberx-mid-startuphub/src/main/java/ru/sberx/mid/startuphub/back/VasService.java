package ru.sberx.mid.startuphub.back;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import ru.sberx.configs.web.WebConfig;
import ru.sberx.dto.services.company.res.GetCompanyListRes;
import ru.sberx.dto.services.company.support.CompanyDto;
import ru.sberx.dto.services.company.support.ImportReplaceDto;
import ru.sberx.dto.services.service.support.ServiceDto;
import ru.sberx.dto.services.support.ActivityDto;
import ru.sberx.mid.startuphub.controller.dto.req.ListReq;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class VasService {

    private final WebClient webClient;
    private final String getVasMethod;
    private final String getVasAndCompanyMethod;
    private final String postActivityMethod;
    private final String getCompanyListMethod;
    private final String addActivityMethod;
    private final String getCompany;

    public VasService(WebClient webClient,
                      @Value("${application.sberx.services.uri}") String uri,
                      @Value("${application.sberx.services.vas.get}") String getVasMethod,
                      @Value("${application.sberx.services.vas.vas-and-company}") String getVasAndCompanyMethod,
                      @Value("${application.sberx.services.vas.acvtivity}") String postActivityMethod,
                      @Value("${application.sberx.services.company.list}") String getCompanyListMethod,
                      @Value("${application.sberx.services.activity}") String addActivityMethod,
                      @Value("${application.sberx.services.company.get}") String getCompany)
            throws URISyntaxException
    {
        this.webClient = webClient;
        this.getVasMethod = new URI(uri + getVasMethod).normalize().toString();
        this.getVasAndCompanyMethod = new URI(uri + getVasAndCompanyMethod).normalize().toString();
        this.postActivityMethod = new URI(uri + postActivityMethod).normalize().toString();
        this.getCompanyListMethod = new URI(uri + getCompanyListMethod).normalize().toString();
        this.addActivityMethod = new URI(uri + addActivityMethod).normalize().toString();
        this.getCompany = new URI(uri + getCompany).normalize().toString();
    }

    public Vas getVas(String vasId) {
        WebConfig.logSending(getVasMethod, "id", vasId);
        Vas vas = webClient.get()
                .uri(getVasMethod, uriBuilder -> uriBuilder.pathSegment("{id}").build(vasId))
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Vas.class)
                .block();
        WebConfig.logReceiving(getVasMethod, vas);
        return vas;
    }

    public VasAndCompanyRes getVasAndCompany(String vasId, Boolean isCompany) {
        String uri = getVasAndCompanyMethod.replace("vasId", vasId);
        WebConfig.logSending(uri, "");
        VasAndCompanyRes r = webClient.get().uri(uri, uriBuilder -> uriBuilder
                        .queryParamIfPresent("isCompany", Optional.ofNullable(isCompany))
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(VasAndCompanyRes.class)
                .block();
        WebConfig.logReceiving(uri, r);
        return r;
    }

    public void postActivity(String vasId,
                             Integer view,
                             Integer click,
                             String type){
        try {
            ActivityDto req = new ActivityDto();
            req.setClickLink(click);
            req.setView(view);
            req.setObjectType(type);
            WebConfig.logSending(postActivityMethod, "serviceId", vasId, "req", req);
            webClient.post()
                    .uri(postActivityMethod, uriBuilder -> uriBuilder.pathSegment("{serviceId}").build(vasId))
                    .headers(WebConfig.defaultHeaders())
                    .bodyValue(req)
                    .retrieve()
                    .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                    .toBodilessEntity()
                    .block();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public GetCompanyListRes getListCompany(ListReq req) {
        WebConfig.logSending(getCompanyListMethod, "name", req.getName() );
        GetCompanyListRes res = webClient.get().uri(getCompanyListMethod, uriBuilder -> uriBuilder
                        .queryParamIfPresent("name", Optional.ofNullable(req.getName()))
                        .queryParamIfPresent("sortBy", Optional.ofNullable(req.getSortBy()))
                        .queryParamIfPresent("orderBy", Optional.ofNullable(req.getOrderBy()))
                        .queryParamIfPresent("isImport", Optional.ofNullable(req.getIsImport()))
                        .queryParamIfPresent("replaceName", Optional.ofNullable(req.getReplaceName()))
                        .queryParamIfPresent("search", Optional.ofNullable(req.getSearch()))
                        .queryParamIfPresent("favorites", Optional.ofNullable(req.getFavorite()))
                        .queryParamIfPresent("view", Optional.ofNullable(req.getView()))
                        .build()
                ).headers(QuestionnaireService.customHeaders("user-id", req.getUserId()))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(GetCompanyListRes.class)
                .block();
        WebConfig.logReceiving(getCompanyListMethod, res);
        return res;
    }

    public CompanyDto getCompany(String id, Long userId) {
        WebConfig.logSending(getCompany, "id", id);
        CompanyDto res = webClient.get().uri(getCompany, uriBuilder -> uriBuilder.pathSegment("{id}").build(id))
                .headers(QuestionnaireService.customHeaders("user-id", userId))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(CompanyDto.class)
                .block();
        WebConfig.logReceiving(getCompany, res);
        return res;
    }

    public void addActivity(Long id, String objectType, String activity, Long userId){
        try {
            ActivityDto req = new ActivityDto();
            req.setId(id);
            req.setObjectType(objectType);
            req.setActivity(activity);
            WebConfig.logSending(addActivityMethod, "req", req);
            webClient.post()
                    .uri(addActivityMethod)
                    .headers(QuestionnaireService.customHeaders("user-id", userId))
                    .bodyValue(req)
                    .retrieve()
                    .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                    .toBodilessEntity()
                    .block();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Vas {
        private Long vasId;
        private Long userId;
        private String name;
        private String note;
        private String master;
        private Boolean ecosystem;
        private String resourceUri;
        private String discount;
        private Integer range;
        private String state;
        private Integer stateCode;
        private Date dateFrom;
        private Date dateTo;
        private String email;
        private List<String> tags;
        private String logoFile;
        private Long category;
        private Boolean isNew;
        private String smallNote;
        private String offerUri;
        private String offer;
        private String secondOffer;
        private String offerDescription;
        private String secondOfferDescription;
        private String clickMethod;
        private String clickAction;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class VasAndCompanyRes {
        private Service service;
        private Company serviceCompany;
        private ImportReplaceDTO importReplace;
        private List<Service> services;
        private Company company;

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Service {
            private Long vasId;
            private String note;
            private String smallNote;
            private String offerUri;
            private String offer;
            private String discount;
            private Integer range;
            private Integer state;
            private Date dateFrom;
            private Date dateTo;
            private Long category;
            private String master;
            private String logoFile;
            private String name;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Company {
            private Long companyId;
            private String name;
            private String note;
            private String email;
            private String logoFile;
            private String resourceUri;
            private Boolean ecosystem;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class ImportReplaceDTO {
            private String note;
            private String benefits;
            private List<String> name;
        }
    }


    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CompanyViewDto {
        private CompanyDto company;
        List<ServiceDto> services;
        private ImportReplaceDto importReplace;
    }
}
