package ru.sberx.mid.startuphub.service.impl.method;

import lombok.Getter;

@Getter
public enum ClientType {
    STARTUP(0, "StartUp", "Стартап"),
    CORPORATE(1, "Corporate", "Корпорация"),
    INVESTOR(2, "Investor", "Инвестор");

    private final Integer type;
    private final String sysName;
    private final String name;

    ClientType(Integer type, String sysName, String name){
        this.type = type;
        this.sysName = sysName;
        this.name = name;
    }

    public static String getSysName(Integer type){
        for(ClientType t : ClientType.values()){
            if (t.getType().equals(type)){
                return t.getSysName();
            }
        }
        return null;
    }

    public static String getName(Integer type){
        for(ClientType t : ClientType.values()){
            if (t.getType().equals(type)){
                return t.getName();
            }
        }
        return null;
    }
}
