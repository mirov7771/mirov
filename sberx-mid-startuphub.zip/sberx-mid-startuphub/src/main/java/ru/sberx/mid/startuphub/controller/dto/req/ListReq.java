package ru.sberx.mid.startuphub.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class ListReq {
    private String sessionId;
    private Integer rowCount;
    private Integer pageToken;
    private Long userId;
    private Boolean owner;
    private List<Long> state;
    private String formName;
    @JsonIgnore
    private Boolean isAdmin;
    private Boolean prioritySort;
    // Filters for Questionnaires
    private String id;
    private String name;
    private Boolean isBran;
    private Boolean isDisabled;
    private Integer birthDay;
    private Boolean site;
    private String location;
    private List<Long> investorType;
    private List<Long> industry;
    private List<Long> innovationMethod;
    private List<Long> stady;
    private List<Long> geography;
    private List<Long> registrationCountry;
    private String communityState;
    // Filters for VAS
    private Long category;
    private Boolean myReplay;
    // Filters for /v2/guide in /v2/list
    private String filters;
    @NotEmpty
    private List<@NotNull Integer> type;
    private Integer rows;
    private Boolean preauthorize;
    private String schema;
    private Boolean investment;
    private List<Long> businessModel;
    private Boolean forLending;
    private Long companyId;
    private List<Long> mvpCode;
    private List<Long> technology;
    @JsonProperty("project_technology")
    private List<Long> projectTechnology;
    @JsonProperty("investment_technology")
    private List<Long> investmentTechnology;
    @JsonProperty("project_geography")
    private List<Long> projectGeography;
    private List<Long> locationCountry;
    @JsonProperty("investment_geography")
    private List<Long> investmentGeography;
    @JsonProperty("investment_industry")
    private List<Long> investmentIndustry;
    private List<Long> interactionType;
    private List<Long> round;
    private String filteredBy;
    private Integer pilotsPerCompany;
    private Boolean notAuth;
    private Boolean sber500;
    private String sortBy;
    private String orderBy;
    private Boolean favorite;
    private Long responsible;
    private Boolean main;
    private Boolean view;
    private Long staff;
    private String search;
    private String locale;
    private Boolean isPilotOffer;
    private Boolean recommend;
    private String role;
    private Boolean isImport;
    private List<String> replaceName;
    private Boolean sales;
    private Integer startBirthDate;
    private Integer endBirthDate;
}
