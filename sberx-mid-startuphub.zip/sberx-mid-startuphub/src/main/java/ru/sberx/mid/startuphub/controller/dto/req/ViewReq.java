package ru.sberx.mid.startuphub.controller.dto.req;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ViewReq {
    @NotNull
    private Integer action;
    @NotNull
    private String name;
    @NotNull
    private Integer type;
    private Long id;
    private String uuid;
    private Boolean preauthorize;
    private String ui;
    private String locale;
    private Boolean admin;
    private Long userId;
    private String role;
    private String tariff;
}
