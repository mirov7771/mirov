package ru.sberx.mid.startuphub.service.impl.method;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.services.company.support.CompanyDto;
import ru.sberx.mid.startuphub.back.GuideService;
import ru.sberx.mid.startuphub.back.QuestionnaireService;
import ru.sberx.mid.startuphub.back.ScreenBuilderService;
import ru.sberx.mid.startuphub.back.VasService;
import ru.sberx.mid.startuphub.controller.dto.req.ViewReq;
import ru.sberx.mid.startuphub.controller.dto.res.ViewRes;
import ru.sberx.utils.util.CastUtils;
import ru.sberx.utils.util.StringUtils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ViewManager {

    private final ObjectMapper objectMapper;
    private final ScreenBuilderService screenBuilderService;
    private final QuestionnaireService questionnaireService;
    private final VasService vasService;
    private final Set<String> isControlShowRoles;
    private static final Map<Long, ViewRes.State> REPLY_STATES = new HashMap<>();
    private final Map<Long, String> states;
    private final GuideService guideService;
    private final static DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

    public static final Set<String> ADMIN_ROLE = new HashSet<>();
    public static final Set<String> CLIENT_ROLE = new HashSet<>();

    static {
        ADMIN_ROLE.add("SberbankEmployee");
        ADMIN_ROLE.add("Administrator");

        REPLY_STATES.put(20011L, new ViewRes.State("/file/20011.svg", "Заявка отправлена", "Дождитесь, пока корпорация ознакомится с вашим предложением", null, 20011L, "Новый"));
        REPLY_STATES.put(20002L, new ViewRes.State("/file/20002.svg", "Ваша заявка в работе", "Корпорация рассматривает ваш отклик. Это занимает некоторое время", null, 20002L, "В работе"));
        REPLY_STATES.put(20009L, new ViewRes.State("/file/20009.svg", "Заявка отклонена", "К сожалению, корпорация не готова к пилотированию вашего решения в рамках данного запроса", "comment", 20009L, "Отказ"));
        REPLY_STATES.put(20004L, new ViewRes.State("/file/20004.svg", "Ваше решение пилотируется", "Корпорация отметила, что запустила с вами пилотный проект", null, 20004L, "Пилотируется"));
        REPLY_STATES.put(20007L, new ViewRes.State("/file/20004.svg", "Работа по заявке завершена", "Корпорация отметила, что ваш пилот состоялся", null, 20007L, "Завершен"));
        REPLY_STATES.put(20003L, new ViewRes.State("/file/20003.svg", "Рассмотрение заявки приостановлено", "Ваш отклик на запрос сейчас находится на паузе, корпорация заинтересовалась решением, но в данный момент не готова к запуску пилота", "comment", 20003L, "Пауза"));
        REPLY_STATES.put(20013L, new ViewRes.State("/file/20009.svg", "Заявка отозвана", "Ваш отклик на запрос отозван", null, 20013L, "Отозван"));

        CLIENT_ROLE.add("CorpProPlus");
        CLIENT_ROLE.add("InvestAngel");
        CLIENT_ROLE.add("InvestPro");
        CLIENT_ROLE.add("CorpLight");
        CLIENT_ROLE.add("CorpPro");
        CLIENT_ROLE.add("InvestLight");
        CLIENT_ROLE.add("Client");
        CLIENT_ROLE.add("SuperClient");
    }

    public ViewManager(ObjectMapper objectMapper,
                       ScreenBuilderService screenBuilderService,
                       QuestionnaireService questionnaireService,
                       VasService vasService,
                       GuideService guideService,
                       @Value("${application.view.is.control.show.role}") String isControlShowRoles)
            throws JsonProcessingException {
        this.objectMapper = objectMapper;
        this.objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        this.objectMapper.disable(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES);
        this.objectMapper.disable(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES);
        this.objectMapper.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        this.objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        this.objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
        this.screenBuilderService = screenBuilderService;
        this.questionnaireService = questionnaireService;
        this.vasService = vasService;
        this.isControlShowRoles = objectMapper.readValue(isControlShowRoles, new TypeReference<>() {
        });
        this.states = GuideService.STATES;
        this.guideService = guideService;
    }

    public ViewRes getView(ViewReq req) {
        ViewRes res = new ViewRes();
        res.setId(req.getId());
        res.setType(req.getType());
        Long userId = req.getUserId();
        Long state = null;
        Integer userTypeId = null;
        Long replyQId = null;
        String replyUuid = null;
        Boolean isException = null;
        QuestionnaireService.ReplyInfo reply = null;
        List<QuestionnaireService.CommentDTO> comments = null;
        QuestionnaireService.Questionnaire questionnaire = null;
        QuestionnaireService.Pilot pilot = null;
        String role = req.getRole();
        Long mainId = req.getId();
        Boolean isImport = null;
        String tariffName = role;
        if (userId != null && org.springframework.util.StringUtils.hasText(role) && !"Administrator".equalsIgnoreCase(role)) {
            QuestionnaireService.TariffRes tariff2;
            try {
                tariff2 = questionnaireService.getTariff(null, userId, "Administrator", true);
                if (tariff2 != null && org.springframework.util.StringUtils.hasText(tariff2.getSysname())) {
                    tariffName = tariff2.getSysname();
                }
            } catch (Exception e) {
                log.error("Error getting tariff ", e);
            }
        }
        if (req.getId() == null
                && org.springframework.util.StringUtils.hasText(req.getUuid())
                && req.getUuid().matches("[0-9]+")) {
            req.setId(Long.valueOf(req.getUuid()));
            req.setUuid(null);
        }
        if (userId != null) {
            List<QuestionnaireService.Type> types = null;
            if (!"Administrator".equals(role))
                types = questionnaireService.getType(userId);
            if (!CollectionUtils.isEmpty(types))
                userTypeId = types.get(0).getType();
            if (org.springframework.util.StringUtils.hasText(role))
                res.setIsControlShow(isControlShowRoles.contains(role));
            if (req.getId() == null && req.getUuid() == null) {
                if (!CollectionUtils.isEmpty(types)) {
                    res.setId(types.get(0).getQuestionnaireId());
                }
            }
            if (!org.springframework.util.StringUtils.hasText(req.getName())
                    && req.getAction() != null
                    && req.getAction().equals(1)) {
                switch (req.getType()) {
                    case 0:
                        req.setName("startup_" + getRole(getRoleName(role, tariffName), types, req.getId(), req.getUuid(), 0));
                        break;
                    case 1:
                        req.setName("corporate_" + getRole(getRoleName(role, tariffName), types, req.getId(), req.getUuid(), 1));
                        break;
                    case 2:
                        req.setName("investor_" + getRole(getRoleName(role, tariffName), types, req.getId(), req.getUuid(), 2));
                        break;
                    case 3:
                        req.setName("company_" + getRoleName(role, tariffName));
                        break;
                    case 7:
                        reply = questionnaireService.getReply(req.getId(), userTypeId);
                        if (reply != null && Boolean.TRUE.equals(reply.getIsPilotOffer()))
                            req.setName("offer_" + getRoleName(role, tariffName));
                        else
                            req.setName("reply_" + getRoleName(role, tariffName));
                        break;
                    case 10:
                        req.setName("round_" + getInvestmentType(req.getId()));
                        break;
                    case 13:
                        req.setName("scouting_" + getRoleName(role, tariffName));
                        break;
                }
            } else if (org.springframework.util.StringUtils.hasText(req.getName()) && Integer.valueOf(1).equals(req.getAction())) {
                req.setName(req.getName().contains("SuperClient")
                        ? req.getName().replace("SuperClient", role)
                        : req.getName().replace("Client", role));
            }
        }
        if (!org.springframework.util.StringUtils.hasText(req.getName()) && req.getType() != null
                && (req.getType().equals(0) || req.getType().equals(1) || req.getType().equals(2)))
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        res.setName(req.getName());
        List<ScreenBuilderService.Form> forms = screenBuilderService.getForms(req.getType(), req.getAction(), req.getName(), req.getLocale());
        if (forms != null && forms.size() > 0) {
            res.setName(forms.get(0).getName());
            res.setLogoFile(StringUtils.getLogo(forms.get(0).getLogoFile()));
            res.setOfferDescription(forms.get(0).getOfferDescription());
            res.setSecondOfferDescription(forms.get(0).getSecondOfferDescription());
            res.setInfo(forms.get(0).getInfo());
        }
        Map<String, Object> personalData;
        QuestionnaireService.Questionnaire parentPersonalData = null;
        Boolean sber500 = false;
        Boolean sber500firstTime = false;
        if (req.getId() != null || req.getUuid() != null) {
            Object o;
            switch (req.getType()) {
                case 0:
                case 1:
                case 2:
                    if (org.springframework.util.StringUtils.hasText(req.getUuid()))
                        questionnaire = questionnaireService.getQuestionnaireByUuid(req.getUuid(), userId);
                    else
                        questionnaire = questionnaireService.getQuestionnaire(req.getId());
                    QuestionnaireService.Questionnaire q = questionnaire;
                    res.setId(req.getId());
                    if (q != null) {
                        req.setId(q.getQuestionnaireId());
                        mainId = q.getQuestionnaireId();
                        isException = q.getIsException();
                    }
                    if (q != null && q.getFeedbacks() != null && q.getFeedbacks().size() > 1) {
                        Long rating = q.getFeedbacks().stream()
                                .reduce(0L, (partSum, fb) -> partSum + (fb.getScore() == null ? 0 : fb.getScore()), Long::sum);
                        res.setRating(1.0 * rating / q.getFeedbacks().size());
                    }
                    if (q != null && q.getQuestionnaire() != null) {
                        isImport = q.getQuestionnaire().getIsImport();
                        res.setLogoFile(StringUtils.getLogo(q.getQuestionnaire().getLogoFile()));
                        res.setName(q.getQuestionnaire().getName());
                        res.setFullName(q.getQuestionnaire().getFullName());
                        res.setComment(q.getQuestionnaire().getComment());
                        res.setFavorite(Boolean.TRUE.equals(q.getQuestionnaire().getFavorite()));
                        sber500 = q.getQuestionnaire().getSber500();
                        if (q.getSberFiveHundred() != null) {
                            sber500firstTime = q.getSberFiveHundred().getFirstTime();
                        }
                        state = q.getQuestionnaire().getStateCode();
                        res.setViewCount(setViewCount(q.getViewCount(), req.getLocale()));
                        if (org.springframework.util.StringUtils.hasText(req.getName()) && req.getName().contains("Administrator"))
                            res.setState(new ViewRes.State(
                                    q.getQuestionnaire().getStateCode(),
                                    getStateName(req, q.getQuestionnaire().getStateCode())
                            ));
                    }
                    if (req.getName() != null
                            && CLIENT_ROLE.stream().noneMatch(r -> req.getName().contains(r))
                            && q != null
                            && q.getQuestionnaire() != null
                            && (req.getId() != null || q.getQuestionnaire().getQuestionnaireId() != null)) {
                        if (Boolean.TRUE.equals(q.getIsChild()) && !"Administrator".equalsIgnoreCase(role)) {
                            QuestionnaireService.Questionnaire qq = questionnaireService.getQuestionnaireByParentId(req.getId() != null ? req.getId() : q.getQuestionnaireId());
                            if (qq != null && qq.getQuestionnaire() != null && qq.getQuestionnaire().getQuestionnaireId() != null) {
                                req.setId(qq.getQuestionnaireId());
                                res.setId(req.getId());
                                isImport = qq.getQuestionnaire().getIsImport() != null ? qq.getQuestionnaire().getIsImport() : isImport;
                                if (CollectionUtils.isEmpty(qq.getUsers()))
                                    qq.setUsers(q.getUsers());

                                o = qq;
                                parentPersonalData = q;
                                if (qq.getQuestionnaire().getComment() != null)
                                    res.setComment(qq.getQuestionnaire().getComment());
                                sber500 = qq.getQuestionnaire().getSber500();
                                if (qq.getSberFiveHundred() != null) {
                                    sber500firstTime = qq.getSberFiveHundred().getFirstTime();
                                }
                            } else {
                                o = q;
                            }
                        } else if (q.getQuestionnaire().getParentId() != null
                                && !q.getQuestionnaire().getParentId().equals(0L)) {
                            parentPersonalData = questionnaireService.getQuestionnaire(q.getQuestionnaire().getParentId());
                            if (parentPersonalData.getQuestionnaire().getComment() != null)
                                res.setComment(parentPersonalData.getQuestionnaire().getComment());
                            o = q;
                        } else {
                            o = q;
                        }
                    } else {
                        o = q;
                    }

                    if ("Administrator".equalsIgnoreCase(role) &&
                            q != null
                            && q.getQuestionnaire() != null
                            && (q.getQuestionnaire().getType().equals(1)
                            || q.getQuestionnaire().getType().equals(2))) {
                        if (q.getQuestionnaire().getType().equals(1))
                            res.setFullName("Корпорация");
                        else {
                            if (q.getQuestionnaire().getInvestorType() != null) {
                                if (q.getQuestionnaire().getInvestorType().equals(11001L))
                                    res.setFullName("Венчурный фонд");
                                else if (q.getQuestionnaire().getInvestorType().equals(11002L))
                                    res.setFullName("Бизнес-ангел");
                                else if (q.getQuestionnaire().getInvestorType().equals(11004L))
                                    res.setFullName("Family Office");
                            }
                        }

                        QuestionnaireService.TariffRes tariff = null;
                        try {
                            tariff = questionnaireService.getTariff(Long.valueOf(q.getQuestionnaire().getQuestionnaireId()), userId, role, true);
                        } catch (Exception e) {
                            log.error("Error getting tariff ", e);
                        }
                        if (tariff != null)
                            res.setTariff("Тариф " + tariff.getName());
                        else
                            res.setTariff("ru".equalsIgnoreCase(req.getLocale()) ? "Тариф не выбран" : "The tariff is not selected");
                    }
                    break;
                case 3:
                    Long vasId = null;
                    if ("vas".equalsIgnoreCase(req.getName())) {
                        VasService.Vas vas = vasService.getVas(req.getId() != null ? req.getId().toString() : req.getUuid());
                        if (res.getLogoFile() == null)
                            res.setLogoFile(StringUtils.getLogo(vas.getLogoFile()));
                        if (vas != null) {
                            vasId = vas.getVasId();
                            res.setName(vas.getName());
                        }
                        o = vas;
                    } else if (req.getName().contains("company") && userId != null) {
                        CompanyDto company = vasService.getCompany(req.getId() != null ? req.getId().toString() : req.getUuid(), userId);
                        VasService.CompanyViewDto companyViewDto = null;
                        if (company != null) {
                            companyViewDto = new VasService.CompanyViewDto();
                            companyViewDto.setCompany(company);
                            companyViewDto.setImportReplace(company.getImportReplace());
                            companyViewDto.setServices(company.getServices());
                            if (company.getLogoFile() != null)
                                res.setLogoFile(StringUtils.getLogo(company.getLogoFile()));
                            if (company.getName() != null)
                                res.setName(company.getName());
                            res.setFavorite(Boolean.TRUE.equals(company.getFavorite()));
                            res.setId(company.getCompanyId());
                            res.setUid(company.getUid());
                            if (company.getCompanyId() != null && !ADMIN_ROLE.contains(role))
                                vasService.addActivity(company.getCompanyId(), "company", "view", userId);
                        }
                        o = companyViewDto;
                    } else {
                        VasService.VasAndCompanyRes vcRes = vasService.getVasAndCompany(req.getId() != null
                                        ? req.getId().toString()
                                        : req.getUuid(),
                                org.springframework.util.StringUtils.hasText(req.getName()) && !req.getName().contains("vas"));
                        if (vcRes != null) {
                            if (res.getLogoFile() == null)
                                if (vcRes.getServiceCompany() != null && vcRes.getServiceCompany().getLogoFile() != null) {
                                    res.setLogoFile(StringUtils.getLogo(vcRes.getServiceCompany().getLogoFile()));
                                } else if (vcRes.getService() != null && vcRes.getService().getLogoFile() != null) {
                                    res.setLogoFile(StringUtils.getLogo(vcRes.getService().getLogoFile()));
                                }
                            if (vcRes.getServiceCompany() != null && vcRes.getServiceCompany().getName() != null)
                                res.setName(vcRes.getServiceCompany().getName());
                            else if (vcRes.getService() != null && vcRes.getService().getName() != null)
                                res.setName(vcRes.getService().getName());
                            if (vcRes.getService() != null)
                                vasId = vcRes.getService().getVasId();
                        }
                        o = vcRes;
                    }
                    if (userId == null || !ADMIN_ROLE.contains(role))
                        vasService.postActivity(req.getId() != null
                                        ? req.getId().toString() : req.getUuid(),
                                1,
                                null,
                                "vas".equalsIgnoreCase(req.getName()) ? "Service" : "Company");
                    if (vasId != null && userId != null && !ADMIN_ROLE.contains(role))
                        vasService.addActivity(vasId, "service", "view", userId);
                    break;
                case 4:
                    pilot = questionnaireService.getPilot(req.getId(), userId);
                    if (pilot.getQuestionnaire() != null) {
                        res.setLogoFile(StringUtils.getLogo(pilot.getQuestionnaire().getLogoFile()));
                    }
                    res.setFavorite(Boolean.TRUE.equals(pilot.getFavorite()));
                    o = pilot;
                    state = pilot.getState();
                    res.setViewCount(setViewCount(pilot.getViewCount(), req.getLocale()));
                    break;
                case 7:
                    if (reply == null && req.getId() != null)
                        reply = questionnaireService.getReply(req.getId(), userTypeId);
                    if (reply != null) {
                        reply.setReply(new QuestionnaireService.ReplyInfo(
                                reply.getReplyId(),
                                reply.getUserId(),
                                reply.getNote(),
                                reply.getFileUrl(),
                                reply.getState(),
                                reply.getDate(),
                                reply.getTableId(),
                                reply.getTableName(),
                                reply.getQuestions(),
                                reply.getCost(),
                                reply.getProcess(),
                                reply.getIsViewed(),
                                reply.getComment(),
                                reply.getModified(),
                                reply.getOfferName(),
                                reply.getOfferDescription(),
                                reply.getQuestionnaireId(),
                                reply.getIsPilotOffer()
                        ));
                        comments = reply.getComments();
                        if (reply.getQuestionnaire() != null) {
                            res.setLogoFile(StringUtils.getLogo(reply.getQuestionnaire().getLogoFile()));
                            res.setName(reply.getQuestionnaire().getName());
                            res.setFullName(reply.getQuestionnaire().getFullName());
                            if (reply.getQuestionnaire().getQuestionnaireId() != null) {
                                res.setQuestionnaireId(Long.valueOf(reply.getQuestionnaire().getQuestionnaireId()));
                                replyQId = Long.valueOf(reply.getQuestionnaire().getQuestionnaireId());
                            }
                            if (reply.getQuestionnaire().getUuid() != null)
                                replyUuid = reply.getQuestionnaire().getUuid().toString();
                            res.setStateCode(reply.getState());
                            if (REPLY_STATES.get(reply.getState()) != null)
                                res.setStateName(REPLY_STATES.get(reply.getState()).getStateName());
                            if (req.getName().equalsIgnoreCase("offer_Client")) {
                                if (org.springframework.util.StringUtils.hasText(reply.getOfferName()))
                                    res.setName(reply.getOfferName());
                                res.setDescription(reply.getOfferDescription());
                                res.setState(createState(reply.getState(), reply.getComment()));
                                if (reply.getQuestionnaire() != null) {
                                    String form_name = "corporate_" + getRoleName(role, tariffName);
                                    String action = "/view?type=1&name=" + form_name + "&id=" + reply.getQuestionnaire().getQuestionnaireId() + "&action=1";
                                    reply.getQuestionnaire().setClickAction(action);
                                    reply.getQuestionnaire().setClickMethod("GET");
                                    res.setQuestionnaire(reply.getQuestionnaire());
                                    if (res.getQuestionnaire().getLogoFile() != null)
                                        res.getQuestionnaire().setLogoFile(StringUtils.getLogo(res.getQuestionnaire().getLogoFile()));
                                }
                            }
                        }
                    }
                    o = reply;
                    break;
                case 9:
                    QuestionnaireService.ApplicationDto application = questionnaireService.getApplicationById(req.getId(), userId != null);
                    res.setName(application.getOrgFullName());
                    state = application.getState();
                    o = application;
                    if ("Administrator".equalsIgnoreCase(role)) {
                        if (org.springframework.util.StringUtils.hasText(application.getTariffName()))
                            res.setTariff("Тариф " + application.getTariffName());
                        else
                            res.setTariff("Тариф не выбран");
                    }
                    break;
                case 10:
                    Long userIdHeader = "Administrator".equalsIgnoreCase(role) ? null : userId;
                    QuestionnaireService.Round round = questionnaireService.getRound(req.getId(), userIdHeader);
                    if (round.getState() != null)
                        state = round.getState().longValue();
                    if (Boolean.TRUE.equals(isStartUpCall(userId))) {
                        res.setName(round.getRoundTypeName());
                        if (round.getCreated() != null) {
                            res.setDate(dateFormat.format(round.getCreated()));
                        }
                    } else {
                        res.setName(round.getStartupName());
                    }
                    res.setFullName(round.getStartupNameFullName());
                    res.setLogoFile(StringUtils.getLogo(round.getLogoFile()));
                    res.setFavorite(Boolean.TRUE.equals(round.getFavorite()));
                    if (round.getViewCount() != null)
                        res.setViewCount(setViewCount(round.getViewCount().intValue(), req.getLocale()));
                    replyQId = round.getQuestionnaireId();
                    QuestionnaireService.Questionnaire rQuestionnaire = questionnaireService.getQuestionnaire(replyQId);
                    if (rQuestionnaire != null && rQuestionnaire.getQuestionnaire() != null && rQuestionnaire.getQuestionnaire().getUuid() != null)
                        replyUuid = rQuestionnaire.getQuestionnaire().getUuid().toString();
                    o = round;
                    break;
                case 11:
                    QuestionnaireService.Community community = questionnaireService.getCommunity(req.getId());
                    state = community.getState();
                    res.setType(community.getType());
                    res.setName(community.getName());
                    res.setComment(community.getComment());
                    res.setQuestionnaireStateCode(community.getQuestionnaireState());
                    res.setQuestionnaireStateName(community.getQuestionnaireStateName());
                    if (community.getQuestionnaireid() != null) {
                        QuestionnaireService.Questionnaire qq = questionnaireService.getQuestionnaire(community.getQuestionnaireid());
                        if (qq != null && qq.getQuestionnaire() != null)
                            res.setLogoFile(StringUtils.getLogo(qq.getQuestionnaire().getLogoFile()));
                        else
                            res.setLogoFile("/file/768840");
                    } else {
                        res.setLogoFile("/file/768840");
                    }
                    o = community;
                    break;
                case 12:
                    QuestionnaireService.Syndicate syndicate = questionnaireService.getSyndicate(req.getId());
                    state = syndicate.getState();
                    res.setType(syndicate.getType());
                    res.setName(syndicate.getOrgFullName());
                    res.setComment(syndicate.getComment());
                    if (syndicate.getQuestionnaireId() != null) {
                        QuestionnaireService.Questionnaire qq = questionnaireService.getQuestionnaire(syndicate.getQuestionnaireId());
                        if (qq != null && qq.getQuestionnaire() != null) {
                            res.setLogoFile(StringUtils.getLogo(qq.getQuestionnaire().getLogoFile()));
                            res.setName(qq.getQuestionnaire().getName());
                        } else
                            res.setLogoFile("/file/768840");
                    }
                    o = syndicate;
                    break;
                case 13:
                    QuestionnaireService.ScoutingDto scouting = questionnaireService.getScouting(req.getUuid());
                    state = scouting.getState();
                    res.setName(scouting.getName());
                    res.setComment(scouting.getComment() == null ? scouting.getAdminComment() : scouting.getComment());
                    res.setEmail(scouting.getEmail());
                    res.setPhone(scouting.getPhone());
                    o = scouting;
                    break;
                case 14:
                    if ("edit_metric".equalsIgnoreCase(req.getName())) {
                        res.setIsControlShow(true);
                        Timestamp beginDate = Timestamp.valueOf("2000-01-01 00:00:00");
                        Timestamp endDate = Timestamp.from(Instant.now());
                        List<QuestionnaireService.GetMetricRes> metricRes = questionnaireService.metric(beginDate.toString(), endDate.toString(), req.getId(), null, userId);
                        o = !CollectionUtils.isEmpty(metricRes) ? metricRes.get(0) : null;
                    } else if ("add_metric_values".equalsIgnoreCase(req.getName())) {
                        List<QuestionnaireService.MetricTypeDto> metricList = questionnaireService.metricList(userId, false, null);
                        o = metricList.stream().filter(metric -> metric.getType() != null && metric.getType().equals(req.getId().intValue())).findAny();
                    } else {
                        o = null;
                    }
                    break;
                default:
                    return res;
            }
            personalData = objectMapper.convertValue(o, new TypeReference<>() {
            });

            if (personalData != null && !personalData.isEmpty()
                    && req.getAction().equals(1)
                    && org.springframework.util.StringUtils.hasText(req.getName())
                    && req.getName().contains("Administrator")) {
                GuideService.AbuseRes abuse = guideService.abuse(req.getId(), null, personalData);
                if (abuse != null
                        && abuse.getState() != null
                        && abuse.getState().equals(1)
                        && abuse.getFields() != null
                        && !abuse.getFields().isEmpty())
                    res.setAbuseState(1);
                else
                    res.setAbuseState(0);
            }
        } else {
            personalData = new HashMap<>();
        }
        if (res.getType() != null
                && org.springframework.util.StringUtils.hasText(tariffName)) {
            if (res.getType().equals(4) && "InvestLight ".equalsIgnoreCase(tariffName))
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
            if (res.getType().equals(2) && "CorpLight".equalsIgnoreCase(tariffName))
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
        }
        //TODO переделать этот костыль
        ScreenBuilderService.ButtonRes.ButtonDto replyButton = null;
        if (CLIENT_ROLE.stream().anyMatch(r -> ("pilot_" + r).equalsIgnoreCase(req.getName()))
                && forms != null) {
            res.setIsControlShow(false);
            if (pilot != null && pilot.getQuestionnaire() != null) {
                QuestionnaireService.QuestionnaireInfo qinfo = new QuestionnaireService.QuestionnaireInfo();
                qinfo.setName(pilot.getQuestionnaire().getName());
                res.setName(pilot.getName());
                qinfo.setFullName(pilot.getQuestionnaire().getFullName());
                qinfo.setLogoFile(StringUtils.getLogo(pilot.getQuestionnaire().getLogoFile()));
                qinfo.setNote(pilot.getQuestionnaire().getNote());
                qinfo.setQuestionnaireId(pilot.getQuestionnaire().getUuid() != null ? pilot.getQuestionnaire().getUuid().toString() : pilot.getQuestionnaire().getQuestionnaireId());

                if (userId != null && org.springframework.util.StringUtils.hasText(role) && pilot.getQuestionnaire().getQuestionnaireId() != null) {
                    String form_name = "corporate_" + getRoleName(role, tariffName);
                    String action = "/view?type=1&name=" + form_name + "&id=" + pilot.getQuestionnaire().getQuestionnaireId() + "&action=1";
                    qinfo.setClickAction(action);
                    qinfo.setClickMethod("GET");
                }

                res.setQuestionnaire(qinfo);
            }
            if (pilot != null && userId != null && org.springframework.util.StringUtils.hasText(role) && Integer.valueOf(0).equals(userTypeId)) {
                if (CLIENT_ROLE.contains(role) && !"Client".equalsIgnoreCase(role)) {
                    if (pilot.getReplyId() != null && pilot.getReplyState() != null && !pilot.getReplyState().equals(20013L)) {
                        log.info("userId {}, pilot {}, replyPilot {}, comment {}", userId, pilot.getPilotId(), pilot.getReplyId(), pilot.getReplyComment());
                        res.setState(createState(pilot.getReplyState(), pilot.getReplyComment()));
                        log.info("response state object {}", res.getState());
                        if (pilot.getReplyState().equals(20011L)
                                || pilot.getReplyState().equals(20003L)
                                || pilot.getReplyState().equals(20002L)) {
                            replyButton = new ScreenBuilderService.ButtonRes.ButtonDto();
                            replyButton.setCode(20013);
                            replyButton.setText("ru".equals(req.getLocale()) ? "Отозвать заявку" : "Withdraw Application");
                            replyButton.setId(pilot.getReplyId());
                        }
                    }
                    List<ScreenBuilderService.Form> replyForms = screenBuilderService.getForms(req.getType(), 2, req.getName() + "_Extra", req.getLocale());
                    if (pilot.getReplyDate() != null
                            && pilot.getReplyState() != null
                            && pilot.getReplyState().equals(20013L)
                            && !CollectionUtils.isEmpty(replyForms)) {
                        Date modified = pilot.getReplyDate();
                        replyForms.forEach(i -> {
                            if (!CollectionUtils.isEmpty(i.getModules()) && !CollectionUtils.isEmpty(i.getModules().get(0).getFields())) {
                                ScreenBuilderService.Form.Module.Field f = new ScreenBuilderService.Form.Module.Field();
                                f.setSysName("revoke_info");
                                f.setType("information");
                                f.setNote("ru".equals(req.getLocale()) ? "Сумма, в которую вы оцениваете ваш пилотный запуск" : "The amount you value your pilot run");
                                f.setExample(("ru".equals(req.getLocale()) ? "Вы отозвали предыдущую заявку " : "You have withdrawn your previous application ") + dateFormat.format(modified));
                                i.getModules().get(0).getFields().add(0, f);
                            }
                        });
                    }
                    forms.addAll(replyForms);
                }
            }
        }

        if (forms != null) {
            screenBuilderService.fillForms(
                    forms,
                    personalData,
                    req.getAction(),
                    sber500,
                    sber500firstTime,
                    req.getLocale(),
                    isException,
                    role,
                    req.getType(),
                    req.getName(),
                    isImport,
                    req.getTariff());
            if (parentPersonalData != null
                    && req.getAction() != null
                    && req.getId() != null
                    && req.getAction().equals(1)
                    && req.getName() != null
                    && req.getName().contains("Administrator")) {
                try {
                    screenBuilderService.fillFormsOld(forms, parentPersonalData);
                } catch (Exception e) {
                    log.error("error getting old value ", e);
                }
            }

            ScreenBuilderService.Form.Module commentModule = null;
            if (req.getType().equals(7) && req.getAction().equals(1)) {
                commentModule = new ScreenBuilderService.Form.Module();
                screenBuilderService.fillCommentModule(commentModule, comments,
                        ScreenBuilderService.DescriptionType.STARTUP_DESCRIPTION, req.getLocale());
            }
            for (ScreenBuilderService.Form f : forms) {
                if (f.getModules() != null && f.getModules().size() > 0) {
                    if (req.getName().contains("startup") && org.springframework.util.StringUtils.hasText(f.getDescription()))
                        res.setDescription(f.getDescription());
                    List<ScreenBuilderService.Form.Module> mods = new ArrayList<>();
                    for (ScreenBuilderService.Form.Module m : f.getModules()) {
                        if (validModule(m)) {
                            if (req.getAction() != null && req.getAction().equals(1)) {
                                if (m.getFields() != null && m.getFields().size() > 0)
                                    m.getFields().forEach(i -> {
                                        if (i.getValues() != null && i.getValues().size() > 0)
                                            i.setValues(null);
                                        if (Boolean.TRUE.equals(i.getIsBlur()))
                                            i.setValue("");
                                    });
                            }
                            mods.add(m);
                        }
                    }
                    if (commentModule != null)
                        mods.add(commentModule);
                    f.setModules(mods);
                }
            }
            if (req.getType() != null && req.getType().equals(9) && role != null
                    && role.equals("Administrator")) {
                ScreenBuilderService.Form.Module applicationCommentModule = new ScreenBuilderService.Form.Module();
                Object applicationId = personalData.get("applicationId");
                if (applicationId instanceof Long) {
                    QuestionnaireService.CommentGetRes commentsRes =
                            questionnaireService.getComments(role, (Long) applicationId, "Application");
                    screenBuilderService.fillCommentModule(applicationCommentModule,
                            commentsRes != null ? commentsRes.getComments() : null,
                            ScreenBuilderService.DescriptionType.USER_DESCRIPTION,
                            req.getLocale());
                    if (forms.isEmpty()) {
                        ScreenBuilderService.Form applicationForm = new ScreenBuilderService.Form();
                        applicationForm.setModules(List.of(applicationCommentModule));
                        forms.add(applicationForm);
                    } else {
                        List<ScreenBuilderService.Form.Module> modules = forms.get(forms.size() - 1).getModules();
                        if (modules == null) {
                            modules = new ArrayList<>();
                            modules.add(applicationCommentModule);
                            forms.get(forms.size() - 1).setModules(modules);
                        } else {
                            modules.add(applicationCommentModule);
                        }
                    }
                }
            }
        }
        res.setForms(forms);

        if (userId != null
                && !CollectionUtils.isEmpty(res.getForms())
                && userTypeId != null
                && (userTypeId.equals(1) || userTypeId.equals(2))
                && req.getType() != null
                && req.getType().equals(0)
                && req.getAction() != null
                && req.getAction().equals(1)
                && org.springframework.util.StringUtils.hasText(req.getUuid())) {
            if (res.getForms().get(0) != null && !CollectionUtils.isEmpty(res.getForms().get(0).getModules())) {
                var metricModule = screenBuilderService.getMetricModule(req.getLocale(), userId, req.getUuid());
                if (metricModule != null)
                    res.getForms().get(0).getModules().add(metricModule);
            }
        }

        if (state != null) {
            res.setStateCode(state);
            res.setStateName(getStateName(req, state));
        }

        if (res.getState() != null && res.getState().getTitle() != null
                || "startup_Administrator".equals(req.getName()) && Long.valueOf(20016).equals(res.getStateCode())) {
            res.setButtons(new ArrayList<>());
        } else {
            try {
                String formName = req.getName();
                if (org.springframework.util.StringUtils.hasText(formName) && formName.contains("_") && (formName.contains("Corp") || formName.contains("Invest")))
                    formName = formName.split("_")[0] + "_SuperClient";
                res.setButtons(screenBuilderService.getButtons(req.getType(), formName, mainId != null ? mainId : req.getId(), req.getUuid(), req.getUserId(), req.getRole()));
                if ((req.getType().equals(7) || req.getType().equals(10))
                        && !CollectionUtils.isEmpty(res.getButtons())
                        && res.getButtons().stream().anyMatch(i -> i.getCode().equals(100000))) {
                    for (ScreenBuilderService.ButtonRes.ButtonDto b : res.getButtons()) {
                        if (b.getCode().equals(100000)) {
                            if (replyQId != null)
                                b.setId(replyQId);
                            if (org.springframework.util.StringUtils.hasText(replyUuid)) {
                                b.setClickMethod("/main/startups/" + replyUuid);
                                b.setUid(replyUuid);
                                b.setClickAction("GET");
                            }
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                log.error("error in getting buttons : ", e);
            }
        }

        if (!CollectionUtils.isEmpty(res.getButtons())
                && req.getType().equals(1)
                && req.getAction().equals(1)
                && userTypeId != null
                && userTypeId.equals(0)) {
            ScreenBuilderService.ButtonRes.ButtonDto technologyButton = null;
            for (ScreenBuilderService.ButtonRes.ButtonDto b : res.getButtons()) {
                if (b.getCode() != null && b.getCode().equals(100001)) {
                    technologyButton = b;
                }
            }
            if (technologyButton != null) {
                res.getButtons().remove(technologyButton);
                res.getButtons().add(0, technologyButton);
            }

        }

        if (replyButton != null) {
            if (CollectionUtils.isEmpty(res.getButtons()))
                res.setButtons(new ArrayList<>());
            res.getButtons().add(replyButton);
        }

        if (CollectionUtils.isEmpty(res.getButtons()) && "offer_Client".equalsIgnoreCase(req.getName())) {
            ScreenBuilderService.ButtonRes.ButtonDto b = new ScreenBuilderService.ButtonRes.ButtonDto();
            if (req.getAction().equals(1)) {
                b.setCode(20013);
                b.setText("ru".equals(req.getLocale()) ? "Отозвать заявку" : "Withdraw application");
                b.setId(req.getId());
                res.setForms(null);
            } else {
                b.setCode(200003);
                b.setText("ru".equals(req.getLocale()) ? "Отправить заявку" : "Send application");
            }
            res.setButtons(List.of(b));
        }

        if ("import_create".equalsIgnoreCase(req.getName())) {
            if (CollectionUtils.isEmpty(res.getButtons()))
                res.setButtons(new ArrayList<>());
            ScreenBuilderService.ButtonRes.ButtonDto b = new ScreenBuilderService.ButtonRes.ButtonDto();
            b.setCode(200003);
            b.setText("ru".equals(req.getLocale()) ? "Добавить" : "Add");
            b.setClickMethod("PUT");
            b.setClickAction("/questionary/" + req.getId());
            res.getButtons().add(b);

            b = new ScreenBuilderService.ButtonRes.ButtonDto();
            b.setCode(200005);
            b.setText("ru".equals(req.getLocale()) ? "Неактуально" : "Not relevant");
            res.getButtons().add(b);

            b = new ScreenBuilderService.ButtonRes.ButtonDto();
            b.setCode(200006);
            b.setText("ru".equals(req.getLocale()) ? "Добавить информацию можно позже на странице редактирования анкеты" : "Not relevant");
            res.getButtons().add(b);
        }

        if (CLIENT_ROLE.stream().anyMatch(r -> ("company_" + role).equalsIgnoreCase(req.getName()))) {
            if (CollectionUtils.isEmpty(res.getButtons()))
                res.setButtons(new ArrayList<>());
            ScreenBuilderService.ButtonRes.ButtonDto b = new ScreenBuilderService.ButtonRes.ButtonDto();
            if (Boolean.TRUE.equals(res.getFavorite())) {
                b.setCode(100006);
                b.setText("Удалить из избранного");
            } else {
                b.setCode(100005);
                b.setText("Добавить в избранное");
            }
            b.setId(CastUtils.castToLong(res.getId()));
            b.setUid(res.getUid());
            res.getButtons().add(b);
        }

        try {
            if (userTypeId != null && userTypeId.equals(0) && req.getType() == 1 && req.getAction().equals(1)) {
                if (questionnaire != null && questionnaire.getEnableOffers()) {
                    List<QuestionnaireService.ReplyInfo> replies = CollectionUtils.isEmpty(questionnaire.getReplies()) ? null :
                            questionnaire.getReplies().stream().filter(i -> i.getUserId() != null
                                    && i.getUserId().equals(userId)).collect(Collectors.toList());

                    if (CollectionUtils.isEmpty(replies) || replies.stream().allMatch(r -> r.getState() == 20009)) {
                        ScreenBuilderService.ButtonRes.ButtonDto button = new ScreenBuilderService.ButtonRes.ButtonDto();
                        button.setCode(100010);
                        button.setText("Предложить пилот");
                        button.setIsDisabled(false);
                        button.setClickAction("/view?type=7&name=offer_Client&action=2");
                        button.setClickMethod("GET");
                        if (CollectionUtils.isEmpty(res.getButtons()))
                            res.setButtons(new ArrayList<>());
                        res.getButtons().add(0, button);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error: ", e);
        }
        log.info("response state object {}", res.getState());

        if ("serviceCompany_import".equalsIgnoreCase(req.getName())) {
            res.setPopupFooter(new ViewRes.PopupFooter(
                    "Зарегистрируйтесь для просмотра полной информациии о сервисе",
                    "После регистрации будут доступны: подробная информация о сервисе и импортозамещении, а также текущие предложения.",
                    "Зарегистрироваться",
                    "Войти"));
        }
        return res;
    }

    private String getStateName(ViewReq req, Long state) {
        String stateStr = states.get(state);
        if ("ru".equals(req.getLocale())
                && req.getType() != null
                && (req.getType().equals(0) || req.getType().equals(1) || req.getType().equals(2))) {
            if (state.equals(20004L)) {
                stateStr = "Анкета опубликована";
            } else if (state.equals(20003L)) {
                stateStr = "Анкета нуждается в доработке";
            } else if (state.equals(20002L)) {
                stateStr = "Анкета на проверке";
            }
        }
        return stateStr;
    }

    private String setViewCount(Integer viewCount, String locale) {
        String val = viewCount != null ? viewCount.toString() : "0";
        if ("ru".equalsIgnoreCase(locale)) {
            if (val.equals("11") || val.equals("12") || val.equals("13") || val.equals("14")) {
                val += " просмотров";
            } else if (val.endsWith("1")) {
                val += " просмотр";
            } else if (val.endsWith("2") || val.endsWith("3") || val.endsWith("4")) {
                val += " просмотра";
            } else {
                val += " просмотров";
            }
        } else {
            if ("1".equals(val)) {
                val += " view";
            } else {
                val += " views";
            }
        }
        return val;
    }

    private Boolean isStartUpCall(Long userId) {
        if (userId != null) {
            List<QuestionnaireService.Type> type = questionnaireService.getType(userId);
            if (type != null && type.size() > 0) {
                for (QuestionnaireService.Type t : type) {
                    if (t.getType() != null && t.getType().equals(0))
                        return true;
                }
            }
        }
        return false;
    }

    private String getInvestmentType(Long id) {
        QuestionnaireService.Round round = questionnaireService.getRound(id, null);
        return (round != null && Boolean.TRUE.equals(round.getInvestment())) ? "Administrator" : "short_Administrator";
    }

    private boolean validModule(ScreenBuilderService.Form.Module m) {
        if (m.getFields() != null && m.getFields().size() > 0) {
            boolean notOnlyHide = false;
            boolean isCardModule = "card".equals(m.getModuleFormat());
            boolean allEmptyFields = true;
            for (ScreenBuilderService.Form.Module.Field f : m.getFields()) {
                if (isCardModule && f.getValue() != null) {
                    allEmptyFields = false;
                    if (notOnlyHide)
                        break;
                }
                if ((f.getFormat() == null) || (f.getFormat() != null && !"hide".equalsIgnoreCase(f.getFormat()))) {
                    notOnlyHide = true;
                    if (isCardModule && !allEmptyFields)
                        break;
                }
            }
            return notOnlyHide && !(isCardModule && allEmptyFields);
        }
        return false;
    }

    //TODO сделать нормальный метод для полуения инфо о статусе пилота
    private ViewRes.State createState(Long replyState, String comment) {
        ViewRes.State state = REPLY_STATES.get(replyState);
        ViewRes.State retState = new ViewRes.State();
        if (state != null) {
            retState.setStateCode(state.getStateCode());
            retState.setStateName(state.getStateName());
            retState.setLogoFile(state.getLogoFile());
            retState.setDescription(state.getDescription());
            retState.setTitle(state.getTitle());
            if ("comment".equals(state.getComment())) {
                retState.setComment(comment);
            }
        }
        return retState;
    }

    private String getRole(String role, List<QuestionnaireService.Type> type, Long id, String uid, Integer typeId) {
        if (!CollectionUtils.isEmpty(type)) {
            for (QuestionnaireService.Type t : type) {
                if (id != null && id.equals(t.getQuestionnaireId()))
                    return "Administrator";
                if (uid != null && uid.equals(t.getUid()))
                    return "Administrator";
                if (typeId.equals(0) && t.getType().equals(0) && "SuperClient".equalsIgnoreCase(role))
                    return "SuperStartup";
            }
        }
        return role;
    }

    private String getRoleName(String role, String tariff) {
        return "SuperClient".equals(role) ? tariff : role;
    }
}
