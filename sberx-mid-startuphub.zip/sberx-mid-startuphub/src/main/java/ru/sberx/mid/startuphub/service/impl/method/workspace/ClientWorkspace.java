package ru.sberx.mid.startuphub.service.impl.method.workspace;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sberx.constants.exception.ErrorRes;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.mid.startuphub.back.*;
import ru.sberx.mid.startuphub.controller.dto.res.workspace.ClientWorkspaceRes;
import ru.sberx.mid.startuphub.service.impl.method.ClientType;
import ru.sberx.utils.util.StringUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

@Service
@Slf4j
public class ClientWorkspace {

    private final ObjectMapper objectMapper;
    private final QuestionnaireService questionnaireService;
    private final ScreenBuilderService screenBuilderService;
    private final Map<String, String> typeNameMapping;
    private final Integer action;
    private final NotificationService notificationService;

    public ClientWorkspace(ObjectMapper objectMapper,
                           QuestionnaireService questionnaireService,
                           ScreenBuilderService screenBuilderService,
                           @Value("${application.workspace.client.type.name.mapping}") String typeNameMapping,
                           @Value("${application.workspace.client.action}") Integer action,
                           NotificationService notificationService) throws JsonProcessingException {
        this.objectMapper = objectMapper;
        this.questionnaireService = questionnaireService;
        this.screenBuilderService = screenBuilderService;
        this.typeNameMapping = this.objectMapper.readValue(typeNameMapping, new TypeReference<>() {
        });
        this.action = action;
        this.notificationService = notificationService;
    }

    public ClientWorkspaceRes getClientWorkspace(Long userId,
                                                 String role,
                                                 String login,
                                                 Integer reqType,
                                                 String locale) {
        if (!"SyndicateUser".equalsIgnoreCase(role)) {
            List<QuestionnaireService.Type> types = questionnaireService.getType(userId);
            if (checkTypes(types)) {
                Long questionnaireId = types.get(0).getQuestionnaireId();
                Integer type = types.get(0).getType();
                ClientWorkspaceRes res = getDraftRes(questionnaireId, type, locale);
                res.setLogin(login);
                res.setUserRole(role);
                return res;
            } else {
                if (types.isEmpty()) {
                    throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
                }
                QuestionnaireService.Type t = types.get(types.size() - 1);
                Long qId = t.getQuestionnaireId();
                QuestionnaireService.Questionnaire parent = questionnaireService
                        .getQuestionnaireByParentId(qId);
                Integer tp = reqType == null ? nvl(t.getType(), 0) : reqType;
                String tariffName = null;
                try {
                    QuestionnaireService.TariffRes tariff = questionnaireService.getTariff(qId, userId, "Administrator", true);
                    if (tariff != null)
                        tariffName = tariff.getSysname();
                } catch (Exception e) {
                    log.error("Error getting tariff: ", e);
                }
                String tariffRole = (org.springframework.util.StringUtils.hasText(role) && "Client".equalsIgnoreCase(role)) ? role :
                        (org.springframework.util.StringUtils.hasText(tariffName) ? tariffName : role);
                List<ScreenBuilderService.Menu> sidebars = screenBuilderService.getMenu(tp, "sidebar", tariffRole);
                for (ScreenBuilderService.Menu menu: sidebars) {
                    if (menu.getSysname() != null && menu.getSysname().equals("reply")) {
                        menu.setReplyCount(t.getNewReply());
                    }
                }
                List<ScreenBuilderService.Menu> menus = screenBuilderService.getMenu(t.getType(), "topbar", null);
                addIdToMenu(sidebars, t.getQuestionnaireId());
                addIdToMenu(menus, t.getQuestionnaireId());
                ClientWorkspaceRes res = new ClientWorkspaceRes();
                res.setSideBar(sidebars);
                ClientWorkspaceRes.Topbar topbar = new ClientWorkspaceRes.Topbar(t.getQuestionnaireId(),
                        t.getUid(),
                        t.getName(),
                        StringUtils.getLogo(t.getLogoPath()),
                        menus);
                res.setTariffSysName(tariffName);
                res.setTopBar(topbar);
                res.setType(t.getType());
                res.setTypeName(ClientType.getName(tp));
                res.setTypeSysName(ClientType.getSysName(tp));
                res.setStateName(t.getStateName());
                res.setStateSysName(t.getStateSysName());
                res.setInvestorType(getInvestorType(t.getInvestorType()));
                res.setSber500Check(parent != null
                        && parent.getQuestionnaire() != null
                        && parent.getQuestionnaire().getSber500() != null
                        ? parent.getQuestionnaire().getSber500()
                        : t.getSber500());
                res.setUuid(t.getUid());
                res.setNewReply(t.getNewReply());
                res.setLogin(login);
                res.setUserRole(role);
                try {
                    if (userId != null) {
                        NotificationService.NoticeAmount noticeAmount = notificationService.getNoticeAmount(userId);
                        res.setNotice(new ClientWorkspaceRes.Notice(
                                noticeAmount.getTotalAmount(),
                                noticeAmount.getNewAmount(),
                                noticeAmount.getWatchedAmount()
                        ));
                    }
                } catch (Exception e) {
                    log.error("Notice get error: ", e);
                }
                return res;
            }
        } else {
            ClientWorkspaceRes res = new ClientWorkspaceRes();
            res.setType(4);
            res.setTypeSysName("SyndicateUser");
            res.setTypeName("Клуб");
            res.setStateName("Активный");
            res.setEmail(login);
            res.setLogin(login);
            res.setUserRole(role);
            res.setTopBar(new ClientWorkspaceRes.Topbar(null,
                    login,
                    null,
                    null,
                    List.of(ScreenBuilderService.Menu.getExitButton())));
            return res;
        }
    }

    private <T> T nvl(T a, T b) {
        return a == null ? b : a;
    }

    private void addIdToMenu(List<ScreenBuilderService.Menu> menus, Long id) {
        if (menus != null && !menus.isEmpty()) {
            for (ScreenBuilderService.Menu i : menus) {
                if (i.getAction() != null && i.getAction().endsWith("id=")) {
                    i.setAction(i.getAction() + id);
                }
                if (i.getAction() != null && i.getAction().contains("{questionnaireId}")) {
                    i.setAction(i.getAction().replace("{questionnaireId}", id.toString()));
                }
            }
        }
    }

    private ClientWorkspaceRes getDraftRes(Long questionnaireId, Integer type, String locale) {
        ClientWorkspaceRes res = new ClientWorkspaceRes();
        QuestionnaireService.Questionnaire q = questionnaireService.getQuestionnaire(questionnaireId);
        List<ScreenBuilderService.Form> forms = screenBuilderService.getForms(type, action, typeNameMapping.get(type.toString()), locale);
        Map<String, Object> personalData = objectMapper.convertValue(q, new TypeReference<>() {
        });
        screenBuilderService.fillForms(forms, personalData, 2, false, false, locale, q != null && Boolean.TRUE.equals(q.getIsException()), null, null, null, null, null);
        res.setQuestionnaireId(questionnaireId);
        if (q != null && q.getQuestionnaire() != null && q.getQuestionnaire().getUuid() != null)
            res.setUuid(q.getQuestionnaire().getUuid().toString());
        res.setId(questionnaireId);
        res.setType(type);
        res.setForms(forms);

        if (q != null
                && q.getQuestionnaire() != null
                && q.getQuestionnaire().getFullName() != null
                && !"".equals(q.getQuestionnaire().getFullName())
                && !" ".equals(q.getQuestionnaire().getFullName())) {
            if (res.getForms() != null
                    && res.getForms().size() == 1
                    && res.getForms().get(0).getModules() != null
                    && res.getForms().get(0).getModules().size() > 0) {
                for (ScreenBuilderService.Form.Module m : res.getForms().get(0).getModules()) {
                    if (m.getModule() != null
                            && "Условия соглашения".equals(m.getModule())
                            && m.getFields() != null
                            && m.getFields().size() > 0) {
                        for (ScreenBuilderService.Form.Module.Field f : m.getFields()) {
                            if (f.getSysName() != null
                                    && (f.getSysName().equals("userConsent_consent")
                                    || f.getSysName().equals("userConsent_contract"))) {
                                f.setValue(true);
                            }
                        }
                        break;
                    }
                }
            }
        }

        if (res.getForms() != null
                && res.getForms().size() == 1
                && res.getForms().get(0).getModules() != null
                && res.getForms().get(0).getModules().size() > 0) {
            for (ScreenBuilderService.Form.Module m : res.getForms().get(0).getModules()) {
                for (ScreenBuilderService.Form.Module.Field f : m.getFields()) {
                    if (f.getSysName() != null && f.getType() != null && f.getType().equals("boolean")) {
                        f.setValue("questionnaire_sber500".equalsIgnoreCase(f.getSysName()) ? "true" : null);
                    }
                }
            }
        }

        if (q != null && q.getQuestionnaire() != null) {
            res.setStateName(q.getQuestionnaire().getStateName());
            res.setSber500Check(q.getQuestionnaire().getSber500());
        }
        return res;
    }

    private boolean checkTypes(List<QuestionnaireService.Type> types) {
        for (QuestionnaireService.Type t : types) {
            if (Boolean.TRUE.equals(t.getIsDisabled()) || t.getState().equals("20009")) {
                DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
                dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+3"));
                List<String> description = List.of("Причину отклонения направили вам на почту " + dateFormat.format(t.getModified())
                        + "\nС требованиями к размещению стартапа на платформе можно ознакомиться на главной странице. " +
                        "Вы можете подать заявку повторно, внеся необходимые изменения в анкету.");
                ErrorRes.ButtonDto button1 = new ErrorRes.ButtonDto();
                button1.setText("Перейти к анкете");
                button1.setType("accept");
                button1.setLink("/view?type=0&action=2&name=startup_edit&id=" + t.getQuestionnaireId());
                ErrorRes.ButtonDto button2 = new ErrorRes.ButtonDto();
                button2.setText("Выйти");
                button2.setType("decline");
                button2.setLink("/");
                List<ErrorRes.ButtonDto> buttons = List.of(button1, button2);
                throw new SberxException(SberxErrors.QUESTIONNAIRE_REJECTED, description, buttons);
            }
        }
        return types.size() == 1
                && types.get(0) != null
                && types.get(0).getStateName() != null
                && types.get(0).getStateName().equalsIgnoreCase("draft");
    }

    private Integer getInvestorType(String type) {
        if (type != null) {
            if (type.equalsIgnoreCase("Бизнес-ангел"))
                return 2;
            else if (type.equalsIgnoreCase("Венчурный фонд"))
                return 3;
            else if (type.equalsIgnoreCase("Family Office"))
                return 4;
            return 5;
        }
        return null;
    }

}
