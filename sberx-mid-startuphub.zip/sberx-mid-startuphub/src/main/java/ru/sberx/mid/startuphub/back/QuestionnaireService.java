package ru.sberx.mid.startuphub.back;

import com.fasterxml.jackson.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import ru.sberx.configs.web.WebConfig;
import ru.sberx.mid.startuphub.controller.dto.req.ListReq;
import ru.sberx.utils.util.StringUtils;

import javax.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.function.Consumer;

import static ru.sberx.constants.Constants.Header.ROLE;
import static ru.sberx.constants.Constants.Header.USER_ID;

@Service
public class QuestionnaireService {
    private final WebClient webClient;
    private final String getQuestionnaireMethod;
    private final String getQuestionnaireListMethod;
    private final String getPilotMethod;
    private final String getTypeMethod;
    private final String getApplicationMethod;
    private final String getRoundMethod;
    private final String getCommunityMethod;
    private final String getSyndicateMethod;
    private final String getQuestionnaireGuidListMethod;
    private final String getScoutingMethod;
    private final Date exceptionDate;
    private final String getReplyMethod;
    private final String getCommentMethod;
    private final String getMetricType;
    private final String getMetric;
    private final String getMetricList;
    private final String getTariffMethod;

    public QuestionnaireService(WebClient webClient,
                                @Value("${application.sberx.questionnaire.uri}") String uri,
                                @Value("${application.sberx.questionnaire.questionnaire.get}") String getQuestionnaireMethod,
                                @Value("${application.sberx.questionnaire.questionnaire.list}") String getQuestionnaireListMethod,
                                @Value("${application.sberx.questionnaire.pilot.get}") String getPilotMethod,
                                @Value("${application.sberx.questionnaire.application.get}") String getApplicationMethod,
                                @Value("${application.sberx.questionnaire.type.get}") String getTypeMethod,
                                @Value("${application.sberx.questionnaire.round}") String getRoundMethod,
                                @Value("${application.sberx.questionnaire.community}") String getCommunityMethod,
                                @Value("${application.sberx.questionnaire.syndicate}") String getSyndicateMethod,
                                @Value("${application.sberx.questionnaire.questionnaire.guid}") String getQuestionnaireGuidListMethod,
                                @Value("${application.sberx.questionnaire.scouting}") String getScoutingMethod,
                                @Value("${application.sberx.questionnaire.exception-date}") Long exceptionDate,
                                @Value("${application.sberx.questionnaire.reply.get}") String getReplyMethod,
                                @Value("${application.sberx.questionnaire.comment}") String getCommentMethod,
                                @Value("${application.sberx.questionnaire.metric.type}") String getMetricType,
                                @Value("${application.sberx.questionnaire.metric.get}") String getMetric,
                                @Value("${application.sberx.questionnaire.metric.list}") String getMetricList)
            throws URISyntaxException {
        this.webClient = webClient;
        this.getQuestionnaireMethod = new URI(uri + getQuestionnaireMethod).normalize().toString();
        this.getPilotMethod = new URI(uri + getPilotMethod).normalize().toString();
        this.getQuestionnaireListMethod = new URI(uri + getQuestionnaireListMethod).normalize().toString();
        this.getApplicationMethod = new URI(uri + getApplicationMethod).normalize().toString();
        this.getTypeMethod = new URI(uri + getTypeMethod).normalize().toString();
        this.getRoundMethod = new URI(uri + getRoundMethod).normalize().toString();
        this.getCommunityMethod = new URI(uri + getCommunityMethod).normalize().toString();
        this.getSyndicateMethod = new URI(uri + getSyndicateMethod).normalize().toString();
        this.getQuestionnaireGuidListMethod = new URI(uri + getQuestionnaireGuidListMethod).normalize().toString();
        this.getScoutingMethod = new URI(uri + getScoutingMethod).normalize().toString();
        this.getReplyMethod = new URI(uri + getReplyMethod).normalize().toString();
        this.getCommentMethod = new URI(uri + getCommentMethod).normalize().toString();

        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("UTC"));
        cal.setTimeInMillis(exceptionDate * 1000L);
        this.exceptionDate = cal.getTime();

        this.getMetricType = new URI(uri + getMetricType).normalize().toString();
        this.getMetric = new URI(uri + getMetric).normalize().toString();
        this.getMetricList = new URI(uri + getMetricList).normalize().toString();
        this.getTariffMethod = new URI(uri + "/tariff").normalize().toString();
    }

    private void setIsException(Questionnaire questionnaire){
        if (questionnaire != null
                && questionnaire.getQuestionnaire() != null
                && questionnaire.getQuestionnaire().getCreated() != null
                && questionnaire.getQuestionnaire().getCreated().after(exceptionDate))
            questionnaire.setIsException(true);
    }

    public Questionnaire getQuestionnaire(Long questionnaireId) {
        WebConfig.logSending(getQuestionnaireMethod, "questionnaireId", questionnaireId);
        Questionnaire questionnaire = webClient.get()
                .uri(getQuestionnaireMethod, uriBuilder -> uriBuilder
                        .queryParam("questionnaireId", questionnaireId)
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Questionnaire.class)
                .block();
        setIsException(questionnaire);
        WebConfig.logReceiving(getQuestionnaireMethod, questionnaire);
        return questionnaire;
    }

    public Questionnaire getQuestionnaireByUuid(String uuid,
                                                Long userid) {
        WebConfig.logSending(getQuestionnaireMethod, "uuid", uuid, "user-id", userid);
        Questionnaire questionnaire = webClient.get()
                .uri(getQuestionnaireMethod, uriBuilder -> uriBuilder
                        .queryParam("uuid", uuid)
                        .build())
                .headers(customHeaders(USER_ID, userid))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Questionnaire.class)
                .block();
        setIsException(questionnaire);
        WebConfig.logReceiving(getQuestionnaireMethod, questionnaire);
        return questionnaire;
    }

    public Round getRound(Long roundId, Long userId) {
        WebConfig.logSending(getRoundMethod, "roundId", roundId, "user-id", userId);
        Round round = webClient.get()
                .uri(getRoundMethod, uriBuilder -> uriBuilder
                        .queryParam("roundId", roundId)
                        .build())
                .headers(customHeaders(USER_ID, userId))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Round.class)
                .block();
        WebConfig.logReceiving(getRoundMethod, round);
        return round;
    }

    public Community getCommunity(Long communityId) {
        WebConfig.logSending(getCommunityMethod, "id", communityId);
        Community community = webClient.get()
                .uri(getCommunityMethod, uriBuilder -> uriBuilder
                        .queryParam("id", communityId)
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Community.class)
                .block();
        WebConfig.logReceiving(getCommunityMethod, community);
        return community;
    }

    public Syndicate getSyndicate(Long id) {
        WebConfig.logSending(getSyndicateMethod, "id", id);
        Syndicate community = webClient.get()
                .uri(getSyndicateMethod, uriBuilder -> uriBuilder
                        .queryParam("id", id)
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Syndicate.class)
                .block();
        WebConfig.logReceiving(getSyndicateMethod, community);
        return community;
    }

    public ScoutingDto getScouting(String uid) {
        WebConfig.logSending(getScoutingMethod, "uid", uid);
        ScoutingDto res = webClient.get()
                .uri(getScoutingMethod, uriBuilder -> uriBuilder
                        .pathSegment("{uid}")
                        .build(uid))
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(ScoutingDto.class)
                .block();
        WebConfig.logReceiving(getScoutingMethod, res);
        return res;
    }

    public Questionnaire getQuestionnaireByParentId(Long parentId) {
        WebConfig.logSending(getQuestionnaireMethod, "parentId", parentId);
        Questionnaire questionnaire = webClient.get()
                .uri(getQuestionnaireMethod, uriBuilder -> uriBuilder
                        .queryParam("parentId", parentId)
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Questionnaire.class)
                .block();
        setIsException(questionnaire);
        WebConfig.logReceiving(getQuestionnaireMethod, questionnaire);
        return questionnaire;
    }

    public List<MetricTypeDto> metricType(){
        return webClient.get()
                .uri(getMetricType)
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono((new ParameterizedTypeReference<List<MetricTypeDto>>() {}))
                .block();
    }

    public List<GetMetricRes> metric(String beginDate, String endDate, Long type, String uuid, Long userId) {
        WebConfig.logSending(getMetric, "beginDate", beginDate, "endDate", endDate, "metricType", type, "uuid", uuid, "userId", userId);
        List<GetMetricRes> res = webClient.get()
                .uri(getMetric, uriBuilder -> uriBuilder
                        .queryParam("beginDate", Optional.ofNullable(beginDate))
                        .queryParam("endDate", Optional.ofNullable(endDate))
                        .queryParamIfPresent("metricType", Optional.ofNullable(type))
                        .queryParamIfPresent("uuid", Optional.ofNullable(uuid))
                        .build())
                .headers(customHeaders(USER_ID, userId))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono((new ParameterizedTypeReference<List<GetMetricRes>>() {}))
                .block();
        WebConfig.logReceiving(getMetric, res);
        return res;
    }


    public List<MetricTypeDto> metricList(Long userId, Boolean addData, String uuid) {
        WebConfig.logSending(getMetricList, "userId", userId, "addData", addData, "uuid", uuid);
        return webClient.get()
                .uri(getMetricList, uriBuilder -> uriBuilder
                        .queryParamIfPresent("addData", Optional.ofNullable(addData))
                        .queryParamIfPresent("uuid", Optional.ofNullable(uuid))
                        .build())
                .headers(customHeaders(USER_ID, userId))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono((new ParameterizedTypeReference<List<MetricTypeDto>>() {}))
                .block();
    }

    public List<QuestionnaireInfo> getQuestionnaireList(Integer type, ListReq req) {
        WebConfig.logSending(getQuestionnaireListMethod, "type", type, "params", req);
        List<QuestionnaireInfo> questionnaireInfos = webClient.get()
                .uri(getQuestionnaireListMethod, uriBuilder -> uriBuilder
                        .queryParam("type", type)
                        .queryParamIfPresent("owner", Optional.ofNullable(req.getOwner()))
                        .queryParamIfPresent("state", Optional.ofNullable(req.getState()))
                        .queryParamIfPresent("name", Optional.ofNullable(req.getName()))
                        .queryParamIfPresent("isBran", Optional.ofNullable(req.getIsBran()))
                        .queryParamIfPresent("isDisabled", Optional.ofNullable(req.getIsDisabled()))
                        .queryParamIfPresent("birthDay", Optional.ofNullable(req.getBirthDay()))
                        .queryParamIfPresent("site", Optional.ofNullable(req.getSite()))
                        .queryParamIfPresent("location", Optional.ofNullable(req.getLocation()))
                        .queryParamIfPresent("investorType", Optional.ofNullable(req.getInvestorType()))
                        .queryParamIfPresent("industry", Optional.ofNullable(req.getIndustry()))
                        .queryParamIfPresent("innovationMethod", Optional.ofNullable(req.getInnovationMethod()))
                        .queryParamIfPresent("stady", Optional.ofNullable(req.getStady()))
                        .queryParamIfPresent("geography", Optional.ofNullable(req.getGeography()))
                        .queryParamIfPresent("registrationCountry", Optional.ofNullable(req.getRegistrationCountry()))
                        .queryParamIfPresent("communityState", Optional.ofNullable(req.getCommunityState()))
                        .queryParamIfPresent("investment", Optional.ofNullable(req.getInvestment()))
                        .queryParamIfPresent("preauthorize", Optional.ofNullable(req.getPreauthorize()))
                        .queryParamIfPresent("rowCount", Optional.ofNullable(req.getRows()))
                        .queryParamIfPresent("businessModel", Optional.ofNullable(req.getBusinessModel()))
                        .queryParamIfPresent("forLending", Optional.ofNullable(req.getForLending()))
                        .queryParamIfPresent("admin", Optional.ofNullable(req.getIsAdmin()))
                        .queryParamIfPresent("prioritySort", Optional.ofNullable(req.getPrioritySort()))
                        .queryParamIfPresent("mvpCode", Optional.ofNullable(req.getMvpCode()))
                        .queryParamIfPresent("technology", Optional.ofNullable(req.getTechnology()))
                        .queryParamIfPresent("project_technology", Optional.ofNullable(req.getProjectTechnology()))
                        .queryParamIfPresent("investment_technology", Optional.ofNullable(req.getInvestmentTechnology()))
                        .queryParamIfPresent("project_geography", Optional.ofNullable(req.getProjectGeography()))
                        .queryParamIfPresent("locationCountry", Optional.ofNullable(req.getLocationCountry()))
                        .queryParamIfPresent("investment_geography", Optional.ofNullable(req.getInvestmentGeography()))
                        .queryParamIfPresent("investment_industry", Optional.ofNullable(req.getInvestmentIndustry()))
                        .queryParamIfPresent("interactionType", Optional.ofNullable(req.getInteractionType()))
                        .queryParamIfPresent("round", Optional.ofNullable(req.getRound()))
                        .queryParamIfPresent("filteredBy", Optional.ofNullable(req.getFilteredBy()))
                        .queryParamIfPresent("sber500", Optional.ofNullable(req.getSber500()))
                        .queryParamIfPresent("sortBy", Optional.ofNullable(req.getSortBy()))
                        .queryParamIfPresent("orderBy", Optional.ofNullable(req.getOrderBy()))
                        .queryParamIfPresent("sessionId", Optional.ofNullable(req.getSessionId()))
                        .queryParamIfPresent("favorite", Optional.ofNullable(req.getFavorite()))
                        .queryParamIfPresent("responsible", Optional.ofNullable(req.getResponsible()))
                        .queryParamIfPresent("main", Optional.ofNullable(req.getMain()))
                        .queryParamIfPresent("staff", Optional.ofNullable(req.getStaff()))
                        .queryParamIfPresent("search", Optional.ofNullable(req.getSearch()))
                        .queryParamIfPresent("view", Optional.ofNullable(req.getView()))
                        .queryParamIfPresent("recommend", Optional.ofNullable(req.getRecommend()))
                        .queryParamIfPresent("isImport", Optional.ofNullable(req.getIsImport()))
                        .queryParamIfPresent("replaceName", Optional.ofNullable(req.getReplaceName()))
                        .queryParamIfPresent("role", Optional.ofNullable(req.getRole()))
                        .queryParamIfPresent("sales", Optional.ofNullable(req.getSales()))
                        .queryParamIfPresent("startBirthDate", Optional.ofNullable(req.getStartBirthDate()))
                        .queryParamIfPresent("endBirthDate", Optional.ofNullable(req.getEndBirthDate()))
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono((new ParameterizedTypeReference<List<QuestionnaireInfo>>() {}))
                .block();
        if (questionnaireInfos != null && questionnaireInfos.size() > 0) {
            questionnaireInfos
                    .stream()
                    .filter(s -> s.getLogoFile() != null)
                    .forEach(s -> s.setLogoFile(StringUtils.getLogo(s.getLogoFile())));
        }
        WebConfig.logReceiving(getQuestionnaireListMethod, questionnaireInfos);
        return questionnaireInfos;
    }

    public Pilot getPilot(Long pilotId,
                          Long userid) {
        WebConfig.logSending(getPilotMethod, "pilotId", pilotId, "userId", userid);
        Pilot pilot = webClient.get()
                .uri(getPilotMethod, uriBuilder -> uriBuilder
                        .pathSegment("{pilotId}")
                        .build(pilotId))
                .headers(customHeaders(USER_ID, userid))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(Pilot.class)
                .block();
        WebConfig.logReceiving(getPilotMethod, pilot);
        return pilot;
    }

    public static Consumer<HttpHeaders> customHeaders(String key, Object value) {
        return (httpHeaders) -> {
            httpHeaders.set("requestId", ThreadContext.get("requestId"));
            httpHeaders.set("client-id", ThreadContext.get("client-id"));
            if (value != null)
                httpHeaders.set(key, String.valueOf(value));
        };
    }

    public static Consumer<HttpHeaders> customHeadersRoleUser(Long userId, String role) {
        return (httpHeaders) -> {
            httpHeaders.set("requestId", ThreadContext.get("requestId"));
            httpHeaders.set("client-id", ThreadContext.get("client-id"));
            httpHeaders.set(USER_ID, String.valueOf(userId));
            httpHeaders.set(ROLE, role);
        };
    }

    public List<Type> getType(Long userId) {
        WebConfig.logSending(getTypeMethod, "userId", userId);
        List<Type> types = webClient.get()
                .uri(getTypeMethod, uriBuilder -> uriBuilder
                        .queryParamIfPresent("userId", Optional.ofNullable(userId))
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(new ParameterizedTypeReference<List<Type>>() {
                })
                .block();
        WebConfig.logReceiving(getTypeMethod, types);
        return types;
    }

    public ApplicationDto getApplicationById(@NotNull Long applicationId, Boolean auth) {
        WebConfig.logSending(getApplicationMethod, "applicationId", applicationId, "auth", auth);
        ApplicationDto dto = webClient.get()
                .uri(getApplicationMethod, uriBuilder -> uriBuilder.queryParam("id", applicationId)
                        .queryParamIfPresent("auth", Optional.of(auth))
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(ApplicationDto.class)
                .block();
        WebConfig.logReceiving(getApplicationMethod, dto);
        return dto;
    }

    public QuestionnaireGuidList getQuestionnaireGuidList(Integer type) {
        WebConfig.logSending(getQuestionnaireGuidListMethod, "type", type);
        QuestionnaireGuidList questionnaireGuidList = webClient.get()
                .uri(getQuestionnaireGuidListMethod, uriBuilder -> uriBuilder
                        .queryParam("type", type)
                        .build())
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(QuestionnaireGuidList.class)
                .block();
        WebConfig.logReceiving(getQuestionnaireGuidListMethod, questionnaireGuidList);
        return questionnaireGuidList;
    }

    public ReplyInfo getReply(Long id, Integer type){
        WebConfig.logSending(getReplyMethod, "id", id, "type", type);
        ReplyInfo reply = webClient.get()
                .uri(getReplyMethod, uriBuilder -> uriBuilder
                        .pathSegment("{id}")
                        .queryParamIfPresent("type", Optional.ofNullable(type))
                        .build(id)
                )
                .headers(WebConfig.defaultHeaders())
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(new ParameterizedTypeReference<ReplyInfo>() {
                })
                .block();
        WebConfig.logReceiving(getReplyMethod, reply);
        return reply;
    }

    public CommentGetRes getComments(String role, Long tableId, String tableName) {
        WebConfig.logSending(getCommentMethod, "role", role, "tableId", tableId, "tableName", tableName);
        CommentGetRes comments = webClient.get()
                .uri(getCommentMethod, uriBuilder -> uriBuilder
                        .queryParam("tableId", tableId)
                        .queryParam("tableName", tableName)
                        .build()
                )
                .headers(customHeaders("role", role))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(CommentGetRes.class)
                .block();
        WebConfig.logReceiving(getReplyMethod, comments);
        return comments;
    }

    public TariffRes getTariff(Long questionnaireId, Long userId, String role, Boolean back) {
        WebConfig.logSending(getTariffMethod, "questionnaireId", questionnaireId);
        TariffRes res = webClient.get()
                .uri(getTariffMethod, uriBuilder -> uriBuilder
                        .queryParamIfPresent("questionnaireId", Optional.ofNullable(questionnaireId))
                        .queryParam("back", Boolean.TRUE.equals(back))
                        .build()
                )
                .headers(customHeadersRoleUser(userId, role))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(TariffRes.class)
                .block();
        WebConfig.logReceiving("/tariff", res);
        return res;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Community{
        private Long state;
        private Integer type;
        private String name;
        private String site;
        private String position;
        private String phoneNumber;
        private String expectation;
        private String useful;
        private long[] industry;
        private long[] technology;
        private Long geography;
        private long[] round;
        private Long ventureProjectsCount;
        private String facebook;
        private String comment;
        private Long id;
        private Long questionnaireid;
        private String stateName;
        private Date modified;
        private Date created;
        private String typeName;
        private String email;
        private String expert;
        private String fio;
        private Long questionnaireState;
        private String questionnaireStateName;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Questionnaire {
        private Long questionnaireId;
        private QuestionnaireInfo questionnaire;
        private Project project;
        private List<Worker> workers;
        private Investment investment;
        private List<InvestorClub> investorClubs;
        private List<Pilot> pilots;
        private List<Representative> representatives;
        private List<Contact> contacts;
        private List<Feedback> feedbacks;
        private List<User> users;
        private List<Founder> founders;
        private List<CommunityUser> communityUsers;
        private User userQuestionnaire;
        private Representative representative;
        private Pilot pilot;
        private List<Pilot> successPilots;
        private List<Pilot> questionnairePilots;
        private List<Pilot> b2cPilots;
        private List<Pilot> b2bPilots;
        private List<Pilot> ecoPilots;
        private Pilot ecoPilot;
        private Boolean isChild;
        private Long userId;
        private SberFiveHundredDto sberFiveHundred;
        private Boolean enableOffers;
        private Boolean isException;
        private Integer viewCount;
        private List<ReplyInfo> replies;
        private ImportReplaceDTO importReplace;
        private List<ImportReplaceDTO.ImportReplaceItemsDTO> importItems;

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Project {
            @NotNull
            private String name;
            private String note;
            private Long[] industry;
            private Long[] interactionType;
            private Long[] businessModel;
            private String problem;
            private String auditory;
            private Boolean haveMVP;
            private Long[] geography;
            private Long[] sales;
            private String demoSite;
            private String demoFile;
            private String competitor;
            private String upSide;
            private String downSide;
            private Integer staff;
            private Integer hiringStaff;
            private String experience;
            private Long stady;
            private Boolean isDisabled;
            private String staffLocation;
            private Long[] expansion;
            private String indirectCompetitor;
            private String demoVideo;
            private String pitchVideo;
            private String addNote;
            private long[] mvpCode;
            private long[] technology;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class User {
            private Long userId;
            private String email;
            private String phoneNumber;
            private String name;
            private String lastName;
            private String firstName;
            private String position;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Worker {
            private Long workerId;
            private String role;
            private Integer age;
            private String note;
            private Float percentage;
            @NotNull
            private String fio;
            private Boolean isDisabled;
            private Long parentId;
            private Boolean isFounder;
            private String facebook;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Investment {
            private Boolean investment;
            private String experience;
            private Long[] round;
            private String sumInvestment;
            private String lastInvestment;
            private String coInvestment;
            private String turnover;
            private String businessPlan;
            private Long[] industry;
            private Long[] geography;
            private String note;
            private Boolean isDisabled;
            private long[] technology;
            private Boolean planInvestment;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class InvestorClub {
            private Long investmentClubId;
            private Long questionnaireId;
            private Long userId;
            private String name;
            private String role;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Representative {
            private Long representativeId;
            @NotNull
            private String fio;
            private String phone;
            private String email;
            private String role;
            private Boolean isDisabled;
            private String facebook;
            private String lastName;
            private String firstName;
            private String position;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Contact {
            private Long contactId;
            @NotNull
            private Long type;
            @NotNull
            private String name;
            @NotNull
            private String value;
            private Boolean isDisabled;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @NoArgsConstructor
        public static class Feedback {
            private Long feedbackId;
            @NotNull
            private Long userId;
            private String userFio;
            private Long unitId;
            private Long userQuestionnaireId;
            private Long interactionState;
            private String comment;
            private Integer score;
            private Date createDate;
            private Date date;
            private Integer needScore;
            private String needComment;
            private Integer caseScore;
            private String caseComment;
            private Integer kpiScore;
            private String kpiComment;
            private Boolean isBran;
            private Date dateend;
            private Date pilotstart;
            private Date pilotend;
            private Date datecontract;
            private String stateName;
            private Integer state;
            private Long questionnaireId;
            private String unitName;
        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JsonIgnoreProperties(ignoreUnknown = true)
        @NoArgsConstructor
        public static class SberFiveHundredDto {
            private Long questionnaireId;
            @JsonProperty("firsttime")
            private Boolean firstTime;
            private String motivation;
            @JsonProperty("monthrevenue")
            private String monthRevenue;
            @JsonProperty("quarterrevenue")
            private String quarterRevenue;
            private Integer clients;
            @JsonProperty("ecorequirement")
            private Long[] ecoRequirement;
        }
    }


    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class QuestionnaireInfo {
        @NotNull
        private UUID uuid;
        List<Long> userId;
        @NotNull
        private String name;
        @NotNull
        private String fullName;
        private Date birthDay;
        private String location;
        private String logoFile;
        private Boolean legalRegistered;
        private Boolean mentoring;
        private String turnover;
        private String site;
        private String note;
        private Long[] innovationMethod;
        private Long[] industry;
        private Boolean mailNews;
        private Long[] stady;
        private Boolean club;
        private Boolean representative;
        @NotNull
        private Integer type;
        private String typeName;
        private Date modified;
        private Date created;
        private Boolean isBran;
        private Boolean isDisabled;
        private Long[] round;
        private Long[] geography;
        private String[] tags;
        private String phoneNumber;
        private String email;
        private Long owner;
        private String inviteFio;
        private String inviteUnit;
        private Long inviteUser;
        private String questionnaireId;
        private Boolean isNew;
        private Integer rang;
        private Long[] model;
        private Integer staff;
        private Long[] interactionType;
        private Long registration;
        private String stateName;
        private Integer state;
        private Long investorType;
        private Long registrationCountry;
        private Boolean successfullCase;
        private Boolean scouting;
        private Integer startupInvestmentYears;
        private Integer lastYearInvestmentsCount;
        private Integer overallPilots;
        private Integer overallContracts;
        private String communityState;
        private Integer allDealsNumber;
        private Integer exitDealsNumber;
        private Integer activeDealsNumber;
        private Boolean accelerator;
        private Integer birthYear;
        private Long locationCountry;
        private Boolean community;
        private Boolean successPilots;
        private Boolean pilot;
        private Boolean successPilotsB2C;
        private Long stateCode;
        private long[] sales;
        private long[] salesValue;
        private String portfolioNote;
        private long[] businessModel;
        private Boolean forLending;
        private String transcription;
        private long[] acceleratorCode;
        private Integer priority;
        private String typeLabel;
        private String userMail;
        private String userPhone;
        private String fullNote;
        private long[] technology;
        @JsonProperty("project_technology")
        private long[] projectTechnology;
        @JsonProperty("investment_technology")
        private long[] investmentTechnology;
        @JsonProperty("project_geography")
        private long[] projectGeography;
        @JsonProperty("investment_geography")
        private long[] investmentGeography;
        @JsonProperty("investment_industry")
        private long[] investmentIndustry;
        private String clickAction;
        private String clickMethod;
        private Long parentId;
        private Date revisionDate;
        private String inn;
        private String acceleratorSite;
        private String comment;
        private Boolean showMore;
        private Boolean sber500;
        private Integer favorites;
        private Boolean favorite;
        private Long responsible;
        private String responsibleLogin;
        private Boolean view;
        private Boolean enableOffers;
        private List<Button> buttons;
        private Boolean offerPilot;
        private Boolean isImport;
        private String acceleratorString;
        private String[] importReplaceName;
        private String businessPlan;
        private Date lastEnter;

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Button {
            private Integer code;
            private String text;
            private Boolean isDisabled;
            private String clickAction;
            private String clickMethod;
        }
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Pilot {
        private Long questionnaireId;
        private List<Long> userId;
        private Long pilotId;
        private Long pilotid;
        private Boolean pilot;
        private String suggestCase;
        private Boolean experience;
        private String businessUnit;
        private String reference;
        private String department;
        private String conditions;
        private Boolean isDisabled;
        private Boolean file;
        private String name;
        private Long state;
        private String stateName;
        private Boolean isPublished;
        private Boolean isBran;
        private Long target;
        private String targetOption;
        private Integer relevance;
        private Long effect;
        private Long resources;
        private Boolean search;
        private Date deadline;
        private Long exp;
        private String company;
        private String decision;
        private Boolean isForeign;
        private String decisionCompany;
        private Boolean isHub;
        private Long[] industry;
        private List<Response> response;
        private QuestionnaireInfo questionnaire;
        private String replyStatus;
        private Boolean ecoSystem;
        private Boolean isB2B;
        private Boolean isB2C;
        private Boolean isSuccess;
        private Boolean isQuestionnaire;
        @JsonProperty("pilot_view")
        private Integer pilotView;
        @JsonProperty("pilot_reply")
        private Integer pilotReply = 0;
        @JsonProperty("pilot_newReply")
        private Integer pilotNewReply = 0;
        private String site;
        private String demoFile;
        private Boolean favorite;
        private Date modified;
        private Boolean view;
        private Date created;
        private Integer viewCount;
        private Long replyState;
        private String replyComment;
        private Long replyId;
        private Date replyDate;
        private Long replyUserId;

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Response {
            private Long responseId;
            private String question;
            private String questionDescription;
            private Boolean isDisabled;
            private String responseNote;
        }
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Type {
        private Integer type;
        private Long questionnaireId;
        private String state;
        private String stateName;
        private String logoPath;
        private String phone;
        private String phoneNumber;
        private String email;
        private Date modified;
        private String name;
        private Boolean isDisabled;
        private String stateSysName;
        private String investorType;
        private Boolean sber500;
        private String uid;
        private Integer newReply;
        private Date lastEnter;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class QuestionnaireStatus {
        private Long questionnaireId;
        private Boolean isDisabled;
        private Long userId;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private static class Founder {
        private Long founderId;
        private Long questionnaireId;
        private String fio;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private static class CommunityUser {
        private Long communityUserId;
        private Long questionnaireId;
        private Long userId;
        private String ambition;
        private String expectation;
        private Long state;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class ApplicationDto {

        @NotNull
        private Long applicationId;
        @NotNull
        private Integer type;
        @NotNull
        private Long state;
        private Date created;
        private Date modified;
        @NotNull
        private String firstName;
        @NotNull
        private String lastName;
        @NotNull
        private String phone;
        @NotNull
        private String position;
        @NotNull
        private String orgFullName;
        @NotNull
        private String site;
        @NotNull
        private String email;
        private Integer investorType;
        private String tariff;
        private String tariffName;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class Round {
        private Long roundId;
        private Long questionnaireId;
        private String startupName;
        private String startupNameFullName;
        private Integer state;
        @JsonFormat(timezone = "GMT+3")
        private Date modified;
        @JsonFormat(timezone = "GMT+3")
        private Date created;
        private Boolean investment;
        private Long roundType;
        private String investmentPurpose;
        private Long sumInvestment;
        private Integer percent;
        private Long preMoney;
        private Long postMoney;
        private String result;
        private Boolean leadCheck;
        private String leadName;
        private Long lastInvestment;
        private Long futureInvestment;
        private Long geography;
        private Integer transactionType;
        private String roundInfo;
        @JsonFormat(timezone = "GMT+3")
        private Date endDate;
        private String presentation;
        private String logoFile;
        private Boolean favorite;
        private Integer marketingPercent;
        private Integer softwarePercent;
        private Integer teamPercent;
        private Integer extensionPercent;
        private String otherDescription;
        private Integer otherPercent;
        private String inviteFio;
        private String email;
        private String phone;
        private Date planDate;
        private String roundTypeName;
        private String clickAction;
        private String stateName;
        private Long viewCount;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class Syndicate {
        private Integer type;
        private String firstName;
        private String lastName;
        private String phone;
        private String position;
        private String orgFullName;
        private String site;
        private String email;
        private Long investorType;
        private Long questionnaireId;
        private String comment;
        private String ventureExperience;
        private Boolean isUnity;
        private String telegramLink;
        private Long sumInvestment;
        private Long id;
        private Date created;
        private Date modified;
        private Long state;
        private String stateName;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class ScoutingDto {
        private String uuid;
        private String name;
        private String phone;
        private String email;
        private String comment;
        private String adminComment;
        private Long state;
        private String stateName;
        private Date modified;
        private Date created;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class QuestionnaireGuidList {
        private List<QuestionnaireUID> list;

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class QuestionnaireUID {
            private UUID uid;
            private String name;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class CommentDTO {
        private Long commentId;
        private String comment;
        private Date date;
        private Boolean edited;
        private Long tableId;
        private String tableName;
        private String role;
        private Long userId;
        private String login;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class CommentGetRes {
        private List<CommentDTO> comments;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @NoArgsConstructor
    @Data
    public static class ReplyInfo {
        private Long replyId;
        private Long userId;
        private String note;
        private String fileUrl;
        @JsonProperty("fileURL")
        private String fileURLStr;
        private Long state;
        private Date date;
        private Long tableId;
        private String tableName;
        private List<Question> questions;
        private String cost;
        private String process;
        private Boolean isViewed;
        private String comment;
        private Date modified;
        private String offerName;
        private String offerDescription;
        private Long questionnaireId;
        private Boolean isPilotOffer;
        private List<CommentDTO> comments;
        private QuestionnaireService.QuestionnaireInfo questionnaire;
        private QuestionnaireService.Questionnaire.Project project;
        private List<QuestionnaireService.Pilot> b2bPilots;
        private List<QuestionnaireService.Pilot.Response> response;
        private ReplyInfo reply;

        public ReplyInfo(Long replyId,
                         Long userId,
                         String note,
                         String fileUrl,
                         Long state,
                         Date date,
                         Long tableId,
                         String tableName,
                         List<Question> questions,
                         String cost,
                         String process,
                         Boolean isViewed,
                         String comment,
                         Date modified,
                         String offerName,
                         String offerDescription,
                         Long questionnaireId,
                         Boolean isPilotOffer) {
            this.replyId = replyId;
            this.userId = userId;
            this.note = note;
            this.fileUrl = fileUrl;
            this.state = state;
            this.date = date;
            this.tableId = tableId;
            this.tableName = tableName;
            this.questions = questions;
            this.cost = cost;
            this.process = process;
            this.isViewed = isViewed;
            this.comment = comment;
            this.modified = modified;
            this.offerName = offerName;
            this.offerDescription = offerDescription;
            this.questionnaireId = questionnaireId;
            this.isPilotOffer = isPilotOffer;
        }

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Question {
            private Long responseId;
            private String responseNote;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class MetricTypeDto {
        private Integer type;
        private String name;
        private String shortName;
        private String description;
        private Boolean money;

        @JsonIgnore
        public GuideService.Values getVal(){
            GuideService.Values val = new GuideService.Values();
            val.setCode(this.type.toString());
            val.setName(this.name);
            val.setDescription(this.description);
            return val;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class ImportReplaceDTO {
        private Long questionnaireId;
        private String note;
        private String benefits;
        private List<String> name;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class ImportReplaceItemsDTO {
            private String name;
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class GetMetricRes {

        private Long metricType;
        private String metricName;
        private String currency;
        private String currencyName;
        private List<Value> values;

        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Value {
            @JsonFormat(timezone = "GMT+3")
            private Date date;
            private Long value;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class TariffRes {
        private String name;
        private String sysname;
    }
}
