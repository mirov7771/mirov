package ru.sberx.mid.startuphub.controller.dto.res.workspace;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.mid.startuphub.back.ScreenBuilderService;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ClientWorkspaceRes {
    private Long questionnaireId;
    private Long id;
    private Integer type;
    private List<ScreenBuilderService.Form> forms;
    private Long userId;
    private List<ScreenBuilderService.Menu> sideBar;
    private Topbar topBar;
    private String typeSysName;
    private String typeName;
    private Boolean isNew;
    private String stateName;
    private String stateSysName;
    private Integer investorType;
    private Boolean sber500Check;
    private String email;
    private Notice notice;
    private Integer newReply;
    private String uuid;
    private String login;
    private String userRole;
    private String tariffSysName;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Topbar {
        private Long questionnaireId;
        private String uuid;
        private String name;
        private String logoFile;
        private List<ScreenBuilderService.Menu> buttons;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    public static class Notice {
        private Integer totalAmount;
        private Integer newAmount;
        private Integer watchedAmount;
    }
}
