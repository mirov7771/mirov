package ru.sberx.mid.startuphub.controller.dto.req;

import lombok.Data;

@Data
public class SuccessStoryReq {
    private String sessionId;
    private String storyType;
    private String text;
}
