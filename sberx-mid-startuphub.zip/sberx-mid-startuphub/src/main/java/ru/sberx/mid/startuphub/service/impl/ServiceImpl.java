package ru.sberx.mid.startuphub.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.google.zxing.qrcode.encoder.Encoder;
import com.google.zxing.qrcode.encoder.QRCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.mid.startuphub.back.*;
import ru.sberx.mid.startuphub.controller.dto.req.ClientWorkspaceReq;
import ru.sberx.mid.startuphub.controller.dto.req.ListReq;
import ru.sberx.mid.startuphub.controller.dto.req.SuccessStoryReq;
import ru.sberx.mid.startuphub.controller.dto.req.ViewReq;
import ru.sberx.mid.startuphub.controller.dto.res.ListV2Res;
import ru.sberx.mid.startuphub.controller.dto.res.ViewRes;
import ru.sberx.mid.startuphub.controller.dto.res.workspace.ClientWorkspaceRes;
import ru.sberx.mid.startuphub.service.Service;
import ru.sberx.mid.startuphub.service.impl.method.ViewManager;
import ru.sberx.mid.startuphub.service.impl.method.list.AbstractList;
import ru.sberx.mid.startuphub.service.impl.method.workspace.ClientWorkspace;
import ru.sberx.mid.startuphub.utils.SvgUtils;

import java.awt.image.BufferedImage;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.mid.startuphub.utils.Constants.*;

@Component
@Slf4j
public class ServiceImpl implements Service {

    private final Map<String, AbstractList> listMethods;
    private final ViewManager viewManager;
    private final ClientWorkspace clientWorkspace;
    private final UserAuthService userAuthService;
    private final GuideService guideService;
    private final QuestionnaireService questionnaireService;
    private final ObjectMapper objectMapper;
    private final Map<String, List<String>> filterNamesMapping;
    private final NotificationService notificationService;
    private final SvgUtils svgUtils;

    @Value("${application.qrcode.url}")
    private String url;
    @Value("${application.preauth.list.count:69}")
    private Integer preauthCount;
    @Value("${application.admin-male}")
    private String adminMale;

    public ServiceImpl(Map<String, AbstractList> listMethods,
                       ViewManager viewManager,
                       ClientWorkspace clientWorkspace,
                       UserAuthService userAuthService,
                       GuideService guideService,
                       QuestionnaireService questionnaireService,
                       ObjectMapper objectMapper,
                       @Value("${application.list.v2.filter.name}") String filterNamesMapping,
                       NotificationService notificationService,
                       SvgUtils svgUtils)
            throws JsonProcessingException {
        this.listMethods = listMethods;
        this.viewManager = viewManager;
        this.clientWorkspace = clientWorkspace;
        this.userAuthService = userAuthService;
        this.guideService = guideService;
        this.questionnaireService = questionnaireService;
        this.objectMapper = objectMapper;
        this.filterNamesMapping = objectMapper.readValue(filterNamesMapping, new TypeReference<>() {
        });
        log.debug("Initialize filter-names mapping: {}", this.filterNamesMapping);
        this.notificationService = notificationService;
        this.svgUtils = svgUtils;
    }

    public List<?> list(ListReq req) {
        if (req.getType() == null) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        }
        List<Map<String, Object>> res = new ArrayList<>();
        if ("Administrator".equalsIgnoreCase(req.getRole()))
            req.setIsAdmin(true);
        log.debug("Parameter {name} for clickAction joined with _{}", req.getRole());
        for (Integer i : req.getType()) {
            String listMethod = AbstractList.getListMethod(i);
            log.info("Getting {} list", listMethod);
            log.debug("List parameters: {}", req);
            List<?> l = listMethods.get(listMethod).getList(i, req);
            log.debug("Received {} list: {}", listMethod, l);
            List<Map<String, Object>> lm = l.stream().map(o -> {
                Map<String, Object> m = objectMapper.convertValue(o, new TypeReference<>() {
                });
                m.put("clickMethod", "GET");
                String clickAction = AbstractList.getClickAction(i, m, req.getRole(), req.getPreauthorize(), req.getFormName(), req.getIsImport(), req.getUserId());
                m.put("clickAction", clickAction);
                if (m.containsKey("companyId"))
                    m.put("type", 3);
                return m;
            }).collect(Collectors.toList());
            log.debug("{} list added : {}", listMethod, lm);
            res.addAll(lm);
        }
        log.debug("Hole list: {}", res);
        log.info("List returned");
        if (Boolean.TRUE.equals(req.getForLending()) && res.size() > 0) {
            res.sort((p1, p2) -> {
                Integer i1 = (Integer) p1.get("priority");
                Integer i2 = (Integer) p2.get("priority");
                return nvl(i2, 0) - nvl(i1, 0);
            });
        } else if (Boolean.TRUE.equals(req.getIsImport()) && !CollectionUtils.isEmpty(res)) {
            String sortBy = "name".equalsIgnoreCase(req.getSortBy()) || "created".equalsIgnoreCase(req.getSortBy()) ? req.getSortBy().toLowerCase() : "modified";
            res.sort((e1, e2) -> {
                String s1 = (String) nvl(e1.get(sortBy), "");
                String s2 = (String) nvl(e2.get(sortBy), "");
                return "DESC".equalsIgnoreCase(req.getOrderBy()) ? s2.compareTo(s1) : s1.compareTo(s2);
            });
        }
        return res;
    }

    private <T> T nvl(T a1, T a2) {
        return a1 == null ? a2 : a1;
    }

    @SuppressWarnings("unchecked")
    @Override
    public ListV2Res listV2(ListReq req) {
        log.info("Getting list(v2)");
        log.debug("List parameters: {}", req);
        ListV2Res res = new ListV2Res();
        filterRequest(req);
        req.setNotAuth(
                !StringUtils.hasText(req.getSessionId())
                        && req.getType() != null
                        && req.getType().size() == 1
                        && req.getType().get(0).equals(0)
        );
        log.info("not auth {}", req.getNotAuth());
        UserAuthService.SessionInfo sessionInfo = null;
        if ((!StringUtils.hasText(req.getRole()) || req.getUserId() == null) && req.getSessionId() != null) {
            sessionInfo = userAuthService.checkSession(req.getSessionId());
            if (sessionInfo != null) {
                req.setUserId(sessionInfo.getExternalId());
                req.setRole(sessionInfo.getRole());
            }
        }
        String tariffName = null;
        String role = sessionInfo != null ? sessionInfo.getRole() : null;
        if (!CollectionUtils.isEmpty(req.getType())
                && req.getUserId() != null) {
            if (StringUtils.hasText(role)
                    && !"Administrator".equalsIgnoreCase(role)
                    && !"SberbankEmployee".equalsIgnoreCase(role)
                    && !"BusinessUnit".equalsIgnoreCase(role)
                    && !"AdministratorBran".equalsIgnoreCase(role)) {
                if (role.equals("CorpLight") || role.equals("InvestLight")) {
                    if (role.equals("CorpLight") && req.getType().stream().anyMatch(i -> i.equals(2)))
                        throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
                    if (role.equals("InvestLight") && req.getType().stream().anyMatch(i -> i.equals(1)))
                        throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
                }
            }
            try {
                QuestionnaireService.TariffRes tariff = questionnaireService.getTariff(null, req.getUserId(), "Administrator", true);
                if (tariff != null && StringUtils.hasText(tariff.getSysname())) {
                    tariffName = tariff.getSysname();
                    if (tariffName.equals("CorpLight") && req.getType().stream().anyMatch(i -> i.equals(2)))
                        throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
                    if (tariffName.equals("InvestLight") && req.getType().stream().anyMatch(i -> i.equals(4)))
                        throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
                }
            } catch (Exception e) {
                log.debug("Ошибка получения тарифа: {}", e.getMessage());
            }
        }

        if (Boolean.TRUE.equals(req.getFavorite())
                && StringUtils.hasText(req.getRole())
                && req.getRole().toLowerCase().contains("light")){
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
        }

        if (Boolean.TRUE.equals(req.getIsImport()))
            req.setType(List.of(0, 3));

        List<?> list = list(req);
        res.setTotalRowCount(list.size());
        String locale = StringUtils.hasText(req.getLocale()) ? req.getLocale() : "ru";

        List<QuestionnaireService.Type> types = null;

        if (req.getUserId() != null)
            types = questionnaireService.getType(req.getUserId());
        String filters = req.getFilters();
        if (!StringUtils.hasText(filters)
                && Boolean.TRUE.equals(req.getOwner())
                && req.getType().contains(PILOT_TYPE)
                && !CollectionUtils.isEmpty(types)
                && CORPORATE_TYPE.equals(types.get(0).getType())) {
            req.setFilters(CORP_OWNER_FILTER);
        }
        List<String> names = Boolean.TRUE.equals(req.getIsImport()) ? null : filterNamesMapping.get(filters);
        if (names != null) {
            List<GuideService.Guide> guides = guideService.getGuideV2(names,
                    null,
                    null,
                    null,
                    StringUtils.hasText(req.getLocale()) ? req.getLocale() : "ru",
                    true);
            if (filters.equals("startup_unity")) {
                guides.stream()
                        .filter(g -> "География инвестиций".equals(g.getName()))
                        .forEach(g -> {
                            g.setName("ru".equalsIgnoreCase(locale) ? "Регион штаб-квартиры стартапа" : "Startup headquarters region");
                            g.setSysname("LocationCountry");
                        });

                GuideService.Guide extraGuide = null;
                for (GuideService.Guide g : guides) {
                    if (g.getName().equals("Регион штаб-квартиры стартапа") || g.getName().equals("Startup headquarters region"))
                        extraGuide = new GuideService.Guide(
                                g.getValues(),
                                "ru".equalsIgnoreCase(locale) ? "Рынки продаж" : "Sales markets",
                                "Geography",
                                null,
                                null,
                                null,
                                null,
                                null);
                }
                if (extraGuide != null)
                    guides.add(extraGuide);
            }
            guides.sort(Comparator.comparingInt(g -> names.indexOf(g.getSysname())));
            if (filters.equals("startup_unity")) {
                guides.stream()
                        .filter(g -> "MVP".equals(g.getSysname()))
                        .forEach(g -> {
                            g.setSysname("Stady");
                            g.setName("ru".equalsIgnoreCase(locale) ? "Стадия проекта" : "Project stage");
                        });
            }
            setupFiltersPayLock(req, guides, tariffName);
//          Отключаем доп фильтры пока не будет готов фронт
//            if (filters.equalsIgnoreCase("startup_unity")){
//                if (CollectionUtils.isEmpty(guides))
//                    guides = new ArrayList<>();
//                GuideService.Guide salesGuide = new GuideService.Guide();
//                salesGuide.setName("ru".equalsIgnoreCase(locale) ? "Наличие продаж" : "Availability of sales");
//                salesGuide.setSysname("Sales");
//                salesGuide.setValues(List.of(
//                        new GuideService.Values(
//                                "ru".equalsIgnoreCase(locale) ? "Есть продажи" : "Sales exists", "true", "radio"
//                        ),
//                        new GuideService.Values(
//                                "ru".equalsIgnoreCase(locale) ? "Нет продаж" : "Sales not exists", "false", "radio"
//                        ))
//                );
//                guides.add(salesGuide);
//
//                GuideService.Guide yearGuide = new GuideService.Guide();
//                yearGuide.setName("ru".equalsIgnoreCase(locale) ? "Дата основания" : "Date of foundation");
//                yearGuide.setSysname("BirthDate");
//                yearGuide.setStep(1);
//                yearGuide.setEndBirthDate(LocalDateTime.now().getYear());
//                yearGuide.setStartBirthDate(2000);
//                yearGuide.setValues(new ArrayList<>());
//                guides.add(yearGuide);
//            }
            res.setFilters(guides);
        }
        if ("user".equals(filters) && !"pilots_user".equals(req.getSchema())) {
            if (req.getSessionId() != null) {
                if (sessionInfo != null) {
                    Long userId = sessionInfo.getUserId();
                    list = list.stream().filter(o -> {
                        Map<String, Object> map = objectMapper.convertValue(o, new TypeReference<>() {
                        });
                        log.info("userId map {}", map);
                        Set<Long> userSet = new HashSet<>();
                        if (map.get("userId") != null) {
                            if (map.get("userId") instanceof Long)
                                userSet.add((Long) map.get("userId"));
                            else if (map.get("userId") instanceof List) {
                                List<Long> userList = (List<Long>) map.get("userId");
                                userSet.addAll(userList);
                            }
                        }
                        return userSet.contains(userId);
                    }).collect(Collectors.toList());
                }
            } else {
                list = new ArrayList<>();
            }
            log.debug("Result list: {}", list);
        }

        if (req.getType() != null && req.getType().size() == 1 || Boolean.TRUE.equals(req.getIsImport())) {
            res.setFavoriteCount(getFavoriteCount(req));
        }

        if (Boolean.TRUE.equals(req.getNotAuth()) && !CollectionUtils.isEmpty(list)) {
            list = list.stream().limit(preauthCount).collect(Collectors.toList());
            res.setLimitCount(preauthCount);
        } else {
            res.setLimitCount(!CollectionUtils.isEmpty(list) ? list.size() : 0);
        }

        if (req.getRowCount() != null) {
            int offset = req.getPageToken() != null ? req.getPageToken() : 0;
            int from = req.getRowCount() * offset;
            int size = list.size();
            if (from < size) {
                int to = from + req.getRowCount();
                if (to >= size) {
                    res.setNextPageToken(null);
                    to = size;
                } else {
                    res.setNextPageToken(offset + 1);
                }
                log.debug("Limiting list, getting sublist from {} to {}", from, to);
                list = list.subList(from, to);
            } else {
                list = List.of();
            }
        }


        setRecommend(res, req, types, tariffName);

        if (Boolean.TRUE.equals(req.getIsImport())) {
            GuideService.Guide filter = new GuideService.Guide();
            filter.setName("ru".equalsIgnoreCase(req.getLocale()) ? "Аналоги" : "Analogs");
            filter.setSysname("replaceName");
            GuideService.SearchDto searchRes = guideService.search(null);
            List<GuideService.Values> values = new ArrayList<>();
            if (searchRes != null && !CollectionUtils.isEmpty(searchRes.getValues())) {
                values = searchRes.getValues().stream().map(searchDto -> {
                    GuideService.Values value = new GuideService.Values();
                    value.setName(searchDto.getName());
                    value.setCode(searchDto.getValue());
                    value.setValue(searchDto.getValue());
                    return value;
                }).collect(Collectors.toList());
            }
            filter.setValues(values);
            res.setFilters(List.of(filter));
        }

        res.setList(list);
        res.setRowCount(res.getList() != null ? res.getList().size() : 0);
        res.setNeedPopup(CollectionUtils.isEmpty(list) &&
                Boolean.TRUE.equals(req.getIsImport())
                && !Boolean.TRUE.equals(req.getFavorite())
                && !Boolean.TRUE.equals(req.getRecommend())
                && !Boolean.TRUE.equals(req.getView())
                && !StringUtils.hasText(req.getSearch())
                && CollectionUtils.isEmpty(req.getReplaceName()));
        log.debug("Received list: {}", res);
        log.info("List(v2) returned");

        if (req.getRowCount() != null) {
            if (res.getTotalRowCount().compareTo(res.getRowCount()) < 1) {
                res.setVisibleRowCount(res.getTotalRowCount());
            } else {
                int pageToken = req.getPageToken() == null ? 0 : req.getPageToken();
                int visibleCount = req.getRowCount() * (pageToken + 1);
                res.setVisibleRowCount(visibleCount > res.getTotalRowCount() ? res.getTotalRowCount() : visibleCount);
            }
        }

        if (Boolean.TRUE.equals(req.getIsImport())
                && req.getUserId() == null
                && !CollectionUtils.isEmpty(res.getList())) {
            res.setList(res.getList().stream().limit(9).collect(Collectors.toList()));
            res.setNextPageToken(null);
        }

        return res;
    }

    private void setupFiltersPayLock(ListReq req, List<GuideService.Guide> guides, String tariffName) {
        String role = "SuperClient".equals(req.getRole()) && StringUtils.hasText(tariffName) ? tariffName : req.getRole();

        if (!StringUtils.hasText(req.getFilters()) || guides == null || guides.isEmpty()
                || role == null)
            return;
        if (!(role.equals(CORP_LIGHT_ROLE) || role.equals(INVEST_LIGHT_ROLE)))
            return;

        String locale = StringUtils.hasText(req.getLocale()) ? req.getLocale() : "ru";

        switch (req.getFilters()) {
            case STARTUP_UNITY_FILTER:
                setPayLock(guides, PAID_STARTUP_FILTERS, locale);
                break;
            case CORP_UNITY_FILTER:
                setPayLock(guides, PAID_CORP_FILTERS, locale);
                break;
            case INVEST_UNITY_FILTER:
                setPayLock(guides, PAID_INVEST_FILTERS, locale);
                break;
            default:
                break;
        }
    }

    private void setPayLock(List<GuideService.Guide> guides, Set<String> paidFilters, String locale) {
        if (guides == null || guides.isEmpty()
                || paidFilters == null || paidFilters.isEmpty()
                || !StringUtils.hasText(locale)) {
            return;
        }

        guides.forEach(guide -> {
            if (guide.getSysname() != null && paidFilters.contains(guide.getSysname())) {
                guide.setLock("tariffLock");
                if (locale.equals("ru")) {
                    guide.setLockText(PAY_LOCK_MESSAGE_RU);
                } else if (locale.equals("en")) {
                    guide.setLockText(PAY_LOCK_MESSAGE_EN);
                }
            }
        });
    }

    private void filterRequest(ListReq req) {
        if (!CollectionUtils.isEmpty(req.getIndustry()))
            req.setIndustry(guideService.filterGuideCodes(req.getIndustry()));
        if (!CollectionUtils.isEmpty(req.getTechnology()))
            req.setTechnology(guideService.filterGuideCodes(req.getTechnology()));
        if (!CollectionUtils.isEmpty(req.getStady()))
            req.setStady(guideService.filterGuideCodes(req.getStady()));
        if (!CollectionUtils.isEmpty(req.getRound()))
            req.setRound(guideService.filterGuideCodes(req.getRound()));
        if (!CollectionUtils.isEmpty(req.getInteractionType()))
            req.setInteractionType(guideService.filterGuideCodes(req.getTechnology()));
        if (!CollectionUtils.isEmpty(req.getGeography()))
            req.setGeography(guideService.filterGuideCodes(req.getGeography()));
        if (!CollectionUtils.isEmpty(req.getLocationCountry()))
            req.setLocationCountry(guideService.filterGuideCodes(req.getLocationCountry()));
        if (!CollectionUtils.isEmpty(req.getBusinessModel()))
            req.setBusinessModel(guideService.filterGuideCodes(req.getBusinessModel()));
        if (!CollectionUtils.isEmpty(req.getInvestorType()))
            req.setInvestorType(guideService.filterGuideCodes(req.getInvestorType()));
        if (!CollectionUtils.isEmpty(req.getInnovationMethod()))
            req.setInnovationMethod(guideService.filterGuideCodes(req.getInnovationMethod()));
    }

    @Override
    public ClientWorkspaceRes getClientWorkspace(ClientWorkspaceReq req) {
        log.info("Getting Client Workspace");
        log.debug("Workspace parameters: {}", req);
        ClientWorkspaceRes res = clientWorkspace.getClientWorkspace(req.getUserId(), req.getRole(), req.getLogin(), req.getType(), req.getLocale());
        log.debug("Received Client Workspace: {}", res);
        log.info("Client Workspace returned");
        return res;
    }

    @Override
    public ViewRes getView(ViewReq req) {
        log.info("Getting View");
        log.debug("View parameters: {}", req);
        ViewRes res = viewManager.getView(req);
        log.debug("Received View: {}", res);
        log.info("View returned");
        return res;
    }

    @Override
    public BufferedImage link(String uid) {
        try {
//            QRCodeWriter barcodeWriter = new QRCodeWriter();
//            BitMatrix bitMatrix =
//                    barcodeWriter.encode(url + uid, BarcodeFormat.QR_CODE, 200, 200);
//
//            return MatrixToImageWriter.toBufferedImage(bitMatrix);
            //return svgUtils.createSvgImage(bitMatrix);
            Map<EncodeHintType, Object> encodingHints = new HashMap<>();
            encodingHints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            QRCode code = Encoder.encode(url + uid, ErrorCorrectionLevel.H, encodingHints);
            return svgUtils.renderQRImage(code, 200, 200, 4);
        } catch (WriterException e) {
            throw new SberxException(SberxErrors.INTERNAL_ERROR, e.getMessage());
        }
    }

    @Override
    public void successStory(SuccessStoryReq req) {
        UserAuthService.SessionInfo sessionInfo = userAuthService.checkSession(req.getSessionId());
        if (sessionInfo != null && sessionInfo.getExternalId() != null) {
            List<QuestionnaireService.Type> type = questionnaireService.getType(sessionInfo.getExternalId());
            if (!CollectionUtils.isEmpty(type))
                notificationService.callNotify("blank",
                        Map.of("theme", type.get(0).getName() + ". История успеха", "text", "<b>" + req.getStoryType() + "</b></br>" + req.getText()),
                        adminMale);
        }
    }

    private Integer getFavoriteCount(ListReq req) {
        return req.getType().stream()
                .mapToInt(type -> listMethods.get(AbstractList.getListMethod(type)).getFavoritesCount(req))
                .sum();
    }

    private void setRecommend(ListV2Res res, ListReq req, List<QuestionnaireService.Type> types, String tariff) {
        if (!Boolean.TRUE.equals(req.getView()) &&
                !Boolean.TRUE.equals(req.getFavorite()) &&
                !Boolean.TRUE.equals(req.getIsImport()) &&
                !Boolean.TRUE.equals(req.getRecommend()) &&
                !StringUtils.hasText(req.getSearch()) &&
                CollectionUtils.isEmpty(req.getRound()) &&
                CollectionUtils.isEmpty(req.getTechnology()) &&
                Objects.isNull(req.getStaff()) &&
                CollectionUtils.isEmpty(req.getBusinessModel()) &&
                CollectionUtils.isEmpty(req.getLocationCountry()) &&
                CollectionUtils.isEmpty(req.getGeography()) &&
                CollectionUtils.isEmpty(req.getInteractionType()) &&
                CollectionUtils.isEmpty(req.getStady()) &&
                CollectionUtils.isEmpty(req.getIndustry()) &&
                req.getType().contains(0) &&
                !CollectionUtils.isEmpty(types) &&
                types.get(0).getType() != null &&
                (types.get(0).getType().equals(CORPORATE_TYPE) || types.get(0).getType().equals(INVESTOR_TYPE))) {
            List<QuestionnaireService.QuestionnaireInfo> recommended = listMethods.get(AbstractList.getListMethod(req.getType().get(0))).getRecommended(req);
            if (!CollectionUtils.isEmpty(recommended)) {
                recommended.sort(Comparator.comparing(i -> Boolean.TRUE.equals(i.getView())));
                res.setRecommendCount(recommended.size());
                res.setRecommend(recommended.stream().limit(3L).collect(Collectors.toList()));
                if (res.getRecommendCount() != null && !res.getRecommendCount().equals(0)) {
                    res.setRecommendTitle("ru".equalsIgnoreCase(req.getLocale()) ? "Рекомендованные " : "Recommended ");
                    res.setRecommendViewAll("ru".equalsIgnoreCase(req.getLocale()) ? "Смотреть все" : "Show all");
                    if (StringUtils.hasText(tariff)
                            && tariff.toLowerCase().contains("light"))
                        res.setRecommendDescription("ru".equalsIgnoreCase(req.getLocale()) ? "Все рекомендованные стартапы доступны только на тарифах Pro" : "All recommended startups are available only on Pro tariffs");
                }
            }
        }
    }

}
