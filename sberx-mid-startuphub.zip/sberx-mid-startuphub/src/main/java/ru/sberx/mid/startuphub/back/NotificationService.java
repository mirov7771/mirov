package ru.sberx.mid.startuphub.back;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import ru.sberx.configs.web.WebConfig;
import ru.sberx.dto.notifications.req.NotifyReq;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

import static ru.sberx.constants.Constants.Header.USER_ID;

@Service
public class NotificationService {
    private final WebClient webClient;
    private final String amountMethod;
    private final String notifyMethod;

    public NotificationService(WebClient webClient,
                               @Value("${application.sberx.notification.uri}") String uri,
                               @Value("${application.sberx.notification.amount}") String amountMethod,
                               @Value("${application.sberx.notification.notify}") String notifyMethod) throws URISyntaxException {
        this.webClient = webClient;
        this.amountMethod = new URI(uri + amountMethod).normalize().toString();
        this.notifyMethod = new URI(uri + notifyMethod).normalize().toString();
    }

    public NoticeAmount getNoticeAmount(Long userId) {
        WebConfig.logSending(amountMethod, "userId", userId);
        NoticeAmount sessionInfo = webClient.get()
                .uri(amountMethod)
                .headers(QuestionnaireService.customHeaders(USER_ID, userId))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(NoticeAmount.class)
                .block();
        WebConfig.logReceiving(amountMethod, sessionInfo);
        return sessionInfo;
    }

    public void callNotify(String sysName, Map<String, Object> params, String receiver){
        WebConfig.logSending(amountMethod, "sysName", sysName, "params", params, "receiver", receiver);
        NotifyReq req = new NotifyReq();
        req.setParams(params);
        req.setReceiver(receiver);
        req.setSysName(sysName);
        req.setType(NotifyReq.Types.EMAIL);
        webClient.post()
                .uri(notifyMethod)
                .headers(WebConfig.defaultHeaders())
                .bodyValue(req)
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .toBodilessEntity()
                .block();
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class NoticeAmount {
        private Integer totalAmount;
        private Integer newAmount;
        private Integer watchedAmount;
    }

}
