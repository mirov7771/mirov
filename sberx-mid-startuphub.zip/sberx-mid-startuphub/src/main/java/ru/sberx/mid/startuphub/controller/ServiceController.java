package ru.sberx.mid.startuphub.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.mid.startuphub.controller.dto.req.*;
import ru.sberx.mid.startuphub.controller.dto.res.ListV2Res;
import ru.sberx.mid.startuphub.controller.dto.res.ViewRes;
import ru.sberx.mid.startuphub.controller.dto.res.workspace.ClientWorkspaceRes;
import ru.sberx.mid.startuphub.service.Service;
import ru.sberx.utils.builder.ResponseBuilder;

import java.awt.image.BufferedImage;

import static ru.sberx.configs.web.WebConfig.setHeaders;
import static ru.sberx.constants.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.constants.Constants.Header.*;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class ServiceController {

    private final Service service;

    @Deprecated
    @GetMapping(value = "v2/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ListV2Res> listV2(@RequestHeader(CLIENT_ID) String clientId,
                                            @RequestHeader(REQUEST_ID) String requestId,
                                            @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                            @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId,
                                            ListReq req)
    {
        setHeaders(requestId, clientId);
        if (!Boolean.TRUE.equals(req.getPreauthorize()))
            req.setSessionId(sessionId);
        req.setLocale(locale);
        return ResponseBuilder.ok(service.listV2(req));
    }

    @GetMapping(value = "workspace/client", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ClientWorkspaceRes> workspaceClient(@RequestHeader(CLIENT_ID) String clientId,
                                                              @RequestHeader(REQUEST_ID) String requestId,
                                                              @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                                              @RequestHeader(USER_ID) Long userId,
                                                              @RequestHeader(ROLE) String role,
                                                              ClientWorkspaceReq req) {
        setHeaders(requestId, clientId);
        req.setUserId(userId);
        req.setRole(role);
        if (req.getType() != null){
            if (req.getType().equals(10) || req.getType().equals(11))
                req.setType(null);
        }
        req.setLocale(locale);
        return ResponseBuilder.ok(service.getClientWorkspace(req));
    }

    @GetMapping(value = "view", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ViewRes> view(@RequestHeader(CLIENT_ID) String clientId,
                                        @RequestHeader(REQUEST_ID) String requestId,
                                        @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                        @RequestHeader(value = USER_ID, required = false) Long userId,
                                        @RequestHeader(value = ROLE, required = false) String role,
                                        ViewReq req) {
        setHeaders(requestId, clientId);
        req.setLocale(locale);
        req.setUserId(userId);
        req.setRole(role);
        return ResponseBuilder.ok(service.getView(req));
    }

    @GetMapping(value = "link/{uuid}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<BufferedImage> link(@PathVariable("uuid") String uid) {
        return ResponseBuilder.ok(service.link(uid));
    }

    @PostMapping(value = "success-story", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> successStory(@RequestHeader(CLIENT_ID) String clientId,
                                             @RequestHeader(REQUEST_ID) String requestId,
                                             @CookieValue(AUTH_SESSION_ID) String sessionId,
                                             @RequestBody SuccessStoryReq req) {
        setHeaders(requestId, clientId);
        req.setSessionId(sessionId);
        service.successStory(req);
        return ResponseBuilder.ok(null);
    }

}
