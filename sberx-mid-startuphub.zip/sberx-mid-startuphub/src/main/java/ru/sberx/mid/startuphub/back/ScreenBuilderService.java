package ru.sberx.mid.startuphub.back;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Functions;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.convert.ApplicationConversionService;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.convert.ConversionService;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;
import org.webjars.NotFoundException;
import ru.sberx.configs.web.WebConfig;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.mid.startuphub.service.impl.method.ViewManager;
import ru.sberx.mid.startuphub.utils.Constants;
import ru.sberx.utils.util.CastUtils;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ru.sberx.constants.Constants.Header.ROLE;
import static ru.sberx.constants.Constants.Header.USER_ID;

@Service
@Slf4j
public class ScreenBuilderService {
    private final static ConversionService conversionService = ApplicationConversionService.getSharedInstance();
    private final static Set<String> applicationForms = Set.of("corp_app_Administrator", "invest_app_Administrator");
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd.MM.yyyy");
    private final WebClient webClient;
    private final String sysnameDelimiter;
    private final String getFormMethod;
    private final String getMenuMethod;
    private final String getButtonsMethod;
    private final GuideService guideService;
    private final UserAuthService userAuthService;
    private final Map<Integer, String> investorNames;
    private final QuestionnaireService questionnaireService;


    public ScreenBuilderService(WebClient webClient,
                                @Value("${application.sberx.screen.builder.uri}") String uri,
                                @Value("${application.sberx.screen.builder.form}") String getFormMethod,
                                @Value("${application.sberx.screen.builder.topbar}") String getMenuMethod,
                                @Value("${application.sberx.screen.builder.buttons}") String getButtonsMethod,
                                @Value("${application.sberx.screen.builder.sysname.delimiter}") String sysnameDelimiter,
                                GuideService guideService,
                                UserAuthService userAuthService,
                                QuestionnaireService questionnaireService) throws URISyntaxException {
        this.webClient = webClient;
        this.sysnameDelimiter = sysnameDelimiter;
        this.guideService = guideService;
        this.userAuthService = userAuthService;
        this.getFormMethod = new URI(uri + getFormMethod).normalize().toString();
        this.getMenuMethod = new URI(uri + getMenuMethod).normalize().toString();
        this.getButtonsMethod = new URI(uri + getButtonsMethod).normalize().toString();
        this.investorNames = GuideService.INVESTOR_NAMES;
        this.questionnaireService = questionnaireService;
    }

    public List<Form> getForms(Integer type, Integer action, String name, String locale) {
        WebConfig.logSending(getFormMethod, "type", type, "action", action, "name", name);
        List<Form> forms = webClient.get()
                .uri(getFormMethod, uriBuilder -> uriBuilder
                        .queryParam("type", type)
                        .queryParam("action", action)
                        .queryParam("name", name)
                        .build())
                .headers(WebConfig.setHeadersWithLocale(locale, null))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(new ParameterizedTypeReference<List<Form>>() {
                })
                .block();
        if (!CollectionUtils.isEmpty(forms)) {
            forms.forEach(i -> {
                if (!CollectionUtils.isEmpty(i.getModules())) {
                    i.getModules().forEach(m -> {
                        if (!CollectionUtils.isEmpty(m.getFields()))
                            m.setFields(m.getFields().stream().distinct().collect(Collectors.toList()));
                    });
                }
            });
        }
        WebConfig.logReceiving(getFormMethod, forms);
        return forms;
    }

    public List<ButtonRes.ButtonDto> getButtons(Integer type, String name, Long id, String uid, Long userId, String role) {
        WebConfig.logSending(getButtonsMethod, "type", type, "id", id, "name", name, "userId", userId);
        ButtonRes buttonRes = webClient.get()
                .uri(getButtonsMethod, uriBuilder -> uriBuilder
                        .queryParam("type", type)
                        .queryParam("id", id)
                        .queryParam("uid", uid)
                        .queryParam("name", name)
                        .build())
                .headers(customHeaders(userId, role))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(ButtonRes.class)
                .block();
        WebConfig.logReceiving(getButtonsMethod, buttonRes);
        if (buttonRes != null)
            return buttonRes.getButtons();
        return new ArrayList<>();
    }

    public static Consumer<HttpHeaders> customHeaders(Long userId, String role) {
        return (httpHeaders) -> {
            httpHeaders.set("requestId", ThreadContext.get("requestId"));
            httpHeaders.set("client-id", ThreadContext.get("client-id"));
            if (userId != null)
                httpHeaders.set(USER_ID, String.valueOf(userId));
            if (role != null)
                httpHeaders.set(ROLE, role);
        };
    }

    public List<Menu> getMenu(Integer userType, String name, String role) {
        WebConfig.logSending(getMenuMethod, "type", userType, "name", name, "role", role);
        List<Menu> menus = webClient.get()
                .uri(getMenuMethod, uriBuilder -> uriBuilder
                        .queryParam("type", userType)
                        .queryParam("name", name)
                        .build())
                .headers(customHeaders(null, role))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(new ParameterizedTypeReference<List<Menu>>() {
                })
                .block();
        WebConfig.logReceiving(getMenuMethod, menus);
        return menus;
    }

    @SuppressWarnings("unchecked")
    public void fillForms(
            List<Form> forms,
            Map<String, Object> data,
            Integer action,
            Boolean sber500,
            Boolean sber500firstTime,
            String locale,
            Boolean isException,
            String role,
            Integer type,
            String formName,
            Boolean isImport,
            String tariff) {
        for (ScreenBuilderService.Form form : forms) {
            if (!CollectionUtils.isEmpty(form.getModules())) {
                removeModulesIfNotContainSber500(form, sber500, sber500firstTime);
                for (ScreenBuilderService.Form.Module m : form.getModules()) {
                    log.trace("Filling module {}", m.getModule());

                    if (m.getModuleType() != null
                            && "question".equalsIgnoreCase(m.getModuleType())
                            && m.getFields() != null
                            && m.getFields().size() > 0) {
                        m.setModule("Вопросы корпорации");
                        m.setIsControlShow(false);
                        if (data.get("response") != null
                                && data.get("response") instanceof List) {
                            List<Map<String, Object>> responses = (List<Map<String, Object>>) data.get("response");
                            if (responses.size() > 0) {
                                Form.Module.Field fieldResponse = m.getFields().get(0);
                                List<Form.Module.Field> newFieldsResponse = new ArrayList<>();
                                int i = 1;
                                for (Map<String, Object> response : responses) {
                                    Form.Module.Field newField = new Form.Module.Field();
                                    String question = getStringValue(response.get("question"));
                                    String responseId = getStringValue(response.get("responseId"));

                                    newField.setFormat(fieldResponse.getFormat());
                                    newField.setExample("Ваш ответ");
                                    newField.setSysName(fieldResponse.getSysName() + "_responseNote");
                                    newField.setType(fieldResponse.getType());
                                    newField.setEdited(true);
                                    newField.setRequired(true);
                                    newField.setIndex(i);
                                    newField.setQuestion(question);
                                    newField.setResponseId(responseId);
                                    newField.setMaxLength("300");
                                    newFieldsResponse.add(newField);

                                    Form.Module.Field newField2 = new Form.Module.Field();
                                    newField2.setFormat("hide");
                                    newField2.setEdited(true);
                                    newField2.setRequired(false);
                                    newField2.setValue(question);
                                    newField2.setSysName(fieldResponse.getSysName() + "_question");
                                    newField2.setType(fieldResponse.getType());
                                    newField2.setIndex(i);
                                    newField2.setMaxLength("300");
                                    newFieldsResponse.add(newField2);

                                    Form.Module.Field newField3 = new Form.Module.Field();
                                    newField3.setFormat("hide");
                                    newField3.setEdited(true);
                                    newField3.setRequired(false);
                                    newField3.setValue(responseId);
                                    newField3.setSysName(fieldResponse.getSysName() + "_responseId");
                                    newField3.setType(fieldResponse.getType());
                                    newField3.setIndex(i);
                                    newFieldsResponse.add(newField3);
                                    i++;
                                }
                                m.setFields(newFieldsResponse);
                            } else {
                                m.setFields(null);
                            }
                        } else {
                            m.setFields(null);
                        }
                    } else if (formName != null
                            && formName.contains("metric")
                            && m.getFields() != null
                            && m.getFields().size() > 0
                            && !CollectionUtils.isEmpty(data)) {
                        if (formName.equalsIgnoreCase("add_metric_values")) {
                            String moduleNote = m.getModuleNote();
                            m.setModuleNote(moduleNote.replaceAll("%metricName%", getStringValue(data.get("name"))));
                        }
                        m.fields.forEach(f -> f.setMaxDate(f.getMaxDate() != null ? DATE_FORMAT.format(new Date()) : null));
                        List<Map<String, Object>> values = (List<Map<String, Object>>) data.get("values");
                        if (!CollectionUtils.isEmpty(values)) {
                            AtomicInteger i = new AtomicInteger();
                            List<Form.Module.Field> newFieldsList = new ArrayList<>();
                            values.forEach(map -> {
                                String metricType = getStringValue(data.get("metricType"));
                                String value = getStringValue(map.get("value"));
                                String date = getStringValue(map.get("date"));
                                int increment = i.getAndIncrement();
                                m.getFields().forEach(field -> {
                                    Form.Module.Field newField = new Form.Module.Field()
                                            .toBuilder()
                                            .localName(field.getLocalName())
                                            .required(field.getRequired())
                                            .type(field.getType())
                                            .example(field.getExample())
                                            .edited(field.getEdited())
                                            .format(field.getFormat())
                                            .sysName(field.getSysName())
                                            .direction(field.getDirection())
                                            .index(increment)
                                            .maxDate(field.maxDate)
                                            .dateError(field.dateError)
                                            .build();
                                    if (field.getSysName().contains("type")) {
                                        newField.setValue(metricType);
                                    } else if (field.getSysName().contains("value"))
                                        newField.setValue(value);
                                    else if (field.getSysName().contains("date"))
                                        newField.setValue(date);
                                    newFieldsList.add(newField);
                                });
                            });
                            m.setFields(newFieldsList);
                        }

                    } else if (m.getFields() != null) {
                        List<Form.Module.Field> newFields = m.getFields().stream().flatMap(f -> {
                            log.trace("Processing field: {}", f);
                            if (f.getSysName() == null && "banner".equals(f.getType()))
                                return Stream.of(f);
                            if (f.getTriggerField() != null
                                    && f.getTriggerValue() != null
                                    && action != null
                                    && action.equals(1)) {
                                Object triggerVal = getValue(f.getTriggerField(), data, m.getIsArray());
                                log.trace("TriggerValue - {}, got value - {}", triggerVal, f.getTriggerValue());
                                String stringTriggerValue = conversionService.convert(triggerVal, String.class);
                                if (!Objects.equals(stringTriggerValue, f.getTriggerValue())) {
                                    log.trace("Deleting field {}", f.getSysName());
                                    return Stream.of();
                                }
                            }
                            Object val = getValue(f.getSysName(), data, m.getIsArray());
                            if (f.getActivity() != null && !f.getActivity().isEmpty()) {
                                List<GuideService.Guide> guides = guideService.getGuideV2(null, null, f.getActivity(), null, locale, null);
                                if (!guides.isEmpty()) {
                                    f.setValues(guides.get(0).getValues());
                                }
                            }
                            if (form.getFormName().contains("metric") && "type".equalsIgnoreCase(f.getSysName())) {
                                f.setValues(questionnaireService.metricType()
                                        .stream()
                                        .sorted(Comparator.comparing(QuestionnaireService.MetricTypeDto::getType))
                                        .map(QuestionnaireService.MetricTypeDto::getVal)
                                        .collect(Collectors.toList()));
                            }

                            if (f.getSysName().contains("[]")) {
                                f.setSysName(f.getSysName().replace("[]", ""));
                            }
                            if (val != null) {
                                if (val instanceof List && Boolean.TRUE.equals(m.getIsArray())) {
                                    Form.Module.Field.FieldBuilder fieldBuilder = f.toBuilder();
                                    List<Form.Module.Field> vs = ((List<?>) val).stream().map(v -> {
                                        Pair<Integer, Object> valueAndIndex = (Pair<Integer, Object>) v;
                                        return fieldBuilder
                                                .index(valueAndIndex.getKey())
                                                .value(valueAndIndex.getValue())
                                                .build();
                                    }).collect(Collectors.toList());
                                    if (action != null && action.equals(1)) {
                                        for (Form.Module.Field ff : vs) {
                                            if (!Boolean.TRUE.equals(ff.getEdited())
                                                    && ff.getValues() != null
                                                    && ff.getSysName() != null
                                                    && ff.getValues().size() > 0
                                                    && (ff.getValue() instanceof List
                                                    || ff.getValue() instanceof Long
                                                    || ff.getValue() instanceof Integer
                                                    || (ff.getValue() instanceof String
                                                    && ((String) ff.getValue()).matches("[0-9]+")
                                                    && ((String) ff.getValue()).length() > 2))) {
                                                log.info("proccessing field in array {}", f);
                                                ff.setFormat("chip");
                                                if ("chip".equalsIgnoreCase(ff.getFormat()))
                                                    prepareValueForArray(ff, ff.getValue(), ff.getValues());
                                                else
                                                    prepareValueForArrayDropDown(ff, ff.getValue(), ff.getValues());
                                                if ("contacts_type".equals(ff.getSysName())
                                                        && (ff.getLocalName() == null || "".equals(ff.getLocalName())))
                                                    ff.setLocalName("Контакт");
                                            }
                                        }
                                        return vs.stream().filter(i -> (i.getValue() != null && !"".equals(i.getValue())));
                                    }
                                    return vs.stream();
                                } else {
                                    f.setValue(val);
                                }
                            }
                            if (!Boolean.TRUE.equals(f.getEdited())) {
                                if (f.getValue() == null && action != null && action.equals(2))
                                    f.setEdited(true);
                            }
                            if (!Boolean.TRUE.equals(f.getEdited())) {
                                if (f.getValues() != null
                                        && f.getValues().size() > 0
                                        && f.getValue() != null
                                        && (f.getValue() instanceof List
                                        || f.getValue() instanceof Long
                                        || f.getValue() instanceof Integer
                                        || (f.getValue() instanceof String
                                        && ((String) f.getValue()).matches("[0-9]+")
                                        && ((String) f.getValue()).length() > 2))) {
                                    f.setFormat("chip");
                                    if ("chip".equalsIgnoreCase(f.getFormat()))
                                        prepareValueForArray(f, f.getValue(), f.getValues());
                                    else
                                        prepareValueForArrayDropDown(f, f.getValue(), f.getValues());
                                }
                            } else {
                                if (f.getValue() instanceof List && !"tags".equalsIgnoreCase(f.getFormat())) {
                                    List<Long> valList = (List<Long>) f.getValue();
                                    f.setValue(valList.stream().map(Functions.toStringFunction()::apply).collect(Collectors.toList()));
                                }
                            }

                            if (f.getSysName().contains("project_mvpCode")
                                    && (form.getFormName().contains("edit") || form.getFormName().contains("New"))) {
                                log.info("processing project_mvpCode");
                                if (f.getValue() != null && f.getValue() instanceof List) {
                                    log.info("processing project_mvpCode - list");
                                    List<Object> mvpVals = (List<Object>) f.getValue();
                                    if (mvpVals.size() > 0) {
                                        log.info("processing project_mvpCode - new value {}", mvpVals.get(0));
                                        f.setValue(mvpVals.get(0));
                                    }
                                }
                            }

                            if ((f.getSysName().contains("logoFile")
                                    || (f.getAllowedTypes() != null && f.getAllowedTypes().size() > 0)
                                    || (f.getType() != null && f.getType().equalsIgnoreCase("hyperLink")))
                                    && f.getValue() != null
                                    && f.getValue() instanceof String) {
                                String logoVal = (String) f.getValue();
                                if (logoVal.contains("/sberx-gateway"))
                                    f.setValue(logoVal.replace("/sberx-gateway", ""));
                            }

                            if ("switch".equalsIgnoreCase(f.getFormat())) {
                                if ("import_create".equalsIgnoreCase(formName) && "questionnaire_isImport".equalsIgnoreCase(f.getSysName()))
                                    f.setValue(null);
                                else if ("questionnaire_isImport".equalsIgnoreCase(f.getSysName()) && isImport == null)
                                    f.setValue(null);
                                else {
                                    if (f.getValue() == null)
                                        f.setValue("false");
                                    else if (f.getValue() instanceof Boolean)
                                        f.setValue(Boolean.TRUE.equals(f.getValue()) ? "true" : "false");
                                }

                                f.setValues(new ArrayList<>());
                                GuideService.Values valTrue = new GuideService.Values();
                                valTrue.setName("ru".equalsIgnoreCase(locale) ? "Да" : "Yes");
                                valTrue.setCode("true");
                                f.getValues().add(valTrue);

                                GuideService.Values valFalse = new GuideService.Values();
                                valFalse.setName("ru".equalsIgnoreCase(locale) ? "Нет" : "No");
                                valFalse.setCode("false");
                                f.getValues().add(valFalse);
                            }

                            if (!Boolean.TRUE.equals(f.getEdited())
                                    && "date".equalsIgnoreCase(f.getType())
                                    && action != null
                                    && action.equals(1)
                                    && (f.getSysName().toLowerCase().contains("modified")
                                    || f.getSysName().toLowerCase().contains("created"))
                                    && f.getValue() != null) {
                                f.setValue(dateToStr(f.getValue()));
                                f.setType("string");
                            }

                            if (f.getType() != null
                                    && f.getType().equals("hyperlink")
                                    && f.getValue() != null
                                    && f.getValue() instanceof String
                                    && f.getSysName() != null
                                    && f.getSysName().toUpperCase().contains("SITE")) {
                                String site = (String) f.getValue();
                                if (!site.startsWith("http"))
                                    f.setValue("https://" + site);
                            }

                            if (f.getSysName() != null
                                    && f.getSysName().toLowerCase().contains("suminvestment")
                                    && f.getValue() != null
                                    && f.getValue() instanceof String) {
                                String si = ((String) f.getValue()).replace(",", "").replace(" ", "");
                                String regex = "\\d+";
                                if (si.matches(regex))
                                    f.setValue(Long.valueOf(si));
                                else
                                    f.setValue(si);
                            }

                            if (f.getSysName() != null
                                    && data != null
                                    && data.get("investment") != null
                                    && Boolean.TRUE.equals(data.get("investment"))
                                    && f.getSysName().equals("otherDescription")
                                    && data.get("otherDescription") != null
                                    && data.get("otherPercent") != null) {
                                f.setLocalName(getStringValue(data.get("otherDescription")));
                                f.setValue(getStringValue(data.get("otherPercent")));
                                f.setMask("%");
                            }

                            if ((form.getType().equals(0) || form.getType().equals(1) || form.getType().equals(2))
                                    && data != null
                                    && f.getSysName() != null
                                    && f.getSysName().equals("session_date")
                                    && data.get("users") != null) {
                                List<Map<String, Object>> users = (List<Map<String, Object>>) data.get("users");
                                if (!CollectionUtils.isEmpty(users)) {
                                    Long userId = CastUtils.castToLong(users.get(0).get("userId"));
                                    if (userId != null) {
                                        try {
                                            UserAuthService.LastSessionDto lastSessionDto = userAuthService.getLastSession(userId);
                                            f.setValue(dateToStr(lastSessionDto.getLastSession()));
                                        } catch (Exception e) {
                                            log.error("Error getting last session: ", e);
                                        }
                                    }
                                }
                            }

                            if (!form.getFormName().contains("_Extra")
                                    && f.getSysName() != null
                                    && !"".equals(f.getSysName())
                                    && !"hide".equalsIgnoreCase(f.getFormat())
                                    && action != null
                                    && action.equals(1)) {
                                if (f.getValue() instanceof List) {
                                    List<?> valList = (List<?>) f.getValue();
                                    if (valList == null || valList.size() == 0)
                                        return null;
                                } else if (f.getValue() == null || "".equals(f.getValue()))
                                    return null;
                            }

                            if (action != null
                                    && action.equals(1)
                                    && f.getSysName() != null
                                    && f.getSysName().equalsIgnoreCase("questionnaire_registrationCountry")
                                    && f.getFormat() != null
                                    && "chip".equals(f.getFormat())) {
                                f.setType(null);
                            }
                            if (Boolean.TRUE.equals(f.getIsBlur()))
                                f.setValue("");
                            if (f.getQuestionaryGuid() != null) {
                                QuestionnaireService.QuestionnaireGuidList questionnaireGuidList =
                                        questionnaireService.getQuestionnaireGuidList(f.getQuestionaryGuid());
                                f.setUIDvalues(questionnaireGuidList);
                                f.setSysName(f.getSysName() == null ? f.getStringSysName() : f.getSysName());
                            }
                            if (f.getSysName().equals("questionnaire_name")
                                    && Integer.valueOf(1).equals(action)
                                    && !StringUtils.hasText(getStringValue(f.getValue()))) {
                                if (Constants.BUSINESS_ANGEL_CODE.equals(getValue("questionnaire_investorType", data, null))) {
                                    return Stream.empty();
                                }
                            }
                            if (Integer.valueOf(3).equals(type) && f.getClickAction() != null && !ViewManager.ADMIN_ROLE.contains(role)) {
                                Long vasId = (Long) getValue("service_vasId", data, false);
                                f.setClickAction(UriComponentsBuilder.fromUriString("/add-activity")
                                        .queryParam("id", vasId)
                                        .queryParam("objectType", "service")
                                        .queryParam("activity", "clickLink")
                                        .build().toString());
                            }
                            if (f.getMaxDate() != null)
                                f.setMaxDate(DATE_FORMAT.format(new Date()));
                            if (StringUtils.hasText(tariff) && "tariff".equalsIgnoreCase(f.getSysName()))
                                f.setValue(tariff);
                            return Stream.of(f);
                        }).peek(f -> {
                            if (f.getSysName() == null && "banner".equals(f.getType()))
                                return;
                            if (f.getLocalName() != null
                                    && (f.getLocalName().contains("termsURL")
                                    || f.getLocalName().contains("policyURL")
                                    || f.getLocalName().contains("sber500PrivacyPolicyURL")
                                    || f.getLocalName().contains("sber500ConsentURL")
                                    || f.getLocalName().contains("sber500TermOfUseURL")
                                    || f.getLocalName().contains("sber500PersonalDataConsentURL")
                                    || f.getLocalName().contains("mailingConsentURL"))) {
                                String localName = f.getLocalName();
                                UserAuthService.Urls us = userAuthService.getUrls(
                                        localName.contains("termsURL"),
                                        localName.contains("policyURL"),
                                        localName.contains("sber500PrivacyPolicyURL"),
                                        localName.contains("sber500ConsentURL"),
                                        localName.contains("sber500TermOfUseURL"),
                                        localName.contains("sber500PersonalDataConsentURL"),
                                        localName.contains("mailingConsentURL"));
                                f.setLocalName(localName.replace("termsURL", us.getTermsURL())
                                        .replace("policyURL", us.getPolicyURL())
                                        .replace("policyURL", us.getPolicyURL())
                                        .replace("sber500PrivacyPolicyURL", us.getSber500PrivacyPolicyURL())
                                        .replace("sber500ConsentURL", us.getSber500ConsentURL())
                                        .replace("sber500TermOfUseURL", us.getSber500TermOfUseURL())
                                        .replace("sber500PersonalDataConsentURL", us.getSber500PersonaDataConsentURL())
                                        .replace("mailingConsentURL", us.getMailingConsentURL()));
                                if (Boolean.TRUE.equals(sber500)) {
                                    f.setValue(true);
                                    f.setEdited(false);
                                    f.setRequired(false);
                                    f.setTriggerField(null);
                                    f.setTriggerValue(null);
                                }
                            } else if (f.getSysName().equalsIgnoreCase("questionnaire_sber500") && Boolean.TRUE.equals(sber500)) {
                                f.setValue("true");
                                f.setEdited(false);
                                f.setRequired(false);
                            } else if (f.getTriggerField() != null
                                    && f.getTriggerField().equalsIgnoreCase("questionnaire_sber500")
                                    && Boolean.TRUE.equals(sber500)) {
                                f.setTriggerField(null);
                                f.setTriggerValue(null);
                            } else if (f.getValue() != null && " ".equals(CastUtils.castToString(f.getValue()))) {
                                f.setValue("");
                            }
                            if (f.getFormat() != null
                                    && f.getFormat().equalsIgnoreCase("search_dropdown")
                                    && f.getValue() == null) {
                                if (Boolean.TRUE.equals(f.getMultySelect()))
                                    f.setValue(new ArrayList<>());
                                else
                                    f.setValue("");
                            }
                            if (f.getValue() != null && f.getValue() instanceof String) {
                                String strVal = (String) f.getValue();
                                if (strVal.contains("$")) {
                                    strVal = strVal.replaceAll(" ", "").replace("$", "");
                                    if (strVal.matches("[0-9]+"))
                                        f.setValue(strVal);
                                }
                            }

                            if (action != null && !action.equals(1) && f.getSysName() != null
                                    && (f.getSysName().toLowerCase().contains("_site")
                                    || f.getSysName().equalsIgnoreCase("contacts_name")
                                    || f.getSysName().equalsIgnoreCase("project_demoVideo")
                                    || f.getSysName().equalsIgnoreCase("representative_facebook"))) {
                                f.setFormat("site");
                            }
//Откатываю для фронта
//                            if (action != null
//                                    && action.equals(2)
//                                    && StringUtils.hasText(f.getSysName())
//                                    && StringUtils.hasText(f.getFormat())
//                                    && StringUtils.hasText(f.getType())
//                                    && f.getSysName().equalsIgnoreCase("contacts_name")
//                                    && f.getType().equalsIgnoreCase("string")
//                                    && f.getFormat().equalsIgnoreCase("site")) {
//                                f.setIndex(1);
//                            }

                            if (Boolean.TRUE.equals(isException)
                                    && !CollectionUtils.isEmpty(f.getExceptionList())
                                    && f.getExceptionList().contains("4182")) {
                                f.setTriggerValue(null);
                                f.setTriggerField(null);
                            }
                            if (data != null && data.get("currency") != null
                                    && ("edit_metrics".equalsIgnoreCase(formName) || "add_metric_values".equalsIgnoreCase(formName))
                                    && f.getSysName().equalsIgnoreCase("items_value")) {
                                String curr = getStringValue(data.get("currency"));
                                if (StringUtils.hasText(curr)) {
                                    if (curr.equals("41001")) {
                                        f.setMask("$");
                                    } else if (curr.equals("41002")) {
                                        f.setMask("rub");
                                    }
                                }
                            }

                        }).collect(Collectors.toList());
                        if (Boolean.TRUE.equals(m.getIsArray())) {
                            newFields.sort((f1, f2) -> {
                                if (f1.index != null && f2.index != null) {
                                    return Integer.compare(f1.index, f2.index);
                                } else if (f1.index == null && f2.index == null) {
                                    return 0;
                                }
                                return f1.index != null ? f1.index : f2.index;
                            });
                        }
                        m.setFields(newFields);
                    }
                    if (applicationForms.contains(form.formName) && !ObjectUtils.isEmpty(m.pageName)) {
                        String[] parts = m.pageName.split("\\+");
                        StringBuilder builder = new StringBuilder();
                        for (String s : parts) {
                            Object o = getValue(s, data, null);
                            if ("investorType".equals(s)) {
                                o = investorNames.get((Integer) o);
                            } else {
                                o = conversionService.convert(o, String.class);
                            }
                            builder.append(o).append(" ");
                        }
                        m.pageName = builder.toString().stripTrailing();
                    }
                }

                for (Form.Module m : form.getModules()) {
                    if (Boolean.TRUE.equals(m.getIsArray())
                            && !CollectionUtils.isEmpty(m.getFields())
                            && m.getFields()
                            .stream()
                            .anyMatch(i -> i.getSysName().equalsIgnoreCase("UIDquestionnaire_name")
                                    || i.getSysName().equalsIgnoreCase("UIDquestionnaire_logoFile"))) {
                        m.getFields().forEach(i -> {
                            if (i.getIndex() != null && (i.getSysName().equalsIgnoreCase("UIDquestionnaire_name")
                                    || i.getSysName().equalsIgnoreCase("UIDquestionnaire_logoFile"))) {
                                i.setValue(getQuestionnaireField(i.getSysName(), i.getTriggerField(), i.getIndex(), m.getFields()));
                            }
                        });
                    }
                }
                if (type != null && (type.equals(0) || type.equals(1) || type.equals(2)))
                    fillComments(form.getModules(), role, form.getType(), locale, data);
            }
        }
    }

    public void fillCommentModule(ScreenBuilderService.Form.Module commentModule,
                                  List<QuestionnaireService.CommentDTO> comments,
                                  DescriptionType descriptionType,
                                  String locale) {
        if (commentModule == null || descriptionType == null) {
            throw new SberxException(SberxErrors.INTERNAL_ERROR);
        }
        if (locale == null) {
            locale = "ru";
        }
        commentModule.setModule("ru".equals(locale) ? "Мои заметки" : "My notes");
        if (descriptionType.equals(DescriptionType.STARTUP_DESCRIPTION)) {
            commentModule.setModuleNote("ru".equals(locale) ? "Стартап не увидит данные заметки, они только для вас" : "The startup will not see these notes, they are only for you");
        }
        if (descriptionType.equals(DescriptionType.USER_DESCRIPTION)) {
            commentModule.setModuleNote("ru".equals(locale) ? "Пользователь не увидит данные заметки, они только для вас" : "The user will not see these notes, they are only for you");
        }
        commentModule.setModuleFormat("comment");
        commentModule.setPage(1);
        commentModule.setPageName("");
        commentModule.setIsArray(true);
        if (CollectionUtils.isEmpty(comments)) {
            ScreenBuilderService.Form.Module.Field field = new ScreenBuilderService.Form.Module.Field();
            field.setDescription("ru".equals(locale) ? "Пока вы ничего не написали" : "You haven't written anything yet");
            commentModule.setFields(List.of(field));
        } else {
            commentModule.setFields(comments.stream().map(i -> {
                ScreenBuilderService.Form.Module.OrderedField field = new ScreenBuilderService.Form.Module.OrderedField();
                field.setCommentId(i.getCommentId());
                field.setValue(i.getComment());
                field.setIsEdited(i.getEdited());
                field.setCreated(i.getDate());
                field.setType("string");
                field.setAuthor(i.getLogin());
                return field;
            }).collect(Collectors.toList()));
        }
    }

    private void fillComments(List<Form.Module> modules, String role, Integer type, String locale, Map<String, Object> data) {
        QuestionnaireService.CommentGetRes comments;
        ScreenBuilderService.Form.Module commentModule = new ScreenBuilderService.Form.Module();
        if (data != null && StringUtils.hasText(role) &&
                (role.equals("Administrator") || role.equals("SberbankEmployee"))) {
            if (type != null &&
                    (type.equals(0) || type.equals(1) || type.equals(2))) {
                Object questionnaireId = data.get("questionnaireId");
                if (questionnaireId instanceof Long) {
                    comments = questionnaireService.getComments(role, (Long) questionnaireId, "Questionary");
                    fillCommentModule(commentModule,
                            comments != null ? comments.getComments() : null,
                            DescriptionType.USER_DESCRIPTION,
                            locale);
                    modules.add(commentModule);
                }
            }
        }

    }

    private void removeModulesIfNotContainSber500(Form form, Boolean sber500, Boolean sber500firstTime) {
        form.getModules().removeIf(module -> !Boolean.TRUE.equals(sber500)
                && !Boolean.TRUE.equals(sber500firstTime)
                && module.getPageName() != null && module.getPageName().equals("Sber500"));
    }

    public String getQuestionnaireField(String sysName, String triggerField, Integer index, List<Form.Module.Field> fields) {
        try {
            String value = null;
            for (Form.Module.Field f : fields) {
                if (triggerField.equalsIgnoreCase(f.getSysName())
                        && index.equals(f.getIndex())
                        && f.getValue() != null) {
                    String qId = (String) f.getValue();
                    QuestionnaireService.Questionnaire q = null;
                    if (f.getSysName().toLowerCase().contains("questionnaireid")) {
                        q = questionnaireService.getQuestionnaire(Long.parseLong(qId));
                    } else if (f.getSysName().toLowerCase().contains("uuid")) {
                        q = questionnaireService.getQuestionnaireByUuid(qId, null);
                    }
                    if (q != null && q.getQuestionnaire() != null) {
                        if (sysName.contains("logo"))
                            value = ru.sberx.utils.util.StringUtils.getLogo(q.getQuestionnaire().getLogoFile());
                        else
                            value = q.getQuestionnaire().getName();
                    }
                    break;
                }
            }
            return value;
        } catch (Exception e) {
            log.error("Error getting UIDquestionnaire field: ", e);
            return null;
        }
    }

    private String getStringValue(Object o) {
        if (o == null)
            return null;
        if (o instanceof String)
            return (String) o;
        if (o instanceof Long) {
            Long val = (Long) o;
            return Long.toString(val);
        }
        if (o instanceof Integer) {
            Integer val = (Integer) o;
            return Integer.toString(val);
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private void prepareValueForArrayDropDown(Form.Module.Field f, Object value, List<GuideService.Values> values) {
        StringBuilder sb = new StringBuilder();
        if (value instanceof List) {
            List<Long> vals = (List<Long>) value;
            for (Long val : vals) {
                String strVal = String.valueOf(val);
                for (GuideService.Values item : values) {
                    if (item.getCode() != null
                            && item.getName() != null
                            && strVal.equals(item.getCode())) {
                        sb.append(item.getName()).append("; ");
                        break;
                    }
                }
            }
        } else if (value instanceof Long || value instanceof Integer) {
            Long vall = getLong(value);
            String str = String.valueOf(vall);
            for (GuideService.Values item : values) {
                if (item.getCode() != null
                        && item.getName() != null
                        && str.equals(item.getCode())) {
                    sb.append(item.getName());
                    break;
                }
            }
        } else if (value instanceof String
                && ((String) value).matches("[0-9]+")
                && ((String) value).length() > 2) {
            String strString = (String) value;
            for (GuideService.Values item : values) {
                if (item.getCode() != null
                        && item.getName() != null
                        && strString.equals(item.getCode())) {
                    sb.append(item.getName());
                    break;
                }
            }
        }
        String s = sb.toString();
        if (s.endsWith("; "))
            s = s.substring(0, s.length() - 2);
        f.setValue(s);
        f.setType("string");
    }

    @SuppressWarnings("unchecked")
    private void prepareValueForArray(Form.Module.Field f, Object value, List<GuideService.Values> values) {
        List<String> l = new ArrayList<>();
        if (value instanceof List) {
            List<Long> vals = (List<Long>) value;
            for (Long val : vals) {
                String strVal = String.valueOf(val);
                for (GuideService.Values item : values) {
                    if (item.getCode() != null
                            && item.getName() != null
                            && strVal.equals(item.getCode())) {
                        l.add(item.getName());
                        break;
                    }
                }
            }
        } else if (value instanceof Long || value instanceof Integer) {
            Long vall = getLong(value);
            String str = String.valueOf(vall);
            for (GuideService.Values item : values) {
                if (item.getCode() != null
                        && item.getName() != null
                        && str.equals(item.getCode())) {
                    l.add(item.getName());
                    break;
                }
            }
        } else if (value instanceof String
                && ((String) value).matches("[0-9]+")
                && ((String) value).length() > 2) {
            String strString = (String) value;
            for (GuideService.Values item : values) {
                if (item.getCode() != null
                        && item.getName() != null
                        && strString.equals(item.getCode())) {
                    l.add(item.getName());
                    break;
                }
            }
        }
        if (l.size() > 0)
            f.setValue(l);
        else
            f.setValue(null);
    }

    private Long getLong(Object value) {
        if (value == null)
            return null;
        if (value instanceof Long)
            return (Long) value;
        if (value instanceof Integer)
            return ((Integer) value).longValue();
        if (value instanceof String)
            return Long.valueOf((String) value);
        return null;
    }

    @SuppressWarnings("unchecked")
    private Object getValue(String sysname, Map<String, Object> data, Boolean isArray) {
        log.trace("Getting value for {}. IsArray - {}", sysname, isArray);
        if (data != null) {
            String[] path = sysname.split(sysnameDelimiter);
            Map<String, Object> currentLevel = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            currentLevel.putAll(data);
            Object res = null;
            try {
                if (Boolean.TRUE.equals(isArray)) {
                    int i = 0;
                    while (!path[i].endsWith("[]")) {
                        go(currentLevel, path[i]);
                        i++;
                    }
                    List<?> list = (List<?>) currentLevel.get(path[i].substring(0, path[i].length() - 2));
                    i++;
                    res = new ArrayList<Pair<Integer, Object>>();
                    if (list != null) {
                        for (int j = 0; j < list.size(); j++) {
                            currentLevel.clear();
                            currentLevel.putAll((Map<String, Object>) list.get(j));
                            for (int k = i; k < path.length - 1; k++) {
                                go(currentLevel, path[k]);
                            }
                            ((List) res).add(Pair.of(j + 1, currentLevel.get(path[path.length - 1])));
                        }
                    } else {
                        ((List) res).add(Pair.of(null, currentLevel.get(path[path.length - 1])));
                    }
                } else {
                    for (int i = 0; i < path.length - 1; i++) {
                        go(currentLevel, path[i]);
                    }
                    res = currentLevel.get(path[path.length - 1]);
                }
                return res;
            } catch (NotFoundException e) {
                return null;
            } catch (Exception e) {
                log.error("Error while getting value {}", sysname, e);
                return null;
            } finally {
                log.trace("Got value: {}", res);
            }
        }
        return null;
    }

    private Object dateToStr(Object value) {
        try {
            if (value instanceof Date) {
                Date dt = (Date) value;
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+3"));
                return dateFormat.format(dt);
            } else if (value instanceof String) {
                return ((String) value).replace("T", " ");
            } else {
                return value;
            }
        } catch (Exception e) {
            log.error("error converting date to str", e);
            return value;
        }
    }

    @SuppressWarnings("unchecked")
    private void go(Map<String, Object> currentLevel, String path) {
        Object o = currentLevel.get(path);
        currentLevel.clear();
        if (o instanceof Map) {
            currentLevel.putAll((Map<String, Object>) o);
        } else {
            throw new NotFoundException("Value not found");
        }
    }


    //заполняем форму старыми данными
    public void fillFormsOld(List<Form> forms, QuestionnaireService.Questionnaire data) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        for (ScreenBuilderService.Form form : forms) {
            for (ScreenBuilderService.Form.Module m : form.getModules()) {
                log.trace("Filling module {}", m.getModule());
                if (m.getFields() != null) {
                    for (Form.Module.Field f : m.getFields()) {
                        if (f.getSysName() != null) {
                            if (f.getSysName().toLowerCase().startsWith("questionnaire_") && data.getQuestionnaire() != null) {
                                prepareFieldOldValue(f, data.getQuestionnaire(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("project_") && data.getProject() != null) {
                                prepareFieldOldValue(f, data.getProject(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("investment_") && data.getInvestment() != null) {
                                prepareFieldOldValue(f, data.getInvestment(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("userquestionnaire_") && data.getUserQuestionnaire() != null) {
                                prepareFieldOldValue(f, data.getUserQuestionnaire(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("representative_") && data.getRepresentative() != null) {
                                prepareFieldOldValue(f, data.getRepresentative(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("pilot_") && data.getPilot() != null) {
                                prepareFieldOldValue(f, data.getPilot(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("ecopilot_") && data.getEcoPilot() != null) {
                                prepareFieldOldValue(f, data.getEcoPilot(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("workers_") && data.getWorkers() != null && data.getWorkers().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getWorkers(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("investorclubs_") && data.getInvestorClubs() != null && data.getInvestorClubs().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getInvestorClubs(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("pilots_") && data.getPilots() != null && data.getPilots().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getPilots(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("representatives_") && data.getRepresentatives() != null && data.getRepresentatives().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getRepresentatives(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("contacts_") && data.getContacts() != null && data.getContacts().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getContacts(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("feedbacks_") && data.getFeedbacks() != null && data.getFeedbacks().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getFeedbacks(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("users_") && data.getUsers() != null && data.getUsers().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getUsers(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("founders_") && data.getFounders() != null && data.getFounders().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getFounders(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("communityusers_") && data.getCommunityUsers() != null && data.getCommunityUsers().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getCommunityUsers(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("successpilots") && data.getSuccessPilots() != null && data.getSuccessPilots().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getSuccessPilots(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("questionnairepilots") && data.getQuestionnairePilots() != null && data.getQuestionnairePilots().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getQuestionnairePilots(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("b2cpilots") && data.getB2cPilots() != null && data.getB2cPilots().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getB2cPilots(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("b2bpilots") && data.getB2bPilots() != null && data.getB2bPilots().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getB2bPilots(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("ecopilots") && data.getEcoPilots() != null && data.getEcoPilots().size() > 0) {
                                prepareFieldOldValueForArray(f, data.getEcoPilots(), mapper);
                            } else if (f.getSysName().toLowerCase().startsWith("sberfivehundred_") && data.getSberFiveHundred() != null) {
                                prepareFieldOldValue(f, data.getSberFiveHundred(), mapper);
                            }
                        }
                    }
                }
            }
        }
    }

    public Form.Module getMetricModule(String locale, Long userId, String uuid){
        List<GuideService.Values> values = new ArrayList<>();
        List<QuestionnaireService.MetricTypeDto> metrics = questionnaireService.metricList(userId, false, uuid);
        if (!CollectionUtils.isEmpty(metrics)){
            for(QuestionnaireService.MetricTypeDto m : metrics){
                GuideService.Values v = new GuideService.Values();
                v.setName(m.getShortName());
                if (m.getType() != null)
                    v.setCode(m.getType().toString());
                values.add(v);
            }
        }
        if (CollectionUtils.isEmpty(values))
            return null;
        Form.Module module = new Form.Module();
        module.setModule(!"ru".equals(locale) ? "Metrics" : "Метрики");
        module.setFields(new ArrayList<>());
        module.getFields().add(new Form.Module.Field("metrics", values));
        module.setPage(1);
        module.setPageName(!"ru".equals(locale) ? "Metrics" : "Метрики");
        module.setModuleFormat("metrics");
        return module;
    }

    @SuppressWarnings("unchecked")
    private void prepareFieldOldValueForArray(Form.Module.Field f, Object data, ObjectMapper mapper) {
        if (data instanceof List) {
            List<Object> list = (List<Object>) data;
            int i = 1;
            for (Object o : list) {
                Map<String, Object> map = mapper.convertValue(o, new TypeReference<>() {
                });
                if (f.getSysName() != null
                        && f.getIndex() != null
                        && f.getIndex().equals(i)) {
                    String[] s = f.getSysName().split("_");
                    if (s.length > 0
                            && map.get(s[1]) != null
                            && f.getSysName() != null
                            && f.getValue() != null) {
                        Object val = null;
                        f.setFormat("hide".equalsIgnoreCase(f.getFormat()) ? f.getFormat() : "chip");
                        if ("chip".equalsIgnoreCase(f.getFormat()) || "hide".equalsIgnoreCase(f.getFormat())) {
                            val = prepareOldValueForArray(f, map.get(s[1]));
                        } else {
                            val = prepareOldValueForArrayDropDown(f, map.get(s[1]));
                        }
                        if (val != null && !val.equals(f.getValue())) {
                            if (!val.equals(""))
                                f.setOldValue(val);
                            else
                                f.setOldValue("не заполнено");
                        }
                    }
                } else {
                    f.setOldValue("не заполнено");
                }
                i++;
            }
        }
    }

    private void prepareFieldOldValue(Form.Module.Field f, Object o, ObjectMapper mapper) {
        Map<String, Object> v = mapper.convertValue(o, new TypeReference<>() {
        });
        String[] s = f.getSysName().split("_");
        if (s.length > 0) {
            if (v.get(s[1]) != null
                    && f.getSysName() != null
                    && f.getValue() != null) {
                Object val = null;
                f.setFormat("chip");
                if (f.getFormat() != null && "chip".equalsIgnoreCase(f.getFormat())) {
                    val = prepareOldValueForArray(f, v.get(s[1]));
                } else {
                    val = prepareOldValueForArrayDropDown(f, v.get(s[1]));
                }
                if (v.get(s[1]) != null && v.get(s[1]) instanceof String) {
                    String strVal = (String) v.get(s[1]);
                    if (strVal.contains("$")) {
                        strVal = strVal.replaceAll(" ", "").replace("$", "");
                        if (strVal.matches("[0-9]+"))
                            val = strVal;
                    }
                }
                if (val != null && !val.equals(f.getValue())) {
                    if (!val.equals(""))
                        f.setOldValue(val);
                    else
                        f.setOldValue("не заполнено");
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    private Object prepareOldValueForArray(Form.Module.Field f, Object value) {
        Object retVal = value;
        if (f.getValues() != null && f.getValues().size() > 0) {
            List<String> l = new ArrayList<>();
            if (value instanceof List) {
                List<Long> vals = (List<Long>) value;
                for (Long val : vals) {
                    String strVal = String.valueOf(val);
                    for (GuideService.Values item : f.getValues()) {
                        if (item.getCode() != null
                                && item.getName() != null
                                && strVal.equals(item.getCode())) {
                            l.add(item.getName());
                            break;
                        }
                    }
                }
            } else if (value instanceof Long || value instanceof Integer) {
                Long vall = getLong(value);
                String str = String.valueOf(vall);
                for (GuideService.Values item : f.getValues()) {
                    if (item.getCode() != null
                            && item.getName() != null
                            && str.equals(item.getCode())) {
                        l.add(item.getName());
                        break;
                    }
                }
            } else if (value instanceof String
                    && ((String) value).matches("[0-9]+")
                    && ((String) value).length() > 2) {
                String strString = (String) value;
                for (GuideService.Values item : f.getValues()) {
                    if (item.getCode() != null
                            && item.getName() != null
                            && strString.equals(item.getCode())) {
                        l.add(item.getName());
                        break;
                    }
                }
            }
            if (l.size() > 0)
                retVal = l;
        }
        if (f.getType() != null && f.getType().equals("boolean"))
            retVal = Boolean.TRUE.equals(retVal) ? "true" : "false";
        return retVal;
    }

    @SuppressWarnings("unchecked")
    private Object prepareOldValueForArrayDropDown(Form.Module.Field f, Object value) {
        if (f.getValues() != null && f.getValues().size() > 0) {
            StringBuilder sb = new StringBuilder();
            if (value instanceof List) {
                List<Long> vals = (List<Long>) value;
                for (Long val : vals) {
                    String strVal = String.valueOf(val);
                    for (GuideService.Values item : f.getValues()) {
                        if (item.getCode() != null
                                && item.getName() != null
                                && strVal.equals(item.getCode())) {
                            sb.append(item.getName()).append("; ");
                            break;
                        }
                    }
                }
            } else if (value instanceof Long || value instanceof Integer) {
                Long vall = getLong(value);
                String str = String.valueOf(vall);
                for (GuideService.Values item : f.getValues()) {
                    if (item.getCode() != null
                            && item.getName() != null
                            && str.equals(item.getCode())) {
                        sb.append(item.getName());
                        break;
                    }
                }
            } else if (value instanceof String
                    && ((String) value).matches("[0-9]+")
                    && ((String) value).length() > 2) {
                String strString = (String) value;
                for (GuideService.Values item : f.getValues()) {
                    if (item.getCode() != null
                            && item.getName() != null
                            && strString.equals(item.getCode())) {
                        sb.append(item.getName());
                        break;
                    }
                }
            }
            String s = sb.toString();
            if (s.endsWith("; "))
                s = s.substring(0, s.length() - 2);
            return s;
        }
        if (f.getType() != null && f.getType().equals("boolean"))
            value = Boolean.TRUE.equals(value) ? "true" : "false";
        return value;
    }

    public enum DescriptionType {
        STARTUP_DESCRIPTION,
        USER_DESCRIPTION
    }

    //заполняем форму старыми данными
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ButtonRes {

        private List<ButtonDto> buttons;

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class ButtonDto {
            private Integer code;
            private String text;
            private String clickAction;
            private String clickMethod;
            private Boolean isDisabled;
            private Long id;
            private String uid;
            private Integer group;
        }
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SchemaValue {
        private Map<String, Object> value;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Menu {
        private Long id;
        private String name;
        private String sysname;
        private String action;
        private String method;
        private String logoFile;
        private Boolean isDefault;
        private String lock;
        private Integer replyCount;

        public static Menu getExitButton() {
            Menu menu = new Menu();
            menu.setName("Выйти");
            menu.setAction("/logout");
            menu.setMethod("DELETE");
            menu.setSysname("exit");
            menu.setLogoFile("/file/768847");
            return menu;
        }
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Form {

        private Integer type;
        private String formName;
        private String name;
        private String description;
        private Integer pages;
        @JsonProperty("form")
        private List<Module> modules;
        private Verify verify;
        private List<Map<String, Object>> buttons;
        private String logoFile;
        private String offerDescription;
        private String secondOfferDescription;
        private String info;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Verify {
            private Long confirm;
            private Long processing;
            private Long canceled;

        }

        @Data
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Module {
            private String module;
            private String moduleNote;
            private String moduleFormat;
            private String moduleType;
            private Integer page;
            private String triggerField;
            private String triggerValue;
            private String pageName;
            private Boolean isArray;
            private List<Field> fields;
            private Integer type;
            private String actionText;
            private Boolean isControlShow;
            private String subTitle;
            private Boolean withIndex;
            private String title;
            private String information;
            private String viewFormat;

            @Data
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Builder(toBuilder = true)
            @NoArgsConstructor
            @AllArgsConstructor
            public static class Field {
                private String sysName;
                private Integer questionaryGuid;
                private String stringSysName;
                private Integer index;
                private String localName;
                private String description;
                private String type;
                private Object value;
                private String format;
                private String mask;
                private String regExp;
                private List<GuideService.Values> values;
                private Boolean edited;
                private Boolean required;
                private List<String> valueList;
                private File file;
                private List<Long> activity;
                private String direction;
                private String maxLength;
                private List<String> allowedTypes;
                private Boolean multySelect;
                private List<String> concatination;
                private String triggerField;
                private String triggerValue;
                private Boolean isBlur;
                private Boolean showLength;
                private String note;
                private String placeholder;
                private String title;
                private String logoFile;
                private String regExpError;
                private Integer minValue;
                private Integer maxValue;
                private String question;
                private String responseId;
                private String questionDescription;
                private String fileName;
                private Float fileSize;
                private Object oldValue;
                private String example;
                private String rows;
                private List<Map<String, Object>> items;
                private String information;
                private Boolean multiLanguage;
                private Long commentId;
                private Boolean isEdited;
                private Date created;
                private QuestionnaireService.QuestionnaireGuidList UIDvalues;
                private String minLength;
                private List<String> exceptionList;
                private List<Map<String, Object>> valueGroups;
                private String dadataService;
                private String dadataStart;
                private String clickAction;
                private String author;
                private String viewFormat;
                private String maxDate;
                private String dateError;

                public Field(String sysName, List<GuideService.Values> values) {
                    this.sysName = sysName;
                    this.values = values;
                    this.type = "array";
                    this.format = "metric";
                    this.edited = false;
                    this.required = false;
                }
            }

            @EqualsAndHashCode(callSuper = true)
            @Data
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @JsonPropertyOrder({"commentId", "value", "isEdited", "created", "type"})
            public static class OrderedField extends Field {
                public OrderedField() {
                    super();
                }
            }
        }
    }

}
