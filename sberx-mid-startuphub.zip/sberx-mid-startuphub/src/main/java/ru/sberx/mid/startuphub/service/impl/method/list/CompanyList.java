package ru.sberx.mid.startuphub.service.impl.method.list;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.dto.services.company.res.GetCompanyListRes;
import ru.sberx.mid.startuphub.back.VasService;
import ru.sberx.mid.startuphub.controller.dto.req.ListReq;

import java.util.ArrayList;
import java.util.List;

@Component("company")
@RequiredArgsConstructor
public class CompanyList extends AbstractList {

    private final VasService vasService;

    @Override
    public List<?> getList(int type, ListReq req) {
        GetCompanyListRes res = vasService.getListCompany(req);
        if (!CollectionUtils.isEmpty(res.getCompanies())) {
            if (Boolean.TRUE.equals(req.getIsImport())){
                res.getCompanies().forEach(i -> {
                    if (StringUtils.hasText(i.getLogoFile()))
                        i.setLogoFile(ru.sberx.utils.util.StringUtils.getLogo(i.getLogoFile()));
                });
                return res.getCompanies();
            } else {
                return res.getCompanies();
            }
        }
        else
            return new ArrayList<>();
    }

    @Override
    public Integer getFavoritesCount(ListReq req) {
        Boolean favorite = req.getFavorite();
        req.setFavorite(true);
        GetCompanyListRes listRes = vasService.getListCompany(req);
        req.setFavorite(favorite);
        if (!CollectionUtils.isEmpty(listRes.getCompanies())) {
            return listRes.getCompanies().size();
        } else {
            return 0;
        }
    }
}
