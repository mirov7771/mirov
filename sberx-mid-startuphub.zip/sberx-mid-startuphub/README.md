# sberx-mid-startuphub

### Confluence: https://sbtatlas.sigma.sbrf.ru/wiki/display/SBERXMAIN/sberx-mid-startuphub
