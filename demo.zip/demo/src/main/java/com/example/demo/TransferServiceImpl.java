package com.example.demo;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.rmi.ServerException;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

@Slf4j
@Service
@Profile("!mock")
public class TransferServiceImpl {

    /**
     * формат даты для МП
     */
    private static final DateTimeFormatter DATE_TIME_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssxxx");

    @SneakyThrows
    public String processRequest() {
//        throw new NullPointerException("test2");
        // загрузка заявления будет асинхронной и результат будет виден как статус заявки
        CompletableFuture<String> test = CompletableFuture.supplyAsync(() -> {
            try {
                return test();
            } catch (NullPointerException e) {
                throw new CompletionException(e);
            }
        });
        try {
            test.join();
        } catch (CompletionException ex){
            try {
                throw ex.getCause();
            }
            catch(Error| RuntimeException| ServerException possible) {
                throw possible;
            }
            catch(Throwable impossible) {
                throw new AssertionError(impossible);
            }
        }
        return "test";
    }

    private String test(){
        log.info("test1!!!");
        throw new NullPointerException("test");
        //return "";
    }

    /**
     * Обработка исключения из асинхронного метода, получения исключения - причины и его вызов
     *
     * @param ex исключение, пробрасываемое при неверном срабатывании асинхронного метода
     */
    private void handleAsyncException(Throwable ex) {
        log.warn("exception in handleAsyncException", ex);

        //if(ex != null){
            log.debug("throwing npe in handleAsyncException");
            throw new NullPointerException("test");
//            String causeName = ex.getCause().getClass().toString();

//            // Получается проверить только так. instanceOf по какой-то причине не срабатывает
//            if (causeName.contains("SbermobileBadRequestException")){
//                log.debug("causeName.contains SbermobileBadRequestException");
//
//                throw new SbermobileBadRequestException(StatusCode.TRANSFER_AGREEMENT_ERROR.getUserMessage(),
//                        StatusCode.TRANSFER_AGREEMENT_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//            if (causeName.contains("SbermobileException")){
//                log.debug("causeName.contains SbermobileException");
//
//                throw new SbermobileException(StatusCode.TRANSFER_AGREEMENT_ERROR.getUserMessage(),
//                        StatusCode.TRANSFER_AGREEMENT_ERROR, HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//            if (causeName.contains("NullPointerException")){
//                throw new NullPointerException();
//            }
       // }
    }
}
