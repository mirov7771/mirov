package com.example.demo.client.http.impl;

import com.example.demo.client.client.RestGate;
import com.example.demo.client.http.RestAPIGate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class RestAPIGateImpl implements RestAPIGate {

    private final RestGate restGate;

    @Override
    public String activateSubscriber(String request) {
        return restGate.call(String.class,
                "http://10.77.40.100:8080/wsdl/DSI_CRM_AccountManagement/AccountManagementPortType",
                null,
                null,
                request,
                HttpMethod.POST,
                null,
                MediaType.APPLICATION_XML);
    }
}
