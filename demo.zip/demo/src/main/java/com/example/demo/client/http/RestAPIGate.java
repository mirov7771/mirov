package com.example.demo.client.http;

public interface RestAPIGate {
    String activateSubscriber(String request);
}
