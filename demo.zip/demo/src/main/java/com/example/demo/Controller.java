package com.example.demo;

import com.example.demo.client.http.RestAPIGate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.ibm.icu.text.Transliterator;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import threegpp.charset.ucs2.UCS2Charset80;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.Cookie;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;


@RestController
@Slf4j
public class Controller {

    private static final Base64.Encoder encoder = Base64.getUrlEncoder();
    private static final Base64.Decoder decoder = Base64.getDecoder();

    public static final String CYRILLIC_TO_LATIN = "Cyrillic-Latin";

    private static final ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
    }

    private static final String TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJnb3N0MzQuMTAtMjAxMiJ9.eyJzdWIiOiJiNTYzYTQxZmU5N2Y5YjAxNWM0NzY3MjU3Y2I5YzE4NjkxZTYyMDU2MjU1ZWE0NjRmMGRmZmIwMjEwNmM4ZmY3IiwiYXVkIjoiMTExMjc3IiwiYWNyIjoibG9hLTMiLCJhenAiOiIxMTEyNzciLCJhdXRoX3RpbWUiOjE2MjUyMDkzMjEsImFtciI6Intwd2QsIG1jYSwgbWZhLCBvdHAsIHNtc30iLCJpc3MiOiJodHRwczovL2VkdXBpcmZpbnRlY2guc2JlcmJhbmsucnU6OTQ0MyIsImV4cCI6MTYyNTIwOTYyNywiaWF0IjoxNjI1MjA5MzI3LCJub25jZSI6IldUSnhhWE5DVmtnemRsaFdTMFI0WjBGdVdYVk9Ra1pGVHpGblgwdGxiaTFtWW10U2RXMWxVRkl4WWpnMjslMkZhdXRoIn0.aMEQha7kEaFmYf2HHaB0GJa-tM6Etz6SIGAhdPrMLaoQ8Qojv9cnAL3uSd86PHvucPxqwD9QWSBWBqB_NU14IA";

    @Autowired
    private TransferServiceImpl transferService;

    @GetMapping("/")
    public ResponseEntity<?> test() throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, JsonProcessingException {

//        JwtParser.JwtPayload jwtPayload = JwtParser.getJwtPayload(TOKEN);
//        jwtPayload.getCustomFields().put("at_hash", UUID.randomUUID().toString());
//        jwtPayload.getCustomFields().put("sub", jwtPayload.getSub());
//        jwtPayload.getCustomFields().put("aud", jwtPayload.getAud());
//        jwtPayload.getCustomFields().put("exp", jwtPayload.getExp());
//        jwtPayload.getCustomFields().put("iss", jwtPayload.getIss());
//        jwtPayload.getCustomFields().put("nonce", jwtPayload.getCustomFields().get("nonce"));
//        jwtPayload.getCustomFields().put("unique_name", "uid=" + 1 + ",ou=sbbid");
//        String newTokenPart = new ObjectMapper().writeValueAsString(jwtPayload.getCustomFields());
//
//        String token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJhdF9oYXNoIjoiZTQ1YzhjMTUtZmE0OS00OWFmLTllNGUtMGRlYmY1OTM5MWFjIiwiYWNyIjoibG9hLTMiLCJzdWIiOiJiNTYzYTQxZmU5N2Y5YjAxNWM0NzY3MjU3Y2I5YzE4NjkxZTYyMDU2MjU1ZWE0NjRmMGRmZmIwMjEwNmM4ZmY3IiwiYXVkIjpbIjExMTI3NyJdLCJ1bmlxdWVfbmFtZSI6InVpZD02LG91PXNiYmlkIiwiYXpwIjoiMTExMjc3IiwiYXV0aF90aW1lIjoxNjI1MjExMDA4LCJhbXIiOiJ7cHdkLCBtY2EsIG1mYSwgb3RwLCBzbXN9IiwiaXNzIjoiaHR0cHM6Ly9lZHVwaXJmaW50ZWNoLnNiZXJiYW5rLnJ1Ojk0NDMiLCJleHAiOjE2MjUyMTE0NTYsImlhdCI6MTYyNTIxMTE1Niwibm9uY2UiOiJXVEp4YVhOQ1ZrZ3pkbGhXUzBSNFowRnVXWFZPUWtaRlR6Rm5YMHRsYmkxbVltdFNkVzFsVUZJeFlqZzIifQ";
//        System.out.println("Token: "+token);
//
//        token += "." + encodeHMACSHA512(token, "b8c1f1d6ba57425e80657ddd353f022e");
//
//
//        return getHash("xFN65mG8pF");
        //return token;
        //{"state":20004,"comment":"","tableId":"322210","tableName":"Pilot"}
//        Map<String, Object> map = new HashMap<>();
//        map.put("state", 20004L);
//        map.put("comment", "");
//        map.put("tableId", "322210");
//        map.put("tableName", "Pilot");
//        map.put("sessionId", "322210");
//        String s = mapper.writeValueAsString(map);
//
//        transferService.processRequest();

        Cookie sessionCookie = new Cookie("AUTH_SESSION_ID", "sessionId");
        sessionCookie.setMaxAge(100);
        sessionCookie.setSecure(true);

        String st = "Миров Артур";

        Transliterator toLatinTrans = Transliterator.getInstance(CYRILLIC_TO_LATIN);
        String result = toLatinTrans.transliterate(st);

        SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm");
        String time = localDateFormat.format(new Date());

        return ResponseEntity.ok().body(time);
    }

    private final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    @PostMapping(value = "/", produces = APPLICATION_JSON_VALUE)
    public void post(@RequestBody Dto dto){
        long milliseconds = dto.getFrom().getTime() - new Date().getTime();
        int days = (int) (milliseconds / (24 * 60 * 60 * 1000));
        log.info("log info days diff {}", days);
        log.info("log info {}", days >= 7);

        List<Pilot> pilotList = new ArrayList<>();
        pilotList.add(new Pilot(1L));
        pilotList.add(new Pilot(2L));
        pilotList.add(new Pilot(3L));
        long[] longs = pilotList.stream().mapToLong(Pilot::getPilotId).toArray();
    }

    @Data
    public static class Dto{
        private Date from;
    }

    protected String getHash(String value){
        try {
            return Base64.getEncoder().encodeToString(
                    MessageDigest.getInstance("SHA-1").digest(value.getBytes(StandardCharsets.ISO_8859_1))
            );
        } catch (NoSuchAlgorithmException ignored){

        }
        return null;
    }

    public String encodeHMACSHA512(String s, String key)
            throws NoSuchAlgorithmException, InvalidKeyException {
        Mac mac = Mac.getInstance("HmacSHA512");
        SecretKeySpec secretKey = new SecretKeySpec(key.getBytes(), "HmacSHA512");
        mac.init(secretKey);
        byte[] encodedBytes = mac.doFinal(s.getBytes());
        return new String(encoder.withoutPadding().encode(encodedBytes));
    }

    private String generateFirstPart(){
        JsonObject jo = new JsonObject();
        jo.addProperty("typ", "JWT");
        jo.addProperty("alg", "HS512");
        return new String(encoder.withoutPadding().encode(jo.toString().getBytes()));
    }

    @Data
    @AllArgsConstructor
    public static class Pilot {
        Long pilotId;
    }


    @GetMapping(value = "/testdto")
    public List<TestDTO> testdto(){
        TestDTO dto1 = new TestDTO("A", 1, new ArrayList<TestDto2>(){{
            add(new TestDto2(111, "active"));
            add(new TestDto2(114, "not_active"));
        }});
        TestDTO dto2 = new TestDTO("B", 2,  new ArrayList<TestDto2>(){{
            add(new TestDto2(112, "active"));
        }});
        TestDTO dto3 = new TestDTO("C", 3,  new ArrayList<TestDto2>(){{
            add(new TestDto2(113, "active"));
        }});
        List<TestDTO> test = new ArrayList<>();
        test.add(dto1);
        test.add(dto2);
        test.add(dto3);

//        List<TestDTO> d = new ArrayList<>(test);
//
//        TestDTO testDTO = test.stream().findFirst().orElse(null);
//        testDTO.setName("E");
//        d.add(testDTO);

        TestDTO testDTO1 = new TestDTO();
        test.stream().findFirst().ifPresent(i -> {
            testDTO1.setNum(i.getNum());
            testDTO1.setName("EEE");
            testDTO1.setList(i.getList().stream().map(v -> {
                TestDto2 dto22 = new TestDto2();
                dto22.setStatus(v.getStatus());
                dto22.setTariffId(5555);
                return dto22;
            }).collect(Collectors.toList()));

        });

        test.add(testDTO1);
        return test;
    }

    @GetMapping("xml")
    public Boolean testxml(){
        String xml = "<S:Envelope xmlns:S=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "   <S:Body>\n" +
                "      <ns2:XMLmessageResponse xmlns:ns2=\"http://webserv.my/\">\n" +
                "         <return>\n" +
                "           <body>\n" +
                "            <OperationResult>0</OperationResult>\n" +
                "            <ClientResults>\n" +
                "               <ClientResult>\n" +
                "                  <MSISDN>79000000005</MSISDN>\n" +
                "                  <Result>1205230001</Result>\n" +
                "               </ClientResult>\n" +
                "            </ClientResults>\n" +
                "           </body>\n" +
                "         </return>\n" +
                "      </ns2:XMLmessageResponse>\n" +
                "   </S:Body>\n" +
                "</S:Envelope>";
//        return xml.replace("&", "&amp;")
//                .replace("<", "&lt;")
//                .replace(">", "&gt;")
//                .replace("\"", "&quot;")
//                .replace("'", "&apos;");
//        return StringEscapeUtils.escapeXml(xml);
//        return xml.substring(0, xml.indexOf("<return>")) +
//                xml.substring(xml.indexOf("<return>"), xml.indexOf("</return>")) +
//                xml.substring(xml.indexOf("</return>"), xml.indexOf("nvelope>"));
//        String strToEscape = xml.substring(xml.indexOf("<return>") + 8, xml.indexOf("</return>"));
//        return xml.replace(strToEscape, StringEscapeUtils.escapeXml(strToEscape));
        return "04500000000".matches("^([0-9]){11}$");
    }

    @Autowired
    private RestAPIGate restAPIGate;

    @GetMapping("telecom")
    public ResponseEntity<String> testTelecom() throws ParserConfigurationException, IOException, SAXException {
        String req = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" \n" +
                "xmlns:dsi=\"http://www.bercut.com/schema/DSI_CRM_AccountManagement\" \n" +
                "xmlns:dsi1=\"http://www.bercut.com/schema/DSI_CRM_SimpleElements\">\n" +
                "   <soapenv:Header/>\n" +
                "   <soapenv:Body>\n" +
                "      <dsi:activateSubscriberRequest>\n" +
                "         <dsi1:branchId>0</dsi1:branchId>\n" +
                "         <dsi:FilterSubscriber>\n" +
                "            <dsi1:msisdn>9957479136</dsi1:msisdn>\n" +
                "         </dsi:FilterSubscriber>\n" +
                "      </dsi:activateSubscriberRequest>\n" +
                "   </soapenv:Body>\n" +
                "</soapenv:Envelope>";
        try {
            Date date = DateUtils.parseDate("01.02.2018", "MMM dd, yyyy HH:mm:ss",
                    "MMM dd, yyyy",
                    "yyyy-MM-dd'T'HH:mm:ss.SSSX",
                    "yyyy-MM-dd'T'HH:mm:ss.SSS",
                    "EEE, dd MMM yyyy HH:mm:ss zzz",
                    "yyyy-MM-dd",
                    "dd.MM.yyyy");
            log.info("Date - {}", date);
        } catch (Exception e) {

        }

        InputSource is = new InputSource();
        is.setCharacterStream(new StringReader(RESPONSE
                .replace("ber-ns0:", "")
                .replace("<billingServiceId>", "<billingServiceId>%servId%")
                .replace("</billingServiceId>", "%servId%</billingServiceId>")));
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();

        Document doc = db.parse(is);
        NodeList nodes = doc.getElementsByTagName("service");
        List<String> list = new ArrayList<>();
        for (int i = 0; i < nodes.getLength(); i++) {
            Element element = (Element) nodes.item(i);
            if (element != null
                    && StringUtils.hasText(element.getTextContent())
                    && element.getTextContent().contains("%servId%")){
                list.add(element.getTextContent().split("%servId%")[1].split("%servId%")[0]);
            }
        }
        log.info("list {}", list);

        return null;
        //return ResponseEntity.ok(restAPIGate.activateSubscriber(req));
    }


    @GetMapping("gsm")
    public String gsm() {
        return DatatypeConverter.printHexBinary("Clipers".getBytes(StandardCharsets.UTF_16BE));
    }

    private static final String RESPONSE = "<?xml version='1.0' encoding='UTF-8'?>\n" +
            "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
            "    <SOAP-ENV:Body xmlns:ber-ns0=\"http://www.bercut.com/specs/schemas/cc_api_core/subscriber_service\">\n" +
            "        <ber-ns0:getEnabledSubscriberServicesResponseParams>\n" +
            "            <ber-ns0:subscriberServicesList>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Мобильный интернет</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Мобильный интернет</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>1244</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая с трафиком</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Переходи на Сбер 500 Минут</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Переходи на Сбер 500 Минут</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2069</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-21T17:03:51.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:billingServiceId>1252</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Вам звонили (MCA) с АП</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Вам звонили (MCA) с АП</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2093</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-06-16T14:09:06.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.85</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>1.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Порог баланса</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Порог баланса</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>1272</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Международные вызовы</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Международные вызовы</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>4</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>SMS</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>SMS</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая с трафиком</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Телефония Вх.</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Телефония Вх.</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>1256</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая с трафиком</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Роуминг</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Роуминг</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>5</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:billingServiceId>2047</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-09T00:01:52.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Смена ТП [Маркер&#x5d;</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Смена ТП [Маркер&#x5d;</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>1903</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-19T11:18:39.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Переходи на Сбер</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Переходи на Сбер</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2059</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-21T17:03:51.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>338.98</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>400.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Телефония Исх.</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Телефония Исх.</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>1</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая с трафиком</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:16:36.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>1 Гб СП Автопродление</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>1 Гб СП Автопродление</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2062</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-21T17:03:51.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Нулевой баланс</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Нулевой баланс</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>1418</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>unlocked</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2020-12-14T14:18:34.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>100 Мин по России СП Автопродление</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>100 Мин по России СП Автопродление</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2061</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-21T17:03:51.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "                <ber-ns0:service>\n" +
            "                    <ber-ns0:serviceName>Переходи на Сбер 5 ГБ</ber-ns0:serviceName>\n" +
            "                    <ber-ns0:billingServiceName>Переходи на Сбер 5 ГБ</ber-ns0:billingServiceName>\n" +
            "                    <ber-ns0:billingServiceId>2070</ber-ns0:billingServiceId>\n" +
            "                    <ber-ns0:serviceTypeName>Периодическая без трафика</ber-ns0:serviceTypeName>\n" +
            "                    <ber-ns0:serviceStatus>active</ber-ns0:serviceStatus>\n" +
            "                    <ber-ns0:sTime>2022-07-21T17:03:51.000+03:00</ber-ns0:sTime>\n" +
            "                    <ber-ns0:eTime>2999-12-31T00:00:00.000+03:00</ber-ns0:eTime>\n" +
            "                    <ber-ns0:costOn>0.00</ber-ns0:costOn>\n" +
            "                    <ber-ns0:costOff>0</ber-ns0:costOff>\n" +
            "                    <ber-ns0:costOnWithTax>0.00</ber-ns0:costOnWithTax>\n" +
            "                    <ber-ns0:costOffWithTax>0</ber-ns0:costOffWithTax>\n" +
            "                    <ber-ns0:costMonth>0.00</ber-ns0:costMonth>\n" +
            "                    <ber-ns0:costMonthWithTax>0.00</ber-ns0:costMonthWithTax>\n" +
            "                    <ber-ns0:currency>RUB</ber-ns0:currency>\n" +
            "                </ber-ns0:service>\n" +
            "            </ber-ns0:subscriberServicesList>\n" +
            "            <ber-ns0:log>\n" +
            "                <ber-ns0:log>Получен запрос getEnabledServices(9800482964);</ber-ns0:log>\n" +
            "            </ber-ns0:log>\n" +
            "        </ber-ns0:getEnabledSubscriberServicesResponseParams>\n" +
            "    </SOAP-ENV:Body>\n" +
            "</SOAP-ENV:Envelope>";



    @GetMapping("/port")
    public List<Porting> getPortingMethod() throws JsonProcessingException {
        final List<Porting> porting = getPorting();
        for (Porting timeSlotRs : porting) {
            //LocalDate currentTimeslotDate = LocalDate.of(date.getDate().getYear(), date.getDate().getMonth(), date.getDate().getDay());
            LocalDate currentTimeslotDate = Instant.ofEpochMilli(timeSlotRs.getDate().getTime())
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate();
            log.info("!!!! " + currentTimeslotDate);
        }
        return porting;
    }

    private static List<Porting> getPorting() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(DATES, new TypeReference<List<Porting>>() {});
    }

    @Data
    private static class Porting {
        private Date date;
    }

    private static final String DATES = "[\n" +
            "    {\n" +
            "      \"date\": \"2022-09-04T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-05T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-06T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-07T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-08T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-09T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-10T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-13T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-14T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-15T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-16T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-17T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-18T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-19T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-22T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-23T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-24T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-25T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-26T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-27T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-09-28T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-01T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-02T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-03T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-04T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-05T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-06T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-07T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-10T00:00:00.000+00:00\"\n" +
            "    },\n" +
            "    {\n" +
            "      \"date\": \"2022-10-11T00:00:00.000+00:00\"\n" +
            "    }\n" +
            "  ]";

}
