package com.example.demo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.concurrent.CompletionException;

@ControllerAdvice
@Slf4j
public class SbermobileExceptionHandler extends ResponseEntityExceptionHandler {


    @ExceptionHandler(RuntimeException.class)
    protected ResponseEntity<BaseResponseDTO> handleRuntimeException(RuntimeException e) {
        StatusInfo statusInfo = new StatusInfo(StatusCode.UNKNOWN_SERVER_ERROR.getUserMessage(), StatusCode.UNKNOWN_SERVER_ERROR);
        log.error(e.getMessage(), e);
        return responseEntityBuilder(statusInfo, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    private ResponseEntity<BaseResponseDTO> responseEntityBuilder(StatusInfo statusInfo, HttpStatus httpStatus) {
        BaseResponseDTO responseDTO = new BaseResponseDTO();
        responseDTO.setStatusInfo(statusInfo);
        return new ResponseEntity<>(responseDTO, httpStatus);
    }
}
