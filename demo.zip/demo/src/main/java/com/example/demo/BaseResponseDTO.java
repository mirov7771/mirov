package com.example.demo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class BaseResponseDTO implements Serializable {

    private static StatusInfo baseStatusInfo = new StatusInfo(StatusCode.OK);
    private StatusInfo statusInfo = baseStatusInfo;

    public BaseResponseDTO(StatusInfo statusInfo){
        this.statusInfo = statusInfo;
    }

    private String time = LocalDateTime.now().toString();
}
