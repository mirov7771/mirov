package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class StatusInfo implements Serializable {

    private final StatusCode statusCode;

    private final String statusMessage;

    public StatusInfo(StatusCode statusCode) {
        this.statusCode = statusCode;
        this.statusMessage = statusCode.getStatusMessage();
    }

    public StatusInfo(@JsonProperty("statusMessage") String statusMessage, @JsonProperty("statusCode") StatusCode statusCode) {
        this.statusCode = statusCode;
        this.statusMessage = statusMessage;
    }

}