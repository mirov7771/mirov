package com.example.demo;

public enum StatusCode {

    OK("", ""),
    CACHED("",""),
    UNKNOWN_SERVER_ERROR("Unknown server status", "Упс, что-то пошло не так"),
    WRONG_NUMBER_FORMAT("Number must consist of 10 digits!", "Номер не найден. Проверьте корректность ввода номера."),
    TOKEN_NOT_FOUND("Token not found in list valid tokens", "Ошибка авторизации. Пожалуйста, авторизуйтесь повторно."),
    NOTIFY_TIME_IS_UP("Notify time is up", "Ошибка времени исполнения уведомления"),
    NOTIFY_TOKEN_NOT_FOUND("Notify token not found", "Токен уведомления не найден."),
    PLATFORM_NOTIFICATION_NOT_FOUND("Platform user is empty for notification", "Для пользователя не указана платформа для уведомления"),
    INVALID_RESPONSE_TELECOM("Invalid response from telecom", "Неверный ответ от телекома"),
    DEVICE_NOT_FOUND("Device not found", "Устройство не найдено."),
    DEVICE_DOESNT_HAVE_SIM("Device doesn't have sim", "В устройстве отсутствует sim карта"),
    CACHE_NOT_REMOVED("Cache not removed", "Не удалось очистить кэш"),
    CACHE_NOT_SAVED("Cache not saved", "Не удалось сохранить в кэш"),
    CLIENT_NOT_FOUND("Client not found", "Упс, что-то пошло не так"),
    NUMBER_NOT_FOUND("User not found", "Невозможно войти под указанным номером."),
    FILE_NOT_FOUND("File not found", "Ошибка загрузки файла. Обратитесь в поддержку за получением Договора."),
    FILE_NAME_IS_EMPTY("File name must be not null", "Ошибка обработки файла, приложите другой файл."),
    DICTIONARY_FILE_FORMAT_NOT_SUPPORTED("Dictionary file format not supported!", "Ошибка формата файла, приложите файл в формате jpeg, jpg или png."),
    NOT_AUTHENTIFICATED("User not authenticated", "Ошибка авторизации. Пожалуйста, авторизуйтесь повторно."),
    BAD_CREDENTIALS("Login and password mismatch", "Неправильная связка номера и пароля"),
    CARD_NOT_FOUND("Card not found", "Привяжите банковскую карту для быстрого пополнения счёта."),
    PAYMENT_GATEWAY_ERROR("Payment gateway error", "Ошибка платежа, обратитесь в техподдержку для решения проблемы"),
    DICTIONARY_NOT_FOUND("Dictionary not found", "Упс, что-то пошло не так"),
    DICTIONARY_ROW_NOT_FOUND("Dictionary row not found", "Упс, что-то пошло не так"),
    NO_DATA_FROM_DICTIONARY("No data for request", "Упс, что-то пошло не так"),
    SOAP_NO_ANSWER("Soap service returned no answer!", "Упс, что-то пошло не так"),
    PAYMENT_NOT_FOUND("There is no payment order", "Ошибка. Обратитесь в техподдержку для решения проблемы"),
    PAYMENT_REGISTRATION_CLIENT("Invalid input or not qualified requirements", "Упс, что-то пошло не так"),
    PAYMENT_REGISTRATION_SERVER("Error during payment process", "Ошибка платежа, обратитесь в техподдержку для решения проблемы"),
    CHECK_ORDER_CLIENT("Invalid input or not qualified requirements", "Ошибка. Обратитесь в техподдержку для решения проблемы"),
    CHECK_ORDER_SERVER("Error during check order process", "Ошибка платежа, обратитесь в техподдержку для решения проблемы"),
    MAIN_NUMBER_HAS_NO_SUCH_ADDITIONAL_NUMBER("Main number has no such additional number!", "В запросе присутствует номер не привязанный к основному"),
    MAIN_NUMBER_ALREADY_HAS_SUCH_ADDITIONAL_NUMBER("Main number already has such additional number!", "Ошибка. Данный номер уже привязан в приложении"),
    SELF_CONNECTION_ADDITIONAL_NUMBER("Additional number equals main number", "Ошибка. Данный номер уже привязан в приложении"),
    QIWI_CLIENT_ERROR("Error during qiwi notification can be fixed by client", "Ошибка. Обратитесь в техподдержку для решения проблемы"),
    QIWI_SERVER_ERROR("Error during qiwi notification. Something went wrong", "Ошибка. Обратитесь в техподдержку для решения проблемы"),
    WRONG_BOUND_STATUS("Wrong bound state or bound not found", "Упс, что-то пошло не так"),
    ACCESS_DENIED("Access denied", "Ошибка. Обратитесь в техподдержку для решения проблемы"),
    BILLING_EXCEPTION("Error during billing call", "Упс, что-то пошло не так"),
    OPTION_ALREADY_CONNECTED("Option is already connected before", "Ошибка подключения. Услуга уже подключена"),
    OPTION_ALREADY_DISABLED("Option is already disabled before", "Ошибка отключения. Услуга не была подключена"),
    OPTION_NOT_AVAILABLE("Option not available for connect", "Ошибка подключения. Данная услуга не доступна на Вашем тарифе."),
    DYNAMIC_FORM_ERROR("Dynamic form not available", "Упс, что-то пошло не так"),
    VALIDATION_ERROR("Error during validation", "Упс, что-то пошло не так"),
    OPTION_NOT_FOUND("Option not found", "Упс, что-то пошло не так"),
    TOO_MANY_FILES("Too many files in request", "Ошибка добавления файлов. Выберите не больше 3-х файлов"),
    NOT_SBERBANK_CARD("This card doesn't belong to sberbank", "Ошибка. Укажите банковскую карту Сбербанка"),
    ADDITIONAL_NUMBERS_LIMIT_REACHED("You already have 5 additional numbers!", "Ошибка. В приложении может быть не более 9-х дополнительных номеров."),
    OPTION_CONNECT_ERROR("Option not connected error", "Ошибка подключения услуги. Обратитесь в техподдержку для решения проблемы"),
    OPTION_NOT_CONNECTED("Option not connected", "Упс, что-то пошло не так"),
    WRONG_ADDITIONAL_NUMBER_OR_PASSWORD("Additional number or password are not correct!", "Упс, что-то пошло не так"),
    SETTINGS_GROUP_NOT_FOUND("Settings Group not faund", ""),
    SETTING_NOT_FOUND("Setting not found", ""),
    SETTING_TEMPLATE_NOT_FOUND("Setting template not found", ""),
    SETTING_TEMPLATE_PARAMS_NOT_FOUND("Setting template params not found", ""),
    ADDITIONAL_NUMBER_NOT_CONNECTED("Additional number not connected to auth number", "Данный дополнительный номер не подключен к основному номеру"),
    COUNTRY_NOT_FOUND("Unknown country", "Роуминг в выбранной стране не доступен."),
    NUMBER_NOT_RECOGNIZED("Number not recognized", ""),
    ADDITIONAL_NUMBER_WRONG_CLIENT_TYPE("Additional number and auth number client type not equals", "Ошибка подключения номера, не доступного при настройке управления."),
    ALIAS_TOO_LONG("Alias too long", "Имя профиля содержит слишком много символов."),
    MESSAGE_TOO_LONG("Message too long", "Пожалуйста, опишите свою проблему более кратко."),
    SPASIBO_AMOUNT("There must be more spasibo bonuses", "Минимальная сумма пополнения должна быть 301₽."),
    WRONG_ADDITIONAL_BANK_CARD("Additional bank cards are not correct!", "Ошибка добавления банковских карт. В приложении может быть привязано не более 5-ти карт."),
    PROMOCODE_NOT_FOUND("Promocode not found", "Промокод не найден, проверьте правильность заполнения"), // 404
    PROMOCODE_EXPIRED("Promocode expired", "Промокод просрочен или уже активирован"), // 409
    PROMOCODE_ACTIVATION_EXCEEDED("Promocode expired", "Превышено число активаций промокода"),  // 424
    PASSWORD_EXPIRED("Temp password was expired", "Истекло время действия временного пароля, пожалуйста получите новый"),// 424 Превышено число активаций промо-кода
    SAVE_FILE("Error during file save", "Ошибка при сохранения файла"),
    // автоплатежи
    HAS_ACTIVE_AUTOPAYMENT("Number has active autopayment", "Ошибка. К номеру уже привязан автоплатеж"),
    WRONG_AUTOPAYMENT_AMOUNT("Wrong autopayment amount", "Ошибка. Неправильно задана сумма автоплатежа"),
    NO_ACTIVE_AUTOPAYMENT("No active autopayment", "Ошибка. Нет активных автоплатежей для данного номера и клиента"),
    WRONG_AUTOPAYMENT_THRESHOLD("Wrong autopayment threshold", "Ошибка. Задан неверный порог автоплатежа"),
    CONNECT_INTERVAL_EXCEPTION("Too early to connect other option", "Повторное подключение услуги возможно через 5 минут"),
    NO_TARIFF_DATA("Error getting tariff data from billing", "Мы не смогли получить информацию по вашему тарифу, попробуйте еще раз или обратитесь в поддержку"),

    IPASS_API_CALLING_ERROR("iPass Service API calling error", "Ошибка при вызове iPass Service API"),
    OPERATION_TEMPORARILY_UNAVAILABLE("Operation temporarily unavailable", "Операция временно недоступна, пожалуйста повторите позднее"),
    UNSUPPORTED_VERSION("Current version is not longer available, please update application", "Текущая версия приложения больше не поддерживается. Пожалуйста, обновите приложение"),

    // перенос номера
    TRANSFER_PREPARE_ERROR( "Number tramsfer prepare request error", "Ошибка создания заявки для данного номера"),
    TRANSFER_AGREEMENT_ERROR( "Number tramsfer upload agreement error", "Ошибка загрузки заявления на перевод"),
    TRANSFER_SEND_ERROR( "Number tramsfer send request error", "Ошибка отправки заявки в обработку для данного номера"),
    TRANSFER_ORDER_NOT_FOUND( "Number transfer order not found", "Не найдена заявка на перенос"),
    TRANSFER_EXIST("Number transfer exist for number", "Для данного номера заявка уже существует"),
    TRANSFER_TEMPORARY_NUMBER_NOT_CONNECTED("Error temporary number selected", "Ошибка выбора временного номера"),
    TRANSFER_SBERTELECOM_NUMBER("Wrong transfered number", "Номер уже в сети СберМобайл"),
    TRANSFER_LIMIT_FOR_NUMBER( "Number can't transferred now", "Номер не может быть перенесен сейчас"),
    TRANSFER_NUMBER_NOT_CONFIRMED( "Transferred number is not confirmed", "Переносимый номер не подтвержден"),

    // смс сообщения
    TOO_MANY_MESSAGES( "Too many sended messages", "Слишком много отправляемых сообщений"),
    MESSAGE_NOT_FOUND("Message not found", "Сообщение не найдено"),
    SEND_CONFIRMATION_ERROR( "Error send confirmation", "Ошибка отправки кода подтверждения"),
    //https://sbtatlas.sigma.sbrf.ru/wiki/pages/viewpage.action?pageId=2461335580
    OTRS_ERROR("Error during sending message to OTRS", "Не удалось отправить заявку. Введите, пожалуйста, корректный email"),
    MAIL_ERROR("Error during sending message to eMail", "Не удалось отправить сообщение"),

    INSUFFICIENT_FUNDS_TO_ACTIVATE_SERVICE_TARIFF_OPTION("Not enough funds", "Недостаточно средств для подключения. Необходимо пополнить баланс."),

    // INVITE RESPONSES
    HARD_UPDATE("The app version is no longer supported, please update application", "Работа данной версии приложения СберМобайл не поддерживается. Необходимо обновить приложение."),
    SOFT_UPDATE("The app version will not be supported soon, please update application", "Поддержка данной версии приложения СберМобайл скоро будет прекращена. Необходимо обновить приложение."),
    AUTHORIZATION_FAIL("Auth fail","Попытка авторизации не удалась"),

    // Beautiful Numbers
    NUMBER_IS_BUSY("The number is occupied by someone else", "Номер уже знял кто-то другой. Кстати, ваш номер тоже не плохо смотрится..."),
    DICTIONARY_RECORD_MISSING("Unknown server status", "Упс, что-то пошло не так"),
    TARIFF_IS_NOT_VALID("Wrong source tariff", "На выбранном номере подключен промо-тариф SberTeam. Преимущества СберПрайм действуют только на обычные тарифы. Смените тариф или выберите другой номер"),
    DISCOUNTS_ALREADY_CONNECTED("User got discounts", "На выбранном номере уже подключена услуга \"%discount%\". Если вы подключите СберПрайм, ваша скидка будет отключена."),
    WRONG_PRIME_CLIENT_STATUS("Wrong client status", "Услуга не доступна. Авторизуйтесь под sberId"),
    DUPLICATE_SUB("User already got sub","Ваш профиль Сбербанк ID уже привязан к %s. Отвязать?"),
    PRIME_IS_ALREADY_CONNECTED_TO_NUMBER("Number already has prime privileges", "К данному номеру уже подключены привелегии СберПрайм"),
    PRIME_ALREADY_CONNECTED("This Prime is already in use", "Данный СберПрайм уже используется на другом номере"),
    INSUFFICIENT_FUNDS_TO_UNBLOCK_TARIFF("Insufficient funds to activate tariff", "Необходимо пополнить баланс на X рублей для активации тарифа"),
    DISCOUNTS_OR_PRIME_ALREADY_CONNECTED("","Скидки и прайм"),
    AURA_OPTION_NOT_CONNECTED("Error during Aura option activating","Не получилось подключить. Что-то пошло не так и мы не смогли подключить услугу \"Аура - защита от мошенников\". Попробуйте позже"),
    AURA_OPTION_NOT_DISABLED("Error during Aura option disabling","Не получилось отключить. Что-то пошло не так и мы не смогли отключить услугу \"Аура - защита от мошенников\". Попробуйте позже")
    ;


    private final String statusMessage;
    private final String userMessage;

    StatusCode(String statusMessage, String userMessage) {
        this.statusMessage = statusMessage;
        this.userMessage = userMessage;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public String getUserMessage() {
        return userMessage;
    }
}
