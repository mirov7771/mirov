package com.example.controller;

import com.example.events.EventPublisher;
import com.example.patterns.Cms;
import com.example.patterns.abstractfactory.ProjectTeamFactory;
import com.example.patterns.abstractfactory.banking.BankingTeamFactory;
import com.example.patterns.abstractfactory.website.WebSiteTeamFactory;
import com.example.patterns.adapter.AdapterJavaToDatabase;
import com.example.patterns.adapter.Database;
import com.example.patterns.bridge.ProgramCreator;
import com.example.patterns.builder.Director;
import com.example.patterns.builder.EnterpriseWebSiteBuilder;
import com.example.patterns.builder.VisitCardWebSiteBuilder;
import com.example.patterns.builder.WebSite;
import com.example.patterns.chainofresponsibility.*;
import com.example.patterns.command.DeleteCommand;
import com.example.patterns.command.InsertCommand;
import com.example.patterns.command.SelectCommand;
import com.example.patterns.command.UpdateCommand;
import com.example.patterns.composite.Project;
import com.example.patterns.decorator.Task;
import com.example.patterns.facade.SprintRunner;
import com.example.patterns.factorymethod.*;
import com.example.patterns.interpreter.AndExpression;
import com.example.patterns.interpreter.Expression;
import com.example.patterns.interpreter.OrExpression;
import com.example.patterns.interpreter.TerminalExperssion;
import com.example.patterns.iterator.Iterator;
import com.example.patterns.iterator.JavaDeveloper;
import com.example.patterns.mediator.Admin;
import com.example.patterns.mediator.SimpleTextChat;
import com.example.patterns.mediator.SimpleUser;
import com.example.patterns.mediator.User;
import com.example.patterns.memento.GitHubRepo;
import com.example.patterns.observer.JavaDeveloperJobSite;
import com.example.patterns.observer.Observer;
import com.example.patterns.observer.Subscriber;
import com.example.patterns.prototype.ProjectFactory;
import com.example.patterns.proxy.ProxyProject;
import com.example.patterns.singleton.ProgramLogger;
import com.example.patterns.state.Sleeping;
import com.example.patterns.templatemethod.NewsPage;
import com.example.patterns.templatemethod.WebsiteTemplate;
import com.example.patterns.templatemethod.WelcomePage;
import com.example.patterns.visitor.JuniorDeveloper;
import com.example.patterns.visitor.SeniorDeveloper;
import com.example.rabbit.RabbitMqRequest;
import com.example.rabbit.SmevRes;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("SBRFSync")
@ManagedResource(objectName = "SBRFSync:category=MBeans,name=SBRFSyncBean")
public class Controller {

    private final Map<String, Developer> developer;

    @Autowired
    public Controller(Map<String, Developer> developer,
                      ProgramCreator programCreator,
                      Project project,
                      Task task,
                      SprintRunner sprintRunner,
                      MeterRegistry registry) {
        this.developer = developer;
        this.programCreator = programCreator;
        this.project = project;
        this.task = task;
        this.sprintRunner = sprintRunner;
        this.counter = registry.counter("SBRFSync");
    }

    ///factory
    @GetMapping("factory-one")
    public void factoryOne(){
        developer.get("java").writeCode();
        developer.get("cpp").writeCode();
    }

    @GetMapping("factory-two")
    public void factoryTwo(){
        new JavaDeveloperFactory().createDeveloper().writeCode();
        new CppDeveloperFactory().createDeveloper().writeCode();
    }

    @GetMapping("factory-three/{type}")
    public void factoryThree(@PathVariable("type") String speciality){
        getFactory(speciality).createDeveloper().writeCode();
    }

    private static DeveloperFactory getFactory(String speciality){
        if (speciality.equalsIgnoreCase("java"))
            return new JavaDeveloperFactory();
        else if (speciality.equalsIgnoreCase("cpp"))
            return new CppDeveloperFactory();
        else
            throw new RuntimeException(speciality + " not exists");
    }


    ///singleton
    @GetMapping("singleton/{log}")
    public void getLog(@PathVariable String log){
        ProgramLogger logger = ProgramLogger.getInstance();
        logger.addLog("start");
        logger.addLog("log " + log);
        logger.addLog("end");
        logger.showLogFile();
    }


    ///abstractfactory
    @GetMapping("abstractfactory/{type}")
    public void getBankingFactory(@PathVariable AFType type){
        ProjectTeamFactory factory;
        if (type.equals(AFType.banking))
            factory = new BankingTeamFactory();
        else
            factory = new WebSiteTeamFactory();
        factory.getDeveloper().writeCode();
        factory.getTester().testCode();
        factory.getProjectManager().manageProject();
    }

    enum AFType {
        banking,
        website
    }

    ///builder
    @GetMapping("build")
    public void builderOne(@RequestParam(value = "type", required = false) String type){
        Director director = new Director();
        if ("WORDPRESS".equalsIgnoreCase(type))
            director.setBuilder(new EnterpriseWebSiteBuilder());
        else
            director.setBuilder(new VisitCardWebSiteBuilder());
        WebSite webSite = director.buildWebsite();
        System.out.println(webSite);
    }

    @GetMapping("build2")
    public com.example.patterns.builder2.WebSite builderTwo(){
        return new com.example.patterns.builder2.WebSite
                .Builder()
                .name("SITE")
                .cms(Cms.ALIFRESCO)
                .price(1000)
                .build();
    }

    //prototype
    @GetMapping("prototype")
    public String prototype(){
        var master = new com.example.patterns.prototype.Project(1, "SuperProject", "java");
        System.out.println(master);

        var masterClone = (com.example.patterns.prototype.Project) master.copy();
        System.out.println(masterClone);

        ProjectFactory factory = new ProjectFactory(master);
        var masterCloneNew = factory.cloneProject();
        System.out.println(masterCloneNew);

        return masterCloneNew.toString();
    }

    //adapter
    @GetMapping("adapter")
    public void adapter(){
        Database database = new AdapterJavaToDatabase();
        database.insert();
        database.update();
        database.select();
        database.delete();
    }


    //bridge
    private final ProgramCreator programCreator;
    @GetMapping("bridge")
    public void bridge(){
        programCreator.program(null);
    }

    //composite
    private final Project project;
    @GetMapping("composite")
    public void composite(){
        project.execute();
    }

    //decorator
    private final Task task;
    @GetMapping("decorator")
    public String decorator(){
        return task.taskExecute();
    }

    //facade
    private final SprintRunner sprintRunner;
    @GetMapping("facade")
    public void facade(){
        sprintRunner.run();
    }

    //flyweight
    @GetMapping("flyweight")
    public void flyweight(@RequestParam("type") List<String> type){
        com.example.patterns.flyweight.DeveloperFactory developerFactory = new com.example.patterns.flyweight.DeveloperFactory();
        type.forEach(i -> developerFactory.getDeveloper(i).writeCode());
    }

    //proxy
    @GetMapping("proxy")
    public void proxy(){
        com.example.patterns.proxy.Project project = new ProxyProject("https://github.com/realproject");
        project.run();
    }

    @Autowired
    private EventPublisher eventPublisher;

    @GetMapping("event")
    public void event(@RequestParam List<String> type){
        type.forEach(i -> eventPublisher.publishCustomEvent(i));
    }

    //chain of responsibility
    @GetMapping("cor")
    public void cor(){
        Notifier reportNotifier = new SimpleReportNotifier(Priority.ROUTINE);
        reportNotifier.setNextNotifier(new EmailNotifier(Priority.IMPORTANT));
        reportNotifier.getNextNotifier().setNextNotifier(new SmsNotifier(Priority.ASAP));
        reportNotifier.notifyManager("Everything OK", Priority.ROUTINE);
        reportNotifier.notifyManager("Something went wrong", Priority.IMPORTANT);
        reportNotifier.notifyManager("Everything gone", Priority.ASAP);
    }

    //command
    @GetMapping("command/{command}")
    public void command(@PathVariable String command) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        com.example.patterns.command.Database database = new com.example.patterns.command.Database();
        com.example.patterns.command.Developer developer = new com.example.patterns.command.Developer(
                new InsertCommand(database),
                new DeleteCommand(database),
                new UpdateCommand(database),
                new SelectCommand(database)
        );
        developer.getClass().getDeclaredMethod(command).invoke(developer);
    }

    //interpreter
    @GetMapping("interpreter/{type}")
    public String interpreter(@PathVariable("type") String type){
        if (type.equalsIgnoreCase("java"))
            return String.format("Is developer know %s? - %s", type, getJavaExpression().interpret(type));
        return String.format("Is developer know %s? - %s", type, getJavaEEExpression().interpret(type));
    }

    private static Expression getJavaExpression(){
        Expression java = new TerminalExperssion("java");
        Expression javaCore = new TerminalExperssion("java core");

        return new OrExpression(java, javaCore);
    }

    private static Expression getJavaEEExpression(){
        Expression java = new TerminalExperssion("java");
        Expression spring = new TerminalExperssion("spring");

        return new AndExpression(java, spring);
    }

    //iterator
    @GetMapping("iterator")
    public void iterator(){
        String[] skills = {"Java", "Spring", "Hibernate", "Maven", "Posgresql"};
        JavaDeveloper javaDeveloper = new JavaDeveloper("Eugene", skills);
        Iterator iterator = javaDeveloper.getIterator();
        System.out.println("Developer: " + javaDeveloper.getName());
        System.out.println("Skills: ");

        while (iterator.hasNext()){
            System.out.print(iterator.next().toString() + " ");
        }
    }

    //mediator
    @GetMapping("mediator")
    public void mediator(){
        SimpleTextChat simpleTextChat = new SimpleTextChat();
        User admin = new Admin(simpleTextChat, "Admin");
        User user1 = new SimpleUser(simpleTextChat, "User1");
        User user2 = new SimpleUser(simpleTextChat, "User2");
        simpleTextChat.setAdmin(admin);
        simpleTextChat.addUserToChat(user1);
        simpleTextChat.addUserToChat(user2);

        user1.sendMessage("Hello, I am User1!!!");
        admin.sendMessage("I am Admin");
    }

    //rabbitmq
    @Autowired
    private AmqpTemplate template;
    @GetMapping("publish")
    public SmevRes publish(){
        String message = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><QueryResult xmlns=\"urn://x-artefacts-smev-gov-ru/services/service-adapter/types\" xmlns:ns2=\"urn://x-artefacts-smev-gov-ru/services/service-adapter/types/faults\">\n" +
                "  <smevMetadata>\n" +
                "    <MessageId>41b6cbdc-cd27-11ec-8019-025de78352e0</MessageId>\n" +
                "    <TransactionCode>df96cf77-ca14-42b9-9ec6-230a9fa756e2</TransactionCode>\n" +
                "    <OriginalMessageID>3c0bd642-cd27-11ec-9503-0050569d89eb</OriginalMessageID>\n" +
                "    <Sender>MNSV03</Sender>\n" +
                "    <Recipient>U468601</Recipient>\n" +
                "    <SendingDate>2022-05-06T13:28:23.287+03:00</SendingDate>\n" +
                "  </smevMetadata>\n" +
                "  <Message xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"ResponseMessageType\">\n" +
                "    <messageType>PrimaryMessage</messageType>\n" +
                "    <ResponseMetadata>\n" +
                "      <clientId>e969d4f5-602a-49c5-b183-baf68091fb4e</clientId>\n" +
                "      <replyToClientId>dcf42a0e-cd26-11ec-9d64-0242ac120002</replyToClientId>\n" +
                "    </ResponseMetadata>\n" +
                "    <ResponseContent>\n" +
                "      <content>\n" +
                "        <MessagePrimaryContent>\n" +
                "          <ResponseSignUkep:ResponseSignUkep xmlns:ResponseSignUkep=\"urn://gosuslugi/sig-contract-ukep/1.0.0\" xmlns=\"urn://gosuslugi/sig-contract-ukep/1.0.0\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ns2=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/basic/1.3\" xmlns:ns3=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/faults/1.3\" xmlns:ns4=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/routing/1.3\" xmlns:ns5=\"urn://x-artefacts-smev-gov-ru/services/message-exchange/types/directive/1.3\" xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" Id=\"ID_2bfb712c-8017-4f40-bb3f-22eee001fe2b\" ReqId=\"Q-f24ec7a6-cd26-11ec-9d64-0242ac120002\" timestamp=\"2022-05-06T13:28:23.130+03:00\">\n" +
                "            <OID>1048108557</OID>\n" +
                "            <Error>\n" +
                "              <ErrorCode>4</ErrorCode>\n" +
                "              <ErrorMessage>Истекло время для подписания документов</ErrorMessage>\n" +
                "            </Error>\n" +
                "          </ResponseSignUkep:ResponseSignUkep>\n" +
                "        </MessagePrimaryContent>\n" +
                "      </content>\n" +
                "      <originalContent></originalContent>\n" +
                "    </ResponseContent>\n" +
                "  </Message>\n" +
                "</QueryResult>\n";
        //template.convertAndSend("055V01_QUEUE_SEND", message);
        return RabbitMqRequest.getResponse(message);
    }

    //dateformatter
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd'T'ddHHmmss");
    private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    @GetMapping("format")
    public String dateFormatter(){
        return sdf.format(new Date());
    }

    @GetMapping("datestr")
    public String dateToString(){
        LocalDateTime dateTime = LocalDateTime.now();
        return dateTime.format(dtf)+"+03:00";
    }

    //memento
    @GetMapping("memento")
    public void memento(){
        com.example.patterns.memento.Project project = new com.example.patterns.memento.Project();
        GitHubRepo gitHub = new GitHubRepo();

        System.out.println("Creating new project. Version 1.0");
        project.setVersionAndDate("1.0");
        System.out.println(project);

        System.out.println("Saving current version to github");
        gitHub.setSave(project.save());

        System.out.println("Updating project to version 1.1");
        project.setVersionAndDate("1.1");
        System.out.println(project);
        System.out.println("Something went wrong. Start rolling back");
        project.load(gitHub.getSave());
        System.out.println("Previous version: " + project);
    }

    //observer
    @GetMapping("observer")
    public void observer(){
        JavaDeveloperJobSite jobSite = new JavaDeveloperJobSite();
        jobSite.addVacancy("Senior java developer");
        jobSite.addVacancy("Middle java developer");

        Observer firstSubscriber = new Subscriber("Ivan");
        jobSite.addObserver(firstSubscriber);

        Observer secondSubscriber = new Subscriber("Petr");
        jobSite.addObserver(secondSubscriber);

        jobSite.addVacancy("Junior java developer");
        jobSite.removeVacancy("Middle java developer");
    }

    //state
    @GetMapping("state")
    public void state(){
        com.example.patterns.state.Developer developer = new com.example.patterns.state.Developer();
        developer.setActivity(new Sleeping());
        for(int i=0;i < 10;i++){
            developer.justDoIt();
            developer.changeActivity();
        }
    }

    //strategy
    @GetMapping("strategy")
    public void strategy(){
        com.example.patterns.strategy.Developer developer = new com.example.patterns.strategy.Developer();
        developer.setActivity(new com.example.patterns.strategy.Sleeping());
        developer.executeActivity();

        developer.setActivity(new com.example.patterns.strategy.Training());
        developer.executeActivity();

        developer.setActivity(new com.example.patterns.strategy.Coding());
        developer.executeActivity();

        developer.setActivity(new com.example.patterns.strategy.Reading());
        developer.executeActivity();
    }

    //template method
    @GetMapping("template_method")
    public void templateMethod(){
        WebsiteTemplate template = new WelcomePage();

        template.showPage();
        System.out.println("\n================================\n");

        template = new NewsPage();
        template.showPage();
    }

    //visitor
    @GetMapping("visitor")
    public void visitor(){
        com.example.patterns.visitor.Project project = new com.example.patterns.visitor.Project();
        com.example.patterns.visitor.Developer junior = new JuniorDeveloper();
        com.example.patterns.visitor.Developer senior = new SeniorDeveloper();

        System.out.println("Junior in Action...");
        project.beWritten(junior);

        System.out.println("\n=======================\n");

        System.out.println("Senior in Action...");
        project.beWritten(senior);

    }

    private final Counter counter;

    @GetMapping("tags")
    @ManagedOperation
    public String[] tags(){
        counter.increment();
        String description = "Тестовый комент #test1 #test2 #TEST3";
        String[] split = description.split("#");
        List<String> a = new ArrayList<>();
        for(int i = 0; i < split.length; i++){
            if (i > 0){
                a.add(split[i].trim());
            }
        }
        return a.toArray(new String[0]);
    }
}

