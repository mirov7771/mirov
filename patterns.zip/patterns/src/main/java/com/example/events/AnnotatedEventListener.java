package com.example.events;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class AnnotatedEventListener {
    @EventListener
    public void onApplicationEvent(CustomSpringEvent event) {
        System.out.println("NEW!!!Received spring custom event - " + event.getMessage());
    }
}
