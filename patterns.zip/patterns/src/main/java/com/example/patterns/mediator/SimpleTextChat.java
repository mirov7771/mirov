package com.example.patterns.mediator;

import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

public class SimpleTextChat implements Chat{
    User admin;
    List<User> users;

    public void setAdmin(User admin) {
        this.admin = admin;
    }

    public void addUserToChat(User user) {
        if (CollectionUtils.isEmpty(this.users))
            this.users = new ArrayList<>();
        this.users.add(user);
    }

    @Override
    public void sendMessage(String message, User user) {
        this.users.forEach(i -> {
            if (i != user)
                i.getMessage(message);
        });
        admin.getMessage(message);
    }
}
