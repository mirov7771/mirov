package com.example.patterns.strategy;

public class Reading implements Activity {
    @Override
    public void justDoIt() {
        System.out.println("Read some book...");
    }
}
