package com.example.patterns.command;

public interface Command {
    void execute();
}
