package com.example.patterns.adapter;

public class JavaApplication {

    public void saveObject(){
        System.out.println("Saving Java Object");
    }

    public void updateObject(){
        System.out.println("Update Java Object");
    }

    public void selectObject(){
        System.out.println("Select Java Object");
    }

    public void deleteObject(){
        System.out.println("Select Java Object");
    }

}
