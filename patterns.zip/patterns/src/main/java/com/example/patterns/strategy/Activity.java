package com.example.patterns.strategy;

public interface Activity {
    void justDoIt();
}
