package com.example.patterns.facade;

public class Developer {
    public void doJobBeforeDeadLine(BugTracker bugTracker){
        if (Boolean.TRUE.equals(bugTracker.isActiveSprint()))
            System.out.println("Developer solved problems...");
        else
            System.out.println("Developer read habr...");
    }
}
