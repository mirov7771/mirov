package com.example.patterns.visitor;

public class SeniorDeveloper implements Developer{
    @Override
    public void create(ProjectClass element) {
        System.out.println("Rewrite code after junior developer...");
    }

    @Override
    public void create(Database element) {
        System.out.println("Fixing database...");
    }

    @Override
    public void create(Test element) {
        System.out.println("Creating reliable test...");
    }
}
