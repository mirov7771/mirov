package com.example.patterns.factorymethod;

public interface DeveloperFactory {
    Developer createDeveloper();
}
