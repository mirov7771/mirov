package com.example.patterns.abstractfactory.banking;

import com.example.patterns.abstractfactory.Developer;
import com.example.patterns.abstractfactory.ProjectManager;
import com.example.patterns.abstractfactory.ProjectTeamFactory;
import com.example.patterns.abstractfactory.Tester;

public class BankingTeamFactory implements ProjectTeamFactory {
    @Override
    public Developer getDeveloper() {
        return new JavaDeveloper();
    }

    @Override
    public Tester getTester() {
        return new ManualTester();
    }

    @Override
    public ProjectManager getProjectManager() {
        return new SeniorProjectManager();
    }
}
