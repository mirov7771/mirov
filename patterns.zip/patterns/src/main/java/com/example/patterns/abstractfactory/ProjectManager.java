package com.example.patterns.abstractfactory;

public interface ProjectManager {
    void manageProject();
}
