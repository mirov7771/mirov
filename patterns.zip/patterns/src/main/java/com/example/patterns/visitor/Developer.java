package com.example.patterns.visitor;

public interface Developer {
    void create(ProjectClass element);
    void create(Database element);
    void create(Test element);
}
