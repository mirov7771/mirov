package com.example.patterns.factorymethod;

import org.springframework.stereotype.Component;

@Component("cpp")
public class CppDeveloper implements Developer{
    @Override
    public void writeCode() {
        System.out.println("C++ code write...");
    }
}
