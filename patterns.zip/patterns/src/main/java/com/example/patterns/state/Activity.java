package com.example.patterns.state;

public interface Activity {
    void justDoIt();
}
