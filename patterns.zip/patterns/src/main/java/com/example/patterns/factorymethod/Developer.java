package com.example.patterns.factorymethod;

public interface Developer {
    void writeCode();
}
