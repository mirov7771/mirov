package com.example.patterns.builder2;

import com.example.patterns.Cms;

public class WebSite {

    private final String name;
    private final Cms cms;
    private final int price;

    public static class Builder {
        private String name;
        private Cms cms;
        private int price;

        public Builder name(String name){
            this.name = name;
            return this;
        }

        public Builder cms(Cms cms){
            this.cms = cms;
            return this;
        }

        public Builder price(int price){
            this.price = price;
            return this;
        }

        public WebSite build(){
            return new WebSite(this);
        }
    }

    public WebSite(Builder builder) {
        this.name = builder.name;
        this.cms = builder.cms;
        this.price = builder.price;
    }

    public String getName() {
        return name;
    }

    public Cms getCms() {
        return cms;
    }

    public int getPrice() {
        return price;
    }
}
