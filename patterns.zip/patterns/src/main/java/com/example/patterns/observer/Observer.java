package com.example.patterns.observer;

import java.util.List;

public interface Observer {
    void handleEvent(List<String> vacancies);
}
