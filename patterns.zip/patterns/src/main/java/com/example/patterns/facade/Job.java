package com.example.patterns.facade;

public class Job {
    public void doJob(){
        System.out.println("Job in progress...");
    }

}
