package com.example.patterns.decorator;

public interface Developer {
    String makeJob();
}
