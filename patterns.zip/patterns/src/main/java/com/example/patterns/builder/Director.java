package com.example.patterns.builder;

public class Director {

    WebSiteBuilder builder;

    public void setBuilder(WebSiteBuilder builder){
        this.builder = builder;
    }

    public WebSite buildWebsite(){
        builder.createWebSite();
        builder.buildName();
        builder.buildCms();
        builder.buildPrice();

        return builder.getWebSite();
    }

}
