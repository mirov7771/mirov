package com.example.patterns.interpreter;

public class TerminalExperssion implements Expression{
    private final String data;

    public TerminalExperssion(String data) {
        this.data = data;
    }

    @Override
    public boolean interpret(String context) {
        return context.contains(data);
    }
}
