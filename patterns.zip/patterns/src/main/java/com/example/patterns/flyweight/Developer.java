package com.example.patterns.flyweight;

public interface Developer {
    void writeCode();
}
