package com.example.patterns.facade;

import org.springframework.stereotype.Service;

@Service
public class SprintRunner {
    public void run(){
//        Job job = new Job();
//        job.doJob();
//
//        BugTracker bugTracker = new BugTracker();
//        bugTracker.startSprint();
//
//        Developer developer = new Developer();
//        developer.doJobBeforeDeadLine(bugTracker);
//
//        bugTracker.endSpring();
//        developer.doJobBeforeDeadLine(bugTracker);
        // Тоже самое что сделаное выше, но через фасад

        new WorkFlowFacade().solveProblems();
    }
}
