package com.example.patterns.abstractfactory;

public interface Developer {
    void writeCode();
}
