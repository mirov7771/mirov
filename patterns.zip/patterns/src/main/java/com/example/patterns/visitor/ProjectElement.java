package com.example.patterns.visitor;

public interface ProjectElement {
    void beWritten(Developer developer);
}
