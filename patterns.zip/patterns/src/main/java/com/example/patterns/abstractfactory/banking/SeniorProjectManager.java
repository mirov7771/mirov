package com.example.patterns.abstractfactory.banking;

import com.example.patterns.abstractfactory.ProjectManager;

public class SeniorProjectManager implements ProjectManager {
    @Override
    public void manageProject() {
        System.out.println("PM manages project...");
    }
}
