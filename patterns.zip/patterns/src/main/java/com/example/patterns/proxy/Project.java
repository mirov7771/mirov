package com.example.patterns.proxy;

public interface Project {
    void run();
}
