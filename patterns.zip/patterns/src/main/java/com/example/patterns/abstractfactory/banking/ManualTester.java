package com.example.patterns.abstractfactory.banking;

import com.example.patterns.abstractfactory.Tester;

public class ManualTester implements Tester {
    @Override
    public void testCode() {
        System.out.println("Manual tester tests code...");
    }
}
