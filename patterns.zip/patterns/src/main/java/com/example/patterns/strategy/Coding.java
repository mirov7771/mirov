package com.example.patterns.strategy;

public class Coding implements Activity {
    @Override
    public void justDoIt() {
        System.out.println("Writing code...");
    }
}
