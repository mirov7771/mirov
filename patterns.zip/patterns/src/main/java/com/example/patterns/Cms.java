package com.example.patterns;

public enum Cms {
    WORDPRESS,
    ALIFRESCO
}
