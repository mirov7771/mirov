package com.example.patterns.mediator;

public interface Chat {
    void sendMessage(String message, User user);
}
