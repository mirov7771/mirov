package com.example.patterns.composite;

import java.util.ArrayList;
import java.util.List;

public class Team {
    private List<Developer> developers = new ArrayList<>();

    public void addDeveloper(Developer developer){
        System.out.println("Add developer [" + developer.getClass().getName() + "]to the the team");
        developers.add(developer);
    }

    public void removeDeveloper(Developer developer){
        System.out.println("Remove developer [" + developer.getClass().getSimpleName() + "]from the the team");
        developers.remove(developer);
    }

    public void createProject() {
        System.out.println("Team of [" + developers.size() + "] developers creates project");
        developers.forEach(Developer::writeCode);
    }
}
