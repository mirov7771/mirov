package com.example.patterns.iterator;

public interface Collection {
    Iterator getIterator();
}
