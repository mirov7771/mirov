package com.example.patterns.bridge;

import org.springframework.stereotype.Component;

@Component
public class ProgramCreator {
    public void program(String[] args){
        Program[] programs = {
                new BankSystem(new JavaDeveloper()),
                new StockBirgeSystem(new DotNetDeveloper())
        };

        for(Program program : programs){
            program.developProgram();
        }
    }

}

