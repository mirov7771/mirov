package com.example.patterns.bridge;

public class StockBirgeSystem extends Program{

    public StockBirgeSystem(Developer developer) {
        super(developer);
    }

    @Override
    public void developProgram() {
        System.out.println("Stock Exchange development in progress...");
        developer.writeCode();
    }
}
