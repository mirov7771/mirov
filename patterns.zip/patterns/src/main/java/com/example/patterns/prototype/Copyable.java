package com.example.patterns.prototype;

public interface Copyable {
    Object copy();
}
