package com.example.patterns.composite;

import org.springframework.stereotype.Component;

@Component
public class Project {
    public void execute(){
        Team team = new Team();

        Developer javaDeveloper1 = new JavaDeveloper();
        Developer javaDeveloper2 = new JavaDeveloper();

        Developer cppDeveloper = new CppDeveloper();

        team.addDeveloper(javaDeveloper1);
        team.addDeveloper(javaDeveloper2);
        team.addDeveloper(cppDeveloper);

        team.createProject();

        team.removeDeveloper(javaDeveloper2);

        team.createProject();
    }
}
