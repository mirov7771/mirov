package com.example.patterns.builder;

import com.example.patterns.Cms;

public class EnterpriseWebSiteBuilder extends WebSiteBuilder {

    @Override
    void buildName() {
        webSite.setName("Enterprise");
    }

    @Override
    void buildCms() {
        webSite.setCms(Cms.ALIFRESCO);
    }

    @Override
    void buildPrice() {
        webSite.setPrice(1000);
    }
}
