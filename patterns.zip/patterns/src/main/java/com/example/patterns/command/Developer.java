package com.example.patterns.command;

public class Developer {
    private final Command insert;
    private final Command delete;
    private final Command update;
    private final Command select;

    public Developer(Command insert,
                     Command delete,
                     Command update,
                     Command select) {
        this.insert = insert;
        this.delete = delete;
        this.update = update;
        this.select = select;
    }

    public void insert(){
        insert.execute();
    }

    public void delete(){
        delete.execute();
    }

    public void update(){
        update.execute();
    }

    public void select(){
        select.execute();
    }
}
