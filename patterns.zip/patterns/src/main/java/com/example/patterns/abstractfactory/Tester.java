package com.example.patterns.abstractfactory;

public interface Tester {
    void testCode();
}
