package com.example.patterns.interpreter;

public interface Expression {
    boolean interpret(String context);
}
