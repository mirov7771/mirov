package com.example.patterns.composite;

public interface Developer {
    void writeCode();
}
