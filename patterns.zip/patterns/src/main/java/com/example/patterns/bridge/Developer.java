package com.example.patterns.bridge;

public interface Developer {
    void writeCode();
}
