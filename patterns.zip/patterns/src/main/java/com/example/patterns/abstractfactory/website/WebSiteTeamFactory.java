package com.example.patterns.abstractfactory.website;

import com.example.patterns.abstractfactory.Developer;
import com.example.patterns.abstractfactory.ProjectManager;
import com.example.patterns.abstractfactory.ProjectTeamFactory;
import com.example.patterns.abstractfactory.Tester;

public class WebSiteTeamFactory implements ProjectTeamFactory {
    @Override
    public Developer getDeveloper() {
        return new PhpDeveloper();
    }

    @Override
    public Tester getTester() {
        return new AutoTester();
    }

    @Override
    public ProjectManager getProjectManager() {
        return new WebSitePM();
    }
}
