package com.example.patterns.abstractfactory.website;

import com.example.patterns.abstractfactory.Tester;

public class AutoTester implements Tester {
    @Override
    public void testCode() {
        System.out.println("Auto tester writes auto tests...");
    }
}
