package com.example.patterns.templatemethod;

public class NewsPage extends WebsiteTemplate {
    @Override
    public void showContent(){
        System.out.println("News");
    }
}
