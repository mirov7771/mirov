package com.example.patterns.state;

public class Reading implements Activity{
    @Override
    public void justDoIt() {
        System.out.println("Read some book...");
    }
}
