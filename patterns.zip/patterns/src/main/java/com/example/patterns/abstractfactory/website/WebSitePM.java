package com.example.patterns.abstractfactory.website;

import com.example.patterns.abstractfactory.ProjectManager;

public class WebSitePM implements ProjectManager {
    @Override
    public void manageProject() {
        System.out.println("website pm manages website...");
    }
}
