package com.example.patterns.decorator;

public class JavaDeveloper implements Developer{
    @Override
    public String makeJob() {
        return "write Java code...";
    }
}
