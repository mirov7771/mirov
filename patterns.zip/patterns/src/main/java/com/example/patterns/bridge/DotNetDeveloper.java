package com.example.patterns.bridge;

public class DotNetDeveloper implements Developer{
    @Override
    public void writeCode() {
        System.out.println(".Net Developer writes Dot Net code...");
    }
}
