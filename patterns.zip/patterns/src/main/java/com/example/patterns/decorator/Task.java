package com.example.patterns.decorator;

import org.springframework.stereotype.Service;

@Service
public class Task {
    public String taskExecute(){
        Developer developer = new JavaTeamLead(new SeniorJavaDeveloper(new JavaDeveloper()));
        return developer.makeJob();
    }
}
