package com.example.patterns.visitor;

public class JuniorDeveloper implements Developer{
    @Override
    public void create(ProjectClass element) {
        System.out.println("Writing poor code...");
    }

    @Override
    public void create(Database element) {
        System.out.println("Drop database...");
    }

    @Override
    public void create(Test element) {
        System.out.println("Creating not reliable test...");
    }
}
