package com.example.patterns.flyweight;

import java.util.HashMap;
import java.util.Map;

public class DeveloperFactory {
    private static final Map<String, Developer> DEVELOPER_MAP = new HashMap<>();

    public Developer getDeveloper(String type){
        Developer developer = DEVELOPER_MAP.get(type);
        if (developer == null){
            switch (type.toLowerCase()){
                case "java":
                    System.out.println("Hiring java developers");
                    developer = new JavaDeveloper();
                    break;
                case "cpp":
                    System.out.println("Hiring c++ developers");
                    developer = new CppDeveloper();
                    break;
                default:
                    throw new RuntimeException("No open vacancies for type " + type + "...");
            }
            DEVELOPER_MAP.put(type, developer);
        }
        return developer;
    }
}
