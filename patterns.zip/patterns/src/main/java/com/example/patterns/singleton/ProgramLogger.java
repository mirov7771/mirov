package com.example.patterns.singleton;

public class ProgramLogger {

    private static ProgramLogger instance;
    private static String logFile = "Start logging \n\r";

    private ProgramLogger(){

    }

    public static synchronized ProgramLogger getInstance(){
        if (instance == null)
            instance = new ProgramLogger();
        return instance;
    }

    public void addLog(String logInfo){
        logFile += logInfo + "\n";
    }

    public void showLogFile(){
        System.out.println(logFile);
    }

}
