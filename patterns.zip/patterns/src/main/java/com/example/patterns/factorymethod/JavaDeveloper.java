package com.example.patterns.factorymethod;

import org.springframework.stereotype.Component;

@Component("java")
public class JavaDeveloper implements Developer{
    @Override
    public void writeCode() {
        System.out.println("Java code write...");
    }
}
