package com.example.patterns.state;

public class Training implements Activity{
    @Override
    public void justDoIt() {
        System.out.println("Training in gym...");
    }
}
