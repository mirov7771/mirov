package com.example.rabbit;

public class RabbitMqRequest {

    public static SmevRes getResponse(String response){
        SmevRes res = new SmevRes();
        res.setRequestId(getTagValue(response, "replyToClientId"));
        res.setErrorCode(getTagValue(response, "ErrorCode"));
        res.setIsSignReject(response.contains("SignReject"));
        res.setFile(getTagValue(response, "filePath"));
        return res;
    }

    private static String getTagValue(String xml, String tag){
        if (xml.contains(tag) && xml.contains("/" + tag))
            return xml.split("<" + tag + ">")[1].split("</" + tag + ">")[0];
        return null;
    }

}
