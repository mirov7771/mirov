package com.example.rabbit;

import lombok.Data;

@Data
public class SmevRes {
    private String requestId;
    private String errorCode;
    private Boolean isSignReject;
    private String file;
}
