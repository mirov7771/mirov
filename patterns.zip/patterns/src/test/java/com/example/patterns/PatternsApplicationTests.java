package com.example.patterns;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatternsApplicationTests {

    @Test
    void contextLoads() {
    }

}
