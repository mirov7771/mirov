package ru.mtsbank.integration.site2.credit.holiday.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import ru.mtsbank.integration.site2.credit.holiday.controllers.request.Request;
import ru.mtsbank.integration.site2.credit.holiday.service.CreditHolidayService;

@RestController
@RequestMapping("site2-credit-holiday")
@Slf4j
@RequiredArgsConstructor
public class ServiceController {

    private final CreditHolidayService creditHolidayService;

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Сервис крединтых каникул."
            , responses = {
            @ApiResponse(responseCode = "0", description = "Успех"),
            @ApiResponse(responseCode = "1", description = "Ошибка")
    })
    public int execute(@RequestBody Request request) {
        int result;
        try {
            creditHolidayService.call(request);
            result = 0;
        } catch (Exception e) {
            log.error("Error in CreditHolidayService: ", e);
            result = 1;
        }
        log.info("Response: {}", result);
        return result;
    }
}
