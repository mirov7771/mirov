package ru.mtsbank.integration.site2.credit.holiday.controllers.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class Request {
    @NotNull
    private String phone;

    private String email;

    @NotNull
    private String code;

    @NotNull
    private Boolean payPercentLoan;

    @NotNull
    private Boolean complianceLimit;

    @NotNull
    private Boolean overdueDebt;

    @NotNull
    private String programCH;

    @NotNull
    private Integer term;

    private List<CreditType> creditTypes;

    @NotNull
    private String reasonReq;

    @NotNull
    private String family;

    @NotNull
    private String name;

    private String fatherName;

    @NotNull
    private String birthDate;

    @NotNull
    private String currentPassport;

    @NotNull
    private String issueDate;

    @NotNull
    private String issueOrgCode;

    @NotNull
    private String issueOrgName;

    private List<File> files;

    @NotNull
    private Boolean flagGiveDoc;

    private Boolean flagChargeCom;

    private Boolean flagCancelGracePer;

    @NotNull
    private Boolean flagAllowPassOthersOrg;

    private String link = null;

    private String mtsRequestId = null;

    public String getPayPercentLoan() {
        return payPercentLoan ? "Y" : "N";
    }

    public String getComplianceLimit() {
        return complianceLimit ? "Y" : "N";
    }

    public String getOverdueDebt() {
        return overdueDebt ? "Y" : "N";
    }

    @Data
    public static class CreditType {
        @NotNull
        private Integer creditType;
        private Integer cardNum;
        private String contractNum;
    }

    @Data
    public static class File {
        @JsonProperty("file")
        private String fileName;
        private String extension;
        @JsonFormat(shape = JsonFormat.Shape.BINARY)
        private byte[] data;


        @Override
        public String toString() {
            return "File{" +
                    "fileName='" + fileName + '\'' +
                    ", extension='" + extension + '\'' +
                    ", data=" + (data == null ? "null" : "...") +
                    '}';
        }
    }

}
