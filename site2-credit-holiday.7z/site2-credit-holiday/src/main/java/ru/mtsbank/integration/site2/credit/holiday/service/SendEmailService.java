package ru.mtsbank.integration.site2.credit.holiday.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.mtsbank.integration.site2.credit.holiday.controllers.request.Request;
import ru.mtsbank.integration.site2.credit.holiday.util.MTSException;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class SendEmailService implements Service {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private final RestTemplate restTemplate;

    @Value("${site2.mjml-service.url}")
    private String mjmlServiceUrl;

    @Value("${site2.mjml-service.template}")
    private String mjmlTemplate;

    @Value("${site2.php-post-service.url}")
    private String phpPostServiceUrl;

    @Value("${site2.php-post-service.from}")
    private String from;

    @Value("${site2.php-post-service.to}")
    private String to;

    @Value("${site2.php-post-service.subject}")
    private String subject;

    @Value("${site2.credit-type-dict}")
    private String creditTypeDictString;

    @Value("${site2.reason-req-dict}")
    private String reasonReqDictString;

    @Value("${site2.reason-req-delimiter}")
    private String reasonReqDelimiter;

    @Value("${site2.program-ch}")
    private String programChDictString;

    @Value("${logging.show-html}")
    private Boolean showHtml;

    private Map<String, String> creditTypeDict;
    private Map<String, String> reasonReqDict;
    private Map<String, String> programChDict;

    @PostConstruct
    @SuppressWarnings("unchecked")
    private void parseCreditTypeDict() {
        try {
            creditTypeDict = objectMapper.readValue(creditTypeDictString, Map.class);
            reasonReqDict = objectMapper.readValue(reasonReqDictString, Map.class);
            programChDict = objectMapper.readValue(programChDictString, Map.class);
        } catch (JsonProcessingException e) {
            throw new MTSException("Error while parsing credit type dictionary", e);
        }
    }


    @Override
    @SuppressWarnings("unchecked")
    public void call(Request request) {
        log.info("SendEmailService started");
        log.trace("SendEmailService input: {}", request);
        try {
            Map<String, Object> mjmlReq = createMjmlRequest(request);
            Map<String, Object> htmlRes = restTemplate.postForObject(mjmlServiceUrl, mjmlReq, Map.class);
            String preparedHtml = "preparedHtml";
            if (htmlRes == null || htmlRes.get(preparedHtml) == null
                    || ((Map<String, Object>) htmlRes.get(preparedHtml)).get("html") == null
                    || ((Map<String, Object>) htmlRes.get(preparedHtml)).get("errors") != null
                    && !((List<?>) ((Map<String, Object>) htmlRes.get(preparedHtml)).get("errors")).isEmpty()) {
                log.error("Bad response from mjml-service: {}", htmlRes);
                throw new MTSException("Bad response from mjml-service");
            }
            String html = (String) ((Map<String, Object>) htmlRes.get(preparedHtml)).get("html");
            log.debug("Html response: {}", showHtml ? html : "<html is too big for log>");
            String fullName = request.getFamily() + " " + request.getName() + (request.getFatherName() != null ? " " + request.getFatherName() : "");
            Map<String, Object> phpReq = createPhpRequest(fullName, html, request.getMtsRequestId());
            Map<String, Object> status = restTemplate.postForObject(phpPostServiceUrl, phpReq, Map.class);
            if (status != null && status.get("meta") != null &&
                    ((Map<String, Object>) status.get("meta")).get("error") != null && ((Integer) ((Map<String, Object>) status.get("meta")).get("error")) != 0) {
                log.error("Bad response from PHP-Service: {}", status);
                throw new MTSException("Bad response from PHP-Service");
            }
        } catch (Exception e) {
            throw new MTSException("Error in SendEmailService", e);
        }
        log.info("SendEmailService finished");
    }

    private Map<String, Object> createMjmlRequest(Request request) {
        Map<String, Object> mjmlReq = new HashMap<>();
        mjmlReq.put("template", mjmlTemplate);
        Map<String, Object> params = new HashMap<>();
        params.put("family", request.getFamily());
        params.put("name", request.getName());
        params.put("fatherName", request.getFatherName());
        params.put("birthDate", request.getBirthDate());
        params.put("phone", request.getPhone());
        params.put("email", request.getEmail());
        params.put("currentPassport", request.getCurrentPassport());
        params.put("issueDate", request.getIssueDate());
        params.put("issueOrgName", request.getIssueOrgName());
        params.put("issueOrgCode", request.getIssueOrgCode());
        params.put("payPercentLoan", request.getPayPercentLoan());
        params.put("complianceLimit", request.getComplianceLimit());
        params.put("overdueDebt", request.getOverdueDebt());
        params.put("programCH", programChDict.get(request.getProgramCH()));
        params.put("term", request.getTerm());
        List<Map<String, Object>> creditTypes = request.getCreditTypes().stream()
                .map(creditTypePojo -> {
                    Map<String, Object> creditTypeMap = new HashMap<>();
                    creditTypeMap.put("name", creditTypeDict.get(creditTypePojo.getCreditType().toString()));
                    if (creditTypePojo.getCardNum() != null) {
                        creditTypeMap.put("cardNum", creditTypePojo.getCardNum());
                    }
                    if (creditTypePojo.getContractNum() != null) {
                        creditTypeMap.put("contractNum", creditTypePojo.getContractNum());
                    }
                    return creditTypeMap;
                })
                .collect(Collectors.toList());
        params.put("creditTypes", creditTypes);
        StringBuilder reasons = new StringBuilder();
        Arrays.stream(request.getReasonReq().split(reasonReqDelimiter))
                .map(s -> reasonReqDict.get(s)).forEach(s -> reasons.append(reasonReqDelimiter).append(s));
        params.put("reasonReq", reasons.toString().substring(1));
        params.put("document", request.getLink() != null ? request.getLink() : "N");
        mjmlReq.put("params", params);
        log.trace("Request to Mjml Converter service: { \"template\": \"template is too big for log\", {}", params); // template не добавлен в лог, потому что парамер template слишком большой, чтобы в Kibana нормально показывались логи
        return mjmlReq;
    }

    private Map<String, Object> createPhpRequest(String fullName, String html, String mtsRequestId) {
        Map<String, Object> data = new HashMap<>();
        data.put("from", from);
        data.put("to", Arrays.asList(to.split(";")));
        data.put("subject", subject.replace("<fullname>", fullName).replace("<mtsRequestId>", mtsRequestId));
        data.put("bodyContentType", "text/html; charset=utf-8");
        Map<String, Object> phpRequest = new HashMap<>();
        phpRequest.put("data", data);
        phpRequest.put("meta", new ArrayList<>());
        data.put("body", showHtml ? html : "html is too big for log");
        log.trace("Request to PHP Send Email service: {}", phpRequest);
        data.put("body", html);
        return phpRequest;
    }
}
