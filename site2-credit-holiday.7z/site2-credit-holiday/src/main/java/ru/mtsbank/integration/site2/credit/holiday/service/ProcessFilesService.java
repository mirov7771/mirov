package ru.mtsbank.integration.site2.credit.holiday.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.gridfs.model.GridFSFile;
import io.nats.streaming.*;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.mtsbank.integration.site2.credit.holiday.controllers.request.Request;
import ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.BankSvcRs;
import ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddrq.*;
import ru.mtsbank.integration.site2.credit.holiday.jaxb.XmlUnmarshaller;
import ru.mtsbank.integration.site2.credit.holiday.util.MTSException;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;

@Component
@Slf4j
public class ProcessFilesService implements Service {

    private static final Base64.Encoder encoder = Base64.getEncoder();
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private final DatatypeFactory datatypeFactory;
    private final GridFsTemplate gridFsTemplate;
    private final RestTemplate restTemplate;
    private final XmlUnmarshaller xmlUnmarshaller;

    @Value("${site2.pdf-compose.url}")
    private String pdfComposeUrl;
    @Value("${site2.pdf-compose.maxPdfSize}")
    private Integer maxPdfSize; // in MB
    @Value("${site2.pdf-compose.prefix}")
    private String prefix;
    @Value("${site2.transport-to-esb.url}")
    private String transportToEsbUrl;
    @Value("${site2.transport-to-esb.spname}")
    private String spName;
    @Value("${site2.transport-to-esb.msg-receiver}")
    private String msgReceiver;
    @Value("${site2.transport-to-esb.msg-type}")
    private String msgType;

    @Value("${site2.nats.url}")
    private String url;
    @Value("${site2.nats.cluster}")
    private String cluster;
    @Value("${site2.nats.topic}")
    private String subject;
    @Value("${site2.nats.timeout}")
    private Integer timeout;


    public ProcessFilesService(GridFsTemplate gridFsTemplate, RestTemplate restTemplate, XmlUnmarshaller xmlUnmarshaller) {
        this.gridFsTemplate = gridFsTemplate;
        this.restTemplate = restTemplate;
        this.xmlUnmarshaller = xmlUnmarshaller;
        try {
            datatypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new MTSException("Can not initialize new DatatypeFactory instance to ProcessFilesService", e);
        }
    }

    @Override
    public void call(Request request) {
        log.info("ProcessFilesService started");
        log.trace("ProcessFilesService input: {}", request);
        try {
            GridFSFile pdf = getPdf(request);
            request.setLink(getLinkFromEsb(pdf, request.getMtsRequestId()));
        } catch (Exception e) {
            throw new MTSException("Error in ProcessFilesService", e);
        }
        log.info("ProcessFilesService finished");
    }

    @SuppressWarnings("unchecked")
    private GridFSFile getPdf(Request request) {
        List<Request.File> files = request.getFiles();
        List<String> fileIds = new ArrayList<>();
        for (Request.File file : files) {
            String filename = request.getMtsRequestId() + "_" + file.getFileName();
            gridFsTemplate.store(new ByteArrayInputStream(file.getData()), filename, file.getExtension());
            fileIds.add(filename);
        }
        log.debug("Files' Ids in GridFS: {}", fileIds);
        Map<String, Object> requestPdfCompose = new HashMap<>();
        requestPdfCompose.put("mongo_files_name", fileIds);

        Map<String, Object> response = restTemplate.postForObject(pdfComposeUrl, requestPdfCompose, Map.class);
        if (response == null) {
            throw new MTSException("Empty response from site2-pdf-compose");
        }
        String rawPdfFileName = (String) response.get("pdf_file");
        GridFSFile rawPdf = gridFsTemplate.findOne(new Query(Criteria.where("filename").is(rawPdfFileName)));
        if (rawPdf == null) {
            log.error("No such PDF file {}", rawPdfFileName);
            throw new MTSException("PDF file not found");
        }
        if (rawPdf.getLength() > maxPdfSize * 1_048_576) {
            log.error("PDF file {} has size over {} MB: {}", rawPdfFileName, maxPdfSize, rawPdf.getLength());
            throw new MTSException("PDF file's size exceeds max size");
        }
        String pdfFileName = prefix + request.getMtsRequestId() + "_" + request.getCurrentPassport();
        return renamePdf(rawPdf, pdfFileName.replaceAll("\\s+", ""));
    }

    private GridFSFile renamePdf(GridFSFile pdf, String newName) {
        try {
            InputStream binaryPdf = gridFsTemplate.getResource(pdf).getInputStream();
            ObjectId newPdf = gridFsTemplate.store(binaryPdf, newName, "pdf", pdf.getMetadata());
            gridFsTemplate.delete(Query.query(Criteria.where("_id").is(pdf.getId())));
            return gridFsTemplate.findOne(Query.query(Criteria.where("_id").is(newPdf)));
        } catch (IOException e) {
            log.error("Error while renaming PDF file in MongoGridFs", e);
            throw new MTSException("Error while renaming PDF file in MongoGridFs", e);
        }
    }

    private String getLinkFromEsb(GridFSFile pdf, String uuid) {
        FDX fileRequest = createEsbReq(pdf);
        String link;
        try {
            Map<String, Object> esbReq = new HashMap<>();
            esbReq.put("uuid", uuid);
            esbReq.put("msg", xmlUnmarshaller.createXml(fileRequest));
            log.debug("Sending file to ESB: {}", esbReq);
            restTemplate.postForObject(transportToEsbUrl, esbReq, Map.class);
            link = getResponseFromEsb(pdf.getFilename(), uuid);
            gridFsTemplate.delete(Query.query(Criteria.where("_id").is(pdf.getId())));
        } catch (Exception e) {
            log.error("Error while getting response from ESB", e);
            throw new MTSException("Error while getting link from ESB ", e);
        }
        return link;
    }

    private FDX createEsbReq(GridFSFile pdf) {
        FileRec fileRec = new FileRec();
        fileRec.setName(pdf.getFilename() + ".pdf");
        fileRec.setFileId(pdf.getFilename());
        fileRec.setData(getData(pdf));
        FileList fileList = new FileList();
        fileList.getFileRec().add(fileRec);
        BankSvcRq bankSvcRq = new BankSvcRq();
        bankSvcRq.setFileList(fileList);
        FDX fdx = new FDX();
        fdx.setBankSvcRq(bankSvcRq);
        ServerInfoType serverInfoType = new ServerInfoType();
        String uuid = UUID.randomUUID().toString();
        serverInfoType.setMsgUID(uuid);
        serverInfoType.setRqUID(uuid);
        serverInfoType.setSPName(spName);
        serverInfoType.setMsgReceiver(msgReceiver);
        serverInfoType.setServerDt(datatypeFactory.newXMLGregorianCalendar(LocalDateTime.now().toString()));
        serverInfoType.setMsgType(msgType);
        fdx.setServerInfo(serverInfoType);
        return fdx;
    }

    private Data getData(GridFSFile pdf) {
        try {
            Data data = new Data();
            InputStream binaryPdfStream = gridFsTemplate.getResource(pdf).getContent();
            byte[] binaryPdf = new byte[(int) pdf.getLength()];
            int readAllBytes = 0;
            while (readAllBytes < pdf.getLength()) {
                int readBytes = binaryPdfStream.read(binaryPdf, readAllBytes, binaryPdf.length);
                if (readBytes == -1) {
                    break;
                } else {
                    readAllBytes += readBytes;
                }
            }
            data.setValue(binaryPdf);
            data.setExtension("PDF");
            data.setAttachmentIsTextData(false);
            return data;
        } catch (IOException e) {
            log.error("Error while getting PDF file from MongoGridFs", e);
            throw new MTSException("Error while getting PDF file from MongoGridFs", e);
        }
    }

    private String getResponseFromEsb(@NonNull String correlationId, String uuid) {
        Options options = new Options.Builder().
                clientId(uuid).
                clusterId(cluster).
                natsUrl(url).
                connectWait(Duration.ofSeconds(timeout)).
                build();
        StreamingConnectionFactory factory = new StreamingConnectionFactory(options);
        try (StreamingConnection connection = factory.createConnection()) {
            log.trace("Connected successfully with ClientId: {}", uuid);
            Instant start = Instant.now();
            AtomicReference<String> link = new AtomicReference<>();
            AtomicReference<MTSException> exception = new AtomicReference<>();
            SubscriptionOptions subscriptionOptions = new SubscriptionOptions.Builder().
                    subscriptionTimeout(Duration.ofSeconds(timeout)).
                    deliverAllAvailable().
                    startWithLastReceived().
                    build();
            MessageHandler messageHandler = m -> {
                log.trace("Get message from NATS: {}", new String(m.getData(), StandardCharsets.UTF_8));
                try {
                    ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FDX fdx = createEsbRes(m.getData());
                    if ("0".equals(fdx.getBankSvcRs().getStatus().getStatusCode())) {
                        String fileId = fdx.getBankSvcRs().getFileList().getFileRec().get(0).getFileId();
                        if (correlationId.equals(fileId)) {
                            log.info("Found message!");
                            link.set(fdx.getBankSvcRs().getFileList().getFileRec().get(0).getLink());
                        }
                    }
                } catch (Exception e) {
                    log.error("Error while parsing message: ", e);
                    exception.set(new MTSException("Error while parsing message", e));
                }
            };
            Subscription nc = connection.subscribe(subject, messageHandler, subscriptionOptions);
            while (link.get() == null && exception.get() == null) {
                if (Duration.between(start, Instant.now()).compareTo(Duration.ofSeconds(timeout)) > 0) {
                    throw new MTSException("Timeout exceeded while getting response from NATS");
                }
            }
            nc.unsubscribe();
            if (exception.get() != null) {
                throw exception.get();
            }
            log.debug("Received link, {}", link.get());
            return link.get();
        } catch (Exception e) {
            throw new MTSException("Error while getting response from NATS", e);
        }
    }

    @SuppressWarnings("unchecked")
    private ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FDX createEsbRes(byte[] m) throws IOException {
        Map<String, Object> res = OBJECT_MAPPER.readValue(m, Map.class);
        ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FDX fdx = new ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FDX();
        Map<String, Object> fdxMap = (Map<String, Object>) res.get("FDX");
        Map<String, Object> serverInfoMap = (Map<String, Object>) fdxMap.get("ServerInfo");
        ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.ServerInfoType serverInfoType = new ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.ServerInfoType();
        serverInfoType.setMsgUID((String) serverInfoMap.get("MsgUID"));
        serverInfoType.setRqUID((String) serverInfoMap.get("RqUID"));
        serverInfoType.setSPName((String) serverInfoMap.get("SPName"));
        serverInfoType.setMsgReceiver((String) serverInfoMap.get("MsgReceiver"));
        serverInfoType.setServerDt(datatypeFactory.newXMLGregorianCalendar(((String) serverInfoMap.get("ServerDt")).replace(' ', 'T')));
        serverInfoType.setMsgType((String) serverInfoMap.get("MsgType"));
        fdx.setServerInfo(serverInfoType);
        Map<String, Object> statusMap = (Map<String, Object>) ((Map<String, Object>) fdxMap.get("BankSvcRs")).get("Status");
        ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FDXStatus status = new ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FDXStatus();
        status.setStatusCode((String) statusMap.get("StatusCode"));
        status.setStatusDesc((String) statusMap.get("StatusDesc"));
        status.setSeverity((String) statusMap.get("Severity"));
        BankSvcRs bankSvcRs = new BankSvcRs();
        bankSvcRs.setStatus(status);
        if ("0".equals(status.getStatusCode())) {
            ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FileRec fileRec = new ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FileRec();
            Map<String, Object> fileRecMap = (Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) fdxMap.get("BankSvcRs")).get("FileList")).get("FileRec");
            fileRec.setFileId((String) fileRecMap.get("FileId"));
            fileRec.setName((String) fileRecMap.get("Name"));
            fileRec.setLink((String) fileRecMap.get("Link"));
            ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FileList fl = new ru.mtsbank.integration.site2.credit.holiday.fileadd.fileaddres.FileList();
            fl.getFileRec().add(fileRec);
            bankSvcRs.setFileList(fl);
        }
        fdx.setBankSvcRs(bankSvcRs);
        log.trace("Generated FDX: {}", xmlUnmarshaller.createXml(fdx));
        return fdx;
    }

}
