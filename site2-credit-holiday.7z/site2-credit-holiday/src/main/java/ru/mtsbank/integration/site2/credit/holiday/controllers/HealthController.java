package ru.mtsbank.integration.site2.credit.holiday.controllers;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.mtsbank.integration.site2.credit.holiday.controllers.health.LivenessHealthIndicator;
import ru.mtsbank.integration.site2.credit.holiday.controllers.health.ReadinessHealthIndicator;

@RestController
@RequestMapping("site2-credit-holiday")
@Slf4j
@RequiredArgsConstructor
public class HealthController {

    private final ReadinessHealthIndicator readinessHealthIndicator;
    private final LivenessHealthIndicator livenessHealthIndicator;

    @GetMapping
    @Operation(hidden = true)
    public String check() {
        return "Application site2-credit-holiday is running";
    }

    @GetMapping(value = "/read", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(hidden = true)
    public Health readiness() {
        return readinessHealthIndicator.health();
    }

    @GetMapping(value = "/live", produces = MediaType.APPLICATION_JSON_VALUE)
    @Operation(hidden = true)
    public Health liveness() {
        return livenessHealthIndicator.health();
    }

}
