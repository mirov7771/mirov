package ru.mtsbank.integration.site2.credit.holiday.dao.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "CH_CLIENTS")
@Data
public class Client {
    @Id
    @Column(name = "MTS_REQUEST_ID")
    private String mtsRequestId;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "CODE")
    private String code;
    @Column(name = "PAY_PERCENT_LOAN")
    private String payPercentLoan;
    @Column(name = "COMPLIANCE_LIMIT")
    private String complianceLimit;
    @Column(name = "OVERDUE_DEBTL")
    private String overdueDebtl;
    @Column(name = "PROGRAM_CH")
    private String programCH;
    @Column(name = "TERM")
    private Integer term;
    @Column(name = "REASON_REQ")
    private String reasonReq;
    @Column(name = "FAMILY")
    private String family;
    @Column(name = "NAME")
    private String name;
    @Column(name = "FATHER_NAME")
    private String fatherName;
    @Column(name = "BIRTH_DATE")
    private Date birthDate;
    @Column(name = "CURRENT_PASSPORT")
    private String currentPassport;
    @Column(name = "ISSUE_DATE")
    private Date issueDate;
    @Column(name = "ISSUE_ORG_CODE")
    private String issueOrgCode;
    @Column(name = "ISSUE_ORG_NAME")
    private String issueOrgName;
    @Column(name = "FLAG_GIVE_DOC")
    private Boolean flagGiveDoc;
    @Column(name = "FLAG_CHARGE_COM")
    private Boolean flagChargeCom;
    @Column(name = "FLAG_CANCEL_GRACE_PER")
    private Boolean flagCancelGracePer;
    @Column(name = "FLAG_ALLOW_PASS_OTHERS_ORG")
    private Boolean flagAllowPassOthersOrg;
}
