package ru.mtsbank.integration.site2.credit.holiday.util;


public class MTSException extends RuntimeException {

    public MTSException() {
    }

    public MTSException(String message) {
        super(message);
    }

    public MTSException(String message, Throwable cause) {
        super(message, cause);
    }

    public MTSException(Throwable cause) {
        super(cause);
    }

}
