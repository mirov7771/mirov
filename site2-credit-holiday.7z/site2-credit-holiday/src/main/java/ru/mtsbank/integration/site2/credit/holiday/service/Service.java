package ru.mtsbank.integration.site2.credit.holiday.service;

import ru.mtsbank.integration.site2.credit.holiday.controllers.request.Request;

public interface Service {
    void call(Request request);
}
