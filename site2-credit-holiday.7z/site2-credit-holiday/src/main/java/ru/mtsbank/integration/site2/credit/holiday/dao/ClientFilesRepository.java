package ru.mtsbank.integration.site2.credit.holiday.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.site2.credit.holiday.dao.model.ClientFile;

@Repository
public interface ClientFilesRepository extends CrudRepository<ClientFile, String> {
}
