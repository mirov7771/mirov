package ru.mtsbank.integration.site2.credit.holiday.dao.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "CH_CLIENT_FILES")
@Data
public class ClientFile implements Serializable {

    @Id
    @Column(name = "MTS_REQUEST_ID")
    private String mtsRequestId;
    @Column(name = "FILE")
    private String fileName;
    @Column(name = "EXTENSION")
    private String extension;
    @Column(name = "DATA")
    private byte[] data;

    @Override
    public String toString() {
        return "ClientFile{" +
                "mtsRequestId='" + mtsRequestId + '\'' +
                ", fileName='" + fileName + '\'' +
                ", extension='" + extension + '\'' +
                ", data=" + (data == null ? "null" : "...") +
                '}';
    }
}
