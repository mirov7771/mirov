package ru.mtsbank.integration.site2.credit.holiday.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.site2.credit.holiday.controllers.request.Request;
import ru.mtsbank.integration.site2.credit.holiday.util.MTSException;

@Component
@Slf4j
@RequiredArgsConstructor
public class CreditHolidayService implements Service {

    private final DatabaseService databaseService;
    private final ProcessFilesService processFilesService;
    private final SendEmailService sendEmailService;


    @Override
    public void call(Request request) {
        log.info("Started Credit Holiday Service");
        log.trace("Input request : {}", request);
        databaseService.call(request);
        if (request.getFiles() != null && !request.getFiles().isEmpty()) {
            try {
                processFilesService.call(request);
            } catch (MTSException e) {
                request.setLink("Error");
            }
        }
        sendEmailService.call(request);
        log.trace("Output request: {}", request);
        log.info("Ended Credit Holiday Service");
    }




}
