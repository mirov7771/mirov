package ru.mtsbank.integration.site2.credit.holiday.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.site2.credit.holiday.dao.model.Client;

import java.math.BigDecimal;

@Repository
public interface ClientsRepository extends CrudRepository<Client, String> {
    @Query(value = "SELECT nextval('client_request_id')", nativeQuery = true)
    public BigDecimal getClientRequestId();
}
