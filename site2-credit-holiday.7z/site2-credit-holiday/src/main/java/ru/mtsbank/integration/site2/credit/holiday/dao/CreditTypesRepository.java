package ru.mtsbank.integration.site2.credit.holiday.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.site2.credit.holiday.dao.model.CreditType;

@Repository
public interface CreditTypesRepository extends CrudRepository<CreditType, String> {
}
