package ru.mtsbank.integration.site2.credit.holiday.dao.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "CH_CREDIT_TYPES")
@Data
public class CreditType implements Serializable {
    @Id
    @Column(name = "MTS_REQUEST_ID")
    private String mtsRequestId;
    @Column(name = "CREDIT_TYPE")
    private Integer type;
    @Column(name = "CARD_NUM")
    private Integer cardNum;
    @Column(name = "CONTRACT_NUM")
    private String contractNum;

}
