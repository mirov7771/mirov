package ru.mtsbank.integration.site2.credit.holiday.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.site2.credit.holiday.controllers.request.Request;
import ru.mtsbank.integration.site2.credit.holiday.dao.ClientFilesRepository;
import ru.mtsbank.integration.site2.credit.holiday.dao.ClientsRepository;
import ru.mtsbank.integration.site2.credit.holiday.dao.CreditTypesRepository;
import ru.mtsbank.integration.site2.credit.holiday.dao.model.Client;
import ru.mtsbank.integration.site2.credit.holiday.dao.model.ClientFile;
import ru.mtsbank.integration.site2.credit.holiday.dao.model.CreditType;
import ru.mtsbank.integration.site2.credit.holiday.util.MTSException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DatabaseService implements Service {


    private final ClientsRepository clientsRepository;
    private final ClientFilesRepository clientFilesRepository;
    private final CreditTypesRepository creditTypesRepository;
    @Value("${request.id.prefix}")
    private String prefix;

    @Override
    public void call(Request request) {
        log.info("DatabaseService started");
        log.trace("DatabaseService input: {}", request);
        try {
            request.setMtsRequestId(generateMtsRequestId());
            saveInDb(request);
        } catch (Exception e) {
            throw new MTSException("Error in DatabaseService", e);
        }
        log.info("DatabaseService finished");
    }

    private String generateMtsRequestId() {
        String id = prefix + clientsRepository.getClientRequestId();
        log.debug("New Request ID: {}", id);
        return id;
    }

    private void saveInDb(Request request) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
        Client client = new Client();
        client.setMtsRequestId(request.getMtsRequestId());
        client.setPhone(request.getPhone());
        client.setEmail(request.getEmail());
        client.setCode(request.getCode());
        client.setPayPercentLoan(request.getPayPercentLoan());
        client.setComplianceLimit(request.getComplianceLimit());
        client.setOverdueDebtl(request.getOverdueDebt());
        client.setProgramCH(request.getProgramCH());
        client.setTerm(request.getTerm());
        client.setReasonReq(request.getReasonReq());
        client.setFamily(request.getFamily());
        client.setName(request.getName());
        client.setFatherName(request.getFatherName());
        client.setCurrentPassport(request.getCurrentPassport());
        try {
            client.setBirthDate(dateFormat.parse(request.getBirthDate()));
            client.setIssueDate(dateFormat.parse(request.getIssueDate()));
        } catch (ParseException e) {
            log.error("Bad birthDate or issueDate format: birthDate : {}, issueDate : {}. Expects dd.MM.yyyy", request.getBirthDate(), request.getIssueDate());
            throw new MTSException("Bad birthDate or issueDate format", e);
        }
        client.setIssueOrgCode(request.getIssueOrgCode());
        client.setIssueOrgName(request.getIssueOrgName());
        client.setFlagGiveDoc(request.getFlagGiveDoc());
        client.setFlagChargeCom(request.getFlagChargeCom());
        client.setFlagCancelGracePer(request.getFlagCancelGracePer());
        client.setFlagAllowPassOthersOrg(request.getFlagAllowPassOthersOrg());
        clientsRepository.save(client);

        List<CreditType> creditTypes = new ArrayList<>();
        for (Request.CreditType clientCredit : request.getCreditTypes()) {
            CreditType creditType = new CreditType();
            creditType.setMtsRequestId(request.getMtsRequestId());
            creditType.setType(clientCredit.getCreditType());
            creditType.setCardNum(clientCredit.getCardNum());
            creditType.setContractNum(clientCredit.getContractNum());
            creditTypes.add(creditType);
        }
        creditTypesRepository.saveAll(creditTypes);
        List<ClientFile> files = new ArrayList<>();
        if (request.getFiles() != null && !request.getFiles().isEmpty()) {
            for (Request.File f : request.getFiles()) {
                ClientFile clientFile = new ClientFile();
                clientFile.setMtsRequestId(request.getMtsRequestId());
                clientFile.setFileName(f.getFileName());
                clientFile.setExtension(f.getExtension());
                clientFile.setData(f.getData());
                files.add(clientFile);
            }
            clientFilesRepository.saveAll(files);
        }
        log.debug("Request {} has saved in DB", request.getMtsRequestId());
        log.trace("Request {} has data: client info - {} # client credit types - {} # client files - {}", request.getMtsRequestId(),
                client, creditTypes, files);
    }

}


