package ru.sbermobile.subscriber.contract.config;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDateTime;
import java.util.UUID;

import static ru.sbermobile.subscriber.contract.controller.util.ResponseBuilder.*;

@Configuration
@RequiredArgsConstructor
public class WebMvcConfig implements WebMvcConfigurer {

    private final RequestInterceptor requestIdInterceptor;

    @Value("${spring.application.name}")
    private String rootPath;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry
                .addInterceptor(requestIdInterceptor)
                .addPathPatterns("/" + rootPath + "/**")
                .excludePathPatterns("/" + rootPath + "/docs/**");
    }

}

@Component
class RequestInterceptor  implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull Object handler) {
        String rqUid = request.getHeader(RQ_UID);
        if (rqUid == null)
            rqUid = UUID.randomUUID().toString();
        String rqTime = request.getHeader(RQ_TM);
        if (rqTime == null)
            rqTime = LocalDateTime.now().toString();
        ThreadContext.put(RQ_UID, rqUid);
        ThreadContext.put(RQ_TM, rqTime);
        String subsystemCode = request.getHeader(SUBSYSTEM_CODE);
        if (StringUtils.hasText(subsystemCode))
            ThreadContext.put(SUBSYSTEM_CODE, subsystemCode);
        return true;
    }

    @Override
    public void afterCompletion(@NonNull HttpServletRequest request,
                                @NonNull HttpServletResponse response,
                                @NonNull  Object handler,
                                Exception ex) throws Exception {
        ThreadContext.clearAll();
    }
}