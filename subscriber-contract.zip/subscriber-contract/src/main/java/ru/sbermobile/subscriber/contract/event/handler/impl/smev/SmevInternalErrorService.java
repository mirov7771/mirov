package ru.sbermobile.subscriber.contract.event.handler.impl.smev;

import org.springframework.stereotype.Component;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;

@Component("smev-internal-error")
public class SmevInternalErrorService extends HandlerService {
    @Override
    public void execute(String requestId) {
        setStatus(requestId, States.SMEV_INTERNAL_ERROR.getId());
    }
}
