package ru.sbermobile.subscriber.contract.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.UUID;

@Data
public class Req {
    private String msisdn;
    private String subsId;
    private String oid;
    private String data;
    private String backLink;
    private String description;
    @JsonIgnore
    private UUID id;
    private String subsSignType;
}
