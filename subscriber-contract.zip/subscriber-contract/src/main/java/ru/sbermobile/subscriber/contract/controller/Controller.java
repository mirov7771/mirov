package ru.sbermobile.subscriber.contract.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sbermobile.subscriber.contract.controller.dto.req.Req;
import ru.sbermobile.subscriber.contract.controller.dto.res.Res;
import ru.sbermobile.subscriber.contract.controller.util.ResponseBuilder;
import ru.sbermobile.subscriber.contract.service.Service;

import static ru.sbermobile.subscriber.contract.controller.util.ResponseBuilder.*;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class Controller {

    private final Service service;

    @Operation(summary = "Метод сохранения договора", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            examples = @ExampleObject(value = "{\n" +
                                    "\"requestId\":\"7726663b-2638-4af9-af96-ee748db3d487\"" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            examples = @ExampleObject(value = "{\n" +
                                    "\"code\": \"ERROR\",\n" +
                                    "\"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = Req.class),
                            examples = @ExampleObject(value = "{" +
                                    "\"msisdn\":\"9876543210\"," +
                                    "\"subsId\":\"2\"," +
                                    "\"oid\":\"1\"," +
                                    "\"data\":\"\"," +
                                    "\"backLink\":\"https://sbermobile.ru\"," +
                                    "\"description\":\"Договор купли-продажи\"" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Res> post(@RequestBody Req req){
        return ResponseBuilder.build(service.post(req));
    }

    @Operation(summary = "Метод получения статуса договора", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            examples = @ExampleObject(value = "{\n" +
                                        "\"requestId\":\"7726663b-2638-4af9-af96-ee748db3d487\"," +
                                        "\"stateId\": 1," +
                                        "\"stateName\":\"Авторизован\"," +
                                        "\"stateDate\": \"2022-01-14T13:13:13.000+0300\"" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            examples = @ExampleObject(value = "{\n" +
                                        "\"code\": \"ERROR\",\n" +
                                        "\"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
    })
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string")),
                    @Parameter(name = "requestId", in = ParameterIn.PATH, description = "Идентификатор запроса", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string"))
            }
    )
    @GetMapping(value = "{requestId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Res> get(@PathVariable String requestId){
        return ResponseBuilder.build(service.get(requestId));
    }

    @GetMapping(value = "version", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getVersion(@Value("${springdoc.version}") String version){
        return ResponseBuilder.build(version);
    }
}
