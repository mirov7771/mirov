package ru.sbermobile.subscriber.contract.gate.client.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.sbermobile.storage.PutDocumentInlineRequest;
import ru.sbermobile.storage.PutDocumentInlineResponse;
import ru.sbermobile.subscriber.contract.gate.client.SoapAPIGate;

import java.math.BigDecimal;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.storage.service}")
    private String serviceUrl;

    @Override
    public PutDocumentInlineResponse putDocumentInline(String fileName, String contentType, byte[] data, String docType, BigDecimal subsId) {
        PutDocumentInlineRequest request = new PutDocumentInlineRequest();
        request.setOverwrite(true);
        request.setName(fileName);
        request.setSubscriberId(subsId);
        request.setDocumentData(data);
        request.setContentType(contentType);
        request.setDocType(docType);
        return (PutDocumentInlineResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, request);
    }
}
