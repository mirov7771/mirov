package ru.sbermobile.subscriber.contract.event.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;

import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class StatusEventListener implements ApplicationListener<StatusEvent> {

    private final Map<String, HandlerService> services;

    @Override
    public void onApplicationEvent(StatusEvent event) {
        log.info("Read event state [{}] for requestId [{}]", event.getState(), event.getRequestId());
        services.get(event.getState()).execute(event.getRequestId());
    }
}
