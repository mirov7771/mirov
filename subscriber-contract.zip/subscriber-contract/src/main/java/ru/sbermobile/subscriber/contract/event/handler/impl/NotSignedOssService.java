package ru.sbermobile.subscriber.contract.event.handler.impl;

import org.springframework.stereotype.Component;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;

@Component("not-signed-oss")
public class NotSignedOssService extends HandlerService {
    @Override
    public void execute(String requestId) {
        setStatus(requestId, States.NOT_SIGNED_OSS.getId());
    }
}
