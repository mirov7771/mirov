package ru.sbermobile.subscriber.contract.gate.client;

import ru.sbermobile.storage.PutDocumentInlineResponse;

import java.math.BigDecimal;

public interface SoapAPIGate {
    PutDocumentInlineResponse putDocumentInline(String fileName, String contentType, byte[] data, String docType, BigDecimal subsId);
}
