package ru.sbermobile.subscriber.contract.event.handler.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDAO;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;
import ru.sbermobile.subscriber.contract.exception.ErrorConstants;
import ru.sbermobile.subscriber.contract.exception.TelecomException;
import ru.sbermobile.subscriber.contract.gate.http.dto.CustomerProfileRes;
import ru.sbermobile.subscriber.contract.gate.smev.ReqResUtil;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component("signed-oss")
@Slf4j
public class SignedOssService extends HandlerService {

    @Autowired
    private AmqpTemplate template;
    @Value("${spring.rabbitmq.queue.send}")
    private String sendQueue;

    @Override
    public void execute(String requestId) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
        DocumentDAO document = getDocument(requestId);
        DocumentDataDAO data = getData(requestId);
        CustomerProfileRes profile = restAPIGate.customerProfile(document.getMsisdn());
        if (profile == null) {
            saveError(document, "Ошибка получения профиля клиента");
            throw new TelecomException(ErrorConstants.CLIENT_PROFILE_NOT_FOUND, null);
        }
        boolean ukep = false;
        if (StringUtils.hasText(document.getSubsSignType())) {
            ukep = document.getSubsSignType().equalsIgnoreCase("UKEP");
        } else if (StringUtils.hasText(profile.getIsEsim())){
            ukep = profile.getIsEsim().equals("Y");
        }
        String fileName = "CC_" + profile.getAccount() + "_" + profile.getContractNum() + "_" + sdf.format(new Date()) + ".pdf";
        try {
            template.convertAndSend(sendQueue, ReqResUtil.createRequest(ukep,
                    requestId,
                    document.getOid(),
                    data.getDocId().toString(),
                    data.getDocUuid().toString(),
                    data.getSigTelecomId().toString(),
                    data.getSigTelecomUuid().toString(),
                    data.getDocPath(),
                    data.getSigTelecomPath(),
                    document.getBackLink(),
                    data.getDocName(),
                    getFormatDate(data.getSignExp() == null ? LocalDateTime.now().plusDays(1) : data.getSignExp()),
                    getFormatDate(LocalDateTime.now())));
            document.setStateId(States.SEND.getId());
            document.setFileName(fileName);
            documentRepository.save(document);
            restAPIGate.setClientOptParam(document.getMsisdn(), document.getStateId());
        } catch (Exception e){
            log.error("Error sending message to RabbitMQ: ", e);
            saveError(document, "Ошибка обращения в адаптер СМЭВ");
        }
    }

    private String getFormatDate(LocalDateTime dateTime){
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
        return dateTime.format(dtf)+"+03:00";
    }
}
