package ru.sbermobile.subscriber.contract.event.handler.impl.smev;

import org.springframework.stereotype.Component;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;

@Component("smev-default-error")
public class SmevDefaultErrorService extends HandlerService {
    @Override
    public void execute(String requestId) {
        setStatus(requestId, States.SMEV_DEFAULT_ERROR.getId());
    }
}
