package ru.sbermobile.subscriber.contract.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;
import ru.sbermobile.subscriber.contract.database.repository.DocumentDataRepository;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.config.StatusEventPublisher;
import ru.sbermobile.subscriber.contract.gate.http.RestAPIGate;
import ru.sbermobile.subscriber.contract.gate.smev.ReqResUtil;
import ru.sbermobile.subscriber.contract.gate.smev.SmevRes;

import java.util.Optional;
import java.util.UUID;

@EnableRabbit
@Component
@RequiredArgsConstructor
@Slf4j
public class RabbitMqListener {

    private final StatusEventPublisher publisher;
    private final RestAPIGate restAPIGate;
    private final DocumentDataRepository documentDataRepository;

    @RabbitListener(queues = "${spring.rabbitmq.queue.receive}")
    public void processQueue1(String message) {
        log.info("Received from queue: " + message);
        SmevRes response = ReqResUtil.getResponse(message);
        if (response.getRequestId() != null) {
            Integer state = null;
            if (response.getErrorCode() != null) {
                if (response.getErrorCode().equals("10")) {
                    state = 5;
                } else if (response.getErrorCode().equals("4")) {
                    state = 6;
                } else if (Boolean.TRUE.equals(response.getIsSignReject())) {
                    state = 7;
                } else if (response.getErrorCode().equals("1")) {
                    state = 10;
                } else if (response.getErrorCode().equals("11")) {
                    state = 11;
                } else if (response.getErrorCode().equals("12")) {
                    state = 12;
                } else if (response.getErrorCode().equals("13")) {
                    state = 13;
                } else if (StringUtils.hasText(response.getErrorCode())) {
                    state = 14;
                }
            } else if (response.getFile() != null) {
                Optional<DocumentDataDAO> optData = documentDataRepository.findById(response.getRequestUid());
                if (optData.isPresent()) {
                    DocumentDataDAO data = optData.get();
                    data.setSigClientId(UUID.randomUUID());
                    data.setSigClientUuid(UUID.randomUUID());
                    data.setSigClientData(restAPIGate.getClientSig(response.getFile()));
                    documentDataRepository.save(data);
                    state = 8;
                }
            }
            if (state != null)
                publisher.publishCustomEvent(response.getRequestId(), States.getSysName(state));
        }
    }

}
