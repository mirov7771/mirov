package ru.sbermobile.subscriber.contract.event.handler.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDAO;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;
import ru.sbermobile.subscriber.contract.exception.TelecomException;

import java.time.LocalDateTime;
import java.util.UUID;

import static ru.sbermobile.subscriber.contract.exception.ErrorConstants.UPLOAD_ERROR;

@Component("authorize")
@Slf4j
public class AuthorizeService extends HandlerService {
    @Override
    public void execute(String requestId) {
        DocumentDAO document = getDocument(requestId);
        DocumentDataDAO data = getData(requestId);
        byte[] sig = restAPIGate.signFile(data.getDocName(), data.getDocData());
        if (sig == null){
            document.setStateId(States.NOT_SIGNED_OSS.getId());
            documentRepository.save(document);
            documentDataRepository.deleteByDocId(UUID.fromString(requestId));
        } else {
            data.setSigTelecomId(UUID.randomUUID());
            data.setSigTelecomUuid(UUID.randomUUID());
            data.setSigTelecomData(sig);
            data.setSignExp(LocalDateTime.now().plusDays(1L));
            data.setDocPath(getFilePath(data.getDocData(), document, UUID.randomUUID() + "_agreement.pdf"));
            data.setSigTelecomPath(getFilePath(sig, document, UUID.randomUUID() + "_signature.sig"));
            document.setStateId(States.SIGNED_OSS.getId());
            documentRepository.save(document);
            documentDataRepository.save(data);
            publisher.publishCustomEvent(requestId, States.SIGNED_OSS.getSysName());
        }
        restAPIGate.setClientOptParam(document.getMsisdn(), document.getStateId());
    }

    private String getFilePath(byte[] data, DocumentDAO dao, String file){
        try {
            return restAPIGate.getFilePath(file, data);
        } catch (Exception e){
            log.error("Error uploading file:", e);
            saveError(dao, "Ошибка сохранения файла для передачи в СМЭВ: " + file);
            throw new TelecomException(UPLOAD_ERROR, null);
        }
    }
}
