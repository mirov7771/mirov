package ru.sbermobile.subscriber.contract.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sbermobile.subscriber.contract.controller.dto.req.Req;
import ru.sbermobile.subscriber.contract.controller.dto.res.Res;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDAO;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;
import ru.sbermobile.subscriber.contract.database.repository.DocumentDataRepository;
import ru.sbermobile.subscriber.contract.database.repository.DocumentRepository;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.config.StatusEventPublisher;
import ru.sbermobile.subscriber.contract.exception.TelecomException;
import ru.sbermobile.subscriber.contract.service.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Base64;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import static ru.sbermobile.subscriber.contract.exception.ErrorConstants.DOCUMENT_NOT_EXISTS;

@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceImpl implements Service {

    private final DocumentRepository documentRepository;
    private final DocumentDataRepository documentDataRepository;
    private final StatusEventPublisher publisher;
    private static final Base64.Decoder decoder = Base64.getDecoder();

    @Override
    public Res post(Req req) {
        log.info("Receive POST request: {}", req);
        Res res = new Res();
        req.setId(UUID.randomUUID());
        saveDocument(req);
        res.setRequestId(req.getId().toString());
        return res;
    }

    @Override
    public Res get(String requestId) {
        Optional<DocumentDAO> document = documentRepository.findById(UUID.fromString(requestId));
        if (document.isEmpty())
            throw new TelecomException(DOCUMENT_NOT_EXISTS, null);

        Res res = new Res();
        res.setRequestId(requestId);
        res.setStateId(document.get().getStateId());
        res.setStateName(States.getName(document.get().getStateId()));
        if (document.get().getStateDate() != null)
            res.setStateDate(Date.from(document.get().getStateDate().atZone(ZoneId.systemDefault()).toInstant()));
        String description = !StringUtils.hasText(document.get().getStateDescription()) ? States.getDescription(document.get().getStateId()) : document.get().getStateDescription();
        res.setStateDescription(description);
        return res;
    }

    private void saveDocument(Req req){
        DocumentDAO documentDAO = new DocumentDAO();
        documentDAO.setId(req.getId());
        documentDAO.setMsisdn(req.getMsisdn());
        documentDAO.setOid(req.getOid());
        documentDAO.setSubsId(req.getSubsId());
        documentDAO.setStateDate(LocalDateTime.now());
        documentDAO.setStateId(States.AUTHORIZE.getId());
        documentDAO.setBackLink(req.getBackLink());
        if (StringUtils.hasText(req.getSubsSignType())) {
            documentDAO.setSubsSignType(req.getSubsSignType());
        }
        documentRepository.save(documentDAO);
        if (StringUtils.hasText(req.getData())){
            DocumentDataDAO dataDAO = new DocumentDataDAO();
            dataDAO.setId(req.getId());
            dataDAO.setDocId(UUID.randomUUID());
            dataDAO.setDocUuid(UUID.randomUUID());
            dataDAO.setDocData(decoder.decode(req.getData()));
            dataDAO.setDocName(req.getDescription());
            documentDataRepository.save(dataDAO);
            publisher.publishCustomEvent(req.getId().toString(), States.AUTHORIZE.getSysName());
        }
    }
}
