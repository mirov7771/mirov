package ru.sbermobile.subscriber.contract.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Date;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Res {
    private String requestId;
    private Integer stateId;
    private String stateName;
    private String stateDescription;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    private Date stateDate;
    private String code;
    private String messageUser;
    private String messageSystem;

    public Res(String code, String messageUser, String messageSystem) {
        this.code = code;
        this.messageUser = messageUser;
        this.messageSystem = messageSystem;
    }
}
