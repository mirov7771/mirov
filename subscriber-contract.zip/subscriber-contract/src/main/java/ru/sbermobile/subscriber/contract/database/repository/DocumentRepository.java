package ru.sbermobile.subscriber.contract.database.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDAO;

import java.util.UUID;

@Repository
public interface DocumentRepository extends CrudRepository<DocumentDAO, UUID> {
}
