package ru.sbermobile.subscriber.contract.gate.http.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import ru.sbermobile.subscriber.contract.exception.TelecomException;
import ru.sbermobile.subscriber.contract.gate.http.RestAPIGate;
import ru.sbermobile.subscriber.contract.gate.client.RestGate;
import ru.sbermobile.subscriber.contract.gate.http.dto.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static ru.sbermobile.subscriber.contract.controller.util.ResponseBuilder.*;
import static ru.sbermobile.subscriber.contract.exception.ErrorConstants.UPLOAD_ERROR;

@Service
@RequiredArgsConstructor
@Slf4j
public class RestAPIGateImpl implements RestAPIGate {

    private final RestGate restGate;
    @Value("${application.octopus.url}")
    private String octopusUrl;
    @Value("${application.signing}")
    private String signingUrl;
    @Value("${application.smev.url}")
    private String smevUrl;
    @Value("${application.octopus.user}")
    private String user;
    @Value("${application.octopus.password}")
    private String password;
    @Value("${application.octopus.opt-param}")
    private String optParamMethod;
    @Value("${application.octopus.customer-profile}")
    private String customerProfileMethod;
    @Value("${application.smev.download}")
    private String downloadMethod;
    @Value("${application.smev.upload}")
    private String uploadMethod;

    @Override
    public CustomerProfileRes customerProfile(String msisdn) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(user, password);
        return restGate.call(CustomerProfileRes.class,
                octopusUrl,
                customerProfileMethod + "/" + msisdn,
                null,
                null,
                HttpMethod.GET,
                headers,
                MediaType.parseMediaType("application/vnd.oracle.adf.action+json"));
    }

    @Override
    public SetClientOptParamRes setClientOptParam(String msisdn, Integer state) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(RQ_UID, UUID.randomUUID().toString());
        headers.set(RQ_TM, LocalDateTime.now().toString());
        headers.set(SUBSYSTEM_CODE, "Sber");
        SetClientOptParamReq req = new SetClientOptParamReq();
        req.setMsisdn(msisdn);
        req.setCodeParam("contractSignStatus");
        req.setValueParam("SIGN_STATUS:" + state);
        return restGate.call(SetClientOptParamRes.class,
                octopusUrl,
                optParamMethod,
                null,
                req,
                HttpMethod.POST,
                headers,
                MediaType.APPLICATION_JSON);
    }

    @Override
    public byte[] signFile(String fileName, byte[] data) {
        try {
            return restGate.upload(byte[].class, signingUrl, fileName, data);
        } catch (Exception e){
            log.error("Error: ", e);
            return null;
        }
    }

    @Override
    public ActivateSubscriberRes activateSubscriber(String msisdn) {
        ActivateSubscriberReq req = new ActivateSubscriberReq();
        req.setName("activateSubscriber");
        req.setParameters(List.of(ActivateSubscriberReq.Parameter.builder().msisdn(msisdn).build(),
                ActivateSubscriberReq.Parameter.builder().subsystemCode("MAP_SM").build()));
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(user, password);
        return restGate.call(ActivateSubscriberRes.class,
                octopusUrl,
                customerProfileMethod,
                null,
                req,
                HttpMethod.POST,
                headers,
                MediaType.parseMediaType("application/vnd.oracle.adf.action+json"));
    }

    @Override
    public byte[] getClientSig(String filePath) {
        try {
            return restGate.call(byte[].class,
                    smevUrl,
                    downloadMethod,
                    Map.of("filePath", filePath),
                    null,
                    HttpMethod.GET,
                    null,
                    MediaType.APPLICATION_JSON);
        } catch (Exception e){
            log.error("Error getting client sig: ", e);
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public String getFilePath(String fileName, byte[] data) {
        Map<String, String> res = restGate.upload(Map.class,
                smevUrl + uploadMethod,
                fileName,
                data);
        if (res.isEmpty() || StringUtils.isEmpty(res.get("filePath")))
            throw new TelecomException(UPLOAD_ERROR, null);
        return res.get("filePath");
    }
}
