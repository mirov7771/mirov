package ru.sbermobile.subscriber.contract.enums;

import lombok.Getter;

@Getter
public enum States {

    AUTHORIZE(1, "Авторизован", "Абонент прошел авторизацию через ЕСИА", "authorize"),
    FORMED(2, "Сформирован", "Договор сформирован", "formed"),
    SIGNED_OSS(3, "Подписан ОСС", "Договор cо стороны Телеком подписан", "signed-oss"),
    SEND(4, "Отправлен абоненту", "Договор отправлен на подписание абоненту в МП Госключ", "send"),
    NOT_SIGNED_OSS(5, "Не подписан ОСС", "Договор не подписан с стороны ТЕЛЕКОМ. Ошибка с подписью телекома", "not-signed-oss"),
    FINISHED(6, "Истек", "Истекло время для подписания документов", "finished"),
    CANCELED(7, "Отказ абонента", "Отказ от подписания с стороны абонента", "canceled"),
    SIGNED_CLIENT(8, "Подписан абонентом", "Договор подписан абонентом", "signed-client"),
    ERROR(9, "Ошибка", "В ходе обработки документа произошла ошибка", "error"),
    SMEV_USER_NOT_FOUND(10, "Ошибка работы со СМЭВ", "Ошибка работы со СМЭВ: Пользователь не найден", "smev-user-not-found"),
    SMEV_INTERNAL_ERROR(11, "Ошибка работы со СМЭВ", "Ошибка работы со СМЭВ: Внутренняя ошибка системы", "smev-internal-error"),
    SMEV_SIGNING_ERROR(12, "Ошибка работы со СМЭВ", "Ошибка работы со СМЭВ: Подпись отправителя запроса не прошла проверку/У пользователя нет УКЭП сертификата", "smev-signing-error"),
    SMEV_SIGN_CHECK_ERROR(13, "Ошибка работы со СМЭВ", "Ошибка работы со СМЭВ: Не удалось проверить подпись отправителя запроса", "smev-sign-check-error"),
    SMEV_DEFAULT_ERROR(14, "Ошибка работы со СМЭВ", "Ошибка работы со СМЭВ", "smev-default-error");

    private final Integer id;
    private final String name;
    private final String description;
    private final String sysName;

    States(Integer id, String name, String description, String sysName) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.sysName = sysName;
    }

    public static String getName(Integer id){
        for(States s : States.values()){
            if (s.getId().equals(id))
                return s.getName();
        }
        return null;
    }

    public static String getSysName(Integer id){
        for(States s : States.values()){
            if (s.getId().equals(id))
                return s.getSysName();
        }
        return null;
    }

    public static String getDescription(Integer id){
        for(States s : States.values()){
            if (s.getId().equals(id))
                return s.getDescription();
        }
        return null;
    }
}
