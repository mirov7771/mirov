package ru.sbermobile.subscriber.contract.controller.util;

import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

public class ResponseBuilder {

    public static final String RQ_UID = "RqUID";
    public static final String RQ_TM = "RqTm";
    public static final String SUBSYSTEM_CODE = "SubsystemCode";

    public static <T> ResponseEntity<T> build(T data) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(RQ_UID, ThreadContext.get(RQ_UID));
        headers.add(RQ_TM, ThreadContext.get(RQ_TM));
        headers.add(SUBSYSTEM_CODE, ThreadContext.get(SUBSYSTEM_CODE));
        return ResponseEntity.ok().headers(headers).body(data);
    }

}
