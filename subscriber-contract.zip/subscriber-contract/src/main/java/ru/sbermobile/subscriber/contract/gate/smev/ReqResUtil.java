package ru.sbermobile.subscriber.contract.gate.smev;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;

@Slf4j
public class ReqResUtil {

    private static final String REQUEST_TYPE_UKEP = "RequestSignUkep";
    private static final String REQUEST_TYPE_CONTRACT = "RequestSigContract";
    private static final String REQUEST_TYPE_UKEP_TNS = "urn://gosuslugi/sig-contract-ukep/1.0.0";
    private static final String REQUEST_TYPE_CONTRACT_TNS = "urn://gosuslugi/sig-contract/1.0.2";

    private static final String REQUEST = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<tns:ClientMessage xsi:schemaLocation=\"urn://x-artefacts-smev-gov-ru/services/service-adapter/types smev-service-adapter-types.xsd\" xmlns:n1=\"http://www.altova.com/samplexml/other-namespace\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:tns=\"urn://x-artefacts-smev-gov-ru/services/service-adapter/types\">\n" +
            "    <tns:itSystem>U468601</tns:itSystem>\n" +
            "    <tns:RequestMessage>\n" +
            "        <tns:RequestMetadata>\n" +
            "            <tns:clientId>%REQUEST_ID%</tns:clientId>\n" +
            "        </tns:RequestMetadata>\n" +
            "        <tns:RequestContent>\n" +
            "            <tns:content>\n" +
            "                <tns:MessagePrimaryContent>\n" +
            "                    <tns:%REQUEST_TYPE% xmlns:tns=\"%REQUEST_TYPE_TNS%\"\n" +
            "                                            Id=\"Q-%Q_ID%\"\n" +
            "                                            routeNumber=\"MNSV03\"\n" +
            "                                            timestamp=\"%DATE%\">\n" +
            "                        <tns:OID>%OID%</tns:OID>\n" +
            "                        <tns:signExp>%SIGN_EXP%</tns:signExp>\n" +
            "                        <tns:descDoc>%DOC_NAME%</tns:descDoc>\n" +
            "                        <tns:Contracts>\n" +
            "                            <tns:Contract>\n" +
            "                                <tns:Document docId=\"%DOC_ID%\" uuid=\"%DOC_UUID%\" mimeType=\"application/pdf\" description=\"%DOC_NAME%\"/>\n" +
            "                                <tns:Signature docId=\"%SIG_ID%\" uuid=\"%SIG_UUID%\"  mimeType=\"application/sig\" description=\"Подпись оператора связи\"/>\n" +
            "                            </tns:Contract>\n" +
            "                        </tns:Contracts>\n" +
            "                        <tns:Backlink>%BACK_LINK%</tns:Backlink>\n" +
            "                    </tns:%REQUEST_TYPE%>\n" +
            "                </tns:MessagePrimaryContent>\n" +
            "                <tns:AttachmentHeaderList>\n" +
            "                    <tns:AttachmentHeader>\n" +
            "                        <tns:Id>%DOC_UUID%</tns:Id>\n" +
            "                        <tns:filePath>%DOC_PATH%</tns:filePath>\n" +
            "                        <tns:TransferMethod>REFERENCE</tns:TransferMethod>\n" +
            "                    </tns:AttachmentHeader>\n" +
            "                    <tns:AttachmentHeader>\n" +
            "                        <tns:Id>%SIG_UUID%</tns:Id>\n" +
            "                        <tns:filePath>%SIG_PATH%</tns:filePath>\n" +
            "                        <tns:TransferMethod>REFERENCE</tns:TransferMethod>\n" +
            "                    </tns:AttachmentHeader>\n" +
            "                </tns:AttachmentHeaderList>\n" +
            "            </tns:content>\n" +
            "        </tns:RequestContent>\n" +
            "    </tns:RequestMessage>\n" +
            "</tns:ClientMessage>";

    public static String createRequest(Boolean isEsim,
                                       String requestId,
                                       String oid,
                                       String docId,
                                       String docUuid,
                                       String sigId,
                                       String sigUuid,
                                       String docPath,
                                       String sigPath,
                                       String backLink,
                                       String docName,
                                       String signExp,
                                       String currDate){
        String request = REQUEST.replace("%REQUEST_ID%", nvl(requestId, ""))
                .replace("%Q_ID%", UUID.randomUUID().toString())
                .replace("%OID%", nvl(oid, ""))
                .replace("%DOC_ID%", nvl(docId, ""))
                .replace("%DOC_UUID%", nvl(docUuid, ""))
                .replace("%SIG_ID%", nvl(sigId, ""))
                .replace("%SIG_UUID%", nvl(sigUuid, ""))
                .replace("%DOC_PATH%", nvl(docPath, ""))
                .replace("%SIG_PATH%", nvl(sigPath, ""))
                .replace("%BACK_LINK%", nvl(backLink, ""))
                .replace("%DOC_NAME%", nvl(docName, ""))
                .replace("%DATE%", nvl(currDate, ""));
        request = request.replace("%SIGN_EXP%", nvl(signExp, ""));
        if (Boolean.TRUE.equals(isEsim)) {
            request = request.replace("%REQUEST_TYPE%", REQUEST_TYPE_UKEP)
                    .replace("%REQUEST_TYPE_TNS%", REQUEST_TYPE_UKEP_TNS);
        } else {
            request = request.replace("%REQUEST_TYPE%", REQUEST_TYPE_CONTRACT)
                    .replace("%REQUEST_TYPE_TNS%", REQUEST_TYPE_CONTRACT_TNS);
        }
        log.info("Request in Rabbit MQ {}", request);
        return request;
    }

    public static SmevRes getResponse(String response){
        SmevRes res = new SmevRes();
        res.setRequestId(getTagValue(response, "replyToClientId"));
        res.setErrorCode(getTagValue(response, "ErrorCode"));
        res.setIsSignReject(response.contains("SignReject"));
        res.setFile(
                getTagValue(response, "Id") + "/" +
                        getTagValue(response, "clientId") + "/" +
                        getTagValue(response, "filePath")
        );
        return res;
    }

    private static String getTagValue(String xml, String tag){
        if (xml.contains(tag) && xml.contains("/" + tag))
            return xml.split("<" + tag + ">")[1].split("</" + tag + ">")[0];
        return null;
    }

    private static String nvl(String a, String b) {
        return a == null ? b : a;
    }

}
