package ru.sbermobile.subscriber.contract.database.dao;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "DOCUMENT")
@Getter
@Setter
public class DocumentDAO implements Serializable {

    private static final long serialVersionUID = -7998091853535130067L;

    @Id
    @Column(name = "ID")
    private UUID id;
    @Column(name = "MSISDN")
    private String msisdn;
    @Column(name = "SUBS_ID")
    private String subsId;
    @Column(name = "OID")
    private String oid;
    @Column(name = "STATE_ID")
    private Integer stateId;
    @Column(name = "STATE_DESCRIPTION")
    private String stateDescription;
    @Column(name = "STATE_DATE")
    private LocalDateTime stateDate;
    @Column(name = "BACK_LINK")
    private String backLink;
    @Column(name = "FILE_NAME")
    private String fileName;
    @Column(name = "SUBS_SIGN_TYPE")
    private String subsSignType;

}
