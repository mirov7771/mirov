package ru.sbermobile.subscriber.contract.gate.http;

import ru.sbermobile.subscriber.contract.gate.http.dto.ActivateSubscriberRes;
import ru.sbermobile.subscriber.contract.gate.http.dto.CustomerProfileRes;
import ru.sbermobile.subscriber.contract.gate.http.dto.SetClientOptParamRes;

public interface RestAPIGate {
    CustomerProfileRes customerProfile(String msisdn);
    SetClientOptParamRes setClientOptParam(String msisdn, Integer state);
    byte[] signFile(String fileName, byte[] data);
    ActivateSubscriberRes activateSubscriber(String msisdn);
    byte[] getClientSig(String filePath);
    String getFilePath(String fileName, byte[] data);
}
