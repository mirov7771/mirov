package ru.sbermobile.subscriber.contract.gate.client;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import java.util.Map;

public interface RestGate {
    <T> T call(Class<T> answerClass,
               String url,
               String method,
               Map<String, Object> queryParams,
               Object body,
               HttpMethod action,
               HttpHeaders headers,
               MediaType contentType);

    <T> T upload(Class<T> answerClass, String url, String fileName, byte[] data);
}
