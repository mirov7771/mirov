package ru.sbermobile.subscriber.contract.exception;

public class ErrorConstants {
    public static final String ERROR = "ERROR";
    public static final String MISSING_REQUIRED_PARAMS = "Не переданы обязательные параметры";
    public static final String SERVICE_NOT_AVAILABLE = "Сервис временно недоступен";
    public static final String DOCUMENT_NOT_EXISTS = "Документа не существует";
    public static final String CLIENT_PROFILE_NOT_FOUND = "Профиль клиента не найден";
    public static final String UPLOAD_ERROR = "Ошибка сохранения файла";
}
