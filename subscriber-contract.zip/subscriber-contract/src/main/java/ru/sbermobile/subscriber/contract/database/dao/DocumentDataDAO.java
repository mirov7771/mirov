package ru.sbermobile.subscriber.contract.database.dao;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "DOCUMENT_DATA")
@Getter
@Setter
public class DocumentDataDAO implements Serializable {

    private static final long serialVersionUID = -6226638805110244114L;

    @Id
    @Column(name = "ID")
    private UUID id;
    @Column(name = "DOC_ID")
    private UUID docId;
    @Column(name = "DOC_UUID")
    private UUID docUuid;
    @Column(name = "SIGN_EXP")
    private LocalDateTime signExp;
    @Lob
    @Type(type="org.hibernate.type.BinaryType")
    @Column(name="DOC_DATA")
    private byte[] docData;
    @Column(name = "DOC_PATH")
    private String docPath;
    @Column(name = "DOC_NAME")
    private String docName;
    @Column(name = "SIG_TELECOM_ID")
    private UUID sigTelecomId;
    @Column(name = "SIG_TELECOM_UUID")
    private UUID sigTelecomUuid;
    @Lob
    @Type(type="org.hibernate.type.BinaryType")
    @Column(name="SIG_TELECOM_DATA")
    private byte[] sigTelecomData;
    @Column(name = "SIG_TELECOM_PATH")
    private String sigTelecomPath;
    @Column(name = "SIG_CLIENT_ID")
    private UUID sigClientId;
    @Column(name = "SIG_CLIENT_UUID")
    private UUID sigClientUuid;
    @Lob
    @Type(type="org.hibernate.type.BinaryType")
    @Column(name="SIG_CLIENT_DATA")
    private byte[] sigClientData;

}
