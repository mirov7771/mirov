package ru.sbermobile.subscriber.contract.service;

import ru.sbermobile.subscriber.contract.controller.dto.req.Req;
import ru.sbermobile.subscriber.contract.controller.dto.res.Res;

public interface Service {
    Res post(Req req);
    Res get(String requestId);
}
