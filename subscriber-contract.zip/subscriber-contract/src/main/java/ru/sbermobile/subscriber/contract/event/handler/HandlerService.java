package ru.sbermobile.subscriber.contract.event.handler;

import org.springframework.beans.factory.annotation.Autowired;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDAO;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;
import ru.sbermobile.subscriber.contract.database.repository.DocumentDataRepository;
import ru.sbermobile.subscriber.contract.database.repository.DocumentRepository;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.config.StatusEventPublisher;
import ru.sbermobile.subscriber.contract.exception.TelecomException;
import ru.sbermobile.subscriber.contract.gate.http.RestAPIGate;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static ru.sbermobile.subscriber.contract.exception.ErrorConstants.DOCUMENT_NOT_EXISTS;

public abstract class HandlerService {

    private static final Set<Integer> SMEV_ERROR_STATES = new HashSet<>();

    static {
        SMEV_ERROR_STATES.add(10);
        SMEV_ERROR_STATES.add(11);
        SMEV_ERROR_STATES.add(12);
        SMEV_ERROR_STATES.add(13);
        SMEV_ERROR_STATES.add(14);
    }

    @Autowired
    protected RestAPIGate restAPIGate;
    @Autowired
    protected DocumentDataRepository documentDataRepository;
    @Autowired
    protected DocumentRepository documentRepository;
    @Autowired
    protected StatusEventPublisher publisher;

    public abstract void execute(String requestId);

    protected DocumentDAO getDocument(String requestId){
        Optional<DocumentDAO> documentDAO = documentRepository.findById(UUID.fromString(requestId));
        if (documentDAO.isEmpty())
            throw new TelecomException(DOCUMENT_NOT_EXISTS, null);
        return documentDAO.get();
    }

    protected DocumentDataDAO getData(String requestId){
        Optional<DocumentDataDAO> documentDataDAO = documentDataRepository.findById(UUID.fromString(requestId));
        if (documentDataDAO.isEmpty())
            throw new TelecomException(DOCUMENT_NOT_EXISTS, null);
        return documentDataDAO.get();
    }

    protected void setStatus(String requestId, Integer stateId){
        DocumentDAO document = getDocument(requestId);
        if (SMEV_ERROR_STATES.contains(stateId)) {
            document.setStateId(5);
            document.setStateDescription(States.getDescription(stateId));
            document.setStateDate(LocalDateTime.now());
        } else {
            document.setStateId(stateId);
        }
        documentRepository.save(document);
        restAPIGate.setClientOptParam(document.getMsisdn(), document.getStateId());
        documentDataRepository.deleteByDocId(UUID.fromString(requestId));
    }

    protected void saveError(DocumentDAO dao, String description){
        documentDataRepository.deleteByDocId(dao.getId());
        dao.setStateId(States.ERROR.getId());
        dao.setStateDescription(description);
        documentRepository.save(dao);
    }
}
