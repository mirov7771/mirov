package ru.sbermobile.subscriber.contract.database.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;

import javax.transaction.Transactional;
import java.util.UUID;

@Repository
public interface DocumentDataRepository extends CrudRepository<DocumentDataDAO, UUID> {
    @Query(value = "delete from DOCUMENT_DATA where ID = :docId", nativeQuery = true)
    @Transactional
    @Modifying
    void deleteByDocId(@Param("docId") UUID docId);
}
