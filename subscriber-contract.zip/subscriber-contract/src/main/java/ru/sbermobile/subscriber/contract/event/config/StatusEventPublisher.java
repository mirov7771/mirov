package ru.sbermobile.subscriber.contract.event.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class StatusEventPublisher {

    private final ApplicationEventPublisher applicationEventPublisher;

    public void publishCustomEvent(String requestId, String state) {
        log.info("Publishing state [{}] event for [{}]", state, requestId);
        StatusEvent customSpringEvent = new StatusEvent(this, requestId, state);
        applicationEventPublisher.publishEvent(customSpringEvent);
    }

}
