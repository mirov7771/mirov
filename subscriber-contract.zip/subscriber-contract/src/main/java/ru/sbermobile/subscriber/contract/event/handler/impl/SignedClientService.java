package ru.sbermobile.subscriber.contract.event.handler.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDAO;
import ru.sbermobile.subscriber.contract.database.dao.DocumentDataDAO;
import ru.sbermobile.subscriber.contract.enums.States;
import ru.sbermobile.subscriber.contract.event.handler.HandlerService;
import ru.sbermobile.subscriber.contract.gate.client.SoapAPIGate;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Component("signed-client")
@Slf4j
public class SignedClientService extends HandlerService {

    @Autowired
    private SoapAPIGate soapAPIGate;

    @Override
    public void execute(String requestId) {
        log.info("Start signing document for requestId [{}]", requestId);
        DocumentDAO document = getDocument(requestId);
        DocumentDataDAO data = getData(requestId);
        BigDecimal subsId = new BigDecimal(document.getSubsId());

        log.info("Sending documents in S3 for requestId [{}]", requestId);
        CompletableFuture.runAsync(() -> sendToS3(document, data, subsId, requestId));

        log.info("Clearing documents db for requestId [{}]", requestId);
        documentDataRepository.deleteByDocId(UUID.fromString(requestId));
        document.setStateId(States.SIGNED_CLIENT.getId());

        log.info("Update status on [{}] for requestId [{}]", States.SIGNED_CLIENT.getId(), requestId);
        documentRepository.save(document);
        restAPIGate.setClientOptParam(document.getMsisdn(), document.getStateId());
        restAPIGate.activateSubscriber(document.getMsisdn());

        log.info("Finish signing document for requestId [{}]", requestId);
    }

    private void sendToS3(DocumentDAO document, DocumentDataDAO data, BigDecimal subsId, String requestId) {
        try {
            if (data.getDocData() != null) {
                log.info("Start sending PDF {} , for requestId {}", document.getFileName() + ".pdf", requestId);
                soapAPIGate.putDocumentInline(document.getFileName() + ".pdf", "application/pdf", data.getDocData(), "CONTRACT", subsId);
                log.info("End sending PDF {} , for requestId {}", document.getFileName() + ".pdf", requestId);
            }
            if (data.getSigTelecomData() != null) {
                log.info("Start sending Telecom SIG {} , for requestId {}", document.getFileName() + "_1.sig", requestId);
                soapAPIGate.putDocumentInline(document.getFileName() + "_1.sig", "application/sig", data.getSigTelecomData(), "UNKNOWN", subsId);
                log.info("End sending Telecom SIG {} , for requestId {}", document.getFileName() + "_1.sig", requestId);
            }
            if (data.getSigClientData() != null) {
                log.info("Start sending Client SIG {} , for requestId {}", document.getFileName() + "_2.sig", requestId);
                soapAPIGate.putDocumentInline(document.getFileName() + "_2.sig", "application/sig", data.getSigClientData(), "UNKNOWN", subsId);
                log.info("End sending Client SIG {} , for requestId {}", document.getFileName() + "_2.sig", requestId);
            }
        } catch (Exception e) {
            log.error("Error sending docs to S3: ", e);
        }
    }
}
