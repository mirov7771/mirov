package ru.sbermobile.subscriber.contract.gate.http.dto;

import lombok.Data;

@Data
public class SetClientOptParamReq {
    private String msisdn;
    private String codeParam;
    private String valueParam;
}
