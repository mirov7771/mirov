package ru.sbermobile.subscriber.contract.event.config;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class StatusEvent  extends ApplicationEvent {

    private static final long serialVersionUID = -3179864216219502729L;
    private final String requestId;
    private final String state;

    public StatusEvent(Object source,
                       String requestId,
                       String state) {
        super(source);
        this.requestId = requestId;
        this.state = state;
    }

}
