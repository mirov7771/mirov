package ru.sbermobile.subscriber.contract.exception;

import lombok.Getter;

@Getter
public class TelecomException extends RuntimeException {

    private static final long serialVersionUID = 8359430630502179416L;

    private final String messageUser;
    private final String messageSystem;

    public TelecomException(String messageUser, String messageSystem) {
        super(messageUser);
        this.messageUser = messageUser;
        this.messageSystem = messageSystem;
    }
}
