package ru.sbermobile.subscriber.contract.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.sbermobile.subscriber.contract.controller.dto.res.Res;

import static ru.sbermobile.subscriber.contract.exception.ErrorConstants.*;

@ControllerAdvice
@Slf4j
public class ValidationHandler {

    @ExceptionHandler({Exception.class})
    protected ResponseEntity<?> handleException(Exception ex){
        log.error("error in service ", ex);
        Res res;
        if (ex instanceof TelecomException){
            TelecomException e = (TelecomException) ex;
            res = new Res(ERROR, e.getMessage(), e.getMessageSystem());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else if (ex instanceof MissingServletRequestParameterException) {
            MissingServletRequestParameterException e = (MissingServletRequestParameterException) ex;
            res = new Res(ERROR, MISSING_REQUIRED_PARAMS, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else if (ex instanceof MissingRequestHeaderException) {
            MissingRequestHeaderException e = (MissingRequestHeaderException) ex;
            res = new Res(ERROR, MISSING_REQUIRED_PARAMS, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else if (ex instanceof MethodArgumentNotValidException) {
            MethodArgumentNotValidException e = (MethodArgumentNotValidException) ex;
            res = new Res(ERROR, MISSING_REQUIRED_PARAMS, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else {
            res = new Res(ERROR, SERVICE_NOT_AVAILABLE, null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        }
    }

}
