package ru.sbermobile.subscriber.contract.gate.smev;

import lombok.Data;

import java.util.UUID;

@Data
public class SmevRes {
    private String requestId;
    private String errorCode;
    private Boolean isSignReject;
    private String file;

    public UUID getRequestUid(){
        return UUID.fromString(this.requestId);
    }
}
