--liquibase formatted sql
--changeset Mirov AA:init_database
drop table if exists document;
create table document
(
    id uuid default md5(random()::text || clock_timestamp()::text)::uuid primary key,
    msisdn varchar null,
    subs_id varchar null,
    oid varchar null ,
    state_id varchar null ,
    state_date timestamp,
    state_description varchar null ,
    back_link varchar null,
    file_name varchar null
);

drop table if exists document_data;
create table document_data
(
    id uuid primary key,
    doc_id uuid default md5(random()::text || clock_timestamp()::text)::uuid,
    doc_uuid uuid default md5(random()::text || clock_timestamp()::text)::uuid,
    doc_data bytea null,
    doc_path varchar null,
    doc_name varchar null ,
    sign_exp timestamp null,
    sig_telecom_id uuid default md5(random()::text || clock_timestamp()::text)::uuid,
    sig_telecom_uuid uuid default md5(random()::text || clock_timestamp()::text)::uuid,
    sig_telecom_data bytea null,
    sig_telecom_path varchar null,
    sig_client_id uuid default md5(random()::text || clock_timestamp()::text)::uuid,
    sig_client_uuid uuid default md5(random()::text || clock_timestamp()::text)::uuid,
    sig_client_data bytea null
);

alter table document add column if not exists subs_sign_type varchar null;
