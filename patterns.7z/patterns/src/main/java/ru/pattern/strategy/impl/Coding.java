package ru.pattern.strategy.impl;

import ru.pattern.strategy.Activity;

public class Coding implements Activity {

    @Override
    public void justDoIt(){
        System.out.println("Coding...");
    }

}
