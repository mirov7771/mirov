package ru.pattern.strategy.impl;

import ru.pattern.strategy.Activity;

public class Training implements Activity {

    @Override
    public void justDoIt() {
        System.out.println("Training...");
    }

}
