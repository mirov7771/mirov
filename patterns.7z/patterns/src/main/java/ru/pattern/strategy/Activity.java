package ru.pattern.strategy;

public interface Activity {
    void justDoIt();
}
