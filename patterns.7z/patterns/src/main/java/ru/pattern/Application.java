package ru.pattern;

import ru.pattern.adapter.AmericanRadio;
import ru.pattern.adapter.AmericanSocket;
import ru.pattern.adapter.EuropeanAdapter;
import ru.pattern.adapter.EuropeanSocket;
import ru.pattern.decorator.Developer;
import ru.pattern.decorator.impl.JavaDeveloper;
import ru.pattern.decorator.impl.JavaTeamLead;
import ru.pattern.decorator.impl.SeniorJavaDeveloper;
import ru.pattern.facade.BugTracker;
import ru.pattern.facade.Job;
import ru.pattern.facade.WorkFlowFacade;
import ru.pattern.observer.JobSite;
import ru.pattern.observer.Observer;
import ru.pattern.observer.Subscriber;
import ru.pattern.prototype.factory.ProjectFactory;
import ru.pattern.prototype.impl.Project;
import ru.pattern.singleton.Logger;
import ru.pattern.strategy.impl.Reading;
import ru.pattern.strategy.impl.Sleeping;
import ru.pattern.strategy.impl.Training;
import ru.pattern.template_method.NewsPage;
import ru.pattern.template_method.WebsiteTemplate;
import ru.pattern.template_method.WelcomePage;
import ru.pattern.visitor.impl.JuniorDeveloper;
import ru.pattern.visitor.impl.SeniorDeveloper;

import java.util.Date;

public class Application {

    public static void main(String[] args){
        //Decorator example
        Developer developer = new JavaTeamLead(new SeniorJavaDeveloper(new JavaDeveloper()));
        System.out.println(developer.makeJob());

        //Singleton example
        Logger.getLogger().writeLog("Test logger singleton");
        Logger.getLogger().writeLog(new Date().toString());
        Logger.getLogger().showLog();

        //Prototype example
        Project master = new Project(1, "master", "Test code");
        ProjectFactory pf = new ProjectFactory(master);
        Project clone = pf.cloneProject();
        clone.setName("develop");
        System.out.println(master);
        System.out.println(clone);

        //Facade example
        ////without facade
        Job job = new Job();
        job.doJob();
        BugTracker bugTracker = new BugTracker();
        bugTracker.startSprint();
        ru.pattern.facade.Developer developer1 = new ru.pattern.facade.Developer();
        developer1.doJobBeforeDeadline(bugTracker);
        bugTracker.endSprint();
        developer1.doJobBeforeDeadline(bugTracker);
        ////same code with facade
        WorkFlowFacade facade = new WorkFlowFacade();
        facade.solveProblems();

        //Visitor example
        ru.pattern.visitor.impl.Project project = new ru.pattern.visitor.impl.Project();
        ru.pattern.visitor.Developer jun = new JuniorDeveloper();
        ru.pattern.visitor.Developer senior = new SeniorDeveloper();
        System.out.println("\n");
        project.beWritten(jun);
        System.out.println("\n");
        project.beWritten(senior);

        //Template Method example
        WebsiteTemplate welcomePage = new WelcomePage();
        WebsiteTemplate newsPage = new NewsPage();
        System.out.println("\n=======================\n");
        welcomePage.showPage();
        System.out.println("\n=======================\n");
        newsPage.showPage();

        //Strategy example
        ru.pattern.strategy.Developer developer2 = new ru.pattern.strategy.Developer();
        developer2.setActivity(new Training());
        developer2.executeActivity();
        developer2.setActivity(new Reading());
        developer2.executeActivity();
        developer2.setActivity(new Sleeping());
        developer2.executeActivity();

        //State example
        System.out.println("\n=======================\n");
        ru.pattern.state.Developer developer3 = new ru.pattern.state.Developer();
        developer3.setActivity(new ru.pattern.state.impl.Sleeping());
        for(int i=0;i<10;i++){
            developer3.justDoIt();
            developer3.changeActivity();
        }

        //Observer(наблюдатель) example
        JobSite jobSite = new JobSite();
        jobSite.addVacancy("Junior developer");
        jobSite.addVacancy("Senior developer");

        Observer subscriber = new Subscriber("Ivanov I I");
        Observer subsriber2 = new Subscriber("Petrov P P");
        jobSite.addObserver(subscriber);
        jobSite.addObserver(subsriber2);

        jobSite.addVacancy("Team Lead");
        jobSite.removeVacancy("Senior developer");

        //Adapter example
        AmericanSocket americanSocket = new AmericanRadio();
        EuropeanSocket europeanSocket = new EuropeanAdapter(americanSocket);
        europeanSocket.execute();
    }

}
