package ru.pattern.prototype;

public interface Copyable {

    Object copy();

}
