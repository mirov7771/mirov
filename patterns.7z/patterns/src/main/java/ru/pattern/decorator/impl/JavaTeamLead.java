package ru.pattern.decorator.impl;

import ru.pattern.decorator.Developer;
import ru.pattern.decorator.decor.DeveloperDecorator;

public class JavaTeamLead extends DeveloperDecorator {

    public JavaTeamLead(Developer developer){
        super(developer);
    }

    private String sendRepoert(){
        return "Send report to customer";
    }

    @Override
    public String makeJob(){
        return super.makeJob() + " "+sendRepoert();
    }

}
