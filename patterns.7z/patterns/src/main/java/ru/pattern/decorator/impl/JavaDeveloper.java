package ru.pattern.decorator.impl;

import ru.pattern.decorator.Developer;

public class JavaDeveloper implements Developer {

    @Override
    public String makeJob(){
        return "Write code";
    }

}
