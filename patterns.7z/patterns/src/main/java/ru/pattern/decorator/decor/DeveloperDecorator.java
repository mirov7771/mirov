package ru.pattern.decorator.decor;

import ru.pattern.decorator.Developer;

public class DeveloperDecorator implements Developer {

    Developer developer;

    public DeveloperDecorator(Developer developer){
        this.developer = developer;
    }

    @Override
    public String makeJob(){
        return developer.makeJob();
    }

}
