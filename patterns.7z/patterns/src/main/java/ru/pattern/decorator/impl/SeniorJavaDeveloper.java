package ru.pattern.decorator.impl;

import ru.pattern.decorator.Developer;
import ru.pattern.decorator.decor.DeveloperDecorator;

public class SeniorJavaDeveloper extends DeveloperDecorator {

    public SeniorJavaDeveloper(Developer developer){
        super(developer);
    }

    private String makeCodeReview(){
        return "Make code review";
    }

    @Override
    public String makeJob(){
        return super.makeJob() + " "+makeCodeReview();
    }

}
