package ru.pattern.decorator;

public interface Developer {

    String makeJob();

}
