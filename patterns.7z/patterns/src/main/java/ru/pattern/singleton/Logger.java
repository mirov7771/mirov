package ru.pattern.singleton;

public class Logger {

    private static Logger logger;

    private static String log = "Log: \n";
    private Logger(){}

    public static synchronized Logger getLogger(){
        if (logger == null)
            logger = new Logger();
        return logger;
    }

    public void writeLog(String info){
        log += info+"\n";
    }

    public void showLog(){
        System.out.println(log);
    }

}
