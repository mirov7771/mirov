package ru.pattern.facade;

public class Job {

    public void doJob(){
        System.out.println("job in progress");
    }

}
