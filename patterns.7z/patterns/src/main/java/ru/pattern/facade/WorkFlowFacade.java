package ru.pattern.facade;

public class WorkFlowFacade {

    Developer developer = new Developer();
    Job job = new Job();
    BugTracker bugTracker = new BugTracker();

    public void solveProblems() {
        try {
            job.doJob();
            bugTracker.startSprint();
            developer.doJobBeforeDeadline(bugTracker);
            Thread.sleep(250);
        } catch (InterruptedException e){
            e.printStackTrace();
        } finally {
            bugTracker.endSprint();
            developer.doJobBeforeDeadline(bugTracker);
        }
    }

}
