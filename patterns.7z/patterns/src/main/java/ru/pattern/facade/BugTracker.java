package ru.pattern.facade;

public class BugTracker {

    private boolean activeSprint;

    public boolean isActiveSprint(){
        return activeSprint;
    }

    public void startSprint(){
        System.out.println("Sprint is started");
        activeSprint = true;
    }

    public void endSprint(){
        System.out.println("Sprint is endeded");
        activeSprint = false;
    }

}
