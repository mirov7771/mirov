package ru.pattern.visitor;

public interface ProjectElement {

    void beWritten(Developer developer);

}
