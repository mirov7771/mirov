package ru.pattern.visitor;

import ru.pattern.visitor.impl.Database;
import ru.pattern.visitor.impl.ProjectClass;
import ru.pattern.visitor.impl.Test;

public interface Developer {

    void create(ProjectClass projectClass);
    void create(Database database);
    void create(Test test);

}
