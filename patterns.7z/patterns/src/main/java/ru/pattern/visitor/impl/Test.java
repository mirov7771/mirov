package ru.pattern.visitor.impl;

import ru.pattern.visitor.Developer;
import ru.pattern.visitor.ProjectElement;

public class Test implements ProjectElement {

    @Override
    public void beWritten(Developer developer){
        developer.create(this);
    }

}
