package ru.pattern.visitor.impl;

import ru.pattern.visitor.Developer;
import ru.pattern.visitor.ProjectElement;

public class Project implements ProjectElement {

    ProjectElement[] projectElements;

    public Project(){
        projectElements = new ProjectElement[]{
                new ProjectClass(),
                new Database(),
                new Test()
        };
    }

    @Override
    public void beWritten(Developer developer){
        for(ProjectElement pr : projectElements)
            pr.beWritten(developer);
    }

}
