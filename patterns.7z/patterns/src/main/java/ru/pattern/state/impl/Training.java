package ru.pattern.state.impl;

import ru.pattern.state.Activity;

public class Training implements Activity {

    @Override
    public void justDoIt() {
        System.out.println("Training...");
    }
}
