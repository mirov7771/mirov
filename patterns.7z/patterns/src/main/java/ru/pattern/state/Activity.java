package ru.pattern.state;

public interface Activity {

    void justDoIt();

}
