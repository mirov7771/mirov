package ru.pattern.state;

import ru.pattern.state.impl.Coding;
import ru.pattern.state.impl.Reading;
import ru.pattern.state.impl.Sleeping;
import ru.pattern.state.impl.Training;

public class Developer {

    private Activity activity;

    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public void changeActivity(){
        if (activity instanceof Sleeping)
            setActivity(new Training());
        else if (activity instanceof Training)
            setActivity(new Coding());
        else if (activity instanceof Coding)
            setActivity(new Reading());
        else if (activity instanceof Reading)
            setActivity(new Sleeping());
    }

    public void justDoIt(){
        activity.justDoIt();
    }
}
