package ru.pattern.adapter;

public interface EuropeanSocket {

    void execute();

}
