package ru.pattern.adapter;

public class AmericanRadio implements AmericanSocket {

    @Override
    public void execute() {
        System.out.println("Radio played...");
    }
}
