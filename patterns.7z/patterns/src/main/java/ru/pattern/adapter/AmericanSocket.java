package ru.pattern.adapter;

public interface AmericanSocket {

    void execute();

}
