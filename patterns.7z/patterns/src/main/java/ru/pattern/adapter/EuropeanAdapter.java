package ru.pattern.adapter;

public class EuropeanAdapter implements EuropeanSocket {

    AmericanSocket americanSocket;

    public EuropeanAdapter(AmericanSocket americanSocket) {
        this.americanSocket = americanSocket;
    }

    @Override
    public void execute() {
        americanSocket.execute();
    }
}
