package ru.sberx.guide.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "GUIDE_OBJECT")
@Data
public class GuideObject implements Serializable {

    private static final long serialVersionUID = -4195162366039734549L;

    @Id
    @Column(name = "GUIDEID")
    private Long guideId;
    @Column(name = "OBJECTNAME")
    private String objectName;
    @Column(name = "ATTRIBUTENAME")
    private String attributeName;

}
