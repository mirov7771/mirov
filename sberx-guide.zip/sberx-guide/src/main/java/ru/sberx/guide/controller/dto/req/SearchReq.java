package ru.sberx.guide.controller.dto.req;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
public class SearchReq {

    @NotEmpty(message = "Company \"name\" array cannot be empty")
    String[] name;

    @NotNull(message = "\"admin\" param value is required")
    Boolean admin;
}
