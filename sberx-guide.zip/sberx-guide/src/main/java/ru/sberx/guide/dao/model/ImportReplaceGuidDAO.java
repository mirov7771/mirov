package ru.sberx.guide.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "IMPORT_REPLACE_GUID")
@Data
@NoArgsConstructor
public class ImportReplaceGuidDAO implements Serializable {

    private static final long serialVersionUID = 5006166185793471121L;

    @Id
    @Column(name = "VALUE")
    private String value;
    @Column(name = "NAME")
    private String name;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
}
