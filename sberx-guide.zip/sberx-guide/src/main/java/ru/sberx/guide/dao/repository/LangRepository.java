package ru.sberx.guide.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.LangDao;

@Repository
public interface LangRepository extends CrudRepository<LangDao, Long> {
    LangDao findByLocale(String locale);
}
