package ru.sberx.guide.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.BadUrlDAO;

import java.util.List;

@Repository
public interface BadUrlDAORepository extends CrudRepository<BadUrlDAO, String> {

    @NonNull
    @Override
    List<BadUrlDAO> findAll();
}
