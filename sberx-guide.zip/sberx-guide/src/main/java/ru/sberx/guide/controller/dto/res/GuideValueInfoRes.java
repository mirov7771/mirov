package ru.sberx.guide.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.guide.dao.model.Guide;

@Data
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
public class GuideValueInfoRes {
    private Long id;
    private Long code;
    private Long guideId;
    private String name;
    private String sysName;
    private String extra;
    private Boolean isDisabled;
    private String logoFile;
    private String icon;
    private Long rang;
    private String description;

    public GuideValueInfoRes(Guide g) {
        this.id = g.getId();
        this.code = g.getCode();
        this.guideId = g.getGuideId();
        this.name = g.getName();
        this.sysName = g.getSysName();
        this.extra = g.getExtra();
        this.isDisabled = g.getIsDisabled();
        this.logoFile = g.getLogoFile();
        this.icon = g.getIcon();
        this.rang = g.getRang();
    }
}
