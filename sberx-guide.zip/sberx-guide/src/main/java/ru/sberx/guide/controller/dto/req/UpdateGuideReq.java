package ru.sberx.guide.controller.dto.req;

import lombok.Data;

@Data
public class UpdateGuideReq {
    private Long guideId;
    private String newObjectName;
    private String newAttributeName;
    private String locale;
}
