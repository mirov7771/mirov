package ru.sberx.guide.utils;

public class Utils {

    public static String replaceBadСharacters(String name) {
        return name.toUpperCase()
                .replaceAll("^\"|\"$", "")
                .trim()
                .replaceAll(" +", " ")
                .replaceAll("^\"|\"$", "")
                .replaceAll("[^a-zA-Zа-яА-Я0-9- ]", "");
    }

}
