package ru.sberx.guide.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.AbuseDAO;

import java.util.List;

@Repository
public interface AbuseDAORepository extends CrudRepository<AbuseDAO, String> {
    @NonNull
    @Override
    List<AbuseDAO> findAll();
}
