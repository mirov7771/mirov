package ru.sberx.guide.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.ImportReplaceGuidDAO;

import java.util.List;

@Repository
public interface ImportReplaceGuidRepository extends CrudRepository<ImportReplaceGuidDAO, String> {
    @NonNull
    @Override
    List<ImportReplaceGuidDAO> findAll();
    List<ImportReplaceGuidDAO> findImportReplaceGuidDAOByValueStartingWith(String keyword);
    List<ImportReplaceGuidDAO> findImportReplaceGuidDAOByValueStartingWithAndIsDisabled(String keyword, Boolean isDisabled);
    List<ImportReplaceGuidDAO> findByIsDisabled(Boolean isDisabled);
}
