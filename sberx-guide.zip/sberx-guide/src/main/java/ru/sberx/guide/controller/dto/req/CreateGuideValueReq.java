package ru.sberx.guide.controller.dto.req;

import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateGuideValueReq {
    private Long guideId;
    @NotBlank
    private String name;
    private String sysName;
    private String extra;
    private String icon;
    private String logoFile;
    private Boolean isDisabled = false;
    private String locale;
    private String description;
    private Boolean isFilter;
}
