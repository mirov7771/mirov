package ru.sberx.guide.service;

import java.util.List;
import java.util.Map;

import ru.sberx.guide.controller.dto.req.*;
import ru.sberx.guide.controller.dto.res.*;
import ru.sberx.guide.controller.dto.support.Group;
import ru.sberx.guide.controller.dto.support.ReferenceRes;

public interface Service {
    Map<String, List<ReferenceRes>> execute(List<Long> guideId, String locale, Boolean isFilter);
    List<GuideV2Res> execute(List<Long> guideId, List<Long> parentId, List<String> name, List<String> parentName, String locale, Boolean isFilter);
    UpdateGuideRes updateGuide(UpdateGuideReq req);
    UpdateGuideValueRes updateGuideValue(UpdateGuideValueReq req);
    CreateGuideRes createGuide(CreateGuideReq req);
    CreateGuideValueRes createGuideValue(CreateGuideValueReq req);
    List<GuideValueInfoRes> getGuideValueInfo(List<Long> codes, Boolean isFilter);
    FaqListRes getFaqList(FaqListReq req);
    CreateFaqQuestionRes createFaqTheme(CreateFaqQuestionReq req);
    CreateFaqQuestionRes createQuestion(CreateQuestionReq req);
    CreateFaqQuestionRes updateQuestionTheme(Group req);
    CreateFaqQuestionRes updateQuestion(UpdateQuestionReq req);
    CreateFaqQuestionRes deleteFaqQuestionTheme(Long id);
    CreateFaqQuestionRes deleteQuestion(Long id);
    List<Long> guideFilter(List<Long> code);
    AbuseRes abuse(AbuseReq req);
    Boolean urlCheck(String value);
    void updateSearch(SearchReq req);
    SearchRes search(List<String> text, Boolean isDisabled);
}
