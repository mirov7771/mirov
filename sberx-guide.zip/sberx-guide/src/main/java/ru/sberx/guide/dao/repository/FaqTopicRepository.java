package ru.sberx.guide.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.FaqTopic;

import javax.transaction.Transactional;
import java.util.Optional;

@Repository
public interface FaqTopicRepository extends CrudRepository<FaqTopic, Long> {
    Optional<FaqTopic> findByName(String groupName);

    @Modifying
    @Transactional
    @Query("update FaqTopic set name = :groupName where id = :id")
    void updateQuestionTheme(String groupName, Long id);

}
