package ru.sberx.guide.controller.dto.support;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class Group {

    private Long id;
    private String groupName;
    private List<QuestionDto> questions;

}
