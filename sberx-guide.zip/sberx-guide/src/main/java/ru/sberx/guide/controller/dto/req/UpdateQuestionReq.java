package ru.sberx.guide.controller.dto.req;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class UpdateQuestionReq {

    @NotNull
    private Long id;
    private Long topicId;
    private String question;
    private String answer;

}
