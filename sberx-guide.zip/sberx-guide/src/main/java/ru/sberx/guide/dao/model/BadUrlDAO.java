package ru.sberx.guide.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Table(name = "BAD_URL")
@Entity
@Getter
@Setter
public class BadUrlDAO implements Serializable {

    private static final long serialVersionUID = -2703360338233141411L;

    @Id
    @Column(name = "VALUE")
    private String value;
}
