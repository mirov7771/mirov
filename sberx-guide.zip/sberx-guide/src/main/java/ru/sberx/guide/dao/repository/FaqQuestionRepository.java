package ru.sberx.guide.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.FaqQuestion;

import javax.transaction.Transactional;

@Repository
public interface FaqQuestionRepository extends CrudRepository<FaqQuestion, Long> {

    @Modifying
    @Transactional
    @Query("delete from FaqQuestion fq where fq.topicId = :topicId")
    void deleteByTopicId(Long topicId);

    @Modifying
    @Transactional
    @Query("update FaqQuestion fq set fq.answer = :answer, fq.question = :question where fq.topicId = :topicId")
    void updateQuestion(String answer, String question, Long topicId);

}
