package ru.sberx.guide.dao.manager;

import lombok.Data;
import ru.sberx.utils.util.CastUtils;

import java.util.Map;

@Data
public class FaqModel {
    private Long topicId;
    private String name;
    private Long id;
    private String question;
    private String answer;

    public FaqModel(Map<String, Object> row) {
        this.topicId = CastUtils.castToLong(row.get("id1"));
        this.name = CastUtils.castToString(row.get("name"));
        this.id = CastUtils.castToLong(row.get("id2"));
        this.question = CastUtils.castToString(row.get("question"));
        this.answer = CastUtils.castToString(row.get("answer"));
    }
}
