package ru.sberx.guide.controller.dto.req;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class CreateQuestionReq {

    @NotNull
    private Long topicId;
    @NotBlank
    private String answer;
    @NotBlank
    private String question;
    private Integer langId;

}
