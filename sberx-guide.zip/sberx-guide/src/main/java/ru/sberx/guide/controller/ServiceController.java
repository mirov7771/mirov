package ru.sberx.guide.controller;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.guide.builder.ResponseBuilder;
import ru.sberx.guide.controller.dto.req.*;
import ru.sberx.guide.controller.dto.support.Group;
import ru.sberx.guide.service.Service;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class ServiceController {

    private final Service service;
    private final String JSON = "application/json;charset=UTF-8";

    @GetMapping(value = "guide", produces = JSON)
    public ResponseEntity<?> guide(@RequestHeader("requestId") String requestId,
                                   @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                   @RequestParam(value = "guideId", required = false) List<Long> guideId,
                                   @RequestParam(value = "isFilter", required = false) Boolean isFilter) {
        ThreadContext.put("requestId", requestId);
        if (guideId == null || guideId.size() == 0)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "guideId");
        return ResponseBuilder.build(service.execute(guideId, locale, isFilter));
    }

    @PutMapping(value = "guide/{guideId}", produces = JSON)
    public ResponseEntity<?> updateGuide(@RequestHeader("requestId") String requestId,
                                         @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                         @PathVariable(value = "guideId") Long guideId,
                                         @Valid @RequestBody UpdateGuideReq req) {
        ThreadContext.put("requestId", requestId);
        req.setGuideId(guideId);
        req.setLocale(locale);
        return ResponseBuilder.build(service.updateGuide(req));
    }

    @PutMapping(value = "/guide/{guideId}/value/{code}", produces = JSON)
    public ResponseEntity<?> updateGuideValue(@RequestHeader("requestId") String requestId,
                                              @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                              @PathVariable(value = "guideId") Long guideId,
                                              @PathVariable(value = "code") Integer code,
                                              @Valid @RequestBody UpdateGuideValueReq req) {
        ThreadContext.put("requestId", requestId);
        req.setGuideId(guideId);
        req.setCode(code);
        req.setLocale(locale);
        return ResponseBuilder.build(service.updateGuideValue(req));
    }

    @PostMapping(value = "/guide", produces = JSON)
    public ResponseEntity<?> createGuide(@RequestHeader("requestId") String requestId,
                                         @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                         @Valid @RequestBody CreateGuideReq req) {
        ThreadContext.put("requestId", requestId);
        req.setLocale(locale);
        return ResponseBuilder.build(service.createGuide(req));
    }

    @PostMapping(value = "/guide/{guideId}/value", produces = JSON)
    public ResponseEntity<?> createGuideValue(@RequestHeader("requestId") String requestId,
                                              @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                              @PathVariable(value = "guideId") Long guideId,
                                              @Valid @RequestBody CreateGuideValueReq req) {
        ThreadContext.put("requestId", requestId);
        req.setGuideId(guideId);
        req.setLocale(locale);
        return ResponseBuilder.build(service.createGuideValue(req));
    }

    @GetMapping(value = "/guide/values", produces = JSON)
    public ResponseEntity<?> getGuideValueInfo(@RequestHeader("requestId") String requestId,
                                               @RequestParam(name = "code") List<Long> codes,
                                               @RequestParam(value = "isFilter", required = false) Boolean isFilter) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getGuideValueInfo(codes, Boolean.TRUE.equals(isFilter)));
    }

    @GetMapping(value = "v2/guide", produces = JSON)
    public ResponseEntity<?> guideV3(@RequestHeader("requestId") String requestId,
                                     @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                     @RequestParam(value = "guideId", required = false) List<Long> guideId,
                                     @RequestParam(value = "parentId", required = false) List<Long> parentId,
                                     @RequestParam(value = "name", required = false) List<String> name,
                                     @RequestParam(value = "parentName", required = false) List<String> parentName,
                                     @RequestParam(value = "isFilter", required = false) Boolean isFilter) {
        checkParams(requestId, guideId, name, parentId, parentName);
        return ResponseBuilder.build(service.execute(guideId, parentId, name, parentName, locale, isFilter));
    }

    @GetMapping(value = "/faq/list", produces = JSON)
    public ResponseEntity<?> getFaqList(@RequestHeader("requestId") String requestId,
                                        @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                        FaqListReq req) {
        ThreadContext.put("requestId", requestId);
        req.setLocale(locale);
        return ResponseBuilder.build(service.getFaqList(req));
    }

    @PostMapping(value = "/faq/group", produces = JSON)
    public ResponseEntity<?> createFaqQuestion(@RequestHeader("requestId") String requestId,
                                               @Valid @RequestBody CreateFaqQuestionReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createFaqTheme(req));
    }

    @PostMapping(value = "faq/question", produces = JSON)
    public ResponseEntity<?> createQuestion(@RequestHeader("requestId") String requestId,
                                            @Valid @RequestBody CreateQuestionReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createQuestion(req));
    }

    @PutMapping(value = "/faq/group/{id}", produces = JSON)
    public ResponseEntity<?> updateQuestionTheme(@RequestHeader("requestId") String requestId,
                                                 @PathVariable("id") Long id,
                                                 @RequestBody Group req) {
        ThreadContext.put("requestId", requestId);
        req.setId(id);
        return ResponseBuilder.build(service.updateQuestionTheme(req));
    }

    @PutMapping(value = "/faq/question/{id}", produces = JSON)
    public ResponseEntity<?> updateQuestion(@RequestHeader("requestId") String requestId,
                                            @PathVariable("id") Long id,
                                            @RequestBody UpdateQuestionReq req) {
        ThreadContext.put("requestId", requestId);
        req.setId(id);
        return ResponseBuilder.build(service.updateQuestion(req));
    }

    @DeleteMapping(value = "/faq/group/{id}", produces = JSON)
    public ResponseEntity<?> deleteFaqQuestionTheme(@RequestHeader("requestId") String requestId,
                                                    @PathVariable("id") Long id) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.deleteFaqQuestionTheme(id));
    }

    @DeleteMapping(value = "/faq/question/{id}", produces = JSON)
    public ResponseEntity<?> deleteQuestion(@RequestHeader("requestId") String requestId,
                                            @PathVariable("id") Long id) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.deleteQuestion(id));
    }

    @GetMapping(value = "/guide/filter", produces = JSON)
    public ResponseEntity<?> guideFilter(@RequestHeader("requestId") String requestId,
                                         @RequestParam("code") List<Long> code) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.guideFilter(code));
    }

    @PostMapping(value = "/abuse", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> abuse(@RequestBody AbuseReq req) {
        return ResponseBuilder.build(service.abuse(req));
    }


    @GetMapping(value = "/urlcheck", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> urlCheck(@RequestHeader("requestId") String requestId,
                                         @RequestParam("value") String value) {
        if (service.urlCheck(value))
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).header("requestId", requestId).build();
        return ResponseEntity.status(HttpStatus.OK).header("requestId", requestId).build();
    }

    @PutMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateSearch(@RequestHeader("requestId") String requestId,
                                             @RequestBody @Valid SearchReq req) {
        ThreadContext.put("requestId", requestId);
        service.updateSearch(req);
        return ResponseEntity.status(HttpStatus.OK).header("requestId", requestId).build();
    }

    @GetMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> search(@RequestHeader("requestId") String requestId,
                                    @RequestParam(required = false) List<@NotBlank String> text,
                                    @RequestParam(value = "isDisabled", required = false) Boolean isDisabled) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.search(text, isDisabled));
    }


    private void checkParams(String requestId, List<Long> guideId, List<String> name, List<Long> parentId, List<String> parentName) {
        ThreadContext.put("requestId", requestId);
        if (CollectionUtils.isEmpty(guideId) && CollectionUtils.isEmpty(name) && CollectionUtils.isEmpty(parentId) && CollectionUtils.isEmpty(parentName))
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "guideId || name");
    }
}
