package ru.sberx.guide.controller.dto.req;

import lombok.Data;
import ru.sberx.guide.controller.dto.support.QuestionDto;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
public class CreateFaqQuestionReq {

    @NotBlank
    private String groupName;
    private List<QuestionDto> questions;
    private Integer langId;

}
