package ru.sberx.guide.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.guide.controller.dto.req.*;
import ru.sberx.guide.controller.dto.res.*;
import ru.sberx.guide.controller.dto.support.Group;
import ru.sberx.guide.controller.dto.support.QuestionDto;
import ru.sberx.guide.controller.dto.support.ReferenceRes;
import ru.sberx.guide.controller.dto.support.SearchDto;
import ru.sberx.guide.dao.manager.FaqModel;
import ru.sberx.guide.dao.manager.GuideDepModel;
import ru.sberx.guide.dao.manager.GuideModel;
import ru.sberx.guide.dao.manager.QueryManager;
import ru.sberx.guide.dao.model.*;
import ru.sberx.guide.dao.repository.*;
import ru.sberx.guide.service.Service;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.guide.utils.Utils.replaceBadСharacters;

@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceImpl implements Service {

    private final GuideObjectRepository guideObjectRepository;
    private final GuideRepository guideRepository;
    private final QueryManager queryManager;
    private final LangRepository langRepository;
    private final GuideObjectLangRepository guideObjectLangRepository;
    private final GuideLangRepository guideLangRepository;
    private final FaqTopicRepository faqTopicRepository;
    private final FaqQuestionRepository faqQuestionRepository;
    private final AbuseDAORepository abuseDAORepository;
    private final BadUrlDAORepository badUrlDAORepository;
    private final ImportReplaceGuidRepository importReplaceGuidRepository;

    private static final List<String> ABUSE_WORDS = new ArrayList<>();

    @PostConstruct
    public void setAbuse() {
        ABUSE_WORDS.addAll(abuseDAORepository.findAll().stream().map(AbuseDAO::getName).collect(Collectors.toList()));
    }

    @Override
    public Map<String, List<ReferenceRes>> execute(List<Long> guideId, String locale, Boolean isFilter) {
        Map<String, List<ReferenceRes>> res = new HashMap<>();
        List<GuideModel> guides = queryManager.getGuideById(guideId, locale);
        log.info("guides {}", guides);
        for (GuideModel g : guides) {
            List<ReferenceRes> list = new ArrayList<>();
            if (res.get(g.getObjectName()) != null && res.get(g.getObjectName()).size() > 0) {
                list = res.get(g.getObjectName());
            }
            log.info("g {}", g);
            if (isFilter != null) {
                if (isFilter.equals(g.getIsFilter()))
                    list.add(getReferenceRes(g));
            } else {
                list.add(getReferenceRes(g));
            }

            res.put(g.getObjectName(), list);
        }
        return res;
    }

    @Override
    public List<GuideV2Res> execute(List<Long> guideId, List<Long> parentId, List<String> name, List<String> parentName, String locale, Boolean isFilter) {
        List<GuideV2Res> res = new ArrayList<>();
        if (!CollectionUtils.isEmpty(guideId) || !CollectionUtils.isEmpty(name)) {
            List<GuideModel> guides;
            if (!CollectionUtils.isEmpty(guideId)) {
                guides = queryManager.getGuideById(guideId, locale);
            } else {
                guides = queryManager.getGuideByName(name, locale);
            }

            if (!CollectionUtils.isEmpty(guides)) {
                Set<String> names = new HashSet<>();
                for (GuideModel g : guides) {
                    if (!names.contains(g.getObjectName())) {
                        GuideV2Res r = new GuideV2Res();
                        r.setName(g.getGoValue());
                        r.setSysname(g.getObjectName());
                        names.add(g.getObjectName());
                        res.add(r);
                    }
                }

                if (!CollectionUtils.isEmpty(res)) {
                    res.forEach(r -> {
                        for (GuideModel g : guides) {
                            if (r.getSysname().equals(g.getObjectName())) {
                                if (CollectionUtils.isEmpty(r.getValues()))
                                    r.setValues(new ArrayList<>());
                                if (isFilter != null) {
                                    if (isFilter.equals(g.getIsFilter()))
                                        r.getValues().add(getReferenceRes(g));
                                } else {
                                    r.getValues().add(getReferenceRes(g));
                                }
                            }
                        }
                    });
                }
            }
        }
        if (!CollectionUtils.isEmpty(parentId) || !CollectionUtils.isEmpty(parentName)) {
            List<GuideDepModel> guideDeps = queryManager.getGuideDep(parentName, parentId, locale);
            if (!CollectionUtils.isEmpty(guideDeps)) {
                Set<String> names = new HashSet<>();
                for (GuideDepModel dep : guideDeps) {
                    if (!names.contains(dep.getObjectName())) {
                        GuideV2Res r = new GuideV2Res();
                        r.setName(dep.getGoValue());
                        r.setSysname(dep.getObjectName());
                        names.add(dep.getObjectName());
                        res.add(r);
                    }
                }

                if (!CollectionUtils.isEmpty(res)) {
                    res.forEach(r -> {
                        Set<Long> parent = new HashSet<>();
                        for (GuideDepModel g : guideDeps) {
                            if (r.getSysname().equals(g.getObjectName())) {
                                if (!parent.contains(g.getPCode())) {
                                    if (CollectionUtils.isEmpty(r.getValues()))
                                        r.setValues(new ArrayList<>());
                                    r.getValues().add(getReferenceRes(g));
                                    parent.add(g.getPCode());
                                }
                                if (!CollectionUtils.isEmpty(r.getValues())) {
                                    for (ReferenceRes referenceRes : r.getValues()) {
                                        if (referenceRes.getCode().equals(g.getPCode())) {
                                            if (CollectionUtils.isEmpty(referenceRes.getLinked())) {
                                                referenceRes.setLinked(new ArrayList<>());
                                            }
                                            if (isFilter != null) {
                                                if (isFilter.equals(g.getIsFilter())) {
                                                    referenceRes.getLinked().add(getLinkedReferenceRes(g));
                                                }
                                            } else {
                                                referenceRes.getLinked().add(getLinkedReferenceRes(g));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                }
            }
        }
        return res;
    }

    @Override
    public UpdateGuideRes updateGuide(UpdateGuideReq req) {
        Optional<GuideObject> guideObjectOptional = guideObjectRepository.findById(req.getGuideId());
        GuideObject guideObject = guideObjectOptional.orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
        if (!ObjectUtils.isEmpty(req.getNewObjectName())) {
            guideObject.setObjectName(req.getNewObjectName());
        }
        if (!ObjectUtils.isEmpty(req.getNewAttributeName())) {
            guideObject.setAttributeName(req.getNewAttributeName());
            LangDao locale = langRepository.findByLocale(req.getLocale());
            if (locale != null) {
                GuideObjectLang objectLang = guideObjectLangRepository.findByIdAndLangId(req.getGuideId(), locale.getId());
                if (objectLang == null) {
                    objectLang = new GuideObjectLang();
                    objectLang.setId(req.getGuideId());
                    objectLang.setLangId(locale.getId());
                }
                objectLang.setValue(req.getNewAttributeName());
                guideObjectLangRepository.save(objectLang);
            }
        }
        guideObjectRepository.save(guideObject);
        return new UpdateGuideRes(guideObject.getGuideId(), guideObject.getObjectName(), guideObject.getAttributeName());
    }

    @Override
    public UpdateGuideValueRes updateGuideValue(UpdateGuideValueReq req) {
        UpdateGuideValueRes res;
        Optional<Guide> guideObjectCode = guideRepository.findByGuideIdAndCode(req.getGuideId(), req.getCode().longValue());
        Guide guide = guideObjectCode.orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
        if (!ObjectUtils.isEmpty(req.getNewExtra())) {
            guide.setExtra(req.getNewExtra());
        }
        if (!ObjectUtils.isEmpty(req.getNewIcon())) {
            guide.setIcon(req.getNewIcon());
        }
        if (!ObjectUtils.isEmpty(req.getNewLogoFile())) {
            guide.setLogoFile(req.getNewLogoFile());
        }

        if (!ObjectUtils.isEmpty(req.getNewName())) {
            guide.setName(req.getNewName());
            LangDao locale = langRepository.findByLocale(req.getLocale());
            if (locale != null) {
                GuideLang guideLang = guideLangRepository.findByIdAndLangId(guide.getId(), locale.getId());
                if (guideLang == null) {
                    guideLang = new GuideLang();
                    guideLang.setId(guide.getId());
                    guideLang.setLangId(locale.getId());
                }
                guideLang.setValue(req.getNewName());
                guideLang.setDescription(req.getDescription());
                guideLangRepository.save(guideLang);
            }
        }
        if (!ObjectUtils.isEmpty(req.getNewSysName())) {
            guide.setSysName(req.getNewSysName());
        }
        if (req.getIsFilter() != null) {
            guide.setIsFilter(req.getIsFilter());
        }
        guideRepository.save(guide);
        res = new UpdateGuideValueRes(guide);
        res.setDescription(req.getDescription());
        return res;
    }

    @Override
    public CreateGuideRes createGuide(CreateGuideReq req) {
        Optional<GuideObject> guideObjectOptional = guideObjectRepository.findByObjectName(req.getObjectName());
        if (guideObjectOptional.isPresent()) {
            throw new SberxException(SberxErrors.ELEMENT_EXISTS);
        } else {
            GuideObject guideObject = new GuideObject();
            Long maxGuideId = guideObjectRepository.findMaxGuideId().orElse(0L);
            guideObject.setGuideId(maxGuideId + 1000);
            guideObject.setObjectName(req.getObjectName());
            guideObject.setAttributeName(req.getAttributeName());
            guideObject = guideObjectRepository.save(guideObject);
            LangDao locale = langRepository.findByLocale(req.getLocale());
            if (locale != null) {
                GuideObjectLang guideLang = new GuideObjectLang();
                guideLang.setLangId(guideObject.getGuideId());
                guideLang.setValue(guideObject.getAttributeName());
                guideLang.setLangId(locale.getId());
                guideObjectLangRepository.save(guideLang);
            }
            return new CreateGuideRes(guideObject.getGuideId(), guideObject.getObjectName(), guideObject.getAttributeName());
        }
    }

    @Override
    public CreateGuideValueRes createGuideValue(CreateGuideValueReq req) {
        guideObjectRepository.findById(req.getGuideId()).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Не найден по id: ".concat(req.getGuideId().toString())));
        if (StringUtils.hasText(req.getSysName()) && guideRepository.findBySysNameAndGuideId(req.getSysName(), req.getGuideId()).isPresent()) {
            throw new SberxException(SberxErrors.ELEMENT_EXISTS,
                    "В таблице уже существует поле с таким sysname: " + req.getSysName());
        }
        if (StringUtils.hasText(req.getName()) && guideRepository.findByNameAndGuideId(req.getName(), req.getGuideId()).isPresent()) {
            throw new SberxException(SberxErrors.ELEMENT_EXISTS,
                    "В таблице уже существует поле с таким name: " + req.getName());
        }
        Guide guide = new Guide();
        Long maxCode = guideRepository.findMaxCode(req.getGuideId()).orElse(req.getGuideId());
        guide.setCode(maxCode + 1);
        guide.setGuideId(req.getGuideId());
        guide.setName(req.getName());
        guide.setSysName(req.getSysName());
        guide.setExtra(req.getExtra());
        guide.setIcon(req.getIcon());
        guide.setLogoFile(req.getLogoFile());
        guide.setIsDisabled(req.getIsDisabled());
        guide.setIsFilter(Boolean.TRUE.equals(req.getIsFilter()));
        guideRepository.save(guide);

        LangDao locale = langRepository.findByLocale(req.getLocale());
        if (locale != null) {
            GuideLang guideLang = new GuideLang();
            guideLang.setId(guide.getId());
            guideLang.setValue(guide.getName());
            guideLang.setLangId(locale.getId());
            guideLang.setDescription(req.getDescription());
            guideLangRepository.save(guideLang);
        }
        return new CreateGuideValueRes(guide.getId(), guide.getGuideId(), guide.getCode(), guide.getName());
    }

    @Override
    public List<GuideValueInfoRes> getGuideValueInfo(List<Long> codes, Boolean isFilter) {
        if (ObjectUtils.isEmpty(codes)) {
            return List.of();
        }
        return guideRepository.findByCodeIn(codes).stream().map(GuideValueInfoRes::new).collect(Collectors.toList());
    }

    @Override
    public FaqListRes getFaqList(FaqListReq req) {
        List<FaqModel> faqList = queryManager.getFaqList(req);
        FaqListRes res = new FaqListRes();
        Map<String, List<FaqModel>> map = faqList.stream().collect(Collectors.groupingBy(FaqModel::getName, LinkedHashMap::new, Collectors.toList()));
        List<Group> groupResList = new ArrayList<>();
        for (Map.Entry<String, List<FaqModel>> entry : map.entrySet()) {
            Group groupRes = new Group();
            List<FaqModel> faqModelList = entry.getValue();
            if (!CollectionUtils.isEmpty(faqModelList)) {
                groupRes.setId(faqModelList.get(0).getTopicId());
                groupRes.setGroupName(entry.getKey());
                groupRes.setQuestions(faqModelList.stream()
                        .filter(q -> !ObjectUtils.isEmpty(q.getAnswer())
                                && !ObjectUtils.isEmpty(q.getQuestion())
                                && !ObjectUtils.isEmpty(q.getId()))
                        .map(t -> new QuestionDto(t.getId(), t.getQuestion(), t.getAnswer())).collect(Collectors.toList()));
                groupResList.add(groupRes);
            }
        }
        res.setList(groupResList);
        return res;
    }

    @Override
    public CreateFaqQuestionRes createFaqTheme(CreateFaqQuestionReq req) {
        if (faqTopicRepository.findByName(req.getGroupName()).isPresent()) {
            throw new SberxException(SberxErrors.ELEMENT_EXISTS,
                    String.format("В таблице уже существует поле с таким groupName: %s", req.getGroupName()));
        }
        CreateFaqQuestionRes res = new CreateFaqQuestionRes();
        FaqTopic faqTopic = new FaqTopic();
        faqTopic.setName(req.getGroupName());
        faqTopic.setLangId(req.getLangId());
        faqTopicRepository.save(faqTopic);
        if (!CollectionUtils.isEmpty(req.getQuestions())) {
            faqQuestionRepository.saveAll(req.getQuestions().stream()
                    .map(t -> new FaqQuestion(t, faqTopic.getId(), req.getLangId()))
                    .collect(Collectors.toList()));
            res.setId(faqTopic.getId());
        }
        return res;
    }

    @Override
    public CreateFaqQuestionRes createQuestion(CreateQuestionReq req) {
        faqTopicRepository.findById(req.getTopicId()).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND,
                String.format("Не найден по id: %s", req.getTopicId().toString())));
        CreateFaqQuestionRes res = new CreateFaqQuestionRes();
        FaqQuestion faqQuestion = new FaqQuestion();
        faqQuestion.setQuestion(req.getQuestion());
        faqQuestion.setAnswer(req.getAnswer());
        faqQuestion.setTopicId(req.getTopicId());
        faqQuestion.setLangId(req.getLangId());
        res.setId(req.getTopicId());
        faqQuestionRepository.save(faqQuestion);
        return res;
    }

    @Override
    public CreateFaqQuestionRes updateQuestionTheme(Group req) {
        faqTopicRepository.findById(req.getId()).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND,
                String.format("Не найден по id: %s", req.getId().toString())));
        CreateFaqQuestionRes res = new CreateFaqQuestionRes();
        faqTopicRepository.updateQuestionTheme(req.getGroupName(), req.getId());
        if (!CollectionUtils.isEmpty(req.getQuestions())) {
            faqQuestionRepository.deleteByTopicId(req.getId());
            faqQuestionRepository.saveAll(req.getQuestions().stream()
                    .map(t -> new FaqQuestion(t, req.getId()))
                    .collect(Collectors.toList()));
            res.setId(req.getId());
        }
        res.setId(req.getId());
        return res;
    }

    @Override
    public CreateFaqQuestionRes updateQuestion(UpdateQuestionReq req) {
        faqQuestionRepository.findById(req.getId()).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND,
                String.format("Не найден по id: %s", req.getId().toString())));
        CreateFaqQuestionRes res = new CreateFaqQuestionRes();
        if (!ObjectUtils.isEmpty(req.getTopicId())) {
            faqTopicRepository.findById(req.getTopicId()).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND,
                    String.format("Не найден по topicId: %s", req.getTopicId().toString())));
            faqQuestionRepository.updateQuestion(req.getAnswer(), req.getQuestion(), req.getTopicId());
            res.setId(req.getId());
        }
        return res;
    }

    @Override
    public CreateFaqQuestionRes deleteFaqQuestionTheme(Long id) {
        CreateFaqQuestionRes res = new CreateFaqQuestionRes();
        faqTopicRepository.deleteById(id);
        faqQuestionRepository.deleteByTopicId(id);
        res.setId(id);
        return res;
    }

    @Override
    public CreateFaqQuestionRes deleteQuestion(Long id) {
        CreateFaqQuestionRes res = new CreateFaqQuestionRes();
        faqQuestionRepository.deleteById(id);
        res.setId(id);
        return res;
    }

    @Override
    public List<Long> guideFilter(List<Long> code) {
        return queryManager.getGuidesCodes(code);
    }

    @Override
    public AbuseRes abuse(AbuseReq req) {
        AbuseRes res = new AbuseRes();
        res.setState(0);
        res.setObjectId(req.getObjectId());
        res.setFields(new HashMap<>());
        if (req.getFields() != null && !req.getFields().isEmpty() && !CollectionUtils.isEmpty(ABUSE_WORDS)) {
            checkFieldsForAbuse(req.getFields(), null, res);
        }
        return res;
    }

    @Override
    public Boolean urlCheck(String value) {
        List<BadUrlDAO> badUrls = badUrlDAORepository.findAll();
        return StringUtils.hasText(value)
                && badUrls.stream().anyMatch(url -> value.toUpperCase().contains(url.getValue().toUpperCase()));
    }

    @Override
    public void updateSearch(SearchReq req) {
        for (String name : req.getName()) {
            if (StringUtils.hasText(name)) {
                String formattedName = name
                        .toUpperCase(Locale.ROOT).trim().replaceAll(" +", " ");
                if (importReplaceGuidRepository.existsById(formattedName)) {
                    if (Boolean.TRUE.equals(req.getAdmin())) {
                        updateSearchForAdmin(name, formattedName);
                    }
                } else {
                    addNewImportReplaceGuid(name, formattedName);
                }
            }
        }
    }

    @Override
    public SearchRes search(List<String> text, Boolean isDisabled) {
        List<SearchDto> searchResult = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            Iterable<ImportReplaceGuidDAO> all;
            if (Boolean.TRUE.equals(isDisabled))
                all = importReplaceGuidRepository.findAll();
            else
                all = importReplaceGuidRepository.findByIsDisabled(false);
            all.forEach(dao -> searchResult.add(new SearchDto(replaceBadСharacters(dao.getValue()), dao.getName())));
            return new SearchRes(searchResult.stream().sorted(Comparator.comparing(SearchDto::getValue)).collect(Collectors.toList()));
        }

        for (String query : text) {
            String formattedName = query
                    .toUpperCase(Locale.ROOT).trim().replaceAll(" +", " ");
            List<ImportReplaceGuidDAO> matchedValues;
            if (Boolean.TRUE.equals(isDisabled))
                matchedValues = importReplaceGuidRepository.findImportReplaceGuidDAOByValueStartingWith(formattedName);
            else
                matchedValues = importReplaceGuidRepository.findImportReplaceGuidDAOByValueStartingWithAndIsDisabled(formattedName, false);
            if (!matchedValues.isEmpty()) {
                searchResult.addAll(matchedValues
                        .stream()
                        .map(dao -> new SearchDto(replaceBadСharacters(dao.getValue()), dao.getName()))
                        .collect(Collectors.toList()));
            }
        }

        if (searchResult.isEmpty()) {
            return new SearchRes(
                    new ArrayList<>(
                            text.stream().map(
                                            str -> new SearchDto(str.toUpperCase(Locale.ROOT), str))
                                    .sorted(Comparator.comparing(SearchDto::getValue))
                                    .collect(Collectors.toList())));
        } else {
            return new SearchRes(searchResult.stream().sorted(Comparator.comparing(SearchDto::getValue)).collect(Collectors.toList()));
        }
    }

    private void updateSearchForAdmin(String name, String formattedName) {
        Optional<ImportReplaceGuidDAO> value = importReplaceGuidRepository.findById(formattedName);
        if (value.isEmpty()) {
            addNewImportReplaceGuid(formattedName, name);
        } else {
            ImportReplaceGuidDAO dao = value.get();
            if ((dao.getValue() != null && dao.getValue().equals(formattedName))
                    && (dao.getName() == null || !dao.getName().equals(name))) {
                dao.setName(name);
                importReplaceGuidRepository.save(dao);
            }
        }
    }

    private void addNewImportReplaceGuid(String name, String formattedName) {
        ImportReplaceGuidDAO dao = new ImportReplaceGuidDAO();
        dao.setValue(formattedName);
        dao.setName(name);
        dao.setIsDisabled(false);
        importReplaceGuidRepository.save(dao);
    }

    private void addAbuseString(String value, String key, String extraKey, AbuseRes res) {
        if (ABUSE_WORDS.stream().anyMatch(i -> value.toUpperCase().contains(i.toUpperCase()))) {
            res.setState(1);
            res.getFields().put(StringUtils.hasText(extraKey) ? extraKey + "_" + key : key, value);
        }
    }

    @SuppressWarnings("unchecked")
    private void checkFieldsForAbuse(Map<String, Object> value, String extraKey, AbuseRes res) {
        for (Map.Entry<String, Object> entry : value.entrySet()) {
            if (entry.getValue() != null) {
                if (entry.getValue() instanceof String) {
                    addAbuseString((String) entry.getValue(), entry.getKey(), extraKey, res);
                } else if (entry.getValue() instanceof Map) {
                    checkFieldsForAbuse((Map<String, Object>) entry.getValue(), entry.getKey(), res);
                } else {
                    String s = String.valueOf(entry.getValue());
                    addAbuseString(s, entry.getKey(), extraKey, res);
                }
            }
        }
    }

    private ReferenceRes getReferenceRes(GuideModel g) {
        ReferenceRes referenceRes = new ReferenceRes();
        referenceRes.setCode(g.getCode());
        referenceRes.setExtra(g.getExtra());
        referenceRes.setIcon(g.getIcon());
        referenceRes.setName(g.getGValue());
        referenceRes.setRang(g.getRang());
        referenceRes.setLogoFile(g.getLogoFile());
        referenceRes.setSysName(g.getSysName());
        referenceRes.setId(g.getId());
        referenceRes.setDescription(g.getDescription());
        return referenceRes;
    }

    private ReferenceRes getReferenceRes(GuideDepModel g) {
        ReferenceRes referenceRes = new ReferenceRes();
        referenceRes.setCode(g.getPCode());
        referenceRes.setName(g.getPValue());
        referenceRes.setRang(g.getPRang());
        referenceRes.setDescription(g.getDescription());
        return referenceRes;
    }

    private ReferenceRes getLinkedReferenceRes(GuideDepModel g) {
        ReferenceRes referenceRes = new ReferenceRes();
        referenceRes.setCode(g.getCCode());
        referenceRes.setName(g.getCValue());
        referenceRes.setRang(g.getCRang());
        referenceRes.setDescription(g.getDescription());
        return referenceRes;
    }

}
