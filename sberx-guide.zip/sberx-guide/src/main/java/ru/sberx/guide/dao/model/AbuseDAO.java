package ru.sberx.guide.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Table(name = "ABUSE")
@Entity
@Getter
@Setter
public class AbuseDAO implements Serializable {

    private static final long serialVersionUID = -8085583561843351697L;

    @Id
    @Column(name = "NAME")
    private String name;

}
