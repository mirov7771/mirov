package ru.sberx.guide.controller.dto.req;

import lombok.Data;

import java.util.Map;

@Data
public class AbuseReq {
    private Map<String, Object> fields;
    private String objectType;
    private Long objectId;
}
