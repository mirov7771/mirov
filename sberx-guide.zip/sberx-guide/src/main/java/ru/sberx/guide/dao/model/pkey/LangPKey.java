package ru.sberx.guide.dao.model.pkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class LangPKey implements Serializable {
    private static final long serialVersionUID = -2972041910032166295L;
    private Long id;
    private Long langId;
}
