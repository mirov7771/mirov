package ru.sberx.guide.controller.dto.res;

import lombok.AllArgsConstructor;
import lombok.Data;
import ru.sberx.guide.controller.dto.support.SearchDto;

import java.util.List;

@Data
@AllArgsConstructor
public class SearchRes {
    List<SearchDto> values;
}
