package ru.sberx.guide.controller.dto.req;

import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class UpdateGuideValueReq {
    private Long guideId;
    private Integer code;
    @NotBlank
    private String newName;
    private String newSysName;
    private String newExtra;
    private String newIcon;
    private String newLogoFile;
    private Boolean isDisabled = false;
    private String locale;
    private String description;
    private Boolean isFilter;
}
