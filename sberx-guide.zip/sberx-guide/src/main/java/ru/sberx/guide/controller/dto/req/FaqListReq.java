package ru.sberx.guide.controller.dto.req;

import lombok.Data;

@Data
public class FaqListReq {
    private String id;
    private String groupName;
    private String search;
    private String locale;
}
