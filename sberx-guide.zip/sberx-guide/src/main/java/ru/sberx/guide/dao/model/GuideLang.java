package ru.sberx.guide.dao.model;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.guide.dao.model.pkey.LangPKey;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(LangPKey.class)
@Table(name = "GUIDE_LANG")
@Getter
@Setter
public class GuideLang implements Serializable {

    private static final long serialVersionUID = -8085583561843351697L;

    @Id
    @Column(name = "ID")
    private Long id;
    @Column(name = "VALUE")
    private String value;
    @Id
    @Column(name = "LANG_ID")
    private Long langId;
    @Column(name = "DESCRIPTION")
    private String description;

}
