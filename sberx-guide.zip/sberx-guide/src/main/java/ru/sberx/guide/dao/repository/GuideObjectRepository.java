package ru.sberx.guide.dao.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.GuideObject;

@Repository
public interface GuideObjectRepository extends CrudRepository<GuideObject, Long> {

    @Query("from GuideObject where objectName = :objectName")
    Optional<GuideObject> findByObjectName(String objectName);
    @Query("select max(guideId) from GuideObject")
    Optional<Long> findMaxGuideId();

}
