package ru.sberx.guide.dao.model;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.guide.controller.dto.support.Group;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "FAQ_TOPIC")
@Getter
@Setter
public class FaqTopic implements Serializable {

    private static final long serialVersionUID = -8085583561843351697L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "NAME", nullable = false)
    private String name;
    @Column(name = "LANG_ID")
    private Integer langId;

    public Group toDto() {
        Group groupRes = new Group();
        groupRes.setGroupName(this.getName());
        return groupRes;
    }

}
