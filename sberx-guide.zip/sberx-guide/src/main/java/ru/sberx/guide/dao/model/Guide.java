package ru.sberx.guide.dao.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "GUIDE")
@Getter
@Setter
public class Guide implements Serializable {

    private static final long serialVersionUID = -8085583561843351697L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "CODE")
    private Long code;
    @Column(name = "GUIDEID")
    private Long guideId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "SYSNAME")
    private String sysName;
    @Column(name = "EXTRA")
    private String extra;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "LOGOFILE")
    private String logoFile;
    @Column(name = "ICON")
    private String icon;
    @Column(name = "RANG")
    private Long rang;
    @Column(name = "ISFILTER")
    private Boolean isFilter;

}
