package ru.sberx.guide.job;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.questionary.questionary.questionary.req.QuestionnaireListReq;
import ru.sberx.dto.questionary.questionary.questionary.support.QuestionnaireDto;
import ru.sberx.dto.services.company.req.GetCompanyListReq;
import ru.sberx.dto.services.company.res.GetCompanyListRes;
import ru.sberx.guide.dao.model.ImportReplaceGuidDAO;
import ru.sberx.guide.dao.repository.ImportReplaceGuidRepository;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.unity.gate.services.companies.CompaniesService;

import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.guide.utils.Utils.replaceBadСharacters;

@EnableAsync
@Component
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final QuestionaryService questionaryService;
    private final CompaniesService companiesService;
    private final ImportReplaceGuidRepository importReplaceGuidRepository;

    @Value("${application.default.clientid}")
    private String clientId;

    @Scheduled(cron = "${application.cron-import-replace}")
    public void checkValidityImportReplaceGuide() {
        log.debug("start job check import replace");
        ThreadContext.put("request-id", UUID.randomUUID().toString());
        ThreadContext.put("client-id", clientId);

        Map<String, String> replaceNames = new HashMap<>();
        QuestionnaireListReq qReq = new QuestionnaireListReq();
        qReq.setType(0);
        qReq.setIsImport(true);
        qReq.setState(List.of(20004L));
        List<QuestionnaireDto> questionnaireList = questionaryService.getQuestionnaireList(qReq);
        if (!CollectionUtils.isEmpty(questionnaireList)) {
            questionnaireList.stream()
                    .filter(q -> !CollectionUtils.isEmpty(q.getImportReplaceName()))
                    .flatMap(q -> q.getImportReplaceName().stream())
                    .forEach(s -> replaceNames.put(replaceBadСharacters(s), s));
        }
        GetCompanyListReq cReq = new GetCompanyListReq();
        cReq.setIsImport(true);
        GetCompanyListRes companyListRes = companiesService.listCompany(cReq);
        if (companyListRes != null && !CollectionUtils.isEmpty(companyListRes.getCompanies())) {
            companyListRes.getCompanies().stream()
                    .filter(c -> c.getImportReplace() != null && c.getImportReplace().getName() != null && c.getImportReplace().getName().length > 0)
                    .flatMap(c -> Arrays.stream(c.getImportReplaceName()))
                    .forEach(s -> replaceNames.put(replaceBadСharacters(s), s));
        }

        List<ImportReplaceGuidDAO> daoList = importReplaceGuidRepository.findAll();
        daoList.forEach(dao -> {
            if (!replaceNames.containsKey(dao.getValue())) {
                dao.setIsDisabled(true);
            } else {
                dao.setIsDisabled(false);
                replaceNames.remove(dao.getValue());
            }
        });

        if (!CollectionUtils.isEmpty(replaceNames)) {
            log.debug("new import replace: {}", replaceNames.values());
            daoList.addAll(replaceNames.entrySet().stream()
                    .map(entry -> {
                        ImportReplaceGuidDAO dao = new ImportReplaceGuidDAO();
                        dao.setValue(entry.getKey());
                        dao.setName(entry.getValue());
                        dao.setIsDisabled(false);
                        return dao;
                    })
                    .collect(Collectors.toList()));
        }
        importReplaceGuidRepository.saveAll(daoList);
    }

}
