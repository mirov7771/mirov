package ru.sberx.guide.dao.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.Guide;

@Repository
public interface GuideRepository extends CrudRepository<Guide, Long> {

    List<Guide> findByCodeIn(List<Long> codes);

    @Query("from Guide where guideId = :guideId and code = :code")
    Optional<Guide> findByGuideIdAndCode(Long guideId, Long code);

    @Query("select max(code) from Guide where guideId = :id")
    Optional<Long> findMaxCode(Long id);

    Optional<Guide> findByNameAndGuideId(String name, Long guideId);

    Optional<Guide> findBySysNameAndGuideId(String sysname, Long guideId);
}
