package ru.sberx.guide.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class CreateGuideRes {
    private Long guideId;
    private String objectName;
    private String attributeName;
}
