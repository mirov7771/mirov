package ru.sberx.guide.dao.manager;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.ColumnMapRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.guide.controller.dto.req.FaqListReq;
import ru.sberx.utils.util.CastUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class QueryManager {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    private final static String GET_GUIDE_BY_ID =
              "select distinct go.guideid                                       as guideId, "
            + "                go.objectname                                    as objectName, "
            + "                gol.value                                        as goValue, "
            + "                g.id                                             as id, "
            + "                gl.value                                         as gValue, "
            + "                g.sysname                                        as sysName, "
            + "                g.extra                                          as extra, "
            + "                g.icon                                           as icon, "
            + "                g.logofile                                       as logoFile, "
            + "                g.code                                           as code, "
            + "                case when g.rang is null then -1 else g.rang end as rang, "
            + "                gl.description                                   as description, "
            + "                g.isfilter                                       as isfilter "
            + "from guide_object go "
            + "         inner join guide_object_lang gol on gol.id = go.guideid "
            + "         inner join lang l on l.id = gol.lang_id and l.locale = :locale "
            + "         inner join guide g on g.guideid = go.guideid "
            + "         inner join guide_lang gl on gl.id = g.id and l.id = gl.lang_id "
            + "where go.guideid in (:ids) "
            + "  and not exists(select 1 from guides_dependencies gd where gd.code_refer_id = g.code) "
            + "  and g.isdisabled = false "
            + "order by 11 desc";

    private final static String GET_GUIDE_BY_NAME =
              "select distinct go.guideid                                       as guideId, "
            + "                go.objectname                                    as objectName, "
            + "                gol.value                                        as goValue, "
            + "                g.id                                             as id, "
            + "                gl.value                                         as gValue, "
            + "                g.sysname                                        as sysName, "
            + "                g.extra                                          as extra, "
            + "                g.icon                                           as icon, "
            + "                g.logofile                                       as logoFile, "
            + "                g.code                                           as code, "
            + "                case when g.rang is null then -1 else g.rang end as rang, "
            + "                gl.description                                   as description, "
            + "                g.isfilter                                       as isfilter "
            + "from guide_object go "
            + "         inner join guide_object_lang gol on gol.id = go.guideid "
            + "         inner join lang l on l.id = gol.lang_id and l.locale = :locale "
            + "         inner join guide g on g.guideid = go.guideid "
            + "         inner join guide_lang gl on gl.id = g.id and l.id = gl.lang_id "
            + "where go.objectname in (:names) "
            + "  and not exists(select 1 from guides_dependencies gd where gd.code_refer_id = g.code) "
            + "  and g.isdisabled = false "
            + "order by 11 desc";

    private final static String GET_GUIDE_DEP_BY_ID =
              "select distinct go.guideid                                              as guideId, "
            + "                go.objectname                                           as objectName, "
            + "                gol.value                                               as goValue, "
            + "                gl.value                                                as pValue, "
            + "                g.code                                                  as pCode, "
            + "                gl2.value                                               as cValue, "
            + "                g2.code                                                 as cCode, "
            + "                case when g.rang is null then g.id * -1 else g.rang end as pRang, "
            + "                case when g2.rang is null then -1 else g2.rang end      as cRang, "
            + "                gl.description                                           as description, "
            + "                g2.isfilter                                              as isfilter "
            + "from guide_object go "
            + "         inner join guide_object_lang gol on gol.id = go.guideid "
            + "         inner join lang l on l.id = gol.lang_id and l.locale = :locale "
            + "         inner join guide g on g.guideid = go.guideid "
            + "         inner join guides_dependencies gd on gd.code_refer_id = g.code "
            + "         inner join guide_lang gl on gl.id = g.id and l.id = gl.lang_id "
            + "         inner join guide g2 on g2.guideid = go.guideid and gd.code_guide_id = g2.code "
            + "         inner join guide_lang gl2 on gl2.id = g2.id and l.id = gl2.lang_id "
            + "where go.objectname in (select objectname from guide_object where g.guideid in (:ids)) "
            + "  and g.isdisabled = false "
            + "order by 8 desc, 9 desc";

    private final static String GET_GUIDE_DEP_BY_NAME =
              "select distinct go.guideid                                              as guideId, "
            + "                go.objectname                                           as objectName, "
            + "                gol.value                                               as goValue, "
            + "                gl.value                                                as pValue, "
            + "                g.code                                                  as pCode, "
            + "                gl2.value                                               as cValue, "
            + "                g2.code                                                 as cCode, "
            + "                case when g.rang is null then g.id * -1 else g.rang end as pRang, "
            + "                case when g2.rang is null then -1 else g2.rang end      as cRang, "
            + "                gl.description                                           as description, "
            + "                g2.isfilter                                              as isfilter "
            + "from guide_object go "
            + "         inner join guide_object_lang gol on gol.id = go.guideid "
            + "         inner join lang l on l.id = gol.lang_id and l.locale = :locale "
            + "         inner join guide g on g.guideid = go.guideid "
            + "         inner join guides_dependencies gd on gd.code_refer_id = g.code "
            + "         inner join guide_lang gl on gl.id = g.id and l.id = gl.lang_id "
            + "         inner join guide g2 on g2.guideid = go.guideid and gd.code_guide_id = g2.code "
            + "         inner join guide_lang gl2 on gl2.id = g2.id and l.id = gl2.lang_id "
            + "where go.objectname in (:names) "
            + "  and g.isdisabled = false "
            + "order by 8 desc, 9 desc";

    private final static String GET_FAQ_VALUES =
            "select t.id as id1\n" +
            "      ,t.name\n" +
            "      ,q.id as id2\n" +
            "      ,q.question\n" +
            "      ,q.answer\n" +
            "   from faq_topic t\n" +
            "        inner join faq_question q on t.id = q.topic_id and t.lang_id = q.lang_id\n" +
            "        inner join lang l on t.lang_id = l.id\n" +
            "  where l.locale = :locale\n";

    private final static String GET_FAQ_VALUES_SEARCH = "select distinct u.id1 , u.name ,u.id2 ,u.question ,u.answer from\n" +
            "(SELECT t.id as id1\n" +
            "      ,t.name\n" +
            "      ,q.id as id2\n" +
            "      ,q.question\n" +
            "      ,q.answer\n" +
            "      ,'1' as ord\n" +
            "    from faq_topic t\n" +
            "  inner join faq_question q on t.id = q.topic_id and t.lang_id = q.lang_id\n" +
            "  inner join lang l on t.lang_id = l.id\n" +
            "   where l.locale = :locale\n" +
            "  and t.name like :search\n" +
            "union\n" +
            "SELECT t.id as id1\n" +
            "      ,t.name\n" +
            "      ,q.id as id2\n" +
            "      ,q.question\n" +
            "      ,q.answer\n" +
            "      ,'2' as ord\n" +
            "    from faq_topic t\n" +
            "  inner join faq_question q on t.id = q.topic_id and t.lang_id = q.lang_id\n" +
            "  inner join lang l on t.lang_id = l.id\n" +
            "  where l.locale = :locale\n" +
            "  and q.question like :search\n" +
            "union\n" +
            "SELECT t.id as id1\n" +
            "      ,t.name\n" +
            "      ,q.id as id2\n" +
            "      ,q.question\n" +
            "      ,q.answer\n" +
            "      ,'3' as ord\n" +
            "    from faq_topic t\n" +
            "  inner join faq_question q on t.id = q.topic_id and t.lang_id = q.lang_id\n" +
            "  inner join lang l on t.lang_id = l.id\n" +
            "  where l.locale = :locale\n" +
            "  and q.answer like :search\n" +
            "order by ord) u";

    private final static String GET_GUIDES_CODES =
              "with cte as (\n"
            + "select code_guide_id as code\n"
            + "  from guides_dependencies gd \n"
            + " where code_refer_id in (:codes)\n"
            + "union\n"
            + "select code as code\n"
            + "  from guide g \n"
            + " where code in  (:codes)\n"
            + "   and not exists (select 1 from guides_dependencies gd where gd.code_refer_id = g.code)\n"
            + ")\n"
            + "select code \n"
            + "  from cte\n"
            + " group by code";

    public List<GuideModel> getGuideById(List<Long> guideId, String locale) {
        Map<String, Object> params = new HashMap<>();
        params.put("locale", locale);
        params.put("ids", guideId);
        return jdbcTemplate.query(GET_GUIDE_BY_ID,
                        params,
                        new ColumnMapRowMapper())
                .stream().map(GuideModel::new)
                .collect(Collectors.toList());
    }

    public List<GuideModel> getGuideByName(List<String> names, String locale){
        Map<String, Object> params = new HashMap<>();
        params.put("locale", locale);
        params.put("names", names);
        return jdbcTemplate.query(GET_GUIDE_BY_NAME,
                        params,
                        new ColumnMapRowMapper())
                .stream().map(GuideModel::new)
                .collect(Collectors.toList());
    }

    public List<GuideDepModel> getGuideDep(List<String> names, List<Long> ids, String locale){
        Map<String, Object> params = new HashMap<>();
        params.put("locale", locale);
        String query = GET_GUIDE_DEP_BY_NAME;
        if (!CollectionUtils.isEmpty(ids)){
            params.put("ids", ids);
            query = GET_GUIDE_DEP_BY_ID;
        } else {
            params.put("names", names);
        }
        return jdbcTemplate.query(query,
                        params,
                        new ColumnMapRowMapper())
                .stream().map(GuideDepModel::new)
                .collect(Collectors.toList());
    }

    public List<FaqModel> getFaqList(FaqListReq req) {
        String sql = GET_FAQ_VALUES;
        Map<String, Object> params = new HashMap<>();
        params.put("locale", req.getLocale());
        if (StringUtils.hasText(req.getId())) {
            sql += " and t.id = :id";
            params.put("id", CastUtils.castToLong(req.getId()));
        } else if (StringUtils.hasText(req.getGroupName())) {
            sql += " and t.name = :name";
            params.put("name", req.getGroupName());
        }
        sql += " order by 1, 3";

        if (StringUtils.hasText(req.getSearch())) {
            String search = "%" + req.getSearch() + "%";
            sql = GET_FAQ_VALUES_SEARCH;
            params.put("search", search);
        }
        return jdbcTemplate.query(sql,
                        params,
                        new ColumnMapRowMapper())
                .stream().map(FaqModel::new)
                .collect(Collectors.toList());
    }

    public List<Long> getGuidesCodes(List<Long> codes){
        return jdbcTemplate.query(GET_GUIDES_CODES,
                    Map.of("codes", codes),
                    new ColumnMapRowMapper())
                .stream()
                .map(i -> CastUtils.castToLong(i.get("code")))
                .collect(Collectors.toList());
    }

}
