package ru.sberx.guide.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.guide.controller.dto.support.QuestionDto;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "FAQ_QUESTION")
@Getter
@Setter
@NoArgsConstructor
public class FaqQuestion implements Serializable {

    private static final long serialVersionUID = -8085583561843351697L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "TOPIC_ID", nullable = false)
    private Long topicId;
    @Column(name = "QUESTION")
    private String question;
    @Column(name = "ANSWER")
    private String answer;
    @Column(name = "LANG_ID")
    private Integer langId;

    public FaqQuestion(QuestionDto dto, Long topicId) {
        this.topicId = topicId;
        this.question = dto.getQuestion();
        this.answer = dto.getAnswer();
    }

    public FaqQuestion(QuestionDto dto, Long topicId, Integer langId) {
        this.topicId = topicId;
        this.question = dto.getQuestion();
        this.answer = dto.getAnswer();
        this.langId = langId;
    }

    public QuestionDto toDto() {
        QuestionDto questionDtoRes = new QuestionDto();
        questionDtoRes.setQuestion(this.question);
        questionDtoRes.setAnswer(this.answer);
        return questionDtoRes;
    }

}
