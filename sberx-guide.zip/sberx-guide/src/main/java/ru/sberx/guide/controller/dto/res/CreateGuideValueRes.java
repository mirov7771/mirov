package ru.sberx.guide.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
public class CreateGuideValueRes {
    private Long id;
    private Long guideId;
    private Long code;
    private String name;
}
