package ru.sberx.guide.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.guide.controller.dto.support.Group;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FaqListRes {

    private List<Group> list;

}
