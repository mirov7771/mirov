package ru.sberx.guide.dao.manager;

import lombok.Data;
import ru.sberx.utils.util.CastUtils;

import java.util.Map;

@Data
public class GuideDepModel {

    private Long guideId;
    private String objectName;
    private String goValue;
    private String pValue;
    private Long pCode;
    private String cValue;
    private Long cCode;
    private Long pRang;
    private Long cRang;
    private String description;
    private Boolean isFilter;

    public GuideDepModel(Map<String, Object> row) {
        this.guideId = CastUtils.castToLong(row.get("guideId"));
        this.objectName = CastUtils.castToString(row.get("objectName"));
        this.goValue = CastUtils.castToString(row.get("goValue"));
        this.pValue = CastUtils.castToString(row.get("pValue"));
        this.pCode = CastUtils.castToLong(row.get("pCode"));
        this.cValue = CastUtils.castToString(row.get("cValue"));
        this.cCode = CastUtils.castToLong(row.get("cCode"));
        this.pRang = CastUtils.castToLong(row.get("pRang"));
        this.cRang = CastUtils.castToLong(row.get("cRang"));
        this.description = CastUtils.castToString(row.get("description"));
        this.isFilter = Boolean.TRUE.equals(row.get("isfilter"));
    }
}
