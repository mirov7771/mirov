package ru.sberx.guide.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "LANG")
@Data
public class LangDao implements Serializable {

    private static final long serialVersionUID = 8529685062814793428L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "LOCALE")
    private String locale;
}
