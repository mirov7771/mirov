package ru.sberx.guide.dao.manager;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import ru.sberx.utils.util.CastUtils;

import java.util.Map;

@Slf4j
@Data
public class GuideModel {

    private Long guideId;
    private String objectName;
    private String goValue;
    private Long id;
    private String gValue;
    private String sysName;
    private String extra;
    private String icon;
    private String logoFile;
    private Long code;
    private Long rang;
    private String description;
    private Boolean isFilter;

    public GuideModel(Map<String, Object> row) {
        this.guideId = CastUtils.castToLong(row.get("guideId"));
        this.objectName = CastUtils.castToString(row.get("objectName"));
        this.goValue = CastUtils.castToString(row.get("goValue"));
        this.id = CastUtils.castToLong(row.get("id"));
        this.gValue = CastUtils.castToString(row.get("gValue"));
        this.sysName = CastUtils.castToString(row.get("sysName"));
        this.extra = CastUtils.castToString(row.get("extra"));
        this.icon = CastUtils.castToString(row.get("icon"));
        this.logoFile = CastUtils.castToString(row.get("logoFile"));
        this.code = CastUtils.castToLong(row.get("code"));
        this.rang = CastUtils.castToLong(row.get("rang"));
        this.description = CastUtils.castToString(row.get("description"));
        this.isFilter = Boolean.TRUE.equals(row.get("isfilter"));
    }
}
