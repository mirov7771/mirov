package ru.sberx.guide.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.guide.dao.model.Guide;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UpdateGuideValueRes {
    private Long guideId;
    private Long code;
    private Long entityId;
    private String name;
    private String sysName;
    private String extra;
    private String icon;
    private String logoFile;
    private Boolean isDisabled;
    private String description;

    public UpdateGuideValueRes(Guide g) {
        this.guideId = g.getGuideId();
        this.code = g.getCode();
        this.entityId = g.getId();
        this.name = g.getName();
        this.sysName = g.getSysName();
        this.icon = g.getIcon();
        this.logoFile = g.getLogoFile();
        this.isDisabled = g.getIsDisabled();
    }
}
