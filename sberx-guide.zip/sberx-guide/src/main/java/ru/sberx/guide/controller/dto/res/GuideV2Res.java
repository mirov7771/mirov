package ru.sberx.guide.controller.dto.res;

import lombok.Data;
import ru.sberx.guide.controller.dto.support.ReferenceRes;

import java.util.List;

@Data
public class GuideV2Res {

    private String name;
    private String sysname;
    private List<ReferenceRes> values;

}
