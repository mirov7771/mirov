package ru.sberx.guide.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.guide.dao.model.GuideObjectLang;

@Repository
public interface GuideObjectLangRepository extends CrudRepository<GuideObjectLang, Long> {
    GuideObjectLang findByIdAndLangId(Long id, Long langId);
}
