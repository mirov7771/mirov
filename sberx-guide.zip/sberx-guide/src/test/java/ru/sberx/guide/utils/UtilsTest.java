package ru.sberx.guide.utils;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class UtilsTest {

    @Test
    public void replaceBadСharactersTest() {
        Assert.assertEquals("CBDFCGJKHJKMLKJLNBHGHFDXZSXCSDVFGJHKJLMKJHGNBCFXVDZC"
                , Utils.replaceBadСharacters("cbdfcgjkhjkml/kjlnbhghfdxzs`xcsdvfgjhkj./l:m/kjhgnbcfxvdzc`"));
        Assert.assertEquals("ABCDF-АЯЫФЫ94343412-ВЫВФВ"
                , Utils.replaceBadСharacters("abcdf-Аяыфы94343412-вывфв"));
        Assert.assertEquals("FSGXFCHJNGCFGVVCSADAXSBCGNBNMVVH"
                , Utils.replaceBadСharacters("fsgxfchjngcfgvvcsa`daxs`bcgnbnmvvh"));
        Assert.assertEquals("GRFDSFZDXASSDSFAGDFGHKMH"
                , Utils.replaceBadСharacters("grfdsfzdxas`sdsfagdfghkmh"));
        Assert.assertEquals("VDSFBFCNVM"
                , Utils.replaceBadСharacters("\\vdsfbfcnvm"));
        Assert.assertEquals("VDSFB FCNVM"
                , Utils.replaceBadСharacters("\\vdsfb  fcnvm"));

    }
}
