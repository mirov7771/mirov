create table guide
(
    ID         BIGINT,
    NAME       VARCHAR(50),
    SYSNAME    VARCHAR(50),
    CODE       BIGINT,
    EXTRA      VARCHAR(50),
    logofile   varchar(150) null,
    icon       varchar(150) null,
    ISDISABLED BOOLEAN default false,
    RANG       BIGINT
);

create index x1_guide on guide (ID, ISDISABLED);

create table guide_object
(
    OBJECTNAME    VARCHAR(150),
    ATTRIBUTENAME VARCHAR(50) NULL,
    GUIDEID       BIGINT
);

create table guides_dependencies
(
    id            bigserial,
    code_guide_id varchar(50),
    code_refer_id varchar(50)
);

create index x1_guide_object on guide_object (GUIDEID);

insert into public.guide (code, name, id)
values (15001, 'Оптимизация текущих процессов, расходов', 15000);

insert into public.guide (code, name, id)
values (15002, 'Введение новых функций, новых каналов выручки', 15000);

insert into public.guide (code, name, id)
values (15003,'Другое',15000);

insert into public.guide (code, name, id)
values (17001,'Да',17000);

insert into public.guide (code, name, id)
values (17002,'Нет',17000);

insert into public.guide (code, name, id)
values (17003,'Затрудняюсь ответить',17000);

insert into public.guide (code, name, id)
values (18001,'Да',18000);

insert into public.guide (code, name, id)
values (18002,'Нет',18000);

insert into public.guide (code, name, id)
values (18003,'Затрудняюсь ответить',18000);

insert into public.guide (code, name, id)
values (16001,'Нет',16000);

insert into public.guide (code, name, id)
values (16002,'Да, путём внутренней разработки',16000);

insert into public.guide (code, name, id)
values (16003,'Да, путём работы с внешней компанией',16000);

insert into public.guide (code, name, id, extra)
values (20001,'Draft',20000, 'all');

insert into public.guide (code, name, id, extra)
values (20002,'На рассмотрении',20000, 'all');

insert into public.guide (code, name, id, extra)
values (20003,'На доработку',20000, 'all');

insert into public.guide (code, name, id, extra)
values (20004,'Активный',20000, 'all');

insert into public.guide (code, name, id, extra)
values (20005,'Архивный',20000, 'all');

insert into public.guide (code, name, id, extra)
values (20007,'Удачный пилот',20000, 'pilot');

insert into public.guide (code, name, id, extra)
values (20008,'Предлагаемый кейс',20000, 'pilot');

insert into public.guide (code, name, id, extra)
values (20009,'Отклоненный',20000, 'all');

insert into public.guide (code, name, id, extra, icon, logofile)
values(0, 'Стартап', 1, '/list?type=1&type=2', 'http://sberx-gateway-ci02898790-etestenab-startuphub-dev.apps.test.enablers.sbrf.ru/sberx-gateway/file/13', 'http://sberx-gateway-ci02898790-etestenab-startuphub-dev.apps.test.enablers.sbrf.ru/sberx-gateway/file/12');

insert into public.guide (code, name, id, extra, icon, logofile)
values(1, 'Корпорация', 1, '/list?type=1&rowcount=100', 'http://sberx-gateway-ci02898790-etestenab-startuphub-dev.apps.test.enablers.sbrf.ru/sberx-gateway/file/15', 'http://sberx-gateway-ci02898790-etestenab-startuphub-dev.apps.test.enablers.sbrf.ru/sberx-gateway/file/10');

insert into public.guide (code, name, id, extra, icon, logofile)
values(2, 'Инвесторы', 1, '/list?type=2&rowcount=100', 'http://sberx-gateway-ci02898790-etestenab-startuphub-dev.apps.test.enablers.sbrf.ru/sberx-gateway/file/14', 'http://sberx-data-store-ci02898790-etestenab-startuphub-dev.apps.test.enablers.sbrf.ru/sberx-data-store/file/11');

insert into public.guide_object (objectname, attributename, guideid)
values('UserType','Участники', 1);