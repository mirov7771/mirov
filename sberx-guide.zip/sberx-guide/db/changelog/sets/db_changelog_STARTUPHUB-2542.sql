--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2542
alter table guide
    add column rang bigint;