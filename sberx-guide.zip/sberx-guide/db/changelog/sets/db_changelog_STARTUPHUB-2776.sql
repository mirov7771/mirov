--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2776

delete from guide where code in (2201, 2202, 2203, 2204, 2205, 2206, 2207, 2208, 2209, 2210);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Северная Америка', 2201);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Южная Америка', 2202);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Центральная Америка', 2203);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Европа', 2204);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Восточная Европа', 2205);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Ближний Восток', 2206);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Центральная и Южная Азия', 2207);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Восточная и Юго-Восточная Азия', 2208);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Африка', 2209);

insert into public.guide (id, guideid, name, code)
values ((select max(id)+1 from guide), 2000, 'Австралия и Океания', 2210);

drop table if exists guides_dependencies;
create table guides_dependencies
(
    id bigserial primary key,
    code_guide_id bigint,
    code_refer_id bigint
);

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Канада'),
        (SELECT code from public.guide WHERE name = 'Северная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мексика'),
        (SELECT code from public.guide WHERE name = 'Северная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'США'),
        (SELECT code from public.guide WHERE name = 'Северная Америка'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Азербайджан'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Армения'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Беларусь'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Казахстан'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Киргизия'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Молдавия'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Россия'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Таджикистан'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Туркмения'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Узбекистан'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Туркмения'), (SELECT code from public.guide WHERE name = 'СНГ'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Украина'), (SELECT code from public.guide WHERE name = 'СНГ'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Аргентина'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Боливия'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бразилия'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Венесуэла'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гайана'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Колумбия'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Парагвай'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Перу'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Суринам'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Уругвай'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Чили'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Эквадор'),
        (SELECT code from public.guide WHERE name = 'Южная Америка'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Антигуа и Барбуда'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Багамы'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Барбадос'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Белиз'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Виргинские острова'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гаити'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гондурас'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гренада'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гватемала'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Доминика'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Доминикана'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Каймановы острова'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Коста-Рика'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Куба'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Никарагуа'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Панама'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сальвадор'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сент-Винсент и Гренадины'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сент-Китс и Невис'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сент-Люсия'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Суринам'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Тринидад и Тобаго'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ямайка'),
        (SELECT code from public.guide WHERE name = 'Центральная Америка'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Великобритания'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Дания'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ирландия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Исландия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Латвия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Литва'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Норвегия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Финляндия'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Швеция'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Эстония'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Австрия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бельгия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Германия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Лихтенштейн'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Люксембург'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Монако'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Нидерланды'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Франция'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Швейцария'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Албания'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Андорра'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Босния и Герцеговина'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Греция'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Испания'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Италия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Кипр'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мальта'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Португалия'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сан-Марино'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Северная Македония'),
        (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сербия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Словения'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Турция'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Хорватия'), (SELECT code from public.guide WHERE name = 'Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Черногория'),
        (SELECT code from public.guide WHERE name = 'Европа'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Азербайджан'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Армения'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Беларусь'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Болгария'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Венгрия'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Грузия'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Молдавия'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Польша'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Россия'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Румыния'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Словакия'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Украина'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Чехия'),
        (SELECT code from public.guide WHERE name = 'Восточная Европа'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бахрейн'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Израиль'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Иордания'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ирак'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Иран'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Йемен'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Катар'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Кувейт'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ливан'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'ОАЭ'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Оман'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Саудовская Аравия'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сирия'),
        (SELECT code from public.guide WHERE name = 'Ближний Восток'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Казахстан'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Киргизия'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Таджикистан'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Туркмения'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Узбекистан'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Афганистан'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бангладеш'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бутан'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Индия'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мальдивы'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Непал'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Пакистан'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Шри-Ланка'),
        (SELECT code from public.guide WHERE name = 'Центральная и Южная Азия'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Китай'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'КНДР'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Южная Корея'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Монголия'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гонконг'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Япония'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бруней'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Вьетнам'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Индонезия'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Камбоджа'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Лаос'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Малайзия'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мьянма'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сингапур'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Таиланд'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Восточный Тимор'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Филиппины'),
        (SELECT code from public.guide WHERE name = 'Восточная и Юго-Восточная Азия'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Алжир'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ангола'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бенин'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ботсвана'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Буркина-Фасо'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Бурунди'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Габон'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гамбия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гана'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гвинея'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Гвинеа-Бисау'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'ДР Конго'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Джибути'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Египет'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Замбия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Зимбабве'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Кабо-Верде'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Камерун'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Кения'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Коморы'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Конго'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Кот-д’Ивуар'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Лесото'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Либерия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Ливия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Маврикий'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мавритания'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мадагаскар'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Малави'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мали'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Марокко'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Мозамбик'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Намибия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Нигер'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Нигерия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Руанда'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сан-Томе и Принсипи'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Эсватини'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сейшелы'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сенегал'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сомали'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Судан'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Сьерра-Леоне'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Танзания'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Того'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Тунис'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Уганда'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'ЦАР'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Чад'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Экваториальная Гвинея'),
        (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Эритрея'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Эфиопия'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'ЮАР'), (SELECT code from public.guide WHERE name = 'Африка'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Южный Судан'),
        (SELECT code from public.guide WHERE name = 'Африка'));

insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Австралия'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Вануату'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Папуа — Новая Гвинея'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Соломоновы острова'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Фиджи'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Маршалловы острова'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Науру'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Палау'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Микронезия'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Кирибати'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Новая Зеландия'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Самоа'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Тонга'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));
insert into public.guides_dependencies (code_guide_id, code_refer_id)
VALUES ((SELECT code from public.guide WHERE name = 'Тувалу'),
        (SELECT code from public.guide WHERE name = 'Австралия и Океания'));