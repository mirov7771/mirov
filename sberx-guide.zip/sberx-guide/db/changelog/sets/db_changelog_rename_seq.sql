--liquibase formatted sql
--changeset Mirov AA:guide_entityid_seq
ALTER SEQUENCE public.guide_entityid_seq RENAME TO guide_id_seq;