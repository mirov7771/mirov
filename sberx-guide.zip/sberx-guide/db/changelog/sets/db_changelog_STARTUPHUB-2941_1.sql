--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-2941_1

-- Вставляем новые значения в справочники
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'Dating', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'Dating'
        );
-- Делаем rang в сортировке по алфавиту
update guide
set
    rang = (select sort.rang from (select code, (row_number() over(order by name))*-1 as rang from guide g where guideid = 3000 order by name asc) as sort where guide.code = sort.code)
where guide.guideid = 3000;
-- Вставляем новые значения в справочник мультиязычности
insert into guide_lang
(id, value, lang_id)
select id, g2."name", 1 from guide g2 where g2."name" = 'Dating' and
    NOT EXISTS (
            SELECT g3.id FROM guide_lang g3 WHERE g3.value = 'Dating' and g3.lang_id = 1
        );
insert into guide_lang
(id, value, lang_id)
select id, g2."name", 2 from guide g2 where g2."name" = 'Dating' and
    NOT EXISTS (
            SELECT g3.id FROM guide_lang g3 WHERE g3.value = 'Dating' and g3.lang_id = 2
        );
