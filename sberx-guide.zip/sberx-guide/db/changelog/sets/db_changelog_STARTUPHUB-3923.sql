--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-3923

create table faq_topic
(
    id   bigserial primary key,
    name varchar not null
);

create table faq_question
(
    id       bigserial primary key,
    topic_id bigint not null,
    question varchar,
    answer   varchar
);

create index x1_faq_question on faq_question (topic_id);