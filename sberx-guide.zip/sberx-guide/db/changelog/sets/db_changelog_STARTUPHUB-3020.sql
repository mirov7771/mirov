--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3020
UPDATE guide
SET "name"='Инвестиции в капитал'
WHERE  code=14001;
delete from guide where code = 14005;
INSERT INTO guide
(id, guideid, "name", code)
VALUES((select (max(id)+1) from guide), 14000, 'KISS', 14005);

