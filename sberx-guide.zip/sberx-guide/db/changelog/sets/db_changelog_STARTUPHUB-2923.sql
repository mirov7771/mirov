--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2923
alter table guide drop column if exists isfilter;
alter table guide
    add column isfilter boolean default false;

update guide set isfilter = true
where id not in
      (select gl.id from guide_lang gl
        where gl.value = 'Идея' or gl.value = 'Прототип, продаж нет');

update guide set isfilter = false
where id in
      (select gl.id from guide_lang gl
       where gl.value = 'Идея' or gl.value = 'Прототип, продаж нет');