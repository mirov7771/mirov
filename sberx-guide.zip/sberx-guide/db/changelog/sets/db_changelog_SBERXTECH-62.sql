--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-62
insert into guide(id,code,name)
values (21000,  21003, 'Сайт компании')
