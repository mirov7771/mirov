--liquibase formatted sql
--changeset Mirov AA:en_locale_guide_object
delete from public.guide_object_lang where lang_id = (select id from lang where locale = 'en');
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(2000, 'Investment geography', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(3000, 'Industries', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(5000, 'Volume of sales', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(8000, 'Sales model', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(13000, 'Technologies', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(21000, 'Contact type', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(24000, 'Business model', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(27000, 'Product development stage', (select id from lang where locale = 'en'));
INSERT INTO public.guide_object_lang (id, value, lang_id) VALUES(38000, 'Ecosystem needs', (select id from lang where locale = 'en'));

insert into guide_object_lang (id, value, lang_id)
select guideid , objectname , (select id from lang where locale = 'en')
from guide_object go2
where guideid not in (select id from guide_object_lang where lang_id = 2);

