--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2874
update guide
set name = 'Туркменистан'
where name = 'Туркмения';

create index x1_guides_dependencies on guides_dependencies(code_refer_id);
create index x2_guides_dependencies on guides_dependencies(code_guide_id);