--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-281
update guide_object
  set objectname = 'InnovationMethod'
where objectname = 'WorkMethod'