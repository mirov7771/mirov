--liquibase formatted sql
--changeset Mirov A:new_industry
update public.guide_object
set attributename = 'Индустрии'
where objectname = 'Industry'
