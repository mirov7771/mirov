--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-4668

-- Вставляем новые значения в справочники
delete from public.guide where guideid = 41000;
delete from public.guide_object where guideid = 41000;

INSERT INTO public.guide (guideid,name,sysname,extra,icon,logofile,code,isdisabled,rang,isfilter) VALUES
    (41000,'Доллары, $','USD',NULL,NULL,NULL,41001,false,NULL,false),
    (41000,'Рубли, ₽','RUR',NULL,NULL,NULL,41002,false,NULL,false);

INSERT INTO public.guide_object (guideid,objectname,attributename) VALUES (41000,'MetricCurrency','Валюты в которых передаются метрики');

-- Вставляем новые значения в справочник мультиязычности
insert into guide_object_lang
(id, value, lang_id)
select g2.guideid , g2.objectname, 1 from guide_object g2 where g2.objectname  = 'MetricCurrency' and
    NOT EXISTS (
            SELECT g3.id FROM guide_object_lang g3 WHERE g3.id = g2.guideid and g3.lang_id = 1
        );
insert into guide_object_lang
(id, value, lang_id)
select g2.guideid , g2.objectname , 2 from guide_object g2 where g2.objectname  = 'MetricCurrency' and
    NOT EXISTS (
            SELECT g3.id FROM guide_object_lang g3 WHERE g3.id = g2.guideid and g3.lang_id = 2
        );

insert into guide_lang
(id, value, lang_id)
select id, g2."name", 1 from guide g2 where g2."name" = 'Доллары, $' and
    NOT EXISTS (
            SELECT g3.id FROM guide_lang g3 WHERE g3.id = g2.id  and g3.lang_id = 1
        );
insert into guide_lang
(id, value, lang_id)
select id, 'USD, $', 2 from guide g2 where g2."name" = 'Доллары, $' and
    NOT EXISTS(
            SELECT g3.id FROM guide_lang g3 WHERE g3.id = g2.id  and g3.lang_id = 2
        );

insert into guide_lang
(id, value, lang_id)
select id, g2."name", 1 from guide g2 where g2."name" = 'Рубли, ₽' and
    NOT EXISTS (
            SELECT g3.id FROM guide_lang g3 WHERE g3.id = g2.id  and g3.lang_id = 1
        );
insert into guide_lang
(id, value, lang_id)
select id, 'RUR, ₽', 2 from guide g2 where g2."name" = 'Рубли, ₽' and
    NOT EXISTS(
            SELECT g3.id FROM guide_lang g3 WHERE g3.id = g2.id  and g3.lang_id = 2
        );