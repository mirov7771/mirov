--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2403
update guide_object
set objectname = 'Technology'
where objectname = 'Techonology';