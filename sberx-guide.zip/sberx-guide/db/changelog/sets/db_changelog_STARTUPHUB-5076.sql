--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5076
alter table import_replace_guid add column if not exists isdisabled boolean default false;