--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1667 Исправление Аэроокосмичской отрасли

UPDATE public.guide SET "name"='Аэрокосмическая отрасль' WHERE code=22027;