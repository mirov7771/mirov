--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-4995
update public.guide_lang
set value = 'Education and development'
where id in (select g.id from guide g
             where g.guideid = 10000
               and g.code = 10009)
  and lang_id = 2;