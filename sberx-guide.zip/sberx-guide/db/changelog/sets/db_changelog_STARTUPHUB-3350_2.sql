--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3350_2
insert into guide_lang
select id, name, (select id from lang where locale = 'ru')
from guide g
where not exists(select 1 from guide_lang l where g.id = l.id);

insert into guide_object_lang
select guideid, attributename, (select id from lang where locale = 'ru')
from guide_object g
where not exists(select 1 from guide_object_lang l where g.guideid = l.id);

