--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-2035 Обновление справочника стадий инвестиования

UPDATE public.guide SET id=6000, "name"='Pre-seed', sysname=NULL, extra=NULL, icon=NULL, logofile=NULL, code=6001, isdisabled=false, value=NULL WHERE entityid=1058;
UPDATE public.guide SET id=6000, "name"='Seed', sysname=NULL, extra=NULL, icon=NULL, logofile=NULL, code=6002, isdisabled=false, value=NULL WHERE entityid=1059;
UPDATE public.guide SET id=6000, "name"='Round A', sysname=NULL, extra=NULL, icon=NULL, logofile=NULL, code=6003, isdisabled=false, value=NULL WHERE entityid=1060;
UPDATE public.guide SET id=6000, "name"='Round B', sysname=NULL, extra=NULL, icon=NULL, logofile=NULL, code=6004, isdisabled=false, value=NULL WHERE entityid=1061;
UPDATE public.guide SET id=6000, "name"='Round C+', sysname=NULL, extra=NULL, icon=NULL, logofile=NULL, code=6005, isdisabled=false, value=NULL WHERE entityid=1062;

INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 6000, 'Late Seed', NULL, NULL, NULL, NULL, 6006, false, NULL);



