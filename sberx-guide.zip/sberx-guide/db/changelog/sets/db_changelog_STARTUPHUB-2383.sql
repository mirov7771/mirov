--liquibase formatted sql
--changeset Molotkov DE :STARTUPHUB-2383
update public.guide set rang = 1060 where code = 6001;
update public.guide set rang = 1050 where code = 6002;
update public.guide set rang = 1040 where code = 6006;
update public.guide set rang = 1030 where code = 6003;
update public.guide set rang = 1020 where code = 6004;
update public.guide set rang = 1010 where code = 6005;