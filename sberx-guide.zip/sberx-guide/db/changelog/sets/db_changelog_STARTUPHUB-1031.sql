--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-1031 Модификация guide для окна авторизации

delete from public.guide_object where guideid = 23000;

INSERT INTO public.guide_object (guideid,objectname,attributename) VALUES
(23000,'Auth','Страница регистрации');

delete from public.guide where id = 23000;

INSERT INTO public.guide (id,name,sysname,extra,icon,logofile,code,isdisabled,value) VALUES
(23000,'Стартапам',NULL,NULL,NULL,NULL,23001,false,'{
  "title": "Стартапам",
  "description": "Если у Вашего юридического лица нет учетной записи в СберБизнес, то пройдите регистрацию. (Регистрация СберБизнес ID не обязывает Вас открывать расчетный счет в Сбере).",
  "ui": "SBBID",
  "buttonTitle": "Регистрация по СберБизнес ID",
  "buttonAction": "/preauthorize"
}'),
(23000,'Корпорациям',NULL,NULL,NULL,NULL,23002,false,'{
  "title": "Корпорациям",
  "description": "Заполните шаблон для рассмотрения Вашей заявки на регистрацию на платформе SberUnity  ",
  "ui": "default",
  "buttonTitle": "Заполнить шаблон",
  "buttonAction": "mailto:sberunity@sberbank.ru?subject=%D0%A0%D0%B5%D0%B3%D0%B8%D1%81%D1%82%D1%80%D0%B0%D1%86%D0%B8%D1%8F%20%D0%BA%D0%BE%D1%80%D0%BF%D0%BE%D1%80%D0%B0%D1%86%D0%B8%D0%B8%20%D0%BD%D0%B0%20%D0%BF%D0%BB%D0%B0%D1%82%D1%84%D0%BE%D1%80%D0%BC%D0%B5%20SberUnity&body=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5%21%0D%0A%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D1%80%D0%B8%D1%81%D0%BE%D0%B5%D0%B4%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D0%BA%20SberUnity.%0D%0A%D0%9D%D0%B0%D0%BF%D1%80%D0%B0%D0%B2%D0%BB%D1%8F%D1%8E%20%D0%BD%D0%B5%D0%BE%D0%B1%D1%85%D0%BE%D0%B4%D0%B8%D0%BC%D1%83%D1%8E%20%D0%B8%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D1%8E%3A%0D%0A%09%D0%A4%D0%98%D0%9E%3A%0D%0A%09%D0%94%D0%BE%D0%BB%D0%B6%D0%BD%D0%BE%D1%81%D1%82%D1%8C%3A%0D%0A%09%D0%9F%D0%BE%D0%BB%D0%BD%D0%BE%D0%B5%20%D0%BD%D0%B0%D0%B8%D0%BC%D0%B5%D0%BD%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B8%3A%0D%0A%09%D0%98%D0%9D%D0%9D%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B8%3A%0D%0A%09%D0%92%D0%B5%D0%B1%D1%81%D0%B0%D0%B9%D1%82%3A%0D%0A%09Email%3A%0D%0A%09%D0%A2%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD%3A%0D%0A%D0%A1%D0%BE%D0%B3%D0%BB%D0%B0%D1%81%D0%B8%D0%B5%20%D1%81%20%D0%9F%D0%BE%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%BE%D0%B9%20%D0%BF%D1%80%D0%B5%D0%B4%D0%BE%D1%81%D1%82%D0%B0%D0%B2%D0%BB%D0%B5%D0%BD%D0%B8%D1%8F%20%D0%B8%20%D0%BE%D0%B1%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B8%20%D0%BF%D0%B5%D1%80%D1%81%D0%BE%D0%BD%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D1%85%20%D0%B4%D0%B0%D0%BD%D0%BD%D1%8B%D1%85%20%D0%BF%D0%BE%D0%B4%D1%82%D0%B2%D0%B5%D1%80%D0%B6%D0%B4%D0%B0%D1%8E%20http%3A%2F%2Fsber.me%2F%3Fp%3D5rVQP"
}'),
(23000,'Инвесторам',NULL,NULL,NULL,NULL,23003,false,'{
  "title": "Инвесторам",
  "description": "Заполните шаблон для рассмотрения Вашей заявки на регистрацию на платформе SberUnity  ",
  "ui": "default",
  "buttonTitle": "Заполнить шаблон",
  "buttonAction": "mailto:sberunity@sberbank.ru?subject=%D0%A0%D0%B5%D0%B3%D0%B8%D1%81%D1%82%D1%80%D0%B0%D1%86%D0%B8%D1%8F%20%D0%B8%D0%BD%D0%B2%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%20%D0%BD%D0%B0%20%D0%BF%D0%BB%D0%B0%D1%82%D1%84%D0%BE%D1%80%D0%BC%D0%B5%20SberUnity&body=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5%21%0D%0A%D0%AF%20%D1%85%D0%BE%D1%87%D1%83%20%D0%BF%D1%80%D0%B8%D1%81%D0%BE%D0%B5%D0%B4%D0%B8%D0%BD%D0%B8%D1%82%D1%8C%D1%81%D1%8F%20%D0%BA%20SberUnity.%0D%0A%D0%9D%D0%B0%D0%BF%D1%80%D0%B0%D0%B2%D0%BB%D1%8F%D1%8E%20%D0%BD%D0%B5%D0%BE%D0%B1%D1%85%D0%BE%D0%B4%D0%B8%D0%BC%D1%83%D1%8E%20%D0%B8%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%86%D0%B8%D1%8E%3A%0D%0A%09%D0%A4%D0%98%D0%9E%3A%0D%0A%09%D0%94%D0%BE%D0%BB%D0%B6%D0%BD%D0%BE%D1%81%D1%82%D1%8C%3A%20%3C%D0%95%D1%81%D0%BB%D0%B8%20%D0%92%D1%8B%20%D0%BF%D1%80%D0%B5%D0%B4%D1%81%D1%82%D0%B0%D0%B2%D0%B8%D1%82%D0%B5%D0%BB%D1%8C%20%D1%84%D0%BE%D0%BD%D0%B4%D0%B0%2C%20%D0%B5%D1%81%D0%BB%D0%B8%20%D0%B1%D0%B8%D0%B7%D0%BD%D0%B5%D1%81-%D0%B0%D0%BD%D0%B3%D0%B5%D0%BB%2C%20%D1%83%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%C2%AB%D0%91%D0%B8%D0%B7%D0%BD%D0%B5%D1%81-%D0%B0%D0%BD%D0%B3%D0%B5%D0%BB%C2%BB%3E%0D%0A%09%D0%9F%D0%BE%D0%BB%D0%BD%D0%BE%D0%B5%20%D0%BD%D0%B0%D0%B8%D0%BC%D0%B5%D0%BD%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%20%D1%84%D0%BE%D0%BD%D0%B4%D0%B0%3A%0D%0A%09%D0%98%D0%9D%D0%9D%20%D0%BA%D0%BE%D0%BC%D0%BF%D0%B0%D0%BD%D0%B8%D0%B8%3A%20%0D%0A%09%D0%92%D0%B5%D0%B1%D1%81%D0%B0%D0%B9%D1%82%3A%0D%0A%09Email%3A%0D%0A%09%D0%A2%D0%B5%D0%BB%D0%B5%D1%84%D0%BE%D0%BD%3A%0D%0A%D0%A1%D0%BE%D0%B3%D0%BB%D0%B0%D1%81%D0%B8%D0%B5%20%D1%81%20%D0%9F%D0%BE%D0%BB%D0%B8%D1%82%D0%B8%D0%BA%D0%BE%D0%B9%20%D0%BE%D0%B1%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B8%20%D0%BF%D0%B5%D1%80%D1%81%D0%BE%D0%BD%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D1%85%20%D0%B4%D0%B0%D0%BD%D0%BD%D1%8B%D1%85%20%D0%BF%D0%BE%D0%B4%D1%82%D0%B2%D0%B5%D1%80%D0%B6%D0%B4%D0%B0%D1%8E%3A%20http%3A%2F%2Fsber.me%2F%3Fp%3D5rVQP"
}');