--liquibase formatted sql
--changeset Mirov AA:duplicate_delete
delete from public.guide where code = '2034';
delete from public.guide where code = '2070' and name = 'Каймановы острова';
