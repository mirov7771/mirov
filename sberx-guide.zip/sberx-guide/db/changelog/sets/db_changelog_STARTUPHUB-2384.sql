--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2384
delete
from public.guide
where upper(name) = 'B2O';

