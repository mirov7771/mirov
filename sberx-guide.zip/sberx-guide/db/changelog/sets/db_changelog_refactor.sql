--liquibase formatted sql
--changeset Timoshkin MA:refactor
ALTER TABLE public.guide rename column id to guideid;

ALTER TABLE public.guide rename column entityid to id;

ALTER TABLE public.guide alter column guideid TYPE bigint;