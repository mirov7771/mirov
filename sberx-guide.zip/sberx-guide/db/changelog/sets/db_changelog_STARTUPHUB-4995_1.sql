--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-4995
update public.guide_lang
set value = 'Startup pilot program, including fast track'
where id in (select g.id from guide g
             where g.guideid = 4000
               and g.code = 4002)
  and lang_id = 2;

update public.guide_lang
set value = 'Specialized department at one University'
where id in (select g.id from guide g
             where g.guideid = 4000
               and g.code = 4008)
  and lang_id = 2;

update public.guide_lang
set value = 'Comoros'
where id in (select g.id from guide g
             where g.guideid = 2000
               and g.code = 2083)
  and lang_id = 2;

update public.guide_lang
set value = 'Latvia'
where id in (select g.id from guide g
             where g.guideid = 2000
               and g.code = 2093)
  and lang_id = 2;

update public.guide_lang
set value = 'Saint Vincent and the Grenadines'
where id in (select g.id from guide g
             where g.guideid = 2000
               and g.code = 2147)
  and lang_id = 2;

update public.guide_lang
set value = 'Czech Republic'
where id in (select g.id from guide g
             where g.guideid = 2000
               and g.code = 2184)
  and lang_id = 2;