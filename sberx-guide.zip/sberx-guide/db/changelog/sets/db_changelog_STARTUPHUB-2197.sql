--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-2197 Исправления текстов выпадающих списков

UPDATE public.guide SET  "name"='E-sports' where code=3050;
UPDATE public.guide SET  "name"='Транзакционная' where code=24002;



