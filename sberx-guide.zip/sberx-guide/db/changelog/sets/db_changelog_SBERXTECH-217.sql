--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-217
insert into guide_object
values(24000, 'BusinessModel', 'Бизнес модель');

insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Подписная', '24001');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', '	Транзакционная', '24002');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Рекламная', '24003');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Прямые продажи', '24004');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Freemium', '24005');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Лицензия', '24006');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Краудсорсинг', '24007');
insert into guide(entityid, id, name, code)
values ((select max(entityid)+1 from guide), '24000', 'Другое', '24008');