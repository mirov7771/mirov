--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3295
delete
from public.guide
where name = 'FMCG'
  and guideid = 8000;

delete
from public.guide
where guideid = 3000
  and name in (select name from guide where guideid = 13000);

delete
from public.guide_lang
where id not in (select id from guide);