--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-2786_2

UPDATE public.guide
SET "name"='Другое'
where code = 21003;

DELETE
from public.guide
where code = 3062;

INSERT INTO public.guide (id, guideid, "name", sysname, extra, icon, logofile, code, isdisabled, rang)
VALUES ((select max(id)+1 from guide),3000, 'Productivity tools', NULL, NULL, NULL, NULL, 3062, false, -61);
