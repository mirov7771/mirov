--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3350
update public.guide set rang = 9006 where code = 9001;
update public.guide set rang = 9005 where code = 9002;
update public.guide set rang = 9004 where code = 9003;
update public.guide set rang = 9003 where code = 9004;
update public.guide set rang = 9002 where code = 9005;
update public.guide set rang = 9001 where code = 9006;