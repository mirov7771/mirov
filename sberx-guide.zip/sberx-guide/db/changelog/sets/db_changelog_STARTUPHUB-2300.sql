--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2033 Пропал фильтр "Модель продаж"
UPDATE guide_object
SET "objectname" = 'Бизнес-модель'
where guideid = 2400;