--liquibase formatted sql
--changeset Mirov AA:for_lending
ALTER TABLE public.guide ALTER COLUMN extra TYPE varchar(150) USING extra::varchar;
update guide
set extra = extra||'&forLending=true'
where id = 1
  and extra not like '%forLending%';