--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-3458
select setval('public.guide_id_seq',  (SELECT max(id)+1 FROM public.guide g));
delete from public.guide_lang where lang_id = 2;
--guide 2000
insert into guide_lang select id, 'Russia', (select id from lang where locale = 'en') from guide where code = 2000;
insert into guide_lang select id, 'Australia', (select id from lang where locale = 'en') from guide where code = 2001;
insert into guide_lang select id, 'Austria', (select id from lang where locale = 'en') from guide where code = 2002;
insert into guide_lang select id, 'Azerbaijan', (select id from lang where locale = 'en') from guide where code = 2003;
insert into guide_lang select id, 'Albania', (select id from lang where locale = 'en') from guide where code = 2004;
insert into guide_lang select id, 'Algeria', (select id from lang where locale = 'en') from guide where code = 2005;
insert into guide_lang select id, 'Angola', (select id from lang where locale = 'en') from guide where code = 2006;
insert into guide_lang select id, 'Andorra', (select id from lang where locale = 'en') from guide where code = 2007;
insert into guide_lang select id, 'Antigua and Barbuda', (select id from lang where locale = 'en') from guide where code = 2008;
insert into guide_lang select id, 'Argentina', (select id from lang where locale = 'en') from guide where code = 2009;
insert into guide_lang select id, 'Armenia', (select id from lang where locale = 'en') from guide where code = 2010;
insert into guide_lang select id, 'Afghanistan', (select id from lang where locale = 'en') from guide where code = 2011;
insert into guide_lang select id, 'Bahamas', (select id from lang where locale = 'en') from guide where code = 2012;
insert into guide_lang select id, 'Bangladesh', (select id from lang where locale = 'en') from guide where code = 2013;
insert into guide_lang select id, 'Barbados', (select id from lang where locale = 'en') from guide where code = 2014;
insert into guide_lang select id, 'Bahrain', (select id from lang where locale = 'en') from guide where code = 2015;
insert into guide_lang select id, 'Belarus', (select id from lang where locale = 'en') from guide where code = 2016;
insert into guide_lang select id, 'Belize', (select id from lang where locale = 'en') from guide where code = 2017;
insert into guide_lang select id, 'Belgium', (select id from lang where locale = 'en') from guide where code = 2018;
insert into guide_lang select id, 'Benin', (select id from lang where locale = 'en') from guide where code = 2019;
insert into guide_lang select id, 'Bulgaria', (select id from lang where locale = 'en') from guide where code = 2020;
insert into guide_lang select id, 'Bolivia', (select id from lang where locale = 'en') from guide where code = 2021;
insert into guide_lang select id, 'Bosnia and Herzegovina', (select id from lang where locale = 'en') from guide where code = 2022;
insert into guide_lang select id, 'Botswana', (select id from lang where locale = 'en') from guide where code = 2023;
insert into guide_lang select id, 'Brazil', (select id from lang where locale = 'en') from guide where code = 2024;
insert into guide_lang select id, 'Brunei', (select id from lang where locale = 'en') from guide where code = 2025;
insert into guide_lang select id, 'Burkina Faso', (select id from lang where locale = 'en') from guide where code = 2026;
insert into guide_lang select id, 'Burundi', (select id from lang where locale = 'en') from guide where code = 2027;
insert into guide_lang select id, 'Bhutan', (select id from lang where locale = 'en') from guide where code = 2028;
insert into guide_lang select id, 'Vanuatu', (select id from lang where locale = 'en') from guide where code = 2029;
insert into guide_lang select id, 'Great Britain', (select id from lang where locale = 'en') from guide where code = 2030;
insert into guide_lang select id, 'Hungary', (select id from lang where locale = 'en') from guide where code = 2031;
insert into guide_lang select id, 'Venezuela', (select id from lang where locale = 'en') from guide where code = 2032;
insert into guide_lang select id, 'Virgin Islands', (select id from lang where locale = 'en') from guide where code = 2033;
insert into guide_lang select id, 'East Timor', (select id from lang where locale = 'en') from guide where code = 2035;
insert into guide_lang select id, 'Vietnam', (select id from lang where locale = 'en') from guide where code = 2036;
insert into guide_lang select id, 'Gabon', (select id from lang where locale = 'en') from guide where code = 2037;
insert into guide_lang select id, 'Haiti', (select id from lang where locale = 'en') from guide where code = 2038;
insert into guide_lang select id, 'Guyana', (select id from lang where locale = 'en') from guide where code = 2039;
insert into guide_lang select id, 'Gambia', (select id from lang where locale = 'en') from guide where code = 2040;
insert into guide_lang select id, 'Ghana', (select id from lang where locale = 'en') from guide where code = 2041;
insert into guide_lang select id, 'Guatemala', (select id from lang where locale = 'en') from guide where code = 2042;
insert into guide_lang select id, 'Guinea', (select id from lang where locale = 'en') from guide where code = 2043;
insert into guide_lang select id, 'Guinea-Bissau', (select id from lang where locale = 'en') from guide where code = 2044;
insert into guide_lang select id, 'Germany', (select id from lang where locale = 'en') from guide where code = 2045;
insert into guide_lang select id, 'Honduras', (select id from lang where locale = 'en') from guide where code = 2046;
insert into guide_lang select id, 'Grenada', (select id from lang where locale = 'en') from guide where code = 2047;
insert into guide_lang select id, 'Greece', (select id from lang where locale = 'en') from guide where code = 2048;
insert into guide_lang select id, 'Georgia', (select id from lang where locale = 'en') from guide where code = 2049;
insert into guide_lang select id, 'North KOREA', (select id from lang where locale = 'en') from guide where code = 2086;
insert into guide_lang select id, 'Denmark', (select id from lang where locale = 'en') from guide where code = 2050;
insert into guide_lang select id, 'Djibouti', (select id from lang where locale = 'en') from guide where code = 2051;
insert into guide_lang select id, 'Dominika', (select id from lang where locale = 'en') from guide where code = 2052;
insert into guide_lang select id, 'Dominicana', (select id from lang where locale = 'en') from guide where code = 2053;
insert into guide_lang select id, 'Egypt', (select id from lang where locale = 'en') from guide where code = 2054;
insert into guide_lang select id, 'Zambia', (select id from lang where locale = 'en') from guide where code = 2055;
insert into guide_lang select id, 'Zimbabwe', (select id from lang where locale = 'en') from guide where code = 2056;
insert into guide_lang select id, 'Israel', (select id from lang where locale = 'en') from guide where code = 2057;
insert into guide_lang select id, 'India', (select id from lang where locale = 'en') from guide where code = 2058;
insert into guide_lang select id, 'Indonesia', (select id from lang where locale = 'en') from guide where code = 2059;
insert into guide_lang select id, 'Jordan', (select id from lang where locale = 'en') from guide where code = 2060;
insert into guide_lang select id, 'Iraq', (select id from lang where locale = 'en') from guide where code = 2061;
insert into guide_lang select id, 'Iran', (select id from lang where locale = 'en') from guide where code = 2062;
insert into guide_lang select id, 'Ireland', (select id from lang where locale = 'en') from guide where code = 2063;
insert into guide_lang select id, 'Iceland', (select id from lang where locale = 'en') from guide where code = 2064;
insert into guide_lang select id, 'Spain', (select id from lang where locale = 'en') from guide where code = 2065;
insert into guide_lang select id, 'Italy', (select id from lang where locale = 'en') from guide where code = 2066;
insert into guide_lang select id, 'Yemen', (select id from lang where locale = 'en') from guide where code = 2067;
insert into guide_lang select id, 'Korea', (select id from lang where locale = 'en') from guide where code = 2087;
insert into guide_lang select id, 'Cape Verde', (select id from lang where locale = 'en') from guide where code = 2069;
insert into guide_lang select id, 'Kazakhstan', (select id from lang where locale = 'en') from guide where code = 2070;
insert into guide_lang select id, 'Cayman Islands', (select id from lang where locale = 'en') from guide where code = 2068;
insert into guide_lang select id, 'Cambodia', (select id from lang where locale = 'en') from guide where code = 2073;
insert into guide_lang select id, 'Cameroon', (select id from lang where locale = 'en') from guide where code = 2074;
insert into guide_lang select id, 'Canada', (select id from lang where locale = 'en') from guide where code = 2075;
insert into guide_lang select id, 'Qatar', (select id from lang where locale = 'en') from guide where code = 2076;
insert into guide_lang select id, 'Kenya', (select id from lang where locale = 'en') from guide where code = 2077;
insert into guide_lang select id, 'Cyprus', (select id from lang where locale = 'en') from guide where code = 2078;
insert into guide_lang select id, 'Kyrgyzstan', (select id from lang where locale = 'en') from guide where code = 2079;
insert into guide_lang select id, 'Kiribati', (select id from lang where locale = 'en') from guide where code = 2080;
insert into guide_lang select id, 'China', (select id from lang where locale = 'en') from guide where code = 2081;
insert into guide_lang select id, 'Colombia', (select id from lang where locale = 'en') from guide where code = 2082;
insert into guide_lang select id, 'Komors', (select id from lang where locale = 'en') from guide where code = 2083;
insert into guide_lang select id, 'Congo', (select id from lang where locale = 'en') from guide where code = 2084;
insert into guide_lang select id, 'DR Congo', (select id from lang where locale = 'en') from guide where code = 2085;
insert into guide_lang select id, 'Costa Rica', (select id from lang where locale = 'en') from guide where code = 2088;
insert into guide_lang select id, 'Ivory Coast', (select id from lang where locale = 'en') from guide where code = 2089;
insert into guide_lang select id, 'Cuba', (select id from lang where locale = 'en') from guide where code = 2090;
insert into guide_lang select id, 'Kuwait', (select id from lang where locale = 'en') from guide where code = 2091;
insert into guide_lang select id, 'Laos', (select id from lang where locale = 'en') from guide where code = 2092;
insert into guide_lang select id, 'Latvian', (select id from lang where locale = 'en') from guide where code = 2093;
insert into guide_lang select id, 'Lesotho', (select id from lang where locale = 'en') from guide where code = 2094;
insert into guide_lang select id, 'Liberia', (select id from lang where locale = 'en') from guide where code = 2095;
insert into guide_lang select id, 'Lebanon', (select id from lang where locale = 'en') from guide where code = 2096;
insert into guide_lang select id, 'Libya', (select id from lang where locale = 'en') from guide where code = 2097;
insert into guide_lang select id, 'Lithuania', (select id from lang where locale = 'en') from guide where code = 2098;
insert into guide_lang select id, 'Liechtenstein', (select id from lang where locale = 'en') from guide where code = 2099;
insert into guide_lang select id, 'Luxembourg', (select id from lang where locale = 'en') from guide where code = 2100;
insert into guide_lang select id, 'Mauritius', (select id from lang where locale = 'en') from guide where code = 2101;
insert into guide_lang select id, 'Mauritania', (select id from lang where locale = 'en') from guide where code = 2102;
insert into guide_lang select id, 'Madagascar', (select id from lang where locale = 'en') from guide where code = 2103;
insert into guide_lang select id, 'Malawi ', (select id from lang where locale = 'en') from guide where code = 2104;
insert into guide_lang select id, 'Malaysia', (select id from lang where locale = 'en') from guide where code = 2105;
insert into guide_lang select id, 'Mali', (select id from lang where locale = 'en') from guide where code = 2106;
insert into guide_lang select id, 'Maldives', (select id from lang where locale = 'en') from guide where code = 2107;
insert into guide_lang select id, 'Malta', (select id from lang where locale = 'en') from guide where code = 2108;
insert into guide_lang select id, 'Morocco', (select id from lang where locale = 'en') from guide where code = 2109;
insert into guide_lang select id, 'Marshall Islands', (select id from lang where locale = 'en') from guide where code = 2110;
insert into guide_lang select id, 'Mexico', (select id from lang where locale = 'en') from guide where code = 2111;
insert into guide_lang select id, 'Mozambique', (select id from lang where locale = 'en') from guide where code = 2112;
insert into guide_lang select id, 'Fiji ', (select id from lang where locale = 'en') from guide where code = 2176;
insert into guide_lang select id, 'Moldova', (select id from lang where locale = 'en') from guide where code = 2113;
insert into guide_lang select id, 'Monaco', (select id from lang where locale = 'en') from guide where code = 2114;
insert into guide_lang select id, 'Mongolia', (select id from lang where locale = 'en') from guide where code = 2115;
insert into guide_lang select id, 'Myanmar', (select id from lang where locale = 'en') from guide where code = 2116;
insert into guide_lang select id, 'Namibia', (select id from lang where locale = 'en') from guide where code = 2117;
insert into guide_lang select id, 'Nauru', (select id from lang where locale = 'en') from guide where code = 2118;
insert into guide_lang select id, 'Nepal', (select id from lang where locale = 'en') from guide where code = 2119;
insert into guide_lang select id, 'Niger', (select id from lang where locale = 'en') from guide where code = 2120;
insert into guide_lang select id, 'Nigeria', (select id from lang where locale = 'en') from guide where code = 2121;
insert into guide_lang select id, 'Netherlands', (select id from lang where locale = 'en') from guide where code = 2122;
insert into guide_lang select id, 'Nicaragua', (select id from lang where locale = 'en') from guide where code = 2123;
insert into guide_lang select id, 'New Zealand', (select id from lang where locale = 'en') from guide where code = 2124;
insert into guide_lang select id, 'Norway', (select id from lang where locale = 'en') from guide where code = 2125;
insert into guide_lang select id, 'UAE', (select id from lang where locale = 'en') from guide where code = 2126;
insert into guide_lang select id, 'Oman', (select id from lang where locale = 'en') from guide where code = 2127;
insert into guide_lang select id, 'Pakistan', (select id from lang where locale = 'en') from guide where code = 2128;
insert into guide_lang select id, 'Palau', (select id from lang where locale = 'en') from guide where code = 2129;
insert into guide_lang select id, 'Panama hat', (select id from lang where locale = 'en') from guide where code = 2130;
insert into guide_lang select id, 'Papua New Guinea', (select id from lang where locale = 'en') from guide where code = 2131;
insert into guide_lang select id, 'Paraguay', (select id from lang where locale = 'en') from guide where code = 2132;
insert into guide_lang select id, 'Peru', (select id from lang where locale = 'en') from guide where code = 2133;
insert into guide_lang select id, 'Poland', (select id from lang where locale = 'en') from guide where code = 2134;
insert into guide_lang select id, 'Portugal', (select id from lang where locale = 'en') from guide where code = 2135;
insert into guide_lang select id, 'Rwanda', (select id from lang where locale = 'en') from guide where code = 2137;
insert into guide_lang select id, 'Romania', (select id from lang where locale = 'en') from guide where code = 2138;
insert into guide_lang select id, 'El Salvador', (select id from lang where locale = 'en') from guide where code = 2139;
insert into guide_lang select id, 'Solomon Islands', (select id from lang where locale = 'en') from guide where code = 2156;
insert into guide_lang select id, 'Samoa', (select id from lang where locale = 'en') from guide where code = 2140;
insert into guide_lang select id, 'San Marino', (select id from lang where locale = 'en') from guide where code = 2141;
insert into guide_lang select id, 'Sao Tome and Principe', (select id from lang where locale = 'en') from guide where code = 2142;
insert into guide_lang select id, 'Saudi Arabia', (select id from lang where locale = 'en') from guide where code = 2143;
insert into guide_lang select id, 'Northern Macedonia', (select id from lang where locale = 'en') from guide where code = 2144;
insert into guide_lang select id, 'Seychelles', (select id from lang where locale = 'en') from guide where code = 2145;
insert into guide_lang select id, 'Senegal', (select id from lang where locale = 'en') from guide where code = 2146;
insert into guide_lang select id, 'Saint Vincent of the Grenadines', (select id from lang where locale = 'en') from guide where code = 2147;
insert into guide_lang select id, 'Saint Kitts and Nevis', (select id from lang where locale = 'en') from guide where code = 2148;
insert into guide_lang select id, 'Saint Lucia', (select id from lang where locale = 'en') from guide where code = 2149;
insert into guide_lang select id, 'Serbia', (select id from lang where locale = 'en') from guide where code = 2150;
insert into guide_lang select id, 'Singapore', (select id from lang where locale = 'en') from guide where code = 2151;
insert into guide_lang select id, 'Syria', (select id from lang where locale = 'en') from guide where code = 2152;
insert into guide_lang select id, 'Slovakia', (select id from lang where locale = 'en') from guide where code = 2153;
insert into guide_lang select id, 'Slovenia', (select id from lang where locale = 'en') from guide where code = 2154;
insert into guide_lang select id, 'USA', (select id from lang where locale = 'en') from guide where code = 2155;
insert into guide_lang select id, 'Somalia', (select id from lang where locale = 'en') from guide where code = 2157;
insert into guide_lang select id, 'Sudan', (select id from lang where locale = 'en') from guide where code = 2158;
insert into guide_lang select id, 'Suriname', (select id from lang where locale = 'en') from guide where code = 2159;
insert into guide_lang select id, 'Sierra Leone', (select id from lang where locale = 'en') from guide where code = 2160;
insert into guide_lang select id, 'Tajikistan', (select id from lang where locale = 'en') from guide where code = 2161;
insert into guide_lang select id, 'Thailand', (select id from lang where locale = 'en') from guide where code = 2162;
insert into guide_lang select id, 'Tanzania', (select id from lang where locale = 'en') from guide where code = 2163;
insert into guide_lang select id, 'Togo', (select id from lang where locale = 'en') from guide where code = 2164;
insert into guide_lang select id, 'Tonga', (select id from lang where locale = 'en') from guide where code = 2165;
insert into guide_lang select id, 'Trinidad and Tobago', (select id from lang where locale = 'en') from guide where code = 2166;
insert into guide_lang select id, 'Tuvalu', (select id from lang where locale = 'en') from guide where code = 2167;
insert into guide_lang select id, 'Tunisia', (select id from lang where locale = 'en') from guide where code = 2168;
insert into guide_lang select id, 'Turkmenistan', (select id from lang where locale = 'en') from guide where code = 2169;
insert into guide_lang select id, 'Turkey', (select id from lang where locale = 'en') from guide where code = 2170;
insert into guide_lang select id, 'Uganda', (select id from lang where locale = 'en') from guide where code = 2171;
insert into guide_lang select id, 'Uzbekistan', (select id from lang where locale = 'en') from guide where code = 2172;
insert into guide_lang select id, 'Ukraine', (select id from lang where locale = 'en') from guide where code = 2173;
insert into guide_lang select id, 'Uruguay', (select id from lang where locale = 'en') from guide where code = 2174;
insert into guide_lang select id, 'Micronesia', (select id from lang where locale = 'en') from guide where code = 2175;
insert into guide_lang select id, 'Philippines', (select id from lang where locale = 'en') from guide where code = 2177;
insert into guide_lang select id, 'Finland', (select id from lang where locale = 'en') from guide where code = 2178;
insert into guide_lang select id, 'France', (select id from lang where locale = 'en') from guide where code = 2179;
insert into guide_lang select id, 'Croatia', (select id from lang where locale = 'en') from guide where code = 2180;
insert into guide_lang select id, 'Central African Republic', (select id from lang where locale = 'en') from guide where code = 2181;
insert into guide_lang select id, 'Chad', (select id from lang where locale = 'en') from guide where code = 2182;
insert into guide_lang select id, 'Montenegro', (select id from lang where locale = 'en') from guide where code = 2183;
insert into guide_lang select id, 'Czech', (select id from lang where locale = 'en') from guide where code = 2184;
insert into guide_lang select id, 'Chile ', (select id from lang where locale = 'en') from guide where code = 2185;
insert into guide_lang select id, 'Switzerland', (select id from lang where locale = 'en') from guide where code = 2186;
insert into guide_lang select id, 'Sweden', (select id from lang where locale = 'en') from guide where code = 2187;
insert into guide_lang select id, 'Sri Lanka', (select id from lang where locale = 'en') from guide where code = 2188;
insert into guide_lang select id, 'Ecuador', (select id from lang where locale = 'en') from guide where code = 2189;
insert into guide_lang select id, 'Equatorial Guinea', (select id from lang where locale = 'en') from guide where code = 2190;
insert into guide_lang select id, 'Eritrea', (select id from lang where locale = 'en') from guide where code = 2191;
insert into guide_lang select id, 'Eswatini', (select id from lang where locale = 'en') from guide where code = 2192;
insert into guide_lang select id, 'Estonia', (select id from lang where locale = 'en') from guide where code = 2193;
insert into guide_lang select id, 'Ethiopia', (select id from lang where locale = 'en') from guide where code = 2194;
insert into guide_lang select id, 'South AFRICA', (select id from lang where locale = 'en') from guide where code = 2195;
insert into guide_lang select id, 'South Sudan', (select id from lang where locale = 'en') from guide where code = 2196;
insert into guide_lang select id, 'Jamaica', (select id from lang where locale = 'en') from guide where code = 2197;
insert into guide_lang select id, 'Japan', (select id from lang where locale = 'en') from guide where code = 2198;

--guide 3000
insert into guide_lang select id, name, (select id from lang where locale = 'en') from guide where guideid = 3000;

--guide 5000
insert into guide_lang select id, 'No sales', (select id from lang where locale = 'en') from guide where code = 5001;
insert into guide_lang select id, 'There are postpaid contracts', (select id from lang where locale = 'en') from guide where code = 5002;
insert into guide_lang select id, 'There are sales in the Russian Federation', (select id from lang where locale = 'en') from guide where code = 5003;
insert into guide_lang select id, 'There are sales in foreign markets', (select id from lang where locale = 'en') from guide where code = 5004;

--guide 8000
insert into guide_lang select id, name, (select id from lang where locale = 'en') from guide where guideid = 8000;

--guide 13000
insert into guide_lang select id, name, (select id from lang where locale = 'en') from guide where guideid = 13000;

--guide 21000
insert into guide_lang select id, 'Crunchbase', (select id from lang where locale = 'en') from guide where code = 21001;
insert into guide_lang select id, 'Facebook', (select id from lang where locale = 'en') from guide where code = 21002;
insert into guide_lang select id, 'Other', (select id from lang where locale = 'en') from guide where code = 21003;

--guide 24000
insert into guide_lang select id, 'Subscription', (select id from lang where locale = 'en') from guide where code = 24001;
insert into guide_lang select id, 'Transactional', (select id from lang where locale = 'en') from guide where code = 24002;
insert into guide_lang select id, 'Advertising', (select id from lang where locale = 'en') from guide where code = 24003;
insert into guide_lang select id, 'Direct sales', (select id from lang where locale = 'en') from guide where code = 24004;
insert into guide_lang select id, 'Freemium', (select id from lang where locale = 'en') from guide where code = 24005;
insert into guide_lang select id, 'License', (select id from lang where locale = 'en') from guide where code = 24006;
insert into guide_lang select id, 'Crowdsourcing', (select id from lang where locale = 'en') from guide where code = 24007;
insert into guide_lang select id, 'Other', (select id from lang where locale = 'en') from guide where code = 24008;

--guide 27000
insert into guide_lang select id, 'Idea', (select id from lang where locale = 'en') from guide where code = 27001;
insert into guide_lang select id, 'Prototype, no sales', (select id from lang where locale = 'en') from guide where code = 27002;
insert into guide_lang select id, 'MVP, first sales', (select id from lang where locale = 'en') from guide where code = 27003;
insert into guide_lang select id, 'Early growth', (select id from lang where locale = 'en') from guide where code = 27004;
insert into guide_lang select id, 'Scaling', (select id from lang where locale = 'en') from guide where code = 27005;
insert into guide_lang select id, 'Late growth', (select id from lang where locale = 'en') from guide where code = 27006;


--guide 38000
delete from public.guide_object where guideid = 38000;
delete from public.guide where guideid = 38000;
delete from public.guide_object_lang where id not in (select guideid from public.guide_object);
delete from public.guide_lang where id not in (select id from public.guide);
INSERT INTO public.guide_object (guideid,objectname,attributename) VALUES
    (38000,'EcoRequirement','Потребности экосистемы');
INSERT INTO public.guide_object_lang (id,value,lang_id) VALUES
    (38000,'Ecosystem needs',1);
INSERT INTO public.guide_object_lang (id,value,lang_id) VALUES
    (38000,'Ecosystem needs',2);
INSERT INTO public.guide (guideid,name,sysname,extra,icon,logofile,code,isdisabled,rang) VALUES
                                                                                             (38000,'AdTech&MarTech',NULL,NULL,NULL,NULL,38001,false,NULL),
                                                                                             (38000,'Autonomous',NULL,NULL,NULL,NULL,38002,false,NULL),
                                                                                             (38000,'CloudTech',NULL,NULL,NULL,NULL,38003,false,NULL),
                                                                                             (38000,'Cybersecurity',NULL,NULL,NULL,NULL,38004,false,NULL),
                                                                                             (38000,'DeepTech',NULL,NULL,NULL,NULL,38005,false,NULL),
                                                                                             (38000,'E-commerce',NULL,NULL,NULL,NULL,38006,false,NULL),
                                                                                             (38000,'EdTech',NULL,NULL,NULL,NULL,38007,false,NULL),
                                                                                             (38000,'Entertainment',NULL,NULL,NULL,NULL,38008,false,NULL),
                                                                                             (38000,'FinTech',NULL,NULL,NULL,NULL,38009,false,NULL),
                                                                                             (38000,'Fitness/WellBeing',NULL,NULL,NULL,NULL,38010,false,NULL);
INSERT INTO public.guide (guideid,name,sysname,extra,icon,logofile,code,isdisabled,rang) VALUES
                                                                                             (38000,'FoodTech',NULL,NULL,NULL,NULL,38011,false,NULL),
                                                                                             (38000,'Gaming',NULL,NULL,NULL,NULL,38012,false,NULL),
                                                                                             (38000,'Healthcare',NULL,NULL,NULL,NULL,38013,false,NULL),
                                                                                             (38000,'LegalTech',NULL,NULL,NULL,NULL,38016,false,NULL),
                                                                                             (38000,'HR-Tech',NULL,NULL,NULL,NULL,38014,false,NULL),
                                                                                             (38000,'Insurance',NULL,NULL,NULL,NULL,38015,false,NULL),
                                                                                             (38000,'Mapping',NULL,NULL,NULL,NULL,38017,false,NULL),
                                                                                             (38000,'Mobility',NULL,NULL,NULL,NULL,38018,false,NULL),
                                                                                             (38000,'PropTech',NULL,NULL,NULL,NULL,38019,false,NULL);
insert into guide_lang select id, name, (select id from lang where locale = 'en') from guide where guideid = 38000;
insert into guide_lang select id, name, (select id from lang where locale = 'ru') from guide where guideid = 38000;
