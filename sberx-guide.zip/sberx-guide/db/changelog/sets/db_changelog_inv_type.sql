--liquibase formatted sql
--changeset Mirov AA:inv_type
delete
from public.guide
where guideid = 11000
  and name = 'Институт развития';

delete
from public.guide_lang
where id not in (select id from guide);