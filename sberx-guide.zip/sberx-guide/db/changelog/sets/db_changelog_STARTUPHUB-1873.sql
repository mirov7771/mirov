--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-1873 Добавление статуса "Выполнен"

INSERT INTO public.guide (guideid, name, sysname, extra, icon, logofile, code, isdisabled, rang, isfilter) VALUES(20000, 'Выполнена', 'done', 'all', NULL, NULL, 20015, false, NULL, true);


