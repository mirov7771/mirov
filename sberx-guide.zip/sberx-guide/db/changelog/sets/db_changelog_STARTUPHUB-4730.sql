--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4730
drop table if exists bad_URL;
create table bad_URL
(
    VALUE VARCHAR(150) PRIMARY KEY
);