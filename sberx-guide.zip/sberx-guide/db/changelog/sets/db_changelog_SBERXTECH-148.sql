--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-148
update guide set code = code+1 where code > 2032;
insert into public.guide
values((select max(entityid)+1 from public.guide), 2000, 'Виргинские острова', null, null, null, null, 2033, false, null);

update guide set code = code+1 where code > 2067;
insert into public.guide
values((select max(entityid)+1 from public.guide), 2000, 'Каймановы острова', null, null, null, null, 2068, false, null);
