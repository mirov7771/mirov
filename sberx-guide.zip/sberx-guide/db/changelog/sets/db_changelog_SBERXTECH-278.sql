--liquibase formatted sql
--changeset Molotkov D:SBERXTECH-278
UPDATE guide_object SET attributename='Модель продаж' WHERE guideid=8000;
UPDATE guide_object SET  attributename='Бизнес-модель' WHERE guideid=24000;
