--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4653
delete from public.guide where code = 20016;
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 20000, 'На удаление', 20016, false);