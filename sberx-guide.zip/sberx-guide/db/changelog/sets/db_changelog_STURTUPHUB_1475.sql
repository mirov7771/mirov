--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1475 Изменение названия элементов справосников и добавить элементы


UPDATE public.guide SET "name"='Adtech & Martech' WHERE code=3001;
INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid)+1 from guide), 3000, 'Telecom', NULL, NULL, NULL, NULL, 3036, false, NULL);
UPDATE public.guide SET  "name"='Беларусь' WHERE code=2016;
UPDATE public.guide SET isdisabled=true WHERE code=8009;
INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid)+1 from guide), 22000, 'Аэроосмческая отрасль', NULL, NULL, NULL, NULL, 22027, false, NULL);

