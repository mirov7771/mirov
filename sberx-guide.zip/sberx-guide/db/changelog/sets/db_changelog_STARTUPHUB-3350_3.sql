--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3350_3
delete from public.guide_object where guideid = 38000;
insert into public.guide_object values (38000, 'EcoRequirement', 'Потребности экосистемы');

delete from public.guide where guideid = 38000;
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'AdTech&MarTech', 38001, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Autonomous', 38002, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'CloudTech', 38003, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Cybersecurity', 38004, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'DeepTech', 38005, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'E-commerce', 38006, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'EdTech', 38007, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Entertainment', 38008, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'FinTech', 38009, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Fitness/WellBeing', 38010, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'FoodTech', 38011, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Gaming', 38012, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Healthcare', 38013, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'HR-Tech', 38014, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Insurance', 38015, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'LegalTech', 38016, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Mapping', 38017, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'Mobility', 38018, false);
insert into public.guide (id, guideid, name, code, isdisabled) values ((select max(id)+1 from public.guide), 38000, 'PropTech', 38019, false);

insert into guide_lang
select id, name, (select id from lang where locale = 'ru')
from guide g
where not exists(select 1 from guide_lang l where g.id = l.id);

insert into guide_object_lang
select guideid, attributename, (select id from lang where locale = 'ru')
from guide_object g
where not exists(select 1 from guide_object_lang l where g.guideid = l.id);