--liquibase formatted sql
--changeset Mirov AA:short_state
insert into guide (entityid, id, name, sysname, extra, code, isdisabled)
values ((select max(entityid)+1 from guide), '20000', 'Предзаполненная анкета', 'short', 'all', '20010', false);