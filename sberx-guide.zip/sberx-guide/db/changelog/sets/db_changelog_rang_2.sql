--liquibase formatted sql
--changeset Mirov AA:rang_2
update public.guide
set rang = rang*-1
where id in ('22000','3000');