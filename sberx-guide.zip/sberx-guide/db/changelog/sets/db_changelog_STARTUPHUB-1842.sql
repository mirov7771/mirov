--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1842 Изменить название технологии

UPDATE public.guide_object SET attributename='Индустрии и технологии' WHERE guideid=3000;
