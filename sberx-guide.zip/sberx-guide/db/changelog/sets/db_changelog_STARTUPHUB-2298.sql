--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-2298

UPDATE public.guide SET  isdisabled=true  WHERE  code=11003;
