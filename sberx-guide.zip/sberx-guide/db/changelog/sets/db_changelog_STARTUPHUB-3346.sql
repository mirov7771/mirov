--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3346
delete from public.guide where code = 20014;
insert into public.guide (id, guideid, name, sysname, extra, code, isdisabled)
values((select max(Id) + 1 from public.guide), 20000, 'Не активна', 'disable', 'all', 20014, false);