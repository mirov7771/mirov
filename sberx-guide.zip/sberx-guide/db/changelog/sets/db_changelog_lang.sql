--liquibase formatted sql
--changeset Mirov AA:lang_locale
drop table if exists lang;
create table lang(
                     id bigserial primary key,
                     locale varchar
);

insert into lang (locale)
values ('ru'),('en');


drop table if exists guide_object_lang;
create table guide_object_lang (
                                   id bigint,
                                   value varchar,
                                   lang_id bigint
);

create index x1_guide_object_lang on guide_object_lang(id);

insert into guide_object_lang
select guideid, attributename, (select id from lang where locale = 'ru')
from guide_object;

drop table if exists guide_lang;
create table guide_lang (
                            id bigint,
                            value varchar,
                            lang_id bigint
);

create index x1_guide_lang on guide_lang(id);

insert into guide_lang
select id, name, (select id from lang where locale = 'ru')
from guide;
