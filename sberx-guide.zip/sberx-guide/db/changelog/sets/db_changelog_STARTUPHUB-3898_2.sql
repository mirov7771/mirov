--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3898_2
delete
from public.guide_lang
where id in (
    select id
    from public.guide g
    where guideid = 10000
)
  and lang_id = 2;

insert into public.guide_lang (id,value,lang_id)
values(996, 'For team work', 2);
insert into public.guide_lang (id,value,lang_id)
values(997, 'Juridical/accounting services', 2);
insert into public.guide_lang (id,value,lang_id)
values(998, 'Operating activities', 2);
insert into public.guide_lang (id,value,lang_id)
values(999, 'Marketing', 2);
insert into public.guide_lang (id,value,lang_id)
values(1000, 'Product development', 2);
insert into public.guide_lang (id,value,lang_id)
values(1001, 'Sales', 2);
insert into public.guide_lang (id,value,lang_id)
values(1002, 'Banking services', 2);
insert into public.guide_lang (id,value,lang_id)
values(1003, 'Learning and growth', 2);
insert into public.guide_lang (id,value,lang_id)
values(1004, 'Cloud Solutions', 2);