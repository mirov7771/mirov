--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4856
alter table faq_topic drop column if exists lang_id;
alter table faq_topic add column lang_id integer null;

alter table faq_question drop column if exists lang_id;
alter table faq_question add column lang_id integer null;

update faq_topic set lang_id = 1;
update faq_question set lang_id = 1;

