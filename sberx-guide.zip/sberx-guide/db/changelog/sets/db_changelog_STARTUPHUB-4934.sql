--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-4934
create table if not exists import_replace_guid
(
    value varchar primary key,
    name varchar
);