--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-47

delete from guide where id = 3000;

INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Adtech', NULL, NULL, NULL, NULL, 3001, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Aero and space', NULL, NULL, NULL, NULL, 3002, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'AI', NULL, NULL, NULL, NULL, 3003, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Agrotech', NULL, NULL, NULL, NULL, 3004, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'AR/VR', NULL, NULL, NULL, NULL, 3005, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Biotech', NULL, NULL, NULL, NULL, 3007, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Blockchain', NULL, NULL, NULL, NULL, 3008, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Community', NULL, NULL, NULL, NULL, 3009, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Cybersecurity', NULL, NULL, NULL, NULL, 3010, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Deeptech', NULL, NULL, NULL, NULL, 3011, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'E-commerce', NULL, NULL, NULL, NULL, 3012, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Edtech', NULL, NULL, NULL, NULL, 3013, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Energy', NULL, NULL, NULL, NULL, 3014, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Entertainment', NULL, NULL, NULL, NULL, 3015, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Fashiontech', NULL, NULL, NULL, NULL, 3016, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Fintech', NULL, NULL, NULL, NULL, 3017, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Fitness / Wellbeing', NULL, NULL, NULL, NULL, 3018, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Foodtech', NULL, NULL, NULL, NULL, 3019, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Gaming', NULL, NULL, NULL, NULL, 3020, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Healthcare', NULL, NULL, NULL, NULL, 3021, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Insurance', NULL, NULL, NULL, NULL, 3022, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'IoT', NULL, NULL, NULL, NULL, 3023, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Media', NULL, NULL, NULL, NULL, 3024, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Legaltech', NULL, NULL, NULL, NULL, 3025, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Proptech', NULL, NULL, NULL, NULL, 3026, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Retail', NULL, NULL, NULL, NULL, 3027, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Recruiting', NULL, NULL, NULL, NULL, 3028, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Robotics', NULL, NULL, NULL, NULL, 3029, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'SaaS', NULL, NULL, NULL, NULL, 3030, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Security', NULL, NULL, NULL, NULL, 3031, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Smart City', NULL, NULL, NULL, NULL, 3032, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Big Data', NULL, NULL, NULL, NULL, 3006, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Transportation', NULL, NULL, NULL, NULL, 3033, false, NULL);
INSERT INTO guide
( id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Travel', NULL, NULL, NULL, NULL, 3034, false, NULL);
INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Other', NULL, NULL, NULL, NULL, 3035, false, NULL);

INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'HRtech', NULL, NULL, NULL, NULL, 3036, false, NULL);
INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Funtech', NULL, NULL, NULL, NULL, 3037, false, NULL);
INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Sporttech', NULL, NULL, NULL, NULL, 3038, false, NULL);
INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Cybersport', NULL, NULL, NULL, NULL, 3039, false, NULL);
INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Spacetech', NULL, NULL, NULL, NULL, 3040, false, NULL);
INSERT INTO guide
(id, name, sysname, extra, icon, logofile, code, isdisabled, value)
VALUES( 3000, 'Alternative Energy', NULL, NULL, NULL, NULL, 3041, false, NULL);

