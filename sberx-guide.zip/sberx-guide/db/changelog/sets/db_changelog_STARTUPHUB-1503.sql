--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1503 Добавлеени справочника Аксеелераторов
delete from public.guide where id = 26000;
delete from public.guide where id = 27000;
delete from public.guide_object where guideid = 26000;
delete from public.guide_object where guideid = 27000;

INSERT INTO public.guide (entityid , id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 26000, 'Sber500', NULL, NULL, NULL, NULL, 26001, false, NULL);
INSERT INTO public.guide (entityid , id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 26000, 'SberUP', NULL, NULL, NULL, NULL, 26002, false, NULL);
INSERT INTO public.guide (entityid , id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 26000, 'SberZ', NULL, NULL, NULL, NULL, 26003, false, NULL);
INSERT INTO public.guide (entityid , id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 26000, 'SberStudent', NULL, NULL, NULL, NULL, 26004, false, NULL);

INSERT INTO public.guide_object (guideid, objectname, attributename) VALUES(26000, 'accelerator', 'Выпускник акселераторов');


INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 27000, 'Идея', NULL, NULL, NULL, NULL, 27001, false, NULL);
INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 27000, 'Прототип', NULL, NULL, NULL, NULL, 27002, false, NULL);
INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 27000, 'MVP', NULL, NULL, NULL, NULL, 27003, false, NULL);
INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 27000, 'Готовый продукт', NULL, NULL, NULL, NULL, 27004, false, NULL);

INSERT INTO public.guide_object (guideid, objectname, attributename) VALUES(27000, 'MVP', 'Стадия развития продукта');
