--liquibase formatted sql
--changeset Timoshkin MA:delete_guide_value
ALTER TABLE public.guide drop column value;