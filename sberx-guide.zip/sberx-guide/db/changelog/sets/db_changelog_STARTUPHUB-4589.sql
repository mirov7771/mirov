--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4589
delete from guide where code = 21002;