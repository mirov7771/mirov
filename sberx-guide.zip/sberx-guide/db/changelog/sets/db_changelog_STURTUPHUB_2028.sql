--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-2028 Изменение справочника стадии развития редактирование старых

UPDATE public.guide SET  "name"='Прототип, продаж нет'  WHERE code=27002;
UPDATE public.guide SET  "name"='MVP, первые продажи'  WHERE code=27003;
UPDATE public.guide SET  "name"='Ранний рост'  WHERE code=27004;

INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 27000, 'Масштабирование', NULL, NULL, NULL, NULL, 27005, false, NULL);
INSERT INTO public.guide (entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value) VALUES((select max(entityid) + 1 from public.guide), 27000, 'Поздний рост', NULL, NULL, NULL, NULL, 27006, false, NULL);




