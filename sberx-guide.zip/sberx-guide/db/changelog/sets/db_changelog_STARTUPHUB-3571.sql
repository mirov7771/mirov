--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3571
select setval('public.guide_id_seq',  (SELECT max(id)+1 FROM public.guide g));

insert into public.guide_object values (39000, 'SumInvestment', 'Сумма инвестиций');

insert into public.guide_object_lang values(39000, 'SumInvestment', (select id from lang where locale = 'ru'));
insert into public.guide_object_lang values(39000, 'SumInvestment', (select id from lang where locale = 'en'));

insert into public.guide (guideid, name, code, isdisabled, rang) values (39000, 'Комфортно инвестировать от $20К, 1-2 раза в год', 39001, false, 4);
insert into public.guide (guideid, name, code, isdisabled, rang) values (39000, 'Готов выделять $50К - $250K на венчурные сделки', 39002, false, 3);
insert into public.guide (guideid, name, code, isdisabled, rang) values (39000, 'Готов инвестировать более $250K в год', 39003, false, 2);
insert into public.guide (guideid, name, code, isdisabled, rang) values (39000, 'Менее 20К', 39004, false, 1);

insert into public.guide_lang values ((select id from guide where code = 39001), 'Комфортно инвестировать от $20К, 1-2 раза в год', (select id from lang where locale = 'ru'));
insert into public.guide_lang values ((select id from guide where code = 39002), 'Готов выделять $50К - $250K на венчурные сделки', (select id from lang where locale = 'ru'));
insert into public.guide_lang values ((select id from guide where code = 39003), 'Готов инвестировать более $250K в год', (select id from lang where locale = 'ru'));
insert into public.guide_lang values ((select id from guide where code = 39004), 'Менее 20К', (select id from lang where locale = 'ru'));

insert into public.guide_lang values ((select id from guide where code = 39001), 'Comfortably invest from $ 20 thousand, 1-2 times a year', (select id from lang where locale = 'en'));
insert into public.guide_lang values ((select id from guide where code = 39002), 'Ready to allocate $ 50 - $ 250 thousand for venture deals', (select id from lang where locale = 'en'));
insert into public.guide_lang values ((select id from guide where code = 39003), 'Ready to invest over $ 250 thousand per year', (select id from lang where locale = 'en'));
insert into public.guide_lang values ((select id from guide where code = 39004), 'Less than 20 thousand', (select id from lang where locale = 'en'));


