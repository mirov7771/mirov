--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-2941

-- Вставляем новые значения в справочники
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'Classified', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'Classified'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'BI/BPM', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'BI/BPM'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'Creator economy', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'Creator economy'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'Social commerce', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'Social commerce'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'MedTech', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'MedTech'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'Web3', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'Web3'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 3000, 'Digital assets', (select max(code)+1 from guide g where guideid = 3000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'Digital assets'
        );
INSERT INTO public.guide
(guideid, "name", code, isfilter)
select 13000, 'No Code', (select max(code)+1 from guide g where guideid = 13000), true
WHERE
    NOT EXISTS (
            SELECT g.id FROM guide g WHERE g."name" = 'No Code'
        );
-- Делаем rang в сортировке по алфавиту
update guide
set
    rang = (select sort.rang from (select code, (row_number() over(order by name))*-1 as rang from guide g where guideid = 3000 order by name asc) as sort where guide.code = sort.code)
where guide.guideid = 3000;
update guide
set
    rang = (select sort.rang from (select code, (row_number() over(order by name))*-1 as rang from guide g where guideid = 13000 order by name asc) as sort where guide.code = sort.code)
where guide.guideid = 13000;
-- Вставляем новые значения в справочник мультиязычности
insert into guide_lang
(id, value, lang_id)
select id, g2."name", 1 from guide g2 where g2."name" in ('Classified','BI/BPM','Creator economy','Social commerce','MedTech','Web3','Digital assets','No Code') and
    NOT EXISTS (
            SELECT g3.id FROM guide_lang g3 WHERE g3.value = 'Web3' and g3.lang_id = 1
        );
insert into guide_lang
(id, value, lang_id)
select id, g2."name", 2 from guide g2 where g2."name" in ('Classified','BI/BPM','Creator economy','Social commerce','MedTech','Web3','Digital assets','No Code') and
    NOT EXISTS (
            SELECT g3.id FROM guide_lang g3 WHERE g3.value = 'Web3' and g3.lang_id = 2
        );








