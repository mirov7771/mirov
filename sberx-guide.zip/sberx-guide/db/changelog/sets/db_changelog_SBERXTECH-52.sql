--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-52
update guide_object set attributename = 'Модель бизнеса' where objectname = 'InteractionType';
