--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3898

ALTER TABLE guide_lang
    ADD description varchar;