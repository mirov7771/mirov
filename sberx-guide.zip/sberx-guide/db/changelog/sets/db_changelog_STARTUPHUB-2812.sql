--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2812

DELETE
FROM guide_object
WHERE guideid = 14000;

INSERT INTO guide_object
    (guideid, objectname, attributename)
VALUES (14000, 'TransactionType', 'Тип сделки');

DELETE
FROM guide
WHERE code = 14001;

INSERT INTO guide
    (id, guideid, "name", code)
VALUES ((select (max(id) + 1) from guide), 14000, 'Прямая инвестиция', 14001);

DELETE
FROM guide
WHERE code = 14002;

INSERT INTO guide
    (id, guideid, "name", code)
VALUES ((select (max(id) + 1) from guide), 14000, 'Конвертируемый займ', 14002);

DELETE
FROM guide
WHERE code = 14003;

INSERT INTO guide
    (id, guideid, "name", code)
VALUES ((select (max(id) + 1) from guide), 14000, 'SAFE', 14003);

DELETE
FROM guide
WHERE code = 14004;

INSERT INTO guide
    (id, guideid, "name", code)
VALUES ((select (max(id) + 1) from guide), 14000, 'Другое', 14004);

DELETE
FROM guide
WHERE code = 20013;

INSERT INTO guide
    (id, guideid, "name", extra, code)
VALUES ((select (max(id) + 1) from guide), 20000, 'Снято с публикации', 'round', 20013);

