--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2402
UPDATE guide
    SET name='Черновик'
WHERE id=20000 and code=20001;

UPDATE guide
    SET name='На проверку'
WHERE id=20000 and code=20002;

UPDATE guide
    SET name='Опубликована'
WHERE id=20000 and code=20004;

UPDATE guide
    SET name='Архивная'
WHERE id=20000 and code=20005;

UPDATE guide
    SET name='Отклонена'
WHERE id=20000 and code=20009;

DELETE FROM guide
WHERE id=20000 and code=20010;

INSERT INTO guide(entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value)
VALUES ((select max(entityid) + 1 from guide), 20000, 'На проверке', 'verify', 'application', NULL, NULL, 20011, false, NULL);

INSERT INTO guide(entityid, id, "name", sysname, extra, icon, logofile, code, isdisabled, value)
VALUES((select max(entityid) + 1 from guide), 20000, 'В работе', 'to_work', 'application', NULL, NULL, 20012, false, NULL);
