# Сервис справочников
## sberx-guide

##### Confluence

https://sbtatlas.sigma.sbrf.ru/wiki/pages/viewpage.action?pageId=3930229984

##### GIT

https://sbtatlas.sigma.sbrf.ru/stash/projects/SBERX/repos/sberx-guide/browse

### GIT FLOW

1. Отрезаем ветку от develop:
---------------------------------
    Пример:
        + если задача feautre/STARTUPHUB-598
        + если баг fix/STARTUPHUB-567

2. Делаем задачу, проверяем локально, кидаем pull request в ветку develop на ответственного разработчика
3. После принятя PR, разработчик (выполняющий задачу) создает merge request из ветки develop в актуальную релизную ветку
---------------------------------
    Пример:
        + release/D-01.001.00 или
        + release/D-01.001.01 или
        + release/D-01.002.00 и т.д.

4. Прикладываем ссылку на MR под задачу и переводим задачу в тестирование
5. Тестирование проверяет задачу на деве и если все норм, принимает MR
6. После слития всех текущих задач для релиза (хотфикса) , тестирование проверяет задачи на стенде ПСИ
7. После тестирования всех задач, тестированием проводится регресс
8. Сборка ставится в прод

### Database

https://sbtatlas.sigma.sbrf.ru/wiki/display/SBERXMAIN/sberx-guide

### Swagger

{service.name}/docs/swagger-ui.html

