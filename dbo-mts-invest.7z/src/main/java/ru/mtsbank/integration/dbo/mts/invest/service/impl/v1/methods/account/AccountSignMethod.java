package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.account;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.trading.grpc.pub.brokeracccore.SignDocResp;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountSignReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response.AccountSignRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

@Slf4j
@Component
public class AccountSignMethod extends AbstractInvestMethod {

    public AccountSignMethod(AuthorizationService authorizationService, GrpcService grpcService) {
        super(authorizationService, grpcService);
    }

    public BaseResponse call(AccountSignReq req) {
        AccountSignRes res = new AccountSignRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (isAuthorised(req.getSrcPhone())) {
            if (req.getCode() == null) {
                grpcService.startValidation(req.getBatchId());
            } else {
                SignDocResp.Status s = grpcService.signDocs(req.getBatchId(), req.getCode());
                if (!SignDocResp.Status.OK.equals(s)) {
                    if (SignDocResp.Status.EXPIRED.equals(s)) {
                        return res.createError(Errors.EXPIRED_CODE.getCode(), Errors.EXPIRED_CODE.getMessage(), Errors.EXPIRED_CODE.getHttpCode(),
                                null, null, "account/sign", res.getRequestId());
                    } else if (SignDocResp.Status.WRONG_CODE.equals(s)) {
                        return res.createError(Errors.WRONG_CODE.getCode(), Errors.WRONG_CODE.getMessage(), Errors.WRONG_CODE.getHttpCode(),
                                null, null, "account/sign", res.getRequestId());
                    } else if (SignDocResp.Status.NO_MORE_RETRIES.equals(s)) {
                        return res.createError(Errors.LIMIT_EXCEEDED.getCode(), Errors.LIMIT_EXCEEDED.getMessage(), Errors.LIMIT_EXCEEDED.getHttpCode(),
                                null, null, "account/sign", res.getRequestId());
                    } else if (SignDocResp.Status.FAILED.equals(s)) {
                        return res.createError(Errors.FAILED_CONFIRM_CODE.getCode(), Errors.FAILED_CONFIRM_CODE.getMessage(), Errors.FAILED_CONFIRM_CODE.getHttpCode(),
                                null, null, "account/sign", res.getRequestId());
                    } else {
                        return res.createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                                null, "Unknown Status from GRPC SignDocs", "account/sign", res.getRequestId());
                    }
                }
            }
        } else {
            log.error("{} : Authorization failed", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, "account/sign", res.getRequestId());
        }
        return res;
    }
}
