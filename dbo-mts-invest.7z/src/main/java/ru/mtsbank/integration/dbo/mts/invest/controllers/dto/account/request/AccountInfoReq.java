package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseRequest;

@EqualsAndHashCode(callSuper = true)
@Data
public class AccountInfoReq extends BaseRequest {
}
