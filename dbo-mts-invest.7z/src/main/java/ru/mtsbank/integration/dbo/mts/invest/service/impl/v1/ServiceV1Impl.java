package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountCreateReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountSignReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientFileReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response.ClientInfoRes;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCancelReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCheckReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferConfirmReq;
import ru.mtsbank.integration.dbo.mts.invest.service.Service;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.account.AccountCreateMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.account.AccountInfoMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.account.AccountSignMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.client.ClientFileMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.client.ClientInfoMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.transfers.TransferCancelMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.transfers.TransferCheckMethod;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.transfers.TransferConfirmMethod;

@Component("v1")
@RequiredArgsConstructor
@Slf4j
public class ServiceV1Impl implements Service {

    private final ClientInfoMethod clientInfoMethod;
    private final ClientFileMethod clientFileMethod;
    private final AccountCreateMethod accountCreateMethod;
    private final AccountInfoMethod accountInfoMethod;
    private final AccountSignMethod accountSignMethod;
    private final TransferCancelMethod transferCancelMethod;
    private final TransferCheckMethod transferCheckMethod;
    private final TransferConfirmMethod transferConfirmMethod;

    @Override
    public BaseResponse clientInfo(ClientInfoReq r) {
        log.info("{}: ClientInfoMethod started", ThreadContext.get("requestId"));
        log.trace("{} : ClientInfoMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res = new ClientInfoRes();
        try {
            res = clientInfoMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = res.createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "client/info", ThreadContext.get("requestId"));
        }
        log.trace("{} : ClientInfoMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : ClientInfoMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse clientFile(ClientFileReq r) {
        log.info("{}: ClientFileMethod started", ThreadContext.get("requestId"));
        log.trace("{} : ClientFileMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res = new ClientInfoRes();
        try {
            res = clientFileMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = res.createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "client/file", ThreadContext.get("requestId"));
        }
        log.trace("{} : ClientFileMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : ClientFileMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse accountCreate(AccountCreateReq r) {
        log.info("{}: AccountCreateMethod started", ThreadContext.get("requestId"));
        log.trace("{} : AccountCreateMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res;
        try {
            res = accountCreateMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = new BaseResponse().createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "account/create", ThreadContext.get("requestId"));

        }
        log.trace("{} : AccountCreateMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : AccountCreateMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse accountInfo(AccountInfoReq r) {
        log.info("{}: AccountInfoMethod started", ThreadContext.get("requestId"));
        log.trace("{} : AccountInfoMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res;
        try {
            res = accountInfoMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = new BaseResponse().createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "account/info", ThreadContext.get("requestId"));

        }
        log.trace("{} : AccountInfoMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : AccountInfoMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse accountSign(AccountSignReq r) {
        log.info("{}: AccountSignMethod started", ThreadContext.get("requestId"));
        log.trace("{} : AccountSignMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res;
        try {
            res = accountSignMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = new BaseResponse().createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "account/sign", ThreadContext.get("requestId"));

        }
        log.trace("{} : AccountSignMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : AccountSignMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse transferCheck(TransferCheckReq r) {
        log.info("{}: TransferCheckMethod started", ThreadContext.get("requestId"));
        log.trace("{} : TransferCheckMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res;
        try {
            res = transferCheckMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = new BaseResponse().createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "transfer/check", ThreadContext.get("requestId"));

        }
        log.trace("{} : TransferCheckMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : TransferCheckMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse transferCancel(TransferCancelReq r) {
        log.info("{}: TransferCancelMethod started", ThreadContext.get("requestId"));
        log.trace("{} : TransferCancelMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res;
        try {
            res = transferCancelMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = new BaseResponse().createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "transfer/cancel", ThreadContext.get("requestId"));

        }
        log.trace("{} : TransferCancelMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : TransferCancelMethod finished", ThreadContext.get("requestId"));
        return res;
    }

    @Override
    public BaseResponse transferSign(TransferConfirmReq r) {
        log.info("{}: TransferConfirmMethod started", ThreadContext.get("requestId"));
        log.trace("{} : TransferConfirmMethod request: {}", ThreadContext.get("requestId"), r);
        BaseResponse res;
        try {
            res = transferConfirmMethod.call(r);
        } catch (Exception e) {
            log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
            res = new BaseResponse().createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                    null, e.getMessage(), "transfer/cancel", ThreadContext.get("requestId"));

        }
        log.trace("{} : TransferConfirmMethod response: {}", ThreadContext.get("requestId"), res);
        log.info("{} : TransferConfirmMethod finished", ThreadContext.get("requestId"));
        return res;
    }
}
