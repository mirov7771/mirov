package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.transfers;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCheckReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.response.TransferCheckRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

@Slf4j
@Component
public class TransferCheckMethod extends AbstractInvestMethod {

    public TransferCheckMethod(AuthorizationService authorizationService, GrpcService grpcService) {
        super(authorizationService, grpcService);
    }

    public BaseResponse call(TransferCheckReq req) {
        TransferCheckRes res = new TransferCheckRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (isAuthorised(req.getSrcPhone())) {
            if (req.getWithdrawalId() == null) {
                if (grpcService.withdrawalEnabled()) {
                    res.setComission(grpcService.withdrawalPreviewInfo(req.getWithdrawalValue()));
                } else {
                    return res.createError(Errors.WITHDRAW_NOT_ALLOWED.getCode(), Errors.WITHDRAW_NOT_ALLOWED.getMessage(),
                            Errors.WITHDRAW_NOT_ALLOWED.getHttpCode(), null, null, "transfer/check", res.getRequestId());
                }
                String withdrawalId = grpcService.startWithdrawal(req.getWithdrawalValue(), req.getToBic(),
                        req.getToAccountNumber(), req.getCurrency());
                if (withdrawalId == null) {
                    return res.createError(Errors.FAILED_CREATE_DOC.getCode(), Errors.FAILED_CREATE_DOC.getMessage(),
                            Errors.FAILED_CREATE_DOC.getHttpCode(), null, null, "transfer/check", res.getRequestId());
                } else {
                    res.setWithdrawalId(withdrawalId);
                }
            } else {
                res.setWithdrawalId(req.getWithdrawalId());
            }
            boolean resent = grpcService.resendWithdrawalSms(res.getWithdrawalId());
            if (!resent) {
                return res.createError(Errors.FAILED_CREATE_DOC.getCode(), Errors.FAILED_CREATE_DOC.getMessage(),
                        Errors.FAILED_CREATE_DOC.getHttpCode(), null, null, "transfer/check", res.getRequestId());
            }
            return res;
        } else {
            log.error("{} : Authorization failed", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, "transfer/check", res.getRequestId());
        }
    }


}
