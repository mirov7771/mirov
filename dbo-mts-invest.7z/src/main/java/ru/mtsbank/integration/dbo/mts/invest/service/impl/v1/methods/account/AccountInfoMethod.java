package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.account;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.trading.broker.commons.BrokerPortfolioPublicAll;
import ru.mts.trading.grpc.pub.brokeracccore.BrokerAccountCoreUserStatus;
import ru.mts.trading.grpc.pub.brokeracccore.GetUserStatusResp;
import ru.mts.trading.grpc.pub.fundtransfer.ExternalTopupInfoResponse;
import ru.mtsbank.integration.dbo.mts.invest.config.CustomConfig;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response.AccountInfoRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class AccountInfoMethod extends AbstractInvestMethod {

    private final Map<String, CustomConfig.MtsInvest.StatusInfo> statusInfoMap;


    public AccountInfoMethod(GrpcService grpcService, AuthorizationService authorizationService, CustomConfig c) {
        super(authorizationService, grpcService);
        this.statusInfoMap = c.getInvest().getStatusInfoMap();
    }

    public BaseResponse call(AccountInfoReq req) {
        AccountInfoRes res = new AccountInfoRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (isAuthorised(req.getSrcPhone())) {
            AccountInfoRes.BrokerAccountInfo info = new AccountInfoRes.BrokerAccountInfo();
            AccountInfoRes.BrokerAccountInfo.Account account = new AccountInfoRes.BrokerAccountInfo.Account();
            List<AccountInfoRes.BrokerAccountInfo.Payment> paymentList = new ArrayList<>();
            AccountInfoRes.BrokerAccountInfo.Issue issue = new AccountInfoRes.BrokerAccountInfo.Issue();
            GetUserStatusResp userStatus = grpcService.getUserStatus();
            if (BrokerAccountCoreUserStatus.BROKER_USER_CLIENT.equals(userStatus.getStatus())) {
                Iterator<BrokerPortfolioPublicAll.PortfolioResponse> streamV2 = grpcService.getStreamV2();
                while (streamV2.hasNext()) {
                    BrokerPortfolioPublicAll.PortfolioResponse pr = streamV2.next();
                    if (pr.getStatus().equals(BrokerPortfolioPublicAll.PortfolioStatus.EXISTS)) {
                        BrokerPortfolioPublicAll.Portfolio portfolio = pr.getPortfolio();
                        log.debug("{} : set account from portfolio {}", ThreadContext.get("requestId"), portfolio);
                        account.setName(portfolio.getName());
                        if (portfolio.hasAvailableWithdrawAmount()) {
                            account.setRest(BigDecimal.valueOf(Long.parseLong(portfolio.getAvailableWithdrawAmount().getValue())));
                        } else {
                            account.setRest(BigDecimal.valueOf(Long.parseLong(portfolio.getAssetsValue().getValue())));
                        }
                        account.setIncome(BigDecimal.valueOf(Long.parseLong(portfolio.getAssetsValue().getValue())));
                        account.setContractId(portfolio.getContractId());
                        break;
                    }
                }
                ExternalTopupInfoResponse externalTopupInfoResponse = grpcService.externalTopupInfo();
                for (ExternalTopupInfoResponse.ExternalTopupInfo i: externalTopupInfoResponse.getEntryList()) {
                    AccountInfoRes.BrokerAccountInfo.Payment payment = new AccountInfoRes.BrokerAccountInfo.Payment();
                    payment.setBic(i.getBic());
                    payment.setInn(i.getInn());
                    payment.setKpp(i.getKpp());
                    payment.setCorrespondentAccount(i.getCorrespondentAccount());
                    payment.setRecipient(i.getRecipient());
                    payment.setAssignment(i.getAssignment());
                    payment.setBeneficiaryBankName(i.getBeneficiaryBankName());
                    payment.setIntermediaryBankName(i.getIntermediaryBankName());
                    paymentList.add(payment);
                }
            } else {
                if (userStatus.getStatus() != null && statusInfoMap.get(userStatus.getStatus().name()) != null) {
                    CustomConfig.MtsInvest.StatusInfo s = statusInfoMap.get(userStatus.getStatus().name());
                    issue.setStatusSysName(userStatus.getStatus().name());
                    issue.setStatusName(s.getStatusName());
                    issue.setStatusDesc(s.getStatusDesc());
                    issue.setCanCreate(s.getCanCreate());
                } else {
                    return res.createError(Errors.NOT_PERMITTED.getCode(), Errors.NOT_PERMITTED.getMessage(),
                            Errors.NOT_PERMITTED.getHttpCode(), null, null, "account/info", res.getRequestId());
                }
            }
            info.setAccount(account);
            info.setPayment(paymentList);
            info.setIssue(issue);
        } else {
            log.error("{} : Authorization failed", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, "account/info", res.getRequestId());
        }
        return res;
    }
}
