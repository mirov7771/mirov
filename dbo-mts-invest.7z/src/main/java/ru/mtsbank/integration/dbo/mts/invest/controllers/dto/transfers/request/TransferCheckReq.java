package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseRequest;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
public class TransferCheckReq extends BaseRequest {

    private BigDecimal withdrawalValue;
    private String toBic;
    private String toAccountNumber;
    private String currency;
    private String withdrawalId;
}
