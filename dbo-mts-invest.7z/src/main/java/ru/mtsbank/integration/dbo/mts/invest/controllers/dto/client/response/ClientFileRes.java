package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseResponse;

@EqualsAndHashCode(callSuper = true)
@Data
public class ClientFileRes extends BaseResponse {
    private String content;
}
