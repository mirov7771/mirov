package ru.mtsbank.integration.dbo.mts.invest.utils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.utils.MtsException;
import ru.mtsbank.integration.dbo.mts.invest.config.CustomConfig;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
@Slf4j
public class AuthorizationService {

    private final RestTemplate restTemplate;
    private final String host;
    private final String appAuthUrl;
    private final String clientAuthUrl;
    private final String clientStatusUrl;
    private final String clientRegisterUrl;
    private final Map<String, Object> req;
    private static final int LOCK_GAP_SECONDS = 5;
    private final AtomicReference<String> token = new AtomicReference<>("");
    private final AtomicReference<Instant> expirationMoment = new AtomicReference<>(Instant.now());
    private final Lock lock = new ReentrantLock();

    public AuthorizationService(RestTemplate restTemplate, CustomConfig c) {
        this.restTemplate = restTemplate;
        if (c.getInvest().getAuth().endsWith("/")) {
            this.appAuthUrl = c.getInvest().getAuth() + "login";
            this.clientAuthUrl = c.getInvest().getAuth() + "token";
            this.clientStatusUrl = c.getInvest().getAuth() + "status";
            this.clientRegisterUrl = c.getInvest().getAuth() + "register";
        } else {
            this.appAuthUrl = c.getInvest().getAuth() + "/login";
            this.clientAuthUrl = c.getInvest().getAuth() + "/token";
            this.clientStatusUrl = c.getInvest().getAuth() + "/status";
            this.clientRegisterUrl = c.getInvest().getAuth() + "/register";
        }
        this.host = c.getInvest().getHost();
        this.req = new HashMap<>();
        req.put("password", c.getInvest().getPassword());
    }

    private static TokenResponse validateAccessToken(ResponseEntity<TokenResponse> responseEntity) throws MtsException {
        if (responseEntity.getStatusCode() != HttpStatus.OK
                || responseEntity.getBody() == null
                || responseEntity.getBody().getData() == null
                || responseEntity.getBody().getData().getAccess() == null
                || responseEntity.getBody().getData().getExpiresAt() == null
                || Instant.now().compareTo(responseEntity.getBody().getData().getExpiresAt()) > 0
        ) {
            log.error("{} : validate: Invalid token: {}", ThreadContext.get("requestId"), responseEntity.getBody());
            throw new MtsException("Failed to login as \"mts_bank\". Auth server response: " + responseEntity.getBody());
        }
        return responseEntity.getBody();
    }

    public String authorize(String phoneNumber, ClientData... clientData) throws MtsException {
        String appToken = null;
        try {
            appToken = getAppAuthorizationToken();
        } catch (Exception e) {
            log.error("{} : Failed to get app token", ThreadContext.get("requestId"), e);
            throw new MtsException(e);
        }
        String sessionToken;
        try {
            sessionToken = getClientAuthorizationToken(appToken, phoneNumber, clientData);
        } catch (MtsException e) {
            log.error("{} : Failed to get client token", ThreadContext.get("requestId"), e);
            throw new MtsException(e);

        }
        return sessionToken;
    }

    public String getClientAuthorizationToken(String appToken, String phoneNumber, ClientData... clientData) throws MtsException {
        Map<String, Object> reqBody = new HashMap<>();
        reqBody.put("phone", "8" + phoneNumber.substring(1));
        RequestEntity<Map<String, Object>> statusRequest = RequestEntity.post(clientStatusUrl).header("Authorization", "Bearer " + appToken).header("Host", this.host).body(reqBody);
        ResponseEntity<StatusResponse> statusResponseResponseEntity = restTemplate.exchange(statusRequest, StatusResponse.class);
        if (HttpStatus.OK.equals(statusResponseResponseEntity.getStatusCode())
                && statusResponseResponseEntity.getBody() != null
                && statusResponseResponseEntity.getBody().getData() != null) {
            RequestEntity<Map<String, Object>> request;
            if (statusResponseResponseEntity.getBody().getData().equals(StatusResponse.Status.UNKNOWN) && clientData.length == 1) {
                ClientData cd = clientData[0];
                reqBody.put("email", cd.getEmail());
                reqBody.put("name", Map.of("familyName", cd.getLastName(), "firstName", cd.getFirstName(), "patronymic", cd.getMiddleName()));
                request = RequestEntity.post(clientRegisterUrl).header("Authorization", "Bearer " + appToken).header("Host", this.host).body(reqBody);
            } else if (statusResponseResponseEntity.getBody().getData().equals(StatusResponse.Status.CLIENT)) {
                request = RequestEntity.post(clientAuthUrl).header("Authorization", "Bearer " + appToken).header("Host", this.host).body(reqBody);
            } else {
                log.error("Bad status returned: {}", statusResponseResponseEntity.getBody());
                throw new MtsException("Bad status returned");
            }
            ResponseEntity<TokenResponse> responseEntity = restTemplate.exchange(request, TokenResponse.class);
            TokenResponse.Token clientToken = validateAccessToken(responseEntity).getData();
            return clientToken.getAccess();
        } else {
            log.error("Bad status returned: {}", statusResponseResponseEntity);
            throw new MtsException("Bad status returned");
        }
    }

    public String getAppAuthorizationToken() throws MtsException {
        log.trace("{} : auth: Started", ThreadContext.get("requestId"));
        if (expirationMoment.get().compareTo(Instant.now()) > 0) {
            log.trace("{} : auth: getting from cache; expires at {}", ThreadContext.get("requestId"), expirationMoment);
            return token.get();
        }
        try {
            if (lock.tryLock(LOCK_GAP_SECONDS, TimeUnit.SECONDS)) {
                try {
                    log.trace("{} : auth: locked", ThreadContext.get("requestId"));
                    if (expirationMoment.get().compareTo(Instant.now()) <= 0) {
                        RequestEntity<Map<String, Object>> request = RequestEntity.post(appAuthUrl).header("Host", this.host).body(req);
                        ResponseEntity<TokenResponse> responseEntity = restTemplate.exchange(request, TokenResponse.class);
                        TokenResponse.Token appToken = validateAccessToken(responseEntity).getData();
                        token.set(appToken.getAccess());
                        expirationMoment.set(appToken.getExpiresAt());
                    }
                    log.info("{} : auth: Logged in successfully as \"mts_bank\", expires at: {}", ThreadContext.get("requestId"), expirationMoment.get());
                    return token.get();
                } finally {
                    lock.unlock();
                    log.trace("{} : auth: unlocked", ThreadContext.get("requestId"));
                }
            } else {
                log.error("{} : auth: Failed to seize lock.", ThreadContext.get("requestId"));
                throw new IllegalThreadStateException("Failed to seize lock (wait)");
            }
        } catch (InterruptedException e) {
            log.error("{} : auth: Failed to seize lock; was interrupted.", ThreadContext.get("requestId"), e);
            throw new IllegalStateException("Failed to seize lock (interrupted)", e);
        }
    }

    @Data
    static class TokenResponse {
        Token data;

        @Data
        static class Token {
            @JsonProperty("accessToken")
            String access;
            UUID sessionId;
            Instant expiresAt;
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class StatusResponse {
        Status data;

        enum Status {
            @JsonProperty("UNKNOWN")
            UNKNOWN,
            @JsonProperty("DISABLED")
            DISABLED,
            @JsonProperty("CLIENT")
            CLIENT
        }
    }
}
