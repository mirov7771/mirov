package ru.mtsbank.integration.dbo.mts.invest.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountCreateReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountSignReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response.AccountCreateRes;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientFileReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response.ClientFileRes;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response.ClientInfoRes;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCancelReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCheckReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.response.TransferCancelRes;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.response.TransferCheckRes;
import ru.mtsbank.integration.dbo.mts.invest.service.Service;

import javax.validation.Valid;
import java.util.Map;
import java.util.UUID;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Tag(name = "MtsInvest")
@RestController
@RequestMapping("dbo-mts-invest")
@Slf4j
public class Controller {

    private final Map<String, Service> services;

    public Controller(Map<String, Service> services) {
        this.services = services;
    }

    @GetMapping(value = "{version}/client/info", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод, получающий информацию о клиенте", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ClientInfoRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> clientInfo(@PathVariable final String version,
                                                   @RequestHeader(value = "Authorization", required = false) String authorization) {
        ClientInfoReq req = new ClientInfoReq();
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).clientInfo(req));
    }

    @GetMapping(value = "{version}/client/file", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод, документ клиента по идентификатору документа", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ClientFileRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> clientFile(@PathVariable final String version,
                                                   @PathVariable final String fileId,
                                                   @RequestHeader(value = "Authorization", required = false) String authorization) {
        ClientFileReq req = new ClientFileReq();
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).clientFile(req));
    }

    @PostMapping(value = "{version}/account/create", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод для создания заявки на открытие брокерского счета.", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = AccountCreateRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> accountCreate(@PathVariable final String version,
                                                      @RequestHeader(value = "Client-id", required = false) String clientId,
                                                      @RequestHeader(value = "Authorization", required = false) String authorization,
                                                      @Valid @RequestBody AccountCreateReq req) {
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).accountCreate(req));
    }

    @GetMapping(value = "{version}/account/info", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод для создания заявки на открытие брокерского счета.", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ClientData.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> accountInfo(@PathVariable final String version,
                                                    @RequestHeader(value = "Authorization", required = false) String authorization) {
        AccountInfoReq req = new AccountInfoReq();
        req.setRboID(req.getSrcPhone(), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).accountInfo(req));
    }

    @PostMapping(value = "{version}/account/sign", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод для подписания документов на открытие счета.", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = AccountCreateRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> accountSign(@PathVariable final String version,
                                                    @RequestHeader(value = "Client-id", required = false) String clientId,
                                                    @RequestHeader(value = "Authorization", required = false) String authorization,
                                                    @Valid @RequestBody AccountSignReq req) {
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).accountSign(req));
    }

    @PostMapping(value = "{version}/transfer/cancel", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод для отмены списания со счёта", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = TransferCancelRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> transferCancel(@PathVariable final String version,
                                                       @RequestHeader(value = "Client-id", required = false) String clientId,
                                                       @RequestHeader(value = "Authorization", required = false) String authorization,
                                                       @Valid @RequestBody TransferCancelReq req) {
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).transferCancel(req));
    }

    @PostMapping(value = "{version}/transfer/check", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод для проверки списания со счета.", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = TransferCheckRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> transferCheck(@PathVariable final String version,
                                                      @RequestHeader(value = "Client-id", required = false) String clientId,
                                                      @RequestHeader(value = "Authorization", required = false) String authorization,
                                                      @Valid @RequestBody TransferCheckReq req) {
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).transferCheck(req));
    }

    @PostMapping(value = "{version}/transfer/confirm", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Метод для подтверждения списания со счета.", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = AccountCreateRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> transferConfirm(@PathVariable final String version,
                                                        @RequestHeader(value = "Client-id", required = false) String clientId,
                                                        @RequestHeader(value = "Authorization", required = false) String authorization,
                                                        @Valid @RequestBody AccountSignReq req) {
        req.setRboID(String.valueOf(req.getRboID()), authorization);
        req.setSrcPhone(req.getSrcPhone(), authorization);
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        return ResponseBuilder.build(services.get(version).accountSign(req));
    }


}
