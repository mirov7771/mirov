package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.client;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.mts.invest.config.CustomConfig;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientFileReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response.ClientFileRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

import java.util.Base64;

@Component
@Slf4j
public class ClientFileMethod extends AbstractInvestMethod {

    private static final Base64.Encoder encoder = Base64.getEncoder();

    private final RestTemplate restTemplate;
    private final String getFileUrl;

    public ClientFileMethod(RestTemplate restTemplate, CustomConfig c, GrpcService grpcService, AuthorizationService authorizationService) {
        super(authorizationService, grpcService);
        this.restTemplate = restTemplate;
        this.getFileUrl = c.getInvest().getFile();
    }

    public BaseResponse call(ClientFileReq req) {
        ClientFileRes res = new ClientFileRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (isAuthorised(req.getSrcPhone())) {
            res.setContent(downloadFile(req.getFileId()));
        }
        return res;
    }

    private String downloadFile(String fileId) {
        String uriTemplate = getFileUrl + fileId;
        RequestEntity<Void> req = RequestEntity.get(uriTemplate)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_PDF.toString())
                .header(HttpHeaders.AUTHORIZATION, "Bearer: " + ThreadContext.get("token"))
                .build();
        log.debug("{} : Sending request to {} : {}", ThreadContext.get("requestId"), uriTemplate, req);
        ResponseEntity<byte[]> res = restTemplate.exchange(req, new ParameterizedTypeReference<>() {
        });
        if (res.getStatusCode().is2xxSuccessful() && res.getBody() != null) {
            byte[] file = res.getBody();
            return encoder.encodeToString(file);
        } else {
            log.warn("{} : Bad answer from {}: {}", ThreadContext.get("requestId"), uriTemplate, res);
        }
        return null;
    }

}
