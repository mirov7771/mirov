package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseRequest;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;

@EqualsAndHashCode(callSuper = true)
@Data
public class AccountCreateReq extends BaseRequest {
    private ClientData clientData;
}
