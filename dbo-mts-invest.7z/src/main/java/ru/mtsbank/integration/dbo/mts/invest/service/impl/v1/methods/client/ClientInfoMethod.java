package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.client;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response.ClientInfoRes;
import ru.mtsbank.integration.mts.xsd.custsearchinqrq.BankSvcRq;
import ru.mtsbank.integration.mts.xsd.custsearchinqrq.CustInfo;
import ru.mtsbank.integration.mts.xsd.custsearchinqrq.CustSearchInqRq;
import ru.mtsbank.integration.mts.xsd.custsearchinqrq.ServerInfoType;
import ru.mtsbank.integration.mts.xsd.custsearchinqrs.*;

import java.util.Date;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.getDate;
import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@Component
@Slf4j
public class ClientInfoMethod {

    private final EsbGate esbGate;
    private final XmlUnmarshaler xmlUnmarshaler;

    public ClientInfoMethod(EsbGate esbGate, XmlUnmarshaler xmlUnmarshaler) {
        this.esbGate = esbGate;
        this.xmlUnmarshaler = xmlUnmarshaler;
    }

    public BaseResponse call(ClientInfoReq req) {
        String requestId = ThreadContext.get("requestId");
        ClientInfoRes res = new ClientInfoRes();
        res.setRequestId(requestId);
        if (req.getRboID() == null && req.getSrcPhone() == null) {
            log.error("{} : There is not rboId in request", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, null, requestId);
        } else if (req.getRboID() == null && req.getSrcPhone() != null) {
            ClientData clientData = new ClientData();
            clientData.setPhoneNumber(req.getSrcPhone());
            res.setClientData(clientData);
        } else {
            try {
                CustSearchInqRq rq = createCustSearchInqRq(req.getRboID().toString(), requestId);
                String reqEsb = xmlUnmarshaler.createXml(rq);
                log.debug("{} : Sending request to ESB: {}", ThreadContext.get("requestId"), reqEsb);
                String resEsb = esbGate.sendInfoMessageWithAnswer(reqEsb);
                log.debug("{} : Received response from ESB: {}", ThreadContext.get("requestId"), resEsb);
                CustSearchInqRs rs = xmlUnmarshaler.parse(CustSearchInqRs.class, resEsb);
                if (rs == null
                        || rs.getBankSvcRs() == null
                        || rs.getBankSvcRs().getCustInfo() == null
                        || rs.getBankSvcRs().getCustInfo().getPersonInfo() == null
                        || !"0".equals(rs.getBankSvcRs().getStatus().getStatusCode())) {
                    res.createError(Errors.NO_CLIENT_DATA.getCode(), Errors.NO_CLIENT_DATA.getMessage(),
                            Errors.NO_CLIENT_DATA.getHttpCode(), null, null, "client/info", requestId);
                } else {
                    CustInfoType custInfo = rs.getBankSvcRs().getCustInfo();
                    ClientData clientData = new ClientData();
                    PersonInfoTypeCustSearchInqRs personInfo = custInfo.getPersonInfo();
                    clientData.setLastName(personInfo.getPersonName().getLastName());
                    clientData.setFirstName(personInfo.getPersonName().getFirstName());
                    clientData.setMiddleName(personInfo.getPersonName().getMiddleName());
                    clientData.setGender(personInfo.getGender());
                    clientData.setBirthPlace(personInfo.getBirthPlace());
                    clientData.setCitizenship(personInfo.getCitizenship().getCountryName());
                    int i = 0;
                    for (IdentityCardType card : personInfo.getIdentityCard()) {
                        if ("21".equals(card.getIdType())) {
                            clientData.setDocSeries(card.getIdSeries());
                            clientData.setDocNumber(card.getIdNum());
                            clientData.setIssuedBy(card.getIssuedBy());
                            clientData.setIssuedByCode(card.getIssuedByCode());
                            clientData.setIssueDate(getDate(card.getIssueDt().getYear(), card.getIssueDt().getMonth(), card.getIssueDt().getDay()));
                            i++;
                        }
                        if ("INSURANCE".equals(card.getIdType())) {
                            clientData.setInsuranceAccountId(card.getIdNum());
                            i++;
                        }
                        if (i == 2) {
                            break;
                        }
                    }
                    clientData.setBirthDay(getDate(personInfo.getBirthday().getYear(), personInfo.getBirthday().getMonth(), personInfo.getBirthday().getDay()));
                    if (personInfo.getContactInfo() != null) {
                        ContactInfoType contactInfoType = personInfo.getContactInfo();
                        clientData.setEmail(contactInfoType.getEmailAddr());
                        i = 0;
                        for (FDXPhoneNum fdxPhoneNum: contactInfoType.getPhoneNum()) {
                            if ("Mobile".equals(fdxPhoneNum.getPhoneType()) && fdxPhoneNum.isPrimary()) {
                                clientData.setPhoneNumber(fdxPhoneNum.getPhone());
                                break;
                            }
                        }
                        for (AddrType addr : contactInfoType.getPostAddr()) {
                            switch (addr.getAddrType()) {
                                case "REGISTRATION":
                                    clientData.setRegistrationAddress(convertAddress(addr));
                                    i++;
                                    break;
                                case "REAL_LIVE":
                                    clientData.setRealLifeAddress(convertAddress(addr));
                                    i++;
                                    break;
                                case "POST":
                                    clientData.setPostAddress(convertAddress(addr));
                                    i++;
                            }
                            if (i == 3) {
                                break;
                            }
                        }
                    }
                }
            } catch (Exception e) {
                log.error("{} : Unexpected error", ThreadContext.get("requestId"), e);
                return res.createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                        null, e.getMessage(), "client/info", requestId);
            }

        }
        return res;
    }

    private CustSearchInqRq createCustSearchInqRq(String custId, String uid) {
        CustSearchInqRq custSearchInqRq = new CustSearchInqRq();
        BankSvcRq bankSvcRq = new BankSvcRq();
        custSearchInqRq.setBankSvcRq(bankSvcRq);

        CustInfo custInfo = new CustInfo();
        custInfo.setCustId(custId);
        bankSvcRq.setCustInfo(custInfo);

        ServerInfoType serverInfoType = new ServerInfoType();
        serverInfoType.setBpId(UUID.randomUUID().toString());
        serverInfoType.setRqUID(uid);
        serverInfoType.setMsgUID(UUID.randomUUID().toString());
        serverInfoType.setMsgType("CustSearchInqRq");
        serverInfoType.setSPName("MTS_EIP_UMP");
        serverInfoType.setMsgReceiver("SIEBEL");
        serverInfoType.setServerDt(getXmlGregorianCalendar(new Date()));
        custSearchInqRq.setServerInfo(serverInfoType);
        return custSearchInqRq;
    }

    private ClientData.Address convertAddress(AddrType addr) {
        ClientData.Address address = new ClientData.Address();
        address.setCountry(addr.getCountry());
        address.setPostalCode(addr.getPostalCode());
        address.setRegion(addr.getRegion());
        address.setDistrict(addr.getDistrict());
        address.setCity(addr.getCity());
        address.setStreet(addr.getStreet());
        address.setHouseNum(String.valueOf(addr.getHouseNum()));
        address.setBlock(addr.getHouseBlock());
        address.setUnit(addr.getUnit());
        address.setSettlement(String.valueOf(addr.getUnitNum()));
        return address;
    }
}
