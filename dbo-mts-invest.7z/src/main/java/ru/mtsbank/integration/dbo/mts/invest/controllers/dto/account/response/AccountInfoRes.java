package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseResponse;

import java.math.BigDecimal;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class AccountInfoRes extends BaseResponse {

    private BrokerAccountInfo brokerAccountInfo;

    @Data
    public static class BrokerAccountInfo {
        private Account account;
        private List<Payment> payment;
        private Issue issue;

        @Data
        public static class Account {
            private String name;
            private BigDecimal rest;
            private BigDecimal income;
            private String contractId;
        }

        @Data
        public static class Payment {
            private String bic;
            private String inn;
            private String kpp;
            private String correspondentAccount;
            private String recipient;
            private String assignment;
            private String beneficiaryBankName;
            private String intermediaryBankName;
        }

        @Data
        public static class Issue {
            private String statusSysName;
            private String statusName;
            private String statusDesc;
            private Boolean canCreate;
        }

    }
}
