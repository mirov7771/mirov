package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseResponse;

@EqualsAndHashCode(callSuper = true)
@Data
public class AccountSignRes extends BaseResponse {
}
