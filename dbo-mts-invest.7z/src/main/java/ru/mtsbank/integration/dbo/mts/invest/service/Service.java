package ru.mtsbank.integration.dbo.mts.invest.service;

import org.springframework.http.HttpStatus;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountCreateReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountSignReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientFileReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request.ClientInfoReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCancelReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCheckReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferConfirmReq;

public interface Service {

    default BaseResponse clientInfo(ClientInfoReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "client/info", null);
    }

    default BaseResponse clientFile(ClientFileReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "client/file", null);
    }

    default BaseResponse accountCreate(AccountCreateReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "account/create", null);
    }


    default BaseResponse accountInfo(AccountInfoReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "account/info", null);
    }

    default BaseResponse accountSign(AccountSignReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "account/sign", null);
    }

    default BaseResponse transferCheck(TransferCheckReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "transfer/check", null);
    }

    default BaseResponse transferCancel(TransferCancelReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "transfer/cancel", null);
    }

    default BaseResponse transferSign(TransferConfirmReq r) {
        return new BaseResponse().createError(null, "This method is not implemented in current version",
                HttpStatus.NOT_ACCEPTABLE.value(), null, null, "transfer/sign", null);
    }
}
