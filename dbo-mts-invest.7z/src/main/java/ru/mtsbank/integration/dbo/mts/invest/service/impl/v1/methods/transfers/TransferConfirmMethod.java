package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.transfers;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.trading.grpc.pub.fundtransfer.SignWithdrawalResponse;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferConfirmReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.response.TransferConfirmRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

@Slf4j
@Component
public class TransferConfirmMethod extends AbstractInvestMethod {


    public TransferConfirmMethod(AuthorizationService authorizationService, GrpcService grpcService) {
        super(authorizationService, grpcService);
    }

    public BaseResponse call(TransferConfirmReq req) {
        TransferConfirmRes res = new TransferConfirmRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (isAuthorised(req.getSrcPhone())) {
            SignWithdrawalResponse.SignWithdrawalStatus status = grpcService.signWithdrawal(req.getWithdrawalId(), req.getCode());
            if (SignWithdrawalResponse.SignWithdrawalStatus.WITHDRAWAL_SIGN_EXPIRED.equals(status)) {
                return res.createError(Errors.EXPIRED_SMS.getCode(), Errors.EXPIRED_SMS.getMessage(), Errors.EXPIRED_SMS.getHttpCode(),
                        null, null, "transfer/cancel", res.getRequestId());
            } else if (SignWithdrawalResponse.SignWithdrawalStatus.WITHDRAWAL_SIGN_WRONG_CODE.equals(status)) {
                return res.createError(Errors.WRONG_SMS_CODE.getCode(), Errors.WRONG_SMS_CODE.getMessage(), Errors.WRONG_SMS_CODE.getHttpCode(),
                        null, null, "transfer/cancel", res.getRequestId());
            } else if (SignWithdrawalResponse.SignWithdrawalStatus.WITHDRAWAL_SIGN_NO_MORE_RETRIES.equals(status)) {
                return res.createError(Errors.SMS_LIMIT_EXCEEDED.getCode(), Errors.SMS_LIMIT_EXCEEDED.getMessage(), Errors.SMS_LIMIT_EXCEEDED.getHttpCode(),
                        null, null, "transfer/cancel", res.getRequestId());
            } else if (SignWithdrawalResponse.SignWithdrawalStatus.WITHDRAWAL_SIGN_OK.equals(status)) {
                return res;
            } else {
                return res.createError(Errors.UNEXPECTED_ERROR.getCode(), Errors.UNEXPECTED_ERROR.getMessage(), Errors.UNEXPECTED_ERROR.getHttpCode(),
                        null, "Unknown Status from GRPC SignWithdrawal", "transfer/cancel", res.getRequestId());
            }
        } else {
            log.error("{} : Authorization failed", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, "transfer/cancel", res.getRequestId());
        }
    }
}
