package ru.mtsbank.integration.dbo.mts.invest.controllers.dto;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public enum Errors {

    NOT_AUTHORISED(1074, "Авторизация не выполнена", HttpStatus.FORBIDDEN),
    NO_CLIENT_DATA(1075, "Не получены клиентские данные", HttpStatus.EXPECTATION_FAILED),
    FAILED_CREATE_ACC(1077, "Ошибка создания заявки на открытие счета", HttpStatus.EXPECTATION_FAILED),
    NOT_PERMITTED(1075, "Клиенту не доступно открытие счета", HttpStatus.FORBIDDEN),
    EXPIRED_CODE(1079, "Истек срок действия кода", HttpStatus.EXPECTATION_FAILED),
    WRONG_CODE(1080, "Неверный код", HttpStatus.NOT_FOUND),
    LIMIT_EXCEEDED(1081, "Превышено количество попыток ввода", HttpStatus.EXPECTATION_FAILED),
    FAILED_CONFIRM_CODE(1082, "Ошибка подтверждения кода", HttpStatus.NOT_FOUND),
    WITHDRAW_NOT_ALLOWED(1085, "Списание со счета недоступно", HttpStatus.NOT_FOUND),
    FAILED_CREATE_DOC(1086, "Ошибка при создании документа", HttpStatus.NOT_FOUND),
    FAILED_SEND_SMS(1087, "Ошибка отправки СМС клиенту", HttpStatus.NOT_FOUND),
    EXPIRED_SMS(1088, "Истёк срок действия СМС", HttpStatus.NOT_FOUND),
    WRONG_SMS_CODE(1089, "Неверный код СМС", HttpStatus.NOT_FOUND),
    SMS_LIMIT_EXCEEDED(1090, "Превышено количество попыток ввода СМС", HttpStatus.NOT_FOUND),
    UNEXPECTED_ERROR(500, "Непредвиденная ошибка", HttpStatus.INTERNAL_SERVER_ERROR),
    ;

    private final int code;
    private final String message;
    private final int httpCode;

    Errors(int code, String message, HttpStatus httpStatus) {
        this.code = code;
        this.message = message;
        this.httpCode = httpStatus.value();
    }
}
/*
HTTP/1.1 404 Not Found
{
    "error": {
        "code": 1085,
        "message": "Списание со счета недоступно",
        "uuid" : "3842-0e29-38eeh-3i2df"
    }
}
 */