package ru.mtsbank.integration.dbo.mts.invest.config;

import lombok.Data;

import java.util.Map;

@Data
public class CustomConfig {

    private MtsInvest invest;

    @Data
    public static class MtsInvest {
        private String host;
        private String auth;
        private String file;
        private String acc;
        private String password;
        private Map<String, StatusInfo> statusInfoMap;

        @Data
        public static class StatusInfo {
            private String statusName;
            private String statusDesc;
            private Boolean canCreate;
        }
    }

}
