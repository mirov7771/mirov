package ru.mtsbank.integration.dbo.mts.invest.controllers.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;

@Data
public class ClientData {
    private String birthPlace;
    @JsonProperty(required = true)
    private String citizenship;
    private String taxId;
    private String insuranceAccountId;
    @JsonProperty(required = true)
    private Date birthDay;
    @JsonProperty(required = true)
    private String gender;
    @JsonProperty(required = true)
    private String firstName;
    private String middleName;
    @JsonProperty(required = true)
    private String lastName;
    @JsonProperty(required = true)
    private String docSeries;
    @JsonProperty(required = true)
    private String docNumber;
    @JsonProperty(required = true)
    private String issuedBy;
    @JsonProperty(required = true)
    private String issuedByCode;

    public void setGender(String gender) {
        if ("male".equalsIgnoreCase(gender)) {
            this.gender = "М";
        } else if ("female".equalsIgnoreCase(gender)) {
            this.gender = "Ж";
        } else {
            this.gender = gender;
        }
    }

    public void setIssuedByCode(String issuedByCode) {
        this.issuedByCode = issuedByCode.replaceAll("-", "");
    }

    @JsonProperty(required = true)
    private Date issueDate;
    @JsonProperty(required = true)
    private Address registrationAddress;
    @JsonProperty(required = true)
    private Address realLifeAddress;
    @JsonProperty(required = true)
    private Address postAddress;
    private String email;
    private String phoneNumber;

    @Data
    public static class Address {
        @JsonProperty(required = true)
        private String country;
        @JsonProperty(required = true)
        private String postalCode;
        private String region;
        private String district;
        private String city;
        private String street;
        private String houseNum;
        private String block;
        private String unit;
        private String settlement;
    }
}
