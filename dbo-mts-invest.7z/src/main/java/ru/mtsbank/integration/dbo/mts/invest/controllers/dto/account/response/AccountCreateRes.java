package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseResponse;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class AccountCreateRes extends BaseResponse {
    private String batchId;
    private List<FileInfo> fileInformation;

    @Data
    public static class FileInfo {
        private String name;
        private String contentType;
        private Integer size;
        private String fileId;
        private String userId;
    }

}
