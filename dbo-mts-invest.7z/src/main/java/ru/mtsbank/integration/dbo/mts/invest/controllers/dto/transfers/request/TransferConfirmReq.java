package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseRequest;

@EqualsAndHashCode(callSuper = true)
@Data
public class TransferConfirmReq extends BaseRequest {
    private String withdrawalId;
    private String code;
}
