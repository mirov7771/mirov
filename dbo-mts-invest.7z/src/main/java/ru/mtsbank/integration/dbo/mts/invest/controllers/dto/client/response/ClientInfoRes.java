package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;

@EqualsAndHashCode(callSuper = true)
@Data
public class ClientInfoRes extends BaseResponse {
    private ClientData clientData;
}
