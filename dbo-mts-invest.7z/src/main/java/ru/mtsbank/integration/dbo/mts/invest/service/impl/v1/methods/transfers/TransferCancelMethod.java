package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.transfers;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.request.TransferCancelReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.response.TransferCancelRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

@Slf4j
@Component
public class TransferCancelMethod extends AbstractInvestMethod {

    public TransferCancelMethod(AuthorizationService authorizationService, GrpcService grpcService) {
        super(authorizationService, grpcService);
    }

    public BaseResponse call(TransferCancelReq req) {
        TransferCancelRes res = new TransferCancelRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (isAuthorised(req.getSrcPhone())) {
            grpcService.cancelWithdrawal(req.getWithdrawalId());
        } else {
            log.error("{} : Authorization failed", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, "transfer/cancel", res.getRequestId());
        }
        return res;
    }
}
