package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.transfers.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseResponse;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
public class TransferCheckRes extends BaseResponse {
    private BigDecimal comission;
    private String withdrawalId;
}
