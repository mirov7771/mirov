package ru.mtsbank.integration.dbo.mts.invest.controllers.dto.client.request;

import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mts.dbo.dto.BaseRequest;

@EqualsAndHashCode(callSuper = true)
@Data
public class ClientFileReq extends BaseRequest {
    private String fileId;
}
