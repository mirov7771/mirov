package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

@Slf4j
public abstract class AbstractInvestMethod {

    private final AuthorizationService authorizationService;
    protected final GrpcService grpcService;

    public AbstractInvestMethod(AuthorizationService authorizationService, GrpcService grpcService) {
        this.authorizationService = authorizationService;
        this.grpcService = grpcService;
    }

    protected Boolean isAuthorised(String phoneNumber, ClientData... clientData) {
        try {
            String sessionToken = authorizationService.authorize(phoneNumber, clientData);
            log.debug("{} : Session token: {}", ThreadContext.get("requestId"), sessionToken);
            ThreadContext.put("token", sessionToken);
            return true;
        } catch (Exception e) {
            log.error("{} : Failed to authorize", ThreadContext.get("requestId"), e);
            return false;
        }
    }
}
