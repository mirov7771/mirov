package ru.mtsbank.integration.dbo.mts.invest.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.mts.dbo.config.CustomConsulService;

@Slf4j
@Configuration
public class ConfigInitializer {
    @Value("${consul_host}")
    private String consulHost;
    @Value("${consul_config_path}")
    private String consulPrefix;
    @Value("${consul_config_acl_token}")
    private String consulToken;
    @Value("${app.name}")
    private String appName;
    @Value("${app.key}")
    private String appKey;

    @Bean
    public CustomConfig getCustomConfig() {
        CustomConfig config = new CustomConsulService()
                .init(CustomConfig.class,
                        consulHost,
                        consulPrefix,
                        consulToken,
                        appName,
                        appKey);
        if (config.getInvest() == null
                || config.getInvest().getAcc() == null
                || config.getInvest().getAuth() == null
                || config.getInvest().getFile() == null
                || config.getInvest().getPassword() == null
                || config.getInvest().getStatusInfoMap() == null) {
            log.error("Config has not fully initialized");
            throw new IllegalArgumentException("Config has not fully initialized");
        }
        return config;
    }
}

