package ru.mtsbank.integration.dbo.mts.invest.utils;

import com.google.protobuf.Empty;
import io.grpc.ClientInterceptor;
import io.grpc.ManagedChannel;
import io.grpc.Metadata;
import io.grpc.netty.shaded.io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.shaded.io.grpc.netty.NettyChannelBuilder;
import io.grpc.netty.shaded.io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.grpc.stub.MetadataUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Service;
import ru.mts.trading.broker.commons.BrokerPortfolioPublicAll;
import ru.mts.trading.broker.commons.BrokerPortfolioServiceGrpc;
import ru.mts.trading.grpc.common.Currency;
import ru.mts.trading.grpc.common.Date;
import ru.mts.trading.grpc.common.StringDecimal;
import ru.mts.trading.grpc.pub.brokeracccore.*;
import ru.mts.trading.grpc.pub.fundtransfer.*;
import ru.mts.trading.grpc.pub.validation.logger.DocValidationLoggerGrpc;
import ru.mts.trading.grpc.pub.validation.logger.StartValidationRequest;
import ru.mtsbank.integration.dbo.mts.invest.config.CustomConfig;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.ClientData;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Iterator;

import static ru.mts.dbo.utils.Utils.nvl;

@Service
@Slf4j
public class GrpcService {

    private final BrokerAccountCoreServiceGrpc.BrokerAccountCoreServiceBlockingStub accountCoreServiceBlockingStub;
    private final BrokerPortfolioServiceGrpc.BrokerPortfolioServiceBlockingStub portfolioServiceBlockingStub;
    private final FundTransferServiceGrpc.FundTransferServiceBlockingStub fundTransferServiceBlockingStub;
    private final DocValidationLoggerGrpc.DocValidationLoggerBlockingStub docValidationLoggerBlockingStub;

    @SneakyThrows
    public GrpcService(CustomConfig customConfig) {
        ManagedChannel channel = NettyChannelBuilder.forAddress("vm-gw-egress-ump.common.svc.cluster.local", 9000)
                .sslContext(GrpcSslContexts.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE).build())
                .build();
        this.accountCoreServiceBlockingStub = BrokerAccountCoreServiceGrpc.newBlockingStub(channel);
        this.portfolioServiceBlockingStub = BrokerPortfolioServiceGrpc.newBlockingStub(channel);
        this.fundTransferServiceBlockingStub = FundTransferServiceGrpc.newBlockingStub(channel);
        this.docValidationLoggerBlockingStub = DocValidationLoggerGrpc.newBlockingStub(channel);
    }

    public GetUserStatusResp getUserStatus() {
        GetUserStatusReq r = GetUserStatusReq.newBuilder().build();
        log.debug("{}: Sending request to GetUserStatus: {}", ThreadContext.get("requestId"), r);
        GetUserStatusResp userStatus = accountCoreServiceBlockingStub.withInterceptors(setMetadataInterceptor()).getUserStatus(r);
        log.debug("{}: Received response: {}", ThreadContext.get("requestId"), userStatus);
        return userStatus;

    }

    public BatchAndFiles createBrokerAcc(ClientData c) {
        PersonName pn = PersonName.newBuilder()
                .setFirstName(c.getFirstName())
                .setLastName(c.getLastName())
                .setPatronymic(c.getMiddleName()).build();
        Passport passport = Passport.newBuilder()
                .setIdNum(c.getDocNumber())
                .setIdSeries(c.getDocSeries())
                .setIssueDate(dateConverter(c.getIssueDate()))
                .setIssuedBy(c.getIssuedBy())
                .setIssuedByCode(c.getIssuedByCode())
                .build();
        Citizenship citizenship = Citizenship.newBuilder()
                .setCountryName(c.getCitizenship())
                .build();

        Address realLifeAddressC = getAddress(c.getRealLifeAddress());
        Address postAddressC = getAddress(c.getPostAddress());
        Address registrationAddressC = getAddress(c.getRegistrationAddress());

        ContactInfo contactInfo = ContactInfo.newBuilder()
                .setRegistrationAddress(registrationAddressC)
                .setRealLifeAddress(realLifeAddressC)
                .setPostAddress(postAddressC)
                .build();
        PersonInfo pi = PersonInfo.newBuilder()
                .setName(pn)
                .setPassport(passport)
                .setBirthPlace(c.getBirthPlace())
                .setCitizenship(citizenship)
                .setContactInfo(contactInfo)
                .setTaxId(c.getTaxId())
                .setInsuranceAccountId(c.getInsuranceAccountId() == null ? "" : c.getInsuranceAccountId())
                .setBirthDay(dateConverter(c.getBirthDay()))
                .setGender(c.getGender())
                .setTaxResident(!"".equals(c.getTaxId()))
                .setNotOfficial(true)
                .build();
        ClientProfile cp = ClientProfile.newBuilder()
                .setPersonInfo(pi)
                .build();
        CustomerInfo i = CustomerInfo.newBuilder().setProfile(cp).build();
        StartBrokerAccCreatingReq r = StartBrokerAccCreatingReq.newBuilder().setCustomerInfo(i).build();
        log.debug("{}: Sending request to StartBrokerAccCreating: {}", ThreadContext.get("requestId"), r);
        BatchAndFiles batchAndFiles = accountCoreServiceBlockingStub.withInterceptors(setMetadataInterceptor()).startBrokerAccCreating(r);
        log.debug("{}: Received response from StartBrokerAccCreating: {}", ThreadContext.get("requestId"), batchAndFiles);
        return batchAndFiles;
    }

    public Iterator<BrokerPortfolioPublicAll.PortfolioResponse> getStreamV2() {
        BrokerPortfolioPublicAll.PortfolioRequest req = BrokerPortfolioPublicAll.PortfolioRequest.newBuilder()
                .setPeriod(BrokerPortfolioPublicAll.Period.ALL_TIME)
                .build();
        log.debug("{}: Sending request to GetStreamV2: {}", ThreadContext.get("requestId"), req);
        Iterator<BrokerPortfolioPublicAll.PortfolioResponse> streamV2 = portfolioServiceBlockingStub.withInterceptors(setMetadataInterceptor()).getStreamV2(req);
        log.debug("{}: Received response from GetStreamV2: {}", ThreadContext.get("requestId"), streamV2);
        return streamV2;
    }

    public ExternalTopupInfoResponse externalTopupInfo() {
        log.debug("{}: Sending request to ExternalTopupInfo", ThreadContext.get("requestId"));
        ExternalTopupInfoResponse externalTopupInfoResponse = fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).externalTopupInfo(Empty.newBuilder().build());
        log.debug("{}: Received response from ExternalTopupInfo: {}", ThreadContext.get("requestId"), externalTopupInfoResponse);
        return externalTopupInfoResponse;
    }

    public void startValidation(String batchId) {
        StartValidationRequest req = StartValidationRequest.newBuilder().setBatchId(batchId).build();
        log.debug("{}: Sending request to StartValidation: {}", ThreadContext.get("requestId"), req);
        docValidationLoggerBlockingStub.withInterceptors(setMetadataInterceptor()).startValidation(req);
    }

    public SignDocResp.Status signDocs(String batchId, String code) {
        SigDocsReq req = SigDocsReq.newBuilder()
                .setBatchId(batchId)
                .setCode(code)
                .build();
        log.debug("{}: Sending request to SignDocs: {}", ThreadContext.get("requestId"), req);
        SignDocResp signDocResp = accountCoreServiceBlockingStub.withInterceptors(setMetadataInterceptor()).signDocs(req);
        log.debug("{}: Received response from SignDocs: {}", ThreadContext.get("requestId"), signDocResp);
        return signDocResp.getStatus();
    }

    public boolean withdrawalEnabled() {
        log.debug("{}: Sending request to WithdrawalEnabled", ThreadContext.get("requestId"));
        WithdrawalEnabledResponse withdrawalEnabledResponse = fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).withdrawalEnabled(Empty.newBuilder().build());
        log.debug("{}: Received response from WithdrawalEnabled: {}", ThreadContext.get("requestId"), withdrawalEnabledResponse);
        return withdrawalEnabledResponse.getEnabled();
    }

    public BigDecimal withdrawalPreviewInfo(BigDecimal withdrawalValue) {
        StringDecimal withdrawalValueString = StringDecimal.newBuilder().setValue(withdrawalValue.toString()).build();
        WithdrawalPreviewInfoRequest req = WithdrawalPreviewInfoRequest.newBuilder()
                .setWithdrawalValue(withdrawalValueString)
                .build();
        log.debug("{}: Sending request to withdrawalPreviewInfo: {}", ThreadContext.get("requestId"), req);
        WithdrawalPreviewInfoResponse withdrawalPreviewInfoResponse = fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).withdrawalPreviewInfo(req);
        log.debug("{}: Received response from withdrawalPreviewInfo: {}", ThreadContext.get("requestId"), withdrawalPreviewInfoResponse);
        if (withdrawalPreviewInfoResponse.hasTax()) {
            StringDecimal resString = withdrawalPreviewInfoResponse.getTax();
            return BigDecimal.valueOf(Long.parseLong(resString.getValue()));
        }
        return null;
    }

    public String startWithdrawal(BigDecimal withdrawalValue, String toBic, String toAccountNumber, String cur) {
        StringDecimal withdrawalValueString = StringDecimal.newBuilder().setValue(withdrawalValue.toString()).build();
        Currency currency = Currency.newBuilder()
                .setValue(cur)
                .build();
        StartWithdrawalRequest req = StartWithdrawalRequest.newBuilder()
                .setWithdrawalValue(withdrawalValueString)
                .setCurrency(currency)
                .setToAccountNumber(toAccountNumber)
                .setToBic(toBic)
                .build();
        log.debug("{}: Sending request to StartWithdrawal: {}", ThreadContext.get("requestId"), req);
        StartWithdrawalResponse startWithdrawalResponse = fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).startWithdrawal(req);
        log.debug("{}: Received response from StartWithdrawal: {}", ThreadContext.get("requestId"), startWithdrawalResponse);

        if (startWithdrawalResponse.hasWithdrawal()) {
            StartWithdrawalResponse.StartWithdrawalInfo withdrawal = startWithdrawalResponse.getWithdrawal();
            if (withdrawal.hasId()) {
                return withdrawal.getId().getValue();
            }
        }
        return null;
    }

    public boolean resendWithdrawalSms(String withdrawId) {
        WithdrawalId withdrawalId = WithdrawalId.newBuilder()
                .setValue(withdrawId)
                .build();
        log.debug("{}: Sending request to ResendWithdrawalSms: {}", ThreadContext.get("requestId"), withdrawalId);
        ResendWithdrawalSmsResponse resendWithdrawalSmsResponse = fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).resendWithdrawalSms(withdrawalId);
        log.debug("{}: Received response from ResendWithdrawalSms: {}", ThreadContext.get("requestId"), resendWithdrawalSmsResponse);
        return ResendWithdrawalSmsResponse.ResendWithdrawalSmsResponseStatus.OK.equals(resendWithdrawalSmsResponse.getResendStatus());
    }

    public void cancelWithdrawal(String withdrawId) {
        WithdrawalId withdrawalId = WithdrawalId.newBuilder()
                .setValue(withdrawId)
                .build();
        log.debug("{}: Sending request to CancelWithdrawal: {}", ThreadContext.get("requestId"), withdrawalId);
        fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).cancelWithdrawal(withdrawalId);
    }

    public SignWithdrawalResponse.SignWithdrawalStatus signWithdrawal(String withdrawId, String code) {
        WithdrawalId withdrawalId = WithdrawalId.newBuilder()
                .setValue(withdrawId)
                .build();
        SignWithdrawalRequest req = SignWithdrawalRequest.newBuilder()
                .setId(withdrawalId)
                .setCode(code)
                .build();
        SignWithdrawalResponse signWithdrawalResponse = fundTransferServiceBlockingStub.withInterceptors(setMetadataInterceptor()).signWithdrawal(req);
        return signWithdrawalResponse.getStatus();
    }


    private ClientInterceptor setMetadataInterceptor() {
        Metadata m = new Metadata();
        Metadata.Key<String> key = Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);
        m.put(key, ThreadContext.get("token"));
        return MetadataUtils.newAttachHeadersInterceptor(m);
    }

    private Date dateConverter(java.util.Date d) {
        LocalDate localDate = LocalDate.ofInstant(d.toInstant(), ZoneId.systemDefault());
        return Date.newBuilder()
                .setDay(localDate.getDayOfMonth())
                .setMonth(localDate.getMonthValue())
                .setYear(localDate.getYear())
                .build();
    }

    private Address getAddress(ClientData.Address address){
        return Address.newBuilder()
                .setCountry(nvl(address.getCountry(),""))
                .setPostalCode(nvl(address.getPostalCode(),""))
                .setRegion(nvl(address.getRegion(),""))
                .setDistrict(nvl(address.getDistrict(),""))
                .setCity(nvl(address.getCity(),""))
                .setStreet(nvl(address.getStreet(),""))
                .setHouseNum(nvl(address.getHouseNum(),""))
                .setBlock(nvl(address.getBlock(),""))
                .setUnit(nvl(address.getUnit(),""))
                .setSettlement(nvl(address.getSettlement(),""))
                .build();
    }

}
