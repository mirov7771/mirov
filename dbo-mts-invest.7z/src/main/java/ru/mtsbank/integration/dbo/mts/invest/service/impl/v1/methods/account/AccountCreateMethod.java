package ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.account;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.utils.Utils;
import ru.mts.trading.grpc.common.FileInformation;
import ru.mts.trading.grpc.pub.brokeracccore.BatchAndFiles;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.Errors;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.request.AccountCreateReq;
import ru.mtsbank.integration.dbo.mts.invest.controllers.dto.account.response.AccountCreateRes;
import ru.mtsbank.integration.dbo.mts.invest.service.impl.v1.methods.AbstractInvestMethod;
import ru.mtsbank.integration.dbo.mts.invest.utils.AuthorizationService;
import ru.mtsbank.integration.dbo.mts.invest.utils.GrpcService;

import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class AccountCreateMethod extends AbstractInvestMethod {

    public AccountCreateMethod(GrpcService grpcService, AuthorizationService authorizationService) {
        super(authorizationService, grpcService);
    }

    public BaseResponse call(AccountCreateReq req) {
        AccountCreateRes res = new AccountCreateRes();
        res.setRequestId(ThreadContext.get("requestId"));
        if (req.getClientData() != null && isAuthorised(req.getSrcPhone(), req.getClientData())) {
            BatchAndFiles batchAndFiles = grpcService.createBrokerAcc(req.getClientData());
            if (batchAndFiles.getBatchId() != null && !Utils.isEmpty(batchAndFiles.getFileDescList())) {
                res.setBatchId(batchAndFiles.getBatchId());
                List<AccountCreateRes.FileInfo> fileInfos = new ArrayList<>();
                for (FileInformation f : batchAndFiles.getFileDescList()) {
                    AccountCreateRes.FileInfo fileInfo = new AccountCreateRes.FileInfo();
                    if (f.hasId()) {
                        fileInfo.setFileId(f.getId().getValue());
                    }
                    fileInfo.setName(f.getName());
                    fileInfo.setContentType(f.getContentType());
                    fileInfo.setSize(f.getSize());
                    if (f.hasUserId()) {
                        fileInfo.setUserId(f.getUserId().getValue());
                    }
                    fileInfos.add(fileInfo);
                }
                res.setFileInformation(fileInfos);
            } else {
                log.error("{} : Failed to create account. Bad response from GRPC: {}", ThreadContext.get("requestId"), batchAndFiles);
                return res.createError(Errors.FAILED_CREATE_ACC.getCode(), Errors.FAILED_CREATE_ACC.getMessage(), Errors.FAILED_CREATE_ACC.getHttpCode(),
                        null, null, "account/create", res.getRequestId());
            }
        } else {
            log.error("{} : Authorization failed", ThreadContext.get("requestId"));
            return res.createError(Errors.NOT_AUTHORISED.getCode(), Errors.NOT_AUTHORISED.getMessage(), Errors.NOT_AUTHORISED.getHttpCode(),
                    null, null, "account/create", res.getRequestId());
        }
        return res;
    }
}
