package ru.mts.dbo.gates;

public interface NotifGate {

    String execute(String messageXml) ;

}
