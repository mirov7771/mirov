package ru.mts.dbo.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ApplicationConfig {

    @JsonProperty("esb")
    private Esb esb;
    @JsonProperty("hf")
    private Hf hf;
    @JsonProperty("sms")
    private Sms sms;
    @JsonProperty("mts")
    private Mts mts;
    @JsonProperty("communication")
    private Communication communication;
    @JsonProperty("spring")
    private Spring spring;
    @JsonProperty("kafka")
    private Kafka kafka;
    @JsonProperty("redis")
    private Redis redis;

    @Data
    public static class Spring {
        @JsonProperty("datasource")
        private Datasource datasource;
        @Data
        public static class Datasource {
            @JsonProperty("driver-class-name")
            private String driverclassname;
            @JsonProperty("password")
            private String password;
            @JsonProperty("url")
            private String url;
            @JsonProperty("username")
            private String username;
        }
    }

    @Data
    public static class Esb {
        @JsonProperty("info")
        private Info info;
        @JsonProperty("pay")
        private Pay pay;
        @JsonProperty("sales")
        private Sales sales;
        @JsonProperty("password")
        private String password;
        @JsonProperty("token")
        private String token;
        @Data
        public static class Info {
            @JsonProperty("in")
            private String in;
            @JsonProperty("out")
            private String out;
        }

        @Data
        public static class Pay {
            @JsonProperty("in")
            private String in;
            @JsonProperty("out")
            private String out;
        }

        @Data
        public static class Sales {
            @JsonProperty("in")
            private String in;
            @JsonProperty("out")
            private String out;
        }
    }

    @Data
    public static class Hf{
        @JsonProperty("address")
        private String address;
    }

    @Data
    public static class Sms {
        @JsonProperty("url")
        private String url;
    }

    @Data
    public static class Mts {
        @JsonProperty("money")
        private Money money;
        @Data
        public static class Money {
            @JsonProperty("gate")
            private String gate;
            @JsonProperty("otherbank")
            private String otherbank;
            @JsonProperty("currency")
            private String currency;
        }
    }

    @Data
    public static class Communication {
        @JsonProperty("url")
        private String url;
    }

    @Data
    public static class Kafka {
        @JsonProperty("server")
        private String server;
        @JsonProperty("group")
        private Group group;
        @JsonProperty("security")
        private Security security;
        @JsonProperty("sasl")
        private Sasl sasl;
        @Data
        public static class Group{
            @JsonProperty("id")
            private String id;
        }
        @Data
        public static class Security{
            @JsonProperty("protocol")
            private String protocol;
        }
        @Data
        public static class Sasl{
            @JsonProperty("mechanism")
            private String mechanism;
            @JsonProperty("jaas")
            private Jaas jaas;
            @Data
            public static class Jaas{
                @JsonProperty("config")
                private String config;
            }
        }
    }

    @Data
    public static class Redis{
        @JsonProperty("host")
        private String host;
        @JsonProperty("port")
        private Integer port;
        @JsonProperty("password")
        private String password;
        @JsonProperty("timeout")
        private Integer timeout;
        @JsonProperty("max_pool_size")
        private Integer maxPoolSize;
        @JsonProperty("db_index")
        private Integer dbIndex;
        @JsonProperty("use_ssl")
        private Boolean useSsl;
    }

}
