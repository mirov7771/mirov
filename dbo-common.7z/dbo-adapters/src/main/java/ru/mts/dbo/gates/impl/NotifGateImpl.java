package ru.mts.dbo.gates.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.gates.NotifGate;

@Service
@Slf4j
public class NotifGateImpl implements NotifGate {

    private final RestTemplate restTemplate;
    private static String url;
    public NotifGateImpl(RestTemplate restTemplate, ApplicationConfig applicationConfig){
        this.restTemplate = restTemplate;
        if (applicationConfig != null
                && applicationConfig.getCommunication() != null)
            url = applicationConfig.getCommunication().getUrl();
    }

    @Override
    public String execute(String messageJson) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
        headers.set("Client-name", "UMP");
        HttpEntity<String> rq = new HttpEntity<>(messageJson, headers);
        return restTemplate.postForObject(url, rq, String.class);
    }

}
