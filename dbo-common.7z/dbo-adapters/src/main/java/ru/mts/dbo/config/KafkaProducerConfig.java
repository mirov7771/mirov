package ru.mts.dbo.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.converter.StringJsonMessageConverter;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

@ConditionalOnExpression("${app.kafka.producer:false}")
@Configuration
@Slf4j
public class KafkaProducerConfig {

    private static ApplicationConfig.Kafka kafka;

    public KafkaProducerConfig(ApplicationConfig applicationConfig) {
        log.info("START INITIALIZE KAFKA PRODUCER");
        kafka = applicationConfig.getKafka();
    }

    @Bean
    public Map<String, Object> producerConfigs() {
        ApplicationConfig.Kafka.Sasl sasl = kafka.getSasl();
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.getServer());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        String jaasCfg = sasl.getJaas().getConfig();
        if (!jaasCfg.equals("none")) {
            props.put("sasl.jaas.config", jaasCfg);
            props.put("sasl.mechanism", sasl.getMechanism());
            props.put("security.protocol", kafka.getSecurity().getProtocol());
            log.info("sasl.jaas.config is " + props.get("sasl.jaas.config"));
        }
        return props;
    }

    @Bean
    public ProducerFactory<String, String> producerFactory() {
        return new DefaultKafkaProducerFactory<>(producerConfigs());
    }

    @Bean
    public KafkaTemplate<String, String> kafkaTemplate() {
        KafkaTemplate<String, String> template = new KafkaTemplate<>(producerFactory());
        template.setMessageConverter(new StringJsonMessageConverter());
        return template;
    }

}
