package ru.mts.dbo.gates;

import java.io.IOException;

public interface EsbGate {

    String sendInfoMessageWithAnswer(String messageXml) throws IOException;
    String sendSalesMessageWithAnswer(String messageXml) throws IOException;
    String sendPayMessageWithAnswer(String messageXml) throws IOException;
    void sendInfoMessage(String messageXml) throws IOException;
    void sendSalesMessage(String messageXml) throws IOException;

}
