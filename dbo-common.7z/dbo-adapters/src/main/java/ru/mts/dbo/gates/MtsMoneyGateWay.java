package ru.mts.dbo.gates;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public interface MtsMoneyGateWay {

    String execute(String method, List<String> rboId);

}
