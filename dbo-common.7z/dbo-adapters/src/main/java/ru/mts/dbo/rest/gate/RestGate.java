package ru.mts.dbo.rest.gate;

public interface RestGate {

    <T> T call(Class<T> answerClass, String url, String method, String json, String action);

}
