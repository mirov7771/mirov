package ru.mts.dbo.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@ConditionalOnExpression("${app.jdbc:false}")
@Configuration
@Slf4j
public class JpaConfig {

    @Bean
    public DataSource dataSource(ApplicationConfig applicationConfig) {
        ApplicationConfig.Spring spring = applicationConfig.getSpring();
        if (spring != null) {
            ApplicationConfig.Spring.Datasource datasource = spring.getDatasource();
            log.info("START INITIALIZE DATASOURCE {}", datasource.getUrl());
            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(datasource.getDriverclassname());
            dataSource.setUrl(datasource.getUrl());
            dataSource.setUsername(datasource.getUsername());
            dataSource.setPassword(datasource.getPassword());
            log.info("END INITIALIZE DATASOURCE");
            return dataSource;
        }
        log.info("NO DATASOURCE NEEDED");
        return null;
    }

}
