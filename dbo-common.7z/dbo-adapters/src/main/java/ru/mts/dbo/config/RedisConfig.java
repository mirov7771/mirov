package ru.mts.dbo.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@ConditionalOnExpression("${app.redis:false}")
@Configuration
@Slf4j
public class RedisConfig {

    @Bean
    public JedisPool getJedisPool(ApplicationConfig applicationConfig)
    {
        ApplicationConfig.Redis redis = applicationConfig.getRedis();
        if (redis != null) {
            log.info("START INITIALIZE REDIS {}", redis.getHost());
            JedisPoolConfig config = new JedisPoolConfig();
            config.setMaxTotal(redis.getMaxPoolSize());
            config.setMaxIdle(redis.getMaxPoolSize());
            JedisPool client = new JedisPool(config, redis.getHost(), redis.getPort(), redis.getTimeout(), redis.getPassword(), redis.getUseSsl());
            log.debug("Connection to redis established");
            return client;
        }
        return null;
    }

}
