package ru.mts.dbo.rest.gate.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.rest.gate.RestGate;

@Service
@RequiredArgsConstructor
public class RestGateImpl implements RestGate {

    private final RestTemplate restTemplate;

    @Override
    public <T> T call(Class<T> answerClass, String url, String method, String json, String action) {
        String callUrl = url+method;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("X-Source", "mtsb");
        HttpEntity<String> rq = new HttpEntity<>(json, headers);
        ResponseEntity<T> exchange = restTemplate.exchange(callUrl, HttpMethod.resolve(action), rq, answerClass);
        return exchange.getBody();
    }
}
