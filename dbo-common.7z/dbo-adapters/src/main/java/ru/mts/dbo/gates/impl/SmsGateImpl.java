package ru.mts.dbo.gates.impl;

import com.google.gson.JsonObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.gates.SmsGate;

@Service
public class SmsGateImpl implements SmsGate {

    private final RestTemplate restTemplate;
    private static String url;

    public SmsGateImpl(RestTemplate restTemplate, ApplicationConfig applicationConfig)
    {
        this.restTemplate = restTemplate;
        if (applicationConfig != null
                && applicationConfig.getSms() != null)
            url = applicationConfig.getSms().getUrl();
    }

    @Override
    public String execute(String token, String type, Long rboId){
        JsonObject param = new JsonObject();
        param.addProperty("otpToken",token);
        param.addProperty("type", type);
        param.addProperty("rboId",rboId);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> rq = new HttpEntity<>(param.toString(), headers);
        String answer = restTemplate.postForObject(url, rq, String.class);
        String ret = "BAD_ANSWER";
        if (answer != null){
            if (answer.contains("true"))
                ret = "GOOD_ANSWER";
        }
        return ret;
    }
}
