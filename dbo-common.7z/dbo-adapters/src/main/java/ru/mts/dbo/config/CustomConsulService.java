package ru.mts.dbo.config;

import com.ecwid.consul.v1.ConsulClient;
import com.ecwid.consul.v1.Response;
import com.ecwid.consul.v1.kv.model.GetValue;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import javax.sql.DataSource;
import java.io.IOException;

@Slf4j
public class CustomConsulService {

    public <T> T init(Class<T> cls
                      ,String consulHost
                      ,String consulPrefix
                      ,String consulToken
                      ,String appName
                      ,String appKey)
    {
        String[] consulHostAndPort = consulHost.split(":");
        String consulHostName = consulHostAndPort[0];
        int consulPort = Integer.parseInt(consulHostAndPort[1]);
        ConsulClient client = new ConsulClient(consulHostName, consulPort);
        String consulPath =  consulPrefix + "/" + appKey+"/"+appName+"/application";
        log.info("*** custom consul env "+consulPath+" / "+consulToken);
        try{
            Response<GetValue> kvValue = client.getKVValue(consulPath, consulToken);
            String consulValue = kvValue.getValue().getDecodedValue();
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            return objectMapper.readValue(consulValue, cls);
        } catch (NullPointerException | IOException e) {
            log.error("Unable to load custom consul data for: {}", consulPath);
            e.printStackTrace();
        }
        return null;
    }

}
