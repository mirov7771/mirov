package ru.mts.dbo.gates.impl;

import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.gates.HumanFactorGate;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class HumanFactorGateImpl implements HumanFactorGate {

    private static String url;
    private final RestTemplate restTemplate;

    public HumanFactorGateImpl(RestTemplate restTemplate, ApplicationConfig applicationConfig) {
        this.restTemplate = restTemplate;
        if (applicationConfig != null
                && applicationConfig.getHf() != null)
            url = applicationConfig.getHf().getAddress();
    }

    @Override
    public Map<String, Object> execute(String address) {
        Map<String, Object> outputParams = new HashMap<>();
        if (!url.equals("none")) {
            JsonObject param = new JsonObject();
            param.addProperty("query", address);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> rq = new HttpEntity<>(param.toString(), headers);
            outputParams = restTemplate.postForObject(url, rq, HashMap.class);
        }
        return outputParams;
    }

    @Override
    public <T> T call(Class<T> cls, String address) {
        if (!url.equals("none")) {
            JsonObject param = new JsonObject();
            param.addProperty("query", address);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> rq = new HttpEntity<>(param.toString(), headers);
            return restTemplate.postForObject(url, rq, cls);
        }
        return null;
    }
}
