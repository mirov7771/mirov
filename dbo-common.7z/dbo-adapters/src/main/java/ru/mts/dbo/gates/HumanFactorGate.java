package ru.mts.dbo.gates;

import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public interface HumanFactorGate {

    Map<String, Object> execute(String address);
    <T> T call(Class<T> cls, String address);

}