package ru.mts.dbo.gates.impl;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.gates.EsbGate;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class EsbGateImpl implements EsbGate {

    private static String infoIn;
    private static String infoOut;
    private static String salesIn;
    private static String salesOut;
    private static String payIn;
    private static String payOut;
    private static String token;
    private static String password;

    public EsbGateImpl(ApplicationConfig applicationConfig)
    {
        if (applicationConfig != null && applicationConfig.getEsb() != null){
            token = applicationConfig.getEsb().getToken();
            password = applicationConfig.getEsb().getPassword();
            if (applicationConfig.getEsb().getInfo() != null){
                infoIn = applicationConfig.getEsb().getInfo().getIn();
                infoOut = applicationConfig.getEsb().getInfo().getOut();
            }
            if (applicationConfig.getEsb().getSales() != null){
                salesIn = applicationConfig.getEsb().getSales().getIn();
                salesOut = applicationConfig.getEsb().getSales().getOut();
            }
            if (applicationConfig.getEsb().getPay() != null){
                payIn = applicationConfig.getEsb().getPay().getIn();
                payOut = applicationConfig.getEsb().getPay().getOut();
            }
        }
    }

    @Override
    public String sendInfoMessageWithAnswer(String messageXml) throws IOException {
        return requestDelete(requestPost(messageXml, infoIn), infoOut);
    }

    @Override
    public String sendSalesMessageWithAnswer(String messageXml) throws IOException {
        return requestDelete(requestPost(messageXml, salesIn), salesOut);
    }

    @Override
    public String sendPayMessageWithAnswer(String messageXml) throws IOException {
        return requestDelete(requestPost(messageXml, payIn), payOut);
    }

    @Override
    public void sendInfoMessage(String messageXml) throws IOException {
        requestPost(messageXml, infoIn);
    }

    @Override
    public void sendSalesMessage(String messageXml) throws IOException {
        requestPost(messageXml, salesIn);
    }

    public String requestDelete(String correlationId, String esbOutUrl) throws IOException {
        log.info("ESB GATE: call delete url {}",esbOutUrl);
        log.info("start searching response for correlationid "+correlationId);
        String url = esbOutUrl + "?correlationId=" + correlationId + "&wait=160000";
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .readTimeout(160000, TimeUnit.MILLISECONDS)
                .connectTimeout(160000, TimeUnit.MILLISECONDS)
                .build();
        Request request = new Request.Builder()
                .url(url)
                .addHeader("ibm-mq-rest-csrf-token", token)
                .addHeader("Content-Type", "text/plain;charset=utf-8")
                .addHeader("Authorization", password)
                .delete()
                .build();
        log.info("end searching response in "+url);
        Response response = httpClient.newCall(request).execute();
        String answer = response.body().string();
        log.info("end searching response for correlationid "+correlationId+" get answer "+answer);
        response.close();
        return answer;
    }

    private String requestPost(String messageXml, String esbInUrl) throws IOException {
        log.info("ESB GATE: call post url {}",esbInUrl);
        OkHttpClient httpClient = new OkHttpClient();
        log.info("start sending request "+messageXml);
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/xml; charset=utf-8"), messageXml);
        Request request = new Request.Builder()
                .url(esbInUrl)
                .addHeader("ibm-mq-rest-csrf-token", token)
                .addHeader("Content-Type", "application/xml")
                .addHeader("Authorization", password)
                .post(requestBody)
                .build();
        log.info("end sending request");
        Response response = httpClient.newCall(request).execute();
        String header = response.header("ibm-mq-md-messageid");
        response.close();
        return header;
    }
}
