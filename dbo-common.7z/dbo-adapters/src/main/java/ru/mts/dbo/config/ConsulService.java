package ru.mts.dbo.config;

import com.ecwid.consul.v1.ConsulClient;
import com.ecwid.consul.v1.Response;
import com.ecwid.consul.v1.kv.model.GetValue;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;

@Service
@Slf4j
public class ConsulService {

    @Value("${consul_host}")
    private String consulHost;
    @Value("${consul_config_path}")
    private String consulPrefix;
    @Value("${consul_config_acl_token}")
    private String consulToken;
    @Value("${app.name}")
    private String appName;
    @Value("${app.key}")
    private String appKey;

    private ConsulClient client;

    @PostConstruct
    private void init() {
        String[] consulHostAndPort = consulHost.split(":");
        String consulHostName = consulHostAndPort[0];
        int consulPort = Integer.parseInt(consulHostAndPort[1]);
        client = new ConsulClient(consulHostName, consulPort);
    }

    @Bean
    public ApplicationConfig getApplicationConfig(){
        return loadApplicationConfigByKey();
    }

    private ApplicationConfig loadApplicationConfigByKey() {
        String consulPath =  consulPrefix + "/" + appKey+"/"+appName+"/application";
        log.info("*** consul env "+consulPath+" / "+consulToken);
        ApplicationConfig config = null;
        try{
            Response<GetValue> kvValue = client.getKVValue(consulPath, consulToken);
            String consulValue = kvValue.getValue().getDecodedValue();
            if (consulValue != null) {
                config = buildConfig(consulValue);
            }
        } catch (NullPointerException | IOException e) {
            log.error("Unable to load consul data for: {}", consulPath);
            e.printStackTrace();
        }
        return config;
    }

    public ApplicationConfig buildConfig(String json) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(json, new TypeReference<ApplicationConfig>() {});
    }

}
