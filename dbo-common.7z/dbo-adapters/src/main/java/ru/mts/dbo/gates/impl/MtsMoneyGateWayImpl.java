package ru.mts.dbo.gates.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.gates.MtsMoneyGateWay;

import java.util.List;

@Service
@Slf4j
public class MtsMoneyGateWayImpl implements MtsMoneyGateWay {

    private final RestTemplate restTemplate;
    private static String mtsUrl;

    public MtsMoneyGateWayImpl(RestTemplate restTemplate, ApplicationConfig applicationConfig){
        this.restTemplate = restTemplate;
        if (applicationConfig != null
                && applicationConfig.getMts() != null
                && applicationConfig.getMts().getMoney() != null)
            mtsUrl = applicationConfig.getMts().getMoney().getGate();
    }

    @Override
    public String execute(String method, List<String> rboId) {
        StringBuilder url = new StringBuilder(mtsUrl + method);
        int sz = rboId.size();
        for(int i=0;i<sz;i++){
            if (i == 0)
                url.append("?");
            if (i < sz-1)
                url.append("bankClientId").append("=").append(rboId.get(i)).append("&");
            else
                url.append("bankClientId").append("=").append(rboId.get(i));
        }
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/x-www-form-urlencoded");
        headers.set("Accept-Encoding", "identity");
        headers.set("Connection", "keep-alive");
        HttpEntity<String> rq = new HttpEntity<>(null, headers);
        ResponseEntity<String> response = restTemplate.getForEntity(url.toString(), String.class);
        if (response.getStatusCodeValue() == 200)
            return response.getBody();
        return null;
    }

}
