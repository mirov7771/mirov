package ru.mts.dbo.gates;

public interface SmsGate {

    String execute(String token, String type, Long rboId);

}
