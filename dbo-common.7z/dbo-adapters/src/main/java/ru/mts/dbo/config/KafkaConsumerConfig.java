package ru.mts.dbo.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

@ConditionalOnExpression("${app.kafka.consumer:false}")
@Configuration
@Slf4j
public class KafkaConsumerConfig {

    private static ApplicationConfig.Kafka kafka;

    public KafkaConsumerConfig(ApplicationConfig applicationConfig) {
        log.info("START INITIALIZE KAFKA CONSUMER");
        kafka = applicationConfig.getKafka();
    }

    @Bean
    public KafkaListenerContainerFactory<?> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        factory.setBatchListener(false);
        ContainerProperties cp = factory.getContainerProperties();
        cp.setMissingTopicsFatal(false);
        return factory;
    }

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerConfigs(kafka));
    }

    @Bean
    public Map<String, Object> consumerConfigs(ApplicationConfig.Kafka kafka) {
        ApplicationConfig.Kafka.Sasl sasl = kafka.getSasl();
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafka.getServer());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, kafka.getGroup().getId());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
        String jaasCfg = sasl.getJaas().getConfig();
        if (!StringUtils.isEmpty(jaasCfg)) {
            props.put("sasl.jaas.config", jaasCfg);
            props.put("sasl.mechanism", sasl.getMechanism());
            props.put("security.protocol", kafka.getSecurity().getProtocol());
        }
        return props;
    }

}
