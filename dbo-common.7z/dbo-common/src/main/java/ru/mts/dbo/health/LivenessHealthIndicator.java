package ru.mts.dbo.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class LivenessHealthIndicator implements HealthIndicator {

    private boolean isHealthy = false;

    public LivenessHealthIndicator() {
    }

    @Override
    public Health health() {
        isHealthy = true;
        return isHealthy ? Health.up().build() : Health.down().build();
    }
}
