package ru.mts.dbo.enums;

public enum LoanStates {

    DRAFT("DRAFT", "Черновик"),
    WAITING_CLIENT_InDO("WAITING_CLIENT.InDO", "Ждем вас в офисе"),
    WAITING_CLIENT_InDBO("WAITING_CLIENT.InDBO", "Ожидание клиента"),
    NEW("NEW", "Предварительно одобрено"),
    PREAPPROVED("PREAPPROVED", "Предварительно одобрено"),
    SCORING("SCORING", "На рассмотрении"),
    APPROVED("APPROVED", "На рассмотрении"),
    DONE("DONE", "Одобрено"),
    CLIENT_REFUSE("CLIENT_REFUSE", "Отказано клиентом"),
    SIGNING("SIGNING", "Подписание документов"),
    SELECTION("SELECTION", "Согласование условий"),
    BANK_REFUSE("BANK_REFUSE", "Отказано банком"),
    PRE_INPUT("PRE_INPUT", "Начало ввода заявки клиентом"),
    INPUT("INPUT","Заявка создана");

    private final String statusSysName;
    private final String status;

    LoanStates(String statusSysName, String status){
        this.statusSysName = statusSysName;
        this.status = status;
    }

    public String getStatusSysName() {
        return statusSysName;
    }

    public String getStatus() {
        return status;
    }

    public static LoanStates getStatusBySysName(String sysName){
        for(LoanStates loanState : LoanStates.values()){
            if (loanState.getStatusSysName().equalsIgnoreCase(sysName))
                return loanState;
        }
        return DRAFT;
    }
}
