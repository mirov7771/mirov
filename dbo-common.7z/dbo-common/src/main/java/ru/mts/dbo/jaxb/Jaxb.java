package ru.mts.dbo.jaxb;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.util.HashMap;
import java.util.Map;

public class Jaxb
{
    private static Map<Class,Jaxb> singletonMap = new HashMap<>();
    private Class clazz;

    private ThreadLocal<Marshaller> marshallerThreadLocal = new ThreadLocal<>();
    private ThreadLocal<Unmarshaller> unmarshallerThreadLocal = new ThreadLocal<>();

    public static synchronized Jaxb get(Class clazz)
    {
        Jaxb jaxb =  singletonMap.get(clazz);
        if (jaxb == null)
        {
            jaxb = new Jaxb(clazz);
            singletonMap.put(clazz, jaxb);
        }
        return jaxb;
    }

    private Jaxb(Class clazz)
    {
        this.clazz = clazz;
    }

    public Marshaller getMarshaller() throws JAXBException
    {
        Marshaller m = marshallerThreadLocal.get();
        if (m == null)
        {
            JAXBContext jc = JAXBContext.newInstance(clazz);
            m = jc.createMarshaller();
            marshallerThreadLocal.set(m);
        }
        return m;
    }

    public Unmarshaller getUnmarshaller() throws JAXBException
    {
        Unmarshaller um = unmarshallerThreadLocal.get();
        if (um == null)
        {
            JAXBContext jc = JAXBContext.newInstance(clazz);
            um = jc.createUnmarshaller();
            unmarshallerThreadLocal.set(um);
        }
        return um;
    }
}
