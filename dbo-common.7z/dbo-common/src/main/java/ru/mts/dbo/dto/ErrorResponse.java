package ru.mts.dbo.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ErrorResponse extends BaseResponse {

    @JsonProperty("error")
    public Error error;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    public static class Error{
        @JsonProperty("code")
        private final Integer code;
        @JsonProperty("message")
        private final String message;
        @JsonProperty("uuid")
        private final String uuid;
        @JsonProperty("externalCode")
        private final String externalCode;
        @JsonProperty("details")
        private final String details;
        @JsonIgnore
        private final int httpCode;
    }

}

