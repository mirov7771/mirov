package ru.mts.dbo.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import ru.mts.dbo.utils.Utils;

import static ru.mts.dbo.utils.Utils.getRboIdFromToken;
import static ru.mts.dbo.utils.Utils.getSrcPhoneFromToken;

@Slf4j
@Getter @Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BaseRequest {

    @JsonProperty("rboId")
    private Long rboID;
    private String srcPhone;

    public void setRboID(String rboID, String token){
        Long rboIdToSet = 0L;
        if (!Utils.isEmpty(token)){
            rboIdToSet = getRboIdFromToken(token);
        }
        if (!rboIdToSet.equals(0L)){
            log.info("set rbo_id from token "+rboIdToSet);
            this.rboID = rboIdToSet;
        } else if (!Utils.isEmpty(rboID)){
            log.info("set rbo_id from header "+rboID);
            this.rboID = Long.valueOf(rboID);
        }
    }


    public void setSrcPhone(String phone, String token){
        String srcPhoneToSet = "";
        if (!Utils.isEmpty(token)){
            log.info("set phone from token {}",srcPhoneToSet);
            srcPhoneToSet = getSrcPhoneFromToken(token);
        }
        if (!Utils.isEmpty(srcPhoneToSet)){
            log.info("set phone from token {}",srcPhoneToSet);
            this.srcPhone = srcPhoneToSet;
        } else if (!Utils.isEmpty(phone)) {
            log.info("set phone from header "+phone);
            this.srcPhone = phone;
        }
    }

}
