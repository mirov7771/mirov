package ru.mts.dbo.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.*;


@Getter
@AllArgsConstructor
public enum FailureType {

    /**
     * Не передан телефон и рбоид
     */
    BAD_TOKEN(1083, FORBIDDEN, "Не получен номер телефона/идентификатор клиента"),
    /**
     * Нештатная, не предусмотренная реализацией ошибка.
     */
    UNEXPECTED_ERROR(100, INTERNAL_SERVER_ERROR),

    /**
     * Ошибка генерации pdf файла
     */
    GENERATE_FILE_ERROR(1040, NOT_FOUND, "Не удалось сформировать документ"),

    /**
     * Некорректный запрос
     */
    INVALID_REQUEST(101, BAD_REQUEST),

    /**
     *Одна из backend систем не отвечает
     */
    BACKEND_TIMEOUT(106, GATEWAY_TIMEOUT, "BackEnd Timeout"),

    /**
     *Одна из backend систем не отвечает
     */
    BACKEND_ERROR_ANSWER(108, UNPROCESSABLE_ENTITY),

    /**
     *Ошибка сервиса
     */
    BACKEND_TECH_ERROR(500, INTERNAL_SERVER_ERROR),

    /**
     *Ошибка сервиса (NullPointerException)
     */
    CUSTOM_NULL_POINTER_ERROR(500, INTERNAL_SERVER_ERROR, "NullPointerException"),

    /**
     *Ошибка сервиса (IOException)
     */
    CUSTOM_IOEXCEPTION_ERROR(500, INTERNAL_SERVER_ERROR, "IOException");

    private int code;

    private HttpStatus httpStatus;

    private String message;


    FailureType(int code, HttpStatus status) {
        this(code, status, status.getReasonPhrase());
    }

}
