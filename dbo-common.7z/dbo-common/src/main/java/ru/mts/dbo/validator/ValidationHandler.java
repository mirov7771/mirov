package ru.mts.dbo.validator;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.RestClientException;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mts.dbo.utils.DboException;
import ru.mts.dbo.utils.Utils;

@ControllerAdvice
@Slf4j
public class ValidationHandler {

    @ExceptionHandler({DboException.class,IllegalArgumentException.class,MethodArgumentNotValidException.class, RestClientException.class, HttpMessageNotReadableException.class})
    protected ResponseEntity<BaseResponse> handleDboException (Exception ex) {
        BaseResponse baseResponse = new BaseResponse();
        if (ex instanceof DboException) {
            log.error("***DboException: " + Utils.getStackError(ex));
            DboException newEx = (DboException) ex;
            baseResponse.createError(newEx.getType().getCode(), newEx.getPassedMessage(), newEx.getType().getHttpStatus().value(), null, null, newEx.getSystem(), newEx.getUuid());
        } else if (ex instanceof IllegalArgumentException){
            log.error("***IllegalArgumentException: " + Utils.getStackError(ex));
            baseResponse.createError(1040, "Не удалось сформировать документ", 404, null, null, null, ex.getMessage());
        } else if (ex instanceof MethodArgumentNotValidException){
            StringBuilder details = new StringBuilder("Required params: ");
            MethodArgumentNotValidException e = (MethodArgumentNotValidException) ex;
            for(FieldError item : e.getBindingResult().getFieldErrors()){
                details.append(item.getField()).append("; ");
            }
            baseResponse.createError(100, "Incorrect request", 400, null, details.toString(), "validation", null);
        } else if (ex instanceof RestClientException || ex instanceof HttpMessageNotReadableException){
            log.error("***RestClientException: " + Utils.getStackError(ex));
            baseResponse.createError(500, "Сервис временно недоступен", 406, null, null, "external", null);
        }
        return ResponseBuilder.build(baseResponse);
    }

}
