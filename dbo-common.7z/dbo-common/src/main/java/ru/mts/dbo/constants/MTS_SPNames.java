package ru.mts.dbo.constants;

public enum MTS_SPNames {

    RBO("RBO"),
    MTS_EIP_UMP("MTS_EIP_UMP"),
    SIEBEL("SIEBEL"),
    Processing("Processing"),
    PHUB("PHUB"),
    ESB("ESB");

    private String value;
    MTS_SPNames(String value){
        this.value = value;
    }
    public String getValue(){
        return this.value;
    }
}
