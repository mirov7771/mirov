package ru.mts.dbo.utils;

public class MtsException extends Exception {

    int code;

    public MtsException(String message, int code) {
        super(message);
        this.code = code;
    }

    public MtsException(String message, int code, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public MtsException() {
        super();
    }

    public MtsException(String message) {
        super(message);
    }

    public int getCode() {
        return code;
    }

    public MtsException(String message, Throwable cause) {
        super(message, cause);
    }

    public void setCode(int code) {
        this.code = code;
    }

    public MtsException(Throwable cause) {
        super(cause);
    }

    protected MtsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
