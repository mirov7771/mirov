package ru.mts.dbo.constants;

public class EMAIL_Constants {

    public static String FROM_EMAIL = "noreply@mtsbank.ru";
    public static String LETTER_BODY_CONTENT_TYPE = "text/plain; charset=utf-8";
    public static String LETTER_SUBJECT = "Заказанные документы";
    public static String LETTER_BODY = "Заказанные документы находятся во вложении к данному письму";
    public static String DOCUMENT_NAME = "Документ";
    public static String UTF8 = "utf-8";

}
