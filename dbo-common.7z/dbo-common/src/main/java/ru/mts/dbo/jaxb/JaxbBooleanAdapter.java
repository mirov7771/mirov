package ru.mts.dbo.jaxb;

import javax.xml.bind.DatatypeConverter;

public class JaxbBooleanAdapter {

    public static Boolean parseIntegerToBoolean(String value) {

        int i = DatatypeConverter.parseInt(value);
        return i == 1;
    }

    public static String printBooleanToInteger(Boolean value) {

        if (value == null) {
            return null;
        }
        return DatatypeConverter.printInt(value ? 1 : 0);
    }
}
