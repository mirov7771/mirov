package ru.mts.dbo.constants;

public class MTSConstants {

    public static String ESB = "ESB";
    public static String UMP = "MTS_EIP_UMP";
    public static String SIEBEL = "SIEBEL";

    public static Long ERROR_CODE = 1L;
    public static String RETURN_MESSAGE_TECHNICAL_ERROR = "Technical error. ";

    public static String DEFAULT_MESSAGE = "Код подтверждения %CODE%";

}
