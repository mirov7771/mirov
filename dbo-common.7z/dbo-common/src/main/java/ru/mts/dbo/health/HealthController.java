package ru.mts.dbo.health;

import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${app.name}")
@Slf4j
public class HealthController {

    @Autowired
    private ReadinessHealthIndicator readinessHealthIndicator;

    @Autowired
    private LivenessHealthIndicator livenessHealthIndicator;

    @GetMapping
    @Operation(hidden = true)
    public String check() {
        return "Application is running";
    }

    @GetMapping(value = "/read")
    @Operation(hidden = true)
    public Health readiness() {
        return readinessHealthIndicator.health();
    }

    @GetMapping(value = "/live")
    @Operation(hidden = true)
    public Health liveness() {
        return livenessHealthIndicator.health();
    }

}
