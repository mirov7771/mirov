package ru.mts.dbo.constants;

public class PDF_Constants {

    public static String FULL_COMPANY_NAME = "Публичное акционерное общество «МТС-Банк»";
    public static String FULL_COMPANY_NAME_ENG = "Public Joint-Stock Company “MTS-Bank”";
    public static String SHORT_COMPANY_NAME = "ПАО «МТС-Банк»";
    public static String SHORT_COMPANY_NAME_ENG = "PJSC «MTS Bank»";
    public static String ADDRESS = "115432, г. Москва, пр-т Андропова, д. 18, корп. 1";
    public static String ADDRESS_ENG = "city of Moscow 18-1, Andropova avenue, 115432";
    public static String ADDRESS_REVERSED = "Российская Федерация, 115432, г. Москва, Андропова пр-т, д. 18, корп. 1";


    public static String PHONE = "8 (495) 777-00-01";
    public static String PHONE_2 = "8 (800) 250-0-520";
    public static String FAX = " 8 (495) 745-98-52";
    public static String EMAIL = "info@mtsbank.ru";
    public static String WEBSITE = "www.mtsbank.ru";


    public static String BIC = "044525232";
    public static String INN = "7702045051";
    public static String OGRN = "1027739053704";
    public static String KPP = "772501001";

    public static String CORR_ACCOUNT = "30101810600000000232 в ОПЕРУ Московского ГТУ Банка России";
    public static String BANK_LICENSE = "Генеральная банковская лицензия No2268 от 17.12.2014 г.";

    public static String ADDRESS_TYPE_REGISTRATION = "REGISTRATION";

}
