package ru.mts.dbo.constants;

public enum MTS_MessageTypes {

    ACCT_LIST_INQ_RQ("AcctListInqRq"),
    DEP_ACCT_STMT_INQ_RQ("DepAcctStmtInqRq"),
    CUST_SEARCH_INQ_RQ("CustSearchInqRq"),
    CUST_NOTIF_ADD_NF("CustNotifAddNf"),
    CARD_SVC_INQ_RQ("CardSvcInqRq"),
    CARD_LIST_INQ_RQ("CardListInqRq"),
    BAL_LIST_INQ_RQ("BalListInqRq"),
    CUST_SVC_STMT_INQ_RQ("CustSvcStmtInqRq"),
    LOAN_LIST_INQ_REQ("LoanListInqRq"),
    DEBT_INQ_REQ("DebtInqRq"),
    EXT_MSG_TYPE_1("1"),
    EXT_MSG_TYPE_5("5"),
    PMT_SCHED_INQ_RQ("PmtSchedInqRq"),
    ORDER_ADD_RQ("OrderAddRq"),
    ORDER_CAN_RQ("OrderCanRq"),

    // Extended Message Types:
    ACTIVE_AND_NON_ACTIVE("ACTIVEANDNONACTIVE"),
    ACTIVE_COUNT("ActiveCount");

    private String value;
    MTS_MessageTypes(String value){
        this.value = value;
    }
    public String getValue(){
        return this.value;
    }
}
