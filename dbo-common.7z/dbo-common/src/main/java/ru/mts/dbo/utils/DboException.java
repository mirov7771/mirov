package ru.mts.dbo.utils;

import lombok.Data;
import lombok.EqualsAndHashCode;


@EqualsAndHashCode(callSuper = true)
@Data
public class DboException extends RuntimeException {
    private FailureType type;
    private String passedMessage;
    private String system;
    private String uuid;

    public DboException(FailureType type) {
        this.type = type;
        this.passedMessage = type.getMessage();
    }

    public DboException(FailureType type, String system, String uuid) {
        this.type = type;
        this.passedMessage = type.getMessage();
        this.system = system;
        this.uuid=uuid;
    }


    @Override
    public String toString() {
        return "DboException{" +
                "type=" + type +
                ", passedMessage='" + passedMessage + '\'' +
                ", system='" + system + '\'' +
                ", uuid='" + uuid + '\'' +
                '}';
    }
}

