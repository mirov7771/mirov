package ru.mts.dbo.constants;

public enum MTS_BusinessProcessId {

    MTS_DBO_ACC_LIST("MTS_DBO_ACC_LIST"),
    MTS_OPER_LIST("MTS_OPER_LIST"),
    MTS_EWALLET("MTS_EWALLET"),
    MBR_EGAR_CRD_ALL("MBR_EGAR_CRD_ALL"),
    MTS_BAL_LIST("MTS_BAL_LIST"),
    MTS_CC_STATEMENT("MTS_CC_STATEMENT"),
    MBR_EGAR_LOANLST("MBR_EGAR_LOANLST"),
    MTS_DEBT_INQ_RQ("MTS_DEBTINQRQ");

    private String value;
    MTS_BusinessProcessId(String value){
        this.value = value;
    }
    public String getValue(){
        return this.value;
    }

}
