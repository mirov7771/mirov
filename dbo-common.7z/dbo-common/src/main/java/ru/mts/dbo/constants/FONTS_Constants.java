package ru.mts.dbo.constants;

public class FONTS_Constants {

    public static float FONT_SIZE_12 = 12f;
    public static float FONT_SIZE_7 = 7f;
    public static String FONT_BASE = "Identity-H";

    public static float TITUL_PAGE_MARGIN_TOP = 20;
    public static float TITUL_PAGE_MARGIN_BOTTOM = 20;
    public static float TITUL_PAGE_MARGIN_RIGHT = 20;
    public static float TITUL_PAGE_MARGIN_LEFT = 10;

}
