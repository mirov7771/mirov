package ru.mts.dbo.constants;

public enum MTS_MsgReceivers {

    RBO("RBO"),
    SIEBEL("SIEBEL"),
    ESB("ESB"),
    MTS_EIP_UMP("MTS_EIP_UMP"),
    Processing("Processing");

    private String value;
    MTS_MsgReceivers(String value){
        this.value = value;
    }
    public String getValue(){
        return this.value;
    }

}
