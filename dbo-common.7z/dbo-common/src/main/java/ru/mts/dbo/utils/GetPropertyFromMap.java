package ru.mts.dbo.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class GetPropertyFromMap {

    private static final ObjectMapper mapper = new ObjectMapper();

    public String getPropertyFromMap(Map<String, Object> params, String property){
        String value = null;
        try{
            String[] props = property.split("\\.");
            int sz = props.length;
            Map<String, Object> propValue = new HashMap<>();
            if (!params.isEmpty()) {
                for (int i = 0; i < sz; i++) {
                    String key = props[i];
                    if (i == 0) {
                        propValue = (HashMap) params.get(key);
                    } else if (i < sz - 1) {
                        if (propValue != null && !propValue.isEmpty()) {
                            propValue = (HashMap) propValue.get(key);
                        }
                    } else {
                        if (propValue != null && !propValue.isEmpty()) {
                            value = (String) propValue.get(key);
                            break;
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error in method getPropertyFromMap " + e);
            e.printStackTrace();
        }
        return value;
    }
}
