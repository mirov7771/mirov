package ru.mts.dbo.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.util.StringUtils;
import org.w3c.dom.NodeList;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE;
import static java.time.format.DateTimeFormatter.ISO_LOCAL_TIME;

public class Utils {

    private static final ObjectMapper mapper = new ObjectMapper();

    public static boolean isEmpty(String str) {
        return str == null || str.length() == 0;
    }

    public static XMLGregorianCalendar getXmlGregorianCalendar(Date date) {
        if (date == null) {
            return null;
        }
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(date));
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static <T> T nvl(T a, T b){
        return a != null ? a : b;
    }

    public static String getSumm(String value){
        value = value.replace(" .","0.");
        StringBuilder sb = new StringBuilder();
        if (!isEmpty(value)) {
            Pattern pat = Pattern.compile("[-]?[0-9]+(.[0-9]+)?");
            Matcher matcher = pat.matcher(value);
            while (matcher.find())
                sb.append(matcher.group());
        }
        String s = sb.toString();
        if (s.contains(".")){
            if (s.substring(s.indexOf(".")).length() == 2){
                s += "0";
            }
        }
        return s;
    }

    public static String castPhone(String phone){
        switch(phone.charAt(0))
        {
            case '7' :
            case '8' : return "+7" + phone.substring(1);
            case '9' : return "+7" + phone;
            case '+' : return phone;
            default: return null;
        }
    }

    public static String formatPhone(String phone){
        String retPhone = phone;
        if (!isEmpty(retPhone)){
            if (retPhone.length() == 10)
                retPhone =  "7"+retPhone;
            else if (retPhone.startsWith("7") && retPhone.length() == 11)
                retPhone =  phone;
            else if (retPhone.startsWith("8") && retPhone.length() == 11)
                retPhone = "7"+phone.substring(1,11);
            else
                retPhone = phone;
        }
        return retPhone.replace("+", "");
    }

    public static BigDecimal devideSum(BigDecimal sum) {
        return sum.divide(new BigDecimal(100)).setScale(2, BigDecimal.ROUND_DOWN);
    }

    public static Date getDate(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static String formatName(String senderPAM) {
        String retVal;
        String[] items = senderPAM.split(" ");
        if (items.length >= 3){
            retVal = formatPart(items[0])+" ";
            retVal += formatPart(items[1])+" ";
            retVal += items[2].toUpperCase().charAt(0)+".";
        } else if (items.length == 2){
            retVal = formatPart(items[0])+" ";
            retVal += items[1].toUpperCase().charAt(0)+".";
        } else {
            retVal = formatPart(senderPAM);
        }
        return retVal;
    }

    private static String formatPart(String part){
        return part.substring(0,1).toUpperCase()+part.substring(1).toLowerCase();
    }

    public static boolean isEmpty(Collection coll) {
        return coll == null || coll.isEmpty();
    }

    public static boolean isNotEmpty(Collection coll) {
        return !isEmpty(coll);
    }

    public static boolean isDigits(String str) {
        return isNumeric(str);
    }

    public static boolean isNumeric(CharSequence cs) {
        if (isEmpty(cs)) {
            return false;
        } else {
            int sz = cs.length();

            for(int i = 0; i < sz; ++i) {
                if (!Character.isDigit(cs.charAt(i))) {
                    return false;
                }
            }

            return true;
        }
    }

    public static boolean isEmpty(CharSequence cs) {
        return cs == null || cs.length() == 0;
    }

    public static String updateStringInSHA(byte[] inputStr){
        String generatedHash = null;
        if (inputStr != null) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-512");
                md.update(inputStr);
                byte[] byteData = md.digest();
                StringBuilder hexString = new StringBuilder();
                for (byte b : byteData) {
                    hexString.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
                }
                generatedHash = hexString.toString();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        return generatedHash;
    }

    public static Integer getIntFromStr(String value){
        if (isNumeric(value))
            return Integer.parseInt(value);
        return null;
    }

    public static BigInteger getBigIntFromStr(String value){
        if (isNumeric(value))
            return new BigInteger(value);
        return null;
    }

    public static BigDecimal getBigDecimalFromStr(String value){
        return new BigDecimal(value.replace(",","."));
    }

    public static Boolean getBoolFromStr(String value){
        return Boolean.valueOf(value);
    }

    public static Date getDateFromStr(String value) throws ParseException {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS Z");
        return format.parse(value);
    }

    public static Float getFloatFromStr(String value) {
        return Float.parseFloat(value);
    }

    public static String getStrFromDate(Date date){
        if (date == null)
            return null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS Z")
                .withZone(ZoneOffset.UTC);
        return formatter.format(date.toInstant());
    }

    public static void setAddrMap(Map<String, String> inputMap, Map<String, String> addrMap, String addrType){
        if (!addrMap.isEmpty()){
            for(Map.Entry<String, String> entry : addrMap.entrySet()){
                inputMap.put(addrType+"/"+entry.getKey(), entry.getValue());
            }
        }
    }

    public static void setRefMap(Map<String, String> inputMap, Map<String, String> refMap, String type){
        if (!refMap.isEmpty()){
            for(Map.Entry<String, String> entry : refMap.entrySet()){
                inputMap.put(type+"/"+entry.getKey(), entry.getValue());
            }
        }
    }

    public static String concatStrings(String... elems){
        StringBuilder sb = new StringBuilder();
        for(String elem: elems){
            if(isNotBlank(elem)){
                sb.append(elem);
            }
        }
        return sb.toString();
    }

    public static String getMonthOrDateAsTwoSymbols(int month) {
        String monthAsString = String.valueOf(month);
        if (monthAsString.length() == 1) {
            monthAsString = "0" + monthAsString;
        }
        return monthAsString;
    }

    public static String getDateAsString(int year, int month, int day) {
        return concatStrings(String.valueOf(year),
                Utils.getMonthOrDateAsTwoSymbols(month),
                Utils.getMonthOrDateAsTwoSymbols(day));
    }

    public static BigInteger getBigIntegerValue(Object value){
        if (value instanceof BigInteger){
            return (BigInteger) value;
        } else if (value instanceof String){
            String p = (String) value;
            return new BigInteger(p);
        }
        return null;
    }

    public static String getStringValue(Object value){
        if (value instanceof String) {
            return (String) value;
        } else if (value instanceof Long){
            Long id = (Long) value;
            return Long.toString(id);
        } else if (value instanceof Integer){
            Integer i = (Integer) value;
            return Integer.toString(i);
        }
        return null;
    }


    public static BigDecimal getBigDecimalValue(Object value){
        if (value == null)
            return null;
        if (value instanceof BigDecimal){
            return (BigDecimal) value;
        } else if (value instanceof String){
            String p = (String) value;
            return new BigDecimal(p);
        } else if (value instanceof Long){
            Long l = (Long) value;
            return new BigDecimal(l);
        }
        return null;
    }

    public static String getString(Object originalID) {
        if (originalID instanceof String)
            return (String) originalID;
        if (originalID instanceof Long){
            Long val = (Long) originalID;
            return val.toString();
        }
        return null;
    }

    public static boolean isBlank(String str) {
        int strLen;
        if (str == null || (strLen = str.length()) == 0) {
            return true;
        }
        for (int i = 0; i < strLen; i++) {
            if ((!Character.isWhitespace(str.charAt(i)))) {
                return false;
            }
        }
        return true;
    }

    public static boolean isNotBlank(String str) {
        return !isBlank(str);
    }

    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> asArrayListWithoutError(Object obj) {
        List<Map<String, Object>> list = new ArrayList<>();
        if (obj instanceof Collection) {
            list = new ArrayList<>((Collection<Map<String, Object>>) obj);
        }
        return list;
    }

    public String updateStringInSHA(String value) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA");
        md.update(value.getBytes());
        byte[] byteData = md.digest();
        StringBuilder hexString = new StringBuilder();
        for (byte byteDatum : byteData) {
            String hex = Integer.toHexString(0xff & byteDatum);
            if (hex.length() == 1)
                hexString.append('0');
            hexString.append(hex);
        }
        String hash = hexString.toString();
        return hash.toUpperCase();
    }

    public static String toHex(String arg) {
        return String.format("%040x", new BigInteger(1, arg.getBytes(StandardCharsets.UTF_8)));
    }


    public static String getStringFromXml(org.w3c.dom.Element element, String tag){
        NodeList node = element.getElementsByTagName(tag);
        if (node != null && node.item(0) != null)
            return node.item(0).getTextContent();
        return null;
    }

    public static String emptyAmount(String amount){
        return !StringUtils.isEmpty(amount) ? amount : "0.00";
    }

    public static String getDateAsStringDotted(int day, int month, int year) {
        return  Utils.getMonthOrDateAsTwoSymbols(day) + "." +
                Utils.getMonthOrDateAsTwoSymbols(month) + "." +
                Utils.getMonthOrDateAsTwoSymbols(year);
    }

    public static ZonedDateTime getDateAsISO8601(String dateString) {
        return  ZonedDateTime.parse(dateString, java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssX"));
    }

    public static ZonedDateTime getZonedDateTimeFromOrigDtAndZoneId(String origDt, ZoneId zoneId) { // <OrigDt>23.06.2020 16:39:31</OrigDt>

        String localDateStr = origDt.split(" ")[0];
        String localTimeStr = origDt.split(" ")[1];

        String dayOfMonth = localDateStr.split("\\.")[0];
        String month = localDateStr.split("\\.")[1];
        String year = localDateStr.split("\\.")[2];
        String localDateStrReversed = year + "-" +  month + "-" + dayOfMonth;

        LocalTime localTime = LocalTime.parse(localTimeStr, ISO_LOCAL_TIME);
        LocalDate localDate = LocalDate.parse(localDateStrReversed,  ISO_LOCAL_DATE);

        return ZonedDateTime.of(localDate, localTime, zoneId);
    }


    public static String getStampPath(Class cls, String stampName){
        return cls.getClassLoader().getResource("page/"+ stampName +".png").toString();
    }

    public static InputStream getStampInputStream(Class cls){
        return cls.getResourceAsStream("page/stamp(print-forms).png");
    }

    public static InputStream getBankInfoInputStream(Class cls){
        return cls.getResourceAsStream("page/bankinfo.png");
    }

    public static String getFontPath(Class cls, String fontName){
        return cls.getClassLoader().getResource("page/"+ fontName +".ttf").toString();
    }

    public static String getLogoPath(Class cls){
        return cls.getClassLoader().getResource("page/logo.png").toString();
    }

    public static String getReportPath(Class cls){
        return cls.getClassLoader().getResource("reports/").toString();
    }

    public static String getSqlCommand(Class cls, String command){
        return new BufferedReader(
                new InputStreamReader(cls.getResourceAsStream("/sql/"+command+".sql"))
        ).lines().collect(Collectors.joining("\n"));
    }

    public static List<String> getStateAndImagePathForTransaction(Class cls, String state){
        List<String> res = new ArrayList<>();
        switch(state)
        {
            case "REGISTERED" :
            case "0" :
                res.add(getStampPath(cls,"PROCESSING"));
                res.add("Перевод зарегистрирован в системе");
            case "REJECTED" :
            case "6" :
                res.add(getStampPath(cls,"REJECTED")) ;
                res.add("Отказ Банка в проведении платежа");
            case "PROCESSING" :
            case "7" :
                res.add(getStampPath(cls,"PROCESSING"));
                res.add("Платеж исполняется");
            case "PROCESSED" :
            case "2" :
                res.add(getStampPath(cls,"PROCESSED"));
                res.add("Перевод выполнен");
            case "3" :
                res.add(getStampPath(cls,"REFUNDED"));
                res.add("Операция отменена (была успешно выполнена и отменена)");
            case "4" :
                res.add(getStampPath(cls,"REFUNDED"));
                res.add("Операция ожидает подтверждения со стороны пользователя кошелька");
            case "5" :
                res.add(getStampPath(cls,"PROCESSING"));
                res.add("");
            case "8" :
                res.add(getStampPath(cls,"REJECTED"));
                res.add("Операция отменена клиентом");
            case "NOT_FOUND" :
                res.add("Перевод не найден");
                res.add("");
            default:
                res.add("Перевод не выполнен");
                res.add("");
        }
        return res;
    }

    public static String getLocalDateTimeAsStringDotted(LocalDateTime localDateTime) { // "01.10 12:30"
        LocalDate localDate = localDateTime.toLocalDate();
        LocalTime localTime = localDateTime.toLocalTime();
        return  getMonthOrDateAsTwoSymbols(localDate.getDayOfMonth()) + "." + getMonthOrDateAsTwoSymbols(localDate.getMonthValue())
                + " " +
                getMonthOrDateAsTwoSymbols(localTime.getHour()) + "." + getMonthOrDateAsTwoSymbols(localTime.getMinute())
                ;
    }

    public static String getStackError(Exception e){
        StringWriter stack = new StringWriter();
        e.printStackTrace(new PrintWriter(stack));
        return stack.toString();
    }

    public static InputStream getFileInputStream(Class cls, String path, String name) {
        return cls.getClassLoader().getResourceAsStream(path+"/"+name);
    }

    public static String formatPhoneWithPlus(String value){
        if (value.startsWith("+7"))
            return value;
        if (value.startsWith("7"))
            return "+"+value;
        return "+7"+value;
    }

    public static Long getRboIdFromToken(String token){
        long ret = 0L;
        try {
            if (!isEmpty(token)) {
                String[] list = token.split("\\.");
                String lastPart = list[list.length - 1].replaceAll("-", "+").replaceAll("_", "/");
                String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
                Map<String, Object> outputParams;
                outputParams = mapper.readValue(decodePart, Map.class);
                if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
                    Map<String, Object> userData = (HashMap) outputParams.get("user_data");
                    String rboId = (String) userData.get("rbo_id");
                    if (!StringUtils.isEmpty(rboId) && Utils.isDigits(rboId))
                        ret = Long.parseLong(rboId);
                }
            }
        } catch (IOException | IllegalArgumentException e){
            e.printStackTrace();
        }
        return ret;
    }

    public static String getSrcPhoneFromToken(String token) {
        String phone = "";
        try {
            if (!isEmpty(token)) {
                String[] list = token.split("\\.");
                String lastPart = list[list.length - 1].replaceAll("-", "+").replaceAll("_", "/");
                String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
                Map<String, Object> outputParams;
                outputParams = mapper.readValue(decodePart, Map.class);
                if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
                    Map<String, Object> userData = (HashMap) outputParams.get("user_data");
                    String phoneNumber = getPhoneFromXor(userData.get("phone_number"));
                    phone = phoneNumber;
                }
            }
        } catch (IOException | IllegalArgumentException e){
            e.printStackTrace();
        }
        return phone;
    }

    public static String getPhoneFromXor(Object phone_number) {
        String retVal = null;
        if (phone_number != null) {
            String value = (String) phone_number;
            if (!Utils.isEmpty(value)) {
                String key = "mts-bank-platform";
                char[] decodedPhoneNumberChars = new char[value.length()];
                for (int i = 0; i < value.length(); i++) {
                    decodedPhoneNumberChars[i] = (char) (value.charAt(i) ^ key.charAt(i % key.length()));
                }
                retVal = new String(decodedPhoneNumberChars);
            }
        }
        return retVal;
    }


    public static String getOtfFontPath(Class cls, String fontName) {
        return cls.getClassLoader().getResource("page/" + fontName + ".otf").toString();
    }

    public static String getLogo2Path(Class cls) {
        return cls.getClassLoader().getResource("page/logo2.png").toString();
    }

    public static String getLogo2EngPath(Class cls) {
        return cls.getClassLoader().getResource("page/logo2eng.png").toString();
    }

    public static void preCheckToken(Long rboId, String phone, String method, String uid) throws DboException{
        if ((rboId == null || rboId.equals(0L)) && (isEmpty(phone) || phone.equals("")))
            throw new DboException(FailureType.BAD_TOKEN,method,uid);
    }

    public static String createJavaDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String retDate = sdf.format(date);
        retDate += "T00:00:00.000+0000";
        return retDate;
    }

    public static Long getLongValue(Object value){
        if (value == null)
            return null;
        if (value instanceof Long)
            return (Long) value;
        if (value instanceof String)
            return Long.valueOf((String) value);
        if (value instanceof Integer)
            return Long.valueOf((Integer) value);
        return null;
    }

    public static String getStrFromDateGmt(Date date, String zone) {
        if (date == null) {
            return null;
        } else {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS Z").withZone(ZoneId.of(zone));
            return formatter.format(date.toInstant());
        }
    }

}
