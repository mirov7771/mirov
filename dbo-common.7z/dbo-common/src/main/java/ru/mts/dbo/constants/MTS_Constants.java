package ru.mts.dbo.constants;

public class MTS_Constants {

    public static String TECHNICAL_ERROR = "Сервис временно недоступен";

    public static String EXT_INFO_METHOD = "ext_info";
    public static String STATEMENT_METHOD = "statement";
    public static String CREDIT_CARD_NAME_HASHED_CARD = "hashed_card";

    public static Boolean PCIDSS = true;

    public static String SYNC = "SYNC";
    public static String ASYNC = "ASYNC";

    public static String TRANSACTION_LIMIT_NAME = "row_limit";
    public static String TRANSACTION_LIMIT_VALUE = "-1";

    public static String USE_ARCH_NAME = "use_arch";
    public static String USE_ARCH_VALUE = "false";

    public static long READ_TIME_OUT_IN_MILLISECONDS = 300_000;

}
