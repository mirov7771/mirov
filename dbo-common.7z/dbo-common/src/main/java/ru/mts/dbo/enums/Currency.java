package ru.mts.dbo.enums;

public enum Currency {

    RUB("RUB", "810"),
    RUR("RUR", "643"),
    USD("USD", "840"),
    EUR("EUR", "978"),
    GPB("GPB", "826");

    private String value;
    private String iso;

    Currency(String value, String iso){
        this.value = value;
        this.iso = iso;
    }

    public static Currency get(String value){
        for(Currency currency : Currency.values()){
            if (currency.value.equalsIgnoreCase(value))
                return currency;
            if (currency.iso.equals(value))
                return currency;
        }
        return null;
    }

    public static Boolean isRub(String value){
        return value.equals(RUB.iso)
                || value.equalsIgnoreCase(RUB.value)
                || value.equalsIgnoreCase(RUR.value)
                || value.equals(RUR.iso);
    }

    public String getValue() {
        return value;
    }

    public String getIso() {
        return iso;
    }
}
