package ru.mts.dbo.enums;

public enum ActivityTypes {

    WORKACTIVITY_1("WORKACTIVITY.1","WORKACTIVITY.1"),
    WORKACTIVITY_2("WORKACTIVITY.2","WORKACTIVITY.4"),
    WORKACTIVITY_3("WORKACTIVITY.3","WORKACTIVITY.2"),
    WORKACTIVITY_4("WORKACTIVITY.4","WORKACTIVITY.8"),
    WORKACTIVITY_5("WORKACTIVITY.5","WORKACTIVITY.7"),
    WORKACTIVITY_6("WORKACTIVITY.6","WORKACTIVITY.6"),
    WORKACTIVITY_7("WORKACTIVITY.7","WORKACTIVITY.5");

    private final String frontValue;
    private final String esbValue;

    ActivityTypes(String frontValue, String esbValue){
        this.frontValue = frontValue;
        this.esbValue = esbValue;
    }

    public String getFrontValue() {
        return frontValue;
    }

    public String getEsbValue() {
        return esbValue;
    }

    public static String getEsbValue(String frontValue){
        for(ActivityTypes types : ActivityTypes.values()){
            if (types.getFrontValue().equalsIgnoreCase(frontValue)){
                return types.getEsbValue();
            }
        }
        return frontValue;
    }


}
