package ru.mts.dbo.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import ru.mts.dbo.utils.Utils;

import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@Slf4j
public class BaseResponse {

    @JsonIgnore
    private ErrorResponse errorResponse;

    @JsonProperty("requestId")
    private String requestId;

    public ErrorResponse createError(Integer code, String message, int httpCode, String externalCode, String details, String service, String requestId){
        String uid = Utils.isEmpty(requestId) ? UUID.randomUUID().toString() : requestId;
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setError(
                new ErrorResponse.Error(code, message, uid, externalCode, details, httpCode)
        );
        this.errorResponse = errorResponse;
        return errorResponse;
    }

}
