package ru.sberx.audit.dao.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.dto.audit.req.CreateAuditReq;
import ru.sberx.dto.audit.res.AuditStatisticRes;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = "AUDIT")
@AllArgsConstructor
@NoArgsConstructor
@SqlResultSetMapping(
        name = "AuditStatisticRow",
        classes = @ConstructorResult(
                targetClass = AuditStatisticRes.Row.class,
                columns = {
                        @ColumnResult(name = "date", type = Date.class),
                        @ColumnResult(name = "userId", type = Long.class)
                }
        )
)
public class AuditDao implements Serializable {

    private static final long serialVersionUID = -5531515181448119279L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "USERNAME")
    private String userName;
    @Column(name = "ACTION")
    private String action;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "ARCHIVE")
    private Boolean archive;
    @Column(name = "SERVICE")
    private String service;
    @Column(name = "REQUEST")
    private String request;
    @Column(name = "IP")
    private String ip;

    public AuditDao(CreateAuditReq req) {
        this.userId = req.getUserId();
        this.userName = req.getUserName();
        this.action = req.getAction();
        this.status = req.getStatus();
        this.date = req.getDate();
        this.service = req.getService();
        this.request = req.getRequest();
        this.ip = req.getIp();
    }
}
