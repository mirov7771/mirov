package ru.sberx.audit.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Component;
import ru.sberx.audit.dao.model.AuditDao;
import ru.sberx.audit.service.Service;
import ru.sberx.audit.service.impl.components.AuditManager;
import ru.sberx.dto.audit.req.AuditListReq;
import ru.sberx.dto.audit.req.AuditStatisticReq;
import ru.sberx.dto.audit.req.CreateAuditReq;
import ru.sberx.dto.audit.res.AuditListRes;
import ru.sberx.dto.audit.res.AuditStatisticRes;
import ru.sberx.utils.util.ListUtils;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ServiceImpl implements Service {

    private final AuditManager auditManager;

    @Override
    public void saveAudit(CreateAuditReq req) {
        auditManager.saveAudit(req);
    }

    @Override
    public AuditListRes getAuditList(AuditListReq req) {
        List<AuditDao> auditDaos = auditManager.getAuditList(req.getDateBegin(), req.getDateEnd(), req.getUserid(), req.getAction());
        List<AuditListRes.Form> list = auditDaos.stream().map(i -> {
            AuditListRes.Form form = new AuditListRes.Form();
            form.setAction(i.getAction());
            form.setService(i.getService());
            form.setDate(i.getDate());
            form.setIp(i.getIp());
            form.setRequest(i.getRequest());
            form.setUserId(i.getUserId());
            form.setUserName(i.getUserName());
            form.setStatus(i.getStatus());
            return form;
        }).sorted((o1, o2) -> {
            if (Objects.nonNull(o1.getDate()) && Objects.nonNull(o2.getDate())) {
                return o1.getDate().compareTo(o2.getDate());
            } else {
                return 0;
            }
        }).collect(Collectors.toList());
        AuditListRes res = new AuditListRes();
        int rowCount = req.getRowCount() != null && list.size() > req.getRowCount() ? req.getRowCount() : list.size();
        Pair<List<AuditListRes.Form>, Integer> shortenList = ListUtils.pagination(list, rowCount, req.getPageToken());
        res.setRows(shortenList.getFirst());
        res.setNextPage(shortenList.getSecond() > 0 ? shortenList.getSecond() : null);
        return res;
    }

    @Override
    public AuditStatisticRes getAuditStatistic(AuditStatisticReq req) {
        AuditStatisticRes res = new AuditStatisticRes();
        List<AuditStatisticRes.Row> rows =  auditManager.getStatistic(req);
        res.setRows(rows);
        return res;
    }
}
