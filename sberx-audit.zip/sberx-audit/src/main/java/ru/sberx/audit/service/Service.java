package ru.sberx.audit.service;


import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.audit.req.AuditListReq;
import ru.sberx.dto.audit.req.AuditStatisticReq;
import ru.sberx.dto.audit.req.CreateAuditReq;
import ru.sberx.dto.audit.res.AuditListRes;
import ru.sberx.dto.audit.res.AuditStatisticRes;

public interface Service {
    default void saveAudit(CreateAuditReq req) {
        throw new SberxException(SberxErrors.METHOD_DOES_NOT_EXIST);
    }
    default AuditListRes getAuditList(AuditListReq req) {
        throw new SberxException(SberxErrors.METHOD_DOES_NOT_EXIST);
    }
    default AuditStatisticRes getAuditStatistic(AuditStatisticReq req) {
        throw new SberxException(SberxErrors.METHOD_DOES_NOT_EXIST);
    }
}
