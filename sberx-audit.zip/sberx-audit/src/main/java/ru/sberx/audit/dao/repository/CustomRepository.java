package ru.sberx.audit.dao.repository;


import ru.sberx.dto.audit.res.AuditStatisticRes;

import java.util.Date;
import java.util.List;

public interface CustomRepository {

    List<AuditStatisticRes.Row> findDistinctDateAndUserId(Date begin, Date end);
}
