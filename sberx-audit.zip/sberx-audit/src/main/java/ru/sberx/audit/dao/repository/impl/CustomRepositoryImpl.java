package ru.sberx.audit.dao.repository.impl;

import org.hibernate.query.Query;
import ru.sberx.audit.dao.repository.CustomRepository;
import ru.sberx.dto.audit.res.AuditStatisticRes;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Date;
import java.util.List;

public class CustomRepositoryImpl implements CustomRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Override
    public List<AuditStatisticRes.Row> findDistinctDateAndUserId(Date beginDate, Date endDate) {
        String sql = "select date(date), userid \n" +
                "from audit a\n" +
                "where\n" +
                "((a.action not like 'AUTH') or (a.action like 'AUTH' and a.status not like 'error'))";
        if (beginDate != null)
            sql += " and a.date >= :beginDate";
        if (endDate != null)
            sql += " and a.date <= :endDate";
        Query<AuditStatisticRes.Row> query = entityManager.createNativeQuery(sql, "AuditStatisticRow").unwrap(Query.class);
        if (sql.contains(":beginDate"))
            query.setParameter("beginDate", beginDate);
        if (sql.contains(":endDate"))
            query.setParameter("endDate", endDate);
        return query.getResultList();
    }
}
