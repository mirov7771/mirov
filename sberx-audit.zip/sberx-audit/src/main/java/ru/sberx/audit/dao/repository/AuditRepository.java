package ru.sberx.audit.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.audit.dao.model.AuditDao;

@Repository
public interface AuditRepository extends CrudRepository<AuditDao, Long>, CustomRepository {
}
