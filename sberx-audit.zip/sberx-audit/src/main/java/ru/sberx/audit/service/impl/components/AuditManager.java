package ru.sberx.audit.service.impl.components;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.audit.dao.model.AuditDao;
import ru.sberx.audit.dao.model.AuditDao_;
import ru.sberx.audit.dao.repository.AuditRepository;
import ru.sberx.dto.audit.req.AuditStatisticReq;
import ru.sberx.dto.audit.req.CreateAuditReq;
import ru.sberx.dto.audit.res.AuditStatisticRes;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Component
@Slf4j
@RequiredArgsConstructor
public class AuditManager {

    private final AuditRepository auditRepository;
    private final EntityManager entityManager;

    private final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public void saveAudit(CreateAuditReq req) {
        AuditDao newAudit = new AuditDao(req);
        log.debug("Saving audit: {}", newAudit);
        AuditDao savedAudit = auditRepository.save(newAudit);
        log.debug("Audit saved with id: {}", savedAudit.getId());
    }

    public List<AuditDao> getAuditList(Date dateBegin, Date dateEnd, Long userId, Integer action) {
        log.debug("Selecting audits with parameters: dateBegin = {}, dateEnd = {}, userId = {}, action = {}", dateBegin, dateEnd, userId, action);
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<AuditDao> query = cb.createQuery(AuditDao.class);
        Root<AuditDao> auditDaoRoot = query.from(AuditDao.class);
        query.select(auditDaoRoot);
        if (userId != null) {
            query.where(cb.equal(auditDaoRoot.get(AuditDao_.USER_ID), userId));
        }
        if (action != null) {
            query.where(cb.equal(auditDaoRoot.get(AuditDao_.ACTION), auditDaoRoot));
        }
        if (dateBegin != null) {
            query.where(cb.greaterThanOrEqualTo(auditDaoRoot.get(AuditDao_.DATE), dateBegin));
        }
        if (dateEnd != null) {
            query.where(cb.lessThanOrEqualTo(auditDaoRoot.get(AuditDao_.DATE), dateEnd));
        }
        List<AuditDao> auditDaos = entityManager.createQuery(query).getResultList();
        log.debug("Returned list from database: {}", auditDaos);
        return auditDaos;
    }

    public List<AuditStatisticRes.Row> getStatistic(AuditStatisticReq req) {
        Date beginDate = req.getDateBegin() != null ? getDateStartOfDay(req.getDateBegin()) : null;
        Date endDate = req.getDateEnd() != null ? getDateEndOfDay(req.getDateEnd()) : null;
        return auditRepository.findDistinctDateAndUserId(beginDate, endDate);
    }

    private Date getDateEndOfDay(String dateStr) {
        Date date = null;
        try {
            date = dateFormat.parse(dateStr);
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            c.set(Calendar.HOUR_OF_DAY, 23);
            c.set(Calendar.MINUTE, 59);
            c.set(Calendar.SECOND, 59);
            c.set(Calendar.MILLISECOND, 999);
            date = c.getTime();
        } catch (ParseException e) {
            log.error("error parse date: {}", e.getMessage());
        }
        return date;
    }

    private Date getDateStartOfDay(String dateStr) {
        Date date = null;
        try {
            date = dateFormat.parse(dateStr);
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            c.set(Calendar.HOUR_OF_DAY, 0);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            date = c.getTime();
        } catch (ParseException e) {
            log.error("error parse date: {}", e.getMessage());
        }
        return date;
    }
}
