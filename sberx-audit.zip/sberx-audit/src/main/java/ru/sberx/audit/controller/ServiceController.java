package ru.sberx.audit.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.audit.service.Service;
import ru.sberx.dto.audit.req.AuditListReq;
import ru.sberx.dto.audit.req.AuditStatisticReq;
import ru.sberx.dto.audit.req.CreateAuditReq;
import ru.sberx.utils.builder.ResponseBuilder;

import javax.validation.Valid;


@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Slf4j
public class ServiceController {

    private static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    private final Service service;

    @PostMapping(value = "audit", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveAudit(@Valid @RequestBody CreateAuditReq req) {
        service.saveAudit(req);
        return ResponseBuilder.ok(null);
    }

    @GetMapping(value = "audit", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAuditList(AuditListReq req) {
        return ResponseBuilder.ok(service.getAuditList(req));
    }

    @GetMapping(value = "audit/statistic", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAuditStatistic(AuditStatisticReq req) {
        return ResponseBuilder.ok(service.getAuditStatistic(req));
    }
}
