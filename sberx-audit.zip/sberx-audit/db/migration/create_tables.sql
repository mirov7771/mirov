CREATE TABLE audit
(
    id       bigint NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    object   varchar(50),
    userid   bigint,
    username varchar(100),
    action   varchar(50),
    status   varchar(20),
    date     timestamp,
    archive  boolean default false,
    service  varchar(200),
    request  text,
    ip       varchar(50)
);


CREATE INDEX x1_audit ON audit (userid);
CREATE INDEX x2_audit ON audit (date);