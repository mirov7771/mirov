--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4344
ALTER TABLE public.audit ALTER COLUMN "object" TYPE varchar(350) USING "object"::varchar;
ALTER TABLE public.audit ALTER COLUMN "username" TYPE varchar(350) USING "username"::varchar;
ALTER TABLE public.audit ALTER COLUMN "action" TYPE text USING "action"::text;
ALTER TABLE public.audit ALTER COLUMN "status" TYPE varchar(250) USING "status"::varchar;
ALTER TABLE public.audit ALTER COLUMN "service" TYPE text USING "service"::text;
ALTER TABLE public.audit ALTER COLUMN "ip" TYPE varchar(250) USING "ip"::varchar;