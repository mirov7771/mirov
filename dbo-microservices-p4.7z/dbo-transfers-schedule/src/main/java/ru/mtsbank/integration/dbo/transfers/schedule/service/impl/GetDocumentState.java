package ru.mtsbank.integration.dbo.transfers.schedule.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.gates.NotifGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.transfers.schedule.builders.JsonBuilder;
import ru.mtsbank.integration.dbo.transfers.schedule.builders.XmlBuilder;
import ru.mtsbank.integration.dbo.transfers.schedule.config.CustomConfig;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.NotificationRepository;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.TransferRepository;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.model.Notification;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.model.Transfer;
import ru.mtsbank.integration.dbo.transfers.schedule.service.MtsScheduler;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.GetDocumentsStateResponse;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.TransferOperations;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.TransferResponse;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static ru.mts.dbo.utils.Utils.formatPhone;

@Slf4j
@Service
@EnableScheduling
public class GetDocumentState implements MtsScheduler {

    @Autowired
    private NotifGate notifGate;

    @Autowired
    private TransferRepository transferRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private CustomConfig customConfig;

    @Autowired
    private XmlBuilder xmlBuilder;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private JsonBuilder jsonBuilder;

    @Autowired
    private EsbGate esbGate;

    @Override
    public void getDocumentState() {

        int batch = customConfig.getApp().getBatch();

        List<Transfer> trnList = transferRepository.findByState("VERIFIED", new PageRequest(0,batch));
        if (!CollectionUtils.isEmpty(trnList)) {
            List<String> listDocExtId = trnList.stream().map(Transfer::getDocExtId).collect(Collectors.toList());


            String DocumentsStateInqXML = xmlBuilder.DocumentsStateInqXML(listDocExtId);

            log.info("Send XML message getDocumentsStateRqXML to ESB");
            String getDocumentsStateRsXML = null;
            try {
                getDocumentsStateRsXML = esbGate.sendPayMessageWithAnswer(DocumentsStateInqXML);
            } catch (IOException e) {
                e.printStackTrace();
            }
            log.info("Received XML message getDocumentsStateRsXML from ESB: " + getDocumentsStateRsXML);

            TransferOperations rs = xmlUnmarshaler.parse(TransferOperations.class, getDocumentsStateRsXML);
            if (rs != null && rs.getBankSvcRs() != null && rs.getBankSvcRs().getGetDocumentsState() != null) {
                GetDocumentsStateResponse getDocumentsStateRs = rs.getBankSvcRs().getGetDocumentsState();
                List<TransferResponse> transferResponseList = getDocumentsStateRs.getDocumentStateInfoList().getDocumentStateInfo();
                log.info("TransferResponseList received");

                transferResponseList.stream()
                        .filter(transferResponse -> !"PROCESSING".equals(transferResponse.getStatus().value()))
                        .forEach(transferResponse -> {
                            String newStatus = transferResponse.getStatus().value();
                            Transfer transfer = getTransfer(trnList, transferResponse.getDocExtId());
                            if (transfer != null) {
                                transfer.setState(newStatus);
                                transferRepository.save(transfer);
                                if ("PROCESSED".equals(newStatus)) { // Если новый статус операции PROCESSED
                                    try {
                                        // для соответствующей записи вызывается сервис пуш уведомлений /communication-gateway для отправки нотификации клиенту
                                        String answer = notifGate.execute(jsonBuilder.getUserNotificationJson(transfer));

                                        // в таблицу notification добавляется запись об отправке уведомления
                                        Notification notification = new Notification();
                                        notification.setDocExtId(transfer.getDocExtId());
                                        notification.setPhone(formatPhone(transfer.getRcvPhone()));
                                        notification.setNotifDate(LocalDateTime.now());
                                        // add fields for notification

                                        if (StringUtils.isEmpty(answer) || answer.contains("error")) {
                                            // Если ответ от communication-gateway возвращает http code 200, обновляем запись в таблице notification на SUCCESS
                                            notification.setStatus("ERROR");
                                        } else {
                                            //, в остальных случаях меняем статус на ERROR
                                            notification.setStatus("SUCCESS");
                                        }
                                        // и записываем в столбец statusdesc ответ сервиса нотификаций
                                        notification.setStatusDesc(answer);
                                        notificationRepository.save(notification);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        });
            }
        }
    }

    private Transfer getTransfer(List<Transfer> trnList, String docExtId){
        Transfer trn = null;
        for(Transfer tranfer : trnList){
            if (docExtId.equals(tranfer.getDocExtId())) {
                trn = tranfer;
                break;
            }
        }
        return trn;

    }
}
