package ru.mtsbank.integration.dbo.transfers.schedule.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Data
public class CustomConfig {

    @JsonProperty("app")
    private App app;
    @JsonProperty("spring")
    private Spring spring;

    @Data
    public static class App {
        @JsonProperty("batch")
        private int batch;
        @JsonProperty("cron")
        private String cron;
    }

    @Data
    public static class Spring {
        @JsonProperty("datasource")
        private Datasource datasource;
        @Data
        public static class Datasource {
            @JsonProperty("driver-class-name")
            private String driverclassname;
            @JsonProperty("password")
            private String password;
            @JsonProperty("url")
            private String url;
            @JsonProperty("username")
            private String username;
        }
    }
}
