package ru.mtsbank.integration.dbo.transfers.schedule.quartz;

import lombok.extern.slf4j.Slf4j;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.transfers.schedule.service.impl.GetDocumentState;

@Slf4j
@Component
@DisallowConcurrentExecution
public class GetDocumentStateJob implements Job {

    @Autowired
    private GetDocumentState getDocumentState;

    @Override
    public void execute(JobExecutionContext context) {
        log.info("Job ** {} ** starting @ {}", context.getJobDetail().getKey().getName(), context.getFireTime());
        getDocumentState.getDocumentState();
        log.info("Job ** {} ** completed.  Next job scheduled @ {}", context.getJobDetail().getKey().getName(), context.getNextFireTime());
    }

}
