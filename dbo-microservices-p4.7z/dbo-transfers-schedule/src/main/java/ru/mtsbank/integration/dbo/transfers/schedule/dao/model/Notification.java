package ru.mtsbank.integration.dbo.transfers.schedule.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Table(name = "NOTIFICATION")
@Getter @Setter
public class Notification implements Serializable {

    private static final long serialVersionUID = -6117320102043250239L;

    @Id
    @Column(name = "NOTIFID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // BIGINT bigint	8 байт	целое в большом диапазоне	-9223372036854775808 .. 9223372036854775807
    @Column(name="NOTIFDATE")
    private LocalDateTime notifDate; // TIMESTAMP timestamp [ (p) ] [ without time zone ]	8 байт	дата и время (без часового пояса)
    @Column(name="PHONE")
    private String phone; // VARCHAR(50)
    @Column(name="DOCEXTID")
    private String docExtId; // BIGINT
    @Column(name="STATUS")
    private String status; // VARCHAR(50)
    @Column(name="STATUSDESC")
    private String statusDesc; // TEXT строка неограниченной переменной длины

}
