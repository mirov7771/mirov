package ru.mtsbank.integration.dbo.transfers.schedule.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.model.Notification;

@Repository
public interface NotificationRepository extends CrudRepository<Notification, String> {

}
