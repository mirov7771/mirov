package ru.mtsbank.integration.dbo.transfers.schedule.quartz;

import org.quartz.JobDetail;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import ru.mtsbank.integration.dbo.transfers.schedule.config.CustomConfig;
import ru.mtsbank.integration.dbo.transfers.schedule.config.QuartzConfig;

@Configuration
@DependsOn("getCustomConfig")
public class QuartzSubmitJobs {

    @Bean(name = "getDocumentStateJobDetail")
    public JobDetailFactoryBean jobGetDocumentState() {
        return QuartzConfig.createJobDetail(GetDocumentStateJob.class, "Class getDocumentStateJob Job");
    }

    @Bean(name = "getDocumentStateJobTrigger")
    public CronTriggerFactoryBean triggerGetDocumentState(@Qualifier("getDocumentStateJobDetail") JobDetail jobDetail, CustomConfig customConfig) {
        return QuartzConfig.createCronTrigger(jobDetail, customConfig.getApp().getCron() , "Class getDocumentStateJob Trigger");
    }
}
