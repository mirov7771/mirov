package ru.mtsbank.integration.dbo.transfers.schedule.dao;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.model.Transfer;

import java.util.List;

@Repository
public interface TransferRepository extends CrudRepository<Transfer, String> {

    Transfer findByDocExtId(String docExtId);
    List<Transfer> findByState(String state, Pageable pageable);

}
