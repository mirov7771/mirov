package ru.mtsbank.integration.dbo.transfers.schedule.builders;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.transfers.schedule.dao.model.Transfer;
import java.time.LocalDateTime;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.*;

@Component("jsonbuilder")
@Slf4j
public class JsonBuilder {

    public String getUserNotificationJson (Transfer transfer) throws JsonProcessingException {
        log.info("Starting getUserNotificationJson method");

        ObjectMapper mapper = new ObjectMapper();
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        // Prepare UserNotification object

        UserNotificationMessage userNotificationMessage = new UserNotificationMessage();
        UserNotificationMessage.UserNotification userNotification = new UserNotificationMessage.UserNotification();
        UserNotificationMessage.UserNotification.Placeholders placeholders = new UserNotificationMessage.UserNotification.Placeholders();

        // Filling in Placeholders content

        placeholders.setSMSFrom("MTS.dengi"); // "MTS.dengi"
        // Изменить формат представления даты
        placeholders.setDateTime(getLocalDateTimeAsStringDotted(LocalDateTime.now())); // "01.10 12:30" значение в формате DD.MM HH:MM (дата и время получения ответа на вызов /getdocumentsState)
        placeholders.setAmount(transfer.getAmount().toString()); // "100.00" amount из БД t.transfer (sum из вызова preprocessInternalTransfer)
        placeholders.setAmountCur("руб."); // "руб."  «руб.» для depositCurrencyISOCode = 643 из вызова preprocessInternalTransfer
        placeholders.setSender(transfer.getSenderName()); // // "Варфоломей Абдурахманович А." «Имя Отчество Ф.» отправителя senderName из БД t.transfer
        placeholders.setUserMessage(transfer.getPurpose()); // purpose из БД t.transfer (значение из userMessage вызова POST /checkTransfer)

        // Filling in UserNotification content
        String requestId = UUID.randomUUID().toString();
        userNotification.setRgUid(requestId); // уникальный идентификатор запроса (генерируется при вызове)
        userNotification.setTemplateId("7"); // "7"
        userNotification.setPhone(formatPhone(transfer.getRcvPhone())); // значение в формате 7NNNNNNNNNN,rcvphone из БД t.transfer +79185557739
        userNotification.setTypeId("7");

        userNotification.setPlaceholders(placeholders);

        userNotificationMessage.setUserNotification(userNotification);

        log.info("Ended DocumentsStateInqXML method");

        // convert to json
        return mapper.writeValueAsString(userNotificationMessage);
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private static class UserNotificationMessage {


        @JsonProperty("userNotification")
        private UserNotification userNotification;

        @Data
        private static class UserNotification {

            @JsonProperty("RqUID")
            private String rgUid; // уникальный идентификатор запроса (генерируется при вызове)
            @JsonProperty("templateId")
            private String templateId; // "7"
            @JsonProperty("phone")
            private String phone; //значение в формате 7NNNNNNNNNN,rcvphone из БД t.transfer
            @JsonProperty("typeIdp")
            private String typeId; //  "7"
            @JsonProperty("placeholders")
            private Placeholders placeholders;

            @Data
            private static class Placeholders {
                @JsonProperty("SMSFrom")
                private String SMSFrom; // "MTS.dengi"
                @JsonProperty("dateTime")
                private String dateTime; // "01.10 12:30" значение в формате DD.MM HH:MM (дата и время получения ответа на вызов /getdocumentsState)
                @JsonProperty("amount")
                private String amount; // "100.00" amount из БД t.transfer (sum из вызова preprocessInternalTransfer)
                @JsonProperty("amountCur")
                private String amountCur; // "руб."  «руб.» для depositCurrencyISOCode = 643 из вызова preprocessInternalTransfer
                @JsonProperty("sender")
                private String sender; // "Варфоломей Абдурахманович А." «Имя Отчество Ф.» отправителя
                @JsonProperty("userMessage")
                private String userMessage; // purpose из БД t.transfer (значение из userMessage вызова POST /checkTransfer)
            }
        }
    }
}