package ru.mtsbank.integration.dbo.transfers.schedule.service;

import java.io.IOException;

public interface MtsScheduler {
    void getDocumentState() throws IOException;
}
