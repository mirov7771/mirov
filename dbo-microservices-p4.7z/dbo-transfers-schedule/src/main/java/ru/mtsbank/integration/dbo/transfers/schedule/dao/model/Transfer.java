package ru.mtsbank.integration.dbo.transfers.schedule.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "TRANSFER")
@Getter @Setter
public class Transfer {

    @Id
    @Column(name = "TRANSFERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transferId;
    @Column(name = "DOCNUMBER")
    private String docNumber;
    @Column(name = "DOCUMENTID")
    private String documentId;
    @Column(name = "TRNDATE")
    private Date trnDate;
    @Column(name = "CLIENTEXTID")
    private Long clientExtId;
    @Column(name = "SRCTYPE")
    private String srcType;
    @Column(name = "SRCID")
    private String srcId;
    @Column(name = "CARDEXPIRY")
    private Date cardExpiry;
    @Column(name = "AMOUNT")
    private BigDecimal amount;
    @Column(name = "RCVNAME")
    private String rcvName;
    @Column(name = "RCVTYPE")
    private String rcvType;
    @Column(name = "RCVID")
    private String rcvId;
    @Column(name = "PURPOSE")
    private String purpose;
    @Column(name = "RCVPHONE")
    private String rcvPhone;
    @Column(name = "DOCEXTID")
    private String docExtId;
    @Column(name = "FEEAMT")
    private BigDecimal feeAmt;
    @Column(name = "TOTALAMT")
    private BigDecimal totalAmt;
    @Column(name = "SENDERNAME")
    private String senderName;
    @Column(name = "STATE")
    private String state;

}

