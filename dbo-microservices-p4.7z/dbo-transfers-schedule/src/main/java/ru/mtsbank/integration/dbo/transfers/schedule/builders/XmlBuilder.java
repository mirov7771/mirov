package ru.mtsbank.integration.dbo.transfers.schedule.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.*;

import java.util.*;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@Component("xmlbuilder")
@Slf4j
public class XmlBuilder {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    public String DocumentsStateInqXML(List<String> listDocExtId) {
        log.info("Starting DocumentsStateInqXML method");
        // Prepare DocumentsStateRq request to ESB

        TransferOperations documentsStateRq = new TransferOperations();
        ServerInfo serverInfo = new ServerInfo();

        ExternalSystemRequest bankSvc = new ExternalSystemRequest();
        GetDocumentsStateRequest getDocumentsState = new GetDocumentsStateRequest();
        StateRequestDocumentList stateRequestDocumentList = new StateRequestDocumentList();

        // Filling in ServerInfo content
        String requestId = UUID.randomUUID().toString();
        serverInfo.setMsgUID(requestId);
        serverInfo.setRqUID(requestId);
        serverInfo.setSPName("MTS_EIP_UMP");
        serverInfo.setMsgReceiver("PHUB");
        serverInfo.setServerDt(getXmlGregorianCalendar(new Date()));
        serverInfo.setMsgType(SimpleMsgTypeType.GET_DOCUMENTS_STATE);

        // Filling in BankSvcRq content
        List<StateRequestDocument> document = new ArrayList<>();
        for (String docExtId: listDocExtId) {
            StateRequestDocument stateRequestDocument = new StateRequestDocument();
            stateRequestDocument.setDocExtId(docExtId);
            document.add(stateRequestDocument);
        }

//        document.stream().map(StateRequestDocument::getDocExtId).forEach(System.out::println);

        stateRequestDocumentList.getDocument().addAll(document);
        getDocumentsState.setDocumentList(stateRequestDocumentList);
        bankSvc.setGetDocumentsState(getDocumentsState);

        // Filling in BankSvcRq content
        documentsStateRq.setBankSvcRq(bankSvc);
        documentsStateRq.setServerInfo(serverInfo);

        // Unmarshalling documentsStateRq
        log.info("Ended DocumentsStateInqXML method");
        return xmlUnmarshaler.createXml(documentsStateRq);
    }

}