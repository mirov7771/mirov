create table SMSTEXT
(
 TEXTID BIGINT GENERATED ALWAYS AS IDENTITY
,TYPE VARCHAR(50)
,TEXTMESSAGE VARCHAR(255)
,SMSSIZE NUMERIC(20) DEFAULT 4
);

create table SMSCODE
(
 CODEID BIGINT GENERATED ALWAYS AS IDENTITY
,ID VARCHAR(150)
,CODE VARCHAR(50)
,TYPE VARCHAR(50)
,EXPIRYDATE TIMESTAMP
);

create table SMSHISTORY
(
 SMSID BIGINT GENERATED ALWAYS AS IDENTITY
,RBOID VARCHAR(150)
,SENDDATE TIMESTAMP
)

create index X1_SMSTEXT on SMSTEXT(TYPE);
create index X1_SMSCODE on SMSCODE(RBOID,TYPE);

insert into SMSTEXT(TYPE,TEXTMESSAGE,SMSSIZE) values('earlyrepayment','Код %CODE% для досрочного погашения кредита',4);
insert into SMSTEXT(TYPE,TEXTMESSAGE,SMSSIZE) values('earlyrepaymentcancel','Код %CODE% для отмены заявки на досрочное погашения кредита',4);
insert into SMSTEXT(TYPE,TEXTMESSAGE,SMSSIZE) values('himself','Введите код %CODE% для подтверждения заявки на сайте МТС Банка',4);
insert into SMSTEXT(TYPE,TEXTMESSAGE) values('sbptransferout', '%date% Успешный перевод %amount% руб. со счета %account% через Систему быстрых платежей. Получатель: %receiver%, %bank%');
insert into SMSTEXT(TYPE,TEXTMESSAGE) values('sbptransferin', '%date% Поступил перевод %amount% руб. на счет %account% через Систему быстрых платежей. Отправитель: %receiver%, %bank%. Комментарий: %comment%.');
insert into SMSTEXT(TYPE,TEXTMESSAGE,SMSSIZE) values('createDebetCard','Код %CODE% для продолжения открытия карты',4);
insert into SMSTEXT(TYPE,TEXTMESSAGE,SMSSIZE) values('closecard','Код %CODE% для закрытия карты',4);
insert into SMSTEXT(TYPE,TEXTMESSAGE,SMSSIZE) values('transferInnerClient','Код %CODE% переводу клиенту МТС Банка',4);

------------------////////////////////////////-----------------------------
drop table SMSCODE;
create table SMSCODE
(
 CODEID BIGINT GENERATED ALWAYS AS IDENTITY
,ID VARCHAR(150)
,CODE VARCHAR(50)
,TYPE VARCHAR(50)
,EXPIRYDATE TIMESTAMP
);
create index X1_SMSCODE on SMSCODE(ID,TYPE);