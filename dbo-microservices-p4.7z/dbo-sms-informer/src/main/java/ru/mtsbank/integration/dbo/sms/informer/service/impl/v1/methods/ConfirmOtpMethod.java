package ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.sms.informer.builders.OtpTokenBuilder;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.ConfirmOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.ConfirmOtpRes;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsCode;
import ru.mtsbank.integration.dbo.sms.informer.dao.SmsCodeRepository;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.isEmpty;

@Component
@Slf4j
public class ConfirmOtpMethod {

    @Autowired
    private SmsCodeRepository smsCodeRepository;

    @Autowired
    private OtpTokenBuilder otpTokenBuilder;

    public ConfirmOtpRes call(ConfirmOtpReq req){
        String uid = UUID.randomUUID().toString();
        log.info("{} Start confirm service with params {}", uid, req.toString());
        ConfirmOtpRes res = new ConfirmOtpRes();
        String smsType = StringUtils.isEmpty(req.getType()) ? "default" : req.getType();
        List<SmsCode> smsCodeList = smsCodeRepository.findByIdAndType(req.getRboID() != null ? req.getRboID().toString() : req.getPhoneNumber(), smsType);
        Date curDate = new Date();
        if (isEmpty(smsCodeList)){
            res.createError(1000, "Введенный пользователем код неверный",406, null, null, "confirmotp", null);
        } else {
            String code = req.getCode();
            boolean notConfirmed = true;
            String message = "Введенный пользователем код неверный";
            int errorCode = 1000;
            for(SmsCode item : smsCodeList){
                String smsCode = item.getCode();
                Date expiryDate = item.getExpiryDate();
                if (smsCode.equals(code) && curDate.compareTo(expiryDate) < 0){
                    notConfirmed = false;
                    smsCodeRepository.delete(item);
                    break;
                } else if (!(curDate.compareTo(expiryDate) < 0)){
                    smsCodeRepository.delete(item);
                    errorCode = 1006;
                    message = "Срок действия одноразового кода истек";
                    break;
                }
            }
            if (Boolean.TRUE.equals(notConfirmed)){
                res.createError(errorCode, message,406, null, null, "confirmotp", uid);
            } else {
                if (req.getRboID() != null) {
                    res.setOtpToken(otpTokenBuilder.getToken(req.getType(), req.getRboID()));
                }
            }
        }
        log.info("{} End confirm service",uid);
        return res;
    }
}
