package ru.mtsbank.integration.dbo.sms.informer.service.impl.v1;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.CheckTokenReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.ConfirmOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.NotifyReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.SendOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.CheckTokenRes;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.ConfirmOtpRes;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.NotifyRes;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.SendOtpRes;
import ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods.CheckTokenMethod;
import ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods.ConfirmOtpMethod;
import ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods.NotifyMethod;
import ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods.SendOtpMethod;
import ru.mtsbank.integration.dbo.sms.informer.service.Service;

@Component("v1")
public class ServiceV1Impl implements Service {

    private final CheckTokenMethod checkTokenMethod;
    private final ConfirmOtpMethod confirmOtpMethod;
    private final NotifyMethod notifyMethod;
    private final SendOtpMethod sendOtpMethod;

    public ServiceV1Impl(CheckTokenMethod checkTokenMethod
            , ConfirmOtpMethod confirmOtpMethod
            , NotifyMethod notifyMethod
            , SendOtpMethod sendOtpMethod)
    {
        this.checkTokenMethod = checkTokenMethod;
        this.confirmOtpMethod = confirmOtpMethod;
        this.notifyMethod = notifyMethod;
        this.sendOtpMethod = sendOtpMethod;
    }

    @Override
    public CheckTokenRes checkToken(CheckTokenReq req) {
        return checkTokenMethod.call(req);
    }

    @Override
    public ConfirmOtpRes confirmOtp(ConfirmOtpReq req) {
        return confirmOtpMethod.call(req);
    }

    @Override
    public NotifyRes notify(NotifyReq req) {
        return notifyMethod.call(req);
    }

    @Override
    public SendOtpRes sendOtp(SendOtpReq req) {
        return sendOtpMethod.call(req);
    }

}
