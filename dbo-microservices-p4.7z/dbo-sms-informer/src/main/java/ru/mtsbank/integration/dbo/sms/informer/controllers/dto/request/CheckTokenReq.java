package ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;

@Getter
@ToString
public class CheckTokenReq extends BaseRequest {

    @JsonProperty("type")
    @NotNull
    private String type;
    @JsonProperty("otpToken")
    @NotNull
    private String otpToken;

}
