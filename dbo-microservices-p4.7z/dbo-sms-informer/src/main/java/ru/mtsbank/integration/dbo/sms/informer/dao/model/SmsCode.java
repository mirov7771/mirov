package ru.mtsbank.integration.dbo.sms.informer.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "SMSCODE")
@Getter @Setter
public class SmsCode implements Serializable {

    private static final long serialVersionUID = 5749946280068590322L;

    @Id
    @Column(name = "CODEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codeId;
    @Column(name = "ID")
    private String id;
    @Column(name = "CODE")
    private String code;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "EXPIRYDATE")
    private Date expiryDate;

}
