package ru.mtsbank.integration.dbo.sms.informer.service;

import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.CheckTokenReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.ConfirmOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.NotifyReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.SendOtpReq;

public interface Service {

    BaseResponse checkToken(CheckTokenReq req);
    BaseResponse confirmOtp(ConfirmOtpReq req);
    BaseResponse notify(NotifyReq req);
    BaseResponse sendOtp(SendOtpReq req);

}
