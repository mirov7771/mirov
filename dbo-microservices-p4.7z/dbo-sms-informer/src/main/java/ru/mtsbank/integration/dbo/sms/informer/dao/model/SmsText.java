package ru.mtsbank.integration.dbo.sms.informer.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SMSTEXT")
@Getter @Setter
public class SmsText implements Serializable {

    private static final long serialVersionUID = 8106684638608731695L;

    @Id
    @Column(name = "TEXTID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long textId;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "TEXTMESSAGE")
    private String textMessage;
    @Column(name = "SMSSIZE")
    private Integer smsSize;

}
