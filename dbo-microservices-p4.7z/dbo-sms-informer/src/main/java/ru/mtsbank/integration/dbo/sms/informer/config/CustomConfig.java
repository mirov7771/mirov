package ru.mtsbank.integration.dbo.sms.informer.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomConfig {

    @JsonProperty("app")
    private App app;

    @Data
    public static class App {
        @JsonProperty("forTest")
        private String forTest;
        @JsonProperty("pintime")
        private String pintime;
    }

}

