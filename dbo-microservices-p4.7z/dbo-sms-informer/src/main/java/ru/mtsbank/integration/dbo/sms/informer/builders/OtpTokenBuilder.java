package ru.mtsbank.integration.dbo.sms.informer.builders;

import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Component
@Slf4j
public class OtpTokenBuilder {

    public String getToken(String type, Long rboId){
        JsonObject param = new JsonObject();
        param.addProperty("type", type);
        if (rboId != null)
            param.addProperty("rboId", rboId);
        String token = Base64.getEncoder().encodeToString(param.toString().trim().getBytes());
        log.info("token for sms is "+token);
        return token;
    }

}
