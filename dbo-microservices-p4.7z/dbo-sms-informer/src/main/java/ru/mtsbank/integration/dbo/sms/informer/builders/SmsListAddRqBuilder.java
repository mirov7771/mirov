package ru.mtsbank.integration.dbo.sms.informer.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.diasoft.integration.mts.xsd.DBOCust.smslistaddrq.*;
import ru.diasoft.integration.mts.xsd.DBOCust.smslistaddrs.SMSListAddRs;
import ru.mts.dbo.constants.MTSConstants;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.MtsException;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.CustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FDXPhoneNum;

import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@Component
@Slf4j
public class SmsListAddRqBuilder {

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    public int createSMSListAddRq(String smsMessage, String phone, Long rboId, String uid) throws MtsException {
        log.info("start sending message "+smsMessage);
        try {
            XMLGregorianCalendar curDate = Utils.getXmlGregorianCalendar(new Date());

            SMSListAddRq rq = new SMSListAddRq();
            BankSvcRq bankSvcRq = new BankSvcRq();
            bankSvcRq.setInstantSend(true);
            bankSvcRq.setEffDt(curDate);
            SMSList smsList = new SMSList();
            SMSRec smsRec = new SMSRec();
            String phoneNumber = formatPhone(phone);
            if (phoneNumber == null || phoneNumber.equals(""))
                phoneNumber = getPhoneNumber(rboId.toString(), uid);
            smsRec.setPhone(phoneNumber);
            smsRec.setSMSText(smsMessage);
            if (!StringUtils.isEmpty(smsMessage))
                smsRec.setSMSTextMask(smsMessage.replaceAll("[0-9]", "*"));
            smsRec.setSMSFrom("MTS-Bank");
            smsList.getSMSRec().add(smsRec);
            bankSvcRq.setSMSList(smsList);

            rq.setBankSvcRq(bankSvcRq);
            ServerInfoCType serverInfoType = new ServerInfoCType();
            serverInfoType.setMsgType("SMSListAddRq");
            serverInfoType.setSPName(MTSConstants.UMP);
            serverInfoType.setMsgReceiver(MTSConstants.ESB);
            serverInfoType.setServerDt(curDate);

            serverInfoType.setMsgUID(uid);
            serverInfoType.setRqUID(uid);
            serverInfoType.setBpId(uid);
            rq.setServerInfo(serverInfoType);

            String messageXml = xmlUnmarshaler.createXml(rq);
            log.info("Send message to mq: " + messageXml);
            String answerXml = esbGate.sendInfoMessageWithAnswer(messageXml);
            SMSListAddRs rs = xmlUnmarshaler.parse(SMSListAddRs.class, answerXml);
            if (rs == null || rs.getBankSvcRs() == null || rs.getBankSvcRs().getStatus() == null)
                return 1;
            String statusCode = rs.getBankSvcRs().getStatus().getStatusCode();
            if (!statusCode.equals("0"))
                return 1;
            return 0;
        } catch (IOException e){
            log.error("Error: "+e);
            e.printStackTrace();
            return 1;
        }
    }

    private String getPhoneNumber(String custId, String uid) throws MtsException, IOException {
        String phoneNumber = null;
        String custSearchXml = xmlUnmarshaler.createXml(custSearchInqRqBuilder.createCustSearchInqRq(custId, uid));
        String custSearchAnswerXml = esbGate.sendSalesMessageWithAnswer(custSearchXml);
        CustSearchInqRs custSearchInqRs = xmlUnmarshaler.parse(CustSearchInqRs.class, custSearchAnswerXml);
        if (custSearchInqRs != null
                && custSearchInqRs.getBankSvcRs() != null
                && custSearchInqRs.getBankSvcRs().getCustInfo() != null
                && custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo() != null
                && custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getContactInfo() != null
                && !CollectionUtils.isEmpty(custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getContactInfo().getPhoneNum()))
        {
            List<FDXPhoneNum> phoneNumsList = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getContactInfo().getPhoneNum();
            if (phoneNumsList != null && phoneNumsList.size() > 0) {
                for (ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FDXPhoneNum fdxPhoneNum : phoneNumsList) {
                    if (fdxPhoneNum.isPrimary()
                            && fdxPhoneNum.getPhoneType().equals("Mobile")){
                        phoneNumber = fdxPhoneNum.getPhone();
                        break;
                    }
                }
            }
        }
        if (phoneNumber == null || phoneNumber.equalsIgnoreCase(""))
            throw new MtsException(MTSConstants.RETURN_MESSAGE_TECHNICAL_ERROR, 1);
        return phoneNumber;
    }

    private String formatPhone(String phone){
        String retPhone = phone;
        if (!StringUtils.isEmpty(retPhone)){
            if (retPhone.length() == 10)
                retPhone =  "+7"+retPhone;
            else if (retPhone.startsWith("7") && retPhone.length() == 11)
                retPhone =  "+"+retPhone;
            else if (retPhone.startsWith("8") && retPhone.length() == 11)
                retPhone = "+7"+phone.substring(1,11);
            else
                retPhone = phone;
        }
        return retPhone;
    }

}
