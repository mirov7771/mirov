package ru.mtsbank.integration.dbo.sms.informer.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.CheckTokenReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.ConfirmOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.NotifyReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.SendOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.*;
import ru.mtsbank.integration.dbo.sms.informer.service.Service;

import javax.validation.Valid;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Tag(name = "SmsInformer")
@RestController
@RequestMapping("dbo-sms-informer")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/checkToken", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "Проверка операции после подтверждения, что валидация кода из смс прошла успешно."
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CheckTokenRes.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> checkToken(@PathVariable final String version
                                                  ,@Valid @RequestBody CheckTokenReq req)
    {
        return ResponseBuilder.build(services.get(version).checkToken(req));
    }

    @PostMapping(value = "{version}/confirmOtp", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "метод проверяет код, введенный пользователем"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ConfirmOtpRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> confirmOtp(@PathVariable final String version
                                                  ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                  ,@RequestHeader(value = "authorization", required = false) String authorization
                                                  ,@Valid @RequestBody ConfirmOtpReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).confirmOtp(req));
    }

    @PostMapping(value = "{version}/notify", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "отправка нотификаций по СМС"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = NotifyRes.class))
            }),
            @ApiResponse(responseCode = "424", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> notify(@PathVariable final String version
                                              ,@Valid @RequestBody NotifyReq req)
    {
        return ResponseBuilder.build(services.get(version).notify(req));
    }

    @PostMapping(value = "{version}/sendOtp", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "метод генерирует OTP код и отправляет СМС клиенту с кодом"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = SendOtpRes.class))
            }),
            @ApiResponse(responseCode = "424", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> sendOtp(@PathVariable final String version
                                               ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                               ,@RequestHeader(value = "authorization", required = false) String authorization
                                               ,@Valid @RequestBody SendOtpReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).sendOtp(req));
    }

}
