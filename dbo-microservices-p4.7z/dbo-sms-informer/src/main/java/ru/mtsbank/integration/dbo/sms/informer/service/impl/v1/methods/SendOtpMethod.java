package ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.constants.MTSConstants;
import ru.mts.dbo.utils.MtsException;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.sms.informer.builders.SmsListAddRqBuilder;
import ru.mtsbank.integration.dbo.sms.informer.config.CustomConfig;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.SendOtpReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.SendOtpRes;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsCode;
import ru.mtsbank.integration.dbo.sms.informer.dao.SmsCodeRepository;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsText;
import ru.mtsbank.integration.dbo.sms.informer.dao.SmsTextRepository;

import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.isEmpty;

@Component
@Slf4j
public class SendOtpMethod {

    @Autowired
    private SmsTextRepository smsTextRepository;

    @Autowired
    private SmsCodeRepository smsCodeRepository;

    @Autowired
    private SmsListAddRqBuilder smsListAddRqBuilder;

    private static CustomConfig.App app;

    public SendOtpMethod(CustomConfig config) {
        app = config.getApp();
    }

    public SendOtpRes call(SendOtpReq req){
        String uid = UUID.randomUUID().toString();
        log.info("{} Start create service",uid);
        SendOtpRes res = new SendOtpRes();
        try {
            String smsType = StringUtils.isEmpty(req.getType()) ? "default" : req.getType();
            List<SmsCode> smsCodeList = smsCodeRepository.findByIdAndType(req.getRboID() != null ? req.getRboID().toString() : req.getPhoneNumber(), smsType);
            if (!isEmpty(smsCodeList))
                smsCodeRepository.deleteAll(smsCodeList);

            SmsText smsText = smsTextRepository.findByType(smsType);
            String smsMessage;
            Integer smsSize;
            if (smsText == null) {
                smsMessage = MTSConstants.DEFAULT_MESSAGE;
                smsSize = 4;
            } else {
                smsMessage = smsText.getTextMessage();
                smsSize = smsText.getSmsSize();
            }

            Boolean forTest = Boolean.valueOf(app.getForTest());
            String code = createCode(smsSize, forTest);

            smsMessage = smsMessage.replace("%CODE%", code);
            int sendResult = smsListAddRqBuilder.createSMSListAddRq(smsMessage, req.getPhoneNumber(), req.getRboID(), uid);
            if (sendResult == 1) {
                res.createError(1001, "Отправка смс невозможна по техническим причинам", 424, null, null, "sendotp", uid);
            } else {
                Date cDate = new Date();
                long pinTime = Long.parseLong(app.getPintime());
                cDate.setTime(cDate.getTime() + pinTime);
                res.setLength(smsSize);
                int lifetime = Integer.parseInt(app.getPintime());
                res.setLifeTime(lifetime / 1000);
                res.setRequestId(uid);
                SmsCode smsCode = new SmsCode();
                smsCode.setCode(code);
                smsCode.setId(req.getRboID() != null ? req.getRboID().toString() : req.getPhoneNumber());
                smsCode.setType(smsType);
                smsCode.setExpiryDate(cDate);
                smsCodeRepository.save(smsCode);
            }
        } catch (MtsException e){
            log.error("{} Error in send otp method: {}", uid, Utils.getStackError(e));
            res.createError(1001, "Отправка смс невозможна по техническим причинам", 424, null, null, "sendotp", uid);
        }
        log.info("{} End create service", uid);
        return res;
    }

    private String createCode(Integer s, Boolean isForTest){
        Random rand = new Random();
        StringBuilder pin = new StringBuilder();
        for(int i=0;i<s;i++) {
            String s1;
            if (isForTest)
                s1 = "1";
            else
                s1 = rand.nextInt(10) + "";
            pin.append(s1, 0, 1);
        }
        return pin.toString();
    }

}
