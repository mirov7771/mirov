package ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;

@Getter
@ToString
public class ConfirmOtpReq extends BaseRequest {

    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("type")
    private String type;
    @JsonProperty("code")
    @NotNull
    private String code;

}
