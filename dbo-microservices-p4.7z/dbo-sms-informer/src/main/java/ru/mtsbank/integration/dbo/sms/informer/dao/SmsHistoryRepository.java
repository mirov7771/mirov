package ru.mtsbank.integration.dbo.sms.informer.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsHistory;

@Repository
public interface SmsHistoryRepository extends CrudRepository<SmsHistory, String> {

}
