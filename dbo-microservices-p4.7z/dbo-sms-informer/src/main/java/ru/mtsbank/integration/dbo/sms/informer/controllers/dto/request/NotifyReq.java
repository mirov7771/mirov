package ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;

import java.util.Map;

@Getter
@ToString
public class NotifyReq extends BaseRequest {

    @JsonProperty("phoneNumber")
    private String phoneNumber;
    @JsonProperty("type")
    private String type;
    @JsonProperty("params")
    private Map<String, String> params;

}
