package ru.mtsbank.integration.dbo.sms.informer.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsText;

@Repository
public interface SmsTextRepository extends CrudRepository<SmsText, String> {

    SmsText findByType(String type);

}
