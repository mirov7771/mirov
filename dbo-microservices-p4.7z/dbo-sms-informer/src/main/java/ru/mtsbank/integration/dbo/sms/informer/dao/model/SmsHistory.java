package ru.mtsbank.integration.dbo.sms.informer.dao.model;

import lombok.Getter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "SMSHISTORY")
@Getter
public class SmsHistory {

    @Id
    @Column(name = "SMSID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long smsId;
    @Column(name = "RBOID")
    private String rboId;
    @Column(name = "SENDDATE")
    private Date sendDate;

    public static class Builder{
        private String rboId;
        private Date sendDate;

        public Builder setRboId(String rboId){
            this.rboId = rboId;
            return this;
        }

        public Builder setSendDate(Date sendDate){
            this.sendDate = sendDate;
            return this;
        }

        public SmsHistory build(){
            return new SmsHistory(this);
        }
    }

    private SmsHistory(){

    }

    private SmsHistory(Builder builder){
        this.rboId = builder.rboId;
        this.sendDate = builder.sendDate;
    }

}
