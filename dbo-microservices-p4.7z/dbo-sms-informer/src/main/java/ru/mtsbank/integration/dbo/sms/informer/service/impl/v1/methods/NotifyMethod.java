package ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.utils.MtsException;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.sms.informer.builders.SmsListAddRqBuilder;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.NotifyReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.NotifyRes;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsHistory;
import ru.mtsbank.integration.dbo.sms.informer.dao.SmsHistoryRepository;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsText;
import ru.mtsbank.integration.dbo.sms.informer.dao.SmsTextRepository;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Component
@Slf4j
public class NotifyMethod {

    @Autowired
    private SmsTextRepository smsTextRepository;

    @Autowired
    private SmsListAddRqBuilder smsListAddRqBuilder;

    @Autowired
    private SmsHistoryRepository smsHistoryRepository;

    public NotifyRes call(NotifyReq req){
        String uid = UUID.randomUUID().toString();
        log.info("{} Start notify service with params {}", uid, req.toString());
        NotifyRes res = new NotifyRes();
        try {
            SmsText smsText = smsTextRepository.findByType(req.getType());
            String smsMessage = smsText.getTextMessage();
            log.info("{} Message text for {} is {}", uid, req.getType(), smsMessage);
            Map<String, String> params = req.getParams();
            log.info("Params is " + params);
            if (params != null && !params.isEmpty()) {
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    smsMessage = smsMessage.replace("%" + entry.getKey() + "%", entry.getValue());
                }
            }
            int sendResult = smsListAddRqBuilder.createSMSListAddRq(smsMessage, req.getPhoneNumber(), req.getRboID(), uid);
            if (sendResult == 1) {
                res.createError(1001, "Отправка смс невозможна по техническим причинам", 424, null, null, "notify", uid);
                res.setSuccess(false);
            } else {
                res.setSuccess(true);
                SmsHistory history = smsHistoryRepository.save(new SmsHistory.Builder()
                        .setRboId(req.getRboID() == null ? req.getPhoneNumber() : req.getRboID().toString())
                        .setSendDate(new Date())
                        .build());
                res.setSmsId(history.getSmsId());
                res.setSendDate(history.getSendDate());
                res.setRequestId(uid);
            }
        } catch (MtsException e){
            log.error("{} Error in notify method: {}",uid,Utils.getStackError(e));
            res.createError(1001, "Отправка смс невозможна по техническим причинам", 424, null, null, "notify", uid);
            res.setSuccess(false);
        }
        log.info("{} End notify service",uid);
        return res;
    }

}
