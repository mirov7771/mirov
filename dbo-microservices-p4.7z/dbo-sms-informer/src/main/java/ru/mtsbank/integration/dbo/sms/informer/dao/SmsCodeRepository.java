package ru.mtsbank.integration.dbo.sms.informer.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.sms.informer.dao.model.SmsCode;

import java.util.List;

@Repository
public interface SmsCodeRepository extends CrudRepository<SmsCode, String> {

    List<SmsCode> findByIdAndType(String id, String type);

}
