package ru.mtsbank.integration.dbo.sms.informer.service.impl.v1.methods;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.request.CheckTokenReq;
import ru.mtsbank.integration.dbo.sms.informer.controllers.dto.response.CheckTokenRes;

import java.io.IOException;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.nvl;

@Component
@Slf4j
public class CheckTokenMethod {

    private final ObjectMapper mapper = new ObjectMapper();

    public CheckTokenRes call(CheckTokenReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start checktoken service with params {}", uid, req.toString());
        CheckTokenRes res = new CheckTokenRes();
        try {
            String token = req.getOtpToken();
            if (StringUtils.isEmpty(token)){
                res.setSuccess(false);
            } else {
                Long rboId = nvl(req.getRboID(),0L);
                String type = req.getType();
                while (token.length()%4 != 0)
                {
                    token = token.substring(0, token.length() - 1);
                }
                String decodeToken = new String(Base64.getDecoder().decode(token));
                Map<String, Object> outputParams;
                outputParams = mapper.readValue(decodeToken, Map.class);
                String tokenType = (String) outputParams.get("type");
                Long tokenRboId = Utils.getLongValue(outputParams.get("rboId"));
                res.setSuccess(type.equalsIgnoreCase(tokenType) && rboId.equals(nvl(tokenRboId,0L)));
            }
        } catch (IOException | IllegalArgumentException e) {
            res.setSuccess(false);
            e.printStackTrace();
        }
        log.info("{} End checktoken service", uid);
        return res;
    }

}
