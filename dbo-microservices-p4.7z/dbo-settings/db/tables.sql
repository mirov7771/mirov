CREATE TABLE "platforms"
(
    "platform_id"   integer     NOT NULL,
    "platform_name" varchar(50) NOT NULL,
    CONSTRAINT "PK_Platform" PRIMARY KEY ("platform_id")
);



CREATE TABLE "versions"
(
    "version_id"   integer GENERATED ALWAYS AS IDENTITY NOT NULL,
    "platform_id"  integer                              NOT NULL,
    "version_code" varchar(200)                         NOT NULL,
    "created_date" timestamp with time zone             NOT NULL,
    "status"       varchar(50)                          NOT NULL,
    CONSTRAINT "PK_Versions" PRIMARY KEY ("version_id"),
    CONSTRAINT "UNIQUE_Versions" UNIQUE ("version_code", "platform_id"),
    CONSTRAINT "FK_56" FOREIGN KEY ("platform_id") REFERENCES "platforms" ("platform_id")
);

CREATE INDEX "fkIdx_56" ON "versions"
    (
     "platform_id"
        );



CREATE TABLE "toggles"
(
    "key"         varchar(200) NOT NULL,
    "toggle_name" varchar(200),
    "description" varchar(500),
    CONSTRAINT "PK_Toggles" PRIMARY KEY ("key")
);


CREATE TABLE "toggles_configurations"
(
    configuration_id integer GENERATED ALWAYS AS IDENTITY NOT NULL
        CONSTRAINT "PK_Configurations"
            PRIMARY KEY,
    version_id       integer                              NOT NULL,
    key              varchar(200)                         NOT NULL
        CONSTRAINT "FK_39"
            REFERENCES toggles,
    platform_id      integer                              NOT NULL,
    value            boolean                              NOT NULL,
    CONSTRAINT "UNIQUE_Configurations"
        UNIQUE (version_id, platform_id, key)
);

CREATE INDEX "fkIdx_36" ON "toggles_configurations"
    (
     "version_id",
     "platform_id"
        );

CREATE INDEX "fkIdx_39" ON "toggles_configurations"
    (
     "key"
        );

INSERT INTO platforms (platform_id, platform_name)
VALUES (1, 'IOS');
INSERT INTO platforms (platform_id, platform_name)
VALUES (2, 'ANDROID');

CREATE TABLE au_versions
(
    id           SERIAL       NOT NULL
        CONSTRAINT au_versions_pk
            PRIMARY KEY,
    user_login   varchar(200) NOT NULL,
    date         timestamp    NOT NULL,
    type         varchar(200) NOT NULL,
    version_id   integer      NOT NULL,
    platform_id  integer      NOT NULL,
    created_date timestamp    NOT NULL,
    status       varchar(50)  NOT NULL,
    version_code varchar(200) NOT NULL
);

CREATE UNIQUE INDEX au_versions_id_uindex
    on au_versions (id);


CREATE TABLE au_toggles
(
    id          SERIAL       NOT NULL
        constraint au_toggles_pk
            primary key,
    user_login  varchar(200) NOT NULL,
    date        date         NOT NULL,
    type        varchar(200) NOT NULL,
    key         varchar(200) NOT NULL,
    toggle_name varchar(200),
    description varchar(500)
);

CREATE TABLE au_toggles_configurations
(
    id               SERIAL       NOT NULL
        CONSTRAINT au_toggles_configurations_pk
            PRIMARY KEY,
    user_login       varchar(200) NOT NULL,
    date             timestamp    NOT NULL,
    type             varchar(200) NOT NULL,
    configuration_id integer      NOT NULL,
    version_id       integer      NOT NULL,
    key              varchar(200) NOT NULL,
    platform_id      integer      NOT NULL,
    value            boolean      NOT NULL
);

CREATE UNIQUE INDEX au_toggles_configurations_id_uindex
    ON au_toggles_configurations (id);



