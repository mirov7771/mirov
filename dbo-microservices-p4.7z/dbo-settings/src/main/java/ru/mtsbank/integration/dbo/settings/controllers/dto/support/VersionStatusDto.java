package ru.mtsbank.integration.dbo.settings.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;

public class VersionStatusDto {

    @JsonProperty("status")
    @Getter @Setter
    private VersionStatus versionStatus;


}
