package ru.mtsbank.integration.dbo.settings.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;

import javax.validation.constraints.NotNull;
import java.sql.Timestamp;
import java.util.Set;

@Getter @Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NewVersionRes extends BaseResponse{
    @JsonProperty("platform")
    @NotNull
    private PlatformName platformName;

    @JsonProperty("number")
    @NotNull
    private String number;

    @JsonProperty("status")
    @NotNull
    private VersionStatus versionStatus;

    @JsonProperty("createdDate")
    @NotNull
    private Timestamp createdDate;

    @JsonProperty("toggles")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private Set<ToggleDto> toggleDtoList;

}
