package ru.mtsbank.integration.dbo.settings.service;

import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;

import java.util.Set;

public interface TogglesService {

    void saveTogglesWithConfig(Version version, Set<ToggleDto> toggles);

    BaseResponse updateToggles(Version version, Set<ToggleDto> toggles);

    BaseResponse changeToggles(Version version, Set<ToggleDto> toggles);
}
