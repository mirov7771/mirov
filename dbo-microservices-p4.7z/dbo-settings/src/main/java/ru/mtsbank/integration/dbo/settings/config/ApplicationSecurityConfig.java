package ru.mtsbank.integration.dbo.settings.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import ru.mtsbank.integration.dbo.settings.controllers.exception.CustomAuthenticationFailureHandler;


@Configuration
@EnableWebSecurity
public class ApplicationSecurityConfig extends WebSecurityConfigurerAdapter {

    @Value("${spring.security.basic-authentication.adminLogin}")
    private String adminLogin;
    @Value("${spring.security.basic-authentication.adminPassword}")
    private String adminPassword;
    @Value("${spring.security.basic-authentication.ciLogin}")
    private String ciLogin;
    @Value("${spring.security.basic-authentication.ciPassword}")
    private String ciPassword;
    @Value("${spring.security.basic-authentication.operatorLogin}")
    private String operatorLogin;
    @Value("${spring.security.basic-authentication.operatorPassword}")
    private String operatorPassword;


    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.csrf().disable()
                .authorizeRequests()
                .antMatchers(HttpMethod.POST, "/dbo-settings/{version}/appVersions")
                .hasRole("CI")
                .antMatchers(HttpMethod.POST, "/dbo-settings/{version}/appVersions/{platform}/{number}/toggles")
                .hasAnyRole("CI", "OPER")
                .antMatchers(HttpMethod.DELETE, "/dbo-settings/{version}/appVersions/{platform}/{number}")
                .hasAnyRole("CI", "OPER")
                .antMatchers(HttpMethod.GET, "/dbo-settings/{version}/toggles/{platform}/{number}")
                .permitAll()
                .antMatchers(HttpMethod.POST, "/dbo-settings/{version}/appVersions/{platform}/{number}/status")
                .hasRole("OPER")
                .antMatchers(HttpMethod.GET, "/dbo-settings/{version}/appVersions")
                .hasRole("OPER")
                .and()
                .httpBasic()
                .and()
                .exceptionHandling().accessDeniedHandler(accessDeniedHandler());
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder authentication) throws Exception {
        authentication.inMemoryAuthentication()
                .withUser(adminLogin)
                .password(passwordEncoder().encode(adminPassword))
                .roles("CI", "OPER")
                .and()
                .withUser(ciLogin)
                .password(passwordEncoder().encode(ciPassword))
                .roles("CI")
                .and()
                .withUser(operatorLogin)
                .password(passwordEncoder().encode(operatorPassword))
                .roles("OPER");
    }

    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        return new CustomAuthenticationFailureHandler();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
