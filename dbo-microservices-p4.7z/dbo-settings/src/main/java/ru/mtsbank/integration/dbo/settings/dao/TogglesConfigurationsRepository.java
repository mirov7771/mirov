package ru.mtsbank.integration.dbo.settings.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.settings.dao.model.TogglesConfigurations;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;

import java.util.List;
import java.util.Set;

@Repository
public interface TogglesConfigurationsRepository extends CrudRepository<TogglesConfigurations, Integer> {

    Set<TogglesConfigurations> findAllByVersion(Version version);

    TogglesConfigurations findTogglesConfigurationsByKey_KeyAndVersion(String key, Version version);
}
