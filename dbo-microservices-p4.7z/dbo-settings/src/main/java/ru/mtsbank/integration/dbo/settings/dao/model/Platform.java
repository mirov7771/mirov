package ru.mtsbank.integration.dbo.settings.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "platforms")
@Getter @Setter
public class Platform {
    @Id
    @Column(name = "platform_id")
    private Integer platformId;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform_name")
    private PlatformName platformName;

}
