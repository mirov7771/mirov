package ru.mtsbank.integration.dbo.settings.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class ErrorResponse extends BaseResponse {

    public Error error;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Getter @Setter
    @AllArgsConstructor
    @ToString
    public static class Error {
        @JsonIgnore
        private int httpCode;
        private int code;
        private String message;
    }


}
