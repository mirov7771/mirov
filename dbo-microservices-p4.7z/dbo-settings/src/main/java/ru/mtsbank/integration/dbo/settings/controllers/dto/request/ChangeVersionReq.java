package ru.mtsbank.integration.dbo.settings.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.VersionStatusDto;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;

@Getter @Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChangeVersionReq {
    @JsonProperty("platform")
    private PlatformName platform;

    @JsonProperty("number")
    private String number;

    @JsonProperty("status")
    private VersionStatusDto versionStatus;
}
