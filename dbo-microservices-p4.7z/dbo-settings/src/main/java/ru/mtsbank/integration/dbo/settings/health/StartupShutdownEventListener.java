package ru.mtsbank.integration.dbo.settings.health;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.util.TimeZone;

@Service
@Slf4j
public class StartupShutdownEventListener {

    @EventListener
    void onStartup(ApplicationReadyEvent event) {
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
            log.info("Started DboSettingsApplication");
        } catch (Exception e) {
            log.error("error: ", e);
        }
    }
}

