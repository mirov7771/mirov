package ru.mtsbank.integration.dbo.settings.dao.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import java.sql.Timestamp;

public class VersionEventListener {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostPersist
    public void onPostPersist(Object object) {
        audit(object, "INSERT");
    }

    @PostUpdate
    public void onPostUpdate(Object object) {
        audit(object, "UPDATE");
    }

    @PostRemove
    public void onPostRemove(Object object) {
        audit(object, "DELETE");
    }

    public void audit(Object object, String operation) {
        Version version = (Version) object;
        String login = SecurityContextHolder.getContext().getAuthentication().getName();
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String SQL = "INSERT INTO au_versions (user_login,date,type,version_id,platform_id,created_date,status,version_code) VALUES (?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(SQL, login, timestamp, operation, version.getVersionId()
                , version.getPlatform().getPlatformId(), version.getCreatedDate(), version.getStatus().toString()
        ,version.getVersionCode());
    }
}
