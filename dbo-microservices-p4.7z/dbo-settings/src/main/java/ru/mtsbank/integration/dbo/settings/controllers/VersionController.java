package ru.mtsbank.integration.dbo.settings.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mtsbank.integration.dbo.settings.builders.ResponseBuilder;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.ChangeTogglesReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.ChangeVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.DeleteVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.NewVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.ErrorResponse;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.NewVersionRes;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.VersionDto;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.VersionStatusDto;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;
import ru.mtsbank.integration.dbo.settings.service.VersionService;

import javax.validation.Valid;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("dbo-settings")
@Slf4j
public class VersionController {

    @Autowired
    private VersionService versionService;

    @Operation(summary = "Создать новую версию. Дополнительно можно передать настройку для новой версии"
            , description = "Возвращает информацию о созданной версии"
            , tags = {"appVersions"}
            , responses = {
            @ApiResponse(responseCode = "200", description = "Версия создана", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = NewVersionRes.class))
            }),
            @ApiResponse(responseCode = "400", description = "Некорректно указаны параметры", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "500", description = "Произошла ошибка в работе севиса", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @PostMapping(value = "{version}/appVersions")
    public ResponseEntity<BaseResponse> createVersion(@Valid @RequestBody NewVersionReq newVersionReq,
                                                      @PathVariable final String version) {
        return ResponseBuilder.build(versionService.createVersion(newVersionReq));
    }




    @Operation(summary = "Изменить версию"
            , description = "Меняет статус версии"
            , tags = {"appVersions"}
            , responses = {
            @ApiResponse(responseCode = "200", description = "Статус версии изменён"),
            @ApiResponse(responseCode = "400", description = "Некорректно указаны параметры", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "500", description = "Произошла ошибка в работе севиса", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @PostMapping(value = "/{version}/appVersions/{platform}/{number}/status")
    public ResponseEntity<BaseResponse> changeStatus(@PathVariable String version,
                                                     @RequestBody VersionStatusDto versionStatus,
                                                     @PathVariable PlatformName platform,
                                                     @PathVariable String number) {
        ChangeVersionReq changeVersionReq = new ChangeVersionReq();
        changeVersionReq.setNumber(number);
        changeVersionReq.setPlatform(platform);
        changeVersionReq.setVersionStatus(versionStatus);
        return ResponseBuilder.build(versionService.changeVersion(changeVersionReq));
    }





    @Operation(summary = "Устанавливает настройку тоглов переключателей"
            , description = "Меняет настройку версии. У весии будет изменён состав и значение переключателей. Если версия в статусе release то состав должен быть тот-же, значение можно менять"
            , tags = {"appVersions"}
            , responses = {
            @ApiResponse(responseCode = "200",
                    description = "Версия изменена",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = NewVersionRes.class))
                    }),
            @ApiResponse(responseCode = "400",
                    description = "Некорректно указаны параметры",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    }),
            @ApiResponse(responseCode = "404",
                    description = "Версия не найдена",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    }),
            @ApiResponse(responseCode = "500",
                    description = "Произошла ошибка в работе севиса",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    })
    })
    @PostMapping(value = "/{version}/appVersions/{platform}/{number}/toggles")
    public ResponseEntity<BaseResponse> changeTogglesForVersion(@Valid @RequestBody Set<ToggleDto> toggles,
                                                                @PathVariable String version,
                                                                @PathVariable PlatformName platform,
                                                                @PathVariable String number) {
        ChangeTogglesReq changeTogglesReq = new ChangeTogglesReq();
        changeTogglesReq.setNumber(number);
        changeTogglesReq.setPlatform(platform);
        changeTogglesReq.setToggles(toggles);
        return ResponseBuilder.build(versionService.changeToggles(changeTogglesReq));
    }




    @Operation(summary = "Удалить версию"
            , description = "Удаляет версию в статусе test"
            , tags = {"appVersions"}
            , responses = {
            @ApiResponse(responseCode = "200", description = "Версия удалена"),
            @ApiResponse(responseCode = "400",
                    description = "Некорректно указаны параметры",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    }),
            @ApiResponse(responseCode = "500",
                    description = "Произошла ошибка в работе севиса",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    })
    })
    @DeleteMapping(value = "{version}/appVersions/{platform}/{number}")
    public ResponseEntity<BaseResponse> deleteVersion(@PathVariable String version,
                                                      @PathVariable PlatformName platform,
                                                      @PathVariable String number) {
        DeleteVersionReq deleteVersionReq = new DeleteVersionReq();
        deleteVersionReq.setNumber(number);
        deleteVersionReq.setPlatform(platform);
        return ResponseBuilder.build(versionService.deleteVersion(deleteVersionReq));
    }




    @Operation(summary = "Получить список всех версий и их настроек"
            , description = "Возвращает массив версий"
            , tags = {"appVersions"}
            , responses = {
            @ApiResponse(responseCode = "200"
                    , description = "Успешный ответ"
                    , content = {
                    @Content(mediaType = "application/json;charset=UTF-8", array = @ArraySchema(schema = @Schema(implementation = NewVersionRes.class)))
            }),
            @ApiResponse(responseCode = "500",
                    description = "Произошла ошибка в работе севиса",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    })
    })
    @GetMapping(value = "{version}/appVersions")
    public List<NewVersionRes> getAllVersions(@PathVariable String version) {
        return versionService.getAllVersions();
    }




    @Operation(summary = "Получить список тоглов для фронта"
            , description = "Метод вернёт реестр переключателей (список тоглов)"
            , tags = {"Feature Toggles"}
            , responses = {
            @ApiResponse(responseCode = "200"
                    , description = "В теле будет массив тоглов"
                    , content = {
                    @Content(mediaType = "application/json;charset=UTF-8", array = @ArraySchema(schema = @Schema(implementation = ToggleDto.class)))
            }),
            @ApiResponse(responseCode = "404",
                    description = "Нет настроенных тоглов. Тело ответа отсутствует"),
            @ApiResponse(responseCode = "500",
                    description = "Произошла ошибка в работе севиса",
                    content = {
                            @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
                    })
    })
    @GetMapping(value = "{version}/toggles/{platform}/{number}")
    public ResponseEntity<BaseResponse> getRegisterToggle(@PathVariable String version,
                                                          @PathVariable PlatformName platform,
                                                          @PathVariable String number) {
        VersionDto versionDto = new VersionDto();
        versionDto.setNumber(number);
        versionDto.setPlatform(platform);
        return ResponseBuilder.build(versionService.getRegisterToggles(versionDto));
    }


}
