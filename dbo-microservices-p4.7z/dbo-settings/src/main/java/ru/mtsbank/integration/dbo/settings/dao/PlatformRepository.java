package ru.mtsbank.integration.dbo.settings.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.settings.dao.model.Platform;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;

@Repository
public interface PlatformRepository extends CrudRepository<Platform, Integer> {
    Platform findByPlatformName(PlatformName platformName);
}
