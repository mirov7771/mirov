package ru.mtsbank.integration.dbo.settings.builders;

import org.springframework.http.ResponseEntity;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;

public class ResponseBuilder {

    public static ResponseEntity<BaseResponse> build(BaseResponse data){
        if (data.getErrorResponse() == null || data.getErrorResponse().getError() == null) {
            return ResponseEntity.ok(data);
        } else {
            return ResponseEntity.status(data.getErrorResponse().getError().getHttpCode()).body(data.getErrorResponse());
        }
    }

}
