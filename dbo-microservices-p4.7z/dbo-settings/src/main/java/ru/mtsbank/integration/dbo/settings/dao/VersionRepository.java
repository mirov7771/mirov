package ru.mtsbank.integration.dbo.settings.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;


@Repository
public interface VersionRepository extends CrudRepository<Version, Integer> {
    Version findByVersionCodeAndPlatform_PlatformName(String versionCode, PlatformName platformName);

    Version findByVersionCodeAndAndPlatform_PlatformNameAndStatusNot(String versionCode,
                                                                           PlatformName platformName,
                                                                           VersionStatus versionStatus);
}
