package ru.mtsbank.integration.dbo.settings.dao.model;

import lombok.*;
import ru.mtsbank.integration.dbo.settings.dao.listener.ToggleEventListener;

import javax.persistence.*;

@Entity
@Table(name = "toggles")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(ToggleEventListener.class)
public class Toggle {

    @Id
    @Column(name = "key")
    private String key;

    @Column(name = "toggle_name")
    private String toggleName;

    @Column(name = "description")
    private String description;
}
