package ru.mtsbank.integration.dbo.settings.dao.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;

import ru.mtsbank.integration.dbo.settings.dao.model.TogglesConfigurations;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import java.sql.Timestamp;

public class ToggleConfigurationsEventListener {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostPersist
    public void onPostPersist(Object object) {
        audit(object, "INSERT");
    }

    @PostUpdate
    public void onPostUpdate(Object object) {
        audit(object, "UPDATE");
    }

    @PostRemove
    public void onPostRemove(Object object) {
        audit(object, "DELETE");
    }

    public void audit(Object object, String operation) {
        TogglesConfigurations togglesConfigurations = (TogglesConfigurations) object;
        String login = SecurityContextHolder.getContext().getAuthentication().getName();
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String SQL = "INSERT INTO au_toggles_configurations (user_login,date,type,configuration_id,version_id,key,platform_id,value) VALUES (?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(SQL, login, timestamp, operation, togglesConfigurations.getTogglesConfigurationId()
                , togglesConfigurations.getVersion().getVersionId(), togglesConfigurations.getKey().getKey(), togglesConfigurations.getPlatformId()
                , togglesConfigurations.getValue());
    }
}
