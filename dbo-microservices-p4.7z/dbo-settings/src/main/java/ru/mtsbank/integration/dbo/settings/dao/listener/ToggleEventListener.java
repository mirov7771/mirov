package ru.mtsbank.integration.dbo.settings.dao.listener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import ru.mtsbank.integration.dbo.settings.dao.model.Toggle;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import javax.persistence.PostUpdate;
import java.sql.Timestamp;


public class ToggleEventListener {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostPersist
    public void onPostPersist(Object object) {
        audit(object, "INSERT");
    }

    @PostUpdate
    public void onPostUpdate(Object object) {
        audit(object, "UPDATE");
    }

    @PostRemove
    public void onPostRemove(Object object) {
        audit(object, "DELETE");
    }

    public void audit(Object object, String operation) {
        Toggle toggle = (Toggle) object;
        String login = SecurityContextHolder.getContext().getAuthentication().getName();
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String SQL = "INSERT INTO au_toggles (user_login,date,type,key,toggle_name,description) VALUES (?,?,?,?,?,?)";
        jdbcTemplate.update(SQL, login, timestamp, operation, toggle.getKey()
                , toggle.getToggleName(), toggle.getDescription());
    }

}

