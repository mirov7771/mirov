package ru.mtsbank.integration.dbo.settings.service;

import ru.mtsbank.integration.dbo.settings.controllers.dto.request.ChangeTogglesReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.ChangeVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.DeleteVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.NewVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.NewVersionRes;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.VersionDto;

import java.util.List;

public interface VersionService {
    BaseResponse createVersion(NewVersionReq version);

    BaseResponse changeVersion(ChangeVersionReq changeVersionReq);

    BaseResponse changeToggles(ChangeTogglesReq changeTogglesRes);

    BaseResponse deleteVersion(DeleteVersionReq deleteVersionReq);

    List<NewVersionRes> getAllVersions();

    BaseResponse getRegisterToggles(VersionDto versionDto);
}
