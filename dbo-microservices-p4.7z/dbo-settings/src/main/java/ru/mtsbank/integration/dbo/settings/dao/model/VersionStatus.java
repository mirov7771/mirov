package ru.mtsbank.integration.dbo.settings.dao.model;

public enum VersionStatus {
    TEST,
    RELEASE;
}
