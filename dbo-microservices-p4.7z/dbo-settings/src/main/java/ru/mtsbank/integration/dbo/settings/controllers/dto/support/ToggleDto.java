package ru.mtsbank.integration.dbo.settings.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.util.Objects;

@Getter @Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ToggleDto {

    @JsonProperty("key")
    @NotNull(message = "key must be not null")
    private String key;

    @JsonProperty("value")
    @NotNull(message = "value must be not null")
    private Boolean value;

    @JsonProperty("name")
    private String name;

    @JsonProperty("description")
    private String description;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ToggleDto toggleDto = (ToggleDto) o;
        return key.equals(toggleDto.key);
    }

    @Override
    public int hashCode() {
        return Objects.hash(key);
    }


}
