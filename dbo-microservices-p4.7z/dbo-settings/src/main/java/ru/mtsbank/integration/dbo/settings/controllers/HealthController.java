package ru.mtsbank.integration.dbo.settings.controllers;

import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import ru.mtsbank.integration.dbo.settings.health.LivenessHealthIndicator;
import ru.mtsbank.integration.dbo.settings.health.ReadinessHealthIndicator;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;


@RestController
@RequestMapping("dbo-settings")
@Slf4j
public class HealthController {

    @Autowired
    private ReadinessHealthIndicator readinessHealthIndicator;

    @Autowired
    private LivenessHealthIndicator livenessHealthIndicator;

    @RequestMapping(method = RequestMethod.GET)
    @Operation(hidden = true)
    public String check() {
        return "Application dbo-settings is running";
    }

    @RequestMapping(value = "/read", method = RequestMethod.GET, produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(hidden = true)
    public Health readiness() {
        return readinessHealthIndicator.health();
    }

    @RequestMapping(value = "/live", method = RequestMethod.GET, produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(hidden = true)
    public Health liveness() {
        return livenessHealthIndicator.health();
    }
}
