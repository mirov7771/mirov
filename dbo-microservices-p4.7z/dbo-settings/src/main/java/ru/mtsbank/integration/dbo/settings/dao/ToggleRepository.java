package ru.mtsbank.integration.dbo.settings.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.settings.dao.model.Toggle;

@Repository
public interface ToggleRepository extends CrudRepository<Toggle, String> {
    Toggle findByKey(String key);
}
