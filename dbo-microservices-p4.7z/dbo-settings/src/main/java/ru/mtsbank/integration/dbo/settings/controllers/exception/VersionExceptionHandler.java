package ru.mtsbank.integration.dbo.settings.controllers.exception;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.mtsbank.integration.dbo.settings.builders.ResponseBuilder;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;

@ControllerAdvice
@Slf4j
public class VersionExceptionHandler {

    @ExceptionHandler(InvalidFormatException.class)
    public ResponseEntity<BaseResponse> handleHttpMessageNotReadableException(InvalidFormatException exception) {
        BaseResponse baseResponse = new BaseResponse();
        if (exception.getTargetType().equals(VersionStatus.class)) {
            baseResponse.createError(400,1056,"Статус указан неккоректно");
        } else {
            baseResponse.createError(400,1055,"Неверно указана платформа. Доступные значения IOS, ANDROID");
        }
        return ResponseBuilder.build(baseResponse);
    }


}
