package ru.mtsbank.integration.dbo.settings.controllers.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandler;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
public class CustomAuthenticationFailureHandler implements AccessDeniedHandler {

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public void handle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AccessDeniedException e) throws IOException {
        httpServletResponse.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        httpServletResponse.setContentType("application/json;charset=UTF-8");
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.createError(400
                , 1057
                , "У пользователя нет подходящей роли для выполнения запроса");
        httpServletResponse.getWriter().write(objectMapper.writeValueAsString(baseResponse.getErrorResponse()));
        log.info("Пользователь " + SecurityContextHolder.getContext().getAuthentication().getName()
                + " пытается получить доступ к защищенному URL");
    }
}
