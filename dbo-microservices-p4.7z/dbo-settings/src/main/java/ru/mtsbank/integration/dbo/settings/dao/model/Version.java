package ru.mtsbank.integration.dbo.settings.dao.model;

import lombok.*;
import ru.mtsbank.integration.dbo.settings.dao.listener.VersionEventListener;
import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "versions", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"version_code", "platform_id"})
})
@Getter @Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(VersionEventListener.class)
public class Version implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "version_id")
    private Integer versionId;

    @Column(name = "platform_id")
    private Integer platformId;

    @ManyToOne
    @JoinColumn(name = "platform_id", referencedColumnName = "platform_id", insertable = false, updatable = false)
    private Platform platform;

    @Column(name = "version_code")
    private String versionCode;

    @Column(name = "created_date")
    private Timestamp createdDate;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private VersionStatus status;

}