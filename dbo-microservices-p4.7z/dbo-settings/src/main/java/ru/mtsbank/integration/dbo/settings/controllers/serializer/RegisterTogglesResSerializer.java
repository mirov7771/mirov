package ru.mtsbank.integration.dbo.settings.controllers.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import org.springframework.boot.jackson.JsonComponent;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.RegisterTogglesRes;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;

import java.io.IOException;
import java.util.Set;

@JsonComponent
public class RegisterTogglesResSerializer extends StdSerializer<RegisterTogglesRes> {

    public RegisterTogglesResSerializer() {
        this(null);
    }

    public RegisterTogglesResSerializer(Class<RegisterTogglesRes> t) {
        super(t);
    }

    @Override
    public void serialize(RegisterTogglesRes value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeStartArray();
        Set<ToggleDto> toggles = value.getToggles();
        for (ToggleDto toggleDto : toggles) {
            gen.writeStartObject();
            gen.writeStringField("key", toggleDto.getKey());
            gen.writeBooleanField("value", toggleDto.getValue());
            gen.writeStringField("name", toggleDto.getName());
            gen.writeStringField("description", toggleDto.getDescription());
            gen.writeEndObject();
        }
        gen.writeEndArray();
    }
}
