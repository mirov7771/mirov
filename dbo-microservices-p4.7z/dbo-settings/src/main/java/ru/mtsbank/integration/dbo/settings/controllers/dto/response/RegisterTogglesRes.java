package ru.mtsbank.integration.dbo.settings.controllers.dto.response;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.controllers.serializer.RegisterTogglesResSerializer;

import java.util.Set;

@Getter @Setter
@JsonSerialize(using = RegisterTogglesResSerializer.class)
public class RegisterTogglesRes extends BaseResponse{

    private Set<ToggleDto> toggles;
}
