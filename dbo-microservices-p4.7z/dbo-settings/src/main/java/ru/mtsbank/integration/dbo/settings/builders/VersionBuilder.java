package ru.mtsbank.integration.dbo.settings.builders;

import ru.mtsbank.integration.dbo.settings.controllers.dto.request.NewVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.NewVersionRes;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.dao.model.Platform;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;

import java.sql.Timestamp;
import java.util.Set;

public class VersionBuilder {

    public static NewVersionRes toBuildResponse(Version version) {
        return NewVersionRes.builder()
                .platformName(version.getPlatform().getPlatformName())
                .number(version.getVersionCode())
                .createdDate(version.getCreatedDate())
                .versionStatus(version.getStatus())
                .build();
    }

    public static NewVersionRes toBuildResponse(Version version, Set<ToggleDto> toggles) {
        return NewVersionRes.builder()
                .platformName(version.getPlatform().getPlatformName())
                .number(version.getVersionCode())
                .createdDate(version.getCreatedDate())
                .versionStatus(version.getStatus())
                .toggleDtoList(toggles)
                .build();
    }

    public static Version toBuildVersionFromDto(NewVersionReq newVersionReq, Platform platform) {
        return Version.builder()
                .status(VersionStatus.TEST)
                .createdDate(new Timestamp(System.currentTimeMillis()))
                .versionCode(newVersionReq.getNumber())
                .platform(platform)
                .platformId(platform.getPlatformId())
                .build();
    }
}
