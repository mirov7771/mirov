package ru.mtsbank.integration.dbo.settings.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.mtsbank.integration.dbo.settings.builders.VersionBuilder;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.dao.ToggleRepository;
import ru.mtsbank.integration.dbo.settings.dao.TogglesConfigurationsRepository;
import ru.mtsbank.integration.dbo.settings.dao.model.Toggle;
import ru.mtsbank.integration.dbo.settings.dao.model.TogglesConfigurations;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;
import ru.mtsbank.integration.dbo.settings.service.TogglesService;

import java.util.HashSet;
import java.util.Set;

@Service
@Slf4j
public class TogglesServiceImpl implements TogglesService {

    @Autowired
    private ToggleRepository toggleRepository;
    @Autowired
    private TogglesConfigurationsRepository togglesConfigurationsRepository;


    @Override
    public void saveTogglesWithConfig(Version version, Set<ToggleDto> toggles) {
        for (ToggleDto toggleDto : toggles) {
            Toggle toggleFromDb = toggleRepository.findByKey(toggleDto.getKey());
            if (toggleFromDb == null) {
                toggleFromDb = toggleRepository.save(Toggle.builder()
                        .key(toggleDto.getKey())
                        .toggleName(toggleDto.getName())
                        .description(toggleDto.getDescription())
                        .build());
            } else {
                if (toggleDto.getName() != null) {
                    toggleFromDb.setToggleName(toggleDto.getName());
                }
                if (toggleDto.getDescription() != null) {
                    toggleFromDb.setDescription(toggleDto.getDescription());
                }
                toggleRepository.save(toggleFromDb);
            }
            TogglesConfigurations togglesConfigurations = TogglesConfigurations.builder()
                    .versionId(version.getVersionId())
                    .version(version)
                    .key(toggleFromDb)
                    .value(toggleDto.getValue())
                    .platformId(version.getPlatformId())
                    .build();
            togglesConfigurationsRepository.save(togglesConfigurations);
        }
    }

    @Override
    public BaseResponse updateToggles(Version version, Set<ToggleDto> togglesDto) {
        Set<ToggleDto> toggles = new HashSet<>();
        for (ToggleDto toggleDto : togglesDto) {
            Toggle toggleFromDb = toggleRepository.findByKey(toggleDto.getKey());
            if (toggleDto.getName() != null) {
                toggleFromDb.setToggleName(toggleDto.getName());
            }
            if (toggleDto.getDescription() != null) {
                toggleFromDb.setDescription(toggleDto.getDescription());
            }
            toggleRepository.save(toggleFromDb);
            TogglesConfigurations toggleConfig = togglesConfigurationsRepository
                    .findTogglesConfigurationsByKey_KeyAndVersion(toggleDto.getKey(), version);
            toggleConfig.setValue(toggleDto.getValue());
            togglesConfigurationsRepository.save(toggleConfig);
            ToggleDto toggle = ToggleDto.builder()
                    .key(toggleFromDb.getKey())
                    .value(toggleConfig.getValue())
                    .name(toggleFromDb.getToggleName())
                    .description(toggleFromDb.getDescription())
                    .build();
            toggles.add(toggle);

        }
        return VersionBuilder.toBuildResponse(version, toggles);
    }

    @Override
    public BaseResponse changeToggles(Version version, Set<ToggleDto> toggles) {
        BaseResponse baseResponse = new BaseResponse();
        if (version.getStatus() == VersionStatus.RELEASE) {
            baseResponse.createError(400, 1050, "Запрещено менять состав тоглов для версии в статусе RELEASED");
            log.info(baseResponse.getErrorResponse().getError().toString());
            return baseResponse;
        }
        Set<TogglesConfigurations> allByVersion = togglesConfigurationsRepository.findAllByVersion(version);
        togglesConfigurationsRepository.deleteAll(allByVersion);
        saveTogglesWithConfig(version, toggles);
        return VersionBuilder.toBuildResponse(version, toggles);
    }
}
