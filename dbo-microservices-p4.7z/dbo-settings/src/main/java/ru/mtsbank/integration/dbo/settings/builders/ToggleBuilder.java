package ru.mtsbank.integration.dbo.settings.builders;

import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.dao.model.TogglesConfigurations;

import java.util.HashSet;
import java.util.Set;

public class ToggleBuilder {

    public static Set<ToggleDto> buildToggleDtoListFromConfig(Set<TogglesConfigurations> configurationsList) {
        Set<ToggleDto> resultList = new HashSet<>();
        for (TogglesConfigurations togglesConfiguration: configurationsList) {
            ToggleDto toggleDto = new ToggleDto();
            toggleDto.setKey(togglesConfiguration.getKey().getKey());
            toggleDto.setValue(togglesConfiguration.getValue());
            toggleDto.setName(togglesConfiguration.getKey().getToggleName());
            toggleDto.setDescription(togglesConfiguration.getKey().getDescription());

            resultList.add(toggleDto);
        }
        return resultList;
    }
}
