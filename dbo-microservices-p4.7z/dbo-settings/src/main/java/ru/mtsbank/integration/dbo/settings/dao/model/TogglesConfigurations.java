package ru.mtsbank.integration.dbo.settings.dao.model;

import lombok.*;
import ru.mtsbank.integration.dbo.settings.dao.listener.ToggleConfigurationsEventListener;

import javax.persistence.*;

@Entity
@Table(name = "toggles_configurations", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"version_id", "platform_id", "key"})
})
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(ToggleConfigurationsEventListener.class)
public class TogglesConfigurations {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "configuration_id")
    private Integer togglesConfigurationId;

    @Column(name = "value")
    private Boolean value;

    @ManyToOne
    @JoinColumns({
            @JoinColumn
                    (name = "version_id",
                            referencedColumnName = "version_id", insertable = false, updatable = false),
            @JoinColumn
                    (
                            name = "platform_id",
                            referencedColumnName = "platform_id", insertable = false, updatable = false
                    )

    })
    private Version version;

    @Column(name = "version_id")
    private Integer versionId;
    @Column(name = "platform_id")
    private Integer platformId;

    @JoinColumn(name = "key", referencedColumnName = "key")
    @ManyToOne
    private Toggle key;
}