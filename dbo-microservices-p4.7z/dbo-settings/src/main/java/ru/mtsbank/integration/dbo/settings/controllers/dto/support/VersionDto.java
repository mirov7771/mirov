package ru.mtsbank.integration.dbo.settings.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;

@Getter @Setter
public class VersionDto {

    @JsonProperty("platform")
    private PlatformName platform;

    @JsonProperty("number")
    private String number;
}
