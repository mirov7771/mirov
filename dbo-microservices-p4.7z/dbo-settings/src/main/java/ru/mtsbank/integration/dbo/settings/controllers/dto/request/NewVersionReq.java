package ru.mtsbank.integration.dbo.settings.controllers.dto.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.dao.model.PlatformName;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.Set;

@Getter @Setter
public class NewVersionReq {
    @JsonProperty("platform")
    @NotNull
    private PlatformName platform;
    @JsonProperty("number")
    @NotNull
    private String number;

    @JsonProperty("toggles")
    @Valid
    private Set<ToggleDto> toggles = new HashSet<>();

}
