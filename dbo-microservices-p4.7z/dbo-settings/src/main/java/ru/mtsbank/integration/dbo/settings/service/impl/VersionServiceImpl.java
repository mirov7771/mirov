package ru.mtsbank.integration.dbo.settings.service.impl;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.mtsbank.integration.dbo.settings.builders.ToggleBuilder;
import ru.mtsbank.integration.dbo.settings.builders.VersionBuilder;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.ChangeTogglesReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.ChangeVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.DeleteVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.request.NewVersionReq;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.BaseResponse;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.NewVersionRes;
import ru.mtsbank.integration.dbo.settings.controllers.dto.response.RegisterTogglesRes;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.ToggleDto;
import ru.mtsbank.integration.dbo.settings.controllers.dto.support.VersionDto;
import ru.mtsbank.integration.dbo.settings.dao.PlatformRepository;
import ru.mtsbank.integration.dbo.settings.dao.TogglesConfigurationsRepository;
import ru.mtsbank.integration.dbo.settings.dao.VersionRepository;
import ru.mtsbank.integration.dbo.settings.dao.model.Platform;
import ru.mtsbank.integration.dbo.settings.dao.model.TogglesConfigurations;
import ru.mtsbank.integration.dbo.settings.dao.model.Version;
import ru.mtsbank.integration.dbo.settings.dao.model.VersionStatus;
import ru.mtsbank.integration.dbo.settings.service.TogglesService;
import ru.mtsbank.integration.dbo.settings.service.VersionService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class VersionServiceImpl implements VersionService {
    @Autowired
    private VersionRepository versionRepository;
    @Autowired
    private PlatformRepository platformRepository;

    @Autowired
    private TogglesConfigurationsRepository togglesConfigurationsRepository;
    @Autowired
    private TogglesService togglesService;


    @Override
    public BaseResponse createVersion(NewVersionReq versionReq) {
        log.info("Start service createVersion");
        NewVersionRes newVersionRes = new NewVersionRes();
        if (versionRepository.findByVersionCodeAndPlatform_PlatformName(
                versionReq.getNumber(), versionReq.getPlatform()) != null) {
            newVersionRes.createError(400, 1051, "Данная версия уже существует на данной платформе");
            log.info(newVersionRes.getErrorResponse().getError().toString());
            return newVersionRes;
        }
        Platform platform = platformRepository.findByPlatformName(versionReq.getPlatform());
        Version version = VersionBuilder.toBuildVersionFromDto(versionReq, platform);
        version = versionRepository.save(version);
        togglesService.saveTogglesWithConfig(version, versionReq.getToggles());
        log.info("End service createVersion");
        return VersionBuilder.toBuildResponse(version, versionReq.getToggles());
    }

    @Override
    public BaseResponse changeVersion(ChangeVersionReq changeVersionReq) {
        log.info("Start service changeVersion");
        BaseResponse baseResponse = new BaseResponse();
        Version version = versionRepository.findByVersionCodeAndPlatform_PlatformName(changeVersionReq.getNumber()
                , changeVersionReq.getPlatform());
        if (version == null) {
            baseResponse.createError(404, 1052, "Данной версии не существует");
            log.info(baseResponse.getErrorResponse().getError().toString());
            return baseResponse;
        }
        if (!isChangeAllowed(version.getStatus(), changeVersionReq.getVersionStatus().getVersionStatus())) {
            baseResponse.createError(400,1053, "Ошибка перехода статусной модели");
            log.info(baseResponse.getErrorResponse().getError().toString());
            return baseResponse;
        }
        version.setStatus(changeVersionReq.getVersionStatus().getVersionStatus());
        versionRepository.save(version);

        log.info("End service changeVersion");
        return baseResponse;
    }

    @Override
    public BaseResponse changeToggles(ChangeTogglesReq changeTogglesReq) {
        log.info("Start service changeToggles");
        BaseResponse baseResponse = new BaseResponse();
        Version version = versionRepository.findByVersionCodeAndPlatform_PlatformName(changeTogglesReq.getNumber(),
                changeTogglesReq.getPlatform());
        if (version == null) {
            baseResponse.createError(404,1052, "Данной версии не существует");
            log.info(baseResponse.getErrorResponse().getError().toString());
            return baseResponse;
        }
        Set<TogglesConfigurations> allByVersion = togglesConfigurationsRepository.findAllByVersion(version);
        List<String> toggleNamesOfVersion = new ArrayList<>();
        for (TogglesConfigurations togglesConfigurations : allByVersion) {
            toggleNamesOfVersion.add(togglesConfigurations.getKey().getKey());
        }
        List<String> toggleNamesOfReq = new ArrayList<>();
        for (ToggleDto toggleDto : changeTogglesReq.getToggles()) {
            toggleNamesOfReq.add(toggleDto.getKey());
        }
        if (toggleNamesOfReq.size() != toggleNamesOfVersion.size()) {
            baseResponse = togglesService.changeToggles(version, changeTogglesReq.getToggles());
            return baseResponse;
        }
        Collections.sort(toggleNamesOfReq);
        Collections.sort(toggleNamesOfVersion);

        if (toggleNamesOfReq.equals(toggleNamesOfVersion)) {
            baseResponse = togglesService.updateToggles(version, changeTogglesReq.getToggles());
        } else {
            baseResponse = togglesService.changeToggles(version, changeTogglesReq.getToggles());
        }
        log.info("End service changeToggles");
        return baseResponse;
    }

    @Override
    public BaseResponse deleteVersion(DeleteVersionReq deleteVersionReq) {
        log.info("Start service deleteVersion");
        BaseResponse baseResponse = new BaseResponse();
        Version version = versionRepository.findByVersionCodeAndPlatform_PlatformName(deleteVersionReq.getNumber(),
                deleteVersionReq.getPlatform());
        if (version == null) {
            baseResponse.createError(404,1052, "Данной версии не существует");
            log.info(baseResponse.getErrorResponse().getError().toString());
            return baseResponse;
        }
        if (version.getStatus() == VersionStatus.RELEASE) {
            baseResponse.createError(400,1054, "Запрещено удалять версию в статусе RELEASED");
            log.info(baseResponse.getErrorResponse().getError().toString());
            return baseResponse;
        }
        Set<TogglesConfigurations> allByVersionConfig = togglesConfigurationsRepository.findAllByVersion(version);
        versionRepository.delete(version);
        togglesConfigurationsRepository.deleteAll(allByVersionConfig);
        log.info("End service deleteVersion");
        return baseResponse;
    }

    @Override
    public List<NewVersionRes> getAllVersions() {
        log.info("Start service getAllVersions");
        List<NewVersionRes> versionResList = new ArrayList<>();
        Iterable<Version> versionFromDbList = versionRepository.findAll();
        for (Version version : versionFromDbList) {
            Set<TogglesConfigurations> configByVersion = togglesConfigurationsRepository.findAllByVersion(version);
            Set<ToggleDto> toggleDtoList = ToggleBuilder.buildToggleDtoListFromConfig(configByVersion);
            versionResList.add(VersionBuilder.toBuildResponse(version, toggleDtoList));
        }
        log.info("End service getAllVersions");
        return versionResList;
    }

    @Override
    public BaseResponse getRegisterToggles(VersionDto versionDto) {
        log.info("Start service getRegisterVersions");
        RegisterTogglesRes registerTogglesRes = new RegisterTogglesRes();
        Version version = versionRepository.findByVersionCodeAndPlatform_PlatformName(versionDto.getNumber(), versionDto.getPlatform());

        if (version == null) {
            registerTogglesRes.createError(404, 1052, "Данной версии не существует");
            log.info(registerTogglesRes.getErrorResponse().getError().toString());
            return registerTogglesRes;
        }
        Set<TogglesConfigurations> allByVersion = togglesConfigurationsRepository.findAllByVersion(version);
        registerTogglesRes.setToggles(ToggleBuilder.buildToggleDtoListFromConfig(allByVersion));
        log.info("End service getAllVersions");
        return registerTogglesRes;
    }

    private boolean isChangeAllowed(VersionStatus versionStatusInDb, VersionStatus versionStatusReq) {
        return versionStatusInDb.ordinal() < versionStatusReq.ordinal();
    }
}
