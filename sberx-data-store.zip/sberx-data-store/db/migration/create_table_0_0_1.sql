create table data_object
(
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    sysname varchar(200) null,
    data bytea null,
    size_mb decimal,
    contenttype varchar(155),
    name varchar(200),
    secret varchar(255) null,
    av_status varchar (20),
    sha256 varchar(64),
    task_id varchar(40),
    create_dttm timestamp
);

create index x1_data_object on data_object(sha256);

create table av_auth
(
  token varchar,
  expires_at timestamp
);