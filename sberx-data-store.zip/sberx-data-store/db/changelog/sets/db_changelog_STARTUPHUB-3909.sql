--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-3909
create table file_access
(
    file_id       bigint primary key not null references data_object (id),
    allowed_users bigint[],
    allowed_roles varchar(100)[]
);