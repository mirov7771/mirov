--liquibase formatted sql
--changeset Mirov AA:file_hash
alter table data_object add column if not exists file_hash varchar null;
create unique index indx1_data_object on data_object(file_hash);
