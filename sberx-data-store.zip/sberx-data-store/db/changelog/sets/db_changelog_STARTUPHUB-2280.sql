--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2280
create index x2_data_object on data_object(name);