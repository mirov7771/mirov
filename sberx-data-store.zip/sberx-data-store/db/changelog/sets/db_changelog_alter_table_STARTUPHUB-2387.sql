--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2387_adding_size_mb_column
alter table data_object add column size_mb decimal;