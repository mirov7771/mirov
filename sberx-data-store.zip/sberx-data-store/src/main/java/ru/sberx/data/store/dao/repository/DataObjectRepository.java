package ru.sberx.data.store.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.data.store.dao.model.DataObject;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

@Repository
public interface DataObjectRepository extends CrudRepository<DataObject, Long> {
    DataObject findByIdAndSecret(Long id, String secret);
    DataObject findByName(String name);
    List<DataObject> findBySha256(String sha256);
    List<DataObject> findByAvStatus(String status);
    List<DataObject> findByNameIn(List<String> names);
    @Transactional
    @Modifying
    @Query("update DataObject set avStatus = 'error' where avStatus = :status and createDttm < :time")
    void updateAVStatus(String status, Date time);
    List<DataObject> findByFileHash(String fileHash);
}
