package ru.sberx.data.store.service.impl.v1;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.controller.dto.res.FileMetaRes;
import ru.sberx.data.store.service.Service;
import ru.sberx.data.store.service.impl.v1.methods.FileDelete;
import ru.sberx.data.store.service.impl.v1.methods.FileGet;
import ru.sberx.data.store.service.impl.v1.methods.FilePost;
import ru.sberx.data.store.service.impl.v1.methods.FilePut;

import java.util.List;

@Component("v1")
@RequiredArgsConstructor
public class ServiceV1Impl implements Service {

    private final FileGet fileGet;
    private final FilePost filePost;
    private final FilePut filePut;
    private final FileDelete fileDelete;

    @Override
    public FileRes select(String fileName, String sessionId) {
        return fileGet.execute(fileName, sessionId);
    }

    @Override
    public List<FileMetaRes> selectMeta(List<String> id) {
        return fileGet.getMeta(id);
    }

    @Override
    public FileRes save(FileReq req) {
        return filePost.execute(req);
    }

    @Override
    public FileRes update(FileReq req) {
        return filePut.execute(req);
    }

    @Override
    public void delete(FileReq req) {
        fileDelete.execute(req);
    }
}
