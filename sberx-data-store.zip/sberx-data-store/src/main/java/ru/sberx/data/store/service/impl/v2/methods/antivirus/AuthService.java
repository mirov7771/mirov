package ru.sberx.data.store.service.impl.v2.methods.antivirus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sberx.data.store.config.WebConfig;
import ru.sberx.data.store.dao.model.Token;
import ru.sberx.data.store.dao.repository.TokenRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import java.net.URI;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
@Slf4j
public class AuthService {

    private final URI authUri;
    private final String authTokenReq;
    private final WebClient webClient;
    private final TokenRepository tokenRepository;

    public AuthService(@Value("${application.antivirus.url}") String url,
                       @Value("${application.antivirus.paths.auth}") String authUri,
                       @Value("${application.antivirus.username}") String username,
                       @Value("${application.antivirus.password}") String password,
                       WebClient webClient,
                       TokenRepository tokenRepository) {
        this.authUri = UriComponentsBuilder.fromHttpUrl(url).path("/").path(authUri).build().normalize().toUri();
        this.authTokenReq = "grant_type=password&username=" + username + "&password=" + password;
        this.webClient = webClient;
        this.tokenRepository = tokenRepository;
    }

    private final AtomicReference<String> cachedAccessToken = new AtomicReference<>("");
    private final AtomicReference<Date> cachedExpiresAt = new AtomicReference<>(new Date());
    private final Lock lock = new ReentrantLock();
    private static final int LOCK_GAP_SECONDS = 5;



    public String getAccessToken() {
        log.debug("Getting access token");
        if (new Date().before(cachedExpiresAt.get())) {
            log.trace("auth: getting token from cache");
            return cachedAccessToken.get();
        }
        try {
            if (lock.tryLock(LOCK_GAP_SECONDS, TimeUnit.SECONDS)) {
                try {
                    log.trace("auth: locked");
                    String accessToken;
                    Optional<Token> actualToken = tokenRepository.findByExpiresAt(new Date());
                    if (actualToken.isPresent()) {
                        Token token = actualToken.get();
                        accessToken = token.getAccessToken();
                        log.trace("auth: getting token from db");
                        cachedExpiresAt.set(token.getExpiresAt());
                    } else {
                        log.trace("auth: updating token in db");
                        tokenRepository.deleteAll();
                        log.trace("auth: sending request to {}", authUri);
                        AuthTokenRes res = webClient.post()
                                .uri(authUri)
                                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                                .bodyValue(authTokenReq)
                                .retrieve()
                                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                                .bodyToMono(AuthTokenRes.class)
                                .block();
                        log.trace("auth: got result from {} : {}", authUri, res);
                        if (res == null) {
                            throw new SberException(SberErrors.INTERNAL_SERVICE_ERROR, "Failed to get access_token from " + authUri);
                        }
                        accessToken = res.getAccessToken();
                        Token t = new Token();
                        t.setAccessToken(res.getAccessToken());
                        t.setExpiresAt(Date.from(Instant.now().plus(res.getExpiresIn(), ChronoUnit.SECONDS)));
                        tokenRepository.save(t);
                        cachedExpiresAt.set(t.getExpiresAt());
                        log.info("auth: Logged in successfully, expires at: {}", t.getExpiresAt());
                    }
                    cachedAccessToken.set(accessToken);
                    return accessToken;
                } finally {
                    lock.unlock();
                    log.trace("auth: unlocked");
                }
            } else {
                log.error("auth: Failed to catch lock.");
                throw new IllegalThreadStateException("Failed to seize lock (wait)");
            }
        } catch (InterruptedException e) {
            log.error("auth: Failed to catch lock; was interrupted.", e);
            throw new IllegalStateException("Failed to catch lock (interrupted)", e);
        }
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    private static class AuthTokenRes {
        @JsonProperty("access_token")
        private String accessToken;
        @JsonProperty("expires_in")
        private Long expiresIn;

        @Override
        public String toString() {
            return "AuthTokenRes{" +
                    "accessToken='" + "..." + '\'' +
                    ", expiresIn=" + expiresIn +
                    '}';
        }
    }

}
