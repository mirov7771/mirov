package ru.sberx.data.store.builder;

import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import ru.sberx.data.store.config.WebConfig;

public class ResponseBuilder {

    public static <T> ResponseEntity<T> build(T data) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(WebConfig.REQUEST_ID, ThreadContext.get(WebConfig.REQUEST_ID));
        return ResponseEntity.ok().headers(headers).body(data);
    }

}
