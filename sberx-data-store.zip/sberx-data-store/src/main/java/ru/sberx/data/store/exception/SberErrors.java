package ru.sberx.data.store.exception;

import lombok.Getter;

@Getter
public enum SberErrors {
    INTERNAL_SERVICE_ERROR(1000, 400, "Сервис временно недоступен"),
    FILE_NOT_FOUND(1005, 404, "Файл не найден"),
    FAILED_TO_SAVE_FILE(1006, 417, "Не удалось сохранить файл"),
    METHOD_DOES_NOT_EXIST(1009, 400, "Метод не существует"),
    EDITING_FORBIDDEN(1023, 417, "Редактирование запрещено"),
    MISSING_REQUIRED_PARAMETERS(1004, 406, "Не переданы обязательные параметры"),
    FILE_DONT_PASS_AV_SCAN(1030, 417, "Не пройдена антивирусная проверка"),
    ;

    private final int code;
    private final int status;
    private final String message;

    SberErrors(int code, int status, String message) {
        this.code = code;
        this.status = status;
        this.message = message;
    }
}
