package ru.sberx.data.store.service.impl.v2;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.service.Service;
import ru.sberx.data.store.service.impl.v2.methods.FileV2AvStatus;
import ru.sberx.data.store.service.impl.v2.methods.FileV2Post;

@Component("v2")
@RequiredArgsConstructor
public class ServiceV2Impl implements Service {

    private final FileV2Post filePost;
    private final FileV2AvStatus fileAvStatus;

    @Override
    public FileRes select(String fileName, String sessionId) {
        return null;
    }

    @Override
    public FileRes save(FileReq req) {
        return filePost.execute(req);
    }

    @Override
    public void delete(FileReq req) {

    }

    @Override
    public void updateAvScanStatus() {
        fileAvStatus.execute(null);
    }

    @Override
    public String getFileStatus(String id) {
        return fileAvStatus.getFileStatus(id);
    }
}
