package ru.sberx.data.store.controller.mock.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Date;

@Data
public class VerdictRes {
    @JsonProperty("task_id")
    private String taskId;
    @JsonProperty("is_malware")
    private Boolean isMalware;
    @JsonProperty("datetime")
    private Date dateTime;
    @JsonProperty("count_av")
    private Integer countAv;
    @JsonProperty("count_detect")
    private Integer countDetect;
}
