package ru.sberx.data.store.dao.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "DATA_OBJECT")
@Getter
@Setter
@ToString
public class DataObject implements Serializable {

    private static final long serialVersionUID = -7576952166071317393L;

    @Id
    @Column(name="ID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(name="SYSNAME")
    private String sysName;
    @Lob
    @Type(type="org.hibernate.type.BinaryType")
    @Column(name="DATA")
    private byte[] data;
    @Column(name = "SIZE_MB")
    private Double sizeMb;
    @Column(name="CONTENTTYPE")
    private String contentType;
    @Column(name="NAME")
    private String name;
    @Column(name = "SECRET")
    private String secret;
    @Column(name = "AV_STATUS")
    private String avStatus;
    @Column(name = "SHA256")
    private String sha256;
    @Column(name = "TASK_ID")
    private String taskId;
    @Column(name = "CREATE_DTTM")
    private Date createDttm;
    @Column(name = "FILE_HASH")
    private String fileHash;

}

