package ru.sberx.data.store.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class FileMetaRes {

    @JsonProperty("id")
    private String id;
    @JsonProperty("createDate")
    private Date createDate;
    @JsonProperty("name")
    private String name;
    private Double size;
    @JsonProperty("mimeType")
    private String mimeType;
    @JsonProperty("fileType")
    private String fileType;
}
