package ru.sberx.data.store.controller.mock;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.sberx.data.store.controller.mock.dto.AuthToken;
import ru.sberx.data.store.controller.mock.dto.StateReq;
import ru.sberx.data.store.controller.mock.dto.SubmitTaskRes;
import ru.sberx.data.store.controller.mock.dto.VerdictRes;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;

import static org.springframework.http.MediaType.APPLICATION_OCTET_STREAM_VALUE;

@RestController
@RequestMapping("antivirus")
@RequiredArgsConstructor
@Slf4j
public class MockAntivirusServiceController {

    private static final MessageDigest digest;
    private static final Base64.Encoder encoder = Base64.getUrlEncoder();

    private static final ConcurrentMap<String, byte[]> cacheFiles = new ConcurrentHashMap<>();
    private static final ConcurrentMap<String, Integer> cacheVerdicts = new ConcurrentHashMap<>();
    private static final AtomicReference<States> state = new AtomicReference<>(States.FORCE_NOT_MALWARE);

    public enum States {
        MALWARE,
        NOT_MALWARE,
        FORCE_MALWARE,
        FORCE_NOT_MALWARE
    }

    static {
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    @PostMapping("mock/state")
    public String changeState(@RequestBody StateReq req) {
        States currentState = state.get();
        log.info("Changing {} state to {}", currentState, req.getNewState());
        return "Changed for new state " + req.getNewState().name();
    }

    @PostMapping("auth/token")
    public AuthToken auth() {
        AuthToken authToken = new AuthToken();
        authToken.setAccessToken(UUID.randomUUID().toString());
        authToken.setExpiresIn(3600L);
        log.info("Generating authToken: {}", authToken);
        return authToken;
    }

    @PostMapping(value = "av_scans", consumes = {"multipart/form-data"})
    public SubmitTaskRes submitTask(@RequestPart("file") MultipartFile body) {
        SubmitTaskRes res = new SubmitTaskRes();
        byte[] file = new byte[0];
        try {
            file = body.getBytes();
        } catch (IOException e) {
            log.error("Could not download file", e);
        }
        String taskId = UUID.randomUUID().toString();
        res.setTaskId(taskId);
        res.setStatus("ok");
        res.setVerdicts(new ArrayList<>());
        String fileId = encoder.encodeToString(digest.digest(file));
        cacheFiles.putIfAbsent(fileId, file);
        cacheVerdicts.putIfAbsent(taskId, 1);
        res.setFileId(fileId);
        log.info("Submitted task: {}", res);
        return res;
    }

    @GetMapping("av_scans/{taskId}")
    public VerdictRes taskInfo(@PathVariable String taskId) {
        VerdictRes res = new VerdictRes();
        Integer i = cacheVerdicts.getOrDefault(taskId, -1);
        States currentState = state.get();
        if (currentState.equals(States.FORCE_MALWARE)) {
            res.setIsMalware(true);
        } else if (currentState.equals(States.FORCE_NOT_MALWARE)) {
            res.setIsMalware(false);
        } else if (i <= 0) {
            if (currentState.equals(States.MALWARE)) {
                res.setIsMalware(true);
            } else if (currentState.equals(States.NOT_MALWARE)) {
                res.setIsMalware(false);
            }
        } else {
            cacheVerdicts.replace(taskId, 0);
        }
        res.setTaskId(taskId);
        log.info("Returning taskInfo: {}", res);
        return res;
    }

    @GetMapping(value = "/samples/{fileId}/file", produces = APPLICATION_OCTET_STREAM_VALUE)
    public byte[] downloadFile(@PathVariable String fileId) {
        try {
            log.info("Returning file {}", fileId);
            return cacheFiles.getOrDefault(fileId, new byte[]{});
        } finally {
            cacheFiles.remove(fileId);
        }
    }

}
