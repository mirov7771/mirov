package ru.sberx.data.store.exception;

import lombok.Getter;

@Getter
public class SberException extends RuntimeException {

    private static final long serialVersionUID = 3880388495022065469L;

    private final Integer code;
    private final Integer status;
    private final String message;
    private final String details;

    public SberException(Integer code, Integer status, String message, String details){
        super(message);
        this.details = details;
        this.code = code;
        this.status = status;
        this.message = message;
    }

    public SberException(SberErrors err) {
        this.code = err.getCode();
        this.status = err.getStatus();
        this.message = err.getMessage();
        this.details = null;
    }

    public SberException(SberErrors err, String details) {
        this.code = err.getCode();
        this.status = err.getStatus();
        this.message = err.getMessage();
        this.details = details;
    }

}
