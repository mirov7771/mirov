package ru.sberx.data.store.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import static ru.sberx.data.store.validator.ConditionValidator.preValidate;

@Component
@Slf4j
public class FileDelete extends File {

    public FileDelete(
            DataObjectRepository dataObjectRepository,
            ApplicationConfig applicationConfig,
            UserAuthService userAuthService) {
        super(dataObjectRepository, applicationConfig, userAuthService);
    }

    @Override
    public FileRes execute(FileReq req) {
        log.info("start delete file");
        if (req.getSessionId() == null || "".equals(req.getSessionId()))
            throw new SberException(SberErrors.EDITING_FORBIDDEN);
        DataObject file = dataObjectRepository.findByIdAndSecret(req.getId(), req.getSessionId());
        preValidate(file, SberErrors.FILE_NOT_FOUND);
        dataObjectRepository.delete(file);
        log.info("end delete file");
        return new FileRes(file.getId());
    }
}
