package ru.sberx.data.store.config;

import io.netty.channel.ChannelOption;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.logging.AdvancedByteBufFormat;
import ru.sberx.data.store.controller.dto.res.ErrorRes;
import ru.sberx.data.store.exception.SberException;

import javax.net.ssl.SSLException;
import java.net.URI;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;



@Configuration
@Slf4j
public class WebConfig {

    public static final String CLIENT_ID = "client-id";
    public static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";
    public static final String REQUEST_ID = "requestId";

    @Value("${application.sberx.url:}")
    private String sberxUrl;
    @Value("${application.timeout:20000}")
    private Integer timeOut;
    @Value("${application.web.max.inmemory.size:50}")
    private Integer maxInmemorySize;

    @Bean
    @Scope("prototype")
    public WebClient webClient(HttpClient httpClient) {
        return WebClient.builder()
                .baseUrl(sberxUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .defaultHeader(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE)
                .codecs(configurer -> configurer
                        .defaultCodecs()
                        .maxInMemorySize(maxInmemorySize * 1024 * 1024))
                .build();
    }

    @Bean
    @Scope("prototype")
    public HttpClient httpClient() throws SSLException {
        SslContext sslContext = SslContextBuilder
                .forClient()
                .trustManager(InsecureTrustManagerFactory.INSTANCE)
                .build();
        return HttpClient.create()
                .wiretap(log.getName(), LogLevel.TRACE, AdvancedByteBufFormat.TEXTUAL)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, timeOut)
                .secure(t -> t.sslContext(sslContext))
                .doOnConnected(conn ->
                        conn.addHandlerLast(new ReadTimeoutHandler(timeOut, TimeUnit.MILLISECONDS))
                                .addHandlerLast(new WriteTimeoutHandler(timeOut, TimeUnit.MILLISECONDS)))
                .responseTimeout(Duration.ofMillis(timeOut));
    }

    public static void setHeaders(String requestId, String clientId) {
        ThreadContext.put(REQUEST_ID, requestId);
        ThreadContext.put(CLIENT_ID, clientId);
    }

    /**
     * Функция, логирующая параметры запроса.
     *
     * @param url URL, куда отправляется запрос
     * @param req параметры запросы: либо один объект, либо пары объектов, состоящие из ключа и значения
     */
    public static void logSending(URI url, Object... req) {
        Object o = "";
        if (req.length > 1) {
            Map<String, Object> m = new LinkedHashMap<>();
            for (int i = 0; i < req.length / 2; i++) {
                m.put((String) req[2 * i], req[2 * i + 1]);
            }
            o = m;
        } else if (req.length == 1) {
            o = req[0];
        }
        log.debug("Sending request to {} : {}", url, o);
    }

    /**
     * Функция, логирующая ответ от внешнего сервиса.
     *
     * @param url URL, откуда пришел ответ
     * @param res ответ от внешнего сервиса
     */
    public static void logReceiving(URI url, Object res) {
        log.debug("Received response from {} : {}", url, res);
    }

    public static Predicate<HttpStatus> sberxErrorStatus() {
        return httpStatus -> httpStatus.is4xxClientError() || httpStatus.is5xxServerError();
    }

    public static Function<ClientResponse, Mono<? extends Throwable>> convertToSberxException() {
        return response -> response.bodyToMono(ErrorRes.class).map(
                errorRes -> new SberException(errorRes.getCode(), response.statusCode().value(), errorRes.getMessage(), errorRes.getDetails())
        );
    }

    public static Consumer<HttpHeaders> defaultHeaders() {
        return httpHeaders -> {
            httpHeaders.set(REQUEST_ID, ThreadContext.get(REQUEST_ID));
            httpHeaders.set(CLIENT_ID, ThreadContext.get(CLIENT_ID));
        };
    }
}
