package ru.sberx.data.store.service.impl.v2.methods.antivirus;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriBuilder;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Flux;
import ru.sberx.data.store.config.WebConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.net.URI;
import java.util.Base64;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class AntivirusService {

    private static final String BEARER = "Bearer ";
    public static final Base64.Decoder decoder = Base64.getDecoder();
    private final URI scanUri;
    private final UriBuilder taskInfoUri;
    private final UriBuilder downloadUri;
    private final WebClient webClient;
    private final AuthService authService;


    public AntivirusService(@Value("${application.antivirus.url}") String url,
                            @Value("${application.antivirus.paths.scan}") String scanUri,
                            @Value("${application.antivirus.paths.task}") String taskInfoUri,
                            @Value("${application.antivirus.paths.download}") String downloadUri,
                            WebClient webClient,
                            AuthService authService) {
        this.scanUri = UriComponentsBuilder.fromHttpUrl(url).path("/").path(scanUri).build().normalize().toUri();
        this.taskInfoUri = UriComponentsBuilder.fromHttpUrl(url).path("/").path(taskInfoUri);
        this.downloadUri = UriComponentsBuilder.fromHttpUrl(url).path("/").path(downloadUri);
        this.webClient = webClient;
        this.authService = authService;
    }

    public TaskInfo checkFile(FileReq req) {
        TaskInfo taskInfo = new TaskInfo();
        String authToken = authService.getAccessToken();
        MultiValueMap<String, HttpEntity<?>> body = prepareFile(req);
        WebConfig.logSending(scanUri, body);
        AVRes res = webClient.post()
                .uri(scanUri)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .header(HttpHeaders.AUTHORIZATION, BEARER + authToken)
                .body(BodyInserters.fromMultipartData(body))
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                .bodyToMono(AVRes.class)
                .block();
        WebConfig.logReceiving(scanUri, res);
        if (res != null) {
            taskInfo.taskId = res.taskId;
            taskInfo.fileId = res.fileId;
            if (res.verdicts != null && !res.verdicts.isEmpty()) {
                taskInfo.isMalware = false;
                for(Verdict v: res.verdicts) {
                    if (Boolean.TRUE.equals(v.isMalware)) {
                        taskInfo.isMalware = true;
                        break;
                    }
                }
            }
        }
        log.debug("Scan result: {}", taskInfo);
        return taskInfo;
    }

    public Boolean isMalware(String taskId) {
        String authToken = authService.getAccessToken();
        log.debug("Attempt to get result of task {}", taskId);
        URI uri = taskInfoUri.build(taskId);
        WebConfig.logSending(uri);
        Verdict v = webClient.get()
                .uri(uri)
                .header(HttpHeaders.AUTHORIZATION, BEARER + authToken)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .onStatus(WebConfig.sberxErrorStatus(), clientResponse -> clientResponse
                        .bodyToMono(String.class)
                        .map(error -> new SberException(SberErrors.INTERNAL_SERVICE_ERROR.getCode(),
                                clientResponse.rawStatusCode(),
                                error, null)))
                .bodyToMono(Verdict.class)
                .block();
        WebConfig.logReceiving(uri, v);
        if (v != null)
            return v.isMalware;
        return null;
    }

    public byte[] downloadFile(String fileId) {
        String authToken = authService.getAccessToken();
        URI uri = downloadUri.build(fileId).normalize();
        WebConfig.logSending(uri);
        try {
            Flux<DataBuffer> dataBufferFlux = webClient.get()
                    .uri(uri)
                    .header(HttpHeaders.AUTHORIZATION, BEARER + authToken)
                    .accept(MediaType.APPLICATION_OCTET_STREAM)
                    .retrieve()
                    .onStatus(WebConfig.sberxErrorStatus(), WebConfig.convertToSberxException())
                    .bodyToFlux(DataBuffer.class);
            try(ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
                DataBufferUtils.write(dataBufferFlux, bytes).map(DataBufferUtils::release).then().block();
                //DataBufferUtils.write(dataBufferFlux, bytes).blockLast();
                if (bytes.size() == 0) {
                    throw new SberException(SberErrors.INTERNAL_SERVICE_ERROR, "Empty response while downloading file from BiZone");
                }
                WebConfig.logReceiving(uri, "[File data]");
                return bytes.toByteArray();
            } catch (IOException e) {
                log.error("Failed to download file", e);
                throw new SberException(SberErrors.INTERNAL_SERVICE_ERROR, "Failed to download file from BiZone");
            }
        } catch (Exception e){
            log.error("Error getting file from BiZone: ", e);
            throw new SberException(SberErrors.INTERNAL_SERVICE_ERROR, "Failed to download file from BiZone");
        }
    }

    private MultiValueMap<String, HttpEntity<?>> prepareFile(FileReq file) {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();
        byte[] bytes = decoder.decode(file.getData());
        builder.part("file", bytes)
                .header(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"file\"; filename=\"" + file.getName() + "\"")
                .header(HttpHeaders.CONTENT_TYPE, file.getContentType());
        builder.part("force", true).header(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"force\"");
        builder.part("priority", 6).header(HttpHeaders.CONTENT_DISPOSITION, "form-data; name=\"priority\"");
        return builder.build();
    }

    @Data
    private static class AVRes {
        private String status;
        @JsonProperty("task_id")
        private String taskId;
        @JsonProperty("file_id")
        private String fileId;
        List<Verdict> verdicts;
    }

    @Data
    private static class Verdict {
        @JsonProperty("task_id")
        private String taskId;
        @JsonProperty("is_malware")
        private Boolean isMalware;
        @JsonProperty("datetime")
        private Date dateTime;
        @JsonProperty("count_av")
        private Integer countAv;
        @JsonProperty("count_detect")
        private Integer countDetect;
    }

    @Data
    public static class TaskInfo {
        private String taskId;
        private String fileId;
        private Boolean isMalware = null;
    }
}
