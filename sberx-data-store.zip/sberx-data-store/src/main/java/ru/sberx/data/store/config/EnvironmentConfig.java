package ru.sberx.data.store.config;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import javax.annotation.PostConstruct;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;

@Configuration
@Slf4j
public class EnvironmentConfig {

    @Value("${log.sender.port:8086}")
    private String port;

    private static final URL logbackFile = EnvironmentConfig.class.getResource("/spring-logback.xml");

    @PostConstruct
    public void doPostConstruct() throws JoranException, IOException {
        overrideLoggingConfig();
    }

    private void overrideLoggingConfig() throws IOException, JoranException {
        String initialString = getText();
        initialString = initialString.replace("{port}", port);
        InputStream targetStream = new ByteArrayInputStream(initialString.getBytes());
        LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
        JoranConfigurator configurator = new JoranConfigurator();
        configurator.setContext(context);
        context.reset();
        configurator.doConfigure(targetStream);
    }

    private String getText() throws IOException {
        if (logbackFile != null) {
            URLConnection connection = EnvironmentConfig.logbackFile.openConnection();
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(
                            connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                response.append(inputLine);
            in.close();
            return response.toString();
        }
        log.error("logback configuration not found");
        throw new SberException(SberErrors.INTERNAL_SERVICE_ERROR, "logback configuration not found");
    }

}