package ru.sberx.data.store.dao.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = "AV_AUTH")
public class Token {

    @Id
    @Column(name = "TOKEN")
    private String accessToken;
    @Column(name = "EXPIRES_AT")
    private Date expiresAt;

}
