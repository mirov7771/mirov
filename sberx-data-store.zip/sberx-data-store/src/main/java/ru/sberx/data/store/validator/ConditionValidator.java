package ru.sberx.data.store.validator;

import org.springframework.util.StringUtils;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import java.util.Base64;
import java.util.HashSet;
import java.util.Set;

public class ConditionValidator {

    public static final Integer TASK_NOT_COMPLETED = 2;
    public static final Integer IS_MALWARE = 1;

    private static final Base64.Decoder decoder = Base64.getDecoder();

    private static final Set<String> VALID_SVG = new HashSet<>();

    static {
        VALID_SVG.add("startup_6df4f39b.svg");
        VALID_SVG.add("corporation_26fda955.svg");
        VALID_SVG.add("pilots_d2f8627d.svg");
        VALID_SVG.add("investor_fc1ede14.svg");
    }

    private ConditionValidator(){}

    public static void preValidate(Object obj, SberErrors err) throws SberException {
        if (obj == null)
            throw new SberException(err);
    }

    public static void validateParams(String method, FileReq req){
        String details = "";
        validData(req.getData());
        if ("post".equals(method)) {
            details = details +
                    (req.getData() == null? "; data" : "") +
                    (req.getName() == null? "; name" : "") +
                    (req.getContentType() == null? "; contentType" : "");
        } else if ("put".equals(method) && req.getId() == null) {
                details += "id";
        }
        if (req.getContentType() != null && !"".equals(req.getContentType())){
            String contentType = req.getContentType();
            if (StringUtils.hasText(req.getName()) && VALID_SVG.contains(req.getName()))
                return;
            if (!(contentType.contains("png")
                    || contentType.contains("pdf")
                    || contentType.contains("doc")
                    || contentType.contains("docx")
                    || contentType.contains("rtf")
                    || contentType.contains("jpeg")
                    || contentType.contains("gif")
                    || contentType.contains("application/octet-stream"))){
                throw new SberException(SberErrors.MISSING_REQUIRED_PARAMETERS, "Not valid content type");
            }
        }
        if (!"".equals(details))
            throw new SberException(SberErrors.MISSING_REQUIRED_PARAMETERS, details);
    }

    private static void validData(String string) {
        try {
            decoder.decode(string);
        } catch (IllegalArgumentException e) {
            throw new SberException(SberErrors.FAILED_TO_SAVE_FILE);
        }
    }

    public static void validateFileName(FileReq req) {
        req.setName(req.getName().replaceAll("[^\\p{L}\\d._-]", ""));
    }

}
