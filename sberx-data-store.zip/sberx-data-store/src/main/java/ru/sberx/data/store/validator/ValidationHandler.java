package ru.sberx.data.store.validator;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.sberx.data.store.controller.dto.res.ErrorRes;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

@ControllerAdvice
@Slf4j
public class ValidationHandler {

    @ExceptionHandler({Exception.class})
    protected ResponseEntity<ErrorRes> handleException(Exception ex){
        log.error("error in service ", ex);
        if (ex instanceof SberException){
            SberException e = (SberException) ex;
            return ResponseEntity.status(e.getStatus()).body(new ErrorRes(e.getCode(), e.getMessage(), e.getDetails()));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
                new ErrorRes(SberErrors.INTERNAL_SERVICE_ERROR.getCode(), SberErrors.INTERNAL_SERVICE_ERROR.getMessage(), ex.getMessage()));
    }

}
