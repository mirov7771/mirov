package ru.sberx.data.store.service.impl.v1.methods;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.util.CollectionUtils;
import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.security.MessageDigest;
import java.util.*;

@RequiredArgsConstructor
@ComponentScan(basePackages = {"ru.sberx.unity.gate", "ru.sberx.rest.gate"})
@Slf4j
public abstract class File {

    private static final Double MB_SIZE = 1_048_576.0;

    protected final DataObjectRepository dataObjectRepository;
    protected final ApplicationConfig applicationConfig;
    protected final UserAuthService userAuthService;

    public abstract FileRes execute(FileReq req);

    protected void setUrl(FileRes res, String contentType, String fileName) {
        String url = applicationConfig.getUrl();
        res.setFileType(contentType);

        if (contentType.contains("pdf")
                || contentType.contains("rtf")
                || contentType.contains("doc")
                || contentType.contains("docx")
                || contentType.contains("application/octet-stream"))
            url = applicationConfig.getContext() + url;

        res.setFileUrl(url + fileName);
    }

    protected Double getFileSize(byte[] file) {
        double size = Math.round(file.length / MB_SIZE * 10.0) / 10.0;
        if (size == 0.0 && file.length > 0) {
            size = 0.01;
        }
        return size;
    }

    protected FileRes checkHash(FileReq req){
        FileRes res = new FileRes();
        String fileHash = shaSum(Base64.getDecoder().decode(req.getData()));
        List<DataObject> files = dataObjectRepository.findByFileHash(fileHash);
        if (!CollectionUtils.isEmpty(files)){
            res.setFileId(files.get(0).getId());
            res.setFileName(req.getName());
            res.setFileType(files.get(0).getContentType());
            res.setFileSize(files.get(0).getSizeMb());
            res.setFileUrl("/sberx-gateway/file/" + files.get(0).getName());
        } else {
            res.setFileHash(fileHash);
        }
        return res;
    }

    protected void checkFile(String name) {
        DataObject dot = dataObjectRepository.findByName(name);
        if (dot != null) {
            dataObjectRepository.deleteById(dot.getId());
        }
    }

    private String shaSum(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            Formatter formatter = new Formatter();
            for (byte b : md.digest(data))
                formatter.format("%02x", b);
            return formatter.toString();
        } catch (Exception e) {
            log.error("Error getting hash: ", e);
            return null;
        }
    }

}

