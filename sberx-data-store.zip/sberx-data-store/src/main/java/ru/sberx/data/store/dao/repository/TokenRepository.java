package ru.sberx.data.store.dao.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.data.store.dao.model.Token;

import java.util.Date;
import java.util.Optional;

@Repository
public interface TokenRepository extends CrudRepository<Token, String> {
    @Query("from Token where expiresAt > current_timestamp ")
    Optional<Token> findByExpiresAt(Date s);
}
