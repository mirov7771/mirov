package ru.sberx.data.store.service.impl.v1.methods;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.data.store.controller.dto.res.FileMetaRes;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.stream.Collectors;

import static ru.sberx.data.store.validator.ConditionValidator.preValidate;

@Component
@RequiredArgsConstructor
@Slf4j
public class FileGet {

    protected final DataObjectRepository dataObjectRepository;

    public FileRes execute(String fileName, String sessionId) {
        log.info("Selecting file: {}", fileName);
        FileRes res = new FileRes();
        DataObject file = dataObjectRepository.findByName(fileName);
        preValidate(file, SberErrors.FILE_NOT_FOUND);
        String contentType = file.getContentType();
        if (!contentType.contains("png")
                && !contentType.contains("jpeg")
                && !contentType.contains("jpg")) {
            if (sessionId == null && file.getSecret() != null && !"".equals(file.getSecret()))
                throw new SberException(SberErrors.FILE_NOT_FOUND);
        }
        if(contentType.contains("application/pdf")){
            res.setFileName(file.getName());
        }
        res.setFileType(file.getContentType());
        CheckContent.validContent(file.getData(), 1);
        res.setData(new ByteArrayInputStream(file.getData()));
        return res;
    }

    public List<FileMetaRes> getMeta(List<String> id) {
        List<DataObject> files = dataObjectRepository.findByNameIn(id);
        if (files == null || files.size() == 0)
            return null;
        return files.stream().map(file -> {
            FileMetaRes res = new FileMetaRes();
            res.setId(file.getSysName());
            res.setCreateDate(file.getCreateDttm());
            res.setName(file.getName());
            res.setSize(file.getSizeMb());
            String[] fType = file.getContentType().split("/");
            if (fType.length > 0)
                res.setMimeType(fType[0]);
            if (fType.length > 1)
                res.setFileType(fType[1]);
            return res;
        }).collect(Collectors.toList());
    }
}
