package ru.sberx.data.store.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import java.util.HashSet;
import java.util.Set;

@Slf4j
public class CheckContent {

    private CheckContent(){}

    private static final Set<String> VALID_CONTENT = new HashSet<>();

    static {
        VALID_CONTENT.add("application/pdf");
        VALID_CONTENT.add("image/png");
        VALID_CONTENT.add("image/jpeg");
        VALID_CONTENT.add("application/vnd");
        VALID_CONTENT.add("application/msword");
        VALID_CONTENT.add("xml");
        VALID_CONTENT.add("application/octet-stream");
    }

    public static void validContent(byte[] bytes, int type){
        Tika tika = new Tika();
        String mimeType = tika.detect(bytes);
        log.info("checking content type {}", mimeType);
        boolean validContent = false;
        for(String s : VALID_CONTENT){
            if (mimeType.contains(s)){
                validContent = true;
                break;
            }
        }
        if (!Boolean.TRUE.equals(validContent) && type == 1){
            validContent = mimeType.contains("svg") || mimeType.contains("text");
        }
        if (!Boolean.TRUE.equals(validContent))
            throw new SberException(SberErrors.FAILED_TO_SAVE_FILE, "Incorrect mime type [" + mimeType + "]");
    }

}
