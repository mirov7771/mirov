package ru.sberx.data.store.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import ru.sberx.data.store.dao.repository.TokenRepository;

import java.util.TimeZone;

@Service
@RequiredArgsConstructor
@Slf4j
public class StartupShutdownEventListener {

    private final TokenRepository tokenRepository;

    @EventListener
    public void onStartup(ApplicationReadyEvent event) {
        try {
            log.info("time-zone {} ", TimeZone.getDefault().getID());
            TimeZone.setDefault(TimeZone.getTimeZone("GMT+3"));
            log.info("Started "+event.getApplicationContext().getId());
            tokenRepository.deleteAll();
        } catch (Exception e) {
            log.error("error: ", e);
        }
    }
}

