package ru.sberx.data.store.controller.mock.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class SubmitTaskRes {
    private String status;
    @JsonProperty("task_id")
    private String taskId;
    @JsonProperty("file_id")
    private String fileId;
    List<VerdictRes> verdicts;
}
