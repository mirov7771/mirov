package ru.sberx.data.store.service.impl.v2.methods;

import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.service.impl.v2.methods.antivirus.AntivirusService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.util.Base64;

import static ru.sberx.data.store.service.impl.v1.methods.CheckContent.validContent;

public abstract class FileV2 extends ru.sberx.data.store.service.impl.v1.methods.File {

    protected static final String DONE = "done";
    protected static final String IN_PROGRESS = "in_progress";
    protected static final String MALWARE = "malware";
    protected static final Base64.Decoder decoder = Base64.getDecoder();

    protected final AntivirusService antivirusService;

    public FileV2(
            DataObjectRepository dataObjectRepository,
            ApplicationConfig applicationConfig,
            AntivirusService antivirusService,
            UserAuthService userAuthService) {
        super(dataObjectRepository, applicationConfig, userAuthService);
        this.antivirusService = antivirusService;
    }

    public abstract FileRes execute(FileReq req);

    protected void checkData(FileReq req, DataObject dataObject) {
        byte[] bytes = decoder.decode(req.getData());
        if (!Boolean.TRUE.equals(req.getSaveName()))
            validContent(bytes, 0);
        AntivirusService.TaskInfo taskInfo = antivirusService.checkFile(req);
        dataObject.setSizeMb(getFileSize(bytes));
        dataObject.setTaskId(taskInfo.getTaskId());
        dataObject.setSha256(taskInfo.getFileId());
        if (taskInfo.getIsMalware() != null) {
            if (Boolean.FALSE.equals(taskInfo.getIsMalware())) {
                dataObject.setData(bytes);
                dataObject.setAvStatus(DONE);
            } else {
                dataObject.setAvStatus(MALWARE);
            }
        } else {
            dataObject.setAvStatus(IN_PROGRESS);
        }
        dataObjectRepository.save(dataObject);
    }

}
