package ru.sberx.data.store.service.impl.v2.methods;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.config.WebConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;
import ru.sberx.data.store.service.impl.v2.methods.antivirus.AntivirusService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.util.*;
import java.util.concurrent.CompletableFuture;

import static ru.sberx.data.store.validator.ConditionValidator.*;

@Component
@Slf4j
public class FileV2Post extends FileV2 {

    @Value("${application.antivirus.delay:7000}")
    private long delay;
    @Value("${application.antivirus.attempts:5}")
    private int attempts;

    public FileV2Post(
            AntivirusService antivirusService,
            DataObjectRepository dataObjectRepository,
            ApplicationConfig applicationConfig,
            UserAuthService userAuthService) {
        super(dataObjectRepository,
                applicationConfig,
                antivirusService,
                userAuthService);
    }

    @Override
    public FileRes execute(FileReq req) {
        log.info("start save file");
        if (!Boolean.TRUE.equals(req.getSaveName()))
            validateParams("post", req);
        validateFileName(req);
        FileRes fileRes = checkHash(req);
        if (!StringUtils.hasText(fileRes.getFileHash()))
            return fileRes;
        req.setUuidValue(UUID.randomUUID().toString());
        String requestId = ThreadContext.get(WebConfig.REQUEST_ID);
        CompletableFuture.runAsync(() -> {
            try {
                saveFile(req, requestId, fileRes.getFileHash());
            } catch (Exception e){
                log.error("Method \"saveFile\" throws exception", e);
            }
        });
        log.info("end save file");
        return createResponse(req);
    }

    private DataObject createDataObjectMetadata(FileReq req) {
        DataObject dataObject = new DataObject();
        dataObject.setContentType(req.getContentType());
        dataObject.setName(req.getUuidValue() + "_" + req.getName());
        dataObject.setSysName(req.getUuidValue());
        if (Boolean.TRUE.equals(req.getSaveName())) {
            String name = req.getName();
            checkFile(name);
            dataObject.setName(req.getName());
        } else {
            dataObject.setSecret(req.getSessionId());
        }
        dataObject.setAvStatus(IN_PROGRESS);
        dataObject.setCreateDttm(new Date());
        return dataObject;
    }

    private FileRes createResponse(FileReq req) {
        FileRes res = new FileRes();
        res.setFileType(req.getContentType());
        if (Boolean.TRUE.equals(req.getSaveName()))
            setUrl(res, req.getContentType(), req.getName());
        else
            setUrl(res, req.getContentType(), req.getUuidValue() + "_" + req.getName());
        res.setFileName(req.getName());
        return res;
    }

    void saveFile(FileReq req, String requestId, String fileHash){
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        DataObject dataObject = createDataObjectMetadata(req);
        dataObject.setFileHash(fileHash);
        dataObjectRepository.save(dataObject);
        checkData(req, dataObject);
        DataObject file = null;
        if (dataObject.getSha256() != null) {
            List<DataObject> existedObjects = dataObjectRepository.findBySha256(dataObject.getSha256());
            if (!CollectionUtils.isEmpty(existedObjects)){
                Optional<DataObject> data = existedObjects.stream().filter(i -> i.getData() != null && "done".equalsIgnoreCase(i.getAvStatus())).findFirst();
                if (data.isPresent()){
                    dataObject.setData(Base64.getDecoder().decode(req.getData()));
                    dataObject.setAvStatus(DONE);
                }
            }
            file = dataObjectRepository.save(dataObject);
        }
        preValidate(file, SberErrors.FAILED_TO_SAVE_FILE);
        if (IN_PROGRESS.equals(file.getAvStatus())) {
            Integer isMalware = isMalwareCheck(file.getTaskId(), 0);
            for(int i=0; i < attempts; i++){
                isMalware = isMalwareCheck(file.getTaskId(), i+1);
                if (!TASK_NOT_COMPLETED.equals(isMalware))
                    break;
            }
            if (IS_MALWARE.equals(isMalware)) {
                file.setAvStatus(MALWARE);
            } else {
                file.setAvStatus(DONE);
                file.setData(decoder.decode(req.getData()));
            }
            dataObjectRepository.save(file);
        }
        if (MALWARE.equals(file.getAvStatus())) {
            throw new SberException(SberErrors.FILE_DONT_PASS_AV_SCAN, "file is malware");
        }
    }

    private Integer isMalwareCheck(String taskId, int attempt){
        try {
            log.info("getting status in post method for task {}, attempt {}, delay {}", taskId, attempt, delay);
            Thread.sleep(delay);
            Boolean b = antivirusService.isMalware(taskId);
            return Boolean.TRUE.equals(b) ? 1 : 0;
        } catch (Exception e){
            log.error("error checking malware ", e);
            return 2;
        }
    }

}
