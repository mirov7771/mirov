package ru.sberx.data.store.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class FileReq {

    private Long id;
    private String name;
    private String newName;
    private String contentType;
    private String data;
    private String sessionId;
    private Boolean saveName;

    private String uuidValue;

    private List<Long> userIds;
    private List<String> roles;

    public FileReq(String name) {
        this.name = name;
    }

    public FileReq(String name, String sessionId) {
        this.name = name;
        this.sessionId = sessionId;
    }

    public FileReq(Long id) {
        this.id = id;
    }

    public FileReq(Long id, String sessionId) {
        this.id = id;
        this.sessionId = sessionId;
    }

    @Override
    public String toString(){
        return "id = "+id
                +", name = "+name
                +", contentType = "+contentType;
    }

}
