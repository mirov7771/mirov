package ru.sberx.data.store.service.impl.v2.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;
import ru.sberx.data.store.service.impl.v2.methods.antivirus.AntivirusService;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@Slf4j
public class FileV2AvStatus extends FileV2 {

    @Value("${application.antivirus.expiry}")
    private long expiryInSeconds;
    @Value("${application.antivirus.delay:7000}")
    private long delay;
    @Value("${application.antivirus.check:false}")
    public Boolean isVirusCheck;

    public FileV2AvStatus(
            AntivirusService antivirusService,
            DataObjectRepository dataObjectRepository,
            ApplicationConfig applicationConfig,
            UserAuthService userAuthService) {
        super(
                dataObjectRepository,
                applicationConfig,
                antivirusService,
                userAuthService);
    }

    @Override
    public FileRes execute(FileReq req) {
        execute();
        return null;
    }

    @Scheduled(cron = "${application.antivirus.update.cron}")
    private void execute() {
        if (!Boolean.TRUE.equals(isVirusCheck)){
            log.info("skip antivirus check");
            return;
        }
        dataObjectRepository.updateAVStatus(IN_PROGRESS, Date.from(Instant.now().minus(expiryInSeconds, ChronoUnit.SECONDS)));
        List<DataObject> files = dataObjectRepository.findByAvStatus(IN_PROGRESS);
        log.debug("Found files in progress: {}", files);
        List<DataObject> updatedFiles = files.stream().parallel().peek(this::setStatus).collect(Collectors.toList());
        dataObjectRepository.saveAll(updatedFiles);
    }

    public String getFileStatus(String id) {
        DataObject file = dataObjectRepository.findByName(id);
        if (file == null || file.getId() == null) {
            throw new SberException(SberErrors.FILE_NOT_FOUND);
        }
        if (file.getTaskId() != null
                && (file.getAvStatus() == null
                || IN_PROGRESS.equals(file.getAvStatus())))
        {
            setStatus(file);
            dataObjectRepository.save(file);
        }
        return Objects.requireNonNullElse(file.getAvStatus(), "no_scan");
    }

    private void setStatus(DataObject f){
        Boolean isMalware = true;
        log.info("getting status in job service for task {}", f.getTaskId());
        try {
            Thread.sleep(delay);
            isMalware = antivirusService.isMalware(f.getTaskId());
        } catch (Exception e){
            log.error("error checking status ", e);
        }

        if (Boolean.TRUE.equals(isMalware)) {
            f.setAvStatus(MALWARE);
        } else {
            f.setAvStatus(DONE);
            f.setData(antivirusService.downloadFile(f.getSha256()));
        }
        log.debug("Updating status of file {} to {}", f.getId(), f.getAvStatus());
    }

}
