package ru.sberx.data.store.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.InputStream;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class FileRes {

    @JsonProperty("fileUrl")
    private String fileUrl;
    @JsonProperty("fileName")
    private String fileName;
    @JsonProperty("fileType")
    private String fileType;
    @JsonProperty("fileId")
    private Long fileId;
    private Double fileSize;

    @JsonIgnore
    private InputStream data;
    @JsonIgnore
    private String fileHash;

    public FileRes(Long fileId) {
        this.fileId = fileId;
    }
}
