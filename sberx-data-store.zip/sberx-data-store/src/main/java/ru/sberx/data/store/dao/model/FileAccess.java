package ru.sberx.data.store.dao.model;

import com.vladmihalcea.hibernate.type.array.ListArrayType;
import lombok.*;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "file_access")
@NoArgsConstructor
@Getter
@Setter
@ToString
@TypeDefs({
        @TypeDef(name = "list-array", typeClass = ListArrayType.class),
})
public class FileAccess implements Serializable {
    @Id
    @Column(name="file_id")
    private Long fileId;

    @Type(type = "list-array")
    @Column(
            name = "allowed_users",
            columnDefinition = "bigint[]"
    )
    private List<Long> allowedUsers;

    @Type(type = "list-array")
    @Column(
            name = "allowed_roles",
            columnDefinition = "varchar[]"
    )
    private List<String> allowedRoles;

    public FileAccess(Long fileId) {
        this.fileId = fileId;
    }
}
