package ru.sberx.data.store.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class ApplicationConfig {

    @Value("${application.url}")
    private String url;
    @Value("${application.context}")
    private String context;

}
