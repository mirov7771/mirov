package ru.sberx.data.store.controller;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.data.store.builder.ResponseBuilder;
import ru.sberx.data.store.config.WebConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;
import ru.sberx.data.store.service.impl.v1.ServiceV1Impl;
import ru.sberx.data.store.service.impl.v2.ServiceV2Impl;
import ru.sberx.unity.gate.Utils;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class ServiceController {

    private final ServiceV1Impl serviceV1;
    private final ServiceV2Impl serviceV2;

    @Value("${application.antivirus.check:false}")
    public Boolean isVirusCheck;

    @GetMapping(value = "file/{name}")
    public void getFile(@RequestHeader(value = WebConfig.REQUEST_ID, required = false) String requestId,
                        @PathVariable("name") String name,
                        @RequestHeader(value = "sessionId", required = false) String sessionId,
                        HttpServletResponse response) {
        InputStream inputStream = null;
        OutputStream outputStream = null;
        try {
            FileRes file = serviceV1.select(name, sessionId);
            String ft = file.getFileType();
            String fn = file.getFileName();
            Utils.customFileHead(response, requestId, ft, fn);
            response.setContentType(file.getFileType());
            inputStream = file.getData();
            outputStream = response.getOutputStream();
            IOUtils.copy(inputStream, outputStream);
        } catch (IOException e) {
            throw new SberException(SberErrors.INTERNAL_SERVICE_ERROR, e.getMessage());
        } finally {
            IOUtils.closeQuietly(inputStream);
            IOUtils.closeQuietly(outputStream);
        }
    }

    @PostMapping(value = "file", produces = WebConfig.APPLICATION_JSON_VALUE)
    public ResponseEntity<FileRes> saveFile(@RequestHeader(WebConfig.REQUEST_ID) String requestId,
                                            @RequestBody FileReq req,
                                            @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId) {
        req.setSessionId(sessionId);
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        return ResponseBuilder.build(serviceV1.save(req));
    }

    @PutMapping(value = "file/{name}", produces = WebConfig.APPLICATION_JSON_VALUE)
    public ResponseEntity<FileRes> updateFile(@RequestHeader(WebConfig.REQUEST_ID) String requestId,
                                              @PathVariable("name") String name,
                                              @RequestBody FileReq req,
                                              @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId) {
        req.setName(name);
        req.setSessionId(sessionId);
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        return ResponseBuilder.build(serviceV1.update(req));
    }

    @PostMapping(value = "v2/file", produces = WebConfig.APPLICATION_JSON_VALUE)
    public ResponseEntity<FileRes> saveFileV2(@RequestHeader(WebConfig.REQUEST_ID) String requestId,
                                              @RequestBody FileReq req,
                                              @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId) {
        req.setSessionId(sessionId);
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        return ResponseBuilder.build(Boolean.TRUE.equals(isVirusCheck) ? serviceV2.save(req) : serviceV1.save(req));
    }

    @DeleteMapping(value = "file/{id}")
    public void deleteFile(@RequestHeader(WebConfig.REQUEST_ID) String requestId,
                           @PathVariable("id") Long id,
                           @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId) {
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        FileReq req;
        if (sessionId != null && !"".equals(sessionId))
            req = new FileReq(id, sessionId);
        else
            req = new FileReq(id);
        serviceV1.delete(req);
    }

    @PatchMapping(value = "/v2/files/av-scan")
    public void updateAvScanStatus(@RequestHeader(WebConfig.REQUEST_ID) String requestId) {
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        serviceV2.updateAvScanStatus();
    }

    @GetMapping(value = "/v2/files/{id}/status")
    public ResponseEntity<?> updateAvScanStatus(@RequestHeader(WebConfig.REQUEST_ID) String requestId, @PathVariable("id") String id) {
        ThreadContext.put(WebConfig.REQUEST_ID, requestId);
        return ResponseBuilder.build(Map.of("status", Boolean.TRUE.equals(isVirusCheck) ? serviceV2.getFileStatus(id) : "done"));
    }


    @PostMapping(value = "file/meta")
    public ResponseEntity<?> getFileMetaInfo(@RequestBody List<String> id) {
        return ResponseBuilder.build(serviceV1.selectMeta(id));
    }

}
