package ru.sberx.data.store.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import java.util.Base64;
import java.util.UUID;

import static ru.sberx.data.store.service.impl.v1.methods.CheckContent.validContent;
import static ru.sberx.data.store.validator.ConditionValidator.*;

@Component
@Slf4j
public class FilePost extends File {

    public FilePost(
            DataObjectRepository dataObjectRepository,
            ApplicationConfig applicationConfig,
            UserAuthService userAuthService) {
        super(dataObjectRepository, applicationConfig ,userAuthService);
    }

    @Override
    public FileRes execute(FileReq req) {
        log.info("start save file");
        validateParams("post", req);
        validateFileName(req);
        FileRes fileRes = checkHash(req);
        if (!StringUtils.hasText(fileRes.getFileHash()))
            return fileRes;
        byte[] bytes = Base64.getDecoder().decode(req.getData());
        if (!Boolean.TRUE.equals(req.getSaveName()))
            validContent(bytes, 0);
        FileRes res = new FileRes();
        DataObject dataObject = new DataObject();
        dataObject.setContentType(req.getContentType());
        dataObject.setName(UUID.randomUUID() + "_" + req.getName());
        dataObject.setSysName(UUID.randomUUID().toString());
        dataObject.setData(bytes);
        dataObject.setSizeMb(getFileSize(bytes));
        dataObject.setAvStatus("done");
        dataObject.setFileHash(fileRes.getFileHash());
        dataObject.setSha256(fileRes.getFileHash());
        if (Boolean.TRUE.equals(req.getSaveName())){
            String name = req.getName();
            checkFile(name);
            dataObject.setName(req.getName());
        } else {
            dataObject.setSecret(req.getSessionId());
        }
        DataObject file = dataObjectRepository.save(dataObject);
        preValidate(file, SberErrors.FAILED_TO_SAVE_FILE);
        res.setFileId(file.getId());
        res.setFileName(req.getName());
        res.setFileSize(file.getSizeMb());
        setUrl(res, req.getContentType(), file.getName());
        log.info("end save file");
        return res;
    }

}
