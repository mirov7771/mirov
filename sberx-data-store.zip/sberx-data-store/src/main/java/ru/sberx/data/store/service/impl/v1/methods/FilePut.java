package ru.sberx.data.store.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.data.store.config.ApplicationConfig;
import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.dao.model.DataObject;
import ru.sberx.data.store.dao.repository.DataObjectRepository;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.unity.gate.user.auth.UserAuthService;

import static ru.sberx.data.store.validator.ConditionValidator.preValidate;

@Component
@Slf4j
public class FilePut extends File {

    public FilePut(
            DataObjectRepository dataObjectRepository,
            ApplicationConfig applicationConfig,
            UserAuthService userAuthService) {
        super(dataObjectRepository, applicationConfig, userAuthService);
    }

    @Override
    public FileRes execute(FileReq req) {
        DataObject dataObject = dataObjectRepository.findByName(req.getName());
        preValidate(dataObject, SberErrors.FILE_NOT_FOUND);

        if(StringUtils.hasText(req.getNewName())){
            dataObject.setName(req.getNewName());
            dataObjectRepository.save(dataObject);
            log.debug("file has been renamed");
        }
        FileRes res = new FileRes();
        if (dataObject.getContentType() != null && dataObject.getName() != null){
            setUrl(res, dataObject.getContentType(), dataObject.getName());
        }
        res.setFileName(dataObject.getName());
        res.setFileType(dataObject.getContentType());
        res.setFileId(dataObject.getId());
        res.setFileSize(dataObject.getSizeMb());
        return res;
    }
}
