package ru.sberx.data.store.service;

import ru.sberx.data.store.controller.dto.req.FileReq;
import ru.sberx.data.store.controller.dto.res.FileRes;
import ru.sberx.data.store.controller.dto.res.FileMetaRes;
import ru.sberx.data.store.exception.SberErrors;
import ru.sberx.data.store.exception.SberException;

import java.util.List;

public interface Service {

    default FileRes select(String fileName, String sessionId) {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }
    default List<FileMetaRes> selectMeta(List<String> id) {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }
    default FileRes save(FileReq req) {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }
    default FileRes update(FileReq req) {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }
    default void delete(FileReq req) {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }
    default void updateAvScanStatus() {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }
    default String getFileStatus(String id) {
        throw new SberException(SberErrors.METHOD_DOES_NOT_EXIST);
    }


}
