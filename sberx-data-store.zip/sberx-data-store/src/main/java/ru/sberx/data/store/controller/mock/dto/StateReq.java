package ru.sberx.data.store.controller.mock.dto;

import lombok.Data;
import ru.sberx.data.store.controller.mock.MockAntivirusServiceController;

@Data
public class StateReq {
    private MockAntivirusServiceController.States newState;
}
