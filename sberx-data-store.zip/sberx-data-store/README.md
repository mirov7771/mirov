# Сервис хранения файлов

### sberx-data-store service

Confluence: https://sbtatlas.sigma.sbrf.ru/wiki/pages/viewpage.action?pageId=4019553435
