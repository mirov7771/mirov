# SBERX GATEWAY SERVICE

### sberx-gateway

Confluence:https://sbtatlas.sigma.sbrf.ru/wiki/display/SBERXMAIN/sberx-gateway
