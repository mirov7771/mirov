package ru.sberx.gateway.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import ru.sberx.dto.activity.req.CommentReq;
import ru.sberx.dto.activity.req.ReplyReq;
import ru.sberx.dto.activity.res.CommentGetRes;
import ru.sberx.dto.activity.res.CommentRes;
import ru.sberx.dto.activity.res.ReplyRes;
import ru.sberx.dto.chat.chats.req.NewChatReq;
import ru.sberx.dto.chat.chats.res.ChatListRes;
import ru.sberx.dto.chat.chats.res.ChatRes;
import ru.sberx.dto.chat.chats.support.UserDto;
import ru.sberx.dto.chat.messages.req.MessagesReq;
import ru.sberx.dto.chat.messages.req.NewMessageReq;
import ru.sberx.dto.chat.messages.res.MessageErrorRes;
import ru.sberx.dto.chat.messages.res.MessagesRes;
import ru.sberx.dto.data.store.req.FileReq;
import ru.sberx.dto.data.store.res.FileRes;
import ru.sberx.dto.guide.faq.req.CreateFaqQuestionReq;
import ru.sberx.dto.guide.faq.req.CreateQuestionReq;
import ru.sberx.dto.guide.faq.req.UpdateQuestionReq;
import ru.sberx.dto.guide.faq.res.CreateFaqQuestionRes;
import ru.sberx.dto.guide.faq.res.FaqListRes;
import ru.sberx.dto.guide.faq.support.GroupDto;
import ru.sberx.dto.guide.guide.res.GuideV2Res;
import ru.sberx.dto.mid.startuphub.req.SuccessStoryReq;
import ru.sberx.dto.mid.startuphub.res.ClientWorkspaceRes;
import ru.sberx.dto.mid.startuphub.res.ViewRes;
import ru.sberx.dto.notifications.req.PermissionReq;
import ru.sberx.dto.notifications.res.NoticeAmountRes;
import ru.sberx.dto.notifications.res.NoticeListRes;
import ru.sberx.dto.notifications.support.NoticeDto;
import ru.sberx.dto.onboarding.req.OnBoardingReq;
import ru.sberx.dto.onboarding.res.GetOnBoardingRes;
import ru.sberx.dto.onboarding.support.OnBoardingDto;
import ru.sberx.dto.partner.integration.req.AuthPostReq;
import ru.sberx.dto.partner.integration.res.AuthPostRes;
import ru.sberx.dto.partner.integration.res.CompaniesListRes;
import ru.sberx.dto.questionary.application.res.ApplicationListRes;
import ru.sberx.dto.questionary.application.support.ApplicationDto;
import ru.sberx.dto.questionary.community.res.CommunityListRes;
import ru.sberx.dto.questionary.community.support.CommunityDto;
import ru.sberx.dto.questionary.csi.req.PostCsiReq;
import ru.sberx.dto.questionary.manage.req.AddFavoriteReq;
import ru.sberx.dto.questionary.manage.req.VerifyReq;
import ru.sberx.dto.questionary.manage.res.VerifyRes;
import ru.sberx.dto.questionary.manage.res.ViewCardRes;
import ru.sberx.dto.questionary.metric.req.PostMetricReq;
import ru.sberx.dto.questionary.metric.res.GetMetricRes;
import ru.sberx.dto.questionary.metric.support.MetricTypeDto;
import ru.sberx.dto.questionary.popup.res.PopupStatusRes;
import ru.sberx.dto.questionary.questionary.feedback.support.FeedBackDto;
import ru.sberx.dto.questionary.questionary.pilot.res.PilotListRes;
import ru.sberx.dto.questionary.questionary.pilot.support.PilotDto;
import ru.sberx.dto.questionary.questionary.questionary.req.OffersReq;
import ru.sberx.dto.questionary.questionary.questionary.req.QuestionnaireReq;
import ru.sberx.dto.questionary.questionary.questionary.req.QuestionnaireUpdateReq;
import ru.sberx.dto.questionary.questionary.questionary.res.GetUserRes;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.questionary.questionary.questionary.support.QuestionnaireResponsibleDto;
import ru.sberx.dto.questionary.questionary.round.req.RoundReq;
import ru.sberx.dto.questionary.questionary.round.res.RoundListRes;
import ru.sberx.dto.questionary.questionary.round.support.RoundDto;
import ru.sberx.dto.questionary.reply.res.ReplyListRes;
import ru.sberx.dto.questionary.scouting.res.ScoutingListRes;
import ru.sberx.dto.questionary.scouting.support.ScoutingDto;
import ru.sberx.dto.questionary.statistic.support.StatisticDto;
import ru.sberx.dto.questionary.status.res.StatusInfoListRes;
import ru.sberx.dto.questionary.syndicate.res.SyndicateRes;
import ru.sberx.dto.questionary.syndicate.support.SyndicateDto;
import ru.sberx.dto.questionary.tariff.req.CheckTariffReq;
import ru.sberx.dto.questionary.tariff.req.PostTariffReq;
import ru.sberx.dto.questionary.tariff.support.TariffDto;
import ru.sberx.dto.questionary.tariff.support.TariffTypeDto;
import ru.sberx.dto.report.res.AuditRes;
import ru.sberx.dto.report.res.ReportRes;
import ru.sberx.dto.screen.builder.button.res.ButtonRes;
import ru.sberx.dto.screen.builder.menu.res.MenuRes;
import ru.sberx.dto.screen.builder.structure.page.res.GetFullPageRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetListRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetRes;
import ru.sberx.dto.screen.builder.widget.support.WidgetDto;
import ru.sberx.dto.services.company.req.CreateCompanyReq;
import ru.sberx.dto.services.company.req.UpdateCompanyReq;
import ru.sberx.dto.services.company.res.GetCompanyListRes;
import ru.sberx.dto.services.company.support.CompanyDto;
import ru.sberx.dto.services.service.req.CreateServiceReq;
import ru.sberx.dto.services.service.req.UpdateServiceReq;
import ru.sberx.dto.services.service.res.GetServiceListRes;
import ru.sberx.dto.services.service.res.ServiceWithCompanyRes;
import ru.sberx.dto.services.service.support.ServiceDto;
import ru.sberx.dto.services.support.ActivityDto;
import ru.sberx.dto.user.auth.req.ApplicationDeleteReq;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.dto.user.auth.res.CompanyUsersListRes;
import ru.sberx.dto.user.auth.res.ConsentRes;
import ru.sberx.dto.user.auth.res.UserListRes;
import ru.sberx.dto.user.auth.support.LastSessionDto;
import ru.sberx.dto.user.auth.support.Permission;
import ru.sberx.gateway.controller.dto.ErrorRes;
import ru.sberx.gateway.external.service.ExternalService;
import ru.sberx.gateway.gate.sberx.*;
import ru.sberx.gateway.util.Constants;
import ru.sberx.gateway.util.Constants.Headers;
import ru.sberx.metrics.Monitoring;

import java.awt.image.BufferedImage;
import java.time.Instant;
import java.util.*;

import static ru.sberx.constants.Constants.Header.AUTH_SESSION_ID;
import static ru.sberx.constants.Constants.Header.CLIENT_ID;
import static ru.sberx.constants.Constants.Header.REQUEST_ID;
import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.gateway.util.Constants.Headers.LOCALE;
import static ru.sberx.gateway.util.Constants.Headers.ROLE;
import static ru.sberx.gateway.util.Constants.Headers.USER_ID;
import static ru.sberx.gateway.util.Constants.Headers.*;
import static ru.sberx.gateway.util.Constants.getUserId;
import static ru.sberx.metrics.UnityMetricName.*;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Slf4j
public class ServiceController {

    private final UserAuthGate userAuthGate;
    private final GuideGate guideGate;
    private final MidStartUpHubGate midStartUpHubGate;
    private final QuestionaryGate questionaryGate;
    private final DataStoreGate dataStoreGate;
    private final ServicesGate servicesGate;
    private final ScreenBuilderGate screenBuilderGate;
    private final ExternalService externalService;
    private final ReportGate reportGate;
    private final PartnerIntegrationGate partnerIntegrationGate;
    private final ChatGate chatGate;
    private final OnboardingGate onboardingGate;
    private final NotificationGate notificationGate;

    private final static Set<String> reportsWithAccess = Set.of("sber500", "syndicate");

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод авторизации",
            description = "Позволяет авторизовать пользователя",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = "type", in = ParameterIn.PATH, required = true, description = "Тип авторизации", schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, description = "Идентификатор приложения", schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, description = "Выбранный язык", schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, description = "Идентификатор пользователя", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Авторизационный токен", schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "auth/{type}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_AUTH)
    public ResponseEntity<?> auth(@RequestHeader(REQUEST_ID) String requestId,
                                  @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                  @PathVariable("type") String type,
                                  @RequestBody Map<String, Object> req)
    {
        return userAuthGate.auth(requestId, locale, type, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод сохранения согласия",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Идентификатор сессии", required = true, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "consent", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_CONSENT)
    public ResponseEntity<?> consent(@RequestHeader(REQUEST_ID) String requestId,
                                     @RequestBody AuthReq req)
    {
        if (ThreadContext.get(USER_ID2) != null)
            req.setUserId(Long.valueOf(ThreadContext.get(USER_ID2)));
        return userAuthGate.saveConsent(requestId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод  получения ссылки на согласие",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ConsentRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, description = "Идентификатор приложения", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, required = true, description = "Идентификатор сессии", schema = @Schema(type = "string")),
                    @Parameter(name = "termsOfUse", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на Пользовательское соглашение", schema = @Schema(type = "boolean")),
                    @Parameter(name = "privacyPolicy", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на Политику конфедициальности", schema = @Schema(type = "boolean")),
                    @Parameter(name = "sber500PrivacyPolicy", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на Политику конфедициальности sber500", schema = @Schema(type = "boolean")),
                    @Parameter(name = "sber500Consent", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на согласие на участие в продукте Акселератор Сбера", schema = @Schema(type = "boolean")),
                    @Parameter(name = "sber500TermOfUse", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на согласие c Правилами участия в программе Sber500", schema = @Schema(type = "boolean")),
                    @Parameter(name = "sber500PersonalDataConsent", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на согласие c Политикой в области обработки и защиты персональных данных", schema = @Schema(type = "boolean")),
                    @Parameter(name = "mailingConsent", in = ParameterIn.QUERY, description = "Признак необходимости найти ссылку на согласие с рекламной рассылкой", schema = @Schema(type = "boolean"))
            }
    )
    @GetMapping(value = "consent", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_CONSENT)
    public ResponseEntity<?> getConsent(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                        @RequestParam(value = "termsOfUse", required = false) Boolean termsOfUse,
                                        @RequestParam(value = "privacyPolicy", required = false) Boolean privacyPolicy,
                                        @RequestParam(value = "sber500PrivacyPolicy", required = false) Boolean sber500PrivacyPolicy,
                                        @RequestParam(value = "sber500Consent", required = false) Boolean sber500Consent,
                                        @RequestParam(value = "sber500TermOfUse", required = false) Boolean sber500TermOfUse,
                                        @RequestParam(value = "sber500PersonalDataConsent", required = false) Boolean sber500PersonalDataConsent,
                                        @RequestParam(value = "mailingConsent", required = false) Boolean mailingConsent)
    {
        return userAuthGate.getConsent(requestId, termsOfUse, privacyPolicy, sber500PrivacyPolicy, sber500Consent, sber500TermOfUse, sber500PersonalDataConsent, mailingConsent);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Завершение сессии",
            description = "Метод выхода из сессии",
            responses = {
            @ApiResponse(responseCode = "401", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @DeleteMapping(value = "logout", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_LOGOUT)
    public ResponseEntity<?> logout(@RequestHeader(REQUEST_ID) String requestId,
                                    @CookieValue(AUTH_SESSION_ID) String sessionId)
    {
        userAuthGate.logout(requestId, sessionId);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод проверки сессии",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "401", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "checksession", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_CHECK_SESSION)
    public ResponseEntity<?> checkSession(@RequestHeader(REQUEST_ID) String requestId,
                                          @CookieValue(AUTH_SESSION_ID) String sessionId) {
        return userAuthGate.checkSession(requestId, sessionId);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Данные авторизации",
            description = " Метод получения данных для авторизации",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "401", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = CLIENT_ID, in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "preauthorize", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_PREAUTHORIZE)
    public ResponseEntity<?> preauthorize(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestHeader(Headers.CLIENT_ID) String clientId,
                                          @RequestParam Map<String, String> param)
    {
        return userAuthGate.preauthorize(requestId, clientId, param);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод авторизации",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "login", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_LOGIN)
    public ResponseEntity<?> login(@RequestHeader(REQUEST_ID) String requestId,
                                   @RequestHeader(Headers.CLIENT_ID) String clientId,
                                   @RequestBody Map<String, Object> req) {
        return userAuthGate.login(requestId, clientId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Регистрация пользователя",
            description = "Метод регистрации пользователя (для корпорации инвесторов)",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "registration", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_REGISTRATION)
    public ResponseEntity<?> registration(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                          @RequestHeader(Headers.CLIENT_ID) String clientId,
                                          @RequestBody Map<String, Object> req)
    {
        return userAuthGate.registration(requestId, locale, clientId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод для удаления пользователя",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = "questionnaireId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "isClient", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @DeleteMapping(value = "user/{questionnaireId}", consumes = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_USER)
    public ResponseEntity<?> deleteUser(@RequestHeader(REQUEST_ID) String requestId,
                                        @PathVariable Long questionnaireId,
                                        @RequestBody(required = false) Map<String, Object> req,
                                        @CookieValue(AUTH_SESSION_ID) String sessionId,
                                        @RequestParam(value = "isClient", required = false) Boolean isClient)
    {
        req.put("sessionId", sessionId);
        return userAuthGate.deleteUser(requestId, questionnaireId, req, isClient);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод создания пользователя",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "userId", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @DeleteMapping(value = "user", consumes = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_USER)
    public ResponseEntity<?> user(@RequestHeader(REQUEST_ID) String requestId,
                                  @RequestParam(value = "userId", required = false) Long userId,
                                  @RequestBody(required = false) Map<String, Object> req,
                                  @CookieValue(AUTH_SESSION_ID) String sessionId) {
        req.put("sessionId", sessionId);
        return userAuthGate.user(requestId, userId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод сброса/восстановления пароля",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "restore-password", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_RESTORE_PASSWORD)
    public ResponseEntity<?> restorePassword(@RequestHeader(REQUEST_ID) String requestId,
                                             @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                             @RequestHeader(Headers.CLIENT_ID) String clientId,
                                             @RequestBody Map<String, Object> req) {
        return userAuthGate.restorePassword(requestId, locale, clientId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод добавления разрешений",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = Permission.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = Permission.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "/permission", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_PERMISSION)
    public ResponseEntity<?> postPermission(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestBody Map<String, Object> req){
        return userAuthGate.postPermission(requestId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод изменения разрешений",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = Permission.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = Permission.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PutMapping(value = "/permission/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_PERMISSION)
    public ResponseEntity<?> putPermission(@RequestHeader(REQUEST_ID) String requestId,
                                           @PathVariable("id") Long id,
                                           @RequestBody Map<String, Object> req){
        return userAuthGate.putPermission(requestId, id, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод получения разрешений",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = Permission.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = Permission.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/permission/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_PERMISSION_LIST)
    public ResponseEntity<?> listPermission(@RequestHeader(REQUEST_ID) String requestId){
        return userAuthGate.listPermission(requestId);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод назначения разрешений роли",
            responses = {
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "/permission/role", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_PERMISSION_ROLE)
    public ResponseEntity<?> rolePermission(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestBody Map<String, Object> req){
        return userAuthGate.rolePermission(requestId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод получение пользователей",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = AuthRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/role/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_ROLE_LIST)
    public ResponseEntity<?> listRole(@RequestHeader(REQUEST_ID) String requestId){
        return userAuthGate.listRole(requestId);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод измнения роли",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = AuthRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "/role", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_ROLE)
    public ResponseEntity<?> postRole(@RequestHeader(REQUEST_ID) String requestId,
                                      @RequestBody Map<String, Object> req){
        return userAuthGate.postRole(requestId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод создания пользователя",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "user", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_USER)
    public ResponseEntity<?> createUser(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestBody Map<String, Object> req) {
        return userAuthGate.createUser(requestId, req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод получения пользователей",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = UserListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = "role", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "userRole", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "role", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "user/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_USER_LIST)
    public ResponseEntity<?> getList(@RequestHeader(REQUEST_ID) String requestId,
                                     @RequestParam(value = "role", required = false) String role,
                                     @RequestParam(value = "userRole", required = false) Integer userRole,
                                     @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                     @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                     @RequestParam(value = "name", required = false) String name) {
        return userAuthGate.getList(requestId, role, userRole, rowCount, pageToken, name);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Дата последнего посещения",
            description = "Метод для получения даты последнего посещения",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = LastSessionDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = "externalId", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "last-session", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_LAST_SESSION)
    public ResponseEntity<?> getLastSession(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestParam(value = "externalId", required = false) Long externalId) {
        return userAuthGate.getLastSession(requestId, externalId);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод удаления пользователя",
            description = "Получение заявки на удаление профиля пользователя",
            responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationDeleteReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Авторизационный токен", schema = @Schema(type = "string")),
            }
    )
    @DeleteMapping(value = "application-delete", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_APPLICATION_DELETE)
    public ResponseEntity<?> applicationDelete(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                               @RequestBody(required = false) Map<String, Object> req) {
        return userAuthGate.applicationDelete(requestId, ThreadContext.get(USER_ID), ThreadContext.get(ROLE), req);
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Дата последнего посещения",
            description = "Метод для получения даты последнего посещения",
            responses = {
                    @ApiResponse(responseCode = "200", content = {
                            @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CompanyUsersListRes.class))
                    }),
                    @ApiResponse(responseCode = "400", content = {
                            @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
                    })
            })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "companyuser/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_COMPANY_USER_LIST)
    public ResponseEntity<?> getCompanyUserList(@RequestHeader(REQUEST_ID) String requestId) {
        return userAuthGate.getCompanyUserList(requestId, getUserId());
    }

    @Tag(name = "user-auth", description = "Сервис авторизации")
    @Operation(
            summary = "Метод создания пользователя",
            responses = {
                    @ApiResponse(responseCode = "200", content = {
                            @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthRes.class))
                    }),
                    @ApiResponse(responseCode = "400", content = {
                            @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
                    })
            })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "companyuser", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_COMPANY_USER)
    public ResponseEntity<?> createCompanyUser(@RequestHeader(REQUEST_ID) String requestId,
                                               @RequestBody Map<String, Object> req) {
        return userAuthGate.createCompanyUser(requestId, getUserId(), req);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(type = "object"))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "guideId", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "isFilter", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
            }
    )
    @GetMapping(value = "guide", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_GUIDE)
    public ResponseEntity<?> guide(@RequestHeader(REQUEST_ID) String requestId,
                                   @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                   @RequestParam(value = "guideId", required = false) List<Long> guideId,
                                   @RequestParam(value = "isFilter", required = false) Boolean isFilter)
    {
        return guideGate.guide(requestId, locale, guideId, isFilter);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = GuideV2Res.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "guideId", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "parentId", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "name", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
                    @Parameter(name = "parentName", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
                    @Parameter(name = "isFilter", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
            }
    )
    @GetMapping(value = "v2/guide", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_GUIDE)
    public ResponseEntity<?> guideV2(@RequestHeader(REQUEST_ID) String requestId,
                                     @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                     @RequestParam(value = "guideId", required = false) List<Long> guideId,
                                     @RequestParam(value = "parentId", required = false) List<Long> parentId,
                                     @RequestParam(value = "name", required = false) List<String> name,
                                     @RequestParam(value = "parentName", required = false) List<String> parentName,
                                     @RequestParam(value = "isFilter", required = false) Boolean isFilter)
    {
        return guideGate.guideV2(requestId, locale, guideId, parentId, name, parentName, isFilter);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = FaqListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "groupName", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "search", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "/faq/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_FAQ_LIST)
    public ResponseEntity<?> getFaqList(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                        @RequestParam(value = "id", required = false) String id,
                                        @RequestParam(value = "groupName", required = false) String groupName,
                                        @RequestParam(value = "search", required = false) String search) {
        return guideGate.getFaqList(requestId, locale, id, groupName, search);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "faq/group", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_FAQ_GROUP)
    public ResponseEntity<?> createFaqTheme(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestBody Map<String, Object> req) {
        return guideGate.createFaqTheme(requestId, req);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateQuestionReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "faq/question", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_FAQ_QUESTION)
    public ResponseEntity<?> createQuestion(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestBody Map<String, Object> req) {
        return guideGate.createQuestion(requestId, req);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GroupDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @PutMapping(value = "/faq/group/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_FAQ_GROUP)
    public ResponseEntity<?> updateQuestionTheme(@RequestHeader(REQUEST_ID) String requestId,
                                                 @PathVariable("id") Long id,
                                                 @RequestBody Map<String, Object> req) {
        return guideGate.updateQuestionTheme(requestId, id, req);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateQuestionReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @PutMapping(value = "faq/question/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_FAQ_QUESTION)
    public ResponseEntity<?> updateQuestion(@RequestHeader(REQUEST_ID) String requestId,
                                            @PathVariable("id") Long id,
                                            @RequestBody Map<String, Object> req) {
        return guideGate.updateQuestion(requestId, id, req);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @DeleteMapping(value = "/faq/group/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_FAQ_GROUP)
    public ResponseEntity<?> deleteFaqQuestionTheme(@RequestHeader(REQUEST_ID) String requestId,
                                                    @PathVariable("id") Long id) {
        return guideGate.deleteFaqQuestionTheme(requestId, id);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateFaqQuestionRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @DeleteMapping(value = "/faq/question/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_FAQ_QUESTION)
    public ResponseEntity<?> deleteQuestion(@RequestHeader(REQUEST_ID) String requestId,
                                            @PathVariable("id") Long id) {
        return guideGate.deleteQuestion(requestId, id);
    }

    @Tag(name = "guide", description = "Сервис справочников")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = FaqListRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "value", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "/urlcheck", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_URL_CHECK)
    public ResponseEntity<?> urlCheck(@RequestHeader(REQUEST_ID) String requestId,
                                      @RequestParam(value = "value") String value) {
        return guideGate.urlCheck(requestId, value);
    }

    @Tag(name = "mid-startuphub", description = "Миддл слой")
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "filters", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "preauthorize", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "userId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "owner", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "isBran", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "isDisabled", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "birthDay", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "site", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "location", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "investorType", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "industry", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "innovationMethod", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "stady", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "geography", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "registrationCountry", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "communityState", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "category", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "myReplay", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "schema", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "investment", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "businessModel", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "forLending", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "companyId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "isAdmin", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "prioritySort", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "formName", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "mvpCode", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "technology", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "project_technology", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "investment_technology", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "project_geography", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "locationCountry", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "investment_geography", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "investment_industry", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "interactionType", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "round", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "staff", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = Headers.COOKIE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "filteredBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "pilotsPerCompany", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "sber500", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "favorite", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "responsible", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "main", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "replaceName", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
            }
    )
    @GetMapping(value = "v2/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_LIST)
    public ResponseEntity<?> listV2(@RequestHeader(Headers.CLIENT_ID) String clientId,
                                    @RequestHeader(REQUEST_ID) String requestId,
                                    @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                    @RequestParam(value = "type", required = false) List<Integer> type,
                                    @RequestParam(value = "filters", required = false) String filters,
                                    @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                    @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                    @RequestParam(value = "preauthorize", required = false) Boolean preauthorize,
                                    @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                    @RequestParam(value = "userId", required = false) Long userId,
                                    @RequestParam(value = "owner", required = false) Boolean owner,
                                    @RequestParam(value = "state", required = false) List<Long> state,
                                    @RequestParam(value = "name", required = false) String name,
                                    @RequestParam(value = "isBran", required = false) Boolean isBran,
                                    @RequestParam(value = "isDisabled", required = false) Boolean isDisabled,
                                    @RequestParam(value = "birthDay", required = false) Integer birthDay,
                                    @RequestParam(value = "site", required = false) Boolean site,
                                    @RequestParam(value = "location", required = false) String location,
                                    @RequestParam(value = "investorType", required = false) Long[] investorType,
                                    @RequestParam(value = "industry", required = false) Long[] industry,
                                    @RequestParam(value = "innovationMethod", required = false) Long[] innovationMethod,
                                    @RequestParam(value = "stady", required = false) Long[] stady,
                                    @RequestParam(value = "geography", required = false) Long[] geography,
                                    @RequestParam(value = "registrationCountry", required = false) Long[] registrationCountry,
                                    @RequestParam(value = "communityState", required = false) String communityState,
                                    @RequestParam(value = "category", required = false) Long category,
                                    @RequestParam(value = "myReplay", required = false) Boolean myReplay,
                                    @RequestParam(value = "schema", required = false) String schema,
                                    @RequestParam(value = "id", required = false) String id,
                                    @RequestParam(value = "investment", required = false) Boolean investment,
                                    @RequestParam(value = "businessModel", required = false) Long[] businessModel,
                                    @RequestParam(value = "forLending", required = false) Boolean forLending,
                                    @RequestParam(value = "companyId", required = false) Long companyId,
                                    @RequestParam(value = "isAdmin", required = false) Boolean isAdmin,
                                    @RequestParam(value = "prioritySort", required = false) Boolean prioritySort,
                                    @RequestParam(value = "formName", required = false) String formName,
                                    @RequestParam(value = "mvpCode", required = false) Long[] mvpCode,
                                    @RequestParam(value = "technology", required = false) Long[] technology,
                                    @RequestParam(value = "project_technology", required = false) Long[] project_technology,
                                    @RequestParam(value = "investment_technology", required = false) Long[] investment_technology,
                                    @RequestParam(value = "project_geography", required = false) Long[] project_geography,
                                    @RequestParam(value = "locationCountry", required = false) Long[] locationCountry,
                                    @RequestParam(value = "investment_geography", required = false) Long[] investmentGeography,
                                    @RequestParam(value = "investment_industry", required = false) Long[]  investmentIndustry,
                                    @RequestParam(value = "interactionType", required = false) Long[] interactionType,
                                    @RequestParam(value = "round", required = false) Long[] round,
                                    @RequestParam(value = "staff", required = false) Long[] staff,
                                    @RequestHeader(value = Headers.COOKIE, required = false) String cookie,
                                    @RequestParam(value = "filteredBy", required = false) String filteredBy,
                                    @RequestParam(value = "pilotsPerCompany", required = false) Integer pilotsPerCompany,
                                    @RequestParam(value = "sber500", required = false) Boolean sber500,
                                    @RequestParam(value = "sortBy", required = false) String sortBy,
                                    @RequestParam(value = "orderBy", required = false) String orderBy,
                                    @RequestParam(value = "favorite", required = false) Boolean favorite,
                                    @RequestParam(value = "responsible", required = false) Long responsible,
                                    @RequestParam(value = "main", required = false) Boolean main,
                                    @RequestParam(value = "view", required = false) Boolean view,
                                    @RequestParam(value = "search", required = false) String search,
                                    @RequestParam(value = "isPilotOffer", required = false) Boolean isPilotOffer,
                                    @RequestParam(value = "recommend", required = false) Boolean recommend,
                                    @RequestParam(value = "isImport", required = false) Boolean isImport,
                                    @RequestParam(value = "replaceName", required = false) String[] replaceName,
                                    @RequestParam(value = "sales", required = false) Boolean sales,
                                    @RequestParam(value = "startBirthDate", required = false) Integer startBirthDate,
                                    @RequestParam(value = "endBirthDate", required = false) Integer endBirthDate)
    {
        Long selectedUserId = userId;
        if (selectedUserId == null && ThreadContext.get(USER_ID) != null) {
            selectedUserId = Long.parseLong(ThreadContext.get(USER_ID));
        }

        return midStartUpHubGate.listV2(clientId,
                requestId,
                locale,
                type,
                filters,
                rowCount,
                questionnaireId,
                preauthorize,
                pageToken,
                selectedUserId,
                ThreadContext.get(ROLE),
                owner,
                state,
                name,
                isBran,
                isDisabled,
                birthDay,
                site,
                location,
                investorType,
                industry,
                innovationMethod,
                stady,
                geography,
                registrationCountry,
                communityState,
                category,
                myReplay,
                schema,
                id,
                investment,
                businessModel,
                forLending,
                companyId,
                isAdmin,
                prioritySort,
                formName,
                mvpCode,
                technology,
                project_technology,
                investment_technology,
                project_geography,
                locationCountry,
                investmentGeography,
                investmentIndustry,
                interactionType,
                round,
                staff,
                cookie,
                filteredBy,
                pilotsPerCompany,
                sber500,
                sortBy,
                orderBy,
                favorite,
                responsible,
                main,
                view,
                search,
                isPilotOffer,
                recommend,
                isImport,
                replaceName,
                sales,
                startBirthDate,
                endBirthDate);
    }

    @Tag(name = "mid-startuphub", description = "Миддл слой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ClientWorkspaceRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, schema = @Schema(type = "integer"))
            }
    )
    @GetMapping(value = "workspace/client", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_WORKSPACE_CLIENT)
    public ResponseEntity<?> workspaceClient(@RequestHeader(Headers.CLIENT_ID) String clientId,
                                             @RequestHeader(REQUEST_ID) String requestId,
                                             @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                             @RequestParam(value = "type", required = false) Integer type)
    {
        return midStartUpHubGate.workspaceClient(clientId, requestId, locale, type, getUserId(), ThreadContext.get(ROLE), ThreadContext.get(USER_LOGIN));
    }

    @Tag(name = "mid-startuphub", description = "Миддл слой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ViewRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "action", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "preauthorize", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "ui", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "uuid", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "admin", in = ParameterIn.QUERY, schema = @Schema(type = "Boolean")),
            }
    )
    @GetMapping(value = "view", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_VIEW)
    public ResponseEntity<?> view(@RequestHeader(Headers.CLIENT_ID) String clientId,
                                  @RequestHeader(REQUEST_ID) String requestId,
                                  @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                  @RequestParam(value = "action", required = false) Integer action,
                                  @RequestParam(value = "name", required = false) String name,
                                  @RequestParam(value = "type", required = false) Integer type,
                                  @RequestParam(value = "id", required = false) Long id,
                                  @RequestParam(value = "uid", required = false) String uid,
                                  @RequestParam(value = "preauthorize", required = false) Boolean pr,
                                  @RequestParam(value = "ui", required = false) String ui,
                                  @RequestParam(value = "uuid", required = false) String uuid,
                                  @RequestParam(value = "admin", required = false) Boolean admin) {
        Long userId = null;
        if (ThreadContext.get(USER_ID2) != null)
            userId = Long.valueOf(ThreadContext.get(USER_ID2));
        return midStartUpHubGate.view(clientId, requestId, locale, action, name, type, id, uid, pr, ui, uuid, admin, getUserId() != null ? getUserId() : userId, ThreadContext.get(ROLE));
    }

    @Tag(name = "mid-startuphub", description = "Миддл слой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = byte[].class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "uuid", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "link/{uuid}", produces = MediaType.IMAGE_PNG_VALUE)
    @Monitoring(GET_LINK)
    public ResponseEntity<BufferedImage> link(@RequestHeader(value = REQUEST_ID, required = false) String requestId,
                                              @PathVariable("uuid") String uid)
    {
        return midStartUpHubGate.link(requestId == null ? UUID.randomUUID().toString() : requestId, uid);
    }

    @Tag(name = "mid-startuphub", description = "Миддл слой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "401", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string"))
            }
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SuccessStoryReq.class))
            }
    )
    @PostMapping(value = "success-story", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_SUCCESS_STORY)
    public ResponseEntity<?> successStory(@RequestHeader(CLIENT_ID) String clientId,
                                          @RequestHeader(REQUEST_ID) String requestId,
                                          @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie,
                                          @RequestBody Map<String, Object> req) {
        return midStartUpHubGate.successStory(clientId, requestId, cookie, req);
    }


    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PilotDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PilotDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "pilot", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_PILOT)
    public ResponseEntity<?> postPilot(@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestBody Map<String, Object> req,
                                       @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId)
    {
        req.put("sessionId", sessionId);
        return questionaryGate.postPilot(requestId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PilotListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "pilotId", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "filteredBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "pilotsPerCompany", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "view", in = ParameterIn.QUERY, schema = @Schema(type = "Boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "pilot/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_PILOT_LIST)
    public ResponseEntity<?> pilotList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                       @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                       @RequestParam(value = "pilotId", required = false) List<Long> pilotId,
                                       @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                       @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                       @RequestParam(value = "name", required = false) String name,
                                       @RequestParam(value = "state", required = false) List<Long> states,
                                       @RequestParam(value = "filteredBy", required = false) String filteredBy,
                                       @RequestParam(value = "pilotsPerCompany", required = false) Integer pilotsPerCompany,
                                       @RequestParam(value = "view", required = false) Boolean view,
                                       @RequestParam(value = "favorite", required = false) Boolean favorite,
                                       @RequestParam(value = "sortBy", required = false) String sortBy,
                                       @RequestParam(value = "orderBy", required = false) String orderBy,
                                       @RequestParam(value = "filters", required = false) String filters,
                                       @RequestParam(value = "schema", required = false) String schema,
                                       @RequestParam(value = "myReply", required = false) Integer myReply,
                                       @RequestParam(value = "id", required = false) String id,
                                       @RequestParam(value = "industry", required = false) List<Long> industry)
    {
        return questionaryGate.pilotList(requestId, getUserId(), ThreadContext.get(ROLE), locale, pilotId, rowCount, pageToken, name, states, filteredBy, pilotsPerCompany, view, favorite, sortBy, orderBy, filters, schema, myReply, id, industry);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = FeedBackDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = FeedBackDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "feedback", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_FEEDBACK)
    public ResponseEntity<?> postFeedback(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestBody Map<String, Object> req)
    {
        return questionaryGate.postFeedback(requestId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = TypeRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = QuestionnaireReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "questionary", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_QUESTIONARY)
    public ResponseEntity<?> postQuestionary(@RequestHeader(REQUEST_ID) String requestId,
                                             @RequestBody Map<String, Object> req,
                                             @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId) {
        req.put("sessionId", sessionId);
        setListField(req, "project", "mvpCode");
        setListField(req, "project", "interactionType");
        setListField(req, "project", "technology");
        setListField(req, "project", "industry");
        setListField(req, "project", "geography");
        setListField(req, "project", "expansion");
        setListField(req, "project", "sales");
        setListField(req, "investment", "round");
        setListField(req, "investment", "industry");
        setListField(req, "investment", "technology");
        setListField(req, "investment", "geography");
        setListField(req, "questionnaire", "businessModel");
        setListField(req, "questionnaire", "industry");
        setListField(req, "questionnaire", "innovationMethod");
        setListField(req, "questionnaire", "interactionType");
        setListField(req, "questionnaire", "stady");
        setListField(req, "questionnaire", "acceleratorCode");

        return questionaryGate.postQuestionary(requestId, ThreadContext.get(USER_ID), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ScoutingListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, schema = @Schema(type = "list<long>")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer"))
            }
    )
    @GetMapping(value = "scouting/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SCOUTING_LIST)
    public ResponseEntity<?> scoutingList(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestParam(value = "name", required = false) String name,
                                          @RequestParam(value = "state", required = false) List<Long> state,
                                          @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                          @RequestParam(value = "pageToken", required = false) Integer pageToken) {
        return questionaryGate.scoutingList(requestId, name, state, rowCount, pageToken);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ScoutingDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "uid", in = ParameterIn.PATH, required = true, schema = @Schema(implementation = UUID.class))
            }
    )
    @GetMapping(value = "scouting/{uid}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SCOUTING)
    public ResponseEntity<?> getScoutingById(@RequestHeader(REQUEST_ID) String requestId,
                                             @PathVariable("uid") UUID uid) {
        return questionaryGate.getScoutingById(requestId, uid);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ScoutingDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ScoutingDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, required = true, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "scouting", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_SCOUTING)
    public ResponseEntity<?> saveScouting(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestBody Map<String, Object> req) {
        return questionaryGate.saveScouting(requestId, ThreadContext.get(USER_ID), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = VerifyRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = VerifyReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "verify", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_VERIFY)
    public ResponseEntity<?> verify(@RequestHeader(REQUEST_ID) String requestId,
                                    @RequestBody Map<String, Object> req,
                                    @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId)
    {
        req.put("sessionId", sessionId);
        return questionaryGate.verify(requestId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "application", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_APPLICATION)
    public ResponseEntity<?> postApplication(@RequestHeader(REQUEST_ID) String requestId,
                                             @RequestBody Map<String, Object> req)
    {
        return questionaryGate.postApplication(requestId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "uuid", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "application/{uuid}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_APPLICATION)
    public ResponseEntity<?> getApplicationByHash(@RequestHeader(REQUEST_ID) String requestId,
                                                  @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId,
                                                  @PathVariable("uuid") String hash)
    {
        return questionaryGate.getApplicationByHash(requestId, hash, StringUtils.hasText(sessionId));
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ApplicationListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "admin", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "list/application", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_LIST_APPLICATION)
    public ResponseEntity<?> getApplicationList(@RequestHeader(REQUEST_ID) String requestId,
                                                @RequestParam(value = "type", required = false) Integer type,
                                                @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                                @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                                @RequestParam(value = "state", required = false) List<Long> states,
                                                @RequestParam(value = "name", required = false) String name,
                                                @RequestParam(value = "admin", required = false) Boolean admin,
                                                @RequestParam(value = "sortBy", required = false) String sortBy,
                                                @RequestParam(value = "orderBy", required = false) String orderBy) {
        return questionaryGate.getApplicationList(requestId, type, rowCount, pageToken, states, name, admin, sortBy, orderBy);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PopupStatusRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "popup/{questionnaireId}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_POPUP)
    public ResponseEntity<?> getPopup(@RequestHeader(REQUEST_ID) String requestId,
                                      @PathVariable("questionnaireId") Long id) {
        return questionaryGate.getPopup(requestId, id);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = PopupStatusRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "v2/popup/{questionnaireId}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_POPUP)
    public ResponseEntity<?> getPopupV2(@RequestHeader(REQUEST_ID) String requestId,
                                        @PathVariable("questionnaireId") Long id) {
        return questionaryGate.getPopupV2(requestId, ThreadContext.get(CLIENT_ID), getUserId(), id);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = PopupStatusRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "v2/popup", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_POPUP)
    public ResponseEntity<?> getPopupByUserId(@RequestHeader(REQUEST_ID) String requestId) {
        return questionaryGate.getPopupByUserId(requestId, ThreadContext.get(CLIENT_ID), getUserId());
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = RoundDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "roundId", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "round", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_ROUND)
    public ResponseEntity<?> getRoundById(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestParam(value = "roundId", required = false) Long roundId) {
        return questionaryGate.getRoundById(requestId, roundId, getUserId());
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = RoundDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = RoundReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "round", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_ROUND)
    public ResponseEntity<?> round(@RequestHeader(REQUEST_ID) String requestId,
                                   @RequestBody Map<String, Object> req) {
        return questionaryGate.postRound(requestId, req, getUserId());
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(type = "string")))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "search/startup", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> searchStartup(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestParam(value = "name", required = false) String name) {
        return questionaryGate.search(requestId, "startup", name);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(type = "string")))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "search/corporate", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> searchCorporate(@RequestHeader(REQUEST_ID) String requestId,
                                             @RequestParam(value = "name", required = false) String name)
    {
        return questionaryGate.search(requestId, "corporate", name);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(type = "string")))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "search/investor", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> searchInvestor(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestParam(value = "name", required = false) String name)
    {
        return questionaryGate.search(requestId, "investor", name);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(type = "string")))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "search/pilot", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> searchPilot(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestParam(value = "name", required = false) String name)
    {
        return questionaryGate.search(requestId, "pilot", name);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ViewCardRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "uuid", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "view-card", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_VIEW_CARD)
    public ResponseEntity<?> viewCard(@RequestHeader(REQUEST_ID) String requestId,
                                      @RequestParam(value = "id", required = false) Long id,
                                      @RequestParam(value = "uuid", required = false) UUID uuid,
                                      @RequestHeader(value = Headers.COOKIE, required = false) String cookie) {
        return questionaryGate.viewCard(requestId, id, uuid, cookie);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = StatusInfoListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "direction", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "child", in = ParameterIn.QUERY, schema = @Schema(type = "boolean"))
            }
    )
    @GetMapping(value = "/questionary/{id}/status-history", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_STATUS_HISTORY)
    public ResponseEntity<?> getStatusHistory(@RequestHeader(REQUEST_ID) String requestId,
                                              @PathVariable("id") Long questionaryId,
                                              @RequestParam("type") Integer type,
                                              @RequestParam(value = "direction", required = false) String direction,
                                              @RequestParam(value = "child", required = false) Boolean child) {
        return questionaryGate.getStatusHistory(requestId, questionaryId, type, direction, child);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = StatisticDto.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "integer")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "dateFrom", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "dateTo", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "statistic", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_STATISTIC)
    public ResponseEntity<?> getStatistic(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestHeader(CLIENT_ID) String clientId,
                                          @RequestHeader(value = USER_ID, required = false) Long userId,
                                          @RequestParam(value = "type", required = false) List<Integer> type,
                                          @RequestParam(value = "dateFrom", required = false) Long dateFrom,
                                          @RequestParam(value = "dateTo", required = false) Long dateTo) {
        return questionaryGate.getStatistic(requestId, clientId, userId, type, dateFrom, dateTo);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = StatisticDto.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true,
                            description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true,
                            description = "Идентификатор приложения", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE,
                            description = "Авторизационный токен", schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "statistic/reply", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_STATISTIC)
    public ResponseEntity<?> getReplyStatistic(@RequestHeader(REQUEST_ID) String requestId,
                                               @RequestHeader(CLIENT_ID) String clientId) {
        return questionaryGate.getReplyStatistic(clientId, requestId, ThreadContext.get(ROLE));
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(type = "string")))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer")))
            }
    )
    @GetMapping(value = "smart-search", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> getSmartSearch(@RequestHeader(REQUEST_ID) String requestId,
                                            @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                            @RequestParam(value = "name", required = false) String name,
                                            @RequestParam(value = "type", required = false) List<String> type) {
        return questionaryGate.getSmartSearch(requestId,locale, name, type);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = GetUserRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "questionnaire/{id}/user", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_QUESTIONNAIRE_USER)
    public ResponseEntity<?> getUserById(@RequestHeader(REQUEST_ID) String requestId,
                                         @PathVariable("id") Long id) {
        return questionaryGate.getUserById(requestId, id);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = RoundListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "investment", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "admin", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "favorite", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "list/round", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_LIST_ROUND)
    public ResponseEntity<?> getRoundList(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestHeader(Headers.CLIENT_ID) String clientId,
                                          @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                          @RequestParam(value = "investment", required = false) Boolean investment,
                                          @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                          @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                          @RequestParam(value = "state", required = false) List<Long> state,
                                          @RequestParam(value = "name", required = false) String name,
                                          @RequestParam(value = "admin", required = false) Boolean admin,
                                          @RequestParam(value = "favorite", required = false) Boolean favorite,
                                          @RequestParam(value = "sortBy", required = false) String sortBy,
                                          @RequestParam(value = "orderBy", required = false) String orderBy) {
        return questionaryGate.getRoundList(requestId,
                clientId,
                getUserId(),
                ThreadContext.get(ROLE),
                questionnaireId,
                investment,
                rowCount,
                pageToken,
                state,
                name,
                admin,
                favorite,
                sortBy,
                orderBy);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PostMetricReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "metric", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_METRIC)
    public ResponseEntity<?> postMetric(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestHeader(Headers.CLIENT_ID) String clientId,
                                        @RequestBody Map<String, Object> req) {
        return questionaryGate.postMetric(requestId, clientId, getUserId(), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PostMetricReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PutMapping(value = "metric", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_METRIC)
    public ResponseEntity<?> putMetric(@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestHeader(Headers.CLIENT_ID) String clientId,
                                       @RequestBody Map<String, Object> req) {
        return questionaryGate.putMetric(requestId, clientId, getUserId(), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = GetMetricRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "beginDate", in = ParameterIn.QUERY, schema = @Schema(type = "date-time")),
                    @Parameter(name = "endDate", in = ParameterIn.QUERY, schema = @Schema(type = "date-time")),
                    @Parameter(name = "metricType", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "uuid", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "metric", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_METRIC)
    public ResponseEntity<?> getMetric(@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestHeader(Headers.CLIENT_ID) String clientId,
                                       @RequestParam(value = "beginDate") String beginDate,
                                       @RequestParam(value = "endDate") String endDate,
                                       @RequestParam(value = "metricType", required = false) Integer metricType,
                                       @RequestParam(value = "uuid", required = false) String uuid)
    {
        return questionaryGate.getMetric(requestId, clientId, getUserId(), beginDate, endDate, metricType, uuid);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = MetricTypeDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "addDate", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "uuid", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "metric/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_METRIC_LIST)
    public ResponseEntity<?> getMetricList(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestHeader(Headers.CLIENT_ID) String clientId,
                                           @RequestParam(value = "addData", required = false) Boolean addData,
                                           @RequestParam(value = "uuid", required = false) String uuid) {
        return questionaryGate.getMetricList(requestId, clientId, getUserId(), addData, uuid);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "metric", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @DeleteMapping(value = "metric/{metric}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_METRIC)
    public ResponseEntity<?> deleteMetric(@RequestHeader(REQUEST_ID) String requestId,
                                          @RequestHeader(Headers.CLIENT_ID) String clientId,
                                          @PathVariable("metric") Integer metric) {
       return questionaryGate.deleteMetric(requestId, clientId, getUserId(), metric);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AddFavoriteReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PutMapping(value = "add-favorite", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_ADD_FAVORITE)
    void putAddFavorite(@RequestHeader(REQUEST_ID) String requestId,
                        @RequestBody Map<String, Object> req) {
        if ("company".equals(req.get("objectType")) || "service".equals(req.get("objectType")))
            servicesGate.addFavorite(requestId, getUserId(), req);
        else
            questionaryGate.addFavoriteUpdate(requestId, getUserId(), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = RoundReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "roundId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
            }
    )
    @PutMapping(value = "round/{roundId}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_ROUND)
    public ResponseEntity<?> changeRound(@RequestHeader(REQUEST_ID) String requestId,
                                         @PathVariable("roundId") Long roundId,
                                         @RequestBody Map<String, Object> req) {
        return questionaryGate.changeRound(requestId, roundId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommunityDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommunityDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "/community", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_COMMUNITY)
    public ResponseEntity<?> saveCommunityBlank (@RequestHeader(REQUEST_ID) String requestId,
                                                 @RequestBody Map<String, Object> req,
                                                 @RequestHeader(value = Headers.COOKIE, required = false) String cookie) {
        return questionaryGate.saveCommunityBlank(requestId, req, cookie);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommunityDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommunityDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PutMapping(value = "/community/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_COMMUNITY)
    public ResponseEntity<?> updateCommunityBlank (@RequestHeader(REQUEST_ID) String requestId,
                                                   @PathVariable("id") Long id,
                                                   @RequestBody Map<String, Object> req,
                                                   @RequestHeader(value = Headers.COOKIE, required = false) String cookie) {
        return questionaryGate.updateCommunityBlank(requestId, id, req, cookie);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommunityDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/community", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_COMMUNITY)
    public ResponseEntity<?> getCommunityBlank (@RequestHeader(REQUEST_ID) String requestId,
                                                @RequestParam(value = "id", required = false) Long id,
                                                @RequestHeader(value = Headers.COOKIE, required = false) String cookie)
    {
        return questionaryGate.getCommunityBlank(requestId, id, cookie);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommunityListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "preauth", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "/community/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_COMMUNITY_LIST)
    public ResponseEntity<?> getCommunityBlankList(@RequestHeader(REQUEST_ID) String requestId,
                                                   @RequestParam(value = "id", required = false) Long id,
                                                   @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                                   @RequestParam(value = "state", required = false) Long[] state,
                                                   @RequestParam(value = "name", required = false) String name,
                                                   @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                                   @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                                   @RequestParam(value = "type", required = false) Integer type,
                                                   @RequestParam(value = "preauth", required = false) Boolean preAuth,
                                                   @RequestParam(value = "sortBy", required = false) String sortBy,
                                                   @RequestParam(value = "orderBy", required = false) String orderBy) {
        return questionaryGate.getCommunityBlankList(requestId, id, questionnaireId, state, name, rowCount, pageToken, type, preAuth, sortBy, orderBy);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SyndicateRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "/syndicate/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SYNDICATE_LIST)
    public ResponseEntity<?> syndicateList(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestParam(value = "state", required = false) List<Long> state,
                                           @RequestParam(value = "name", required = false) String name,
                                           @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                           @RequestParam(value = "pageToken", required = false) Integer pageToken) {
        return questionaryGate.getSyndicateList(requestId, state, name, rowCount, pageToken);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SyndicateRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/syndicate", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SYNDICATE)
    public ResponseEntity<?> getSyndicateQuestionnaire(@RequestHeader(REQUEST_ID) String requestId,
                                                       @RequestParam(value = "id", required = false) Long id,
                                                       @RequestParam(value = "uid", required = false) String uid) {
        return questionaryGate.getSyndicateQuestionnaire(requestId, id, uid);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SyndicateDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SyndicateDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "/syndicate", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_SYNDICATE)
    public ResponseEntity<?> saveSyndicate(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestBody Map<String, Object> req) {
        return questionaryGate.saveSyndicate(requestId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = QuestionnaireResponsibleDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = QuestionnaireResponsibleDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @PutMapping(value = "/questionary/{id}/responsible", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_RESPONSIBLE)
    public ResponseEntity<?> changeQuestionnaireResponsible(@RequestHeader(Headers.REQUEST_ID) String requestId,
                                                            @PathVariable("id") Long questionnaireId,
                                                            @RequestBody Map<String, Object> req) {
        return questionaryGate.changeQuestionnaireResponsible(requestId, questionnaireId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = OffersReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @PutMapping(value = "/questionary/{id}/offer", consumes = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_OFFER)
    public ResponseEntity<?> updateQuestionnaireOffer(@RequestHeader(Headers.REQUEST_ID) String requestId,
                                                      @PathVariable("id") String questionnaireId,
                                                      @RequestBody Map<String, Object> req) {
        return questionaryGate.updateQuestionnaireOffer(requestId, ThreadContext.get(ROLE), questionnaireId, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(
            summary = "Предложения пилотов",
            description = "Метод для управления корпорацией возможностью получения предложений пилотироваться от стартапов",
            responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = QuestionnaireUpdateReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true,
                            description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true,
                            description = "Идентификатор анкеты", schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE,
                            description = "Авторизационный токен", schema = @Schema(type = "string"))
            }
    )
    @PutMapping(value = "/questionary/{id}", consumes = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_QUESTIONARY)
    public ResponseEntity<?> updateQuestionnaire(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                                 @PathVariable("id") Long questionnaireId,
                                                 @RequestBody Map<String, Object> req){
        return questionaryGate.updateQuestionnaire(requestId, questionnaireId, ThreadContext.get(ROLE), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PostCsiReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "/csi", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_CSI)
    public void saveCsi(@RequestHeader(REQUEST_ID) String requestId,
                        @RequestHeader(Headers.CLIENT_ID) String clientId,
                        @RequestBody Map<String, Object> req) {
        questionaryGate.saveCsi(requestId, clientId, getUserId(), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CheckTariffReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "/tariff/check", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_TARIFF_CHECK)
    public void checkTariff(@RequestHeader(REQUEST_ID) String requestId,
                            @RequestBody Map<String, Object> req) {
        questionaryGate.checkTariff(requestId, ThreadContext.get(ROLE), getUserId(), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = TariffDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "questionnaireUuid", in = ParameterIn.QUERY, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/tariff", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_TARIFF)
    public ResponseEntity<?> getTariff(@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                       @RequestParam(value = "questionnaireUuid", required = false) String questionnaireUuid) {
        return questionaryGate.getTariff(requestId, ThreadContext.get(ROLE), getUserId(), questionnaireId, questionnaireUuid);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PostTariffReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "/tariff", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_TARIFF)
    public ResponseEntity<?> postTariff(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestBody Map<String, Object> req) {
        return questionaryGate.postTariff(requestId, ThreadContext.get(ROLE), getUserId(), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = TariffTypeDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "questionnaireId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "questionnaireUuid", in = ParameterIn.QUERY, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/tariff/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_TARIFF_LIST)
    public ResponseEntity<?> getTariffList(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                           @RequestParam(value = "questionnaireUuid", required = false) String questionnaireUuid) {
        return questionaryGate.getTariffList(requestId, questionnaireId, questionnaireUuid);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(type = "string")))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "search/vas", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> searchVas(@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestParam(value = "name", required = false) String name)
    {
        return servicesGate.search(requestId, name);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ServiceDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateServiceReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "vas", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_VAS)
    public ResponseEntity<?> saveService(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestBody Map<String, Object> req)
    {
        return servicesGate.saveService(requestId, req);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ServiceDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateServiceReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PutMapping(value = "vas", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_VAS)
    public ResponseEntity<?> updateService(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestBody Map<String, Object> req)
    {
        return servicesGate.updateService(requestId, req);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ServiceDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "vas/{vasId}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_VAS)
    public ResponseEntity<?> getVasInfo(@RequestHeader(REQUEST_ID) String requestId,
                                        @PathVariable("vasId") String vasId) {
        return servicesGate.getVasInfo(requestId, vasId);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetServiceListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "vasId", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "master", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "category", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "state", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "preauthorize", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "vas/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_VAS_LIST)
    public ResponseEntity<?> list(@RequestHeader(REQUEST_ID) String requestId,
                                  @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                  @RequestParam(value = "vasId", required = false) List<Long> vasId,
                                  @RequestParam(value = "name", required = false) String name,
                                  @RequestParam(value = "master", required = false) String master,
                                  @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                  @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                  @RequestParam(value = "category", required = false) List<Long> category,
                                  @RequestParam(value = "state", required = false) Integer state,
                                  @RequestParam(value = "preauthorize", required = false) Boolean preauthorize,
                                  @RequestParam(value = "sortBy", required = false) String sortBy,
                                  @RequestParam(value = "orderBy", required = false) String orderBy,
                                  @RequestParam(value = "uid", required = false) String uid) {
        return servicesGate.list(requestId, locale, vasId, name, master, rowCount, pageToken, category, state, preauthorize, sortBy, orderBy, uid);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CompanyDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "companyId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "company/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_COMPANY)
    public ResponseEntity<?> getCompany(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestHeader(value = LOCALE, required = false) String locale,
                                        @PathVariable(value = "id") String id,
                                        @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                        @RequestParam(value = "pageToken", required = false) Integer pageToken) {
        return servicesGate.getCompany(requestId, getUserId(), locale, id, rowCount, pageToken);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetCompanyListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "isImport", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "uid", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "favorites", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "view", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "replaceName", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "string"))),
            }
    )
    @GetMapping(value = "company/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_COMPANY_LIST)
    public ResponseEntity<?> listCompany(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestHeader(value = LOCALE, required = false) String locale,
                                         @RequestParam(value = "name", required = false) String name,
                                         @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                         @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                         @RequestParam(value = "sortBy", required = false) String sortBy,
                                         @RequestParam(value = "orderBy", required = false) String orderBy,
                                         @RequestParam(value = "isImport", required = false) Boolean isImport,
                                         @RequestParam(value = "uid", required = false) String uid,
                                         @RequestParam(value = "favorites", required = false) Boolean favorites,
                                         @RequestParam(value = "view", required = false) Boolean view,
                                         @RequestParam(value = "replaceName", required = false) String[] replaceName) {
        return servicesGate.listCompany(requestId, locale, getUserId(), name, rowCount, pageToken, sortBy, orderBy, isImport, uid, favorites, view, replaceName);

    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ServiceWithCompanyRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "vasId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "vas/{vasId}/company", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_VAS_COMPANY)
    public ResponseEntity<?> vasAndCompany(@RequestHeader(REQUEST_ID) String requestId,
                                           @PathVariable("vasId") String vasId) {
        return servicesGate.vasAndCompany(requestId, vasId);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CompanyDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CreateCompanyReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "company", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_COMPANY)
    public ResponseEntity<?> saveCompany(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestBody Map<String, Object> req) {
        return servicesGate.saveCompany(requestId, getUserId(), req);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CompanyDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = UpdateCompanyReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PutMapping(value = "company", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_COMPANY)
    public ResponseEntity<?> updateCompany(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestBody Map<String, Object> req) {
        return servicesGate.updateCompany(requestId, req);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CompanyDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "serviceId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @PostMapping(value = "company/activity/{serviceId}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_COMPANY_ACTIVITY)
    public void updateClickAndView(@RequestHeader(REQUEST_ID) String requestId,
                                   @PathVariable(value = "serviceId") String serviceId,
                                   @RequestBody Map<String, Object> req){
        servicesGate.updateClickAndView(requestId, serviceId, req);
    }

    @Tag(name = "services", description = "Сервис работы с сервисами (VAS)")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ActivityDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "add-activity", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_ADD_ACTIVITY)
    public void addActivity(@RequestHeader(REQUEST_ID) String requestId,
                            @RequestBody Map<String, Object> req){
        servicesGate.addActivity(requestId, getUserId(), req);
    }

    @GetMapping(value = "add-activity", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_ADD_ACTIVITY)
    public void addActivity(@RequestHeader(REQUEST_ID) String requestId,
                            @RequestParam("id") Long id,
                            @RequestParam("objectType") String objectType,
                            @RequestParam("activity") String activity) {
        Map<String, Object> req = new HashMap<>();
        req.put("id", id);
        req.put("objectType", objectType);
        req.put("activity", activity);
        servicesGate.addActivity(requestId, getUserId(), req);
    }

    @Tag(name = "data-store", description = "Сервис работы с файлами")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = MediaType.ALL_VALUE, schema = @Schema(implementation = byte[].class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "file/{name}")
    @Monitoring(GET_FILE)
    public ResponseEntity<?> getFile(@PathVariable("name") String name,
                                     @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId) {
        return dataStoreGate.getFile(UUID.randomUUID().toString(), name, sessionId);
    }

    @Tag(name = "data-store", description = "Сервис работы с файлами")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = FileRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = FileReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "file", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_FILE)
    public ResponseEntity<?> saveFile(@RequestHeader(REQUEST_ID) String requestId,
                                      @RequestBody Map<String, Object> req,
                                      @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId)
    {
        int i = 0;
        ResponseEntity<?> response = null;
        req.put("sessionId", sessionId);
        try {
            response = dataStoreGate.saveFileV2(requestId, req);
        } catch (Exception e) {
            e.printStackTrace();
            i = 1;
        }
        if (i != 0){
            try {
                response = dataStoreGate.saveFileV2(requestId, req);
            } catch (Exception e) {
                e.printStackTrace();
                response = dataStoreGate.saveFile(requestId, req);
            }
        }

        return response;
    }

    @Tag(name = "data-store", description = "Сервис работы с файлами")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(type = "object"))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "/v2/files/{id}/status", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_FILE_STATUS)
    ResponseEntity<?> getAvScanStatus(@RequestHeader(REQUEST_ID) String requestId,
                                      @PathVariable("id") String id) {
        try {
            return dataStoreGate.getAvScanStatus(requestId, id);
        } catch (Exception e) {
            return ResponseEntity.ok(Map.of("status", "done"));
        }
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = MenuRes.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "menu", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_MENU)
    private ResponseEntity<?> menu(@RequestHeader(REQUEST_ID) String requestId,
                                   @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                   @RequestParam("type") Integer type,
                                   @RequestParam("name") String name,
                                   @RequestParam(value = "id", required = false) Long id) {
        return screenBuilderGate.menu(requestId, locale, ThreadContext.get(ROLE), type, name, id);
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = WidgetListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "features", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_FEATURES)
    public ResponseEntity<?> features(@RequestHeader(REQUEST_ID) String requestId,
                               @RequestHeader(value = HttpHeaders.LOCATION, required = false) String location) {
        return screenBuilderGate.features(requestId, getUserId(), location);
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = WidgetRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = WidgetDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @PostMapping(value = "feature", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_FEATURE)
    public ResponseEntity<?> featureSave(@RequestHeader(REQUEST_ID) String requestId,
                                  @RequestBody Map<String, Object> req) {
        return screenBuilderGate.featureSave(requestId, req);
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @DeleteMapping(value = "feature/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_FEATURE)
    void featureDelete(@RequestHeader(REQUEST_ID) String requestId,
                       @PathVariable("id") Long id) {
        screenBuilderGate.featureDelete(requestId, id);
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = WidgetDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
            }
    )
    @PutMapping(value = "feature/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_FEATURE)
    void featureUpdate(@RequestHeader(REQUEST_ID) String requestId,
                       @PathVariable("id") Long id,
                       @RequestBody Map<String, Object> req){
        screenBuilderGate.featureUpdate(requestId, id, req);
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetFullPageRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = HttpHeaders.LOCATION, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = HttpHeaders.ACCEPT_LANGUAGE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "showHidden", in = ParameterIn.HEADER, schema = @Schema(type = "boolean")),
                    @Parameter(name = "featureStatus", in = ParameterIn.HEADER, array = @ArraySchema(schema = @Schema(type = "string"))),
            }
    )
    @GetMapping(value = "structure/pages", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_PAGES)
    public ResponseEntity<?> getPage(@RequestHeader(REQUEST_ID) String requestId,
                                     @RequestHeader(value = HttpHeaders.LOCATION, defaultValue = "/root") String pageUri,
                                     @RequestHeader(value = LOCALE, required = false) String locale,
                                     @RequestHeader(value = HttpHeaders.ACCEPT_LANGUAGE, required = false) String language,
                                     @RequestParam(value = "showHidden", required = false) Boolean showHidden,
                                     @RequestParam(value = "featureStatus", required = false) List<String> featureStatuses ) {
        return screenBuilderGate.getPage(requestId, ThreadContext.get(USER_ID), ThreadContext.get(ROLE), locale, pageUri, language, showHidden, featureStatuses);
    }

    @Tag(name = "screen-builder", description = "Сервис построения экранных форм")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ButtonRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "buttons", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_BUTTONS)
    public ResponseEntity<?> buttons(@RequestHeader(REQUEST_ID) String requestId,
                                     @RequestHeader(value = LOCALE, required = false, defaultValue = "ru") String locale,
                                     @RequestParam(value = "name", required = false) String name,
                                     @RequestParam(value = "type", required = false) Integer type,
                                     @RequestParam(value = "id", required = false) Long questionnaireId,
                                     @RequestHeader(value = Headers.COOKIE, required = false) String cookie) {
        return screenBuilderGate.buttons(requestId, locale, name, type, questionnaireId, cookie);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ReplyRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ReplyReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @SuppressWarnings("unchecked")
    @PostMapping(value = "reply", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_REPLY)
    public ResponseEntity<?> postReply(@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                                       @RequestBody Map<String, Object> req) {
        if (req.get("response") != null
                && req.get("response") instanceof List
                && req.get("reply") != null
                && req.get("reply") instanceof Map) {
            Map<String, Object> pilot = new HashMap<>();
            Map<String, Object> reply = (Map<String, Object>) req.get("reply");
            pilot.put("pilotId", reply.get("tableId"));
            pilot.put("response", req.get("response"));
            log.info("create response {}", pilot);
            questionaryGate.postPilot(requestId, pilot);
        }
        return questionaryGate.postReply(requestId, getUserId(), locale, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ReplyListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, description = "Выбранный язык", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Авторизационный токен", schema = @Schema(type = "string")),
                    @Parameter(name = "rowcount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "state", in = ParameterIn.QUERY, schema = @Schema(type = "long[]")),
                    @Parameter(name = "id", in = ParameterIn.QUERY, schema = @Schema(type = "long[]")),
                    @Parameter(name = "schema", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "name", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "view", in = ParameterIn.QUERY, schema = @Schema(type = "boolean")),
                    @Parameter(name = "sortBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "orderBy", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "isPilotOffer", in = ParameterIn.QUERY, schema = @Schema(type = "boolean"))
            }
    )
    @GetMapping(value = "reply/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_REPLY_LIST)
    public ResponseEntity<?> getReplyList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                                   @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                   @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                   @RequestParam(value = "state", required = false) List<Long> states,
                                   @RequestParam(value = "id", required = false) List<Long> id,
                                   @RequestParam(value = "schema", required = false) String schema,
                                   @RequestParam(value = "name", required = false) String name,
                                   @RequestParam(value = "view", required = false) Boolean view,
                                   @RequestParam(value = "orderBy", required = false) String orderBy,
                                   @RequestParam(value = "sortBy", required = false) String sortBy,
                                   @RequestParam(value = "isPilotOffer", required = false) Boolean isPilotOffer){
        return questionaryGate.getReplyList(requestId, getUserId(), ThreadContext.get(ROLE), locale, rowCount, pageToken, states, id, schema, name, view, sortBy, orderBy, isPilotOffer);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommentRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommentReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Авторизационный токен", schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "comment", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_COMMENT)
    public ResponseEntity<?> postComment(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestBody Map<String, Object> req) {
        return questionaryGate.postComment(requestId, getUserId(), ThreadContext.get(ROLE), ThreadContext.get(USER_LOGIN), req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommentReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, required = true, schema = @Schema(type = "string"))
            }
    )
    @PutMapping(value = "comment/{id}", consumes = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_COMMENT)
    public void updateComment(@RequestHeader(REQUEST_ID) String requestId,
                              @PathVariable("id") Long id,
                              @RequestBody Map<String, Object> req) {
        questionaryGate.updateComment(requestId, getUserId(), id, req);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommentGetRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Авторизационный токен", schema = @Schema(type = "string")),
                    @Parameter(name = "tableId", in = ParameterIn.QUERY, required = true, description = "Идентификатор объекта", schema = @Schema(type = "string")),
                    @Parameter(name = "tableName", in = ParameterIn.QUERY, required = true, description = "Тип объекта", schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "comment", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_COMMENT)
    public ResponseEntity<?> getComment(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestParam("tableId") Long tableId,
                                        @RequestParam("tableName") String tableName) {
        return questionaryGate.getComment(requestId, ThreadContext.get(ROLE), tableId, tableName);
    }

    @Tag(name = "questionary", description = "Сервис работы с анкетой")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = CommentReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, description = "Уникальный идентификатор запроса", schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, description = "Авторизационный токен", schema = @Schema(type = "string"))
            }
    )
    @DeleteMapping(value = "comment/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_COMMENT)
    public void deleteComment(@RequestHeader(REQUEST_ID) String requestId,
                              @PathVariable("id") Long id) {
        questionaryGate.deleteComment(requestId, Long.valueOf(ThreadContext.get(USER_ID)), id);
    }

    @Tag(name = "report", description = "Сервис построения отчетов")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ReportRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "userId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "reportId", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "dateFrom", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "dateTo", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "companyId", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
            }
    )
    @GetMapping(value = "report")
    @Monitoring(GET_REPORT)
    public ResponseEntity<?> getReport(@RequestHeader(Headers.CLIENT_ID) String clientId,
                                     @RequestHeader(value = REQUEST_ID, required = false) String requestId,
                                     @CookieValue(value = AUTH_SESSION_ID, required = false) String sessionId,
                                     @RequestParam(value = "userId", required = false) Long userId,
                                     @RequestParam(value = "reportId") String reportId,
                                     @RequestParam(value = "dateFrom", required = false) Long dateFrom,
                                     @RequestParam(value = "dateTo", required = false) Long dateTo,
                                     @RequestParam(value = "companyId", required = false) Long companyId,
                                     @RequestParam(value = "type", required = false) List<Integer> type)
    {
        Boolean reportsUse = null;
        if (reportsWithAccess.contains(reportId.toLowerCase(Locale.ROOT)) && StringUtils.hasText(sessionId)){
            reportsUse = Boolean.TRUE.equals(Boolean.valueOf(ThreadContext.get("reportsUse")));
        }
        return reportGate.getFile(clientId, requestId, ThreadContext.get(USER_ID2), userId, reportId, dateFrom, dateTo, companyId, type, reportsUse);
    }

    @Tag(name = "report", description = "Сервис построения отчетов")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(
                            schema = @Schema(implementation = AuditRes.class, type = "array")
                    ))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "audit")
    @Monitoring(GET_AUDIT)
    public ResponseEntity<?> getAudit(@RequestHeader(Headers.CLIENT_ID) String clientId,
                                      @RequestHeader(value = REQUEST_ID) String requestId)
    {
        return reportGate.getAudit(clientId, requestId);
    }

    @Tag(name = "partner-integration", description = "Сервис интеграции с партнерами")
    @Operation(summary = "Метод получения списка компаний по параметрам", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(
                            schema = @Schema(implementation = CompaniesListRes.class, type = "array")
                    ))
            }),
            @ApiResponse(responseCode = "401", description = "Не переданы authorization и/или client-id", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1002,\n" +
                                    "  \"message\": \"Invalid session\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "400", description = "Не переданы обязательные параметры", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1004,\n" +
                                    "  \"message\": \"Не переданы обязательные параметры\",\n" +
                                    "  \"details\": \"список не переданных обязательных параметров FromDateTime\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "400", description = "Неправильный формат запроса", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1018,\n" +
                                    "  \"message\": \"Неправильный формат запроса\",\n" +
                                    "  \"details\": \"Неправильный формат запроса (fromDateTime > toDateTime)\"\n" +
                                    "}"))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, description = "Идентификатор вызывающей системы", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "authorization", in = ParameterIn.HEADER, description = "Сессионный токен из выдачи /auth POST", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, description = "Тип компании", array = @ArraySchema(schema = @Schema(type = "string"))),
                    @Parameter(name = "fromDateTime", in = ParameterIn.QUERY, description = "Дата и время нижнего диапазона поиска", required = true, schema = @Schema(type = "date-time")),
                    @Parameter(name = "toDateTime", in = ParameterIn.QUERY, description = "Дата и время верхнего диапазона поиска в формате", schema = @Schema(type = "date-time")),
                    @Parameter(name = "pageSize", in = ParameterIn.QUERY, description = "Максимальное количество анкет в ответе", schema = @Schema(type = "integer")),
                    @Parameter(name = "pageNumber", in = ParameterIn.QUERY, description = "Номер пакета с анкетами", schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "/partner/companies/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(BRAN)
    public ResponseEntity<?> getCompaniesList (@RequestHeader(REQUEST_ID) String requestId,
                                               @RequestHeader(Headers.CLIENT_ID) String clientId,
                                               @RequestHeader("authorization") String sessionId,
                                               @RequestParam(value = "type", required = false) List<String> type,
                                               @RequestParam(value = "fromDateTime", required = false) String fromDateTime,
                                               @RequestParam(value = "toDateTime", required = false) String toDateTime,
                                               @RequestParam(value = "pageSize", required = false) Integer pageSize,
                                               @RequestParam(value = "pageNumber", required = false) Integer pageNumber){
        return partnerIntegrationGate.getCompaniesList(requestId,clientId, sessionId, type, fromDateTime, toDateTime, pageSize, pageNumber);
    }

    @Tag(name = "partner-integration", description = "Сервис интеграции с партнерами")
    @Operation(summary = "Метод получения файла по уникальному идентификатору", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM_VALUE, schema = @Schema(implementation = byte[].class))
            }),
            @ApiResponse(responseCode = "401", description = "Не передан или передан невалидный авторизационный токен", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1002,\n" +
                                    "  \"message\": \"Invalid session\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Файл не найден", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1005,\n" +
                                    "  \"message\": \"Файл не найден\"\n" +
                                    "}"))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, description = "Идентификатор вызывающей системы", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "authorization", in = ParameterIn.HEADER, description = "Сессионный токен из выдачи /auth POST", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, description = "Уникальный идентификатор файла", required = true, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "/partner/files/{id}")
    @Monitoring(BRAN)
    public ResponseEntity<?> getFilesId (@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestHeader(Headers.CLIENT_ID) String clientId,
                                         @RequestHeader("authorization") String sessionId,
                                         @PathVariable(value = "id") String id){
        return partnerIntegrationGate.getFilesId(requestId, clientId, sessionId, id);
    }

    @Tag(name = "partner-integration", description = "Сервис интеграции с партнерами")
    @Operation(summary = "Метод авторизации партнера", responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthPostRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"accessToken\": \"19d7e392-ee5c-4468-93a5-d74a166df452\",\n" +
                                    "  \"accessTokenExpireDate\": \"2021-10-06T12:32:53.490+03:00\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Не найден объект", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": 1020,\n" +
                                    "  \"message\": \"Ошибка доступа: не найден объект\"\n" +
                                    "}"))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, description = "Идентификатор приложения", required = true, schema = @Schema(type = "string")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, description = "Уникальный идентификатор запроса", required = true, schema = @Schema(type = "string")),
            }
    )
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода auth",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = AuthPostReq.class))
            }
    )
    @PostMapping(value = "/partner/auth", produces = APPLICATION_JSON_VALUE)
    @Monitoring(BRAN)
    public ResponseEntity<?> postAuth (@RequestHeader(REQUEST_ID) String requestId,
                                       @RequestHeader(Headers.CLIENT_ID) String clientId,
                                       @RequestBody Map<String, Object> req){
        return partnerIntegrationGate.postAuth(requestId, clientId, req);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = UserDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "users/me", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserInfo(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestHeader(Headers.CLIENT_ID) String clientId) {
        return chatGate.getUserInfo(requestId, clientId, ThreadContext.get(USER_ID));
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ChatRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NewChatReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "chats", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveChat(@RequestHeader(REQUEST_ID) String requestId,
                                      @RequestBody Map<String, Object> req)
    {
        return chatGate.saveChat(requestId, ThreadContext.get(USER_ID), req);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ChatRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "chatId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "chats/{chatId}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getChatById(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestHeader(Headers.CLIENT_ID) String clientId,
                                         @PathVariable("chatId") Long chatId)
    {
        return chatGate.getChatById(requestId, clientId, ThreadContext.get(USER_ID), chatId);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ChatListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "status", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "type", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "chats/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> chatList(@RequestHeader(REQUEST_ID) String requestId,
                                  @RequestHeader(Headers.CLIENT_ID) String clientId,
                                  @RequestParam(value = "status", required = false) String status,
                                  @RequestParam(value = "type", required = false) String type)
    {
        return chatGate.list(requestId, clientId, ThreadContext.get(USER_ID), status, type);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(type = "integer"))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NewMessageReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "chatId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "chats/{chatId}/messages", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createMessage(@RequestHeader(REQUEST_ID) String requestId,
                                           @PathVariable("chatId") Long chatId,
                                           @RequestBody Map<String, Object> req)
    {
        return chatGate.createMessage(requestId, ThreadContext.get(USER_ID), chatId, req);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "207", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = MessageErrorRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = MessagesReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "chatId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "chats/{chatId}/messages/delete", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@RequestHeader(REQUEST_ID) String requestId,
                                    @RequestHeader(Headers.CLIENT_ID) String clientId,
                                    @PathVariable("chatId") Long chatId,
                                    @RequestBody Map<String, Object> req)
    {
        return chatGate.delete(requestId, clientId, ThreadContext.get(USER_ID), chatId, req);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "207", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = MessageErrorRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = MessagesReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = "chatId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "chats/{chatId}/messages/is-delivered", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> isDelivered(@RequestHeader(REQUEST_ID) String requestId,
                                         @RequestHeader(Headers.CLIENT_ID) String clientId,
                                         @PathVariable("chatId") Long chatId,
                                         @RequestBody Map<String, Object> req)
    {
        return chatGate.isDelivered(requestId, clientId, ThreadContext.get(USER_ID), chatId, req);
    }

    @Tag(name = "chat", description = "Чат")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = MessagesRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "chatId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "messages", in = ParameterIn.QUERY, array = @ArraySchema(schema = @Schema(type = "integer"))),
                    @Parameter(name = "take", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "fromDate", in = ParameterIn.QUERY, schema = @Schema(type = "date-time")),
                    @Parameter(name = "direction", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
                    @Parameter(name = "byUser", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "chats/{chatId}/messages", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestHeader(REQUEST_ID) String requestId,
                                 @RequestHeader(Headers.CLIENT_ID) String clientId,
                                 @PathVariable("chatId") Long chatId,
                                 @RequestParam(value = "messages", required = false) List<Long> messages,
                                 @RequestParam(value = "take", required = false) Integer take,
                                 @RequestParam(value = "fromDate", required = false) Instant fromDate,
                                 @RequestParam(value = "direction", required = false) String direction,
                                 @RequestParam(value = "byUser", required = false) Long byUser)
    {
        return chatGate.get(requestId, clientId, ThreadContext.get(USER_ID), chatId, messages, take, fromDate, direction, byUser);
    }

    @Tag(name = "chat", description = "Чат")
    @Parameters(
            value = {
                    @Parameter(name = "chatId", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = LOCALE, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "chats/{chatId}/messages/is-read", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> isRead(@RequestHeader(REQUEST_ID) String requestId,
                                    @RequestHeader(Headers.CLIENT_ID) String clientId,
                                    @PathVariable("chatId") Long chatId,
                                    @RequestBody Map<String, Object> req)
    {
        return chatGate.isRead(requestId, clientId, ThreadContext.get(USER_ID), chatId, req);
    }

    @Tag(name = "onboarding", description = "Сервис онбординга")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = OnBoardingReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "onboarding/status", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_ONBOARDING_STATUS)
    public ResponseEntity<?> sendOnboardingStatus(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestHeader(Headers.CLIENT_ID) String clientId,
                                           @RequestBody Map<String, Object> req) {
        return onboardingGate.sendOnboardingStatus(requestId, clientId, ThreadContext.get(USER_ID), externalService.getType(getUserId()), req);
    }

    @Tag(name = "onboarding", description = "Сервис онбординга")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetOnBoardingRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string")),
                    @Parameter(name = "sysName", in = ParameterIn.QUERY, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "onboarding", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_ONBOARDING)
    public ResponseEntity<?> getOnboarding(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestHeader(Headers.CLIENT_ID) String clientId,
                                           @RequestParam("sysName") String sysName) {
        return onboardingGate.getOnboarding(requestId, clientId, ThreadContext.get(USER_ID), externalService.getType(getUserId()), sysName);
    }

    @Tag(name = "onboarding", description = "Сервис онбординга")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetOnBoardingRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = OnBoardingDto.class)))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = CLIENT_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, schema = @Schema(type = "string"))
            }
    )
    @PostMapping(value = "onboarding", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_ONBOARDING)
    public ResponseEntity<?> rewriteOnboarding(@RequestHeader(REQUEST_ID) String requestId,
                                               @RequestHeader(Headers.CLIENT_ID) String clientId,
                                               @RequestBody List<Map<String, Object>> req) {
        return onboardingGate.rewriteOnboarding(requestId, clientId, req);
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NoticeDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer"))
            }
    )
    @GetMapping(value = "notice/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_NOTICE)
    public ResponseEntity<?> getNotice(@RequestHeader(REQUEST_ID) String requestId,
                                       @PathVariable Long id) {
        return notificationGate.getNotice(requestId, getUserId(), id);
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200"),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "integer")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer"))
            }
    )
    @DeleteMapping(value = "notice/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(DELETE_NOTICE)
    public ResponseEntity<?> deleteNotice(@RequestHeader(REQUEST_ID) String requestId,
                                          @PathVariable Long id) {
        return notificationGate.deleteNotice(requestId, getUserId(), id);
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NoticeListRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "rowCount", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
                    @Parameter(name = "pageToken", in = ParameterIn.QUERY, schema = @Schema(type = "integer")),
            }
    )
    @GetMapping(value = "notice/list", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_NOTICE_LIST)
    public ResponseEntity<?> getNoticeList(@RequestHeader(REQUEST_ID) String requestId,
                                           @RequestParam(required = false) Integer rowCount,
                                           @RequestParam(required = false) Integer pageToken,
                                           @RequestParam(required = false) Boolean watched) {
        return notificationGate.getNoticeList(requestId, getUserId(), rowCount, pageToken, watched);
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation =  NoticeAmountRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
            }
    )
    @GetMapping(value = "notice/amount", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_NOTICE_AMOUNT)
    public ResponseEntity<?> getNoticeAmount(@RequestHeader(REQUEST_ID) String requestId) {
        return notificationGate.getNoticeAmount(requestId, getUserId());
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NoticeDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NoticeDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "string")),
                    @Parameter(name = "id", in = ParameterIn.PATH, required = true, schema = @Schema(type = "integer"))
            }
    )
    @PutMapping(value = "notice/{id}", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_NOTICE)
    public ResponseEntity<?> putNotice(@RequestHeader(REQUEST_ID) String requestId,
                                       @PathVariable Long id,
                                       @RequestBody Map<String, Object> req){
        return notificationGate.putNotice(requestId, getUserId(), id, req);
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NoticeDto.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = NoticeDto.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = SEND_USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "integer"))
            }
    )
    @PostMapping(value = "notice", produces = APPLICATION_JSON_VALUE)
    @Monitoring(POST_NOTICE)
    public ResponseEntity<?> postNotice(@RequestHeader(REQUEST_ID) String requestId,
                                        @RequestHeader(value = Constants.Headers.SEND_USER_ID, required = false) Long sendUserId,
                                        @RequestBody Map<String, Object> req){
        return notificationGate.postNotice(requestId, getUserId(), sendUserId, req);
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE)
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = USER_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = SEND_USER_ID, in = ParameterIn.HEADER, schema = @Schema(type = "integer"))
            }
    )
    @PutMapping(value = "notice/watched", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_NOTICE_WATCHED)
    public ResponseEntity<?> patchNotice(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId){
        return notificationGate.patchNotice(requestId, getUserId());
    }

    @Tag(name = "notification", description = "Сервис нотификаций")
    @Operation(responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE)
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = PermissionReq.class))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = REQUEST_ID, in = ParameterIn.HEADER, required = true, schema = @Schema(type = "string")),
                    @Parameter(name = AUTH_SESSION_ID, in = ParameterIn.COOKIE, required = true, description = "Авторизационный токен", schema = @Schema(type = "string"))
            }
    )
    @PutMapping(value = "permission", produces = APPLICATION_JSON_VALUE)
    @Monitoring(PUT_NOTICE_PERMISSION)
    public ResponseEntity<?> putPermission(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                           @RequestBody Map<String, Object> req){
        Long userId = getUserId();
        return notificationGate.putPermission(requestId, userId, externalService.getType(userId),req);
    }

    @Tag(name = "mid-startuphub", description = "Миддл слой")
    @Operation(
            summary = "Поиск названия компании",
            responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, array = @ArraySchema(schema = @Schema(implementation = String.class)))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorRes.class))
            })
    })
    @Parameters(
            value = {
                    @Parameter(name = "uuid", in = ParameterIn.QUERY, required = true,
                            description = "Текст", schema = @Schema(type = "string"))
            }
    )
    @GetMapping(value = "/search", produces = APPLICATION_JSON_VALUE)
    @Monitoring(GET_SEARCH)
    public ResponseEntity<?> search(@RequestParam("text") String text){
        //TODO перенести в mid-startuphub и прикрутить дадату
        return ResponseEntity.ok(List.of(text));
    }

    @Operation(hidden = true)
    @GetMapping(value = "/health/mail", produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> mailHealth() {
        return notificationGate.mailHeath();
    }

    @SuppressWarnings("unchecked")
    private void setListField(Map<String, Object> req, String mapKey, String key) {
        if (req.get(mapKey) != null
                && req.get(mapKey) instanceof Map) {
            Map<String, Object> map = (Map<String, Object>) req.get(mapKey);
            if (map.get(key) != null) {
                if (map.get(key) instanceof Long) {
                    Long val = (Long) map.get(key);
                    map.put(key, List.of(val));
                } else if (map.get(key) instanceof String) {
                    String val = (String) map.get(key);
                    map.put(key, List.of(Long.valueOf(val)));
                } else if (map.get(key) instanceof Integer) {
                    Integer val = (Integer) map.get(key);
                    map.put(key, List.of(val.longValue()));
                } else if (map.get(key) instanceof List) {
                    map.put(key, map.get(key));
                } else {
                    map.put(key, null);
                }
                req.put(mapKey, map);
            }
        }
    }

}
