package ru.sberx.gateway.gate.sberx;

import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

import java.util.List;
import java.util.Map;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

@FeignClient(name = "onboardingGate", url = "${feign.client.sberx.onboarding}", configuration = SberxGateConfig.class)
public interface OnboardingGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "onboarding/status", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> sendOnboardingStatus(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                           @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                           @RequestHeader(Constants.Headers.USER_ID) String userId,
                                           @RequestHeader(Constants.Headers.ROLE) Integer role,
                                           @RequestBody Map<String, Object> req);


    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "onboarding", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getOnboarding(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                    @RequestHeader(Constants.Headers.USER_ID) String userId,
                                    @RequestHeader(Constants.Headers.ROLE) Integer role,
                                    @RequestParam("sysName") String sysName);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "onboarding", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> rewriteOnboarding(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                        @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                        @RequestBody List<Map<String, Object>> req);
}
