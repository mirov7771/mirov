package ru.sberx.gateway.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties("application.abuse")
@Data
public class ApplicationConfig {
    private List<String> methods;
}
