package ru.sberx.gateway.config;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ru.sberx.gateway.external.interceptors.ReqResInterceptor;

@Configuration
@RequiredArgsConstructor
public class WebMvcConfig implements WebMvcConfigurer {

    private final ReqResInterceptor reqResInterceptor;

    @Value("${spring.application.name}")
    private String rootPath;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry
                .addInterceptor(reqResInterceptor)
                .addPathPatterns("/"+rootPath+"/**");
    }
}
