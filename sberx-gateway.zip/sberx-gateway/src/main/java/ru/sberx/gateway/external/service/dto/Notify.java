package ru.sberx.gateway.external.service.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Notify {

    private String sysName;
    private Map<String, Object> params;
    private String receiver;
    private String type;

}