package ru.sberx.gateway.gate.sberx;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

import feign.Headers;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;
import ru.sberx.gateway.util.Constants.Headers.Chats;

@FeignClient(name = "chatGate", url = "${feign.client.sberx.chat}", configuration = SberxGateConfig.class)
public interface ChatGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "users/me", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getUserInfo(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                  @RequestHeader(Chats.USER_ID) String userId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "chats", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveChat(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @RequestHeader(Chats.USER_ID) String userId,
                               @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "chats/{chatId}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getChatById(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                  @RequestHeader(Chats.USER_ID) String userId,
                                  @PathVariable("chatId") Long chatId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "chats/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> list(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                           @RequestHeader(Chats.USER_ID) String userId,
                           @RequestParam(value = "status", required = false) String status,
                           @RequestParam(value = "type", required = false) String type);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "chats/{chatId}/messages", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> createMessage(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestHeader(Chats.USER_ID) String userId,
                                    @PathVariable("chatId") Long chatId,
                                    @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "chats/{chatId}/messages/delete", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> delete(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                             @RequestHeader(value = Chats.USER_ID, required = false) String userId,
                             @PathVariable("chatId") Long chatId,
                             @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "chats/{chatId}/messages/is-delivered", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> isDelivered(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                  @RequestHeader(value = Chats.USER_ID, required = false) String userId,
                                  @PathVariable("chatId") Long chatId,
                                  @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "chats/{chatId}/messages", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> get(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                          @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                          @RequestHeader(Chats.USER_ID) String userId,
                          @PathVariable("chatId") Long chatId,
                          @RequestParam(value = "messages", required = false) List<Long> messages,
                          @RequestParam(value = "take", required = false) Integer take,
                          @RequestParam(value = "fromDate", required = false) Instant fromDate,
                          @RequestParam(value = "direction", required = false) String direction,
                          @RequestParam(value = "byUser", required = false) Long byUser);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "chats/{chatId}/messages/is-read", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> isRead(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                             @RequestHeader(Chats.USER_ID) String userId,
                             @PathVariable("chatId") Long chatId,
                             @RequestBody Map<String, Object> req);

}
