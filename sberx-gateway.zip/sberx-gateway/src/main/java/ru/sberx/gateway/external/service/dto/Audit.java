package ru.sberx.gateway.external.service.dto;

import lombok.Data;

import java.util.Date;

@Data
public class Audit {
    private Long userId;
    private String userName;
    private String action;
    private String status;
    private Date date;
    private String service;
    private String request;
    private String ip;
}
