package ru.sberx.gateway.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import ru.sberx.gateway.util.Constants.Headers;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class HttpUtils {

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final String[] IP_HEADER_CANDIDATES = {
            "X-Forwarded-For",
            "Proxy-Client-IP",
            "WL-Proxy-Client-IP",
            "HTTP_X_FORWARDED_FOR",
            "HTTP_X_FORWARDED",
            "HTTP_X_CLUSTER_CLIENT_IP",
            "HTTP_CLIENT_IP",
            "HTTP_FORWARDED_FOR",
            "HTTP_FORWARDED",
            "HTTP_VIA",
            "REMOTE_ADDR"
    };

    static {
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
    }

    public static String getRequestId(HttpServletRequest request){
        String requestId = request.getHeader(Headers.REQUEST_ID);
        if (requestId == null)
            requestId = request.getHeader("requestid");
        return requestId;
    }

    public static String getClientId(HttpServletRequest request){
        String clientId = request.getHeader(Headers.CLIENT_ID);
        if (clientId == null)
            clientId = request.getHeader("clientId");
        if (clientId == null)
            clientId = request.getHeader("client-Id");
        if (clientId == null)
            clientId = request.getHeader("Client-Id");
        if (clientId == null)
            clientId = request.getHeader("clientid");
        return clientId;
    }

    public static Map<String, Object> getBodyMap(String request){
        if (!StringUtils.hasText(request))
            return null;
        try {
            return mapper.readValue(request, new TypeReference<HashMap<String, Object>>() {
            });
        } catch (Exception e) {
            log.error("error parsing request ", e);
            return null;
        }
    }

    public static String getClientIpAddress(HttpServletRequest request) {
        for (String header : IP_HEADER_CANDIDATES) {
            String ip = request.getHeader(header);
            if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
                return ip;
            }
        }
        return request.getRemoteAddr();
    }

}
