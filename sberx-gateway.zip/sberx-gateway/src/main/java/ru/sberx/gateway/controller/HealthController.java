package ru.sberx.gateway.controller;

import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.actuate.health.Health;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.gateway.controller.health.LivenessIndicator;
import ru.sberx.gateway.controller.health.ReadinessIndicator;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class HealthController {

    private final ReadinessIndicator readinessIndicator;
    private final LivenessIndicator livenessIndicator;

    @Operation(hidden = true)
    @GetMapping("/read")
    public Health readiness() {
        return readinessIndicator.health();
    }

    @Operation(hidden = true)
    @GetMapping("/live")
    public Health liveness() {
        return livenessIndicator.health();
    }

}
