package ru.sberx.gateway.gate.config;

import feign.Client;
import feign.Logger;
import feign.codec.ErrorDecoder;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.ssl.SSLContexts;
import org.springframework.context.annotation.Bean;
import ru.sberx.gateway.gate.handler.SberxErrorHandler;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

public class SberxGateConfig {

    @Bean
    public Client client() {
        return new Client.Default(getSSLSocketFactory(), new NoopHostnameVerifier());
    }

    @Bean
    public ErrorDecoder errorDecoder() {
        return new SberxErrorHandler();
    }

    @Bean
    public Logger.Level feignLoggerLevel(){
        return Logger.Level.FULL;
    }

    private SSLSocketFactory getSSLSocketFactory() {
        try {
            TrustStrategy acceptingTrustStrategy = (chain, authType) -> true;
            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
