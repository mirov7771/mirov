package ru.sberx.gateway.external.service;

import ru.sberx.dto.user.auth.support.Access;
import ru.sberx.gateway.external.service.dto.AbuseReq;
import ru.sberx.gateway.external.service.dto.AbuseRes;
import ru.sberx.gateway.external.service.dto.SessionInfo;

import java.util.List;

public interface ExternalService {
    void saveAudit(String requestId, String clientId, String sessionId, String action, String service, String request, String ip, String status);
    SessionInfo getUserInfo(String session);
    Integer getType(Long userId);
    List<Access> getAccess();
    AbuseRes abuse(AbuseReq req);
}
