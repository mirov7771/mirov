package ru.sberx.gateway.gate.sberx;


import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.gateway.util.Constants.Headers.LOCALE;

import feign.Headers;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

@FeignClient(name = "serviceGate", url = "${feign.client.sberx.services}", configuration = SberxGateConfig.class)
public interface ServicesGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "search/vas", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> search(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @RequestParam(value = "name", required = false) String name);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "vas", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveService(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "vas", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> updateService(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "vas/{vasId}", produces = APPLICATION_JSON_VALUE)
     ResponseEntity<?> getVasInfo(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @PathVariable("vasId") String vasId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "vas/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> list(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                           @RequestParam(value = "vasId", required = false) List<Long> vasId,
                           @RequestParam(value = "name", required = false) String name,
                           @RequestParam(value = "master", required = false) String master,
                           @RequestParam(value = "rowCount", required = false) Integer rowCount,
                           @RequestParam(value = "pageToken", required = false) Integer pageToken,
                           @RequestParam(value = "category", required = false) List<Long> category,
                           @RequestParam(value = "state", required = false) Integer state,
                           @RequestParam(value = "preauthorize", required = false) Boolean preauthorize,
                           @RequestParam(value = "sortBy", required = false) String sortBy,
                           @RequestParam(value = "orderBy", required = false) String orderBy,
                           @RequestParam(value = "uid", required = false) String uid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "vas/{vasId}/company", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> vasAndCompany(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @PathVariable("vasId") String vasId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "company", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveCompany(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                  @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "company", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> updateCompany(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "company/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getCompany(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                 @RequestHeader(value = Constants.Headers.LOCALE, required = false) String locale,
                                 @PathVariable(value = "id") String id,
                                 @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                 @RequestParam(value = "pageToken", required = false) Integer pageToken);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "company/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> listCompany(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(value = Constants.Headers.LOCALE, required = false) String locale,
                                  @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                  @RequestParam(value = "name", required = false) String name,
                                  @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                  @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                  @RequestParam(value = "sortBy", required = false) String sortBy,
                                  @RequestParam(value = "orderBy", required = false) String orderBy,
                                  @RequestParam(value = "isImport", required = false) Boolean isImport,
                                  @RequestParam(value = "uid", required = false) String uid,
                                  @RequestParam(value = "favorites", required = false) Boolean favorites,
                                  @RequestParam(value = "view", required = false) Boolean view,
                                  @RequestParam(value = "replaceName", required = false) String[] replaceName);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "company/activity/{serviceId}", produces = APPLICATION_JSON_VALUE)
    void updateClickAndView(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                            @PathVariable(value = "serviceId") String serviceId,
                            @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "add-favorite", produces = APPLICATION_JSON_VALUE)
    void addFavorite(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                     @RequestHeader(Constants.Headers.USER_ID) Long userId,
                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "add-activity", produces = APPLICATION_JSON_VALUE)
    void addActivity(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                     @RequestHeader(Constants.Headers.USER_ID) Long userId,
                     @RequestBody Map<String, Object> req);
}
