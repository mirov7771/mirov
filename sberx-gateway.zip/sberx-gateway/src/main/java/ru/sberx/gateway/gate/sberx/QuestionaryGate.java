package ru.sberx.gateway.gate.sberx;

import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.gateway.util.Constants.Headers.*;

@FeignClient(name = "questionaryGate", url = "${feign.client.sberx.questionary}", configuration = SberxGateConfig.class)
public interface QuestionaryGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "pilot", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> postPilot(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "feedback", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> postFeedback(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "search/{type}", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> search(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @PathVariable("type") String type,
                             @RequestParam(value = "name", required = false) String name);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "questionary", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> postQuestionary(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                      @RequestHeader(value = Constants.Headers.USER_ID, required = false) String userId,
                                      @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "verify", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> verify(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "application", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> postApplication(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                      @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "round", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> postRound(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestBody Map<String, Object> req,
                                @RequestHeader(value = USER_ID, required = false) Long userId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "application/{hash}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getApplicationByHash(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                           @PathVariable("hash") String hash,
                                           @RequestParam(value = "auth", required = false) Boolean auth);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "view-card", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> viewCard(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @RequestParam(value = "id", required = false) Long id,
                               @RequestParam(value = "uuid", required = false) UUID uuid,
                               @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/list/application", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getApplicationList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                         @RequestParam(value = "type", required = false) Integer type,
                                         @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                         @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                         @RequestParam(value = "state", required = false) List<Long> states,
                                         @RequestParam(value = "name", required = false) String name,
                                         @RequestParam(value = "admin", required = false) Boolean admin,
                                         @RequestParam(value = "sortBy", required = false) String sortBy,
                                         @RequestParam(value = "orderBy", required = false) String orderBy);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "popup/{questionnaireId}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getPopup(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @PathVariable("questionnaireId") Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "v2/popup/{questionnaireId}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getPopupV2(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                 @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                 @PathVariable("questionnaireId") Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "v2/popup", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getPopupByUserId(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                       @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                       @RequestHeader(Constants.Headers.USER_ID) Long userId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "round", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getRoundById(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestParam(value = "roundId", required = false) Long roundId,
                                   @RequestHeader(value = USER_ID, required = false) Long userId);


    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "user/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getUserById(@RequestHeader("requestId") String requestId,
                                  @PathVariable("id") Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "list/round", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getRoundList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                   @RequestHeader(value = USER_ID, required = false) Long userId,
                                   @RequestHeader(value = ROLE, required = false) String role,
                                   @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                   @RequestParam(value = "investment", required = false) Boolean investment,
                                   @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                   @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                   @RequestParam(value = "state", required = false) List<Long> state,
                                   @RequestParam(value = "name", required = false) String name,
                                   @RequestParam(value = "admin", required = false) Boolean admin,
                                   @RequestParam(value = "favorite", required = false) Boolean favorite,
                                   @RequestParam(value = "sortBy", required = false) String sortBy,
                                   @RequestParam(value = "orderBy", required = false) String orderBy);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "/metric", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postMetric(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                 @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                                 @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "/metric", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> putMetric(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                                @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "metric", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getMetric(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                                @RequestParam(value = "beginDate") String beginDate,
                                @RequestParam(value = "endDate") String endDate,
                                @RequestParam(value = "metricType", required = false) Integer metricType,
                                @RequestParam(value = "uuid", required = false) String uuid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "metric/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getMetricList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                    @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                                    @RequestParam(value = "addData", required = false) Boolean addDate,
                                    @RequestParam(value = "uuid", required = false) String uuid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @DeleteMapping(value = "metric/{metric}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> deleteMetric(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                   @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                                   @PathVariable("metric") Integer metric);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "add-favorite", produces = APPLICATION_JSON_VALUE)
    void addFavoriteUpdate(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestHeader(Constants.Headers.USER_ID) Long userId,
                           @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "round/{roundId}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> changeRound(@RequestHeader("requestId") String requestId,
                                  @PathVariable("roundId") Long roundId,
                                  @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "/community", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveCommunityBlank(@RequestHeader("requestId") String requestId,
                                         @RequestBody Map<String, Object> req,
                                         @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "/community/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> updateCommunityBlank(@RequestHeader("requestId") String requestId,
                                           @PathVariable("id") Long id,
                                           @RequestBody Map<String, Object> req,
                                           @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/community", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getCommunityBlank(@RequestHeader("requestId") String requestId,
                                        @RequestParam(value = "id", required = false) Long id,
                                        @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/community/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getCommunityBlankList(@RequestHeader("requestId") String requestId,
                                            @RequestParam(value = "id", required = false) Long id,
                                            @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                            @RequestParam(value = "state", required = false) Long[] state,
                                            @RequestParam(value = "name", required = false) String name,
                                            @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                            @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                            @RequestParam(value = "type", required = false) Integer type,
                                            @RequestParam(value = "preauth", required = false) Boolean preAuth,
                                            @RequestParam(value = "sortBy", required = false) String sortBy,
                                            @RequestParam(value = "orderBy", required = false) String orderBy);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/questionary/{id}/status-history", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getStatusHistory(@RequestHeader("requestId") String requestId,
                                       @PathVariable("id") Long questionaryId,
                                       @RequestParam("type") Integer type,
                                       @RequestParam(value = "direction", required = false) String direction,
                                       @RequestParam(value = "child", required = false) Boolean child);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/syndicate/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getSyndicateList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                       @RequestParam(value = "state", required = false) List<Long> state,
                                       @RequestParam(value = "name", required = false) String name,
                                       @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                       @RequestParam(value = "pageToken", required = false) Integer pageToken);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/syndicate", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getSyndicateQuestionnaire(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                                @RequestParam(value = "id", required = false) Long id,
                                                @RequestParam(value = "uid", required = false) String uid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "/syndicate", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveSyndicate(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestBody Map<String, Object> req);


    @GetMapping(value = "statistic", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getStatistic(@RequestHeader("requestId") String requestId,
            @RequestHeader("client-id") String clientId,
            @RequestHeader(value = "user-id", required = false) Long userId,
            @RequestParam(value = "type", required = false) List<Integer> type,
            @RequestParam(value = "dateFrom", required = false) Long dateFrom,
            @RequestParam(value = "dateTo", required = false) Long dateTo);

    @GetMapping(value = "statistic/reply", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getReplyStatistic(@RequestHeader("client-id") String clientId,
                                        @RequestHeader("requestId") String requestId,
                                        @RequestHeader("role") String role);

    @GetMapping(value = "smart-search", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getSmartSearch(@RequestHeader("requestId") String requestId,
                                     @RequestHeader(value = "locale", defaultValue = "ru") String locale,
                                     @RequestParam(value = "name", required = false) String name,
                                     @RequestParam(value = "type", required = false) List<String> type);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "/questionary/{id}/responsible", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> changeQuestionnaireResponsible(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                                     @PathVariable(value = "id") Long questionnaireId,
                                                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "/questionary/{id}/offer", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<?> updateQuestionnaireOffer(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                               @RequestHeader(value = ROLE, required = false) String role,
                                               @PathVariable("id") String questionnaireId,
                                               @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "/questionary/{id}", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<?> updateQuestionnaire(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                          @PathVariable("id") Long questionnaireId,
                                          @RequestHeader(value = ROLE, required = false) String role,
                                          @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "scouting/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> scoutingList(@RequestHeader("requestId") String requestId,
                                   @RequestParam(value = "name", required = false) String name,
                                   @RequestParam(value = "state", required = false) List<Long> state,
                                   @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                   @RequestParam(value = "pageToken", required = false) Integer pageToken);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "scouting/{uid}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getScoutingById(@RequestHeader("requestId") String requestId,
                                      @PathVariable("uid") UUID uid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "scouting", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveScouting(@RequestHeader("requestId") String requestId,
                                   @RequestHeader(value = USER_ID, required = false) String userId,
                                   @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "comment", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postComment(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                                  @RequestHeader(ru.sberx.constants.Constants.Header.ROLE) String role,
                                  @RequestHeader("login") String login,
                                  @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "comment/{id}", method = RequestMethod.PUT, consumes = APPLICATION_JSON_VALUE)
    void updateComment(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                       @RequestHeader(ru.sberx.constants.Constants.Header.USER_ID) Long userId,
                       @PathVariable("id") Long id,
                       @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "comment", method = RequestMethod.GET, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getComment(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(Constants.Headers.ROLE) String role,
                                 @RequestParam("tableId") Long tableId,
                                 @RequestParam("tableName") String tableName);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "comment/{id}", method = RequestMethod.DELETE, produces = APPLICATION_JSON_VALUE)
    void deleteComment(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                       @RequestHeader(USER_ID) Long userId,
                       @PathVariable("id") Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "reply", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postReply(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                                @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "reply/list", method = RequestMethod.GET, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getReplyList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                   @RequestHeader(value = Constants.Headers.ROLE, defaultValue = "Client") String role,
                                   @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                                   @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                   @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                   @RequestParam(value = "state", required = false) List<Long> states,
                                   @RequestParam(value = "id", required = false) List<Long> id,
                                   @RequestParam(value = "schema", required = false) String schema,
                                   @RequestParam(value = "name", required = false) String name,
                                   @RequestParam(value = "view", required = false) Boolean view,
                                   @RequestParam(value = "sortBy", required = false) String sortBy,
                                   @RequestParam(value = "orderBy", required = false) String orderBy,
                                   @RequestParam(value = "isPilotOffer", required = false) Boolean isPilotOffer);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "pilot/list", method = RequestMethod.GET, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> pilotList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(value = Constants.Headers.USER_ID) Long userId,
                                @RequestHeader(value = Constants.Headers.ROLE, defaultValue = "Client") String role,
                                @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                @RequestParam(value = "pilotId", required = false) List<Long> pilotId,
                                @RequestParam(value = "rowCount", required = false) Integer rowCount,
                                @RequestParam(value = "pageToken", required = false) Integer pageToken,
                                @RequestParam(value = "name", required = false) String name,
                                @RequestParam(value = "state", required = false) List<Long> states,
                                @RequestParam(value = "filteredBy", required = false) String filteredBy,
                                @RequestParam(value = "pilotsPerCompany", required = false) Integer pilotsPerCompany,
                                @RequestParam(value = "view", required = false) Boolean view,
                                @RequestParam(value = "favorite", required = false) Boolean favorite,
                                @RequestParam(value = "sortBy", required = false) String sortBy,
                                @RequestParam(value = "orderBy", required = false) String orderBy,
                                @RequestParam(value = "filters", required = false) String filters,
                                @RequestParam(value = "schema", required = false) String schema,
                                @RequestParam(value = "myReply", required = false) Integer myReply,
                                @RequestParam(value = "id", required = false) String id,
                                @RequestParam(value = "industry", required = false) List<Long> industry);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "/csi", produces = APPLICATION_JSON_VALUE)
    void saveCsi(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                 @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                 @RequestHeader(Constants.Headers.USER_ID) Long userId,
                 @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "/tariff/check", produces = APPLICATION_JSON_VALUE)
    void checkTariff(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                     @RequestHeader(Constants.Headers.ROLE) String role,
                     @RequestHeader(Constants.Headers.USER_ID) Long userId,
                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/tariff", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getTariff(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(value = Constants.Headers.ROLE, required = false) String role,
                                @RequestHeader(value = Constants.Headers.USER_ID, required = false) Long userId,
                                @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                @RequestParam(value = "questionnaireUuid", required = false) String questionnaireUuid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "/tariff", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postTariff(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(Constants.Headers.ROLE) String role,
                                 @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                 @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/tariff/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getTariffList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                    @RequestParam(value = "questionnaireUuid", required = false) String questionnaireUuid);
}
