package ru.sberx.gateway.util;

import lombok.Getter;
import ru.sberx.gateway.controller.dto.ErrorRes;

@Getter
public class AbuseException extends RuntimeException {

    private static final long serialVersionUID = 8865131922762122347L;
    private final ErrorRes errorRes;

    public AbuseException(ErrorRes errorRes) {
        super(errorRes.getMessage());
        this.errorRes = errorRes;
    }
}
