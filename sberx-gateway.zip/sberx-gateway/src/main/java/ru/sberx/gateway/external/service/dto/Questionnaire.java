package ru.sberx.gateway.external.service.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Questionnaire {

    private Long questionnaireId;
    private QuestionnaireInfo questionnaire;
    private Project project;
    private List<Worker> workers;
    private Investment investment;
    private List<InvestorClub> investorClubs;
    private List<Pilot> pilots;
    private List<Representative> representatives;
    private List<Contact> contacts;
    private List<Feedback> feedbacks;
    private List<User> users;
    private List<Founder> founders;
    private List<CommunityUser> communityUsers;
    private User userQuestionnaire;
    private Representative representative;
    private Pilot pilot;
    private List<Pilot> successPilots;
    private List<Pilot> questionnairePilots;
    private List<Pilot> b2cPilots;
    private List<Pilot> b2bPilots;
    private List<Pilot> ecoPilots;
    private Pilot ecoPilot;
    private Integer action;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Project {
        private String name;
        private String note;
        private Long[] industry;
        private Long[] interactionType;
        private Long[] businessModel;
        private String problem;
        private String auditory;
        private Boolean haveMVP;
        private Long[] geography;
        private Long[] sales;
        private String demoSite;
        private String demoFile;
        private String competitor;
        private String upSide;
        private String downSide;
        private Integer staff;
        private Integer hiringStaff;
        private String experience;
        private Long stady;
        private Boolean isDisabled;
        private String staffLocation;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class User {
        private Long userId;
        private String email;
        private String phoneNumber;
        private String name;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Worker {
        private Long workerId;
        private String role;
        private Integer age;
        private String note;
        private Float percentage;
        private String fio;
        private Boolean isDisabled;
        private Long parentId;
        private Boolean isFounder;
        private String facebook;
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Investment {
        private Boolean investment;
        private String experience;
        private Long[] round;
        private BigDecimal sumInvestment;
        private String lastInvestment;
        private String coInvestment;
        private String turnover;
        private String businessPlan;
        private Long[] industry;
        private Long[] geography;
        private String note;
        private Boolean isDisabled;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class InvestorClub {
        private Long investmentClubId;
        private Long questionnaireId;
        private Long userId;
        private String name;
        private String role;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Representative {
        private Long representativeId;
        private String fio;
        private String phone;
        private String email;
        private String role;
        private Boolean isDisabled;
        private String facebook;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Contact {
        private Long contactId;
        private Long type;
        private String name;
        private String value;
        private Boolean isDisabled;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class Feedback {
        private Long feedbackId;
        private Long userId;
        private String userFio;
        private Long unitId;
        private Long userQuestionnaireId;
        private Long interactionState;
        private String comment;
        private Integer score;
        private Date createDate;
        private Date date;
        private Integer needScore;
        private String needComment;
        private Integer caseScore;
        private String caseComment;
        private Integer kpiScore;
        private String kpiComment;
        private Boolean isBran;
        private Date dateend;
        private Date pilotstart;
        private Date pilotend;
        private Date datecontract;
        private String stateName;
        private Integer state;
        @NonNull
        private Long questionnaireId;
        private String unitName;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class QuestionnaireInfo {
        List<Long> userId;
        private String name;
        private String fullName;
        private Date birthDay;
        private String location;
        private String logoFile;
        private Boolean legalRegistered;
        private Boolean mentoring;
        private String turnover;
        private String site;
        private String note;
        private Long[] innovationMethod;
        private Long[] industry;
        private Boolean mailNews;
        private Long[] stady;
        private Boolean club;
        private Boolean representative;
        private Integer type;
        private String typeName;
        private Date modified;
        private Date created;
        private Boolean isBran;
        private Boolean isDisabled;
        private Long[] round;
        private Long[] geography;
        private String[] tags;
        private String phoneNumber;
        private String email;
        private Long owner;
        private String inviteFio;
        private String inviteUnit;
        private Long inviteUser;
        private Long questionnaireId;
        private Boolean isNew;
        private Integer rang;
        private Long[] model;
        private Integer staff;
        private Long[] interactionType;
        private Long registration;
        private String stateName;
        private Integer state;
        private Long investorType;
        private Long registrationCountry;
        private Boolean successfullCase;
        private Boolean scouting;
        private Integer startupInvestmentYears;
        private Integer lastYearInvestmentsCount;
        private Integer overallPilots;
        private Integer overallContracts;
        private String communityState;
        private Integer allDealsNumber;
        private Integer exitDealsNumber;
        private Integer activeDealsNumber;
        private Boolean accelerator;
        private Integer birthYear;
        private String locationCountry;
        private Boolean community;
        private Boolean successPilots;
        private Boolean pilot;
        private Boolean successPilotsB2C;
        private Long stateCode;
        private String comment;
        private String namePilot;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Pilot {
        private Long questionnaireId;
        private List<Long> userId;
        private Long pilotId;
        private Boolean pilot;
        private String suggestCase;
        private Boolean experience;
        private String businessUnit;
        private String reference;
        private String department;
        private String conditions;
        private Boolean isDisabled;
        private Boolean file;
        private String name;
        private Long state;
        private String stateName;
        private Boolean isPublished;
        private Boolean isBran;
        private Long target;
        private String targetOption;
        private Integer relevance;
        private Long effect;
        private Long resources;
        private Boolean search;
        private Date deadline;
        private Long exp;
        private String company;
        private String decision;
        private Boolean isForeign;
        private String decisionCompany;
        private Boolean isHub;
        private Long[] industry;
        private List<Response> response;
        private QuestionnaireInfo questionnaire;
        private String replyStatus;
        private Boolean ecoSystem;
        private Boolean isB2B;
        private Boolean isB2C;
        private Boolean isSuccess;
        private Boolean isQuestionnaire;
        @JsonProperty("pilot_view")
        private Long pilotView = 0L;
        @JsonProperty("pilot_reply")
        private Long pilotReply = 0L;
        @JsonProperty("pilot_newReply")
        private Long pilotNewReply = 0L;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Response {
            private Long responseId;
            private String question;
            private String questionDescription;
            private Boolean isDisabled;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    private static class Founder {
        private Long founderId;
        private Long questionnaireId;
        private String fio;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    private static class CommunityUser {
        private Long communityUserId;
        private Long questionnaireId;
        private Long userId;
        private String ambition;
        private String expectation;
        private Long state;
    }

    @JsonIgnore
    public Map<String, Object> toMap(){
        Map<String, Object> map = new HashMap<>();
        ObjectMapper mapper = new ObjectMapper();
        if (this.questionnaire != null){
            map = mapper.convertValue(this.questionnaire, Map.class);
        }
        if (this.representative != null){
            map.putAll(mapper.convertValue(this.representative, Map.class));
        }
        if (this.investment != null){
            map.putAll(mapper.convertValue(this.investment, Map.class));
        }
        if (this.project != null){
            map.putAll(mapper.convertValue(this.project, Map.class));
        }
        return map;
    }
}
