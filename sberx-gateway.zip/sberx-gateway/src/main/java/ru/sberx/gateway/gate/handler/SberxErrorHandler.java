package ru.sberx.gateway.gate.handler;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.SneakyThrows;
import org.springframework.http.HttpStatus;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.gateway.controller.dto.ErrorRes;

import java.io.IOException;
import java.io.InputStream;

public class SberxErrorHandler implements ErrorDecoder {

    @SneakyThrows
    @Override
    public Exception decode(String s, Response response) {
        if (response != null) {
            if (response.body() != null) {
                try (InputStream inputStream = response.body().asInputStream()) {
                    ObjectMapper mapper = new ObjectMapper();
                    mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
                    ErrorRes errorRes = mapper.readValue(inputStream, ErrorRes.class);
                    if (errorRes != null && errorRes.getCode() != null) {
                        if (errorRes.getTitle() != null && errorRes.getButton() != null)
                            return new SberxException(errorRes.getDetails(),
                                    errorRes.getCode(),
                                    HttpStatus.resolve(response.status()),
                                    errorRes.getMessage(),
                                    errorRes.getTitle(),
                                    errorRes.getDescription(),
                                    errorRes.getButton().getText(),
                                    errorRes.getButton().getLink(),
                                    errorRes.getImg());
                        SberxErrors err = SberxErrors.getByCode(errorRes.getCode());
                        if (err != null)
                            return new SberxException(err);
                        return new SberxException(errorRes.getCode(),
                                HttpStatus.resolve(response.status()),
                                errorRes.getMessage(),
                                errorRes.getDetails());
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else if (response.status() == 401)
                return new SberxException(SberxErrors.getByCode(1002));
        }
        return new SberxException(SberxErrors.getByCode(1000));
    }
}
