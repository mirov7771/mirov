package ru.sberx.gateway.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class ErrorRes {

    private Integer code;
    private String message;
    @JsonIgnore
    private String details;
    private List<String> description;
    private String img;
    private String title;
    private ButtonDto button;
    private Boolean abuse;
    private Map<String, String> fields;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class ButtonDto {
        private String text;
        private String link;
    }

    public ErrorRes(String title,
                    List<String> description,
                    String buttonText,
                    String buttonLink,
                    String img,
                    Integer code,
                    String message,
                    String details) {
        this.title = title;
        this.description = description;
        this.img = img;
        this.code = code;
        this.message = message;
        this.details = details;
        if (StringUtils.hasText(buttonLink) || StringUtils.hasText(buttonText)) {
            this.button = new ButtonDto();
            button.setLink(buttonLink);
            button.setText(buttonText);
        }
    }
}
