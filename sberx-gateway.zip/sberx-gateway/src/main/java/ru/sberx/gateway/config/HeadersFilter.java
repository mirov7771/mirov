package ru.sberx.gateway.config;

import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.HttpMethod.DELETE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.HEAD;
import static org.springframework.http.HttpMethod.OPTIONS;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingResponseWrapper;

@ConditionalOnExpression("${application.cors.enable:true}")
@Component
public class HeadersFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain fc) throws IOException, ServletException {
        if(servletResponse instanceof HttpServletResponse
                && servletRequest instanceof HttpServletRequest) {
            HttpServletResponse response = (HttpServletResponse) servletResponse;
            HttpServletRequest request = (HttpServletRequest) servletRequest;
            String origin = request.getHeader(ORIGIN);
            String referer = request.getHeader(ORIGIN);
            if (origin != null && (origin.contains("startuphub")
                    || origin.contains("sber-unity")
                    || origin.contains("sberunity")
                    || origin.contains("admin")
                    || origin.contains("bran")
                    || origin.contains("local")))
                response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, origin);
            else if (referer != null && (referer.contains("startuphub")
                    || referer.contains("sber-unity")
                    || referer.contains("sberunity")
                    || referer.contains("admin")
                    || referer.contains("bran")
                    || referer.contains("local")))
                response.setHeader(ACCESS_CONTROL_ALLOW_ORIGIN, referer);
            response.setHeader(ACCESS_CONTROL_ALLOW_HEADERS, String.join(",",
                    ORIGIN,
                    "X-Requested-With",
                    CONTENT_TYPE,
                    ACCEPT,
                    AUTHORIZATION,
                    "requestId",
                    "requestid",
                    "client-id",
                    SET_COOKIE,
                    SET_COOKIE2,
                    "auth_session_id",
                    EXPIRES,
                    "expiry",
                    COOKIE));
            response.setHeader(ACCESS_CONTROL_EXPOSE_HEADERS, String.join(",",
                    ACCESS_CONTROL_ALLOW_ORIGIN,
                    ACCESS_CONTROL_ALLOW_HEADERS,
                    ACCESS_CONTROL_ALLOW_CREDENTIALS,
                    ACCESS_CONTROL_ALLOW_METHODS, ORIGIN,
                    "X-Requested-With",
                    CONTENT_TYPE,
                    ACCEPT,
                    AUTHORIZATION,
                    "requestId",
                    "requestid",
                    "client-id",
                    SET_COOKIE,
                    SET_COOKIE2,
                    "auth_session_id",
                    EXPIRES,
                    "expiry",
                    COOKIE));
            response.setHeader(ACCESS_CONTROL_ALLOW_CREDENTIALS, "true");
            response.setHeader(ACCESS_CONTROL_ALLOW_METHODS,
                    String.join(",",
                            GET.name(),
                            POST.name(),
                            PUT.name(),
                            DELETE.name(),
                            OPTIONS.name(),
                            HEAD.name()));
            response.setHeader("Content-Security-Policy",
                    "default-src 'self'; font-src *;img-src * data:; script-src *; style-src *");
            ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
            fc.doFilter(new RequestWrapper(request), responseWrapper);
            responseWrapper.copyBodyToResponse();
        } else {
            fc.doFilter(servletRequest, servletResponse);
        }
    }

}
