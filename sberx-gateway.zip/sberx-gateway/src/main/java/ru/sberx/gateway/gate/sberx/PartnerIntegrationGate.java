package ru.sberx.gateway.gate.sberx;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

import feign.Headers;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

@FeignClient(name = "partnerIntegrationGate", url = "${feign.client.sberx.integration}", configuration = SberxGateConfig.class)
public interface PartnerIntegrationGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "companies/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getCompaniesList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                       @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                       @RequestHeader("authorization") String sessionId,
                                       @RequestParam(value = "type", required = false) List<String> type,
                                       @RequestParam(value = "fromDateTime", required = false) String fromDateTime,
                                       @RequestParam(value = "toDateTime", required = false) String toDateTime,
                                       @RequestParam(value = "pageSize", required = false) Integer pageSize,
                                       @RequestParam(value = "pageNumber", required = false) Integer pageNumber);

    @GetMapping(value = "/files/{id}")
    ResponseEntity<byte[]> getFilesId (@RequestHeader(Constants.Headers.REQUEST_ID) String requestid,
                                  @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                  @RequestHeader("authorization") String sessionId,
                                  @PathVariable(value = "id") String id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "auth", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postAuth (@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                @RequestBody Map<String, Object> req);
}
