package ru.sberx.gateway.validator;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingRequestCookieException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.gateway.controller.dto.ErrorRes;
import ru.sberx.gateway.util.AbuseException;
import ru.sberx.gateway.util.Constants;

@ControllerAdvice
@Slf4j
public class ValidationHandler {

    @ExceptionHandler({Exception.class})
    protected ResponseEntity<ErrorRes> handleException(Exception ex){
        log.error("error in service", ex);
        if (ex instanceof AbuseException) {
            AbuseException e = (AbuseException) ex;
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(e.getErrorRes());
        } else if (ex instanceof SberxException){
            SberxException e = (SberxException) ex;
            return ResponseEntity.status(e.getHttpStatus()).body(new ErrorRes(e.getTitle(),
                    e.getDescription(),
                    e.getButtonText(),
                    e.getButtonLink(),
                    e.getImg(),
                    e.getCode(),
                    e.getMessage(),
                    e.getDetails()));
        } else if (ex instanceof MissingServletRequestParameterException
                || ex instanceof MissingRequestHeaderException
                || ex instanceof MissingRequestCookieException) {
            SberxErrors e = SberxErrors.getByCode(1004);
            return ResponseEntity.status(406).body(new ErrorRes(e.getTitle(),
                    e.getDescription(),
                    e.getButtonText(),
                    e.getButtonLink(),
                    e.getImg(),
                    e.getErrorCode(),
                    e.getMessage().get(ThreadContext.get(Constants.Headers.LOCALE)),
                    null));
        }
        SberxErrors e = SberxErrors.getByCode(1000);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorRes(e.getTitle(),
                e.getDescription(),
                e.getButtonText(),
                e.getButtonLink(),
                e.getImg(),
                e.getErrorCode(),
                e.getMessage().get(ThreadContext.get(Constants.Headers.LOCALE)),
                null));
    }

}