package ru.sberx.gateway.external.service.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Reply {

    private Long tableId;
    private Long pilotId;
    private String tableName;
    private String note;
    private String fileURL;
    private Long state;
    private Reply reply;

}
