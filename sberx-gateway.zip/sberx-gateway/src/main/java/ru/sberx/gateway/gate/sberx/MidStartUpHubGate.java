package ru.sberx.gateway.gate.sberx;

import static ru.sberx.constants.Constants.Header.*;
import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.gateway.util.Constants.Headers.LOCALE;
import static ru.sberx.gateway.util.Constants.Headers.USER_LOGIN;

import feign.Headers;

import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

@FeignClient(name = "midStartUpHubGate", url = "${feign.client.sberx.midstartuphub}", configuration = SberxGateConfig.class)
public interface MidStartUpHubGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "/v2/list", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> listV2(@RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                             @RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                             @RequestParam(value = "type", required = false) List<Integer> type,
                             @RequestParam(value = "filters", required = false) String filters,
                             @RequestParam(value = "rowCount", required = false) Integer rowCount,
                             @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                             @RequestParam(value = "preauthorize", required = false) Boolean preauthorize,
                             @RequestParam(value = "pageToken", required = false) Integer pageToken,
                             @RequestParam(value = "userId", required = false) Long userId,
                             @RequestParam(value = "role", required = false) String role,
                             @RequestParam(value = "owner", required = false) Boolean owner,
                             @RequestParam(value = "state", required = false) List<Long> state,
                             @RequestParam(value = "name", required = false) String name,
                             @RequestParam(value = "isBran", required = false) Boolean isBran,
                             @RequestParam(value = "isDisabled", required = false) Boolean isDisabled,
                             @RequestParam(value = "birthDay", required = false) Integer birthDay,
                             @RequestParam(value = "site", required = false) Boolean site,
                             @RequestParam(value = "location", required = false) String location,
                             @RequestParam(value = "investorType", required = false) Long[] investorType,
                             @RequestParam(value = "industry", required = false) Long[] industry,
                             @RequestParam(value = "innovationMethod", required = false) Long[] innovationMethod,
                             @RequestParam(value = "stady", required = false) Long[] stady,
                             @RequestParam(value = "geography", required = false) Long[] geography,
                             @RequestParam(value = "registrationCountry", required = false) Long[] registrationCountry,
                             @RequestParam(value = "communityState", required = false) String communityState,
                             @RequestParam(value = "category", required = false) Long category,
                             @RequestParam(value = "myReplay", required = false) Boolean myReplay,
                             @RequestParam(value = "schema", required = false) String schema,
                             @RequestParam(value = "id", required = false) String id,
                             @RequestParam(value = "investment", required = false) Boolean investment,
                             @RequestParam(value = "businessModel", required = false) Long[] businessModel,
                             @RequestParam(value = "forLending", required = false) Boolean forLending,
                             @RequestParam(value = "companyId", required = false) Long companyId,
                             @RequestParam(value = "isAdmin", required = false) Boolean isAdmin,
                             @RequestParam(value = "prioritySort", required = false) Boolean prioritySort,
                             @RequestParam(value = "formName", required = false) String formName,
                             @RequestParam(value = "mvpCode", required = false) Long[] mvpCode,
                             @RequestParam(value = "technology", required = false) Long[] technology,
                             @RequestParam(value = "project_technology", required = false) Long[] project_technology,
                             @RequestParam(value = "investment_technology", required = false) Long[] investment_technology,
                             @RequestParam(value = "project_geography", required = false) Long[] project_geography,
                             @RequestParam(value = "locationCountry", required = false) Long[] locationCountry,
                             @RequestParam(value = "investment_geography", required = false) Long[] investmentGeography,
                             @RequestParam(value = "investment_industry", required = false) Long[] investmentIndustry,
                             @RequestParam(value = "interactionType", required = false) Long[] interactionType,
                             @RequestParam(value = "round", required = false) Long[] round,
                             @RequestParam(value = "staff", required = false) Long[] staff,
                             @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie,
                             @RequestParam(value = "filteredBy", required = false) String filteredBy,
                             @RequestParam(value = "pilotsPerCompany", required = false) Integer pilotsPerCompany,
                             @RequestParam(value = "sber500", required = false) Boolean sber500,
                             @RequestParam(value = "sortBy", required = false) String sortBy,
                             @RequestParam(value = "orderBy", required = false) String orderBy,
                             @RequestParam(value = "favorite", required = false) Boolean favorite,
                             @RequestParam(value = "responsible", required = false) Long responsible,
                             @RequestParam(value = "main", required = false) Boolean main,
                             @RequestParam(value = "view", required = false) Boolean view,
                             @RequestParam(value = "search", required = false) String search,
                             @RequestParam(value = "isPilotOffer", required = false) Boolean isPilotOffer,
                             @RequestParam(value = "recommend", required = false) Boolean recommend,
                             @RequestParam(value = "isImport", required = false) Boolean isImport,
                             @RequestParam(value = "replaceName", required = false) String[] replaceName,
                             @RequestParam(value = "sales", required = false) Boolean sales,
                             @RequestParam(value = "startBirthDate", required = false) Integer startBirthDate,
                             @RequestParam(value = "endBirthDate", required = false) Integer endBirthDate);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "workspace/client", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> workspaceClient(@RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                      @RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                      @RequestHeader(value = Constants.Headers.LOCALE, required = false, defaultValue = "ru") String locale,
                                      @RequestParam(value = "type", required = false) Integer type,
                                      @RequestHeader(USER_ID) Long userId,
                                      @RequestHeader(ROLE) String role,
                                      @RequestParam(value = "login") String login);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "view", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> view(@RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                           @RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestHeader(value = Constants.Headers.LOCALE, required = false, defaultValue = "ru") String locale,
                           @RequestParam(value = "action", required = false) Integer action,
                           @RequestParam(value = "name", required = false) String name,
                           @RequestParam(value = "type", required = false) Integer type,
                           @RequestParam(value = "id", required = false) Long id,
                           @RequestParam(value = "uid", required = false) String uid,
                           @RequestParam(value = "preauthorize", required = false) Boolean preauthorize,
                           @RequestParam(value = "ui", required = false) String ui,
                           @RequestParam(value = "uuid", required = false) String uuid,
                           @RequestParam(value = "admin", required = false) Boolean admin,
                           @RequestHeader(value = USER_ID, required = false) Long userId,
                           @RequestHeader(value = ROLE, required = false) String role);

    @GetMapping(value = "link/{uuid}", produces = MediaType.IMAGE_PNG_VALUE)
    ResponseEntity<BufferedImage> link(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                       @PathVariable("uuid") String uid);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "success-story", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> successStory(@RequestHeader(CLIENT_ID) String clientId,
                                   @RequestHeader(REQUEST_ID) String requestId,
                                   @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie,
                                   @RequestBody Map<String, Object> req);

}
