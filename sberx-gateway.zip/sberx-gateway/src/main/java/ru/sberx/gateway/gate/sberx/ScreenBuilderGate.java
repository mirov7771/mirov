package ru.sberx.gateway.gate.sberx;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.gateway.util.Constants.Headers.LOCALE;
import static ru.sberx.gateway.util.Constants.Headers.ROLE;

import feign.Headers;
import java.util.List;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

@FeignClient(name = "screenBuilderGate", url = "${feign.client.sberx.screenbuilder}", configuration = SberxGateConfig.class)
public interface ScreenBuilderGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "menu", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> menu(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                           @RequestHeader(value = ROLE, required = false) String role,
                           @RequestParam("type") Integer type,
                           @RequestParam("name") String name,
                           @RequestParam(value = "id", required = false) Long id);

    @GetMapping(value = "features", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> features(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @RequestHeader(value = Constants.Headers.USER_ID, required = false) Long userId,
                               @RequestHeader(value = HttpHeaders.LOCATION, required = false) String location);

    @PostMapping(value = "feature", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> featureSave(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestBody Map<String, Object> req);

    @DeleteMapping(value = "feature/{id}", produces = APPLICATION_JSON_VALUE)
    void featureDelete(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                       @PathVariable("id") Long id);

    @PutMapping(value = "feature/{id}", produces = APPLICATION_JSON_VALUE)
    void featureUpdate(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                       @PathVariable("id") Long id,
                       @RequestBody Map<String, Object> req);

    @GetMapping(value = "buttons", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> buttons(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                              @RequestHeader(value = Constants.Headers.LOCALE, required = false, defaultValue = "ru") String locale,
                              @RequestParam(value = "name", required = false) String name,
                              @RequestParam(value = "type", required = false) Integer type,
                              @RequestParam(value = "id", required = false) Long questionnaireId,
                              @RequestHeader(value = Constants.Headers.COOKIE, required = false) String cookie);

    @GetMapping(value = "structure/pages", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getPage(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                              @RequestHeader(value = Constants.Headers.USER_ID, required = false) String userId,
                              @RequestHeader(value = Constants.Headers.ROLE, required = false) String role,
                              @RequestHeader(value = Constants.Headers.LOCALE, required = false) String locale,
                              @RequestHeader(value = HttpHeaders.LOCATION, required = false, defaultValue = "/root") String pageUri,
                              @RequestHeader(value = HttpHeaders.ACCEPT_LANGUAGE, required = false) String language,
                              @RequestParam(value = "showHidden", required = false) Boolean showHiddem,
                              @RequestParam(value = "featureStatus", required = false) List<String> featureStatuses);

}
