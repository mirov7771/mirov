package ru.sberx.gateway.gate.sberx;

import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

import java.util.List;
import java.util.Map;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

@FeignClient(name = "guideGate", url = "${feign.client.sberx.guide}", configuration = SberxGateConfig.class)
public interface GuideGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "guide", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> guide(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                            @RequestHeader(value = Constants.Headers.LOCALE, required = false, defaultValue = "ru") String locale,
                            @RequestParam(value = "guideId", required = false) List<Long> guideId,
                            @RequestParam(value = "isFilter", required = false) Boolean isFilter);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "v2/guide", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> guideV2(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                              @RequestHeader(value = Constants.Headers.LOCALE, required = false, defaultValue = "ru") String locale,
                              @RequestParam(value = "guideId", required = false) List<Long> guideId,
                              @RequestParam(value = "parentId", required = false) List<Long> parentId,
                              @RequestParam(value = "name", required = false) List<String> name,
                              @RequestParam(value = "parentName", required = false) List<String> parentName,
                              @RequestParam(value = "isFilter", required = false) Boolean isFilter);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/list", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> getFaqList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(value = Constants.Headers.LOCALE, required = false, defaultValue = "ru") String locale,
                                 @RequestParam(value = "id", required = false) String id,
                                 @RequestParam(value = "groupName", required = false) String groupName,
                                 @RequestParam(value = "search", required = false) String search);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/group", produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> createFaqTheme(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/question", produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> createQuestion(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/group/{id}", produces = APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
    ResponseEntity<?> updateQuestionTheme(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                          @PathVariable("id") Long id,
                                          @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/question/{id}", produces = APPLICATION_JSON_VALUE, method = RequestMethod.PUT)
    ResponseEntity<?> updateQuestion(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @PathVariable("id") Long id,
                                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/group/{id}", produces = APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
    ResponseEntity<?> deleteFaqQuestionTheme(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                             @PathVariable("id") Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "faq/question/{id}", produces = APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
    ResponseEntity<?> deleteQuestion(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @PathVariable("id") Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "urlcheck", produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> urlCheck(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @RequestParam(value = "value") String value);
}
