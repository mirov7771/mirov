package ru.sberx.gateway.external.interceptors;

import javax.annotation.Nonnull;
import javax.annotation.PostConstruct;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.support.Access;
import ru.sberx.gateway.config.ApplicationConfig;
import ru.sberx.gateway.config.RequestWrapper;
import ru.sberx.gateway.controller.dto.ErrorRes;
import ru.sberx.gateway.external.service.ExternalService;
import ru.sberx.gateway.external.service.dto.AbuseReq;
import ru.sberx.gateway.external.service.dto.AbuseRes;
import ru.sberx.gateway.external.service.dto.SessionInfo;
import ru.sberx.gateway.util.AbuseException;
import ru.sberx.gateway.util.Action;
import ru.sberx.gateway.util.Constants.Headers;

import java.time.LocalDateTime;
import java.util.*;

import static ru.sberx.gateway.util.HttpUtils.*;

@Configuration
@RequiredArgsConstructor
@Slf4j
public class ReqResInterceptor implements HandlerInterceptor {

    private final ExternalService externalService;
    private final ApplicationConfig applicationConfig;

    @Value("${spring.application.name}")
    private String root;
    @Value("${application.default.clientid}")
    private String defaultClientId;

    private static List<Access> access = new ArrayList<>();
    private static final String UNAUTHORIZED = "Unauthorized";

    @PostConstruct
    void getAccess(){
        try {
            if (CollectionUtils.isEmpty(access))
                access = externalService.getAccess();
            log.debug("access list [{}]", access);
        } catch (Exception e){
            log.error("Error getting access list: ", e);
        }
    }

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             @Nonnull Object handler)
            throws Exception {
        ThreadContext.put(Headers.REQUEST_ID, StringUtils.hasText(request.getHeader(Headers.REQUEST_ID)) ? request.getHeader(Headers.REQUEST_ID) : UUID.randomUUID().toString());
        log.debug("[{} {}] start at [{}]", request.getMethod(), request.getRequestURI(), LocalDateTime.now());
        ThreadContext.clearMap();
        log.debug("Start UserRole [{}], UserId [{}]", ThreadContext.get(Headers.ROLE), ThreadContext.get(Headers.USER_ID));
        String sessionId = getSessionId(response.getHeader(Headers.AUTH_SESSION_ID), request.getCookies());
        String action = request.getRequestURI();
        String method = request.getMethod();
        String params = request.getQueryString();
        ThreadContext.put(Headers.LOCALE, StringUtils.hasText(request.getHeader(Headers.LOCALE)) ? request.getHeader(Headers.LOCALE) : "ru");
        ThreadContext.put(Headers.CLIENT_ID, StringUtils.hasText(request.getHeader(Headers.CLIENT_ID)) ? request.getHeader(Headers.CLIENT_ID) : defaultClientId);

        if (StringUtils.hasText(action) && !action.contains("docs") && !action.contains("health") && StringUtils.hasText(method)) {
            action = action.replace("/" + root, "");
            log.debug("method [{}], action [{}], params [{}]", method, action, params);
            String role = UNAUTHORIZED;
            if (StringUtils.hasText(sessionId)) {
                SessionInfo session = externalService.getUserInfo(sessionId);
                if (session == null) {
                    log.debug("[{} {}] end at [{}] with status [{}]", request.getMethod(), request.getRequestURI(), LocalDateTime.now(), HttpStatus.UNAUTHORIZED);
                    throw new SberxException(SberxErrors.INVALID_SESSION);
                }
                role = session.getRole();

                ThreadContext.put(Headers.ROLE, role);
                ThreadContext.put(Headers.USER_ID, String.valueOf(session.getExternalId() != null ? session.getExternalId() : session.getUserId()));
                ThreadContext.put(Headers.USER_ID2, String.valueOf(session.getUserId()));
                ThreadContext.put("reportsUse", String.valueOf(Boolean.TRUE.equals(session.getReportUse())));
                if (StringUtils.hasText(session.getLogin()))
                    ThreadContext.put(Headers.USER_LOGIN, session.getLogin());
            }
            if (!method.equalsIgnoreCase(HttpMethod.OPTIONS.toString()))
                checkRoleAccess(role, action, method, params);
        }
        log.debug("End UserRole [{}], UserId [{}]", ThreadContext.get(Headers.ROLE), ThreadContext.get(Headers.USER_ID));

        //STARTUPHUB-4705 [БЭК] Доработка методов сохранения контента в БД. (проверка неразрешенных слов)
        if (StringUtils.hasText(action)
                && StringUtils.hasText(method)
                && (method.equalsIgnoreCase(HttpMethod.POST.name()) || method.equalsIgnoreCase(HttpMethod.PUT.name()))){
            if (!CollectionUtils.isEmpty(applicationConfig.getMethods()) && applicationConfig.getMethods().contains(action)) {
                Map<String, Object> requestBody = getBodyMap(new RequestWrapper(request).getBody());
                if (requestBody != null && !requestBody.isEmpty()) {
                    AbuseReq abuseReq = new AbuseReq();
                    abuseReq.setObjectType(action);
                    abuseReq.setFields(requestBody);
                    AbuseRes abuse = externalService.abuse(abuseReq);
                    if (abuse != null
                            && abuse.getState() != null
                            && abuse.getState().equals(1)
                            && abuse.getFields() != null
                            && !abuse.getFields().isEmpty()) {
                        ErrorRes errorRes = new ErrorRes();
                        errorRes.setCode(1052);
                        errorRes.setMessage("Содержится запрещенная лексика");
                        errorRes.setAbuse(true);
                        errorRes.setFields(abuse.getFields());
                        log.debug("[{} {}] end at [{}] with status [{}]", request.getMethod(), request.getRequestURI(), LocalDateTime.now(), HttpStatus.NOT_ACCEPTABLE);
                        throw new AbuseException(errorRes);
                    }
                }
            }
        }

        return true;
    }

    private void checkRoleAccess(String role, String action, String method, String params) {
        log.info("Start checking role [{}]", role);
        if (CollectionUtils.isEmpty(access))
            access = externalService.getAccess();
        if (!CollectionUtils.isEmpty(access)) {
            Optional<Access> roleAccess = access.stream().filter(i -> i.getRole().equalsIgnoreCase(role)).findFirst();
            if (roleAccess.isEmpty() || CollectionUtils.isEmpty(roleAccess.get().getApi())) {
                log.debug("[{} {}] end at [{}] with status [{}]", method, action, LocalDateTime.now(), HttpStatus.BAD_REQUEST);
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            }
            boolean noAccess = true;
            for (Access.Api api : roleAccess.get().getApi()) {
                log.debug("Granted access [{}, {}, {}], request [{}, {}, {}]", api.getMethod(), api.getAction(), api.getParams(), method, action, params);
                if (method.equalsIgnoreCase(api.getMethod()) && (action.startsWith(api.getAction()) || api.getAction().equals("**"))) {
                    if (StringUtils.hasText(api.getParams())) {
                        if (!api.getParams().contains("&") && params.contains(api.getParams()))
                            noAccess = false;
                        else {
                            String[] apiParams = api.getParams().split("&");
                            if (apiParams.length > 0) {
                                for (String p : apiParams) {
                                    noAccess = !params.contains(p);
                                }
                            }
                        }
                    } else {
                        noAccess = false;
                    }
                }
                if (!Boolean.TRUE.equals(noAccess)) {
                    log.debug("Access [{}, {}, {}] is granted!", api.getMethod(), api.getAction(), api.getParams());
                    break;
                }
            }
            if (Boolean.TRUE.equals(noAccess)) {
                log.debug("[{} {}] end at [{}] with status [{}]", method, action, LocalDateTime.now(), HttpStatus.BAD_REQUEST);
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            }
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request,
                                HttpServletResponse response,
                                @Nonnull Object handler,
                                Exception ex)
            throws Exception {
        String sessionId = getSessionId(response.getHeader(Headers.AUTH_SESSION_ID), request.getCookies());
        log.debug("sessionId = {}", sessionId);
        if (sessionId != null) {
            log.debug("start async saving event for {}", sessionId);
            String body = new RequestWrapper(request).getBody();
            String status = response.getStatus() == 200 ? "success" : "error";
            String action = Action.getActionName(request.getRequestURI());
            String ip = getClientIpAddress(request);
            if (!StringUtils.hasText(body))
                body = request.getQueryString();
            log.debug("request for audit {} with status {} and action {} from ip {}", body, status, action, ip);
            externalService.saveAudit(getRequestId(request),
                    getClientId(request),
                    sessionId,
                    action,
                    request.getRequestURL().toString(),
                    body,
                    ip,
                    status);
            log.info("end async saving event for {}", sessionId);
        }
        response.setHeader(HttpHeaders.TRANSFER_ENCODING, null);
        log.debug("response headers {}", Arrays.toString(response.getHeaderNames().toArray()));
        log.debug("[{} {}] end at [{}] with status [{}]", request.getMethod(), request.getRequestURI(), LocalDateTime.now(), HttpStatus.OK);
        ThreadContext.clearAll();
    }

    private String getSessionId(String sessionId, Cookie[] cookies){
        if (StringUtils.hasText(sessionId))
            return sessionId;
        if (cookies != null) {
            for(Cookie cookie : cookies) {
                if (cookie.getName().equals(Headers.AUTH_SESSION_ID)) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

}
