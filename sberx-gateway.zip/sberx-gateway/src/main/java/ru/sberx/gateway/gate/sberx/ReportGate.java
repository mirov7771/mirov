package ru.sberx.gateway.gate.sberx;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

import java.util.List;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

@FeignClient(name = "reportGate", url = "${feign.client.sberx.report}", configuration = SberxGateConfig.class)
public interface ReportGate {

    @GetMapping(value = "report", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getFile(@RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                              @RequestHeader(value = Constants.Headers.REQUEST_ID, required = false) String requestId,
                              @RequestHeader(value = Constants.Headers.USER_ID, required = false) String userID,
                              @RequestParam(value = "userId", required = false) Long userId,
                              @RequestParam(value = "reportId") String reportId,
                              @RequestParam(value = "dateFrom", required = false) Long dateFrom,
                              @RequestParam(value = "dateTo", required = false) Long dateTo,
                              @RequestParam(value = "companyId", required = false) Long companyId,
                              @RequestParam(value = "type", required = false) List<Integer> type,
                              @RequestParam(value = "reportsUse", required = false) Boolean reportsUse);

    @GetMapping(value = "audit", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getAudit(@RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                               @RequestHeader(Constants.Headers.REQUEST_ID) String requestId);
}
