package ru.sberx.gateway.controller.dto.swagger.auth;

public class AuthDTO {
    String login;
    String password;
    String newPassword;
    Boolean termOfUseConsent;
}
