package ru.sberx.gateway.external.service.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AbuseRes {
    private Integer state;
    private Map<String, String> fields;
}
