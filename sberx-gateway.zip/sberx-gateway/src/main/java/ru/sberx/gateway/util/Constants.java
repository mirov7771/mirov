package ru.sberx.gateway.util;

import org.apache.logging.log4j.ThreadContext;

public class Constants {

    public static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    public static class Headers {

        public static final String CLIENT_ID = "client-id";
        public static final String REQUEST_ID = "requestId";
        public static final String AUTH_SESSION_ID = "AUTH_SESSION_ID";
        public static final String COOKIE = "cookie";
        public static final String USER_ID = "user-id";
        public static final String USER_ID2 = "user-id2";
        public static final String SEND_USER_ID = "send-user-id";
        public static final String ROLE = "role";
        public static final String USER_LOGIN = "user-login";
        public static final String LOCALE = "locale";
        public static final String TYPE_ID = "type-id";

        public static class Chats {
            public static final String USER_ID = "user-id";
        }
    }

    public static Long getUserId(){
        if (ThreadContext.get(Headers.USER_ID) != null)
            return Long.valueOf(ThreadContext.get(Headers.USER_ID));
        return null;
    }

}
