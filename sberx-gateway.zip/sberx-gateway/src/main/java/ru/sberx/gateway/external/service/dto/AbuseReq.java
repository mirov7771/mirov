package ru.sberx.gateway.external.service.dto;

import lombok.Data;

import java.util.Map;

@Data
public class AbuseReq {
    private Map<String, Object> fields;
    private String objectType;
    private Long objectId;
}
