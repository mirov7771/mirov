package ru.sberx.gateway.external.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import ru.sberx.dto.user.auth.support.Access;
import ru.sberx.gateway.external.client.RestGate;
import ru.sberx.gateway.external.service.ExternalService;
import ru.sberx.gateway.external.service.dto.AbuseReq;
import ru.sberx.gateway.external.service.dto.AbuseRes;
import ru.sberx.gateway.external.service.dto.Audit;
import ru.sberx.gateway.external.service.dto.SessionInfo;
import ru.sberx.metrics.Monitoring;
import ru.sberx.gateway.util.Action;
import ru.sberx.gateway.util.Constants.Headers;

import static ru.sberx.metrics.UnityMetricName.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExternalServiceImpl implements ExternalService {

    private final RestGate restGate;

    @Value("${feign.client.sberx.audit}")
    private String auditUrl;
    @Value("${feign.client.sberx.userauth}")
    private String authUrl;
    @Value("${feign.client.sberx.questionary}")
    private String questionaryUrl;
    @Value("${feign.client.sberx.guide}")
    private String guideUrl;

    private boolean auditStatus;

    @Async("threadPoolTaskExecutor")
    @Override
    @Monitoring(EXTERNAL_SAVE_AUDIT)
    public void saveAudit(String requestId,
                          String clientId,
                          String sessionId,
                          String action,
                          String service,
                          String request,
                          String ip,
                          String status)
    {
        log.info("{} try save audit event", requestId);
        HttpHeaders headers = new HttpHeaders();
        headers.add(Headers.REQUEST_ID, requestId);
        log.info("{} start checking session {}", requestId, sessionId);
        SessionInfo sessionInfo = getSessionInfo(headers, sessionId);
        if (sessionInfo != null
                && sessionInfo.getUserId() != null) {
            log.info("{} end checking session {}", requestId, sessionInfo);
            if (Boolean.TRUE.equals(auditStatus) && checkAction(action, status)) {
                try {
                    log.info("{} audit service is available {}", requestId, auditUrl);
                    Audit req = new Audit();
                    req.setUserName(sessionInfo.getLogin());
                    req.setUserId(sessionInfo.getUserId());
                    req.setDate(new Date());
                    req.setAction(action);
                    req.setService(service);
                    req.setRequest(request);
                    req.setIp(ip);
                    req.setStatus(status);
                    log.info("{} start saving audit event {}", requestId, req);
                    restGate.call(String.class,
                            auditUrl,
                            "/audit",
                            null,
                            req,
                            HttpMethod.POST,
                            headers,
                            MediaType.APPLICATION_JSON);
                    log.info("end saving audit event");
                } catch (Exception e) {
                    log.error("request for audit event parsing error ", e);
                }
            } else {
                log.info("audit service is not available {}", auditUrl);
            }
        }
    }

    @Monitoring(EXTERNAL_AUTH_CHECK_SESSION)
    @Override
    public SessionInfo getUserInfo(String session) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(Headers.REQUEST_ID, ThreadContext.get(Headers.REQUEST_ID));
        return getSessionInfo(headers, session);
    }

    @SuppressWarnings("unchecked")
    @Override
    @Monitoring(EXTERNAL_QUESTIONARY_TYPE)
    public Integer getType(Long userId) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(Headers.REQUEST_ID, ThreadContext.get(Headers.REQUEST_ID));
        headers.add(Headers.CLIENT_ID, ThreadContext.get(Headers.CLIENT_ID));
        List<Map<String, Object>> type = restGate.call(List.class,
                questionaryUrl,
                "/type",
                Map.of("userId", userId),
                null,
                HttpMethod.GET,
                headers,
                MediaType.APPLICATION_JSON);
        if (type != null && type.size() > 0){
            return (Integer) type.get(0).get("type");
        }
        return null;
    }

    @Monitoring(EXTERNAL_AUTH_ACCESS)
    @Override
    public List<Access> getAccess() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(Headers.REQUEST_ID, UUID.randomUUID().toString());
        return restGate.call(new ParameterizedTypeReference<List<Access>>(){},
                authUrl,
                "/access",
                null,
                null,
                HttpMethod.GET,
                headers,
                MediaType.APPLICATION_JSON);
    }

    @Monitoring(EXTERNAL_ABUSE)
    @Override
    public AbuseRes abuse(AbuseReq req) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(Headers.REQUEST_ID, UUID.randomUUID().toString());
        return restGate.call(new ParameterizedTypeReference<AbuseRes>(){},
                guideUrl,
                "/abuse",
                null,
                req,
                HttpMethod.POST,
                headers,
                MediaType.APPLICATION_JSON);
    }

    private SessionInfo getSessionInfo(HttpHeaders headers, String sessionId){
        return restGate.call(SessionInfo.class,
                authUrl,
                "/checksession/" + sessionId,
                null,
                null,
                HttpMethod.GET,
                headers,
                MediaType.APPLICATION_JSON);
    }

    @PostConstruct
    public void auditStatus() {
        try {
            String status = restGate.call(String.class,
                    auditUrl,
                    "/live",
                    null,
                    null,
                    HttpMethod.GET,
                    null,
                    MediaType.APPLICATION_JSON);
            if (status != null)
                auditStatus = status.contains("UP");
            else
                auditStatus = false;
        } catch (Exception e){
            log.error("audit is unreacheable ", e);
            auditStatus = false;
        }
    }

    private boolean checkAction(String action, String status){
        if (action.equals(Action.INVALID_SESSION.toString()))
            return "error".equals(status);
        return true;
    }
}
