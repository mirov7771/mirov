package ru.sberx.gateway.gate.sberx;

import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

import java.util.Map;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

@FeignClient(name = "userAuthGate", url = "${feign.client.sberx.userauth}", configuration = SberxGateConfig.class)
public interface UserAuthGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "auth/{type}", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> auth(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                           @PathVariable("type") String type,
                           @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "logout/{id}", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.DELETE)
    ResponseEntity<?> logout(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                             @PathVariable("id") String sessionId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "checksession/{id}", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> checkSession(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @PathVariable("id") String sessionId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "preauthorize", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.GET)
    ResponseEntity<?> preauthorize(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                   @RequestParam Map<String, String> param);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "login", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> login(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                            @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                            @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "restore-password", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    ResponseEntity<?> restorePassword(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                      @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                                      @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                      @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "registration", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> registration(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(value = Constants.Headers.LOCALE, defaultValue = "ru") String locale,
                                   @RequestHeader(Constants.Headers.CLIENT_ID) String clientId,
                                   @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @DeleteMapping(value = "user/{questionnaireId}", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<?> deleteUser(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @PathVariable Long questionnaireId,
                                 @RequestBody Map<String, Object> req,
                                 @RequestParam(value = "isClient", required = false) Boolean isClient);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @DeleteMapping(value = "user", consumes = APPLICATION_JSON_VALUE)
    ResponseEntity<?> user(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                           @RequestParam(value = "userId", required = false) Long userId,
                           @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "permission", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postPermission(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "permission/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> putPermission(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @PathVariable("id") Long id,
                                    @RequestBody Map<String, Object> req);


    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/permission/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> listPermission(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "permission/role", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> rolePermission(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/role/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> listRole(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "role", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postRole(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "user", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> createUser(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "user/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                              @RequestParam(value = "role", required = false) String role,
                              @RequestParam(value = "userRole", required = false) Integer userRole,
                              @RequestParam(value = "rowCount", required = false) Integer rowCount,
                              @RequestParam(value = "pageToken", required = false) Integer pageToken,
                              @RequestParam(value = "name", required = false) String name);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "last-session", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getLastSession(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                     @RequestParam(value = "externalId", required = false) Long externalId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "consent", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveConsent(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestBody AuthReq req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "consent", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getConsent(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestParam(value = "termsOfUse", required = false) Boolean termsOfUse,
                                 @RequestParam(value = "privacyPolicy", required = false) Boolean privacyPolicy,
                                 @RequestParam(value = "sber500PrivacyPolicy", required = false) Boolean sber500PrivacyPolicy,
                                 @RequestParam(value = "sber500Consent", required = false) Boolean sber500Consent,
                                 @RequestParam(value = "sber500TermOfUse", required = false) Boolean sber500TermOfUse,
                                 @RequestParam(value = "sber500PersonalDataConsent", required = false) Boolean sber500PersonalDataConsent,
                                 @RequestParam(value = "mailingConsent", required = false) Boolean mailingConsent);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @DeleteMapping(value = "application-delete", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> applicationDelete(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                        @RequestHeader(Constants.Headers.USER_ID) String userId,
                                        @RequestHeader(Constants.Headers.ROLE) String role,
                                        @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "companyuser/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getCompanyUserList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                         @RequestHeader(Constants.Headers.USER_ID) Long userId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "companyuser", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> createCompanyUser(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                        @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                        @RequestBody Map<String, Object> req);
}
