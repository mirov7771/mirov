package ru.sberx.gateway.util;

public enum Action {

    AUTH("auth"),
    INVALID_SESSION("checksession"),
    LOGOUT("logout"),
    PILOT_ADD_UPDATE("pilot"),
    FEEDBACK_ADD_UPDATE("feedback"),
    REPLY_ADD_UPDATE("reply"),
    VERIFY("verify"),
    VERIFY_Q_2004("20004_Q"),
    VERIFY_P_2009("20009_P"),
    VERIFY_P_2004("20004_P"),
    REPLY_Q_0("0_Q"),
    REPLY_Q_1("1_Q"),
    REPLY_P_0("0_P"),
    REPLY_P_1("1_P"),
    QUESTIONNAIRE_ADD_UPDATE("questionary"),
    USER_DELETE("user");

    private final String value;

    Action(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static String getActionName(String value){
        for(Action action : Action.values()){
            if (value.contains(action.value))
                return action.toString();
        }
        return value;
    }
}
