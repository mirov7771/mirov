package ru.sberx.gateway.gate.sberx;

import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

import java.util.Map;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

@FeignClient(name = "notificationGate", url = "${feign.client.sberx.notification}", configuration = SberxGateConfig.class)
public interface NotificationGate {

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "notice/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getNotice(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                @PathVariable Long id);


    @Headers("Content-Type: application/json;charset=UTF-8")
    @DeleteMapping(value = "notice/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> deleteNotice(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                   @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                   @PathVariable Long id);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "notice/list", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getNoticeList(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                    @RequestParam(required = false) Integer rowCount,
                                    @RequestParam(required = false) Integer pageToken,
                                    @RequestParam(required = false) Boolean watched);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "notice/amount", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> getNoticeAmount(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                      @RequestHeader(Constants.Headers.USER_ID) Long userId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "notice/{id}", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> putNotice(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                @PathVariable Long id,
                                @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PostMapping(value = "notice", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> postNotice(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                 @RequestHeader(value = Constants.Headers.SEND_USER_ID, required = false) Long sendUserId,
                                 @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "notice/watched", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> patchNotice(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                  @RequestHeader(Constants.Headers.USER_ID) Long userId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @PutMapping(value = "permission", produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> putPermission(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                    @RequestHeader(Constants.Headers.USER_ID) Long userId,
                                    @RequestHeader(Constants.Headers.TYPE_ID) Integer typeId,
                                    @RequestBody Map<String, Object> req);

    @GetMapping(value = "health/mail", produces = MediaType.TEXT_PLAIN_VALUE)
    ResponseEntity<String> mailHeath();
}
