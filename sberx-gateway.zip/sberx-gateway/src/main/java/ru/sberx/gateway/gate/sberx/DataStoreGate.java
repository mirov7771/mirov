package ru.sberx.gateway.gate.sberx;

import static ru.sberx.gateway.util.Constants.APPLICATION_JSON_VALUE;

import feign.Headers;
import java.util.Map;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.gateway.gate.config.SberxGateConfig;
import ru.sberx.gateway.util.Constants;

@FeignClient(name = "dataStoreGate", url = "${feign.client.sberx.datastore}", configuration = SberxGateConfig.class)
public interface DataStoreGate {

    @RequestMapping(value = "file/{name}", method = RequestMethod.GET)
    ResponseEntity<byte[]> getFile(@RequestHeader(value = Constants.Headers.REQUEST_ID, required = false) String requestId,
                                   @PathVariable("name") String name,
                                   @RequestHeader(value = "sessionId", required = false) String sessionId);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "file", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveFile(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                               @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @RequestMapping(value = "/v2/file", method = RequestMethod.POST, consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
    ResponseEntity<?> saveFileV2(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                 @RequestBody Map<String, Object> req);

    @Headers("Content-Type: application/json;charset=UTF-8")
    @GetMapping(value = "/v2/files/{id}/status")
    ResponseEntity<?> getAvScanStatus(@RequestHeader(Constants.Headers.REQUEST_ID) String requestId,
                                      @PathVariable("id") String id);

}
