###Proxy Сервис для методов из DeliveryServicesPort

- SOAP: GetDeliveryRegion --> REST: sbermobile/api/v1/getDeliveryRegion
- SOAP: OrderDeliverySIM --> REST: sbermobile/api/v1/orderDeliverySim
- SOAP: GetOrderDetail --> REST: sbermobile/api/v1/getOrderDetail

####Properties
- application.telecom.url - урл вэб-сервиса (soap)
- application.telecom.service - название эндпоинта вэб-сервиса (soap)
- application.telecom.timeout -  время ожидания ответа от вэб-сервиса (soap)
- application.telecom.system -  очередь