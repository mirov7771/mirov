package ru.telecom.gateway.controller.order.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;


@Schema(description = "структура ответа",
        example = "{\n" +
                "    \"orderDeliveryId\": 1006014072,\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Заказ 1006014072 будет доставлен 11.02.2021 c 09:00 до 12:00 ч. К оплате 500 руб. Курьер за 1ч свяжется с Вами. Поддержка клиентов 89800800000\"\n" +
                "    }\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class OrderDeliverySIMRes extends BaseRes {
    @Schema(minimum = "0", maximum = "100000000000", example = "1006014072", description = "Результат выполнения заказа SIM-карты")
    private BigDecimal orderDeliveryId;
}
