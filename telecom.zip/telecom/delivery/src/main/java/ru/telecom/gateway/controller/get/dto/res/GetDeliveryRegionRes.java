package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;


@Schema(description = "структура ответа",
        example = "{\n" +
                "    \"deliveryRegions\": [\n" +
                "        {\n" +
                "            \"deliveryDistricts\": [\n" +
                "                {\n" +
                "                    \"courierDelivery\": \"Y\",\n" +
                "                    \"districtName\": \"Москва\",\n" +
                "                    \"pickup\": \"Y\"\n" +
                "                }\n" +
                "            ],\n" +
                "            \"okato\": \"45000000000\",\n" +
                "            \"regionName\": \"Москва\"\n" +
                "        }\n" +
                "    ],\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                "    }\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetDeliveryRegionRes extends BaseRes {

    @ArraySchema(maxItems = 1000000000)
    private List<DeliveryRegion> deliveryRegions;

    @Schema(description = "структура объекта",
            example = "{\n" +
                      "    \"deliveryDistricts\": [\n" +
                      "        {\n" +
                      "            \"courierDelivery\": \"Y\",\n" +
                      "            \"districtName\": \"Москва\",\n" +
                      "            \"pickup\": \"Y\"\n" +
                      "        }\n" +
                      "    ],\n" +
                      "    \"okato\": \"45000000000\",\n" +
                      "    \"regionName\": \"Москва\"\n" +
                      "}")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class DeliveryRegion {
        @Schema(maxLength = 11, example = "46000000000", pattern = "^(.*){11}$", description = "Код ОКАТО")
        private String okato;
        @Schema(maxLength = 250, example = "Москва", pattern = "^(.*){250}$", description = "Название региона")
        private String regionName;
        @ArraySchema(maxItems = 1000)
        private List<DeliveryDistricts> deliveryDistricts;

        @Schema(description = "структура объекта",
                example = "{\n" +
                          "    \"courierDelivery\": \"Y\",\n" +
                          "    \"districtName\": \"Москва\",\n" +
                          "    \"pickup\": \"Y\"\n" +
                          "}")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class DeliveryDistricts {
            @Schema(maxLength = 1, example = "Y", pattern = "^(.*){1}$", allowableValues = {"Y", "N"}, description = "Возможна курьерская доставка")
            private String courierDelivery;
            @Schema(maxLength = 1, example = "N", pattern = "^(.*){1}$", allowableValues = {"Y", "N"}, description = "Возможен самовывоз")
            private String pickup;
            @Schema(maxLength = 250, example = "Москва", pattern = "^(.*){250}$", description = "Название населённого пункта")
            private String districtName;
        }
    }
}
