package ru.telecom.gateway.validator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.database.function.GetDeliveryPayment;
import ru.telecom.gateway.database.function.InPCustomer;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static ru.telecom.gateway.constant.Constants.Params.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class RequestValidator {

    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;
    private final InPCustomer inPCustomer;
    private final GetDeliveryPayment getDeliveryPayment;

    public void validate(String prm, String error){
        log.info("Check if stub is On");
        if (Y.equalsIgnoreCase(getParamValue(prm, mappingConfig.getSystemCode()))){
            log.info("Stub Error On");
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, error, null);
        }
        log.info("Stub is Off");
    }

    public String getSystemParam(String prm){
        return getParamValue(prm, mappingConfig.getSystemCode());
    }

    public String getOkato(String regionId){
        String okato = null;
        if (Y.equalsIgnoreCase(getParamValue(REMAP_REGION_ID, mappingConfig.getSystemCode()))){
            String regions = getParamValue(REMAP_REGION_ID, "ORDER_SIM");
            if (StringUtils.hasText(regions)){
                Map<String, String> regionsMap = stringToMap(regions);
                if (!regionsMap.isEmpty()){
                    for (Map.Entry<String, String> entry : regionsMap.entrySet()) {
                        String key = entry.getKey();
                        if (key.equalsIgnoreCase(regionId)) {
                            okato = entry.getValue();
                            break;
                        }
                    }
                }
            }
        } else {
            okato = inPCustomer.formatOkato(regionId);
        }
        if (StringUtils.hasText(okato))
            return okato;
        return regionId;
    }

    public BigDecimal getDeliveryPayment(String region, BigDecimal tariffId, String optionIds) {
        if (StringUtils.hasText(region) && tariffId != null) {
            try {
                Object deliveryPayment = getDeliveryPayment.getDeliveryPayment(region, tariffId, optionIds);
                if (deliveryPayment != null) {
                    if (deliveryPayment instanceof BigDecimal)
                        return (BigDecimal) (deliveryPayment);
                    if (deliveryPayment instanceof String)
                        return new BigDecimal((String) (deliveryPayment));
                    if (deliveryPayment instanceof Integer)
                        return BigDecimal.valueOf((Integer)(deliveryPayment));
                    if (deliveryPayment instanceof Long)
                        return BigDecimal.valueOf((Long) deliveryPayment);
                }
            } catch (Exception e) {
                log.error("Error getDeliveryPayment: ", e);
                return null;
            }
        }
        return null;
    }

    private Map<String, String> stringToMap(String string) {
        Map<String, String> map = new HashMap<>();
        String[] pairs = string.split(";");

        for (String pair : pairs) {
            String[] keyValue = pair.split(":");
            map.put(keyValue[0].trim(), keyValue[1].trim());
        }

        return map;
    }


    private String getParamValue(String prm, String queue){
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(prm, queue);
        if (param.isPresent())
            return param.get().getValue();
        return N;
    }

}
