package ru.telecom.gateway.gate.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.xml.delivery.*;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.telecom.service}")
    private String serviceUrl;

    @Override
    public GetDeliveryRegionResponse getDeliveryRegion(GetDeliveryRegion req) {
        return (GetDeliveryRegionResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public OrderDeliverySIMResponse orderDeliverySIM(OrderDeliverySIM req) {
        return (OrderDeliverySIMResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetOrderDetailResponse getOrderDetail(GetOrderDetail req) {
        return (GetOrderDetailResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetDeliveryTimeResponse getDeliveryTime(GetDeliveryTime req) {
        return (GetDeliveryTimeResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }
}
