package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;

@Schema(description = "структура ответа",
        example = "{\n" +
                "    \"orderDetail\": {\n" +
                "        \"branchId\": 0,\n" +
                "        \"contactPhone\": \"9151587817\",\n" +
                "        \"courierAmount\": 500,\n" +
                "        \"courierOrderSrc\": \"WebSBOL\",\n" +
                "        \"courierSrc\": \"IML\",\n" +
                "        \"courierUid\": \"1006014933\",\n" +
                "        \"fio\": \"Тест Тест Тест\",\n" +
                "        \"id\": 6014933,\n" +
                "        \"okato\": \"45000000000\",\n" +
                "        \"ratePlanId\": 37,\n" +
                "        \"region\": \"МСК+МО\",\n" +
                "        \"serviceId\": 1867,\n" +
                "        \"uid\": 1006014933\n" +
                "    },\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                "    }\n" +
                "}")
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GetOrderDetailRes extends BaseRes {

    private OrderDetail orderDetail;

    @Schema(description = "структура объекта",
            example = "{\n" +
            "        \"branchId\": 0,\n" +
            "        \"contactPhone\": \"9151587817\",\n" +
            "        \"courierAmount\": 500,\n" +
            "        \"courierOrderSrc\": \"WebSBOL\",\n" +
            "        \"courierSrc\": \"IML\",\n" +
            "        \"courierUid\": \"1006014933\",\n" +
            "        \"fio\": \"Тест Тест Тест\",\n" +
            "        \"id\": 6014933,\n" +
            "        \"okato\": \"45000000000\",\n" +
            "        \"ratePlanId\": 37,\n" +
            "        \"region\": \"МСК+МО\",\n" +
            "        \"serviceId\": 1867,\n" +
            "        \"uid\": 1006014933\n" +
            "    }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class OrderDetail{
        @Schema(minimum = "0", maximum = "100000000000", example = "994", description = "Id Филиала Оператора")
        private BigDecimal branchId;
        @Schema(maxLength = 20, example = "46000000000", pattern = "^(([0-9]){10,20})$", description = "Контактный номер телефона клиента (МП Подключи)")
        private String contactPhone;
        @Schema(minimum = "0", maximum = "100000000000", example = "249", description = "Стоимость доставки курьером в МП Подключи")
        private BigDecimal courierAmount;
        @Schema(maxLength = 250, example = "https://sbermobile.ru/", pattern = "^(.*){250}$", description = "Откуда поступил заказ в МП Подключи")
        private String courierOrderSrc;
        @Schema(maxLength = 250, example = "SbtPickup", pattern = "^(.*){250}$", description = "Назначение исполнителя заказа в МП Подключи")
        private String courierSrc;
        @Schema(maxLength = 250, example = "1002166256", pattern = "^(.*){250}$", description = "CourierUid в МП Подключи (отличается от uid)")
        private String courierUid;
        @Schema(maxLength = 250, example = "Морева Анна Владимировна", pattern = "^(.*){250}$", description = "ФИО Клиента, на кого оформлялся заказ (МП Подключи)")
        private String fio;
        @Schema(minimum = "0", maximum = "100000000000", example = "2166256", description = "Id заказа в МП Подключи")
        private BigDecimal id;
        @Schema(maxLength = 50, example = "46000000000", pattern = "^(.*){50}$", description = "Код ОКАТО")
        private String okato;
        @Schema(minimum = "0", maximum = "100000000000", example = "107", description = "Id ТП подложки (Москва) (МП Подключи)")
        private BigDecimal ratePlanId;
        @Schema(maxLength = 250, example = "Респ. Карелия", pattern = "^(.*){250}$", description = "Наименование Региона в МП Подключи")
        private String region;
        @Schema(minimum = "0", maximum = "100000000000", example = "1311", description = "Id ТП (услуги)")
        private BigDecimal serviceId;
        @Schema(minimum = "0", maximum = "100000000000", example = "1002166256", description = "Uid заказа в МП Подключи")
        private BigDecimal uid;
        @Schema(maxLength = 32, example = "1006014933", pattern = "^(.*){32}$", description = "Номер ДУЛ из REST в МП Подключи")
        private String docNo;
        @Schema(maxLength = 250, example = "mail@mail.ru", pattern = "^(.*){250}$", description = "email Клиента")
        private String email;
    }

}
