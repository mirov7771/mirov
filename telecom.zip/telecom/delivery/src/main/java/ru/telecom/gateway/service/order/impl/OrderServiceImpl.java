package ru.telecom.gateway.service.order.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.order.dto.req.OrderDeliverySIMReq;
import ru.telecom.gateway.controller.order.dto.res.OrderDeliverySIMRes;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.order.OrderService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.delivery.*;

import java.math.BigDecimal;

import static ru.telecom.gateway.constant.Constants.Keys.*;
import static ru.telecom.gateway.constant.Constants.Params.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;

    @Override
    public OrderDeliverySIMRes orderDeliverySIM(OrderDeliverySIMReq req) {
        requestValidator.validate(STUB_ODS, "Ошибка выполнения внешнего Web-сервиса");
        log.info("Stub is Off");
        OrderDeliverySIMRes res = new OrderDeliverySIMRes();
        OrderDeliverySIM input = new OrderDeliverySIM();
        Order order = new Order();
        if (StringUtils.hasText(req.getAction()))
            order.setAction(req.getAction());
        if (StringUtils.hasText(req.getChannel()))
            order.setChannel(req.getChannel());

        if (StringUtils.hasText(req.getCourierDeliveryType()))
            order.setCourierDeliveryType(req.getCourierDeliveryType());

        String pickUpAddr = requestValidator.getSystemParam(STUB_DELIVERY_ADDR);
        if (StringUtils.hasText(req.getAddress())) {
            if (StringUtils.hasText(pickUpAddr)
                    && StringUtils.hasText(req.getCourierDeliveryType())
                    && "pickup".equalsIgnoreCase(req.getCourierDeliveryType()))
                order.setAddress(pickUpAddr);
            else
                order.setAddress(req.getAddress());
        } else if (StringUtils.hasText(pickUpAddr)) {
            order.setAddress(pickUpAddr);
        }

        if (StringUtils.hasText(req.getDeliveryDate()))
            order.setDeliveryDate(req.getDeliveryDate());
        if (StringUtils.hasText(req.getDeliveryTime()))
            order.setDeliveryTime(req.getDeliveryTime());
        if (StringUtils.hasText(req.getContactPhone()))
            order.setContactPhone(req.getContactPhone());

        if (StringUtils.hasText(req.getName()))
            order.setName(req.getName());
        else
            order.setName("");

        if (Y.equalsIgnoreCase(requestValidator.getSystemParam(STUB_DELIVERY_NAME))){
            String phone = requestValidator.getSystemParam(STUB_DELIVERY_PHONE);
            if (StringUtils.hasText(phone))
                order.setContactPhone(phone);
            order.setName("Test Test");
        }

        String optionIds = req.getOptionsIds();
        if (!StringUtils.hasText(optionIds)) {
            optionIds = "";
            if (StringUtils.hasText(req.getSubPrime()))
                optionIds += SUBPRIME + ":" + req.getSubPrime();
            if (StringUtils.hasText(req.getPromoCode()))
                optionIds += (optionIds.contains(SUBPRIME) ? ";" : "") + PROMOCODE + ":" + req.getPromoCode();
            if (StringUtils.hasText(req.getServId()))
                optionIds += (optionIds.contains(SUBPRIME) || optionIds.contains(PROMOCODE) ? ";" : "") + SERVID + ":" + req.getServId();
        }
        if (StringUtils.hasText(optionIds))
            order.setOptionsIds(optionIds);

        if (req.getDeliveryRegion() != null)
            order.setDeliveryRegion(requestValidator.getOkato(req.getDeliveryRegion()));
        if (req.getTariffId() != null)
            order.setTariffId(req.getTariffId());
        if (req.getSimCount() != null)
            order.setSimCount(req.getSimCount());
        if (req.getKeepNumber() != null)
            order.setKeepNumber(req.getKeepNumber());
        if (req.getPayment() != null && !req.getPayment().equals(BigDecimal.ZERO))
            order.setPayment(req.getPayment());
        else {
            BigDecimal deliveryPayment = requestValidator.getDeliveryPayment(order.getDeliveryRegion(), req.getTariffId(), order.getOptionsIds());
            if (deliveryPayment != null)
                order.setPayment(deliveryPayment);
        }
        if (req.getClientInfo() != null){
            ClientInfo info = new ClientInfo();
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setBirthPlace(req.getClientInfo().getBirthPlace());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setGender(req.getClientInfo().getGender());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setBirthDate(req.getClientInfo().getBirthDate());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setDocType(req.getClientInfo().getDocType());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setSerial(req.getClientInfo().getSerial());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setDocId(req.getClientInfo().getDocId());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setUfmsCode(req.getClientInfo().getUfmsCode());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setIssuer(req.getClientInfo().getIssuer());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setIssueDate(req.getClientInfo().getIssueDate());
            if (StringUtils.hasText(req.getClientInfo().getBirthPlace()))
                info.setDueDate(req.getClientInfo().getDueDate());
            if (StringUtils.hasText(req.getClientInfo().getCity()))
                info.setCity(req.getClientInfo().getCity());
            if (StringUtils.hasText(req.getClientInfo().getStreet()))
                info.setStreet(req.getClientInfo().getStreet());
            if (StringUtils.hasText(req.getClientInfo().getHouse()))
                info.setHouse(req.getClientInfo().getHouse());
            if (StringUtils.hasText(req.getClientInfo().getZipCode()))
                info.setZipCode(req.getClientInfo().getZipCode());
            order.setClientInfo(info);
        }
        input.setOrder(order);
        OrderDeliverySIMResponse output = soapAPIGate.orderDeliverySIM(input);

        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения внешнего Web-сервиса", null);

        OrderDeliveryData returnData = output.getReturn();
        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        res.setOrderDeliveryId(returnData.getOrderDeliveryId());

        return res;
    }
}
