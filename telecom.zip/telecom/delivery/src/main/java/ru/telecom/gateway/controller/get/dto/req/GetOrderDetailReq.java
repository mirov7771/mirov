package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Schema(description = "структура запроса",
        example = "{\n" +
                "  \"orderNo\": \"1002166256\"\n" +
                "}")
@Data
public class GetOrderDetailReq {
    @NotNull
    @Schema(maxLength = 32, example = "1002166256", pattern = "^(.*){32}$", description = "Номер заказа в МП Подключи")
    private String orderNo;
}
