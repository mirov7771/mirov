package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "структура запроса",
        example = "{\n" +
                "    \"okato\": \"46000000000\"\n" +
                "}")
@Data
public class GetDeliveryRegionReq {
    @Schema(maxLength = 11, example = "46000000000", pattern = "^(.*){11}$", description = "Код ОКАТО")
    private String okato;
}
