package ru.telecom.gateway.controller.order.dto.req;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.controller.order.dto.support.ClientInfo;

@Schema(description = "структура запроса",
        example = "{\n" +
                "    \"action\": \"order_sim\",\n" +
                "    \"deliveryRegion\": 45000000000,\n" +
                "    \"deliveryDate\": \"11.02.2021\",\n" +
                "    \"deliveryTime\": \"09:00 - 12:00\",\n" +
                "    \"simCount\": 1,\n" +
                "    \"contactPhone\": \"9151587817\",\n" +
                "    \"name\": \"Тест Тест Тест\",\n" +
                "    \"address\": \"Ул. Южная 23\",\n" +
                "    \"keepNumber\": 0,\n" +
                "    \"tariffId\": 1867,\n" +
                "    \"payment\": 0,\n" +
                "    \"optionsIds\": \"PROMOCODE:SBER_BOX\",\n" +
                "    \"courierDeliveryType\": \"courier_delivery\",\n" +
                "    \"clientInfo\": {\n" +
                "        \"birthPlace\": \"Место рождения\",\n" +
                "        \"gender\": \"Муж\",\n" +
                "        \"birthDate\": \"01.01.2001\",\n" +
                "        \"docType\": \"Паспорт РФ\",\n" +
                "        \"serial\": \"1299\",\n" +
                "        \"docId\": \"986532\",\n" +
                "        \"ufmsCode\": \"302-005\",\n" +
                "        \"issuer\": \"Советским РОВД\",\n" +
                "        \"issueDate\": \"01.01.2001\",\n" +
                "        \"city\": \"г. Москва\",\n" +
                "        \"street\": \"ул. Вязов\",\n" +
                "        \"house\": \"13\",\n" +
                "        \"zipCode\": \"666999\"\n" +
                "    },\n" +
                "    \"channel\": \"SBER_BOX\"\n" +
                "}")
@Data
public class OrderDeliverySIMReq {
    @Schema(maxLength = 32, pattern = "^(.*){32}$", allowableValues = {"order_sim", "replace_sim"}, example = "order_sim", description = "Действие")
    private String action;
    @Schema(maxLength = 20, pattern = "^(.*){20}$", example = "45000000000", description = "Идентификатор филиала/региона")
    private String deliveryRegion;
    @Schema(maxLength = 16, pattern = "^(.*){16}$", example = "11.02.2021", description = "Дата заказа в формате dd.mm.yyyy")
    private String deliveryDate;
    @Schema(maxLength = 16, pattern = "^(.*){16}$", example = "09:00 - 12:00", description = "Временной диапазон заказа в формате HH24:MI - HH24:MI")
    private String deliveryTime;
    @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Кол-во sim в заказе", defaultValue = "1")
    private BigDecimal simCount = new BigDecimal(1);
    @Schema(maxLength = 10, pattern = "^(.*){10}$", example = "9151587817", description = "Контактный номер телефона")
    private String contactPhone;
    @Schema(maxLength = 512, pattern = "^(.*){512}$", example = "Иванов Иван Иванович", description = "ФИО Клиента/абонента")
    private String name;
    @Schema(maxLength = 1024, pattern = "^(.*){1024}$", example = "Ул. Южная 23", description = "Адрес доставки")
    private String address;
    @Schema(minimum = "0", maximum = "1", example = "0", allowableValues = {"0", "1"}, description = "нужен ли mnp")
    private BigDecimal keepNumber = new BigDecimal(0);
    @Schema(minimum = "0", maximum = "100000000000", example = "1867", description = "Идентификатор Тарифа/Пакета для подключения")
    private BigDecimal tariffId;
    @Schema(minimum = "0", maximum = "100000000000", example = "0", description = "сумма зачисления на счёт абонента при регистрации")
    private BigDecimal payment;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", example = "12e876235879345", description = "Промо код")
    private String promoCode;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", example = "e5952ac9214bf654741664f9f5e38d5e9098dca266095503de8834d49a6c955eb8a59f2f35d5394e", description = "SUB PRIME")
    private String subPrime;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", example = "1234", description = "ID сервиса")
    private String servId;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", allowableValues = {"courier_delivery", "pickup"}, defaultValue = "courier_delivery", example = "courier_delivery", description = "самовывоз или доставка курьером")
    private String courierDeliveryType = "courier_delivery";
    private ClientInfo clientInfo;
    @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "SBER_BOX", description = "Канал продаж")
    private String channel;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "PROMOCODE:SBER_BOX", description = "Опции")
    private String optionsIds;
}
