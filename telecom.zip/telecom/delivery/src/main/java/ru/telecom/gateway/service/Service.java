package ru.telecom.gateway.service;

public interface Service {
}
