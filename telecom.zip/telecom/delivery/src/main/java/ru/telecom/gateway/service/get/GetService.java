package ru.telecom.gateway.service.get;

import ru.telecom.gateway.controller.get.dto.req.GetDeliveryRegionReq;
import ru.telecom.gateway.controller.get.dto.req.GetDeliveryTimeReq;
import ru.telecom.gateway.controller.get.dto.req.GetOrderDetailReq;
import ru.telecom.gateway.controller.get.dto.res.GetDeliveryRegionRes;
import ru.telecom.gateway.controller.get.dto.res.GetDeliveryTimeRes;
import ru.telecom.gateway.controller.get.dto.res.GetOrderDetailRes;
import ru.telecom.gateway.service.Service;

public interface GetService extends Service {
    GetDeliveryRegionRes getDeliveryRegion(GetDeliveryRegionReq req);
    GetOrderDetailRes getOrderDetail(GetOrderDetailReq req);
    GetDeliveryTimeRes getDeliveryTime(GetDeliveryTimeReq req);
}
