package ru.telecom.gateway.controller.get.dto.req;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Schema(description = "структура запроса",
        example = "{\n" +
                "  \"regionId\": \"46000000000\",\n" +
                "  \"dateTime\": \"1990-08-30T13:13:13.000+0300\"\n" +
                "}")
@Data
public class GetDeliveryTimeReq {
    @NotNull
    @Schema(maxLength = 20, example = "46000000000", pattern = "^(.*){20}$", description = "Код ОКАТО")
    private String regionId;
    @NotNull
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "1990-08-30T13:13:13.000+0300", description = "Конец периода")
    private Date dateTime;
}
