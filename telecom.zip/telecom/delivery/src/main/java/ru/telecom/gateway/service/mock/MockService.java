package ru.telecom.gateway.service.mock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.res.GetOrderDetailRes;

import java.math.BigDecimal;

@Service
public class MockService {

    public GetOrderDetailRes getOrderDetail() {
        GetOrderDetailRes res = new GetOrderDetailRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));

        BigDecimal maxNum = new BigDecimal("100000000000");
        GetOrderDetailRes.OrderDetail orderDetail = new GetOrderDetailRes.OrderDetail();
        orderDetail.setBranchId(maxNum);
        orderDetail.setContactPhone("96496496496496496496");
        orderDetail.setCourierAmount(maxNum);
        orderDetail.setCourierOrderSrc(StringUtils.repeat("OK", 125));
        orderDetail.setCourierSrc(StringUtils.repeat("OK", 125));
        orderDetail.setCourierUid(StringUtils.repeat("OK", 125));
        orderDetail.setFio(StringUtils.repeat("OK", 125));
        orderDetail.setId(maxNum);
        orderDetail.setOkato(StringUtils.repeat("0", 50));
        orderDetail.setRatePlanId(maxNum);
        orderDetail.setRegion(StringUtils.repeat("OK", 125));
        orderDetail.setServiceId(maxNum);
        orderDetail.setUid(maxNum);
        orderDetail.setDocNo(StringUtils.repeat("0", 32));
        orderDetail.setEmail(StringUtils.repeat("OK", 125));
        res.setOrderDetail(orderDetail);
        return res;
    }

}
