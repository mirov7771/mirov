package ru.telecom.gateway.controller.order.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "структура объекта",
        example = "{\n" +
                "        \"birthPlace\": \"Место рождения\",\n" +
                "        \"gender\": \"Муж\",\n" +
                "        \"birthDate\": \"01.01.2001\",\n" +
                "        \"docType\": \"Паспорт РФ\",\n" +
                "        \"serial\": \"1299\",\n" +
                "        \"docId\": \"986532\",\n" +
                "        \"ufmsCode\": \"302-005\",\n" +
                "        \"issuer\": \"Советским РОВД\",\n" +
                "        \"issueDate\": \"01.01.2001\",\n" +
                "        \"city\": \"г. Москва\",\n" +
                "        \"street\": \"ул. Вязов\",\n" +
                "        \"house\": \"13\",\n" +
                "        \"zipCode\": \"666999\"\n" +
                "    }")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ClientInfo {
    @Schema(maxLength = 512, pattern = "^(.*){512}$", example = "Москва", description = "Место рождения")
    private String birthPlace;
    @Schema(maxLength = 3, pattern = "^(.*){3}$", allowableValues = {"Муж", "Жен"}, example = "Муж", description = "Пол")
    private String gender;
    @Schema(maxLength = 10, pattern = "^(.*){10}$", example = "01.01.2001", description = "Дата рождения")
    private String birthDate;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", allowableValues = {"Паспорт РФ", "Временное удостоверение личности гражданина РФ", "Паспорт иностранного гражданина", "Удостоверение личности моряка", "Дипломатический паспорт", "Вид на жительство лица без гражданства", "Удостоверение беженца", "Свидетельство о предоставлении временного убежища"}, example = "Паспорт РФ", description = "ДУЛ")
    private String docType;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "1299", description = "Серия документа")
    private String serial;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "986532", description = "Номер документа")
    private String docId;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "302-005", description = "Код УФМС подразделения")
    private String ufmsCode;
    @Schema(maxLength = 512, pattern = "^(.*){512}$", example = "Советским РОВД", description = "Кем выдан документ")
    private String issuer;
    @Schema(maxLength = 10, pattern = "^(.*){10}$", example = "01.01.2001", description = "Когда выдан документ")
    private String issueDate;
    @Schema(maxLength = 10, pattern = "^(.*){10}$", example = "01.01.2031", description = "Дата окончания действия")
    private String dueDate;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", example = "Москва", description = "Город адреса регистрации")
    private String city;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", example = "Нарвская", description = "Улица адреса регистрации")
    private String street;
    @Schema(maxLength = 128, pattern = "^(.*){128}$", example = "7", description = "Дом адреса регистрации")
    private String house;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "125130", description = "Почтовый индекс адреса регистрации")
    private String zipCode;
}
