package ru.telecom.gateway.controller.order;

import static ru.telecom.gateway.constant.Constants.APPLICATION_JSON_VALUE;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.base.support.SberApiError;
import ru.telecom.gateway.controller.order.dto.req.OrderDeliverySIMReq;
import ru.telecom.gateway.controller.order.dto.res.OrderDeliverySIMRes;
import ru.telecom.gateway.service.order.OrderService;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Tag(name = "Order Methods")
public class OrderController {

    private final OrderService service;

    @Operation(summary = "Метод формирования заказа на доставку СИМ", description = "Сформировать заказ на доставку курьером/получение в ВСП SIM-карты", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = OrderDeliverySIMRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"orderDeliveryId\": 1006014072,\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Заказ 1006014072 будет доставлен 11.02.2021 c 09:00 до 12:00 ч. К оплате 500 руб. Курьер за 1ч свяжется с Вами. Поддержка клиентов 89800800000\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = OrderDeliverySIMReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"action\": \"order_sim\",\n" +
                                    "    \"deliveryRegion\": 45000000000,\n" +
                                    "    \"deliveryDate\": \"11.02.2021\",\n" +
                                    "    \"deliveryTime\": \"09:00 - 12:00\",\n" +
                                    "    \"simCount\": 1,\n" +
                                    "    \"contactPhone\": \"9151587817\",\n" +
                                    "    \"name\": \"Тест Тест Тест\",\n" +
                                    "    \"address\": \"Ул. Южная 23\",\n" +
                                    "    \"keepNumber\": 0,\n" +
                                    "    \"tariffId\": 1867,\n" +
                                    "    \"payment\": 0,\n" +
                                    "    \"optionsIds\": \"PROMOCODE:SBER_BOX\",\n" +
                                    "    \"courierDeliveryType\": \"courier_delivery\",\n" +
                                    "    \"clientInfo\": {\n" +
                                    "        \"birthPlace\": \"Место рождения\",\n" +
                                    "        \"gender\": \"Муж\",\n" +
                                    "        \"birthDate\": \"01.01.2001\",\n" +
                                    "        \"docType\": \"Паспорт РФ\",\n" +
                                    "        \"serial\": \"1299\",\n" +
                                    "        \"docId\": \"986532\",\n" +
                                    "        \"ufmsCode\": \"302-005\",\n" +
                                    "        \"issuer\": \"Советским РОВД\",\n" +
                                    "        \"issueDate\": \"01.01.2001\",\n" +
                                    "        \"city\": \"г. Москва\",\n" +
                                    "        \"street\": \"ул. Вязов\",\n" +
                                    "        \"house\": \"13\",\n" +
                                    "        \"zipCode\": \"666999\"\n" +
                                    "    },\n" +
                                    "    \"channel\": \"SBER_BOX\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 29, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "orderDeliverySim", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<OrderDeliverySIMRes> orderDeliverySIM(@RequestBody OrderDeliverySIMReq req) {
        return ResponseBuilder.build(service.orderDeliverySIM(req));
    }

}
