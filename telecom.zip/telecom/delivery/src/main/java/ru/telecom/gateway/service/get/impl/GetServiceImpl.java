package ru.telecom.gateway.service.get.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.GetDeliveryRegionReq;
import ru.telecom.gateway.controller.get.dto.req.GetDeliveryTimeReq;
import ru.telecom.gateway.controller.get.dto.req.GetOrderDetailReq;
import ru.telecom.gateway.controller.get.dto.res.GetDeliveryRegionRes;
import ru.telecom.gateway.controller.get.dto.res.GetDeliveryTimeRes;
import ru.telecom.gateway.controller.get.dto.res.GetOrderDetailRes;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.delivery.*;

import static ru.telecom.gateway.constant.Constants.Params.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;
    private final DateBuilder dateBuilder;
    @Value("${application.telecom.stub-branch}")
    private boolean stubBranch;

    @Override
    public GetDeliveryRegionRes getDeliveryRegion(GetDeliveryRegionReq req) {
        requestValidator.validate(STUP_GDR, "Ошибка выполнения операции");
        log.info("Stub is Off");
        GetDeliveryRegionRes res = new GetDeliveryRegionRes();
        GetDeliveryRegion input = new GetDeliveryRegion();
        if (StringUtils.hasText(req.getOkato()))
            input.setOkato(req.getOkato());

        GetDeliveryRegionResponse output = soapAPIGate.getDeliveryRegion(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения операции", null);

        DeliveryData returnData = output.getReturn();
        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        if (!CollectionUtils.isEmpty(returnData.getDeliveryRegions())){
            res.setDeliveryRegions(returnData.getDeliveryRegions()
                    .stream()
                    .filter(i -> StringUtils.hasText(i.getOkato()) && i.getOkato().matches("^([0-9]){11}$"))
                    .map(i -> {
                        GetDeliveryRegionRes.DeliveryRegion dto = new GetDeliveryRegionRes.DeliveryRegion();
                        dto.setOkato(i.getOkato());
                        dto.setRegionName(i.getRegionName());
                        if (!CollectionUtils.isEmpty(i.getDeliveryDistricts())){
                            dto.setDeliveryDistricts(new ArrayList<>());
                            for(DeliveryDistricts d : i.getDeliveryDistricts()){
                                GetDeliveryRegionRes.DeliveryRegion.DeliveryDistricts item = new GetDeliveryRegionRes.DeliveryRegion.DeliveryDistricts();
                                item.setDistrictName(d.getDistrictName());
                                item.setPickup(d.getPickup());
                                item.setCourierDelivery(d.getCourierDelivery());
                                dto.getDeliveryDistricts().add(item);
                            }
                        }
                        return dto;
                    })
                    .limit(999)
                    .collect(Collectors.toList()));
        }
        return res;
    }

    @Override
    public GetOrderDetailRes getOrderDetail(GetOrderDetailReq req) {
        requestValidator.validate(STUB_GOD, "Данные о заказе не найдены");
        GetOrderDetailRes res = new GetOrderDetailRes();
        GetOrderDetail input = new GetOrderDetail();
        input.setOrderNo(req.getOrderNo());
        GetOrderDetailResponse output = soapAPIGate.getOrderDetail(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Данные о заказе не найдены", null);

        OrderDetailData returnData = output.getReturn();
        if (returnData.getResult() == null
                || (Constants.ERROR.equalsIgnoreCase(output.getReturn().getResult().getCode())
                && (returnData.getResult().getMessageUser() == null || returnData.getResult().getMessageUser().contains("ERROR"))))
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Данные о заказе не найдены", null);

        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        if (returnData.getOrderDetail() != null){
            GetOrderDetailRes.OrderDetail detail = new GetOrderDetailRes.OrderDetail();
            detail.setBranchId(returnData.getOrderDetail().getBranchId());
            detail.setUid(returnData.getOrderDetail().getUid());
            detail.setRegion(returnData.getOrderDetail().getRegion());
            detail.setRatePlanId(returnData.getOrderDetail().getRatePlanId());
            if (Boolean.TRUE.equals(stubBranch)) {
                detail.setBranchId(new BigDecimal(965));
                detail.setRatePlanId(new BigDecimal(31));
            }
            detail.setOkato(returnData.getOrderDetail().getOkato());
            detail.setId(returnData.getOrderDetail().getId());
            detail.setFio(returnData.getOrderDetail().getFio());
            detail.setEmail(returnData.getOrderDetail().getEmail());
            detail.setDocNo(returnData.getOrderDetail().getDocNo());
            detail.setCourierUid(returnData.getOrderDetail().getCourierUid());
            detail.setContactPhone(returnData.getOrderDetail().getContactPhone());
            detail.setCourierAmount(returnData.getOrderDetail().getCourierAmount());
            detail.setCourierOrderSrc(returnData.getOrderDetail().getCourierOrderSrc());
            detail.setCourierSrc(returnData.getOrderDetail().getCourierSrc());
            detail.setServiceId(returnData.getOrderDetail().getServiceId());
            res.setOrderDetail(detail);
        }
        return res;
    }

    @Override
    public GetDeliveryTimeRes getDeliveryTime(GetDeliveryTimeReq req) {
        requestValidator.validate("STUB_GDT", "Для заданного региона нет доступных дат доставки");
        GetDeliveryTime input = new GetDeliveryTime();
        input.setRegionId(requestValidator.getOkato(req.getRegionId()));
        input.setDateTime(dateBuilder.convertDate(req.getDateTime()));
        GetDeliveryTimeResponse output = soapAPIGate.getDeliveryTime(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Для заданного региона нет доступных дат доставки", null);
        GetDeliveryTimeRes res = new GetDeliveryTimeRes();
        if (output.getReturn().getResult() != null)
            res.setResult(new ResultDto(output.getReturn().getResult().getCode(), output.getReturn().getResult().getMessageUser()));
        if (!CollectionUtils.isEmpty(output.getReturn().getDeliveryDatesTimes())) {
            res.setDeliveryDatesTimes(new ArrayList<>());
            for(DeliveryDatesTimes ddt : output.getReturn().getDeliveryDatesTimes()){
                GetDeliveryTimeRes.DeliveryDatesTime time = new GetDeliveryTimeRes.DeliveryDatesTime();
                time.setDate(ddt.getDate());
                if (!CollectionUtils.isEmpty(ddt.getTimesRanges())){
                    time.setTimesRanges(ddt.getTimesRanges().stream().map(
                            i -> {
                                GetDeliveryTimeRes.DeliveryDatesTime.TimesRange range = new GetDeliveryTimeRes.DeliveryDatesTime.TimesRange();
                                range.setTimesRange(i.getTimesRange());
                                return range;
                            }
                    ).collect(Collectors.toList()));
                }
                res.getDeliveryDatesTimes().add(time);
            }
        }
        return res;
    }
}
