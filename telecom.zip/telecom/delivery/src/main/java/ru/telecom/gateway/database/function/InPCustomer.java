package ru.telecom.gateway.database.function;

import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Component
public class InPCustomer {

    @PersistenceContext
    private EntityManager entityManager;

    public String formatOkato(String region){
        return  (String) entityManager
                .createNativeQuery(
                        "SELECT IN_P_CUSTOMER.FORMAT_OKATO(:I_OKATO) FROM DUAL"
                )
                .setParameter("I_OKATO", region)
                .getSingleResult();
    }

}
