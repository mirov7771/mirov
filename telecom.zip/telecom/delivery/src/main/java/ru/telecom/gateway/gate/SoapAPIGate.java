package ru.telecom.gateway.gate;

import ru.telecom.gateway.xml.delivery.*;

public interface SoapAPIGate {
    default GetDeliveryRegionResponse getDeliveryRegion(GetDeliveryRegion req) {
        return null;
    }
    default OrderDeliverySIMResponse orderDeliverySIM(OrderDeliverySIM req) {
        return null;
    }
    default GetOrderDetailResponse getOrderDetail(GetOrderDetail req){
        return null;
    }
    default GetDeliveryTimeResponse getDeliveryTime(GetDeliveryTime req) {
        return null;
    }
}
