package ru.telecom.gateway.database.function;

import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigDecimal;

@Component
public class GetDeliveryPayment {

    @PersistenceContext
    private EntityManager entityManager;

    public Object getDeliveryPayment(String region, BigDecimal tariffId, String optionIds){
        return  entityManager
                .createNativeQuery(
                        "SELECT sh_p_order.get_delivery_payment(:I_REGIONID, :I_TARIFF_ID, :I_OPTION_IDS) FROM DUAL"
                )
                .setParameter("I_REGIONID", region)
                .setParameter("I_TARIFF_ID", tariffId)
                .setParameter("I_OPTION_IDS", optionIds)
                .getSingleResult();
    }

}
