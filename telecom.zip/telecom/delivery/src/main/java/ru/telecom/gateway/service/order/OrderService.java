package ru.telecom.gateway.service.order;

import ru.telecom.gateway.controller.order.dto.req.OrderDeliverySIMReq;
import ru.telecom.gateway.controller.order.dto.res.OrderDeliverySIMRes;
import ru.telecom.gateway.service.Service;

public interface OrderService extends Service {
    OrderDeliverySIMRes orderDeliverySIM(OrderDeliverySIMReq req);
}
