package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.util.List;

@Schema(description = "струтура ответа", example = "{\n" +
        "    \"deliveryDatesTimes\": [\n" +
        "        {\n" +
        "            \"date\": \"11.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 12:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"12:00 - 15:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"15:00 - 18:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"18:00 - 21:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        },\n" +
        "        {\n" +
        "            \"date\": \"09.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 12:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"12:00 - 15:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"15:00 - 18:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"18:00 - 21:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        },\n" +
        "        {\n" +
        "            \"date\": \"12.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 12:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"12:00 - 15:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"15:00 - 18:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"18:00 - 21:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        },\n" +
        "        {\n" +
        "            \"date\": \"08.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 12:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"12:00 - 15:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"15:00 - 18:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"18:00 - 21:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        },\n" +
        "        {\n" +
        "            \"date\": \"06.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 18:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        },\n" +
        "        {\n" +
        "            \"date\": \"10.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 12:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"12:00 - 15:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"15:00 - 18:00\"\n" +
        "                },\n" +
        "                {\n" +
        "                    \"timesRange\": \"18:00 - 21:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        },\n" +
        "        {\n" +
        "            \"date\": \"07.02.2021\",\n" +
        "            \"timesRanges\": [\n" +
        "                {\n" +
        "                    \"timesRange\": \"09:00 - 18:00\"\n" +
        "                }\n" +
        "            ]\n" +
        "        }\n" +
        "    ],\n" +
        "    \"result\": {\n" +
        "        \"code\": \"OK\",\n" +
        "        \"messageUser\": \"Операция выполнена успешно\"\n" +
        "    }\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetDeliveryTimeRes extends BaseRes {

    @ArraySchema(maxItems = 1000000000)
    private List<DeliveryDatesTime> deliveryDatesTimes;

    @Schema(description = "структура объекта", example = "{\n" +
            "            \"date\": \"11.02.2021\",\n" +
            "            \"timesRanges\": [\n" +
            "                {\n" +
            "                    \"timesRange\": \"09:00 - 12:00\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"timesRange\": \"12:00 - 15:00\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"timesRange\": \"15:00 - 18:00\"\n" +
            "                },\n" +
            "                {\n" +
            "                    \"timesRange\": \"18:00 - 21:00\"\n" +
            "                }\n" +
            "            ]\n" +
            "        }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class DeliveryDatesTime {
        private String date;
        @ArraySchema(maxItems = 1000000000)
        private List<TimesRange> timesRanges;

        @Schema(description = "структура объекта", example = "{\n" +
                "                    \"timesRange\": \"09:00 - 12:00\"\n" +
                "                }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class TimesRange {
            private String timesRange;
        }
    }
}
