package ru.telecom.gateway.gate.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.xml.promo.SrvActivatePromocode;
import ru.telecom.gateway.xml.promo.SrvActivatePromocodeResponse;
import ru.telecom.gateway.xml.promo.SrvGetPromocodeInfo;
import ru.telecom.gateway.xml.promo.SrvGetPromocodeInfoResponse;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.telecom.service}")
    private String serviceUrl;

    @Override
    public SrvGetPromocodeInfoResponse getPromocodeInfo(SrvGetPromocodeInfo req) {
        return (SrvGetPromocodeInfoResponse) getWebServiceTemplate().marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public SrvActivatePromocodeResponse activatePromocode(SrvActivatePromocode req) {
        return (SrvActivatePromocodeResponse) getWebServiceTemplate().marshalSendAndReceive(serviceUrl, req);
    }
}
