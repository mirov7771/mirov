package ru.telecom.gateway.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.JAXBElement;

public class ObjectUtils {

    public static BigDecimal getBigDecimal(Object value) {
        BigDecimal ret = null;
        if (value != null) {
            if (value instanceof BigDecimal) {
                ret = (BigDecimal) value;
            } else if (value instanceof String) {
                ret = new BigDecimal((String) value);
            } else if (value instanceof BigInteger) {
                ret = new BigDecimal((BigInteger) value);
            } else if (value instanceof Number) {
                ret = BigDecimal.valueOf(((Number) value).doubleValue());
            } else {
                throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass() +
                        " into a BigDecimal.");
            }
        }
        return ret;
    }

    public static  <T> T getValueFromJAXB(JAXBElement<T> element) {
        if (element.isNil()) {
            return null;
        }
        return element.getValue();
    }

}
