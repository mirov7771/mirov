package ru.telecom.gateway.service.get.impl;

import static ru.telecom.gateway.util.ObjectUtils.getValueFromJAXB;

import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.GetPromocodeInfoReq;
import ru.telecom.gateway.controller.get.dto.res.GetPromocodeInfoRes;
import ru.telecom.gateway.controller.get.dto.res.GetPromocodeInfoRes.PromocodeInfoDto;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.promo.Order;
import ru.telecom.gateway.xml.promo.PromoCodeData;
import ru.telecom.gateway.xml.promo.Result;
import ru.telecom.gateway.xml.promo.SrvGetPromocodeInfo;
import ru.telecom.gateway.xml.promo.SrvGetPromocodeInfoResponse;
import ru.telecom.gateway.xml.promo.TariffArray;

@Service
@Slf4j
@RequiredArgsConstructor
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;

    @Override
    public GetPromocodeInfoRes getPromocodeInfo(GetPromocodeInfoReq req) {
        requestValidator.validate("STUB_GPCI", "404", "Not Found", null);
        SrvGetPromocodeInfo soapReq = new SrvGetPromocodeInfo();
        soapReq.setMsisdn(req.getMsisdn());
        soapReq.setBranchID(req.getBranchId());
        soapReq.setCode(req.getCode());
        soapReq.setShowCase(req.getShowCase());
        if (StringUtils.hasText(req.getChannel()))
            soapReq.getChannel().setValue(req.getChannel());

        SrvGetPromocodeInfoResponse soapRes = soapAPIGate.getPromocodeInfo(soapReq);

        GetPromocodeInfoRes res = new GetPromocodeInfoRes();
        if (soapRes != null &&
                soapRes.getSrvGetPromocodeInfoResult() != null &&
                !Boolean.TRUE.equals(soapRes.getSrvGetPromocodeInfoResult().isNil()) &&
                soapRes.getSrvGetPromocodeInfoResult().getValue() != null &&
                !Boolean.TRUE.equals(soapRes.getSrvGetPromocodeInfoResult().getValue().getResult().isNil()) &&
                soapRes.getSrvGetPromocodeInfoResult().getValue().getResult().getValue() != null) {
            PromoCodeData promocodeData = soapRes.getSrvGetPromocodeInfoResult().getValue();
            Result soapResult = promocodeData.getResult().getValue();
            res.setResult(new ResultDto(getValueFromJAXB(soapResult.getCode()), getValueFromJAXB(soapResult.getMessageUser())));
            TariffArray tariffs = promocodeData.getTariffs().getValue();
            res.setTariffs(tariffs.getTarifves().stream().map(t -> {
                PromocodeInfoDto p = new PromocodeInfoDto();
                if (t.getId() != null) {
                    p.setId(t.getId().toString());
                }
                p.setName(t.getName());
                p.setOrder(t.getOrders().getValue().getOrders().stream().map(Order::getOrder).collect(Collectors.toList()));
                return p;
            }).collect(Collectors.toList()));
        }
        if (res.getResult() == null)
            throw new TelecomException("404", HttpStatus.BAD_REQUEST, "Not Found", null);
        return res;
    }

}
