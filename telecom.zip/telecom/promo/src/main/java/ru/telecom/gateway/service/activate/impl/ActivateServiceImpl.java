package ru.telecom.gateway.service.activate.impl;

import static ru.telecom.gateway.util.ObjectUtils.getValueFromJAXB;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.activate.dto.req.ActivatePromocodeReq;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.activate.ActivateService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.promo.Result;
import ru.telecom.gateway.xml.promo.SrvActivatePromocode;
import ru.telecom.gateway.xml.promo.SrvActivatePromocodeData;
import ru.telecom.gateway.xml.promo.SrvActivatePromocodeResponse;

@Service
@Slf4j
@RequiredArgsConstructor
public class ActivateServiceImpl implements ActivateService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;

    @Override
    public BaseRes activatePromocodeInfo(ActivatePromocodeReq req) {
        requestValidator.validate("STUB_APC", Constants.ERROR, "Ошибка выполнения операции", null);
        SrvActivatePromocode soapReq = new SrvActivatePromocode();
        soapReq.setBranchID(req.getBranchId());
        soapReq.setCode(req.getCode());
        soapReq.setMsisdn(req.getMsisdn());
        soapReq.setShowCase(req.getShowCase());
        if (StringUtils.hasText(req.getChannel())) {
            soapReq.getChannel().setValue(req.getChannel());
        }
        SrvActivatePromocodeResponse soapRes = soapAPIGate.activatePromocode(soapReq);
        BaseRes res = new BaseRes();
        if (soapRes != null &&
                soapRes.getSrvActivatePromocodeResult() != null &&
                !Boolean.TRUE.equals(soapRes.getSrvActivatePromocodeResult().isNil()) &&
                soapRes.getSrvActivatePromocodeResult().getValue() != null &&
                !Boolean.TRUE.equals(soapRes.getSrvActivatePromocodeResult().getValue().getResult().isNil()) &&
                soapRes.getSrvActivatePromocodeResult().getValue().getResult().getValue() != null)
        {
            SrvActivatePromocodeData soapData = soapRes.getSrvActivatePromocodeResult().getValue();
            Result soapResult = soapData.getResult().getValue();
            res.setResult(new ResultDto(getValueFromJAXB(soapResult.getCode()), getValueFromJAXB(soapResult.getMessageUser())));
        }
        if (res.getResult() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения операции", null);
        return res;
    }
}
