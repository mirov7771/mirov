package ru.telecom.gateway.validator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;

import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class RequestValidator {

    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;

    public void validate(String prm, String code, String error, String messageSystem){
        log.info("Check if stub is On");
        if ("Y".equalsIgnoreCase(getParamValue(prm, mappingConfig.getSystemCode()))){
            log.info("Stub Error On");
            throw new TelecomException(code, HttpStatus.BAD_REQUEST, error, null, messageSystem);
        }
        log.info("Stub is Off");
    }

    private String getParamValue(String prm, String queue){
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(prm, queue);
        if (param.isPresent())
            return param.get().getValue();
        return "N";
    }

}
