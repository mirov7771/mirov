package ru.telecom.gateway.service.get;

import static ru.telecom.gateway.constant.Constants.ERROR;

import org.springframework.http.HttpStatus;
import ru.telecom.gateway.controller.get.dto.req.GetPromocodeInfoReq;
import ru.telecom.gateway.controller.get.dto.res.GetPromocodeInfoRes;
import ru.telecom.gateway.exception.TelecomException;

public interface GetService {

    default GetPromocodeInfoRes getPromocodeInfo(GetPromocodeInfoReq req) {
        throw new TelecomException(ERROR, HttpStatus.METHOD_NOT_ALLOWED, "Метод не реализован", null);
    }

}
