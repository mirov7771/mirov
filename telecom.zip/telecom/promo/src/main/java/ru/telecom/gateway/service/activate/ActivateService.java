package ru.telecom.gateway.service.activate;

import static ru.telecom.gateway.constant.Constants.ERROR;

import org.springframework.http.HttpStatus;
import ru.telecom.gateway.controller.activate.dto.req.ActivatePromocodeReq;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.exception.TelecomException;

public interface ActivateService {

    default BaseRes activatePromocodeInfo(ActivatePromocodeReq req) {
        throw new TelecomException(ERROR, HttpStatus.METHOD_NOT_ALLOWED, "Метод не реализован", null);
    }

}
