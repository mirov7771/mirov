package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "Ответ на получение информации о промо коде")
@Data
public class GetPromocodeInfoRes extends BaseRes {

    private List<PromocodeInfoDto> tariffs;


    @Schema(example = "{\n" +
            "    \"id\": \"1733\",\n" +
            "    \"name\": \"SberTeam\",\n" +
            "    \"order\": [\"12345678901\"]\n" +
            "}")
    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class PromocodeInfoDto {

        @Schema(maxLength = 32, pattern = "^(\\d){10}$", example = "9585940115", description = "Номер абонента")
        private String id;
        @Schema(maxLength = 32, pattern = "^(\\d){10}$", example = "9585940115", description = "Номер абонента")
        private String name;
        @ArraySchema(maxItems = 128, minItems = 0,
                schema = @Schema(maxLength = 32, pattern = "^(\\d){10}$", example = "9585940115", description = "Номер абонента")
        )
        private List<String> order;

    }

}
