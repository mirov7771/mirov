package ru.telecom.gateway.config.mvc.interceptors;


import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;
import static ru.telecom.gateway.constant.Constants.SERVICE_NOT_AVAILABLE;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import ru.telecom.gateway.exception.TelecomException;


@Component
@RequiredArgsConstructor
public class RequestInterceptor implements HandlerInterceptor {

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");

    @Value("${application.telecom.stub500:false}")
    private Boolean stub500;
    @Value("${application.telecom.stub400:false}")
    private Boolean stub400;

    @Override
    public boolean preHandle(HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull Object handler) {
        if (Boolean.TRUE.equals(stub500))
            throw new TelecomException(ERROR, HttpStatus.INTERNAL_SERVER_ERROR, SERVICE_NOT_AVAILABLE, null);

        if (Boolean.TRUE.equals(stub400))
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, SERVICE_NOT_AVAILABLE, null);

        String rqUid = request.getHeader(RQ_UID);
        if (rqUid == null) {
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, MISSING_REQUIRED_PARAMS, "missing" + RQ_UID);
        }
        String rqTime = request.getHeader(RQ_TM);
        if (rqTime == null) {
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, MISSING_REQUIRED_PARAMS, "missing" + RQ_TM);
        }
        try {
            dateFormat.parse(rqTime);
        } catch (ParseException e) {
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, MISSING_REQUIRED_PARAMS, RQ_TM + " has wrong format. Should be " + dateFormat.toPattern());
        }
        String subsystemCode = request.getHeader(SUBSYSTEM_CODE);
        if (subsystemCode == null) {
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, MISSING_REQUIRED_PARAMS, "missing" + SUBSYSTEM_CODE);
        }
        ThreadContext.put(RQ_UID, rqUid);
        ThreadContext.put(RQ_TM, rqTime);
        ThreadContext.put(SUBSYSTEM_CODE, subsystemCode);
        return true;
    }
}
