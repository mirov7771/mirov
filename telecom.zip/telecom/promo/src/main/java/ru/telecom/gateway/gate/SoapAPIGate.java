package ru.telecom.gateway.gate;


import ru.telecom.gateway.xml.promo.SrvActivatePromocode;
import ru.telecom.gateway.xml.promo.SrvActivatePromocodeResponse;
import ru.telecom.gateway.xml.promo.SrvGetPromocodeInfo;
import ru.telecom.gateway.xml.promo.SrvGetPromocodeInfoResponse;

public interface SoapAPIGate {

    SrvGetPromocodeInfoResponse getPromocodeInfo(SrvGetPromocodeInfo req);
    SrvActivatePromocodeResponse activatePromocode(SrvActivatePromocode req);

}
