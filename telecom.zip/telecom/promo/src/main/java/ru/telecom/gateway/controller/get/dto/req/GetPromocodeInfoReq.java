package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import javax.validation.constraints.NotNull;
import lombok.Data;

@Schema(description = "Запрос на получение информации о промо коде", example = "{\n"
        + "\"msisdn\" :\"9585940115\", \n"
        + "\"branchId\" : 0, \n"
        + "\"code\" : \"111\", \n"
        + "\"showCase\" : \"AS_FS\",\n"
        + "\"channel\" :  \"AS_FS\"\n"
        + "}")
@Data
public class GetPromocodeInfoReq {

    @NotNull
    @Schema(maxLength = 20, example = "9585940115", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "0", description = "Id Филиала Оператора")
    private BigDecimal branchId;
    @NotNull
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "111", description = "Промо код")
    private String code;
    @NotNull
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "AS_FS", description = "Код витрины")
    private String showCase;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "AS_FS", description = "Код канала")
    private String channel;

}
