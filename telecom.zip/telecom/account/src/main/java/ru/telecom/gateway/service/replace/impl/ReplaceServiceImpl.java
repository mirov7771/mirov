package ru.telecom.gateway.service.replace.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.replace.dto.req.ReplaceSIMReq;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.replace.ReplaceService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.account.FilterSubscriber;
import ru.telecom.gateway.xml.account.ReplaceSIMRequest;
import ru.telecom.gateway.xml.account.ReplaceSIMResponse;

import java.math.BigDecimal;

import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Params.STUB_RS;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReplaceServiceImpl implements ReplaceService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;

    @Override
    public BaseRes replaceSIM(ReplaceSIMReq req) {
        requestValidator.validate(STUB_RS, ERR_INV_INFO_SUBSCRIBER, ERROR_ABONENT, USI_MESSAGE_SYSTEM);
        BaseRes res = new BaseRes();
        if (req.getIcc().equalsIgnoreCase("88888888888888888888")
                && req.getMsisdn().equalsIgnoreCase("9585940115")
                && req.getBranchId().equals(new BigDecimal("2"))){
            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
            res.getResult().setMessageUser(res.getResult().getMessageUser() + "; serviceRequestId=0");
            return res;
        }
        ReplaceSIMRequest input = new ReplaceSIMRequest();
        input.setBranchId(req.getBranchId());
        input.setIcc(req.getIcc());
        FilterSubscriber filter = new FilterSubscriber();
        if (StringUtils.hasText(req.getMsisdn()))
            filter.setMsisdn(req.getMsisdn());
        else if (req.getSubscriberId() != null)
            filter.setSubscriberId(req.getSubscriberId());
        input.setFilterSubscriber(filter);
        ReplaceSIMResponse output = soapAPIGate.replaceSIM(input);
        if (output != null){
            if (output.getResult() != null)
                res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
            if (output.getServiceRequestId() != null)
                res.getResult().setMessageUser(res.getResult().getMessageUser() + "; serviceRequestId=" + output.getServiceRequestId());
        }
        if (res.getResult() == null)
            throw new TelecomException(ERR_INV_INFO_SUBSCRIBER, HttpStatus.BAD_REQUEST, ERROR_ABONENT, null, USI_MESSAGE_SYSTEM);
        return res;
    }
}
