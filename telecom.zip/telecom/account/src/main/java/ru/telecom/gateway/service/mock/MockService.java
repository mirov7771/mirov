package ru.telecom.gateway.service.mock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.res.GetSubscriberICCHistoryRes;
import ru.telecom.gateway.controller.replace.dto.res.ReplaceSIMRes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class MockService {

    public BaseRes execute() {
        BaseRes res = new BaseRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        return res;
    }

    public GetSubscriberICCHistoryRes getSubscriberICCHistory() {
        GetSubscriberICCHistoryRes res = new GetSubscriberICCHistoryRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));

        res.setICCHistory(new ArrayList<>());
        GetSubscriberICCHistoryRes.ICCHistory iccHistory = new GetSubscriberICCHistoryRes.ICCHistory();

        BigDecimal maxNum = new BigDecimal("100000000000");
        iccHistory.setSubscriberId(maxNum);
        iccHistory.setIcc(StringUtils.repeat("1", 30));
        iccHistory.setStartDateTime(new Date());
        iccHistory.setEndDateTime(new Date());
        iccHistory.setCreateDateTime(new Date());
        iccHistory.setCreateUserId(maxNum);
        iccHistory.setCreateUserName(StringUtils.repeat("U", 250));
        iccHistory.setStatCardId(maxNum);
        iccHistory.setStatCardName(StringUtils.repeat("C", 250));
        iccHistory.setRn(maxNum);

        res.getICCHistory().addAll(Stream.generate(() -> iccHistory).limit(1000).collect(Collectors.toList()));

        return res;
    }

}
