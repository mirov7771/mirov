package ru.telecom.gateway.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.jms.*;

@Component
@Slf4j
public class ActiveMQProducer {

    @Value("${application.jms.host}")
    private String host;
    @Value("${application.jms.queue.doc}")
    private String docQueue;
    @Value("${application.jms.queue.replace}")
    private String replaceQueue;

    public void sendMessage(String queueName, String message) throws JMSException {
        String q = queueName.equalsIgnoreCase("docs") ? docQueue : replaceQueue;
        log.debug("ActiveMQ: Get message for send [{}] in queue [{}] (host [{}])", message, q, host);
        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(host);
        Connection connection = connectionFactory.createConnection();
        Session session = connection.createSession(false,
                Session.AUTO_ACKNOWLEDGE);
        Queue queue = session.createQueue(q);
        MessageProducer producer = session.createProducer(queue);
        producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

        producer.send(session.createTextMessage(message));
        session.close();
        connection.close();
    }

}
