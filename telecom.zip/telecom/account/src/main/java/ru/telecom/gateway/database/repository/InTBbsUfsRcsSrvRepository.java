package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.telecom.gateway.database.model.InTBbsUfsRcsSrv;

@Repository
public interface InTBbsUfsRcsSrvRepository extends CrudRepository<InTBbsUfsRcsSrv, Long> {
}
