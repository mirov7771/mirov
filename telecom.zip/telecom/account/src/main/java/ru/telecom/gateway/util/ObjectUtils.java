package ru.telecom.gateway.util;

import java.math.BigDecimal;
import java.math.BigInteger;

public class ObjectUtils {

    public static BigDecimal getBigDecimal(Object value) {
        BigDecimal ret = null;
        if (value != null) {
            if (value instanceof BigDecimal) {
                ret = (BigDecimal) value;
            } else if (value instanceof String) {
                ret = new BigDecimal((String) value);
            } else if (value instanceof BigInteger) {
                ret = new BigDecimal((BigInteger) value);
            } else if (value instanceof Number) {
                ret = BigDecimal.valueOf(((Number) value).doubleValue());
            } else {
                throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass() +
                        " into a BigDecimal.");
            }
        }
        return ret;
    }

    public static Long getLong(Object value) {
        Long ret = 0L;
        if (value != null) {
            if (value instanceof Long) {
                ret = (Long) value;
            } else if (value instanceof BigDecimal) {
                ret = ((BigDecimal) value).longValue();
            } else if (value instanceof String) {
                ret = Long.valueOf((String) value);
            } else if (value instanceof Integer) {
                ret = (((Integer) value).longValue());
            }  else if (value instanceof BigInteger) {
                ret = ((BigInteger) value).longValue();
            } else if (value instanceof Number) {
                ret = (((Number) value).longValue());
            } else {
                throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass() +
                        " into a Long.");
            }
        }
        return ret;
    }

    public static Integer getInteger(Object value) {
        Integer ret = null;
        if (value != null) {
            if (value instanceof Integer) {
                ret = (Integer) value;
            } else if (value instanceof BigDecimal) {
                ret = ((BigDecimal) value).intValue();
            } else if (value instanceof String) {
                ret = Integer.valueOf((String) value);
            } else if (value instanceof Long) {
                ret = (((Long) value).intValue());
            }  else if (value instanceof BigInteger) {
                ret = ((BigInteger) value).intValue();
            } else if (value instanceof Number) {
                ret = (((Number) value).intValue());
            } else {
                throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass() +
                        " into a Integer.");
            }
        }
        return ret;
    }

}
