package ru.telecom.gateway.validator;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;

import java.math.BigDecimal;
import java.util.*;

import static ru.telecom.gateway.constant.Constants.Params.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class RequestValidator {

    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;

    public void validate(String prm, String code, String error, String messageSystem){
        log.info("Check if stub is On");
        if (Y.equalsIgnoreCase(getParamValue(prm, mappingConfig.getSystemCode()))){
            log.info("Stub Error On");
            throw new TelecomException(code, HttpStatus.BAD_REQUEST, error, null, messageSystem);
        }
        log.info("Stub is Off");
    }

    public String getSystemParam(String prm){
        return getParamValue(prm, mappingConfig.getSystemCode());
    }

    public String getCurrentSystem() {
        return mappingConfig.getSystemCode();
    }

    public BigDecimal getBranchId(BigDecimal branchId){
        if (Y.equalsIgnoreCase(getSystemParam(SUBST_BRANCH_ID))){
            String branchTo = getSystemParam(SUBST_BRANCH_TO);
            if (StringUtils.hasText(branchTo)){
                if (!branchTo.contains(":") && !branchTo.contains(";"))
                    return new BigDecimal(branchTo);
                else {
                    Map<String, String> branchMap = stringToMap(branchTo);
                    if (branchMap.isEmpty())
                        return branchId;
                    for(Map.Entry<String, String> branch : branchMap.entrySet()){
                        if (branch.getKey().equals(branchId.toString()))
                            return new BigDecimal(branch.getValue());
                    }
                    return branchId;
                }
            }

        }
        return branchId;
    }

    public List<OstSystemParam> getSystemParams(List<String> params){
        return ostSystemParamRepository.findByCodeInAndOutSystemCode(params, mappingConfig.getSystemCode());
    }

    private String getParamValue(String prm, String queue){
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(prm, queue);
        if (param.isPresent())
            return param.get().getValue();
        return N;
    }

    private Map<String, String> stringToMap(String string) {
        Map<String, String> map = new HashMap<>();
        String[] pairs = string.split(";");

        for (String pair : pairs) {
            String[] keyValue = pair.split(":");
            map.put(keyValue[0].trim(), keyValue[1].trim());
        }

        return map;
    }

    public boolean validateDropperDate(String validTill) {
        if (!StringUtils.hasText(validTill))
            return false;
        try {
            Date date = DateUtils.parseDate(validTill, "MMM dd, yyyy HH:mm:ss",
                    "MMM dd, yyyy",
                    "yyyy-MM-dd'T'HH:mm:ss.SSSX",
                    "yyyy-MM-dd'T'HH:mm:ss.SSS",
                    "EEE, dd MMM yyyy HH:mm:ss zzz",
                    "yyyy-MM-dd",
                    "dd.MM.yyyy");
            return date.after(new Date());
        } catch (Exception e) {
            log.error("Error parsing valid_till date: ", e);
            return false;
        }
    }

}
