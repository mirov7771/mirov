package ru.telecom.gateway.constant;

import java.math.BigDecimal;
import java.util.List;

public class Constants {

    public static final String SUB_MOCK = "SBOL_PRO_SBER_API_TEST_MOCKSANEK";

    public static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    public static final String OK = "OK";
    public static final String ERROR = "ERROR";

    public static final String MISSING_REQUIRED_PARAMS = "Ошибка запроса.: Не переданы обязательные параметры";
    public static final String SERVICE_NOT_AVAILABLE = "Ошибка сервиса.: Сервис временно недоступен";
    public static final String ERROR_ABONENT = "Ошибка получения информации по абоненту.";
    public static final String ERROR_CLIENT = "Ошибка при создании клиента.";
    public static final String SUCCESS_MESSAGE = "Выполнено успешно";
    public static final String DEALER_INFO_ERROR = "Ошибка получения информации и дилере из БД.";

    public static final String ERR_INV_CREATE_CLNT = "ERR_INV_CREATE_CLNT";
    public static final String ERR_INV_INFO_ICC = "ERR_INV_INFO_ICC";
    public static final String ERR_INV_INFO_SUBSCRIBER = "ERR_INV_INFO_SUBSCRIBER";
    public static final String ERR_SERVICE_CONNECTED = "ERR_SERVICE_CONNECTED";
    public static final String ERR_INV_DEALERS = "ERR_INV_DEALERS";

    public static final String USI_PROFILE_ERROR = "Ошибка получения информации по SIM-карте.";
    public static final String USI_MESSAGE_SYSTEM = "ORA-01403: no data found (-99)";
    public static final String DEALER_INFO_ERROR_DESCRIPTION = "Operation 'GetDealers' return empty list dealers";
    
    public static final BigDecimal USI_STATUS = new BigDecimal("3");
    public static final BigDecimal BRANCH_MOSCOW = new BigDecimal("2");
    public static final BigDecimal BRANCH_SPB = new BigDecimal("4");
    public static final BigDecimal SWITCH_MOSCOW = new BigDecimal("1");
    public static final BigDecimal SWITCH_SPB = new BigDecimal("96");
    public static final BigDecimal DEALER_SPB = new BigDecimal("108");

    public static class Headers {
        public static final String RQ_UID = "RqUID";
        public static final String RQ_TM = "RqTm";
        public static final String SUBSYSTEM_CODE = "SubsystemCode";
    }

    public static class Params {
        public static final String STUB_AS = "STUB_AS";
        public static final String STUB_SSOP = "STUB_SSOP";
        public static final String STUB_RS = "STUB_RS";
        public static final String STUB_GMLP = "STUB_GMLP";
        public static final String STUB_GUP = "STUB_GUP";
        public static final String STUB_GUSIP = "STUB_GUSIP";
        public static final String STUB_GSICCH = "STUB_GSICCH";
        public static final String STUB_GCS = "STUB_GCS";
        public static final String SUBST_BRANCH_ID = "SUBST_BRANCH_ID";
        public static final String SUBST_BRANCH_TO = "SUBST_BRANCH_TO";
        public static final String STUB_RCS_ERR = "STUB_RCS_ERR";
        public static final String STUB_RCS = "STUB_RCS";
        public static final String STUB_RESERVE_MSISDN = "STUB_RESERVE_MSISDN";
        public static final String CSSS_IDS_XS_ASFS = "CSSS_IDS_XS_ASFS";
        public static final String ACTIVATE_SUBS = "ACTIVATE_SUBS";
        public static final String STUB_GDP = "STUB_GDP";
        public static final List<String> PARAMS = List.of(STUB_RESERVE_MSISDN, CSSS_IDS_XS_ASFS, ACTIVATE_SUBS, STUB_RCS);
        public static final String Y = "Y";
        public static final String N = "N";
    }

}
