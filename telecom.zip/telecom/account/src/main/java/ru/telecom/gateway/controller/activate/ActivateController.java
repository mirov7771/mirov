package ru.telecom.gateway.controller.activate;

import static ru.telecom.gateway.constant.Constants.APPLICATION_JSON_VALUE;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;
import static ru.telecom.gateway.constant.Constants.SUB_MOCK;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.activate.dto.req.ActivateSubscriberReq;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.base.support.SberApiError;
import ru.telecom.gateway.service.activate.ActivateService;
import ru.telecom.gateway.service.mock.MockService;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Tag(name = "Activate Methods")
public class ActivateController {

    private final ActivateService service;
    private final MockService mockService;

    @Operation(summary = "Метод активации абонента", description = "Возвращает результат активации абонента", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = BaseRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Выполнено успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ActivateSubscriberReq.class),
                            examples = @ExampleObject(value = "{\n"
                                    + "  \"branchId\": 0,\n"
                                    + "  \"msisdn\": \"9585940115\"\n"
                                    + "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "activateSubscriber", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<BaseRes> activateSubscriber(@RequestHeader(SUBSYSTEM_CODE) String subsystemCode,
                                                      @Valid @RequestBody ActivateSubscriberReq req) {
        if (SUB_MOCK.equalsIgnoreCase(subsystemCode))
            return ResponseBuilder.build(mockService.execute());
        else
            return ResponseBuilder.build(service.activateSubscriber(req));
    }

}
