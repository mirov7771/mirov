package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура запроса",
        example = "{\n" +
                "  \"branchId\": 2,\n" +
                "  \"outContractNameClntSubs\": \"ClientSubs\",\n" +
                "  \"msisdn\": \"9300039711\",\n" +
                "  \"clientId\": 181816,\n" +
                "  \"accountNumber\": 119205,\n" +
                "  \"contractNumber\": 1000084001,\n" +
                "  \"documentIdentityId\": 24,\n" +
                "  \"documentSeries\": \"1205\",\n" +
                "  \"documentNumber\": \"983265\",\n" +
                "  \"fullName\": \"Единая Фронтальная Система ИФТ\",\n" +
                "  \"invNum\": \"40817810\",\n" +
                "  \"balanceFlag\": 1 \n" +
                "}")
@Data
public class GetClntSubsReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @NotNull
    @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "ClientSubs", description = "Флаг, определяющий выходные параметры операции")
    private String outContractNameClntSubs;
    @Schema(minimum = "0", maximum = "100000000000", example = "181816", description = "идентификатор созданного клиента")
    private BigDecimal clientId;
    @Schema(minimum = "0", maximum = "100000000000", example = "119205", description = "Номер лицевого счета")
    private BigDecimal accountNumber;
    @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Номер контракта")
    private BigDecimal contractNumber;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @Schema(minimum = "0", maximum = "24", allowableValues = {"1", "2", "3", "4", "5", "7", "8", "9", "24"}, example = "24", description = "Вид документа")
    private BigDecimal documentIdentityId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1205", description = "Серия")
    private String documentSeries;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "983265", description = "Номер")
    private String documentNumber;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Единая Фронтальная Система ИФТ", description = "Полное имя пользователя")
    private String fullName;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "40817810", description = "Номер счета. Поле обязательное, если поиск клиента осуществляется по номеру счета")
    private String invNum;
    @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Возвращать или нет размер основного баланса. 1-возвращать.")
    private BigDecimal balanceFlag;
}
