package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура запроса",
        example = "{\n" +
                "  \"branchId\": \"2\",\n" +
                "  \"userId\": \"2\",\n" +
                "  \"userLogin\": \"UFS\"\n" +
                "}")
@Data
public class GetUserProfileReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "100000000000", example = "111", description = "Идентификатор пользователя")
    private BigDecimal userId;
    @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "UFS_IFT", description = "Логин пользователя")
    private String userLogin;
}
