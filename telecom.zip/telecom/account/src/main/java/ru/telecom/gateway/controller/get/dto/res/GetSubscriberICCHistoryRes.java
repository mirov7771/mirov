package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.config.MultiDateDeserializer;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Schema(description = "структура ответа",
        example = "{\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Выполнено успешно\"\n" +
                "    },\n" +
                "    \"ICCHistory\": [{\n" +
                "        \"subscriberId\": 172559,\n" +
                "        \"createUserId\": 965,\n" +
                "        \"statCardId\": 1,\n" +
                "        \"icc\": \"89701501078001248910\",\n" +
                "        \"createUserName\": \"MSDCRM\",\n" +
                "        \"statCardName\": \"Активирована\"\n" +
                "    }]\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetSubscriberICCHistoryRes extends BaseRes {

    @ArraySchema(maxItems = 1000000)
    private List<ICCHistory> ICCHistory;

    @Schema(description = "структура объекта",
            example = "{\n" +
            "        \"subscriberId\": 172559,\n" +
            "        \"createUserId\": 965,\n" +
            "        \"statCardId\": 1,\n" +
            "        \"icc\": \"89701501078001248910\",\n" +
            "        \"createUserName\": \"MSDCRM\",\n" +
            "        \"statCardName\": \"Активирована\"\n" +
            "    }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class ICCHistory {
        @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Идентификатор абонента")
        private BigDecimal subscriberId;
        @Schema(maxLength = 30, pattern = "^(.*){30}$", example = "89701501077100083863", description = "ICC SIM-карты")
        private String icc;
        @JsonDeserialize(using = MultiDateDeserializer.class)
        @Schema(example = "2005-08-30T13:13:13.000+0300", description = "Начало периода получения истории")
        private Date startDateTime;
        @JsonDeserialize(using = MultiDateDeserializer.class)
        @Schema(example = "2005-08-30T13:13:13.000+0300", description = "Окончания периода получения истории")
        private Date endDateTime;
        @JsonDeserialize(using = MultiDateDeserializer.class)
        @Schema(example = "2005-08-30T13:13:13.000+0300", description = "Дата создания записи")
        private Date createDateTime;
        @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id пользователя, который сменил sim-карту абоненту")
        private BigDecimal createUserId;
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "MSDCRM", description = "Имя пользователя, который сменил sim-карту абоненту")
        private String createUserName;
        @Schema(minimum = "0", maximum = "100000000000", example = "7", description = "Id статуса SIM-карты")
        private BigDecimal statCardId;
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Активирована", description = "Наименование статуса sim-карты")
        private String statCardName;
        @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Идентификтаор строки")
        private BigDecimal rn;
    }
}
