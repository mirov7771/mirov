package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура запроса",
        example = "{\n" +
        "    \"branchId\": 1,\n" +
        "    \"icc\": \"89701501078001248910\",\n" +
        "    \"iccMask\": \"1234\",\n" +
        "    \"msisdn\": \"9654728990\"\n" +
        "}")
@Data
public class GetUSIProfileReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(maxLength = 30, pattern = "^(.*){30}$", example = "89701501077100083863", description = "Открытый номер сим-карты, скрейтч-карты")
    private String icc;
    @Schema(maxLength = 30, pattern = "^(.*){30}$", description = "Маска открытого номера сим-карты, скрейтч-карты")
    private String iccMask;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
}
