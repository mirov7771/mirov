package ru.telecom.gateway.service.reserve;

import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveAccountNumberReq;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveContractNumberReq;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveMsisdnReq;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveMsisdnReturnReq;
import ru.telecom.gateway.controller.reserve.dto.res.ReserveAccountNumberRes;
import ru.telecom.gateway.controller.reserve.dto.res.ReserveContractNumberRes;
import ru.telecom.gateway.service.Service;

public interface ReserveService extends Service {
    ReserveAccountNumberRes reserveAccountNumber(ReserveAccountNumberReq req);
    ReserveContractNumberRes reserveContractNumber(ReserveContractNumberReq req);
    BaseRes reserveMsisdn(ReserveMsisdnReq req);
    BaseRes reserveMsisdnReturn(ReserveMsisdnReturnReq req);
}
