package ru.telecom.gateway.service.register;

import ru.telecom.gateway.controller.register.dto.req.RegisterClientReq;
import ru.telecom.gateway.controller.register.dto.res.RegisterClientRes;
import ru.telecom.gateway.service.Service;

public interface RegisterService extends Service {
    RegisterClientRes registerClient(RegisterClientReq req);

}
