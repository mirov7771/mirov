package ru.telecom.gateway.service.reserve.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveAccountNumberReq;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveContractNumberReq;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveMsisdnReq;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveMsisdnReturnReq;
import ru.telecom.gateway.controller.reserve.dto.res.ReserveAccountNumberRes;
import ru.telecom.gateway.controller.reserve.dto.res.ReserveContractNumberRes;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.reserve.ReserveService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.account.ReserveAccountNumberRequest;
import ru.telecom.gateway.xml.account.ReserveAccountNumberResponse;
import ru.telecom.gateway.xml.account.ReserveContractNumberRequest;
import ru.telecom.gateway.xml.account.ReserveContractNumberResponse;
import ru.telecom.gateway.xml.account.ReserveMsisdnRequest;
import ru.telecom.gateway.xml.account.ReserveMsisdnResponse;
import ru.telecom.gateway.xml.account.ReserveMsisdnReturnRequest;
import ru.telecom.gateway.xml.account.ReserveMsisdnReturnResponse;

import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReserveServiceImpl implements ReserveService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;

    @Override
    public ReserveAccountNumberRes reserveAccountNumber(ReserveAccountNumberReq req) {
        log.info("Check if stub is On");
        requestValidator.validate("STUB_RAN", "ERR_INV_ACCOUNT_NUMBER", "Ошибка резервирования номера счета в биллинговой системе.", null);
        log.info("Stub is Off");
        ReserveAccountNumberRequest soapReq = new ReserveAccountNumberRequest();
        if (req.getBranchId() != null) {
            soapReq.setBranchId(req.getBranchId());
        }
        ReserveAccountNumberResponse soapRes = soapAPIGate.reserveAccountNumber(soapReq);
        if (soapRes == null || soapRes.getResult() == null)
            throw new TelecomException("ERR_INV_ACCOUNT_NUMBER", HttpStatus.BAD_REQUEST, "Ошибка резервирования номера счета в биллинговой системе.", null);
        ReserveAccountNumberRes res = new ReserveAccountNumberRes();
        res.setResult(new ResultDto(soapRes.getResult().getCode(), soapRes.getResult().getMessageUser()));
        res.setAccountNumber(soapRes.getAccountNumber());
        return res;
    }

    @Override
    public ReserveContractNumberRes reserveContractNumber(ReserveContractNumberReq req) {
        log.info("Check if stub is On");
        requestValidator.validate("STUB_RCN", "ERR_INV_CONTRACT_NUMBER", "Ошибка резервирования номера счета в биллинговой системе.", null);
        log.info("Stub is Off");
        ReserveContractNumberRequest soapReq = new ReserveContractNumberRequest();
        if (req.getBranchId() != null) {
            soapReq.setBranchId(req.getBranchId());
        }
        ReserveContractNumberResponse soapRes = soapAPIGate.reserveContractNumber(soapReq);
        if (soapRes == null || soapRes.getResult() == null)
            throw new TelecomException("ERR_INV_CONTRACT_NUMBER", HttpStatus.BAD_REQUEST, "Ошибка резервирования номера счета в биллинговой системе.", null);
        ReserveContractNumberRes res = new ReserveContractNumberRes();
        res.setResult(new ResultDto(soapRes.getResult().getCode(), soapRes.getResult().getMessageUser()));
        res.setContractNumber(soapRes.getContractNumber());
        return res;
    }

    @Override
    public BaseRes reserveMsisdn(ReserveMsisdnReq req) {
        log.info("Check if stub is On");
        requestValidator.validate("STUB_RM", "ERR_INV_NO_DATA_FOUND_PHONE", "Указанный номер телефона не найден.", "ORA-01403: no data found (1403)");
        log.info("Stub is Off");
        ReserveMsisdnRequest soapReq = new ReserveMsisdnRequest();
        if (req.getBranchId() != null) {
            soapReq.setBranchId(requestValidator.getBranchId(req.getBranchId()));
        }
        if (StringUtils.hasText(req.getMsisdn())) {
            soapReq.setMsisdn(req.getMsisdn());
        }
        if (req.getDealerId() != null) {
            soapReq.setDealerId(req.getDealerId());
            if (req.getDealerId().equals(Constants.DEALER_SPB))
                soapReq.setBranchId(new BigDecimal(0));
        }
        ReserveMsisdnResponse soapRes = soapAPIGate.reserveMsisdn(soapReq);
        if (soapRes == null || soapRes.getResult() == null)
            throw new TelecomException("ERR_INV_NO_DATA_FOUND_PHONE", HttpStatus.BAD_REQUEST, "Указанный номер телефона не найден.", null, "ORA-01403: no data found (1403)");

        return setBaseRes(soapRes.getResult().getCode(), soapRes.getResult().getMessageUser());
    }

    @Override
    public BaseRes reserveMsisdnReturn(ReserveMsisdnReturnReq req) {
        log.info("Check if stub is On");
        requestValidator.validate("STUB_RMR", "ERR_INV_NO_DATA_FOUND_PHONE", "Указанный номер телефона не найден.", "ORA-01403: no data found (1403)");
        log.info("Stub is Off");
        ReserveMsisdnReturnRequest soapReq = new ReserveMsisdnReturnRequest();
        if (req.getBranchId() != null) {
            soapReq.setBranchId(req.getBranchId());
        }
        if (StringUtils.hasText(req.getMsisdn())) {
            soapReq.setMsisdn(req.getMsisdn());
        }
        ReserveMsisdnReturnResponse soapRes = soapAPIGate.reserveMsisdnReturn(soapReq);
        if (soapRes == null || soapRes.getResult() == null)
            throw new TelecomException("ERR_INV_NO_DATA_FOUND_PHONE", HttpStatus.BAD_REQUEST, "Указанный номер телефона не найден.", null, "ORA-01403: no data found (1403)");

        return setBaseRes(soapRes.getResult().getCode(), soapRes.getResult().getMessageUser());
    }

    private BaseRes setBaseRes(String code, String messageUser){
        BaseRes res = new BaseRes();
        res.setResult(new ResultDto(code, messageUser));
        return res;
    }
}
