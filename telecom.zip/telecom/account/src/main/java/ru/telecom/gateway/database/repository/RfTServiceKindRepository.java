package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import ru.telecom.gateway.database.model.RfTServiceKind;

import java.util.Optional;

public interface RfTServiceKindRepository extends CrudRepository<RfTServiceKind, Long> {
    Optional<RfTServiceKind> findById(Long id);
}
