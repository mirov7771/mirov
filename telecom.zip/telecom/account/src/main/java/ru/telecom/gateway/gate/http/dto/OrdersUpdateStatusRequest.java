package ru.telecom.gateway.gate.http.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class OrdersUpdateStatusRequest {
    @JsonProperty("order_number")
    private String orderNumber;
    @JsonProperty("readonly")
    private Boolean readonly;
    @JsonProperty("msisdn")
    private String msisdn;
}
