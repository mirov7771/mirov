package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура запроса",
        example = "{\n"
                + "     \"branchId\": 2,\n"
                + "     \"subscriberId\": 1,\n"
                + "     \"msisdn\": \"9585940115\"\n"
                + "}")
@Data
public class GetSubscriberICCHistoryReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Идентификатор абонента")
    private BigDecimal subscriberId;
    @Schema(maxLength = 20, example = "9585940115", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
}
