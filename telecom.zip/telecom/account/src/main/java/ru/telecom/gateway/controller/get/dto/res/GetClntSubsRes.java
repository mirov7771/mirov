package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Schema(description = "структура ответа",
        example = "{\n" +
                "  \"result\": {\n" +
                "    \"code\": \"OK\",\n" +
                "    \"messageUser\": \"Выполнено успешно\"\n" +
                "  },\n" +
                "  \"client\": {\n" +
                "    \"clientBaseParameter\": {\n" +
                "      \"branchId\": 0,\n" +
                "      \"clientId\": 0,\n" +
                "      \"clientTypeId\": 0,\n" +
                "      \"clientTypeName\": \"string\",\n" +
                "      \"clientJurTypeId\": 0,\n" +
                "      \"dealerId\": 0,\n" +
                "      \"clientStatusID\": 0,\n" +
                "      \"clientStatusName\": \"string\",\n" +
                "      \"singleBillingFlag\": \"string\",\n" +
                "      \"paymentTypeId\": 0,\n" +
                "      \"paymentTypeName\": \"string\"\n" +
                "    },\n" +
                "    \"contractDatas\": [\n" +
                "      {\n" +
                "        \"accountNumber\": 0,\n" +
                "        \"contractNumber\": 0,\n" +
                "        \"signatureContractDateTime\": \"2022-01-09T15:04:44.362Z\",\n" +
                "        \"email\": \"string\",\n" +
                "        \"resident\": 0\n" +
                "      }\n" +
                "    ],\n" +
                "    \"deliveryData\": {\n" +
                "      \"deliveryTypeId\": 0,\n" +
                "      \"deliveryTypeName\": \"string\",\n" +
                "      \"post\": \"string\",\n" +
                "      \"city\": \"string\",\n" +
                "      \"street\": \"string\",\n" +
                "      \"house\": \"string\"\n" +
                "    },\n" +
                "    \"personalProfile\": {\n" +
                "      \"fullName\": \"string\",\n" +
                "      \"genderId\": 0,\n" +
                "      \"dateOfBirth\": \"2022-01-09T15:04:44.362Z\",\n" +
                "      \"identityDocuments\": [\n" +
                "        {\n" +
                "          \"documentIdentity\": \"string\",\n" +
                "          \"country\": \"string\",\n" +
                "          \"documentSeries\": \"string\",\n" +
                "          \"documentNumber\": \"string\",\n" +
                "          \"documentDateOfIssue\": \"2022-01-09T15:04:44.362Z\",\n" +
                "          \"documentAuthority\": \"string\"\n" +
                "        }\n" +
                "      ],\n" +
                "      \"registrationAddress\": {\n" +
                "        \"country\": \"string\",\n" +
                "        \"post\": \"string\",\n" +
                "        \"region\": \"string\",\n" +
                "        \"subRegion\": \"string\",\n" +
                "        \"city\": \"string\",\n" +
                "        \"street\": \"string\",\n" +
                "        \"building\": \"string\",\n" +
                "        \"house\": \"string\"\n" +
                "      }\n" +
                "    },\n" +
                "    \"clientOptParameter\": {\n" +
                "      \"documentReference\": \"string\",\n" +
                "      \"mobileBankType\": 0,\n" +
                "      \"placeOfBirth\": \"string\",\n" +
                "      \"sellerPointId\": 0,\n" +
                "      \"sellerManager\": \"string\",\n" +
                "      \"documentDivisionCode\": \"string\",\n" +
                "      \"documentDateTo\": \"2022-01-09T15:04:44.362Z\",\n" +
                "      \"endContractDateTime\": \"2022-01-09T15:04:44.362Z\"\n" +
                "    },\n" +
                "    \"clientBalanceParameters\": [\n" +
                "      {\n" +
                "        \"balanceDigts\": [\n" +
                "          {\n" +
                "            \"balanceTypeId\": 0,\n" +
                "            \"balanceName\": \"string\",\n" +
                "            \"balanceId\": 0\n" +
                "          }\n" +
                "        ],\n" +
                "        \"balanceParameters\": [\n" +
                "          {\n" +
                "            \"clientBalanceId\": 0,\n" +
                "            \"balanceValue\": 0,\n" +
                "            \"balanceId\": 0\n" +
                "          }\n" +
                "        ]\n" +
                "      }\n" +
                "    ]\n" +
                "  },\n" +
                "  \"subsribers\": [\n" +
                "    {\n" +
                "      \"subsBaseParameter\": {\n" +
                "        \"msisdn\": \"string\",\n" +
                "        \"subscriberId\": 0,\n" +
                "        \"icc\": \"string\",\n" +
                "        \"subsTypeID\": 0,\n" +
                "        \"subsTypeName\": \"string\",\n" +
                "        \"ratePlanId\": 0,\n" +
                "        \"ratePlanName\": \"string\",\n" +
                "        \"password\": \"string\",\n" +
                "        \"subsStatusID\": 0,\n" +
                "        \"subsStatusName\": \"string\",\n" +
                "        \"activationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                "        \"registrationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                "        \"dealerName\": \"string\",\n" +
                "        \"reliabilityType\": \"string\"\n" +
                "      },\n" +
                "      \"subsOptParameter\": {\n" +
                "        \"intDivisionCode\": \"string\",\n" +
                "        \"intDivisionRegion\": \"string\",\n" +
                "        \"employeID\": 0,\n" +
                "        \"sellerCode\": \"string\",\n" +
                "        \"sellerId\": 0\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetClntSubsRes extends BaseRes {
    private GetClntSubsClient client;
    @ArraySchema(maxItems = 10000)
    private List<GetClntSubsSubscriber> subsribers;

    @Schema(description = "структура объекта",
            example = "{\n" +
                    "    \"clientBaseParameter\": {\n" +
                    "      \"branchId\": 0,\n" +
                    "      \"clientId\": 0,\n" +
                    "      \"clientTypeId\": 0,\n" +
                    "      \"clientTypeName\": \"string\",\n" +
                    "      \"clientJurTypeId\": 0,\n" +
                    "      \"dealerId\": 0,\n" +
                    "      \"clientStatusID\": 0,\n" +
                    "      \"clientStatusName\": \"string\",\n" +
                    "      \"singleBillingFlag\": \"string\",\n" +
                    "      \"paymentTypeId\": 0,\n" +
                    "      \"paymentTypeName\": \"string\"\n" +
                    "    },\n" +
                    "    \"contractDatas\": [\n" +
                    "      {\n" +
                    "        \"accountNumber\": 0,\n" +
                    "        \"contractNumber\": 0,\n" +
                    "        \"signatureContractDateTime\": \"2022-01-09T15:04:44.362Z\",\n" +
                    "        \"email\": \"string\",\n" +
                    "        \"resident\": 0\n" +
                    "      }\n" +
                    "    ],\n" +
                    "    \"deliveryData\": {\n" +
                    "      \"deliveryTypeId\": 0,\n" +
                    "      \"deliveryTypeName\": \"string\",\n" +
                    "      \"post\": \"string\",\n" +
                    "      \"city\": \"string\",\n" +
                    "      \"street\": \"string\",\n" +
                    "      \"house\": \"string\"\n" +
                    "    },\n" +
                    "    \"personalProfile\": {\n" +
                    "      \"fullName\": \"string\",\n" +
                    "      \"genderId\": 0,\n" +
                    "      \"dateOfBirth\": \"2022-01-09T15:04:44.362Z\",\n" +
                    "      \"identityDocuments\": [\n" +
                    "        {\n" +
                    "          \"documentIdentity\": \"string\",\n" +
                    "          \"country\": \"string\",\n" +
                    "          \"documentSeries\": \"string\",\n" +
                    "          \"documentNumber\": \"string\",\n" +
                    "          \"documentDateOfIssue\": \"2022-01-09T15:04:44.362Z\",\n" +
                    "          \"documentAuthority\": \"string\"\n" +
                    "        }\n" +
                    "      ],\n" +
                    "      \"registrationAddress\": {\n" +
                    "        \"country\": \"string\",\n" +
                    "        \"post\": \"string\",\n" +
                    "        \"region\": \"string\",\n" +
                    "        \"subRegion\": \"string\",\n" +
                    "        \"city\": \"string\",\n" +
                    "        \"street\": \"string\",\n" +
                    "        \"building\": \"string\",\n" +
                    "        \"house\": \"string\"\n" +
                    "      }\n" +
                    "    },\n" +
                    "    \"clientOptParameter\": {\n" +
                    "      \"documentReference\": \"string\",\n" +
                    "      \"mobileBankType\": 0,\n" +
                    "      \"placeOfBirth\": \"string\",\n" +
                    "      \"sellerPointId\": 0,\n" +
                    "      \"sellerManager\": \"string\",\n" +
                    "      \"documentDivisionCode\": \"string\",\n" +
                    "      \"documentDateTo\": \"2022-01-09T15:04:44.362Z\",\n" +
                    "      \"endContractDateTime\": \"2022-01-09T15:04:44.362Z\"\n" +
                    "    },\n" +
                    "    \"clientBalanceParameters\": [\n" +
                    "      {\n" +
                    "        \"balanceDigts\": [\n" +
                    "          {\n" +
                    "            \"balanceTypeId\": 0,\n" +
                    "            \"balanceName\": \"string\",\n" +
                    "            \"balanceId\": 0\n" +
                    "          }\n" +
                    "        ],\n" +
                    "        \"balanceParameters\": [\n" +
                    "          {\n" +
                    "            \"clientBalanceId\": 0,\n" +
                    "            \"balanceValue\": 0,\n" +
                    "            \"balanceId\": 0\n" +
                    "          }\n" +
                    "        ]\n" +
                    "      }\n" +
                    "    ]\n" +
                    "  }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class GetClntSubsClient {
        private GetClntSubsBaseParameterClnt clientBaseParameter;
        @ArraySchema(maxItems = 10000)
        private List<GetClntSubsContractData> contractDatas;
        private GetClntSubsDeliveryData deliveryData;
        private GetClntSubsPersonalProfile personalProfile;
        private GetClntSubsOptParametersClnt clientOptParameter;
        @ArraySchema(maxItems = 10000)
        private List<GetClntSubsClientBalance> clientBalanceParameters;

        @Schema(description = "структура объекта",
                example = "{\n" +
                        "      \"branchId\": 0,\n" +
                        "      \"clientId\": 0,\n" +
                        "      \"clientTypeId\": 0,\n" +
                        "      \"clientTypeName\": \"string\",\n" +
                        "      \"clientJurTypeId\": 0,\n" +
                        "      \"dealerId\": 0,\n" +
                        "      \"clientStatusID\": 0,\n" +
                        "      \"clientStatusName\": \"string\",\n" +
                        "      \"singleBillingFlag\": \"string\",\n" +
                        "      \"paymentTypeId\": 0,\n" +
                        "      \"paymentTypeName\": \"string\"\n" +
                        "    }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsBaseParameterClnt {
            @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
            private BigDecimal branchId;
            @Schema(minimum = "0", maximum = "100000000000", example = "181816", description = "идентификатор созданного клиента")
            private BigDecimal clientId;
            @Schema(minimum = "0", maximum = "100000000000", example = "181816", description = "Идентификатор типа клиента")
            private BigDecimal clientTypeId;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Клиент", description = "Наименование типа клиента")
            private String clientTypeName;
            @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Идентификатор юридического типа клиента")
            private BigDecimal clientJurTypeId;
            @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Идентификатор дилера")
            private BigDecimal dealerId;
            @Schema(minimum = "0", maximum = "100000000000", example = "181816", description = "Идентификатор статуса клиента")
            private BigDecimal clientStatusID;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Активен", description = "Наименование статуса клиента")
            private String clientStatusName;
            @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "1", description = "Признак индивидуального биллинга")
            private String singleBillingFlag;
            @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Идентификатор типа оплаты клиента")
            private BigDecimal paymentTypeId;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Авансовый", description = "Наименование типа оплаты")
            private String paymentTypeName;
        }

        @Schema(description = "структура объекта",
                example = "\n" +
                        "        \"accountNumber\": 0,\n" +
                        "        \"contractNumber\": 0,\n" +
                        "        \"signatureContractDateTime\": \"2022-01-09T15:04:44.362Z\",\n" +
                        "        \"email\": \"string\",\n" +
                        "        \"resident\": 0\n" +
                        "      }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsContractData {
            @Schema(minimum = "0", maximum = "100000000000", example = "119205", description = "Номер лицевого счета")
            private BigDecimal accountNumber;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Номер контракта")
            private BigDecimal contractNumber;
            @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата и время подписания контракта")
            private Date signatureContractDateTime;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "mail@mail.ru", description = "Электронная почта")
            private String email;
            @Schema(minimum = "0", maximum = "1", example = "1", description = "Признак резидента")
            private BigDecimal resident;
        }
        
        @Schema(description = "структура объекта",
                example = "{\n" +
                        "      \"deliveryTypeId\": 0,\n" +
                        "      \"deliveryTypeName\": \"string\",\n" +
                        "      \"post\": \"string\",\n" +
                        "      \"city\": \"string\",\n" +
                        "      \"street\": \"string\",\n" +
                        "      \"house\": \"string\"\n" +
                        "    }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsDeliveryData {
            @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Идентификатор типа доставки")
            private BigDecimal deliveryTypeId;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Курьер", description = "Наименование типа доставки")
            private String deliveryTypeName;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "125130", description = "Индекс")
            private String post;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Город")
            private String city;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Нарвская", description = "Улица")
            private String street;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "7", description = "Дом")
            private String house;
        }

        @Schema(description = "структура объекта",
                example = "{\n" +
                        "      \"fullName\": \"string\",\n" +
                        "      \"genderId\": 0,\n" +
                        "      \"dateOfBirth\": \"2022-01-09T15:04:44.362Z\",\n" +
                        "      \"identityDocuments\": [\n" +
                        "        {\n" +
                        "          \"documentIdentity\": \"string\",\n" +
                        "          \"country\": \"string\",\n" +
                        "          \"documentSeries\": \"string\",\n" +
                        "          \"documentNumber\": \"string\",\n" +
                        "          \"documentDateOfIssue\": \"2022-01-09T15:04:44.362Z\",\n" +
                        "          \"documentAuthority\": \"string\"\n" +
                        "        }\n" +
                        "      ],\n" +
                        "      \"registrationAddress\": {\n" +
                        "        \"country\": \"string\",\n" +
                        "        \"post\": \"string\",\n" +
                        "        \"region\": \"string\",\n" +
                        "        \"subRegion\": \"string\",\n" +
                        "        \"city\": \"string\",\n" +
                        "        \"street\": \"string\",\n" +
                        "        \"building\": \"string\",\n" +
                        "        \"house\": \"string\"\n" +
                        "      }\n" +
                        "    }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsPersonalProfile {
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Иванов Иван Иванович", description = "ФИО")
            private String fullName;
            @Schema(minimum = "0", maximum = "1", example = "1", description = "Идентификатор пола")
            private BigDecimal genderId;
            @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата рождения")
            private Date dateOfBirth;
            @ArraySchema(maxItems = 100)
            private List<GetClntSubsDocumentIdentity> identityDocuments;
            private GetClntSubsRegistrationAddress registrationAddress;

            @Schema(description = "структура объекта",
                    example = "{\n" +
                            "          \"documentIdentity\": \"string\",\n" +
                            "          \"country\": \"string\",\n" +
                            "          \"documentSeries\": \"string\",\n" +
                            "          \"documentNumber\": \"string\",\n" +
                            "          \"documentDateOfIssue\": \"2022-01-09T15:04:44.362Z\",\n" +
                            "          \"documentAuthority\": \"string\"\n" +
                            "        }")
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Data
            public static class GetClntSubsDocumentIdentity {
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Паспорт", description = "Тип документа")
                private String documentIdentity;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "РФ", description = "Страна")
                private String country;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "40 09", description = "Серия документа")
                private String documentSeries;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "964984", description = "Номер документа")
                private String documentNumber;
                @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата выдачи документа")
                private Date documentDateOfIssue;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "ТП №67 ОТДЕЛА УФМС РОССИИ ПО СПБ И ЛЕНИНГРАДСКОЙ ОБЛ. В ПРИМОРСКОМ Р-НЕ ГОР.САНКТ-ПЕТЕРБУРГЕ", description = "Кем выдан документ")
                private String documentAuthority;
            }

            @Schema(description = "структура объекта",
                    example = "{\n" +
                            "        \"country\": \"string\",\n" +
                            "        \"post\": \"string\",\n" +
                            "        \"region\": \"string\",\n" +
                            "        \"subRegion\": \"string\",\n" +
                            "        \"city\": \"string\",\n" +
                            "        \"street\": \"string\",\n" +
                            "        \"building\": \"string\",\n" +
                            "        \"house\": \"string\"\n" +
                            "      }")
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Data
            public static class GetClntSubsRegistrationAddress {
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Россия", description = "Страна")
                private String country;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "125130", description = "Индекс")
                private String post;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Регион")
                private String region;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Войковский", description = "Район")
                private String subRegion;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Город")
                private String city;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Нарвская", description = "Улица")
                private String street;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "2", description = "Строение")
                private String building;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "7", description = "Дом")
                private String house;                
            }
        }

        @Schema(description = "структура объекта",
                example = "{\n" +
                        "      \"documentReference\": \"string\",\n" +
                        "      \"mobileBankType\": 0,\n" +
                        "      \"placeOfBirth\": \"string\",\n" +
                        "      \"sellerPointId\": 0,\n" +
                        "      \"sellerManager\": \"string\",\n" +
                        "      \"documentDivisionCode\": \"string\",\n" +
                        "      \"documentDateTo\": \"2022-01-09T15:04:44.362Z\",\n" +
                        "      \"endContractDateTime\": \"2022-01-09T15:04:44.362Z\"\n" +
                        "    }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsOptParametersClnt {
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "https://site.ru", description = "Ссылка на договор")
            private String documentReference;
            @Schema(minimum = "0", maximum = "2", example = "2", description = "Флаг наличия на абоненте услуги мобильный банк в Сбербанке.")
            private BigDecimal mobileBankType;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Место рождения")
            private String placeOfBirth;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор точки продаж")
            private BigDecimal sellerPointId;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Иванов Иван Иванович", description = "Имя менеджера, заключившего контракт")
            private String sellerManager;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "770-077", description = "Код подразделения")
            private String documentDivisionCode;
            @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Срок действия документа")
            private Date documentDateTo;
            @Schema(example = "2023-08-30T13:13:13.000+0300", description = "Дата и время окончания контракта")
            private Date endContractDateTime;
        }

        @Schema(description = "структура объекта",
                example = "{\n" +
                        "        \"balanceDigts\": [\n" +
                        "          {\n" +
                        "            \"balanceTypeId\": 0,\n" +
                        "            \"balanceName\": \"string\",\n" +
                        "            \"balanceId\": 0\n" +
                        "          }\n" +
                        "        ],\n" +
                        "        \"balanceParameters\": [\n" +
                        "          {\n" +
                        "            \"clientBalanceId\": 0,\n" +
                        "            \"balanceValue\": 0,\n" +
                        "            \"balanceId\": 0\n" +
                        "          }\n" +
                        "        ]\n" +
                        "      }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsClientBalance {
            @ArraySchema(maxItems = 10000)
            private List<GetClntSubsBalanceDigt> balanceDigts;
            @ArraySchema(maxItems = 10000)
            private List<GetClntSubsBalanceParameter> balanceParameters;

            @JsonIgnore
            public List<GetClntSubsBalanceDigt> getBalanceDigtsList(){
                if (this.balanceDigts == null)
                    this.balanceDigts = new ArrayList<>();
                return this.balanceDigts;
            }

            @JsonIgnore
            public List<GetClntSubsBalanceParameter> getBalanceParametersList(){
                if (this.balanceParameters == null)
                    this.balanceParameters = new ArrayList<>();
                return this.balanceParameters;
            }

            @Schema(description = "структура объекта",
                    example = "{\n" +
                            "            \"balanceTypeId\": 0,\n" +
                            "            \"balanceName\": \"string\",\n" +
                            "            \"balanceId\": 0\n" +
                            "          }")
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Data
            public static class GetClntSubsBalanceDigt {
                @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор типа баланса")
                private Long balanceTypeId;
                @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "А", description = "Наименование баланса")
                private String balanceName;
                @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор баланса")
                private BigDecimal balanceId;                
            }

            @Schema(description = "структура объекта",
                    example = "{\n" +
                            "            \"clientBalanceId\": 0,\n" +
                            "            \"balanceValue\": 0,\n" +
                            "            \"balanceId\": 0\n" +
                            "          }")
            @JsonInclude(JsonInclude.Include.NON_NULL)
            @Data
            public static class GetClntSubsBalanceParameter {
                @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор баланса")
                private BigDecimal clientBalanceId;
                @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Величина баланса")
                private BigDecimal balanceValue;
                @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор баланса")
                private BigDecimal balanceId;
            }
        }
    }

    @Schema(description = "структура объекта",
            example = "{\n" +
                    "      \"subsBaseParameter\": {\n" +
                    "        \"msisdn\": \"string\",\n" +
                    "        \"subscriberId\": 0,\n" +
                    "        \"icc\": \"string\",\n" +
                    "        \"subsTypeID\": 0,\n" +
                    "        \"subsTypeName\": \"string\",\n" +
                    "        \"ratePlanId\": 0,\n" +
                    "        \"ratePlanName\": \"string\",\n" +
                    "        \"password\": \"string\",\n" +
                    "        \"subsStatusID\": 0,\n" +
                    "        \"subsStatusName\": \"string\",\n" +
                    "        \"activationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                    "        \"registrationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                    "        \"dealerName\": \"string\",\n" +
                    "        \"reliabilityType\": \"string\"\n" +
                    "      },\n" +
                    "      \"subsOptParameter\": {\n" +
                    "        \"intDivisionCode\": \"string\",\n" +
                    "        \"intDivisionRegion\": \"string\",\n" +
                    "        \"employeID\": 0,\n" +
                    "        \"sellerCode\": \"string\",\n" +
                    "        \"sellerId\": 0\n" +
                    "      }\n" +
                    "    }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class GetClntSubsSubscriber {
        private GetClntSubsBaseParameterSubs subsBaseParameter;
        private GetClntSubsOptParametersSubs subsOptParameter;

        @Schema(description = "структура объекта",
                example = "{\n" +
                        "        \"msisdn\": \"string\",\n" +
                        "        \"subscriberId\": 0,\n" +
                        "        \"icc\": \"string\",\n" +
                        "        \"subsTypeID\": 0,\n" +
                        "        \"subsTypeName\": \"string\",\n" +
                        "        \"ratePlanId\": 0,\n" +
                        "        \"ratePlanName\": \"string\",\n" +
                        "        \"password\": \"string\",\n" +
                        "        \"subsStatusID\": 0,\n" +
                        "        \"subsStatusName\": \"string\",\n" +
                        "        \"activationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                        "        \"registrationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                        "        \"dealerName\": \"string\",\n" +
                        "        \"reliabilityType\": \"string\"\n" +
                        "      }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsBaseParameterSubs {
            @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
            private String msisdn;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор абонента")
            private BigDecimal subscriberId;
            @Schema(maxLength = 30, pattern = "^(.*){30}$", example = "89701501077100083863", description = "Открытый номер сим-карты, скрейтч-карты")
            private String icc;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор типа абонента")
            private BigDecimal subsTypeID;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "PREPAID", description = "Наименование типа абонента")
            private String subsTypeName;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор тарифного плана в биллинговой системе")
            private BigDecimal ratePlanId;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Базовый(СПБ)", description = "Название тарифного плана в биллингововй системе")
            private String ratePlanName;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "123456", description = "Пароль абонента")
            private String password;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Идентификатор статуса абонента")
            private BigDecimal subsStatusID;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Активен", description = "Наименование статуса абонента")
            private String subsStatusName;
            @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата активации")
            private Date activationDate;
            @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата регистрации")
            private Date registrationDate;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Иванов Иван Иванович", description = "Наименование дилера")
            private String dealerName;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1", description = "Категория надежности")
            private String reliabilityType;
        }

        @Schema(description = "структура объекта",
                example = "{\n" +
                        "        \"intDivisionCode\": \"string\",\n" +
                        "        \"intDivisionRegion\": \"string\",\n" +
                        "        \"employeID\": 0,\n" +
                        "        \"sellerCode\": \"string\",\n" +
                        "        \"sellerId\": 0\n" +
                        "      }")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class GetClntSubsOptParametersSubs {
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "123", description = "Номер ВСП (ВСП/ОСБ/ТБ), если продажа была через ЕФС Банка")
            private String intDivisionCode;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Регион ВСП, если продажа была через ЕФС Банка")
            private String intDivisionRegion;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Табельный номер сотрудника ВСП/DSA, если продажа была через ЕФС Банка\t")
            private BigDecimal employeID;
            @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "123", description = "Код продавца")
            private String sellerCode;
            @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Код агента, выполнившего продажу")
            private BigDecimal sellerId;
        }
    }

}
