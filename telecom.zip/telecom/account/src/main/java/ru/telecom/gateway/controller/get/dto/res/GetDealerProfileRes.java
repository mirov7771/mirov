package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;
import java.util.List;

@Schema(description = "структура ответа",
        example = "{\n" +
                "\"result\": {\n" +
                "    \"code\": \"OK\",\n" +
                "    \"messageUser\": \"Выполнено успешно\"\n" +
                "},\n" +
                "\"dealerProfile\": [{\n" +
                "        \"dealerId\": 1234,\n" +
                "        \"dealerNum\": \"23\",\n" +
                "        \"dealerName\": \"МГТС\",\n" +
                "        \"clientId\": 111\n" +
                "}]\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetDealerProfileRes extends BaseRes {

    @ArraySchema(maxItems = 10000)
    private List<DealerProfile> dealerProfile;

    @Schema(description = "структура объекта",
            example = "{\n" +
                    "        \"dealerId\": 1234,\n" +
                    "        \"dealerNum\": \"23\",\n" +
                    "        \"dealerName\": \"МГТС\",\n" +
                    "        \"clientId\": 111\n" +
                    "      }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class DealerProfile {
        @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Дилера")
        private BigDecimal dealerId;
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1232232323", description = "Номер дилера")
        private String dealerNum;
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Иванов Иван Иванович", description = "Наименование дилера")
        private String dealerName;
        @Schema(minimum = "0", maximum = "100000000000", example = "181816", description = "идентификатор созданного клиента")
        private BigDecimal clientId;
    }

}
