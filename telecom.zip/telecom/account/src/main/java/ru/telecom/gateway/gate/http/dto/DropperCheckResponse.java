package ru.telecom.gateway.gate.http.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class DropperCheckResponse {
    @JsonProperty("code")
    private String code;
    @JsonProperty("single_drop_value")
    private Integer singleDropValue;
    @JsonProperty("full_dropper_value")
    private Integer fullDropperValue;
    @JsonProperty("valid_till")
    private String validTill;
    @JsonProperty("id_tariffs")
    private List<String> idTariffs;
}
