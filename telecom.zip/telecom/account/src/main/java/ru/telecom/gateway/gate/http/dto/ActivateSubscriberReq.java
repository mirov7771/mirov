package ru.telecom.gateway.gate.http.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ActivateSubscriberReq {
    @JsonProperty("name")
    private String name;
    @JsonProperty("parameters")
    private List<ActivateSubscriberReq.Parameter> parameters;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Parameter {
        @JsonProperty("msisdn")
        private String msisdn;
        @JsonProperty("subsystemCode")
        private String subsystemCode;
    }
    @JsonIgnore
    public void fillParameters(String msisdn,
                               String subsystemCode) {
        this.parameters = new ArrayList<>();
        ActivateSubscriberReq.Parameter prm1 = new ActivateSubscriberReq.Parameter();
        prm1.setMsisdn(msisdn);
        this.parameters.add(prm1);
        ActivateSubscriberReq.Parameter prm2 = new ActivateSubscriberReq.Parameter();
        prm2.setSubsystemCode(subsystemCode);
        this.parameters.add(prm2);
    }
}
