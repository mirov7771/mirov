package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;

@Schema(description = "структура ответа",
        example = "{\n" +
        "\"result\": {\n" +
        "    \"code\": \"OK\",\n" +
        "    \"messageUser\": \"Выполнено успешно\"\n" +
        "},\n" +
        "\"userProfile\": {\n" +
        "    \"userId\": 231,\n" +
        "    \"userLogin\": \"IFT\",\n" +
        "    \"branchId\": 965,\n" +
        "    \"userStatusId\": 1,\n" +
        "    \"fullName\": \"Единая Фронтальная Система ИФТ\",\n" +
        "    \"dealerId\": 108,\n" +
        "    \"departmentId\": 7\n" +
        "}\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetUserProfileRes extends BaseRes {

    private UserProfile userProfile;

    @Schema(description = "структура объекта",
            example = "{\n" +
            "    \"userId\": 231,\n" +
            "    \"userLogin\": \"IFT\",\n" +
            "    \"branchId\": 965,\n" +
            "    \"userStatusId\": 1,\n" +
            "    \"fullName\": \"Единая Фронтальная Система ИФТ\",\n" +
            "    \"dealerId\": 108,\n" +
            "    \"departmentId\": 7\n" +
            "}")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class UserProfile {
        @Schema(minimum = "0", maximum = "100000000000", example = "111", description = "Идентификатор пользователя")
        private BigDecimal userId;
        @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "UFS_IFT", description = "Логин пользователя")
        private String userLogin;
        @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
        private BigDecimal branchId;
        @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Статус пользователя")
        private BigDecimal userStatusId;
        @Schema(maxLength = 520, pattern = "^(.*){520}$", example = "Единая Фронтальная Система ИФТ", description = "Полное имя пользователя")
        private String fullName;
        @Schema(minimum = "0", maximum = "100000000000", example = "108", description = "Id Дилера")
        private BigDecimal dealerId;
        @Schema(minimum = "0", maximum = "100000000000", example = "7", description = "Id Департамента")
        private BigDecimal departmentId;
    }
}
