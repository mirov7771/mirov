package ru.telecom.gateway.controller.activate.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import javax.validation.constraints.NotNull;
import lombok.Data;

@Schema(description = "Входные данные для активации абонента",
        example = "{\n"
                + "     \"msisdn\": \"9585940115\"\n"
                + "}")
@Data
public class ActivateSubscriberReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Идентификатор абонента")
    private BigDecimal subscriberId;
    @Schema(maxLength = 20, example = "9585940115", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
}
