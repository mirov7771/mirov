package ru.telecom.gateway.service.get.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.*;
import ru.telecom.gateway.controller.get.dto.res.*;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.account.*;

import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Params.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;
    private final RequestValidator requestValidator;

    @Override
    public GetMsisdnListPoolRes getMsisdnListPool(GetMsisdnListPoolReq req) {
        log.info("Check if stub is On");
        requestValidator.validate(STUB_GMLP, "ERR_NO_MSISDN_POOL", "Нет свободных номеров для продажи.", "Свободные номера для продажи не найдены в биллинговой системе.");
        log.info("Stub is Off");
        GetMsisdnListPoolRes res = new GetMsisdnListPoolRes();
        GetMsisdnListPoolRequest input = new GetMsisdnListPoolRequest();
        input.setBranchId(req.getBranchId());
        MsisdnFilter filter = new MsisdnFilter();

        log.debug("MsisdnTypeId before transforming {}", req.getMsisdnTypeId());
        if (req.getBranchId().toString().equals("4")){
            if (req.getMsisdnTypeId() != null) {
                switch (req.getMsisdnTypeId().toString()) {
                    case "114":
                    case "115":
                    case "116":
                        filter.setMsisdnTypeId(req.getMsisdnTypeId());
                        break;
                    default:
                        filter.setMsisdnTypeId(new BigDecimal("104"));
                }
            } else {
                filter.setMsisdnTypeId(new BigDecimal("104"));
            }
        } else if (req.getBranchId().toString().equals("2")){
            if (req.getMsisdnTypeId() != null) {
                switch (req.getMsisdnTypeId().toString()){
                    case "3":
                    case "2":
                    case "4":
                        filter.setMsisdnTypeId(req.getMsisdnTypeId());
                        break;
                    default:
                        filter.setMsisdnTypeId(new BigDecimal("1"));
                }
            } else {
                filter.setMsisdnTypeId(new BigDecimal("1"));
            }
        } else {
            if (req.getMsisdnTypeId() != null) {
                filter.setMsisdnTypeId(req.getMsisdnTypeId());
            }
        }
        log.debug("MsisdnTypeId after transforming {}", filter.getMsisdnTypeId());

        log.debug("BranchID before transforming {}", req.getBranchId());
        filter.setBranchId(requestValidator.getBranchId(req.getBranchId()));
        log.debug("BranchID after transforming {}", filter.getBranchId());

        if (StringUtils.hasText(req.getMsisdnMask()))
            filter.setMsisdnMask(req.getMsisdnMask());
        if (req.getMsisdnClassId() != null)
            filter.setMsisdnClassId(req.getMsisdnClassId());
        if (req.getCountRecord() != null)
            filter.setCountRecord(req.getCountRecord());
        input.setMsisdnFilter(filter);
        GetMsisdnListPoolResponse output = soapAPIGate.getMsisdnListPool(input);
        if (output != null){
            if (output.getResult() != null)
                res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
            if (!CollectionUtils.isEmpty(output.getMsisdnPoolLists())){
                res.setMsisdnPoolList(output.getMsisdnPoolLists()
                        .stream()
                        .map(i -> {
                            GetMsisdnListPoolRes.MsisdnPool pool = new GetMsisdnListPoolRes.MsisdnPool();
                            pool.setMsisdn(i.getMsisdn());
                            pool.setMsisdnClassId(i.getMsisdnClassId());
                            pool.setMsisdnId(i.getMsisdnId());
                            pool.setMsisdnTypeId(i.getMsisdnTypeId());
                            pool.setMsisdnClassName(i.getMsisdnClassName());
                            pool.setMsisdnTypeName(i.getMsisdnTypeName());
                            return pool;
                        })
                        .collect(Collectors.toList()));
            }
        }
        if (res.getResult() == null && CollectionUtils.isEmpty(res.getMsisdnPoolList()))
            throw new TelecomException("ERR_NO_MSISDN_POOL", HttpStatus.BAD_REQUEST, "Нет свободных номеров для продажи.", null, "Свободные номера для продажи не найдены в биллинговой системе.");
        return res;
    }

    @Override
    public GetUserProfileRes getUserProfile(GetUserProfileReq req) {
        log.info("Check if stub is On");
        requestValidator.validate(STUB_GUP, "ERR_INV_USER_INFO", "Ошибка при получении информации о пользователе.", "Пользователь не найден (-99)");
        log.info("Stub is Off");
        GetUserProfileRes res = new GetUserProfileRes();
        GetUserProfileRequest input = new GetUserProfileRequest();
        log.debug("BranchID before transforming {}", req.getBranchId());
        input.setBranchId(requestValidator.getBranchId(req.getBranchId()));
        log.debug("BranchID after transforming {}", input.getBranchId());
        FilterFindUser filterFindUser = new FilterFindUser();
        if (req.getUserLogin() != null)
            filterFindUser.setUserLogin(req.getUserLogin());
        if (req.getUserId() != null)
            filterFindUser.setUserId(req.getUserId());
        input.setFilterFindUser(filterFindUser);

        GetUserProfileResponse output = soapAPIGate.getUserProfile(input);
        if (output != null) {
            if (output.getResult() != null)
                res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));

            if (output.getUserProfile() != null) {
                GetUserProfileRes.UserProfile userProfile = new GetUserProfileRes.UserProfile();
                userProfile.setUserId(output.getUserProfile().getUserId());
                userProfile.setUserLogin(output.getUserProfile().getUserLogin());
                userProfile.setBranchId(output.getUserProfile().getBranchId());
                userProfile.setUserStatusId(output.getUserProfile().getUserStatusId());
                userProfile.setFullName(output.getUserProfile().getFullName());
                if (input.getBranchId().toString().equals("0")){
                    userProfile.setDealerId(new BigDecimal("1"));
                } else {
                    userProfile.setDealerId(output.getUserProfile().getDealerId());
                }
                userProfile.setDepartmentId(output.getUserProfile().getDepartmentId());

                res.setUserProfile(userProfile);
            }
        }
        if (res.getResult() == null && res.getUserProfile() == null)
            throw new TelecomException("ERR_INV_USER_INFO", HttpStatus.BAD_REQUEST, "Ошибка при получении информации о пользователе.", null, "Пользователь не найден (-99)");
        return res;
    }

    @Override
    public GetUSIProfileRes getUSIProfile(GetUSIProfileReq req) {
        log.info("Check if stub is On");
        requestValidator.validate(STUB_GUSIP, ERR_INV_INFO_ICC, USI_PROFILE_ERROR, USI_MESSAGE_SYSTEM);
        log.info("Stub is Off");
        GetUSIProfileRes res = new GetUSIProfileRes();
        GetUSIProfileRequest input = new GetUSIProfileRequest();
        FilterFindICC filterFindICC = new FilterFindICC();
        log.debug("BranchID before transforming {}", req.getBranchId());
        BigDecimal branchId = requestValidator.getBranchId(req.getBranchId());
        String isSubstBranchId = requestValidator.getSystemParam(SUBST_BRANCH_ID);
        log.debug("BranchID after transforming {}", branchId);
        input.setBranchId(branchId);

        if (StringUtils.hasText(req.getMsisdn()))
            filterFindICC.setMsisdn(req.getMsisdn());
        if (StringUtils.hasText(req.getIccMask()))
            filterFindICC.setIccMask(req.getIccMask());
        if (StringUtils.hasText(req.getIcc()))
            filterFindICC.setIcc(req.getIcc());

        input.setFilterFindICC(filterFindICC);

        GetUSIProfileResponse output = soapAPIGate.getUSIProfile(input);
        if (output != null) {
            if (output.getResult() != null)
                res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
            if (output.getUSIProfile() != null) {
                GetUSIProfileRes.USIProfile usiProfile = new GetUSIProfileRes.USIProfile();

                BigDecimal branchIdRes = output.getUSIProfile().getBranchId();
                BigDecimal usiStatusId = output.getUSIProfile().getUsiStatusId();
                BigDecimal switchId = output.getUSIProfile().getSwitchId();
                BigDecimal dealerId = output.getUSIProfile().getDealerId();
                String switchName = output.getUSIProfile().getSwitchName();
                String msisdn = output.getUSIProfile().getMsisdn();
                String icc = output.getUSIProfile().getIcc();
                //Если во входном параметре задан один branchId, а в выходном запросе этот brachId отличается, то генерировать ошибку.
                if (!Boolean.TRUE.equals(branchId.equals(branchIdRes))) {
                    log.debug("Несоответствие значений branchId. В запросе: {}, . В ответе: {}", branchId, branchIdRes);
                    throw new TelecomException(ERR_INV_INFO_ICC, HttpStatus.BAD_REQUEST, USI_PROFILE_ERROR, null, USI_MESSAGE_SYSTEM);
                }

                // Если статус SIM-карты !=3 (Передана), то генерируем ошибку
                if (!Boolean.TRUE.equals(USI_STATUS.equals(usiStatusId))){
                    log.debug("Статус SIM-карты: {} . Не соответствует значению 3 - Передана.", usiStatusId);
                    throw new TelecomException(ERR_INV_INFO_ICC, HttpStatus.BAD_REQUEST, USI_PROFILE_ERROR, null, USI_MESSAGE_SYSTEM);
                }

                if (Y.equalsIgnoreCase(isSubstBranchId)) {
                    //Проверим, если 2 - то CENTER_MOSCOW
                    if (Boolean.TRUE.equals(BRANCH_MOSCOW.equals(req.getBranchId()))
                            && !Boolean.TRUE.equals(SWITCH_MOSCOW.equals(switchId))) {
                        log.debug("SIM-карта не соответствует указанному коммутатору. branchIdFrom = 2; switchName = {}", switchName);
                        throw new TelecomException(ERR_INV_INFO_ICC, HttpStatus.BAD_REQUEST, USI_PROFILE_ERROR, null, USI_MESSAGE_SYSTEM);
                    }

                    //Проверим, если 4 - то SZ_SAINTPETER
                    if (Boolean.TRUE.equals(BRANCH_SPB.equals(req.getBranchId()))
                            && !Boolean.TRUE.equals(DEALER_SPB.equals(dealerId))
                            && !Boolean.TRUE.equals(SWITCH_SPB.equals(switchId))) {
                        log.debug("SIM-карта не соответствует указанному коммутатору. branchIdFrom = 4; dealerId = 1; switchName = {}", switchName);
                        throw new TelecomException(ERR_INV_INFO_ICC, HttpStatus.BAD_REQUEST, USI_PROFILE_ERROR, null, USI_MESSAGE_SYSTEM);
                    }
                }

                if (Boolean.TRUE.equals(usiStatusId.equals(USI_STATUS)) && StringUtils.hasText(msisdn)){
                    log.debug("SIM-карта: {}  в процессе связывания с msisdn: {}", icc, switchName);
                    throw new TelecomException(ERR_INV_INFO_ICC, HttpStatus.BAD_REQUEST, USI_PROFILE_ERROR, null, USI_MESSAGE_SYSTEM);
                }

                usiProfile.setBranchId(branchIdRes);
                usiProfile.setDealerId(dealerId);
                usiProfile.setPartyId(output.getUSIProfile().getPartyId());
                usiProfile.setPartyTypeId(output.getUSIProfile().getPartyTypeId());
                usiProfile.setPartyStatusId(output.getUSIProfile().getPartyStatusId());
                usiProfile.setIcc(icc);
                usiProfile.setUsiId(output.getUSIProfile().getUsiId());
                usiProfile.setUsi(output.getUSIProfile().getUsi());
                usiProfile.setUsiStatusId(usiStatusId);
                usiProfile.setSwitchId(switchId);
                usiProfile.setSwitchName(switchName);
                usiProfile.setMsisdn(msisdn);
                usiProfile.setMsisdnId(output.getUSIProfile().getMsisdnId());
                usiProfile.setMsisdnStatusId(output.getUSIProfile().getMsisdnStatusId());
                usiProfile.setMsisdnStatusName(output.getUSIProfile().getMsisdnStatusName());
                res.setUsiProfile(usiProfile);
            }
        }
        if (res.getResult() == null && res.getUsiProfile() == null)
            throw new TelecomException(ERR_INV_INFO_ICC, HttpStatus.BAD_REQUEST, USI_PROFILE_ERROR, null, USI_MESSAGE_SYSTEM);
        return res;
    }

    @Override
    public GetSubscriberICCHistoryRes getSubscriberICCHistory(GetSubscriberICCHistoryReq req) {
        requestValidator.validate(STUB_GSICCH, ERR_INV_INFO_SUBSCRIBER, ERROR_ABONENT, USI_MESSAGE_SYSTEM);
        GetSubscriberICCHistoryRes res = new GetSubscriberICCHistoryRes();
        GetSubscriberICCHistoryRequest input = new GetSubscriberICCHistoryRequest();
        input.setBranchId(req.getBranchId());
        FilterSubscriber filter = new FilterSubscriber();
        if (StringUtils.hasText(req.getMsisdn()))
            filter.setMsisdn(req.getMsisdn());
        else if (req.getSubscriberId() != null)
            filter.setSubscriberId(req.getSubscriberId());
        input.setFilterSubscriber(filter);
        GetSubscriberICCHistoryResponse output = soapAPIGate.getSubscriberICCHistory(input);
        if (output != null){
            if (output.getResult() != null)
                res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
            if (!CollectionUtils.isEmpty(output.getICCHistories())){
                res.setICCHistory(output.getICCHistories()
                        .stream()
                        .map(i -> {
                            GetSubscriberICCHistoryRes.ICCHistory iccHistory = new GetSubscriberICCHistoryRes.ICCHistory();
                            iccHistory.setIcc(i.getIcc());
                            iccHistory.setSubscriberId(i.getSubscriberId());
                            iccHistory.setCreateDateTime(dateBuilder.convertDate(i.getCreateDateTime()));
                            iccHistory.setCreateUserId(i.getCreateUserId());
                            iccHistory.setEndDateTime(dateBuilder.convertDate(i.getEndDateTime()));
                            iccHistory.setStartDateTime(dateBuilder.convertDate(i.getStartDateTime()));
                            iccHistory.setStatCardName(i.getStatCardName());
                            iccHistory.setStatCardId(i.getStatCardId());
                            iccHistory.setCreateUserName(i.getCreateUserName());
                            iccHistory.setRn(i.getRn());
                            return iccHistory;
                        })
                        .collect(Collectors.toList()));
            }
        }
        if (res.getResult() == null && CollectionUtils.isEmpty(res.getICCHistory()))
            throw new TelecomException(ERR_INV_INFO_SUBSCRIBER, HttpStatus.BAD_REQUEST, ERROR_ABONENT, null, USI_MESSAGE_SYSTEM);
        return res;
    }

    @Override
    public GetClntSubsRes getClntSubs(GetClntSubsReq req) {
        requestValidator.validate(STUB_GCS, "ERR_CCAC_INFO_CLIENT", "Данные не найдены.", "get_subscriber_error : AccountManagement.getSubscriber: -99 : ORA-01403: no data found()");
        GetClntSubsRes res = new GetClntSubsRes();
        GetClntSubsRequest input = new GetClntSubsRequest();
        input.setBranchId(req.getBranchId());
        input.setOutContractNameClntSubs(OutContractNameClntSubs.fromValue(req.getOutContractNameClntSubs()));
        if (StringUtils.hasText(req.getMsisdn()))
            input.setMsisdn(req.getMsisdn());
        if (req.getDocumentIdentityId() != null){
            FilterDocumentIdentity documentIdentity = new FilterDocumentIdentity();
            documentIdentity.setDocumentIdentityId(req.getDocumentIdentityId());
            documentIdentity.setDocumentNumber(req.getDocumentNumber());
            documentIdentity.setDocumentSeries(req.getDocumentSeries());
            input.setDocumentIdentity(documentIdentity);
        }
        if (req.getClientId() != null || req.getAccountNumber() != null) {
            FilterClient client = new FilterClient();
            client.setClientId(req.getClientId());
            client.setAccountNumber(req.getAccountNumber());
            input.setClient(client);
        }
        if (req.getBalanceFlag() != null)
            input.setBalanceFlag(req.getBalanceFlag());
        if (StringUtils.hasText(req.getInvNum()))
            input.setInvNum(req.getInvNum());
        if (StringUtils.hasText(req.getFullName())){
            FilterFullName fullName = new FilterFullName();
            fullName.setFullName(req.getFullName());
            input.setFullName(fullName);
        }
        if (req.getContractNumber() != null){
            FilterContract contract = new FilterContract();
            contract.setContractNumber(req.getContractNumber());
            input.setContract(contract);
        }
        GetClntSubsResponse output = soapAPIGate.getClntSubs(input);
        if (output != null){
            if (output.getResult() != null)
                res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
            if (output.getClient() != null){
                GetClntSubsRes.GetClntSubsClient client = new GetClntSubsRes.GetClntSubsClient();
                if (!CollectionUtils.isEmpty(output.getClient().getClientBalanceParameters())){
                    client.setClientBalanceParameters(new ArrayList<>());
                    for(GetClntSubsClientBalance cb : output.getClient().getClientBalanceParameters()){
                        if (!CollectionUtils.isEmpty(cb.getBalanceDigts()) || !CollectionUtils.isEmpty(cb.getBalanceParameters())) {
                            GetClntSubsRes.GetClntSubsClient.GetClntSubsClientBalance clientBalance = new GetClntSubsRes.GetClntSubsClient.GetClntSubsClientBalance();
                            if (!CollectionUtils.isEmpty(cb.getBalanceDigts())){
                                clientBalance
                                        .getBalanceDigtsList()
                                        .addAll(cb.getBalanceDigts().stream().map(
                                                i -> {
                                                    GetClntSubsRes.GetClntSubsClient.GetClntSubsClientBalance.GetClntSubsBalanceDigt d = new GetClntSubsRes.GetClntSubsClient.GetClntSubsClientBalance.GetClntSubsBalanceDigt();
                                                    d.setBalanceName(i.getBalanceName());
                                                    d.setBalanceId(i.getBalanceId());
                                                    d.setBalanceTypeId(i.getBalanceTypeId());
                                                    return d;
                                                }
                                        ).collect(Collectors.toList()));
                            }
                            if (!CollectionUtils.isEmpty(cb.getBalanceParameters())){
                                clientBalance
                                        .getBalanceParametersList()
                                        .addAll(cb.getBalanceParameters().stream().map(
                                                i -> {
                                                    GetClntSubsRes.GetClntSubsClient.GetClntSubsClientBalance.GetClntSubsBalanceParameter b = new GetClntSubsRes.GetClntSubsClient.GetClntSubsClientBalance.GetClntSubsBalanceParameter();
                                                    b.setBalanceValue(i.getBalanceValue());
                                                    b.setBalanceId(i.getBalanceId());
                                                    b.setClientBalanceId(i.getClientBalanceId());
                                                    return b;
                                                }
                                        ).collect(Collectors.toList()));
                            }
                            client.getClientBalanceParameters().add(clientBalance);
                        }
                    }
                }
                if (output.getClient().getClientBaseParameter() != null){
                    GetClntSubsRes.GetClntSubsClient.GetClntSubsBaseParameterClnt clnt = new GetClntSubsRes.GetClntSubsClient.GetClntSubsBaseParameterClnt();
                    clnt.setClientId(output.getClient().getClientBaseParameter().getClientId());
                    clnt.setBranchId(output.getClient().getClientBaseParameter().getBranchId());
                    clnt.setClientJurTypeId(output.getClient().getClientBaseParameter().getClientJurTypeId());
                    clnt.setDealerId(output.getClient().getClientBaseParameter().getDealerId());
                    clnt.setClientStatusID(output.getClient().getClientBaseParameter().getClientStatusID());
                    clnt.setClientStatusName(output.getClient().getClientBaseParameter().getClientStatusName());
                    clnt.setClientTypeId(output.getClient().getClientBaseParameter().getClientTypeId());
                    clnt.setClientTypeName(output.getClient().getClientBaseParameter().getClientTypeName());
                    clnt.setPaymentTypeId(output.getClient().getClientBaseParameter().getPaymentTypeId());
                    clnt.setPaymentTypeName(output.getClient().getClientBaseParameter().getPaymentTypeName());
                    clnt.setSingleBillingFlag(output.getClient().getClientBaseParameter().getSingleBillingFlag());
                    client.setClientBaseParameter(clnt);
                }
                if (output.getClient().getClientOptParameter() != null){
                    GetClntSubsRes.GetClntSubsClient.GetClntSubsOptParametersClnt subs = new GetClntSubsRes.GetClntSubsClient.GetClntSubsOptParametersClnt();
                    subs.setDocumentDateTo(dateBuilder.convertDate(output.getClient().getClientOptParameter().getDocumentDateTo()));
                    subs.setDocumentReference(output.getClient().getClientOptParameter().getDocumentReference());
                    subs.setDocumentDivisionCode(output.getClient().getClientOptParameter().getDocumentDivisionCode());
                    subs.setEndContractDateTime(dateBuilder.convertDate(output.getClient().getClientOptParameter().getEndContractDateTime()));
                    subs.setMobileBankType(output.getClient().getClientOptParameter().getMobileBankType());
                    subs.setPlaceOfBirth(output.getClient().getClientOptParameter().getPlaceOfBirth());
                    subs.setSellerManager(output.getClient().getClientOptParameter().getSellerManager());
                    subs.setSellerPointId(output.getClient().getClientOptParameter().getSellerPointId());
                    client.setClientOptParameter(subs);
                }
                if (output.getClient().getDeliveryData() != null){
                    GetClntSubsRes.GetClntSubsClient.GetClntSubsDeliveryData data = new GetClntSubsRes.GetClntSubsClient.GetClntSubsDeliveryData();
                    data.setCity(output.getClient().getDeliveryData().getCity());
                    data.setDeliveryTypeId(output.getClient().getDeliveryData().getDeliveryTypeId());
                    data.setDeliveryTypeName(output.getClient().getDeliveryData().getDeliveryTypeName());
                    data.setHouse(output.getClient().getDeliveryData().getHouse());
                    data.setPost(output.getClient().getDeliveryData().getPost());
                    data.setStreet(output.getClient().getDeliveryData().getStreet());
                    client.setDeliveryData(data);
                }
                if (output.getClient().getPersonalProfile() != null){
                    GetClntSubsRes.GetClntSubsClient.GetClntSubsPersonalProfile profile = new GetClntSubsRes.GetClntSubsClient.GetClntSubsPersonalProfile();
                    profile.setFullName(output.getClient().getPersonalProfile().getFullName());
                    profile.setGenderId(output.getClient().getPersonalProfile().getGenderId());
                    profile.setDateOfBirth(dateBuilder.convertDate(output.getClient().getPersonalProfile().getDateOfBirth()));
                    if (output.getClient().getPersonalProfile().getRegistrationAddress() != null) {
                        GetClntSubsRes.GetClntSubsClient.GetClntSubsPersonalProfile.GetClntSubsRegistrationAddress address = new GetClntSubsRes.GetClntSubsClient.GetClntSubsPersonalProfile.GetClntSubsRegistrationAddress();
                        address.setStreet(output.getClient().getPersonalProfile().getRegistrationAddress().getStreet());
                        address.setCity(output.getClient().getPersonalProfile().getRegistrationAddress().getCity());
                        address.setBuilding(output.getClient().getPersonalProfile().getRegistrationAddress().getBuilding());
                        address.setHouse(output.getClient().getPersonalProfile().getRegistrationAddress().getHouse());
                        address.setPost(output.getClient().getPersonalProfile().getRegistrationAddress().getPost());
                        address.setCountry(output.getClient().getPersonalProfile().getRegistrationAddress().getCountry());
                        address.setSubRegion(output.getClient().getPersonalProfile().getRegistrationAddress().getSubRegion());
                        address.setRegion(output.getClient().getPersonalProfile().getRegistrationAddress().getRegion());
                        profile.setRegistrationAddress(address);
                    }
                    if (!CollectionUtils.isEmpty(output.getClient().getPersonalProfile().getIdentityDocuments())) {
                        profile.setIdentityDocuments(new ArrayList<>());
                        for(GetClntSubsDocumentIdentity i : output.getClient().getPersonalProfile().getIdentityDocuments()){
                            GetClntSubsRes.GetClntSubsClient.GetClntSubsPersonalProfile.GetClntSubsDocumentIdentity identity = new GetClntSubsRes.GetClntSubsClient.GetClntSubsPersonalProfile.GetClntSubsDocumentIdentity();
                            identity.setDocumentIdentity(i.getDocumentIdentity());
                            identity.setCountry(i.getCountry());
                            identity.setDocumentAuthority(i.getDocumentAuthority());
                            identity.setDocumentNumber(i.getDocumentNumber());
                            identity.setDocumentSeries(i.getDocumentSeries());
                            identity.setDocumentDateOfIssue(dateBuilder.convertDate(i.getDocumentDateOfIssue()));
                            profile.getIdentityDocuments().add(identity);
                        }
                    }
                    client.setPersonalProfile(profile);
                }
                if (!CollectionUtils.isEmpty(output.getClient().getContractDatas())){
                    client.setContractDatas(new ArrayList<>());
                    for(GetClntSubsContractData cd : output.getClient().getContractDatas()){
                        GetClntSubsRes.GetClntSubsClient.GetClntSubsContractData contractData = new GetClntSubsRes.GetClntSubsClient.GetClntSubsContractData();
                        contractData.setContractNumber(cd.getContractNumber());
                        contractData.setAccountNumber(cd.getAccountNumber());
                        contractData.setEmail(cd.getEmail());
                        contractData.setResident(cd.getResident());
                        contractData.setSignatureContractDateTime(dateBuilder.convertDate(cd.getSignatureContractDateTime()));
                        client.getContractDatas().add(contractData);
                    }
                }
                res.setClient(client);
            }
            if (!CollectionUtils.isEmpty(output.getSubsribers())){
                res.setSubsribers(new ArrayList<>());
                for(GetClntSubsSubscriber s : output.getSubsribers()){
                    if (s.getSubsBaseParameter() != null || s.getSubsOptParameter() != null) {
                        GetClntSubsRes.GetClntSubsSubscriber g = new GetClntSubsRes.GetClntSubsSubscriber();
                        if (s.getSubsBaseParameter() != null) {
                            GetClntSubsRes.GetClntSubsSubscriber.GetClntSubsBaseParameterSubs base = new GetClntSubsRes.GetClntSubsSubscriber.GetClntSubsBaseParameterSubs();
                            base.setIcc(s.getSubsBaseParameter().getIcc());
                            base.setMsisdn(s.getSubsBaseParameter().getMsisdn());
                            base.setActivationDate(dateBuilder.convertDate(s.getSubsBaseParameter().getActivationDate()));
                            base.setPassword(s.getSubsBaseParameter().getPassword());
                            base.setDealerName(s.getSubsBaseParameter().getDealerName());
                            base.setSubscriberId(s.getSubsBaseParameter().getSubscriberId());
                            base.setRatePlanId(s.getSubsBaseParameter().getRatePlanId());
                            base.setSubsStatusID(s.getSubsBaseParameter().getSubsStatusID());
                            base.setRatePlanName(s.getSubsBaseParameter().getRatePlanName());
                            base.setSubsTypeName(s.getSubsBaseParameter().getSubsTypeName());
                            base.setSubsTypeID(s.getSubsBaseParameter().getSubsTypeID());
                            base.setSubsStatusName(s.getSubsBaseParameter().getSubsStatusName());
                            base.setReliabilityType(s.getSubsBaseParameter().getReliabilityType());
                            base.setRegistrationDate(dateBuilder.convertDate(s.getSubsBaseParameter().getRegistrationDate()));
                            g.setSubsBaseParameter(base);
                        }
                        if (s.getSubsOptParameter() != null) {
                            GetClntSubsRes.GetClntSubsSubscriber.GetClntSubsOptParametersSubs opt = new GetClntSubsRes.GetClntSubsSubscriber.GetClntSubsOptParametersSubs();
                            opt.setEmployeID(s.getSubsOptParameter().getEmployeID());
                            opt.setIntDivisionCode(s.getSubsOptParameter().getIntDivisionCode());
                            opt.setSellerCode(s.getSubsOptParameter().getSellerCode());
                            opt.setSellerId(s.getSubsOptParameter().getSellerId());
                            opt.setIntDivisionRegion(s.getSubsOptParameter().getIntDivisionRegion());
                            g.setSubsOptParameter(opt);
                        }
                        res.getSubsribers().add(g);
                    }
                }
            }
        }
        if (res.getResult() == null && res.getClient() == null && CollectionUtils.isEmpty(res.getSubsribers()))
            throw new TelecomException("ERR_CCAC_INFO_CLIENT", HttpStatus.BAD_REQUEST, "Данные не найдены.", null, "get_subscriber_error : AccountManagement.getSubscriber: -99 : ORA-01403: no data found()");
        return res;
    }

    @Override
    public GetDealerProfileRes getDealerProfile(GetDealerProfileReq req) {
        requestValidator.validate(STUB_GDP, ERR_INV_DEALERS, DEALER_INFO_ERROR, DEALER_INFO_ERROR_DESCRIPTION);
        GetDealerProfileRes res = new GetDealerProfileRes();
        GetDealerProfileRequest input = new GetDealerProfileRequest();
        input.setBranchId(requestValidator.getBranchId(req.getBranchId()));
        if (req.getDealerId() != null)
            input.setDealerId(req.getDealerId());
        GetDealerProfileResponse output = soapAPIGate.getDealerProfile(input);
        if (output == null || output.getResult() == null)
            throw new TelecomException(ERR_INV_DEALERS, HttpStatus.BAD_REQUEST, DEALER_INFO_ERROR, DEALER_INFO_ERROR_DESCRIPTION);

        res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
        if (!CollectionUtils.isEmpty(output.getDealerProfiles())){
            res.setDealerProfile(output.getDealerProfiles().stream()
                    .map(i -> {
                        GetDealerProfileRes.DealerProfile profile = new GetDealerProfileRes.DealerProfile();
                        profile.setDealerId(i.getDealerId());
                        profile.setDealerName(i.getDealerName());
                        profile.setDealerNum(i.getDealerNum());
                        profile.setClientId(i.getClientId());
                        return profile;
                    })
                    .collect(Collectors.toList()));
        }
        return res;
    }
}
