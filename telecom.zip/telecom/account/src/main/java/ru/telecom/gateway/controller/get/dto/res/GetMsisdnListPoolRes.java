package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.math.BigDecimal;
import java.util.List;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

@Schema(description = "структура ответа",
        example = "{\n" +
        "    \"result\": {\n" +
        "        \"code\": \"OK\",\n" +
        "        \"messageUser\": \"Выполнено успешно\"\n" +
        "    },\n" +
        "    \"msisdnPoolList\": [\n" +
        "        {\n" +
        "            \"msisdn\": \"9957149082\",\n" +
        "            \"msisdnId\": 3052524,\n" +
        "            \"msisdnTypeId\": 104,\n" +
        "            \"msisdnTypeName\": \"Обычные СПБ\",\n" +
        "            \"msisdnClassId\": 2,\n" +
        "            \"msisdnClassName\": \"Федеральный\"\n" +
        "        }\n" +
        "    ]\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetMsisdnListPoolRes extends BaseRes {

    @ArraySchema(maxItems = 10000)
    private List<MsisdnPool> msisdnPoolList;

    @Schema(description = "структура объекта",
            example = "{\n" +
            "            \"msisdn\": \"9957149082\",\n" +
            "            \"msisdnId\": 3052524,\n" +
            "            \"msisdnTypeId\": 104,\n" +
            "            \"msisdnTypeName\": \"Обычные СПБ\",\n" +
            "            \"msisdnClassId\": 2,\n" +
            "            \"msisdnClassName\": \"Федеральный\"\n" +
            "        }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class MsisdnPool {
        @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
        private String msisdn;
        @Schema(minimum = "0", maximum = "100000000000", example = "3052524", description = "Id Телефонного номера")
        private BigDecimal msisdnId;
        @Schema(minimum = "0", maximum = "104", example = "4", allowableValues = {"1", "2", "3", "4", "104"}, defaultValue = "1", description = "Id Типа телефонного номера")
        private BigDecimal msisdnTypeId;
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Обычные СПБ", description = "Наименование типа телефонного номера")
        private String msisdnTypeName;
        @Schema(minimum = "0", maximum = "4", example = "4", allowableValues = {"1", "2", "3", "4"}, description = "Id Категории телефонного номера")
        private BigDecimal msisdnClassId;
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Федеральный", description = "Наименование категории телефонного номера")
        private String msisdnClassName;
    }
}
