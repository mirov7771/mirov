package ru.telecom.gateway.service.get;

import ru.telecom.gateway.controller.get.dto.req.*;
import ru.telecom.gateway.controller.get.dto.res.*;
import ru.telecom.gateway.service.Service;

public interface GetService extends Service {
    GetMsisdnListPoolRes getMsisdnListPool(GetMsisdnListPoolReq req);
    GetUserProfileRes getUserProfile(GetUserProfileReq req);
    GetUSIProfileRes getUSIProfile(GetUSIProfileReq req);
    GetSubscriberICCHistoryRes getSubscriberICCHistory(GetSubscriberICCHistoryReq req);
    GetClntSubsRes getClntSubs(GetClntSubsReq req);
    GetDealerProfileRes getDealerProfile(GetDealerProfileReq req);
}
