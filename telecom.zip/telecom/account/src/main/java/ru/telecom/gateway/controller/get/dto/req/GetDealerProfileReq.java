package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура запроса",
        example = "{\n" +
                "    \"branchId\": 1,\n" +
                "    \"dealerId\": 1\n" +
                "}")
@Data
public class GetDealerProfileReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Дилера")
    private BigDecimal dealerId;
}
