package ru.telecom.gateway.controller.get;

import static ru.telecom.gateway.constant.Constants.APPLICATION_JSON_VALUE;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;
import static ru.telecom.gateway.constant.Constants.SUB_MOCK;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.base.support.SberApiError;
import ru.telecom.gateway.controller.get.dto.req.*;
import ru.telecom.gateway.controller.get.dto.res.*;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.service.mock.MockService;

import javax.validation.Valid;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Tag(name = "Get Methods")
public class GetController {

    private final GetService service;
    private final MockService mockService;

    @Operation(summary = "Метод для получения списка номеров", description = "Операция предназначена для получения списка номеров, доступных для продажи. Операция также осуществляет поиск доступных для продажи номеров по маске.", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetMsisdnListPoolRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Выполнено успешно\"\n" +
                                    "    },\n" +
                                    "    \"msisdnPoolList\": [\n" +
                                    "        {\n" +
                                    "            \"msisdn\": \"9957149082\",\n" +
                                    "            \"msisdnId\": 3052524,\n" +
                                    "            \"msisdnTypeId\": 104,\n" +
                                    "            \"msisdnTypeName\": \"Обычные СПБ\",\n" +
                                    "            \"msisdnClassId\": 2,\n" +
                                    "            \"msisdnClassName\": \"Федеральный\"\n" +
                                    "        }\n" +
                                    "    ]\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetMsisdnListPoolReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branchId\": 1,\n" +
                                    "    \"msisdnClassId\": 1,\n" +
                                    "    \"msisdnTypeId\": 2,\n" +
                                    "    \"countRecord\": 10\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getMsisdnListPool", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetMsisdnListPoolRes> getMsisdnListPool(@Valid @RequestBody GetMsisdnListPoolReq req) {
        return ResponseBuilder.build(service.getMsisdnListPool(req));
    }

    @Operation(summary = "Метод получения профиля пользователя биллинговой системы", description = "Получение профиля пользователя биллинговой системы", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetUserProfileRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Выполнено успешно\"\n" +
                                    "    },\n" +
                                    "    \"userProfile\": {\n" +
                                    "        \"userId\": 231,\n" +
                                    "        \"userLogin\": \"IFT\",\n" +
                                    "        \"branchId\": 965,\n" +
                                    "        \"userStatusId\": 1,\n" +
                                    "        \"fullName\": \"Единая Фронтальная Система ИФТ\",\n" +
                                    "        \"dealerId\": 108,\n" +
                                    "        \"departmentId\": 7\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetUserProfileReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branchId\": 1,\n" +
                                    "    \"userId\": 1,\n" +
                                    "    \"userLogin\": \"test\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getUserProfile", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetUserProfileRes> getUserProfile(@Valid @RequestBody GetUserProfileReq req) {
        return ResponseBuilder.build(service.getUserProfile(req));
    }

    @Operation(summary = "Метод получения профиля SIM-карты", description = "Получение профиля SIM-карты", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetUSIProfileRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Выполнено успешно\"\n" +
                                    "    },\n" +
                                    "    \"usiProfile\": {\n" +
                                    "        \"branchId\": 231,\n" +
                                    "        \"dealerId\": \"IFT\",\n" +
                                    "        \"partyId\": 965,\n" +
                                    "        \"partyTypeId\": 1,\n" +
                                    "        \"partyStatusId\": 1,\n" +
                                    "        \"icc\": \"89701501078001248910\",\n" +
                                    "        \"usiId\": 7,\n" +
                                    "        \"usi\": \"test\",\n" +
                                    "        \"usiStatusId\": 7,\n" +
                                    "        \"switchId\": 7,\n" +
                                    "        \"switchName\": \"тестовый свитчер\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetUSIProfileReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branchId\": 1,\n" +
                                    "    \"icc\": \"89701501078001248910\",\n" +
                                    "    \"iccMask\": \"1234\",\n" +
                                    "    \"msisdn\": \"9654728990\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getUSIProfile", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetUSIProfileRes> getUSIProfile(@Valid @RequestBody GetUSIProfileReq req) {
        return ResponseBuilder.build(service.getUSIProfile(req));
    }

    @Operation(summary = "Метод получения истории изменения ICC абонента", description = "Операция получения истории изменения ICC абонента", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetSubscriberICCHistoryRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Выполнено успешно\"\n" +
                                    "    },\n" +
                                    "    \"ICCHistory\": [{\n" +
                                    "        \"subscriberId\": 172559,\n" +
                                    "        \"createUserId\": 965,\n" +
                                    "        \"statCardId\": 1,\n" +
                                    "        \"icc\": \"89701501078001248910\",\n" +
                                    "        \"createUserName\": \"MSDCRM\",\n" +
                                    "        \"statCardName\": \"Активирована\"\n" +
                                    "    }]\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetSubscriberICCHistoryReq.class),
                            examples = @ExampleObject(value = "{\n"
                                    + "     \"branchId\": 2,\n"
                                    + "     \"subscriberId\": 1,\n"
                                    + "     \"msisdn\": \"9585940115\"\n"
                                    + "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getSubscriberICCHistory", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetSubscriberICCHistoryRes> getSubscriberICCHistory(@RequestHeader(SUBSYSTEM_CODE) String subsystemCode,
                                                                              @Valid @RequestBody GetSubscriberICCHistoryReq req) {
        if (SUB_MOCK.equalsIgnoreCase(subsystemCode))
            return ResponseBuilder.build(mockService.getSubscriberICCHistory());
        else
            return ResponseBuilder.build(service.getSubscriberICCHistory(req));
    }

    @Operation(summary = "Метод получения профиля абонента", description = "Операция предназначена для получения профиля абонента", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetClntSubsRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"result\": {\n" +
                                    "    \"code\": \"OK\",\n" +
                                    "    \"messageUser\": \"Выполнено успешно\"\n" +
                                    "  },\n" +
                                    "  \"client\": {\n" +
                                    "    \"clientBaseParameter\": {\n" +
                                    "      \"branchId\": 0,\n" +
                                    "      \"clientId\": 0,\n" +
                                    "      \"clientTypeId\": 0,\n" +
                                    "      \"clientTypeName\": \"string\",\n" +
                                    "      \"clientJurTypeId\": 0,\n" +
                                    "      \"dealerId\": 0,\n" +
                                    "      \"clientStatusID\": 0,\n" +
                                    "      \"clientStatusName\": \"string\",\n" +
                                    "      \"singleBillingFlag\": \"string\",\n" +
                                    "      \"paymentTypeId\": 0,\n" +
                                    "      \"paymentTypeName\": \"string\"\n" +
                                    "    },\n" +
                                    "    \"contractDatas\": [\n" +
                                    "      {\n" +
                                    "        \"accountNumber\": 0,\n" +
                                    "        \"contractNumber\": 0,\n" +
                                    "        \"signatureContractDateTime\": \"2022-01-09T15:04:44.362Z\",\n" +
                                    "        \"email\": \"string\",\n" +
                                    "        \"resident\": 0\n" +
                                    "      }\n" +
                                    "    ],\n" +
                                    "    \"deliveryData\": {\n" +
                                    "      \"deliveryTypeId\": 0,\n" +
                                    "      \"deliveryTypeName\": \"string\",\n" +
                                    "      \"post\": \"string\",\n" +
                                    "      \"city\": \"string\",\n" +
                                    "      \"street\": \"string\",\n" +
                                    "      \"house\": \"string\"\n" +
                                    "    },\n" +
                                    "    \"personalProfile\": {\n" +
                                    "      \"fullName\": \"string\",\n" +
                                    "      \"genderId\": 0,\n" +
                                    "      \"dateOfBirth\": \"2022-01-09T15:04:44.362Z\",\n" +
                                    "      \"identityDocuments\": [\n" +
                                    "        {\n" +
                                    "          \"documentIdentity\": \"string\",\n" +
                                    "          \"country\": \"string\",\n" +
                                    "          \"documentSeries\": \"string\",\n" +
                                    "          \"documentNumber\": \"string\",\n" +
                                    "          \"documentDateOfIssue\": \"2022-01-09T15:04:44.362Z\",\n" +
                                    "          \"documentAuthority\": \"string\"\n" +
                                    "        }\n" +
                                    "      ],\n" +
                                    "      \"registrationAddress\": {\n" +
                                    "        \"country\": \"string\",\n" +
                                    "        \"post\": \"string\",\n" +
                                    "        \"region\": \"string\",\n" +
                                    "        \"subRegion\": \"string\",\n" +
                                    "        \"city\": \"string\",\n" +
                                    "        \"street\": \"string\",\n" +
                                    "        \"building\": \"string\",\n" +
                                    "        \"house\": \"string\"\n" +
                                    "      }\n" +
                                    "    },\n" +
                                    "    \"clientOptParameter\": {\n" +
                                    "      \"documentReference\": \"string\",\n" +
                                    "      \"mobileBankType\": 0,\n" +
                                    "      \"placeOfBirth\": \"string\",\n" +
                                    "      \"sellerPointId\": 0,\n" +
                                    "      \"sellerManager\": \"string\",\n" +
                                    "      \"documentDivisionCode\": \"string\",\n" +
                                    "      \"documentDateTo\": \"2022-01-09T15:04:44.362Z\",\n" +
                                    "      \"endContractDateTime\": \"2022-01-09T15:04:44.362Z\"\n" +
                                    "    },\n" +
                                    "    \"clientBalanceParameters\": [\n" +
                                    "      {\n" +
                                    "        \"balanceDigts\": [\n" +
                                    "          {\n" +
                                    "            \"balanceTypeId\": 0,\n" +
                                    "            \"balanceName\": \"string\",\n" +
                                    "            \"balanceId\": 0\n" +
                                    "          }\n" +
                                    "        ],\n" +
                                    "        \"balanceParameters\": [\n" +
                                    "          {\n" +
                                    "            \"clientBalanceId\": 0,\n" +
                                    "            \"balanceValue\": 0,\n" +
                                    "            \"balanceId\": 0\n" +
                                    "          }\n" +
                                    "        ]\n" +
                                    "      }\n" +
                                    "    ]\n" +
                                    "  },\n" +
                                    "  \"subsribers\": [\n" +
                                    "    {\n" +
                                    "      \"subsBaseParameter\": {\n" +
                                    "        \"msisdn\": \"string\",\n" +
                                    "        \"subscriberId\": 0,\n" +
                                    "        \"icc\": \"string\",\n" +
                                    "        \"subsTypeID\": 0,\n" +
                                    "        \"subsTypeName\": \"string\",\n" +
                                    "        \"ratePlanId\": 0,\n" +
                                    "        \"ratePlanName\": \"string\",\n" +
                                    "        \"password\": \"string\",\n" +
                                    "        \"subsStatusID\": 0,\n" +
                                    "        \"subsStatusName\": \"string\",\n" +
                                    "        \"activationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                                    "        \"registrationDate\": \"2022-01-09T15:04:44.362Z\",\n" +
                                    "        \"dealerName\": \"string\",\n" +
                                    "        \"reliabilityType\": \"string\"\n" +
                                    "      },\n" +
                                    "      \"subsOptParameter\": {\n" +
                                    "        \"intDivisionCode\": \"string\",\n" +
                                    "        \"intDivisionRegion\": \"string\",\n" +
                                    "        \"employeID\": 0,\n" +
                                    "        \"sellerCode\": \"string\",\n" +
                                    "        \"sellerId\": 0\n" +
                                    "      }\n" +
                                    "    }\n" +
                                    "  ]\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetClntSubsReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"branchId\": 2,\n" +
                                    "  \"outContractNameClntSubs\": \"ClientSubs\",\n" +
                                    "  \"msisdn\": \"9300039711\",\n" +
                                    "  \"clientId\": 181816,\n" +
                                    "  \"accountNumber\": 119205,\n" +
                                    "  \"contractNumber\": 1000084001,\n" +
                                    "  \"documentIdentityId\": 24,\n" +
                                    "  \"documentSeries\": \"1205\",\n" +
                                    "  \"documentNumber\": \"983265\",\n" +
                                    "  \"fullName\": \"Единая Фронтальная Система ИФТ\",\n" +
                                    "  \"invNum\": \"40817810\",\n" +
                                    "  \"balanceFlag\": 1 \n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getClntSubs", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetClntSubsRes> getClntSubs(@Valid @RequestBody GetClntSubsReq req) {
        return ResponseBuilder.build(service.getClntSubs(req));
    }

    @Operation(summary = "Метод получения профиля Дилера", description = "Получение профиля Дилера", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetDealerProfileRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "\"result\": {\n" +
                                    "    \"code\": \"OK\",\n" +
                                    "    \"messageUser\": \"Выполнено успешно\"\n" +
                                    "},\n" +
                                    "\"dealerProfile\": [{\n" +
                                    "        \"dealerId\": 1234,\n" +
                                    "        \"dealerNum\": \"23\",\n" +
                                    "        \"dealerName\": \"МГТС\",\n" +
                                    "        \"clientId\": 111\n" +
                                    "}]\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetDealerProfileReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branchId\": 1,\n" +
                                    "    \"dealerId\": 1\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getDealerProfile", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetDealerProfileRes> getDealerProfile(@Valid @RequestBody GetDealerProfileReq req) {
        return ResponseBuilder.build(service.getDealerProfile(req));
    }

}
