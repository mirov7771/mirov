package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура запроса",
        example = "{\n" +
                "    \"branchId\": 1,\n" +
                "    \"msisdnClassId\": 1,\n" +
                "    \"msisdnTypeId\": 2,\n" +
                "    \"msisdnMask\": \"1234\",\n" +
                "    \"countRecord\": 10\n" +
                "}")
@Data
public class GetMsisdnListPoolReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "4", example = "4", allowableValues = {"1", "2", "3", "4"}, description = "Id Категории телефонного номера")
    private BigDecimal msisdnClassId;
    @Schema(minimum = "0", maximum = "104", example = "4", allowableValues = {"1", "2", "3", "4", "104"}, defaultValue = "1", description = "Id Типа телефонного номера")
    private BigDecimal msisdnTypeId = new BigDecimal(1);
    @Schema(maxLength = 4, example = "1234", pattern = "^(.*){4}$", description = "Маска из 4-х цифр. Если маска не задана, то возвращаются N случайных")
    private String msisdnMask;
    @Schema(minimum = "0", maximum = "1000", example = "1", defaultValue = "1", description = "Количество номеров в запрашиваемом списке")
    private Long countRecord = 1L;
}
