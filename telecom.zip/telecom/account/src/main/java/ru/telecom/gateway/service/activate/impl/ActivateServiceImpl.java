package ru.telecom.gateway.service.activate.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.controller.activate.dto.req.ActivateSubscriberReq;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.http.dto.ActivateSubscriberRes;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.activate.ActivateService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.account.ActivateSubscriberRequest;
import ru.telecom.gateway.xml.account.ActivateSubscriberResponse;
import ru.telecom.gateway.xml.account.FilterSubscriber;

import java.util.HashSet;
import java.util.Set;

import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Params.STUB_AS;

@Component
@RequiredArgsConstructor
@Slf4j
public class ActivateServiceImpl implements ActivateService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;
    private final RestAPIGate restAPIGate;

    @Value("${application.telecom.activate.enabled:false}")
    private Boolean isRest;

    private static final Set<String> MOCK_MSISDN = new HashSet<>();
    static {
        MOCK_MSISDN.add("9640000000");
        MOCK_MSISDN.add("9640000001");
        MOCK_MSISDN.add("9640000002");
        MOCK_MSISDN.add("9640000003");
        MOCK_MSISDN.add("9640000004");
        MOCK_MSISDN.add("9640000005");
        MOCK_MSISDN.add("9640000006");
        MOCK_MSISDN.add("9640000007");
        MOCK_MSISDN.add("9640000008");
        MOCK_MSISDN.add("9640000009");
    }

    @Override
    public BaseRes activateSubscriber(ActivateSubscriberReq req) {
        BaseRes res = new BaseRes();
        requestValidator.validate(STUB_AS, ERR_INV_INFO_SUBSCRIBER, ERROR_ABONENT, USI_MESSAGE_SYSTEM);
        if (Boolean.TRUE.equals(isRest) && StringUtils.hasText(req.getMsisdn())) {
            ActivateSubscriberRes activateSubscriberRes = restAPIGate.activateSubscriber(req.getMsisdn());
            if (activateSubscriberRes == null
                    || activateSubscriberRes.getResult() == null
                    || !StringUtils.hasText(activateSubscriberRes.getResult().getErrorCode())) {
                throw new TelecomException(ERR_INV_INFO_SUBSCRIBER, HttpStatus.BAD_REQUEST, ERROR_ABONENT, null, USI_MESSAGE_SYSTEM);
            } else {
                res.setResult(new ResultDto(activateSubscriberRes.getResult().getErrorCode(), activateSubscriberRes.getResult().getErrorText()));
            }
        } else {
            ActivateSubscriberRequest soapReq = new ActivateSubscriberRequest();
            soapReq.setBranchId(req.getBranchId());
            FilterSubscriber filterSubscriber = new FilterSubscriber();
            if (StringUtils.hasText(req.getMsisdn())) {
                if (MOCK_MSISDN.contains(req.getMsisdn())) {
                    res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
                    return res;
                }
                filterSubscriber.setMsisdn(req.getMsisdn());
            }
            if (req.getSubscriberId() != null) {
                filterSubscriber.setSubscriberId(req.getSubscriberId());
            }
            soapReq.setFilterSubscriber(filterSubscriber);
            ActivateSubscriberResponse soapRes = soapAPIGate.activateSubscriber(
                    soapReq);
            if (soapRes != null && soapRes.getResult() != null)
                res.setResult(new ResultDto(soapRes.getResult().getCode(), soapRes.getResult().getMessageUser()));
            else
                throw new TelecomException(ERR_INV_INFO_SUBSCRIBER, HttpStatus.BAD_REQUEST, ERROR_ABONENT, null, USI_MESSAGE_SYSTEM);
        }
        return res;
    }
}
