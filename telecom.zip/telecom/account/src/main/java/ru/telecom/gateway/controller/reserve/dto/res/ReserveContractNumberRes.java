package ru.telecom.gateway.controller.reserve.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class ReserveContractNumberRes extends BaseRes {
    private BigDecimal contractNumber;
}
