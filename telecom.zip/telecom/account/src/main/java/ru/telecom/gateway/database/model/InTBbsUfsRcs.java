package ru.telecom.gateway.database.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "in_t_bbs_ufs_rcs")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class InTBbsUfsRcs implements Serializable {

    private static final long serialVersionUID = 4241728575308850663L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "in_q_bbs_ufs_rcs")
    @SequenceGenerator(name = "in_q_bbs_ufs_rcs", sequenceName = "in_q_bbs_ufs_rcs", allocationSize = 10)
    private Long id;
    @Column(name = "LOG_ID")
    private Long logId;
    @Column(name = "BRANCH_ID")
    private Long branchId;
    @Column(name = "CLIENT_TYPE_ID")
    private Long clientTypeId;
    @Column(name = "CLIENT_JUR_TYPE_ID")
    private Long clientJurTypeId;
    @Column(name = "DEALER_ID")
    private Long dealerId;
    @Column(name = "MSISDN")
    private String msisdn;
    @Column(name = "RATE_PLAN_ID")
    private Long ratePlanId;
    @Column(name = "ICC")
    private String icc;
    @Column(name = "SUBS_PASSWORD")
    private String subsPassword;
    @Column(name = "ACTIVATE_SUBSCRIBER")
    private String activateSubscriber;
    @Column(name = "ACCOUNT_NUMBER")
    private Long accountNumber;
    @Column(name = "CONTRACT_NUMBER")
    private Long contractNumber;
    @Column(name = "SIGNATURE_DATETIME")
    private Date signatureDateTime;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "FULL_NAME")
    private String fullName;
    @Column(name = "DATE_OF_BIRTH")
    private Date dateOfBirth;
    @Column(name = "GENDER_ID")
    private Integer genderId;
    @Column(name = "DOCUMENT_IDENTITY_ID")
    private Long documentIdentityId;
    @Column(name = "DOCUMENT_SERIES")
    private String documentSeries;
    @Column(name = "DOCUMENT_NUMBER")
    private String documentNumber;
    @Column(name = "DOCUMENT_AUTHORITY")
    private String documentAuthority;
    @Column(name = "DOCUMENT_DATE_OF_ISSUE")
    private Date documentDateOfIssue;
    @Column(name = "DOCUMENT_COUNTRY")
    private String documentCountry;
    @Column(name = "COUNTRY")
    private String country;
    @Column(name = "CITY")
    private String city;
    @Column(name = "STREET")
    private String street;
    @Column(name = "HOUSE")
    private String house;
    @Column(name = "POST")
    private String post;
    @Column(name = "REGION")
    private String region;
    @Column(name = "SUB_REGION")
    private String subRegion;
    @Column(name = "APARTMENT")
    private String apartment;
    @Column(name = "NOTES")
    private String notes;
    @Column(name = "DELIVERY_TYPE_ID")
    private Long deliveryTypeId;
    @Column(name = "CITY_D")
    private String cityD;
    @Column(name = "STREET_D")
    private String streetD;
    @Column(name = "HOUSE_D")
    private String houseD;
    @Column(name = "POST_D")
    private String postD;
    @Column(name = "REGION_D")
    private String regionD;
    @Column(name = "SUB_REGION_D")
    private String subRegionD;
    @Column(name = "APARTMENT_D")
    private String apartmentD;
    @Column(name = "NOTES_D")
    private String notesD;
    @Column(name = "OPT_PARAMETERS_CLIENT")
    private String optParametersClient;
    @Column(name = "OPT_PARAMETERS_SUBS")
    private String optParametersSubs;
    @Column(name = "CLIENT_ID")
    private Long clientId;
    @Column(name = "SUBSCRIBER_ID")
    private Long subscriberId;
    @Column(name = "EMPLOYE_ID")
    private String employeId;
    @Column(name = "SELLER_MANAGER")
    private String sellerManager;
    @Column(name = "CONTRACT_DATE_TO")
    private Date contractDateTo;
    @Column(name = "CHANGE_RATE")
    private String changeRate;
    @Column(name = "CHANGE_RATE_DATE")
    private Date changeRateDate;
    @Column(name = "ERROR_STATUS")
    private String errorStatus;
    @Column(name = "ERROR_TEXT")
    private String errorText;
    @Column(name = "SELLER_ID")
    private String sellerId;
    @Column(name = "INT_DIVISION_CODE")
    private String intDivisionCode;
    @Column(name = "SEND_DOC")
    private String sendDoc;
    @Column(name = "NUMBER_TO_CHANGE")
    private String numberToChange;
    @Column(name = "CHANGE_NUMBER_DATE")
    private Date changeNumberDate;
    @Column(name = "CLIENT_IDENTIFIED")
    private String clientIdentified;
}
