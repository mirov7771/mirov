package ru.telecom.gateway.database.procedure;

import lombok.extern.slf4j.Slf4j;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.util.ObjectUtils;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class ProcedureCaller {

    @PersistenceContext
    private EntityManager entityManager;

    public Map<String, String> addPay(String channel,
                                      String msisdn,
                                      String promoCode,
                                      Integer paymentSum,
                                      Integer paymentDeadDay) {
        Map<String, String> retMap = new HashMap<>();
        StoredProcedureQuery query = entityManager
                .createStoredProcedureQuery("pm_p_payment.add_pay")
                .registerStoredProcedureParameter(1, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(2, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(3, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(4, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(5, Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter(6, Integer.class, ParameterMode.IN)
                .registerStoredProcedureParameter(7, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(8, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(9, Integer.class, ParameterMode.OUT)
                .registerStoredProcedureParameter(10, Integer.class, ParameterMode.OUT)
                .registerStoredProcedureParameter(11, String.class, ParameterMode.OUT)
                .setParameter(1, channel)
                .setParameter(2, "DROPPER")
                .setParameter(3, msisdn)
                .setParameter(4, promoCode)
                .setParameter(5, paymentSum)
                .setParameter(6, paymentDeadDay)
                .setParameter(7, "")
                .setParameter(8, "");

        try {

            query.execute();

            Integer paymentDocId = (Integer) query.getOutputParameterValue(9);
            Integer errCode = (Integer) query.getOutputParameterValue(10);
            String errText = (String) query.getOutputParameterValue(11);
            if (errCode != null)
                retMap.put("o_err_code", String.valueOf(errCode));
            if (paymentDocId != null)
                retMap.put("paymentDocId", String.valueOf(paymentDocId));
            if (StringUtils.hasText(errText))
                retMap.put("o_err_text", errText);
        } catch (Exception e) {
            log.error("Error calling procedure pm_p_payment.add_pay: ", e);
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
        return retMap;
    }

    public Map<String, String> checkSubsServExists(String iServId, BigDecimal iDocId, String iDocSeries, String iDocNumber){
        Map<String, String> retMap = new HashMap<>();
        StoredProcedureQuery query = entityManager
                .createStoredProcedureQuery("IN_P_CUSTOMER.CHECK_SUBS_SERV_EXISTS")
                .registerStoredProcedureParameter(1, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(2, BigDecimal.class, ParameterMode.IN)
                .registerStoredProcedureParameter(3, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(4, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(5, String.class, ParameterMode.OUT)
                .registerStoredProcedureParameter(6, String.class, ParameterMode.OUT)
                .setParameter(1, iServId)
                .setParameter(2, iDocId)
                .setParameter(3, iDocSeries)
                .setParameter(4, iDocNumber);

        try {
            query.execute();

            String errCode = (String) query.getOutputParameterValue(5);
            String errText = (String) query.getOutputParameterValue(6);
            if (StringUtils.hasText(errCode))
                retMap.put("o_err_code", errCode);
            if (StringUtils.hasText(errText))
                retMap.put("o_err_text", errText);
        } catch (Exception e) {
            log.error("Error calling procedure IN_P_CUSTOMER.CHECK_SUBS_SERV_EXISTS: ", e);
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
        return retMap;
    }

    public Map<String, Object> getActiveServiceName(BigDecimal iSubscriberId){
        Map<String, Object> retMap = new HashMap<>();
        StoredProcedureQuery query = entityManager
                .createStoredProcedureQuery("TF_P_TARIFF_PLAN.GET_ACTIVE_SERVICE_NAME")
                .registerStoredProcedureParameter(1, BigDecimal.class, ParameterMode.IN)
                .registerStoredProcedureParameter(2, Long.class, ParameterMode.OUT)
                .registerStoredProcedureParameter(3, String.class, ParameterMode.OUT)
                .setParameter(1, iSubscriberId);

        try {
            query.execute();

            Long serviceId = (Long) query.getOutputParameterValue(2);
            String serviceName = (String) query.getOutputParameterValue(3);
            if (serviceId != null)
                retMap.put("o_service_id", serviceId);
            if (StringUtils.hasText(serviceName))
                retMap.put("o_service_name", serviceName);
        } catch (Exception e) {
            log.error("Error calling procedure TF_P_TARIFF_PLAN.GET_ACTIVE_SERVICE_NAME: ", e);
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
        return retMap;
    }

    public BigDecimal getSubsId(String msisdn){
        return ObjectUtils.getBigDecimal(entityManager
                .createNativeQuery("SELECT IN_P_CUSTOMER.GET_SUBS_ID(:MSISDN, null) FROM DUAL")
                .setParameter("MSISDN", msisdn)
                .getSingleResult());
    }

}
