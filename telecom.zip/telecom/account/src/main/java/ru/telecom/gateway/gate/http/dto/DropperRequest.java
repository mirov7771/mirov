package ru.telecom.gateway.gate.http.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class DropperRequest {
    @JsonProperty("name")
    private String name;
    @JsonProperty("parameters")
    private List<Parameter> parameters;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Parameter {
        @JsonProperty("channel")
        private String channel;
        @JsonProperty("paymentType")
        private String paymentType;
        @JsonProperty("msisdn")
        private String msisdn;
        @JsonProperty("promocode")
        private String promocode;
        @JsonProperty("paymentSum")
        private Integer paymentSum;
        @JsonProperty("paymentDeadDay")
        private Integer paymentDeadDay;
        @JsonProperty("comment")
        private String comment;
    }
    @JsonIgnore
    public void fillParameters(String channel,
                               String msisdn,
                               String promoCode,
                               Integer paymentSum,
                               Integer paymentDeadDay) {
        this.parameters = new ArrayList<>();
        Parameter prm1 = new Parameter();
        prm1.setChannel(channel);
        this.parameters.add(prm1);
        Parameter prm2 = new Parameter();
        prm2.setPromocode(promoCode);
        this.parameters.add(prm2);
        Parameter prm3 = new Parameter();
        prm3.setPaymentSum(paymentSum);
        this.parameters.add(prm3);
        Parameter prm4 = new Parameter();
        prm4.setPaymentDeadDay(paymentDeadDay);
        this.parameters.add(prm4);
        Parameter prm5 = new Parameter();
        prm5.setPaymentType("BONUS");
        this.parameters.add(prm5);
        Parameter prm6 = new Parameter();
        prm6.setMsisdn(msisdn);
        this.parameters.add(prm6);
    }
}
