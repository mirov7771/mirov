package ru.telecom.gateway.controller.reserve.dto.req;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Schema(description = "структура запроса",
        example = "{\n" +
                "  \"branchId\": 2\n" +
                "}")
@Data
public class ReserveContractNumberReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
}
