package ru.telecom.gateway.service.set;

import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.set.dto.req.SetSubsOptParametersReq;
import ru.telecom.gateway.service.Service;

public interface SetService extends Service {
    BaseRes setSubsOptParameters(SetSubsOptParametersReq req);
}
