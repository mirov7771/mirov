package ru.telecom.gateway.service.replace;

import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.replace.dto.req.ReplaceSIMReq;
import ru.telecom.gateway.controller.replace.dto.res.ReplaceSIMRes;
import ru.telecom.gateway.service.Service;

public interface ReplaceService extends Service {
    BaseRes replaceSIM(ReplaceSIMReq req);
}
