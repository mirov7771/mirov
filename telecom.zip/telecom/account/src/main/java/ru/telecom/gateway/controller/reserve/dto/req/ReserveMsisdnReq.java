package ru.telecom.gateway.controller.reserve.dto.req;

import java.math.BigDecimal;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Schema(description = "структура запроса",
        example = "{\n" +
                "  \"branchId\": 2,\n" +
                "  \"dealerId\": 2,\n" +
                "  \"msisdn\": \"9645173535\"\n" +
                "}")
@Data
public class ReserveMsisdnReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Дилера")
    private BigDecimal dealerId;
    @NotNull
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
}
