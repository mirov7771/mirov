package ru.telecom.gateway.controller.register.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import javax.validation.constraints.Size;
import java.math.BigDecimal;

@Schema(description = "структура ответа",
        example = "{\n" +
        "    \"result\": {\n" +
        "        \"code\": \"OK\",\n" +
        "        \"messageUser\": \"Выполнено успешно\"\n" +
        "    },\n" +
        "    \"infoRegister\": {\n" +
        "        \"clientId\": 181816,\n" +
        "        \"subscriberId\": 182010,\n" +
        "        \"contractNumber\": 1000525068,\n" +
        "        \"accountNumber\": 707052,\n" +
        "        \"msisdn\": \"9770024015\"\n" +
        "    }\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class RegisterClientRes extends BaseRes {

    private InfoRegister infoRegister;

    @Schema(description = "структура объекта",
            example = "{\n" +
            "    \"clientId\": 181816,\n" +
            "    \"subscriberId\": 182010,\n" +
            "    \"contractNumber\": 1000525068,\n" +
            "    \"accountNumber\": 707052,\n" +
            "    \"msisdn\": \"9770024015\"\n" +
            "}")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class InfoRegister {
        @Schema(minimum = "0", maximum = "100000000000", example = "181816", description = "идентификатор созданного клиента")
        private BigDecimal clientId;
        @Schema(minimum = "0", maximum = "100000000000", example = "182010", description = "идентификатор созданного абонента")
        private BigDecimal subscriberId;
        @Schema(minimum = "0", maximum = "100000000000", example = "119205", description = "Номер лицевого счета")
        private BigDecimal accountNumber;
        @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Номер контракта")
        private BigDecimal contractNumber;
        @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
        private String msisdn;
    }

    @JsonIgnore
    public void stubInfo(){
        this.infoRegister = new InfoRegister();
        this.infoRegister.setClientId(new BigDecimal("66699"));
        this.infoRegister.setSubscriberId(new BigDecimal("66699"));
        this.infoRegister.setContractNumber(new BigDecimal("1000666999"));
        this.infoRegister.setAccountNumber(new BigDecimal("666999"));
    }
}
