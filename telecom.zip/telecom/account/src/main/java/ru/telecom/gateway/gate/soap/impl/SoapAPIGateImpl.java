package ru.telecom.gateway.gate.soap.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.xml.account.*;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.telecom.service}")
    private String serviceUrl;

    @Override
    public GetMsisdnListPoolResponse getMsisdnListPool(GetMsisdnListPoolRequest req) {
        return (GetMsisdnListPoolResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ReserveMsisdnResponse reserveMsisdn(ReserveMsisdnRequest req) {
        return (ReserveMsisdnResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ReserveMsisdnReturnResponse reserveMsisdnReturn(ReserveMsisdnReturnRequest req) {
        return (ReserveMsisdnReturnResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetUserProfileResponse getUserProfile(GetUserProfileRequest req) {
        return (GetUserProfileResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetUSIProfileResponse getUSIProfile(GetUSIProfileRequest req) {
        return (GetUSIProfileResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ReserveAccountNumberResponse reserveAccountNumber(ReserveAccountNumberRequest req) {
        return (ReserveAccountNumberResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public RegisterClientResponse registerClient(RegisterClientRequest req) {
        return (RegisterClientResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ReserveContractNumberResponse reserveContractNumber(ReserveContractNumberRequest req) {
        return (ReserveContractNumberResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ActivateSubscriberResponse activateSubscriber(ActivateSubscriberRequest req) {
        return (ActivateSubscriberResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ReplaceSIMResponse replaceSIM(ReplaceSIMRequest req) {
        return (ReplaceSIMResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetSubscriberICCHistoryResponse getSubscriberICCHistory(GetSubscriberICCHistoryRequest req) {
        return (GetSubscriberICCHistoryResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public SetSubsOptParametersResponse setSubsOptParameters(SetSubsOptParametersRequest req) {
        return (SetSubsOptParametersResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetClntSubsResponse getClntSubs(GetClntSubsRequest req) {
        return (GetClntSubsResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetDealerProfileResponse getDealerProfile(GetDealerProfileRequest req) {
        return (GetDealerProfileResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }
}
