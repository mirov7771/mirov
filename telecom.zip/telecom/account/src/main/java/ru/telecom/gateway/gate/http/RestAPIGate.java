package ru.telecom.gateway.gate.http;

import ru.telecom.gateway.gate.http.dto.ActivateSubscriberRes;
import ru.telecom.gateway.gate.http.dto.DropperCheckResponse;
import ru.telecom.gateway.gate.http.dto.DropperResponse;
import ru.telecom.gateway.gate.http.dto.OrdersUpdateStatusResponse;

import java.util.List;

public interface RestAPIGate {
    OrdersUpdateStatusResponse ordersUpdateStatus(String orderNo, String msisdn);
    String changeSubscriberServiceStatus(String branchId, String msisdn, String servId);
    DropperResponse addPay(String channel, String msisdn, String promoCode, Integer paymentSum, Integer paymentDeadDay);
    DropperCheckResponse check(String promoCode);
    List<String> getEnabledSubscriberServices(String msisdn);
    ActivateSubscriberRes activateSubscriber(String msisdn);
}
