package ru.telecom.gateway.stub;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveMsisdnReq;
import ru.telecom.gateway.service.reserve.ReserveService;

import java.math.BigDecimal;

import static ru.telecom.gateway.constant.Constants.Params.Y;

@Component
@RequiredArgsConstructor
@Slf4j
public class ReserveMsisdnStub {

    private final ReserveService reserveService;

    public void reserveMsisdnUFS(String reserveStub, BigDecimal branchId, String msisdn){
        if (Y.equalsIgnoreCase(reserveStub)){
            try {
                ReserveMsisdnReq req = new ReserveMsisdnReq();
                req.setBranchId(branchId);
                req.setMsisdn(msisdn);
                reserveService.reserveMsisdn(req);
            } catch (Exception e){
                log.error("ReserveMsisdn error: ", e);
            }
        }
    }

}
