package ru.telecom.gateway.gate.http.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ActivateSubscriberRes {
    @JsonProperty("result")
    private Result result;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Result {
        @JsonProperty("ErrorCode")
        private String errorCode;
        @JsonProperty("ErrorText")
        private String errorText;
    }
}
