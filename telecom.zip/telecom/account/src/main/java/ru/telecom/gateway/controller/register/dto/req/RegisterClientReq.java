package ru.telecom.gateway.controller.register.dto.req;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;

import javax.validation.constraints.NotNull;

@Schema(description = "структура запроса",
        example = "{\n" +
        "   \"branchId\": 965,\n" +
        "   \"clientTypeId\": 1,\n" +
        "   \"clientJurTypeId\": 1,\n" +
        "   \"dealerId\": 108,\n" +
        "   \"msisdn\": 9585942088,\n" +
        "   \"ratePlanId\": 4,\n" +
        "   \"integratedCircuitCardIdentifier\": 89701501077100000000,\n" +
        "   \"password\": 104,\n" +
        "   \"activateSubscriber\": false,\n" +
        "   \"accountNumber\": 119205,\n" +
        "   \"contractNumber\": 1000084001,\n" +
        "   \"signatureContractDateTime\": \"2018-07-04T14:03:59\",\n" +
        "   \"email\": \"email@sberbank-tele.com\",\n" +
        "   \"fullName\": \"Выхухолев Капибара Утконосович\",\n" +
        "   \"dateOfBirth\": \"2017-11-08T13:13:13.000+03:00\",\n" +
        "   \"genderId\": 0,\n" +
        "   \"documentIdentityId\": 1,\n" +
        "   \"documentSeries\": 1205,\n" +
        "   \"documentNumber\": 983265,\n" +
        "   \"documentAuthority\": \"Советским РОВД г. Астрахани\",\n" +
        "   \"documentDateOfIssue\": \"2005-08-30T13:13:13.000+03:00\",\n" +
        "   \"documentCountry\": \"РФ\",\n" +
        "   \"country\": \"Россия\",\n" +
        "   \"city\": \"Москва\",\n" +
        "   \"street\": \"Вавилова\",\n" +
        "   \"house\": 19,\n" +
        "   \"post\": 143987,\n" +
        "   \"region\": \"Москва\",\n" +
        "   \"subRegion\": \"Населенный пункт\",\n" +
        "   \"apartment\": \"Квартира\",\n" +
        "   \"comment\": \"Комментарий к документу\",\n" +
        "   \"employeeId\": \"etatarintsev@sberbank-tele.com\",\n" +
        "   \"sellerManager\": \"Фамилия Имя Отчество\",\n" +
        "   \"intDivisionCode\": 38908301110,\n" +
        "   \"docDivisionCode\": \"302-005\",\n" +
        "   \"sellerId\": 314159265,\n" +
        "   \"termsOfServices\": \"IS_ACC_COMM_SRV:Y;IS_USE_MY_INFO:Y;IS_ADV_INFO:Y;IS_TRANS_PD:Y;IS_USE_FOUNDS:Y;\",\n" +
        "   \"servId\": 1356,\n" +
        "   \"contractDateTo\": \"01.02.2018\"\n" +
        "}")
@Data
public class RegisterClientReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "4", allowableValues = {"1", "3", "4"}, example = "1", description = "Типы клиентов")
    private BigDecimal clientTypeId;
    @Schema(minimum = "0", maximum = "4", allowableValues = {"1", "2", "3", "4"}, example = "1", description = "Юридический статус клиента")
    private BigDecimal clientJurTypeId;
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Дилера")
    private BigDecimal dealerId;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Идентификатор плана")
    private BigDecimal ratePlanId;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "89701501077100009363", description = "Номер SIM-карты")
    private String integratedCircuitCardIdentifier;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "0104", description = "Пароль")
    private String password;
    @Schema(description = "Признак активации абонента при создании")
    private Boolean activateSubscriber;
    @Schema(minimum = "0", maximum = "100000000000", example = "119205", description = "Номер лицевого счета")
    private BigDecimal accountNumber;
    @Schema(minimum = "0", maximum = "100000000000", example = "1000084001", description = "Номер контракта")
    private BigDecimal contractNumber;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата подписания договора")
    private Date signatureContractDateTime;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "etatarintsev@sberbank-tele.com", description = "Электронная почта")
    private String email;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Выхухолев Капибара Утконосович", description = "Полное имя")
    private String fullName;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "1990-08-30T13:13:13.000+0300", description = "Дата рождения")
    private Date dateOfBirth;
    @Schema(minimum = "0", maximum = "1", allowableValues = {"0", "1"}, example = "1", description = "Пол")
    private BigDecimal genderId;
    @Schema(minimum = "0", maximum = "24", allowableValues = {"1", "2", "3", "4", "5", "7", "8", "9", "24"}, example = "24", description = "Вид документа")
    private BigDecimal documentIdentityId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1205", description = "Серия")
    private String documentSeries;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "983265", description = "Номер")
    private String documentNumber;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Советским РОВД г. Астрахани", description = "Кем выдано")
    private String documentAuthority;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "2005-08-30T13:13:13.000+0300", description = "Дата выдачи")
    private Date documentDateOfIssue;
    @Schema(maxLength = 250, pattern = "^(.*){150}$", example = "РФ", description = "Гражданство")
    private String documentCountry;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Россия", description = "Страна")
    private String country;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Город")
    private String city;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Нарвская", description = "Улица")
    private String street;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "7", description = "Дом")
    private String house;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "125130", description = "Индекс")
    private String post;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Регион")
    private String region;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Населенный пункт")
    private String subRegion;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "70", description = "Квартира")
    private String apartment;
    @Schema(maxLength = 500, pattern = "^(.*){500}$", example = "Комментарий к документу", description = "Комментарий к документу")
    private String comment;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "132", description = "Табельный номер сотрудника ВСП")
    private String employeeId;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "Фамилия Имя Отчество", description = "Менеджер по продажам")
    private String sellerManager;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "38908301110", description = "Номер ВСП")
    private String intDivisionCode;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "Код подразделения ДУ", description = "302-005")
    private String docDivisionCode;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "314159265", description = "Код агента")
    private String sellerId;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Согласия абонентов")
    private String termsOfServices;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "1356", description = "Подключение пакета")
    private String servId;
    @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "01.02.2018", description = "Дата действия договора")
    private String contractDateTo;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "1356", description = "Признак проверки услуги РГС")
    private String serviceCheckFlag;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1356", description = "Идентификатор клиента банка")
    private String sberbankId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1356", description = "Промокод")
    private String promoCode;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Владыка", description = "Должность сотрудника")
    private String jobTitle;
    @Schema(maxLength = 20, pattern = "^(([0-9]){10,20})$", example = "9645173534", description = "MSISDN на который делается replaceMsisdn")
    private String numberToChange;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "AAA-BBB-123-456", description = "Фискальный номер")
    private String fiscalNumber;
    @Schema(maxLength = 50, pattern = "^(.*){50}$", example = "29.01.2021 12:13:14", description = "Дата фискального чека (Связной).")
    private String fiscalDate;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Москва", description = "Место рождения")
    private String placeOfBirth;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Y", description = "тправлять документ Клиенту на email?")
    private String sendDoc;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "N", description = "Признак идентифицированного Клиента")
    private String clientIdentified;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона для связи")
    private String contactPhone;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", example = "1356", description = "Номер заказа")
    private String orderNo;
}
