package ru.telecom.gateway.database.model;


import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "in_t_bbs_ufs_rcs_srv")
@NoArgsConstructor
@Getter
@Setter
public class InTBbsUfsRcsSrv implements Serializable {

    private static final long serialVersionUID = -6207353178774899673L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "in_q_bbs_ufs_rcs_srv")
    @SequenceGenerator(name = "in_q_bbs_ufs_rcs_srv", sequenceName = "in_q_bbs_ufs_rcs_srv", allocationSize = 1)
    private Long id;
    @Column(name = "RCS_ID")
    private Long rcsId;
    @Column(name = "SERV_ID")
    private Long servId;
    @Column(name = "ERROR_STATUS")
    private String errorStatus;

    public InTBbsUfsRcsSrv(Long rcsId, Long servId, String errorStatus) {
        this.rcsId = rcsId;
        this.servId = servId;
        this.errorStatus = errorStatus;
    }
}
