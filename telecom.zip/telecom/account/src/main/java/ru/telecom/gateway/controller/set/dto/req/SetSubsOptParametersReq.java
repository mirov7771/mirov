package ru.telecom.gateway.controller.set.dto.req;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.List;

@Schema(description = "структура запроса",
        example = "{\n"
                + "     \"branchId\": 2,\n"
                + "     \"subscriberId\": 1,\n"
                + "     \"msisdn\": \"9585940115\"\n"
                + "}")
@Data
public class SetSubsOptParametersReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Идентификатор абонента")
    private BigDecimal subscriberId;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @ArraySchema(maxItems = 1000000, schema = @Schema(description = "Опциональные параметры", example = "[{\n"
            + "     \"codeParam\": \"employeID\",\n"
            + "     \"valueParam\": \"TIKHONOVA-SY@HQ.SZB.SBRF.RU\",\n"
            + "     \"description\": \"test\"\n"
            + "}]"))
    private List<OptParameters> optParameters;

    @Schema(description = "структура объекта",
            example = "{\n"
                    + "     \"codeParam\": \"employeID\",\n"
                    + "     \"valueParam\": \"TIKHONOVA-SY@HQ.SZB.SBRF.RU\",\n"
                    + "     \"description\": \"test\"\n"
                    + "}")
    @Data
    public static class OptParameters {
        @Schema(maxLength = 250, example = "employeID", pattern = "^(.*){250}$", description = "Код опционального параметра")
        private String codeParam;
        @Schema(maxLength = 250, example = "TIKHONOVA-SY@HQ.SZB.SBRF.RU", pattern = "^(.*){250}$", description = "Значение опционального параметра")
        private String valueParam;
        @Schema(maxLength = 250, example = "test", pattern = "^(.*){250}$", description = "Описание параметра")
        private String description;
    }
}
