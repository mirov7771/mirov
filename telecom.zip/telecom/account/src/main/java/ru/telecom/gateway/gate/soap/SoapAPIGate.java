package ru.telecom.gateway.gate.soap;

import ru.telecom.gateway.xml.account.*;

public interface SoapAPIGate {

    default GetMsisdnListPoolResponse getMsisdnListPool(GetMsisdnListPoolRequest req) {
        return null;
    }
    default ReserveMsisdnResponse reserveMsisdn(ReserveMsisdnRequest req) {
        return null;
    }
    default ReserveMsisdnReturnResponse reserveMsisdnReturn(ReserveMsisdnReturnRequest req) {
        return null;
    }
    default GetUserProfileResponse getUserProfile(GetUserProfileRequest req) {
        return null;
    }
    default GetUSIProfileResponse getUSIProfile(GetUSIProfileRequest req) {
        return null;
    }
    default ReserveAccountNumberResponse reserveAccountNumber(ReserveAccountNumberRequest req) {
        return null;
    }
    default RegisterClientResponse registerClient(RegisterClientRequest req) {
        return null;
    }
    default ReserveContractNumberResponse reserveContractNumber(ReserveContractNumberRequest req) {
        return null;
    }
    default ActivateSubscriberResponse activateSubscriber(ActivateSubscriberRequest req) {
        return null;
    }
    default ReplaceSIMResponse replaceSIM(ReplaceSIMRequest req){
        return null;
    }
    default GetSubscriberICCHistoryResponse getSubscriberICCHistory(GetSubscriberICCHistoryRequest req) {
        return null;
    }
    default SetSubsOptParametersResponse setSubsOptParameters(SetSubsOptParametersRequest req) {
        return null;
    }
    default GetClntSubsResponse getClntSubs(GetClntSubsRequest req) {
        return null;
    }
    default GetDealerProfileResponse getDealerProfile(GetDealerProfileRequest req) {
        return null;
    }

}
