package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Schema(description = "структура ответа",
        example = "{\n" +
        "\"result\": {\n" +
        "    \"code\": \"OK\",\n" +
        "    \"messageUser\": \"Выполнено успешно\"\n" +
        "},\n" +
        "\"usiProfile\": {\n" +
        "    \"branchId\": 231,\n" +
        "    \"dealerId\": \"IFT\",\n" +
        "    \"partyId\": 965,\n" +
        "    \"partyTypeId\": 1,\n" +
        "    \"partyStatusId\": 1,\n" +
        "    \"icc\": \"89701501078001248910\",\n" +
        "    \"usiId\": 7,\n" +
        "    \"usi\": \"test\",\n" +
        "    \"usiStatusId\": 7,\n" +
        "    \"switchId\": 7,\n" +
        "    \"switchName\": \"тестовый свитчер\"\n" +
        "}\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetUSIProfileRes extends BaseRes {
    private USIProfile usiProfile;

    @Schema(description = "структура объекта",
            example = "{\n" +
            "\"branchId\": 231,\n" +
            "\"dealerId\": \"IFT\",\n" +
            "\"partyId\": 965,\n" +
            "\"partyTypeId\": 1,\n" +
            "\"partyStatusId\": 1,\n" +
            "\"icc\": \"89701501078001248910\",\n" +
            "\"usiId\": 7,\n" +
            "\"usi\": \"test\",\n" +
            "\"usiStatusId\": 7,\n" +
            "\"switchId\": 7,\n" +
            "\"switchName\": \"тестовый свитчер\"\n" +
            "}")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class USIProfile {
        @NotNull
        @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
        private BigDecimal branchId;
        @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Id Дилера")
        private BigDecimal dealerId;
        @Schema(minimum = "0", maximum = "100000000000", example = "20", description = "Id Партии")
        private BigDecimal partyId;
        @Schema(minimum = "0", maximum = "100000000000", example = "2", description = "Id Типа партии")
        private BigDecimal partyTypeId;
        @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Id Статуса партии")
        private BigDecimal partyStatusId;
        @Schema(maxLength = 30, pattern = "^(.*){30}$", example = "89701501077100083863", description = "Открытый номер сим-карты, скрейтч-карты")
        private String icc;
        @Schema(minimum = "0", maximum = "261408", example = "965", description = "Id Карты")
        private BigDecimal usiId;
        @Schema(maxLength = 130, pattern = "^(.*){130}$", example = "250507800124891", description = "Уникальный идентификатор абонента")
        private String usi;
        @Schema(minimum = "0", maximum = "100000000000", example = "3", description = "Статуса SIM-карты")
        private BigDecimal usiStatusId;
        @Schema(minimum = "0", maximum = "100000000000", example = "96", description = "Id Коммутатора")
        private BigDecimal switchId;
        @Schema(maxLength = 200, pattern = "^(.*){200}$", example = "SZ_SAINTPETER", description = "Наименование коммутатора")
        private String switchName;
        @Schema(maxLength = 20, example = "9585940115", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
        private String msisdn;
        @Schema(minimum = "0", maximum = "100000000000", example = "4", defaultValue = "1", description = "Id телефонного номера")
        private BigDecimal msisdnId;
        @Schema(minimum = "0", maximum = "100000000000", example = "4", defaultValue = "1", description = "Id статуса")
        private BigDecimal msisdnStatusId;
        @Schema(maxLength = 200, pattern = "^(.*){200}$", example = "Активный", description = "Наименование статуса")
        private String msisdnStatusName;
    }
}
