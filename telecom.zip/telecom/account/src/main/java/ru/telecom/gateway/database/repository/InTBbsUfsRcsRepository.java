package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.telecom.gateway.database.model.InTBbsUfsRcs;

@Repository
public interface InTBbsUfsRcsRepository extends CrudRepository<InTBbsUfsRcs, Long> {
}
