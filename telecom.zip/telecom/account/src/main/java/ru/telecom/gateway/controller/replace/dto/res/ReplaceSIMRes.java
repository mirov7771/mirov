package ru.telecom.gateway.controller.replace.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

import java.math.BigDecimal;

@Schema(description = "структура ответа",
        example = "{\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Выполнено успешно\"\n" +
                "    },\n" +
                "    \"serviceRequestId\": 123,\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class ReplaceSIMRes extends BaseRes {
    private BigDecimal serviceRequestId;
}
