package ru.telecom.gateway.validator;

import static ru.telecom.gateway.constant.Constants.ERROR;
import static ru.telecom.gateway.constant.Constants.MISSING_REQUIRED_PARAMS;
import static ru.telecom.gateway.constant.Constants.SERVICE_NOT_AVAILABLE;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.exception.TelecomException;

@ControllerAdvice
@Slf4j
public class ValidationHandler {

    @Value("${application.telecom.stub400:false}")
    private Boolean stub400;
    @Value("${application.telecom.stub500:false}")
    private Boolean stub500;

    @ExceptionHandler({Exception.class})
    protected ResponseEntity<?> handleException(Exception ex){
        log.error("error in service ", ex);
        ResultDto res;
        if (ex instanceof TelecomException){
            TelecomException e = (TelecomException) ex;
            res = new ResultDto(e.getCode(), e.getMessage(), e.getDescription(), e.getMessageSystem());
            BaseRes baseRes = new BaseRes();
            baseRes.setResult(res);
            if (!Boolean.TRUE.equals(stub400) && !Boolean.TRUE.equals(stub500))
                return ResponseBuilder.build(baseRes);
            else
                return ResponseEntity.status(e.getStatus()).body(res);
        } else if (ex instanceof MissingServletRequestParameterException) {
            MissingServletRequestParameterException e = (MissingServletRequestParameterException) ex;
            res = new ResultDto(ERROR, MISSING_REQUIRED_PARAMS, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else if (ex instanceof MissingRequestHeaderException) {
            MissingRequestHeaderException e = (MissingRequestHeaderException) ex;
            res = new ResultDto(ERROR, MISSING_REQUIRED_PARAMS, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else if (ex instanceof MethodArgumentNotValidException) {
            MethodArgumentNotValidException e = (MethodArgumentNotValidException) ex;
            res = new ResultDto(ERROR, MISSING_REQUIRED_PARAMS, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        } else {
            res = new ResultDto(ERROR, SERVICE_NOT_AVAILABLE, null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(res);
        }
    }

}
