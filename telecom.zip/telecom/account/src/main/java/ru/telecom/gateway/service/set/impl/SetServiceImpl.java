package ru.telecom.gateway.service.set.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.set.dto.req.SetSubsOptParametersReq;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.set.SetService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.account.FilterSubscriber;
import ru.telecom.gateway.xml.account.OptParameters;
import ru.telecom.gateway.xml.account.SetSubsOptParametersRequest;
import ru.telecom.gateway.xml.account.SetSubsOptParametersResponse;

import java.util.stream.Collectors;

import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Params.STUB_SSOP;

@Service
@RequiredArgsConstructor
@Slf4j
public class SetServiceImpl implements SetService {

    private final SoapAPIGate soapAPIGate;
    private final RequestValidator requestValidator;

    @Override
    public BaseRes setSubsOptParameters(SetSubsOptParametersReq req) {
        requestValidator.validate(STUB_SSOP, ERR_INV_INFO_SUBSCRIBER, ERROR_ABONENT, USI_MESSAGE_SYSTEM);

        BaseRes res = new BaseRes();
        SetSubsOptParametersRequest input = new SetSubsOptParametersRequest();
        input.setBranchId(req.getBranchId());
        FilterSubscriber filter = new FilterSubscriber();
        if (!StringUtils.hasText(req.getMsisdn()) && req.getSubscriberId() == null)
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, MISSING_REQUIRED_PARAMS, null);

        if (StringUtils.hasText(req.getMsisdn()))
            filter.setMsisdn(req.getMsisdn());
        else if (req.getSubscriberId() != null)
            filter.setSubscriberId(req.getSubscriberId());
        input.setFilterSubscriber(filter);
        if (!CollectionUtils.isEmpty(req.getOptParameters())){
            input.getOptParameters().addAll(
                    req.getOptParameters().stream().map(
                            i -> {
                                OptParameters o = new OptParameters();
                                o.setCodeParam(i.getCodeParam());
                                o.setValueParam(i.getValueParam());
                                o.setDescription(i.getDescription());
                                return o;
                            }
                    ).collect(Collectors.toList())
            );
        }
        SetSubsOptParametersResponse output = soapAPIGate.setSubsOptParameters(input);
        if (output != null && output.getResult() != null)
            res.setResult(new ResultDto(output.getResult().getCode(), output.getResult().getMessageUser()));
        else
            throw new TelecomException(ERR_INV_INFO_SUBSCRIBER, HttpStatus.BAD_REQUEST, ERROR_ABONENT, null, USI_MESSAGE_SYSTEM);
        return res;
    }
}
