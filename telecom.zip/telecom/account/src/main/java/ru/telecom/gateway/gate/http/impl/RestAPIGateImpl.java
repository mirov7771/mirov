package ru.telecom.gateway.gate.http.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.http.client.RestGate;
import ru.telecom.gateway.gate.http.dto.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

@Service
@RequiredArgsConstructor
@Slf4j
public class RestAPIGateImpl implements RestAPIGate {

    private final RestGate restGate;
    @Value("${application.telecom.pod-kluchi.url}")
    private String url;
    @Value("${application.telecom.pod-kluchi.auth}")
    private String auth;
    @Value("${application.telecom.aoi.url}")
    private String aoi;
    @Value("${application.telecom.dropper.url}")
    private String dropper;
    @Value("${application.telecom.dropper.user}")
    private String user;
    @Value("${application.telecom.dropper.password}")
    private String password;
    @Value("${application.telecom.dropper.check}")
    private String check;

    @Value("${application.telecom.activate.url}")
    private String activateUrl;
    @Value("${application.telecom.activate.user}")
    private String activateUser;
    @Value("${application.telecom.activate.password}")
    private String activatePassword;

    private static final String REQUEST = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sub=\"http://www.bercut.com/specs/schemas/cc_api_core/subscriber_service\">\n" +
            "   <soapenv:Header/>\n" +
            "   <soapenv:Body>\n" +
            "      <sub:changeSubscriberServiceStatusRequestParams>\n" +
            "         <sub:branchId>%branchId%</sub:branchId>\n" +
            "         <sub:subscriber>\n" +
            "            <sub:msisdn>%msisdn%</sub:msisdn>            \n" +
            "         </sub:subscriber>\n" +
            "         <sub:servId>%servId%</sub:servId>\n" +
            "         <sub:operation>active</sub:operation>\n" +
            "         <sub:chargeOrder>0</sub:chargeOrder>\n" +
            "      </sub:changeSubscriberServiceStatusRequestParams>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    private static final String ESS_REQUEST = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sub=\"http://www.bercut.com/specs/schemas/cc_api_core/subscriber_service\">\n" +
            "   <soapenv:Header/>\n" +
            "   <soapenv:Body>\n" +
            "      <sub:getEnabledSubscriberServicesRequestParams>\n" +
            "         <sub:branchId>0</sub:branchId>\n" +
            "         <sub:subscriber>\n" +
            "            <sub:msisdn>%msisdn%</sub:msisdn>\n" +
            "         </sub:subscriber>\n" +
            "      </sub:getEnabledSubscriberServicesRequestParams>\n" +
            "   </soapenv:Body>\n" +
            "</soapenv:Envelope>";

    @Override
    public OrdersUpdateStatusResponse ordersUpdateStatus(String orderNo, String msisdn) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.set("ServerAuthorization", auth);
            return restGate.call(OrdersUpdateStatusResponse.class,
                    url,
                    null,
                    null,
                    new OrdersUpdateStatusRequest(orderNo, true, msisdn),
                    HttpMethod.POST,
                    headers,
                    MediaType.APPLICATION_JSON);
        } catch (Exception e) {
            log.error("Ошибка вызова сервиса Подключи: ", e);
            return null;
        }
    }

    @Override
    public String changeSubscriberServiceStatus(String branchId, String msisdn, String servId) {
        String request = REQUEST.replace("%branchId%", branchId)
                .replace("%msisdn%", msisdn)
                .replace("%servId%", servId);
        try {
            return restGate.call(String.class,
                    aoi,
                    null,
                    null,
                    request,
                    HttpMethod.POST,
                    null,
                    MediaType.TEXT_XML);
        } catch (Exception e) {
            log.error("Error calling changeSubscriberServiceStatus: ", e);
            return null;
        }
    }

    @Override
    public DropperResponse addPay(String channel, String msisdn, String promoCode, Integer paymentSum, Integer paymentDeadDay) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setBasicAuth(user, password);
            DropperRequest request = new DropperRequest();
            request.setName("addPay");
            request.fillParameters(channel, msisdn, promoCode, paymentSum, paymentDeadDay);
            return restGate.call(DropperResponse.class,
                    dropper,
                    null,
                    null,
                    request,
                    HttpMethod.POST,
                    headers,
                    MediaType.parseMediaType("application/vnd.oracle.adf.action+json"));
        } catch (Exception e) {
            log.error("Error dropper addPay: ", e);
            return null;
        }
    }

    @Override
    public DropperCheckResponse check(String promoCode) {
        try {
            Map<String, Object> query = new HashMap<>();
            query.put("code", promoCode);
            return restGate.call(DropperCheckResponse.class,
                    check,
                    null,
                    query,
                    null,
                    HttpMethod.GET,
                    null,
                    MediaType.APPLICATION_JSON);
        } catch (Exception e) {
            log.error("Error checking drop promoCode: ", e);
            return null;
        }
    }

    @Override
    public List<String> getEnabledSubscriberServices(String msisdn) {
        String request = ESS_REQUEST.replace("%msisdn%", msisdn);
        try {
            String xml = restGate.call(String.class,
                    aoi,
                    null,
                    null,
                    request,
                    HttpMethod.POST,
                    null,
                    MediaType.TEXT_XML);
            List<String> list = new ArrayList<>();
            if (StringUtils.hasText(xml) && xml.contains("billingServiceId")) {
                InputSource is = new InputSource();
                is.setCharacterStream(new StringReader(xml
                        .replace("ber-ns0:", "")
                        .replace("<billingServiceId>", "<billingServiceId>%servId%")
                        .replace("</billingServiceId>", "%servId%</billingServiceId>")));
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                DocumentBuilder db = dbf.newDocumentBuilder();

                Document doc = db.parse(is);
                NodeList nodes = doc.getElementsByTagName("service");
                for (int i = 0; i < nodes.getLength(); i++) {
                    Element element = (Element) nodes.item(i);
                    if (element != null
                            && StringUtils.hasText(element.getTextContent())
                            && element.getTextContent().contains("%servId%")){
                        list.add(element.getTextContent().split("%servId%")[1].split("%servId%")[0]);
                    }
                }
            }
            return list;
        } catch (Exception e) {
            log.error("Error calling getEnabledSubscriberServices: ", e);
            return null;
        }
    }

    @Override
    public ActivateSubscriberRes activateSubscriber(String msisdn) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(activateUser, activatePassword);
        ActivateSubscriberReq req = new ActivateSubscriberReq();
        req.setName("activateSubscriber");
        req.fillParameters(msisdn, ThreadContext.get(SUBSYSTEM_CODE) != null ? ThreadContext.get(SUBSYSTEM_CODE) : "SBOL_PRO");
        return restGate.call(ActivateSubscriberRes.class,
                activateUrl,
                null,
                null,
                req,
                HttpMethod.POST,
                headers,
                MediaType.parseMediaType("application/vnd.oracle.adf.action+json"));
    }
}
