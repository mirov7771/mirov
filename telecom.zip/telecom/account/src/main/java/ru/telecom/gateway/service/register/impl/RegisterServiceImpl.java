package ru.telecom.gateway.service.register.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.config.ActiveMQProducer;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.register.dto.req.RegisterClientReq;
import ru.telecom.gateway.controller.register.dto.res.RegisterClientRes;
import ru.telecom.gateway.controller.register.dto.res.RegisterClientRes.InfoRegister;
import ru.telecom.gateway.database.model.*;
import ru.telecom.gateway.database.procedure.ProcedureCaller;
import ru.telecom.gateway.database.repository.InTBbsUfsLogRepository;
import ru.telecom.gateway.database.repository.InTBbsUfsRcsRepository;
import ru.telecom.gateway.database.repository.InTBbsUfsRcsSrvRepository;
import ru.telecom.gateway.database.repository.RfTServiceKindRepository;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.http.dto.DropperCheckResponse;
import ru.telecom.gateway.gate.http.dto.OrdersUpdateStatusResponse;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.register.RegisterService;
import ru.telecom.gateway.stub.ReserveMsisdnStub;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.account.*;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;
import static ru.telecom.gateway.constant.Constants.Params.*;
import static ru.telecom.gateway.util.ObjectUtils.getInteger;
import static ru.telecom.gateway.util.ObjectUtils.getLong;

@Service
@RequiredArgsConstructor
@Slf4j
public class RegisterServiceImpl implements RegisterService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;
    private final RequestValidator requestValidator;
    private final ProcedureCaller procedureCaller;
    private final RfTServiceKindRepository rfTServiceKindRepository;
    private final ReserveMsisdnStub reserveMsisdnStub;
    private final RestAPIGate restAPIGate;
    private final InTBbsUfsRcsRepository inTBbsUfsRcsRepository;
    private final InTBbsUfsLogRepository inTBbsUfsLogRepository;
    private final InTBbsUfsRcsSrvRepository inTBbsUfsRcsSrvRepository;
    private final ActiveMQProducer activeMQProducer;

    private final static ObjectMapper mapper = new ObjectMapper();

    @Override
    public RegisterClientRes registerClient(RegisterClientReq req) {
        requestValidator.validate(STUB_RCS_ERR, ERR_INV_CREATE_CLNT, ERROR_CLIENT, "0");
        List<OstSystemParam> params = requestValidator.getSystemParams(PARAMS);
        String reserveStub = null;
        String servId = null;
        String isActivateSubs = null;
        String isStubRcs = null;

        for(OstSystemParam o : params){
            if (StringUtils.hasText(o.getValue())) {
                if (STUB_RESERVE_MSISDN.equalsIgnoreCase(o.getCode()))
                    reserveStub = o.getValue();
                else if (CSSS_IDS_XS_ASFS.equalsIgnoreCase(o.getCode())) {
                    if (!o.getValue().contains(","))
                        servId = o.getValue();
                    else
                        servId = o.getValue().split(",")[0];
                } else if (ACTIVATE_SUBS.equalsIgnoreCase(o.getCode()))
                    isActivateSubs = o.getValue();
                else if (STUB_RCS.equalsIgnoreCase(o.getCode()))
                    isStubRcs = o.getValue();
            }
        }
        log.info("Register Client Params [{}, {}, {}, {}]", reserveStub, servId, isActivateSubs, isStubRcs);
        RegisterClientRes res = new RegisterClientRes();
        if (!CollectionUtils.isEmpty(params)
                && StringUtils.hasText(isStubRcs)
                && Y.equalsIgnoreCase(isStubRcs)){
            log.info("Stub success response");
            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
            res.stubInfo();
            return res;
        }

        RegisterClientRequest soapReq = new RegisterClientRequest();

        BaseParameters baseParameters = new BaseParameters();
        if (req.getBranchId() != null) {
            log.debug("BranchID before transforming {}", req.getBranchId());
            baseParameters.setBranchId(requestValidator.getBranchId(req.getBranchId()));
            log.debug("BranchID after transforming {}", baseParameters.getBranchId());

            if (baseParameters.getBranchId().equals(new BigDecimal("0")))
                req.setDealerId(new BigDecimal("1"));
        }
        if (req.getClientJurTypeId() != null)
            baseParameters.setClientJurTypeId(req.getClientJurTypeId());

        if (req.getClientTypeId() != null)
            baseParameters.setClientTypeId(req.getClientTypeId());

        if (req.getDealerId() != null)
            baseParameters.setDealerId(req.getDealerId());

        soapReq.setBaseParameter(baseParameters);

        BaseParameterSubscriber baseParameterSubscriber = new BaseParameterSubscriber();
        if (req.getActivateSubscriber() != null)
            baseParameterSubscriber.setActivateSubscriber(req.getActivateSubscriber());
        if (Y.equalsIgnoreCase(isActivateSubs))
            baseParameterSubscriber.setActivateSubscriber(false);

        if (StringUtils.hasText(req.getMsisdn()))
            baseParameterSubscriber.setMsisdn(req.getMsisdn());

        if (StringUtils.hasText(req.getPassword()))
            baseParameterSubscriber.setPassword(req.getPassword());

        if (StringUtils.hasText(req.getIntegratedCircuitCardIdentifier()))
            baseParameterSubscriber.setIntegratedCircuitCardIdentifier(req.getIntegratedCircuitCardIdentifier());

        if (req.getRatePlanId() != null) {
            log.debug("RatePlanID before transforming {}", req.getRatePlanId());
            baseParameterSubscriber.setRatePlanId(req.getRatePlanId().equals(new BigDecimal("31")) ? new BigDecimal("37") : req.getRatePlanId());
            log.debug("RatePlanID after transforming {}", baseParameterSubscriber.getRatePlanId());
        }

        soapReq.setBaseParameterSubscriber(baseParameterSubscriber);

        CоntractData contractData = new CоntractData();
        if (req.getAccountNumber() != null)
            contractData.setAccountNumber(req.getAccountNumber());

        if (req.getContractNumber() != null)
            contractData.setContractNumber(req.getContractNumber());

        if (StringUtils.hasText(req.getEmail()))
            contractData.setEmail(req.getEmail());

        if (req.getSignatureContractDateTime() != null)
            contractData.setSignatureContractDateTime(dateBuilder.convertDate(req.getSignatureContractDateTime()));

        soapReq.setContractData(contractData);

        DeliveryData deliveryData = new DeliveryData();
        PersonalProfileData personalProfileData = new PersonalProfileData();

        if (StringUtils.hasText(req.getFullName()))
            personalProfileData.setFullName(req.getFullName());

        if (req.getDateOfBirth() != null)
            personalProfileData.setDateOfBirth(dateBuilder.convertDate(req.getDateOfBirth()));

        if (req.getGenderId() != null)
            personalProfileData.setGenderId(req.getGenderId());

        if (req.getDocumentIdentityId() != null)
            personalProfileData.setDocumentIdentityId(req.getDocumentIdentityId());

        if (StringUtils.hasText(req.getDocumentSeries()))
            personalProfileData.setDocumentSeries(req.getDocumentSeries());

        if (StringUtils.hasText(req.getDocumentNumber()))
            personalProfileData.setDocumentNumber(req.getDocumentNumber());

        if (StringUtils.hasText(req.getDocumentAuthority()))
            personalProfileData.setDocumentAuthority(req.getDocumentAuthority());

        if (req.getDocumentDateOfIssue() != null)
            personalProfileData.setDocumentDateOfIssue(dateBuilder.convertDate(req.getDocumentDateOfIssue()));

        if (StringUtils.hasText(req.getDocumentCountry()))
            personalProfileData.setDocumentCountry(req.getDocumentCountry());

        if (StringUtils.hasText(req.getCountry()))
            personalProfileData.setCountry(req.getCountry());

        if (StringUtils.hasText(req.getCity())) {
            personalProfileData.setCity(req.getCity());
            deliveryData.setCity(req.getCity());
        }
        if (StringUtils.hasText(req.getStreet())) {
            personalProfileData.setStreet(req.getStreet());
            deliveryData.setStreet(req.getStreet());
        }
        if (StringUtils.hasText(req.getHouse())) {
            personalProfileData.setHouse(req.getHouse());
            deliveryData.setHouse(req.getHouse());
        }
        if (StringUtils.hasText(req.getPost())) {
            personalProfileData.setPost(req.getPost());
            deliveryData.setPost(req.getPost());
        }
        if (StringUtils.hasText(req.getRegion())) {
            personalProfileData.setRegion(req.getRegion());
            deliveryData.setRegion(req.getRegion());
        }
        if (StringUtils.hasText(req.getSubRegion())) {
            personalProfileData.setSubRegion(req.getSubRegion());
            deliveryData.setSubRegion(req.getSubRegion());
        }
        if (StringUtils.hasText(req.getApartment())) {
            personalProfileData.setApartment(req.getApartment());
            deliveryData.setApartment(req.getApartment());
        }
        if (StringUtils.hasText(req.getComment())) {
            personalProfileData.setComment(req.getComment());
            deliveryData.setComment(req.getComment());
        }

        soapReq.setDeliveryData(deliveryData);
        soapReq.setPersonalProfileData(personalProfileData);

        OptParameters p = new OptParameters();
        if (StringUtils.hasText(req.getEmployeeId())) {
            p.setCodeParam("employeID");
            p.setValueParam(req.getEmployeeId());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getSellerManager())) {
            p = new OptParameters();
            p.setCodeParam("sellerManager");
            p.setValueParam(req.getSellerManager());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getIntDivisionCode())) {
            p = new OptParameters();
            p.setCodeParam("intDivisionCode");
            p.setValueParam(req.getIntDivisionCode());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getDocDivisionCode())) {
            p = new OptParameters();
            p.setCodeParam("docDivisionCode");
            p.setValueParam(req.getDocDivisionCode());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getPlaceOfBirth())) {
            p = new OptParameters();
            p.setCodeParam("placeOfBirth");
            p.setValueParam(req.getPlaceOfBirth());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getSendDoc())) {
            p = new OptParameters();
            p.setCodeParam("sendDoc");
            p.setValueParam(req.getSendDoc());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getClientIdentified())) {
            p = new OptParameters();
            p.setCodeParam("clientIdentified");
            p.setValueParam(req.getClientIdentified());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getSellerId())) {
            p = new OptParameters();
            p.setCodeParam("sellerId");
            p.setValueParam(req.getSellerId());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getTermsOfServices())) {
            p = new OptParameters();
            p.setCodeParam("termsOfServices");
            p.setValueParam(req.getTermsOfServices());
            soapReq.getOptParametersClients().add(p);
        }

        if (StringUtils.hasText(req.getServId())) {
            p = new OptParameters();
            p.setCodeParam("servId");
            p.setValueParam(req.getServId());
            soapReq.getOptParametersSubs().add(p);
        }

        if (StringUtils.hasText(req.getOrderNo())) {
            p = new OptParameters();
            p.setCodeParam("orderNo");
            p.setValueParam(req.getOrderNo());
            soapReq.getOptParametersSubs().add(p);
        }

        if (StringUtils.hasText(req.getContractDateTo())) {
            p = new OptParameters();
            p.setCodeParam("contractDateTo");
            p.setValueParam(req.getContractDateTo());
            soapReq.getOptParametersSubs().add(p);
        }

        if (StringUtils.hasText(req.getContactPhone())) {
            p = new OptParameters();
            p.setCodeParam("contactPhone");
            p.setValueParam(req.getContactPhone());
            soapReq.getOptParametersClients().add(p);
        }

        try {
            if (StringUtils.hasText(req.getServiceCheckFlag())) {
                p = new OptParameters();
                p.setCodeParam("serviceCheckFlag");
                p.setValueParam(req.getServiceCheckFlag());
                soapReq.getOptParametersSubs().add(p);

                if (StringUtils.hasText(servId) && "RGS".equalsIgnoreCase(req.getServiceCheckFlag())) {
                    log.info("Start RGS processing");
                    log.info("Call antinFraud check");
                    Map<String, String> checkStatus
                            = procedureCaller.checkSubsServExists(servId, req.getDocumentIdentityId(), req.getDocumentSeries(), req.getDocumentNumber());
                    log.debug("Call antinFraud check result {}", checkStatus);
                    if (checkStatus != null
                            && !checkStatus.isEmpty()
                            && !"OK".equalsIgnoreCase(checkStatus.get("o_err_code"))
                            && StringUtils.hasText(checkStatus.get("o_err_text"))
                            && checkStatus.get("o_err_text").contains(" ")) {
                        log.info("Try get active TP name");
                        String[] msgParts = checkStatus.get("o_err_text").split(" ");
                        Optional<RfTServiceKind> rfTServiceKind = rfTServiceKindRepository.findById(Long.valueOf(servId));
                        BigDecimal subsId = procedureCaller.getSubsId(msgParts[msgParts.length - 1]);
                        log.info("Found subsId {}", subsId);
                        if (subsId != null) {
                            log.info("Get active TP name procedure");
                            Map<String, Object> activeServiceName = procedureCaller.getActiveServiceName(subsId);
                            log.info("Get active TP name procedure result {}", activeServiceName);
                            if (activeServiceName != null && !activeServiceName.isEmpty()) {
                                String errMsg = "MSISDN:" + msgParts[msgParts.length - 1] + ";TP:" + activeServiceName;
                                if (rfTServiceKind.isPresent())
                                    errMsg += ";serviceName:" + rfTServiceKind.get().getName();
                                throw new TelecomException(ERR_SERVICE_CONNECTED, HttpStatus.BAD_REQUEST, errMsg, null);
                            }
                        }
                    }
                }
            }

            if (StringUtils.hasText(req.getSberbankId())) {
                p = new OptParameters();
                p.setCodeParam("sberbankId");
                p.setValueParam(req.getSberbankId());
                soapReq.getOptParametersSubs().add(p);
            }

            if (StringUtils.hasText(req.getPromoCode())) {
                p = new OptParameters();
                p.setCodeParam("promoCode");
                p.setValueParam(req.getPromoCode());
                soapReq.getOptParametersSubs().add(p);
            }

            if (StringUtils.hasText(req.getJobTitle())) {
                p = new OptParameters();
                p.setCodeParam("jobTitle");
                p.setValueParam(req.getJobTitle());
                soapReq.getOptParametersSubs().add(p);
            }

            if (StringUtils.hasText(req.getNumberToChange())) {
                p = new OptParameters();
                p.setCodeParam("numberToChange");
                p.setValueParam(req.getNumberToChange());
                soapReq.getOptParametersSubs().add(p);
            }

            if (StringUtils.hasText(req.getFiscalNumber())) {
                p = new OptParameters();
                p.setCodeParam("fiscalNumber");
                p.setValueParam(req.getFiscalNumber());
                soapReq.getOptParametersSubs().add(p);
            }

            if (StringUtils.hasText(req.getFiscalDate())) {
                p = new OptParameters();
                p.setCodeParam("fiscalDate");
                p.setValueParam(req.getFiscalDate());
                soapReq.getOptParametersSubs().add(p);
            }

            RegisterClientResponse soapRes = soapAPIGate.registerClient(soapReq);

//            For local
//            RegisterClientResponse soapRes = new RegisterClientResponse();
//            Result r1 = new Result();
//            r1.setCode("OK");
//            r1.setMessageUser("OK");
//            InfoRegisterClientSubscriber register = new InfoRegisterClientSubscriber();
//            register.setClientId(new BigDecimal(4922699));
//            register.setSubscriberId(new BigDecimal(4942817));
//            register.setMsisdn(req.getMsisdn());
//            register.setAccountNumber(new BigDecimal(10303233));
//            register.setContractNumber(new BigDecimal(836492));
//            soapRes.setResult(r1);
//            soapRes.setInfoRegister(register);
            if (soapRes == null || soapRes.getResult() == null)
                throw new TelecomException(ERR_INV_CREATE_CLNT, HttpStatus.BAD_REQUEST, ERROR_CLIENT, null);

            Long subscriberId = 0L;
            Long clientId = 0L;
            Result result = soapRes.getResult();
            res.setResult(new ResultDto(result.getCode(), result.getMessageUser()));
            List<String> servIds = new ArrayList<>();
            if (soapRes.getInfoRegister() != null) {
                InfoRegister infoRegisterRes = new InfoRegister();
                infoRegisterRes.setClientId(soapRes.getInfoRegister().getClientId());
                infoRegisterRes.setSubscriberId(soapRes.getInfoRegister().getSubscriberId());
                subscriberId = getLong(infoRegisterRes.getSubscriberId());
                clientId = getLong(infoRegisterRes.getClientId());
                infoRegisterRes.setContractNumber(soapRes.getInfoRegister().getContractNumber());
                infoRegisterRes.setAccountNumber(soapRes.getInfoRegister().getAccountNumber());
                infoRegisterRes.setMsisdn(soapRes.getInfoRegister().getMsisdn());
                res.setInfoRegister(infoRegisterRes);
            }

            if (StringUtils.hasText(req.getServId())
                    && StringUtils.hasText(baseParameterSubscriber.getMsisdn())
                    && baseParameters.getBranchId() != null) {
                if (req.getServId().contains(",")) {
                    servIds.addAll(Arrays.asList(req.getServId().split(",")));
                } else {
                    servIds.add(req.getServId());
                }
                if (!CollectionUtils.isEmpty(servIds))
                    for(String i : servIds) {
                        String cssRes = restAPIGate.changeSubscriberServiceStatus(req.getBranchId().toString(), baseParameterSubscriber.getMsisdn(), i);
                        if (!StringUtils.hasText(cssRes)) {
                            Thread.sleep(300);
                            log.debug("Receive error on changeSubscriberServiceStatus, try again for {}", i);
                            restAPIGate.changeSubscriberServiceStatus(req.getBranchId().toString(), baseParameterSubscriber.getMsisdn(), i);
                        }
                    }
            }

            if (res.getResult() != null
                    && OK.equalsIgnoreCase(res.getResult().getCode())) {

                StringBuilder optParamsClient = new StringBuilder();
                if (!CollectionUtils.isEmpty(soapReq.getOptParametersClients()))
                    soapReq.getOptParametersClients().forEach(i -> optParamsClient.append(i.getCodeParam())
                            .append(":")
                            .append(i.getValueParam())
                            .append(";"));
                StringBuilder optParamsSubs = new StringBuilder();
                if (!CollectionUtils.isEmpty(soapReq.getOptParametersSubs()))
                    soapReq.getOptParametersSubs().forEach(i -> optParamsSubs.append(i.getCodeParam())
                            .append(":")
                            .append(i.getValueParam())
                            .append(";"));
                Date contractDateTo = null;
                try {
                    if (req.getContractDateTo() != null)
                        contractDateTo = DateUtils.parseDate(req.getContractDateTo(), "MMM dd, yyyy HH:mm:ss",
                                "MMM dd, yyyy",
                                "yyyy-MM-dd'T'HH:mm:ss.SSSX",
                                "yyyy-MM-dd'T'HH:mm:ss.SSS",
                                "EEE, dd MMM yyyy HH:mm:ss zzz",
                                "yyyy-MM-dd",
                                "dd.MM.yyyy");
                } catch (Exception e) {
                    log.error("Error parsingDate: ", e);
                }

                Long rcsId = null;
                try {
                    String subSystemCode = ThreadContext.get(SUBSYSTEM_CODE) == null ? "MAP_SBOL" : ThreadContext.get(SUBSYSTEM_CODE);
                    String currentSystem = requestValidator.getCurrentSystem() == null ? "UFS_QUEUE_PROM" : requestValidator.getCurrentSystem();
                    InTBbsUfsLog logDb = inTBbsUfsLogRepository.save(InTBbsUfsLog.builder()
                                    .serviceName("RegisterClientSubscriber")
                                    .errorStatus(res.getResult().getCode())
                                    .errorText(res.getResult().getMessageUser())
                                    .subsystemCode(subSystemCode)
                                    .reqDate(new Date())
                                    .resDate(new Date())
                                    .timeOperations(1L)
                                    .currentSystem(currentSystem)
                            .build());
                    if (logDb.getId() != null) {
                        InTBbsUfsRcs rcs = inTBbsUfsRcsRepository.save(InTBbsUfsRcs.builder()
                                .logId(logDb.getId())
                                .branchId(getLong(baseParameters.getBranchId()))
                                .clientTypeId(getLong(baseParameters.getClientTypeId()))
                                .clientJurTypeId(getLong(baseParameters.getClientJurTypeId()))
                                .dealerId(getLong(baseParameters.getDealerId()))
                                .msisdn(baseParameterSubscriber.getMsisdn())
                                .ratePlanId(getLong(baseParameterSubscriber.getRatePlanId()))
                                .icc(baseParameterSubscriber.getIntegratedCircuitCardIdentifier())
                                .subsPassword(baseParameterSubscriber.getPassword())
                                .activateSubscriber(Boolean.TRUE.equals(baseParameterSubscriber.isActivateSubscriber()) ? Y : N)
                                .accountNumber(getLong(contractData.getAccountNumber()))
                                .contractNumber(getLong(contractData.getContractNumber()))
                                .signatureDateTime(req.getSignatureContractDateTime())
                                .email(contractData.getEmail())
                                .fullName(personalProfileData.getFullName())
                                .dateOfBirth(req.getDateOfBirth())
                                .genderId(getInteger(personalProfileData.getGenderId()))
                                .documentIdentityId(getLong(personalProfileData.getDocumentIdentityId()))
                                .documentSeries(personalProfileData.getDocumentSeries())
                                .documentNumber(personalProfileData.getDocumentNumber())
                                .documentAuthority(personalProfileData.getDocumentAuthority())
                                .documentDateOfIssue(req.getDocumentDateOfIssue())
                                .documentCountry(personalProfileData.getDocumentCountry())
                                .country(personalProfileData.getCountry())
                                .city(personalProfileData.getCity())
                                .street(personalProfileData.getStreet())
                                .house(personalProfileData.getHouse())
                                .post(personalProfileData.getPost())
                                .region(personalProfileData.getRegion())
                                .subRegion(personalProfileData.getSubRegion())
                                .apartment(personalProfileData.getApartment())
                                .notes(personalProfileData.getComment())
                                .deliveryTypeId(getLong(deliveryData.getDeliveryTypeId()))
                                .cityD(deliveryData.getCity())
                                .streetD(deliveryData.getStreet())
                                .houseD(deliveryData.getHouse())
                                .postD(deliveryData.getPost())
                                .regionD(deliveryData.getRegion())
                                .subRegionD(deliveryData.getSubRegion())
                                .apartmentD(deliveryData.getApartment())
                                .notesD(deliveryData.getComment())
                                .optParametersClient(optParamsClient.toString())
                                .optParametersSubs(optParamsSubs.toString())
                                .clientId(clientId)
                                .subscriberId(subscriberId)
                                .employeId(req.getEmployeeId())
                                .sellerManager(req.getSellerManager())
                                .contractDateTo(contractDateTo)
                                .sellerId(req.getSellerId())
                                .intDivisionCode(req.getIntDivisionCode())
                                .sendDoc(StringUtils.hasText(req.getSendDoc()) ? Y : N)
                                .numberToChange(req.getNumberToChange())
                                .clientIdentified(req.getClientIdentified())
                                .build());
                        rcsId = rcs.getId();
                        if (rcs.getId() != null && !CollectionUtils.isEmpty(servIds))
                            inTBbsUfsRcsSrvRepository.saveAll(servIds.stream()
                                    .map(i -> new InTBbsUfsRcsSrv(rcs.getId(), getLong(i), "")).collect(Collectors.toList()));

                        if (Y.equalsIgnoreCase(requestValidator.getSystemParam("SEND_DOC"))) {
                            Map<String, Object> sendObjectMap = new HashMap<>();
                            sendObjectMap.put("id", rcsId);
                            sendObjectMap.put("clientId", rcs.getClientId());
                            sendObjectMap.put("accountNumber", rcs.getAccountNumber());
                            sendObjectMap.put("contractNumber", rcs.getContractNumber());
                            sendObjectMap.put("subscriberId", rcs.getSubscriberId());
                            sendObjectMap.put("msisdn", rcs.getMsisdn());
                            sendObjectMap.put("sellerId", rcs.getSellerId());
                            sendObjectMap.put("docFileDir", requestValidator.getSystemParam("DOC_FILE_DIR"));
                            sendObjectMap.put("sendDoc", rcs.getSendDoc());
                            sendObjectMap.put("email", rcs.getEmail());
                            sendObjectMap.put("currentSystem", currentSystem);
                            sendObjectMap.put("subSystemCode", subSystemCode);
                            String sendObjectJson = mapper.writeValueAsString(sendObjectMap);
                            try {
                                activeMQProducer.sendMessage("docs", sendObjectJson);
                            } catch (Exception e) {
                                log.error("Error sending to ActiveMQ, queue DOCS: ", e);
                            }
                        }
                    }
                } catch (Exception e) {
                    log.error("Error creating client in octopus: ", e);
                }

                if (Y.equalsIgnoreCase(requestValidator.getSystemParam("SEND_RM")) && StringUtils.hasText(req.getNumberToChange())) {
                    Map<String, Object> numberToChangeMap = new HashMap<>();
                    numberToChangeMap.put("id", rcsId);
                    numberToChangeMap.put("subscriberId", subscriberId);
                    numberToChangeMap.put("msisdn", baseParameterSubscriber.getMsisdn());
                    numberToChangeMap.put("numberToChange", baseParameterSubscriber.getMsisdn());
                    numberToChangeMap.put("sellerId", "SBOL_PRO");
                    numberToChangeMap.put("currentSystem", "UFS_QUEUE_PROM");
                    numberToChangeMap.put("subSystemCode", "MAP_SBOL");
                    String numberToChangeJson = mapper.writeValueAsString(numberToChangeMap);
                    try {
                        activeMQProducer.sendMessage("replace", numberToChangeJson);
                    } catch (Exception e) {
                        log.error("Error sending to ActiveMQ, queue REPLACE: ", e);
                    }
                }

                if (StringUtils.hasText(req.getOrderNo())
                        && StringUtils.hasText(req.getMsisdn())) {
                    OrdersUpdateStatusResponse ordersUpdateStatusResponse = restAPIGate.ordersUpdateStatus(req.getOrderNo(), req.getMsisdn());
                    if (ordersUpdateStatusResponse == null
                            || !StringUtils.hasText(ordersUpdateStatusResponse.getStatus())
                            || !"success".equalsIgnoreCase(ordersUpdateStatusResponse.getStatus())) {
                        log.error("Ошибка вызова сервиса Подключи: {} - {}", req.getOrderNo(), req.getMsisdn());
                    }
                }

                if (StringUtils.hasText(req.getPromoCode())) {
                    DropperCheckResponse check = restAPIGate.check(req.getPromoCode());
                    if (check != null
                            && check.getFullDropperValue() != null
                            && check.getSingleDropValue() != null
                            && !check.getSingleDropValue().equals(0)
                            && check.getFullDropperValue().compareTo(check.getSingleDropValue()) > 0
                            && !CollectionUtils.isEmpty(check.getIdTariffs())
                            && Boolean.TRUE.equals(requestValidator.validateDropperDate(check.getValidTill()))) {
                        List<String> enabledList = restAPIGate.getEnabledSubscriberServices(baseParameterSubscriber.getMsisdn());
                        if (!CollectionUtils.isEmpty(enabledList)
                                && enabledList.stream().anyMatch(i -> check.getIdTariffs().contains(i))) {
                            int paymentDeadDay = check.getFullDropperValue() / check.getSingleDropValue();
//Заменяю вызов рестапи на вызов хранимой процедуры
//                            DropperResponse dropperResponse = restAPIGate.addPay(ThreadContext.get(SUBSYSTEM_CODE),
//                                    baseParameterSubscriber.getMsisdn(),
//                                    req.getPromoCode(),
//                                    check.getSingleDropValue(),
//                                    paymentDeadDay);
                            Map<String, String> dropperResponse = procedureCaller.addPay(ThreadContext.get(SUBSYSTEM_CODE),
                                    baseParameterSubscriber.getMsisdn(),
                                    req.getPromoCode(),
                                    check.getSingleDropValue(),
                                    paymentDeadDay);
                            log.debug("Dropper addPay response: {}", dropperResponse);
                        }
                    }
                }
            }

            return res;
        } catch (Exception e){
            log.error("Error register Client: ", e);
            reserveMsisdnStub.reserveMsisdnUFS(reserveStub, soapReq.getBaseParameter().getBranchId(), soapReq.getBaseParameterSubscriber().getMsisdn());
            if (e instanceof TelecomException) {
                TelecomException te = (TelecomException) e;
                throw new TelecomException(te.getCode(), HttpStatus.BAD_REQUEST, te.getMessageUser(), te.getMessageSystem());
            } else {
                throw new TelecomException(ERR_INV_CREATE_CLNT, HttpStatus.BAD_REQUEST, ERROR_CLIENT, "0");
            }
        }
    }

}
