package ru.telecom.gateway.service.activate;

import ru.telecom.gateway.controller.activate.dto.req.ActivateSubscriberReq;
import ru.telecom.gateway.controller.base.res.BaseRes;

public interface ActivateService {

    BaseRes activateSubscriber(ActivateSubscriberReq req);
}
