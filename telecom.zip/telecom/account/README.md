###Proxy Сервис для методов из DSI_CRM_AccountManagementBinding

- SOAP: GetMsisdnListPool --> REST: sbermobile/api/v1/getMsisdnListPool
- SOAP: GetUserProfile --> REST: sbermobile/api/v1/getUserProfile
- SOAP: GetUSIProfile --> REST: sbermobile/api/v1/getUSIProfile
- SOAP: RegisterClientSubscriber --> REST: sbermobile/api/v1/registerClient
- SOAP: ReserveAccountNumber --> REST: sbermobile/api/v1/reserveAccountNumber
- SOAP: ReserveContractNumber --> REST: sbermobile/api/v1/reserveContractNumber
- SOAP: ReserveMsisdn --> REST: sbermobile/api/v1/reserveMsisdn
- SOAP: ReserveMsisdnReturn --> REST: sbermobile/api/v1/reserveMsisdnReturn
- SOAP: ActivateSubscriber --> REST: sbermobile/api/v1/activateSubscriber
- SOAP: ReplaceSIM --> REST: sbermobile/api/v1/replaceSIM
- SOAP: GetSubscriberICCHistory --> REST: sbermobile/api/v1/getSubscriberICCHistory
- SOAP: SetSubsOptParameters --> REST: sbermobile/api/v1/setSubsOptParameters
- SOAP: GetClntSubs --> REST: sbermobile/api/v1/getClntSubs

####Properties
- application.telecom.url - урл вэб-сервиса (soap)
- application.telecom.service - название эндпоинта вэб-сервиса (soap)
- application.telecom.timeout -  время ожидания ответа от вэб-сервиса (soap)
- application.telecom.system -  очередь