package ru.telecom.gateway.service.mock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;

@Service
public class MockService {

    public BaseRes changeSubscriberServiceStatus() {
        BaseRes res = new BaseRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        return res;
    }

}
