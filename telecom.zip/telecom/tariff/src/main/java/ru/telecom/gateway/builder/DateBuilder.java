package ru.telecom.gateway.builder;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContextException;
import org.springframework.stereotype.Component;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Date;
import java.util.GregorianCalendar;

@Component
@RequiredArgsConstructor
@Slf4j
public class DateBuilder {

    private static final DatatypeFactory dataTypeFactory;

    static {
        try {
            dataTypeFactory = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            log.error("Datatype Configuration error", e);
            throw new ApplicationContextException("Could not initialize bean RegisterService", e);
        }
    }

    public XMLGregorianCalendar convertDate(Date date) {
        if (date == null)
            return null;
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTime(date);
        return dataTypeFactory.newXMLGregorianCalendar(gc);
    }

    public Date convertDate(XMLGregorianCalendar calendar) {
        if (calendar == null)
            return null;
        return calendar.toGregorianCalendar().getTime();
    }

}
