package ru.telecom.gateway.controller.get.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import lombok.Data;
import org.springframework.util.CollectionUtils;

@Schema(description = "Бонусы", example = "{\n"
        + "        \"bonusPercent\": 1,\n"
        + "        \"promoText\": \"Возврат до 1% СПАСИБО\"\n"
        + "      }")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Bonus {
    @Schema(minimum = "0", maximum = "100000000000", example = "1", description = "Стоимость продления на следующий период")
    private BigDecimal bonusPercent;
    @Schema(maxLength = 32, pattern = "^(.*){250}$", example = "Возврат до 1% СПАСИБО", description = "Наименование тарифного плана (услуги)")
    private String promoText;

    public Bonus(ru.telecom.gateway.xml.tariff.Bonus b) {
        List<Serializable> list = b.getBonusPercentsAndBonusTexts();
        if (!CollectionUtils.isEmpty(list)) {
            this.bonusPercent = (BigDecimal) list.get(0);
            if (list.size() > 1) {
                this.promoText = (String) list.get(1);
            }
        }
    }
}
