package ru.telecom.gateway.controller.get.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import ru.telecom.gateway.xml.tariff.Sms;
import ru.telecom.gateway.xml.tariff.Voice;

@Schema(description = "Тип трафика и его объемы входящие в тариф", example = "{\n"
        + "        \"voice\": {\n"
        + "          \"measure\": 600,\n"
        + "          \"quantity\": \"MINUTES\"\n"
        + "        }\n"
        + "      }")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@Slf4j
public class Traffic {
    @Schema(implementation = Data.class, description = "Данные - GB, MB", nullable = true)
    private Data data;
    @Schema(implementation = Data.class, description = "Голос - минуты, секунды", nullable = true)
    private Data voice;
    @Schema(implementation = Data.class, description = "SMS", nullable = true)
    private Data sms;

    public Traffic(ru.telecom.gateway.xml.tariff.Traffic traffic) {
        List<Serializable> list = traffic.getVoicesAndDatasAndSms();
        if (!CollectionUtils.isEmpty(list)) {
            list.forEach(i -> {
                if (i instanceof ru.telecom.gateway.xml.tariff.Data){
                    ru.telecom.gateway.xml.tariff.Data d = (ru.telecom.gateway.xml.tariff.Data) i;
                    this.data = new Data(d);
                } else if (i instanceof Voice) {
                    Voice v = (Voice) i;
                    this.voice = new Data(v);
                } else if (i instanceof Sms){
                    Sms s = (Sms) i;
                    this.sms = new Data(s);
                }
            });
        }
    }

}