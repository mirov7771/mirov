package ru.telecom.gateway.controller.change.dto.req;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

@Schema(description = "структура запроса",
        example = "{\n" +
                "    \"msisdn\": \"9645173535\",\n" +
                "    \"serviceId\": 31,\n" +
                "    \"serviceStatus\": \"ACTIVATE\",\n" +
                "    \"chargeOrder\": \"1\",\n" +
                "    \"targetDate\": \"1990-08-30T13:13:13.000+0300\"\n" +
                "}")
@Data
public class ChangeSubscriberServiceStatusReq {
    @NotNull
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id услуги")
    private BigDecimal serviceId;
    @Schema(maxLength = 50, pattern = "^(.*){50}$", description = "Действие над услугой", example = "ACTIVATE", allowableValues = {"ACTIVATE", "DISABLE", "BLOCK"})
    private String serviceStatus = "ACTIVATE";
    @Schema(minimum = "0", maximum = "10", example = "1", description = "Создавать начисление на заказ или нет")
    private BigDecimal chargeOrder = new BigDecimal("1");
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "1990-08-30T13:13:13.000+0300", description = "Дата смены статуса услуги")
    private Date targetDate;
}
