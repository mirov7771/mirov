package ru.telecom.gateway.controller.get.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Provider {
    @ArraySchema(maxItems = 128, schema = @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Beeline", description = "Провайдер"))
    private List<String> provider;
}
