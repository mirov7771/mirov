package ru.telecom.gateway.controller.get.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import ru.telecom.gateway.xml.tariff.Sms;
import ru.telecom.gateway.xml.tariff.Voice;

import javax.xml.bind.JAXBElement;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(example = "{\n"
        + "          \"measure\": 600,\n"
        + "          \"quantity\": \"MINUTES\"\n"
        + "        }")
@Slf4j
public class Data {
    @Schema(minimum = "0", maximum = "100000000000", example = "600", description = "Код единицы измерения")
    private BigDecimal quantity;
    @Schema(maxLength = 32, example = "MINUTES", pattern = "^(.*){32}$", description = "Величина")
    private String measure;
    @Schema(maxLength = 520, example = "60", pattern = "^(.*){520}$", description = "Минимальное значение")
    private String maxAvgMin;

    public Data(Voice v) {
        v.getQuantitiesAndMeasuresAndMaxAvgMins().forEach(i -> {
            if (i.getName() != null && i.getValue() != null) {
                if ("measure".contains(i.getName().toString().toLowerCase()))
                    this.measure = (String) i.getValue();
                if ("quantity".contains(i.getName().toString().toLowerCase()))
                    this.quantity = (BigDecimal) i.getValue();
                if ("maxAvgMin".contains(i.getName().toString().toLowerCase()))
                    this.maxAvgMin = (String) i.getValue();
            }
        });
    }

    public Data(Sms s) {
        s.getQuantitiesAndMeasuresAndMaxAvgMins().forEach(i -> {
            if (i.getName() != null && i.getValue() != null) {
                if ("measure".contains(i.getName().toString().toLowerCase()))
                    this.measure = (String) i.getValue();
                if ("quantity".contains(i.getName().toString().toLowerCase()))
                    this.quantity = (BigDecimal) i.getValue();
                if ("maxAvgMin".contains(i.getName().toString().toLowerCase()))
                    this.maxAvgMin = (String) i.getValue();
            }
        });
    }

    public Data(ru.telecom.gateway.xml.tariff.Data d) {
        d.getQuantitiesAndMeasuresAndMaxAvgMins().forEach(i -> {
            if (i.getName() != null && i.getValue() != null) {
                if ("measure".contains(i.getName().toString().toLowerCase()))
                    this.measure = (String) i.getValue();
                if ("quantity".contains(i.getName().toString().toLowerCase()))
                    this.quantity = (BigDecimal) i.getValue();
                if ("maxAvgMin".contains(i.getName().toString().toLowerCase()))
                    this.maxAvgMin = (String) i.getValue();
            }
        });
    }

}