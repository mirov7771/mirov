package ru.telecom.gateway.service.get;

import ru.telecom.gateway.controller.get.dto.req.GetTariffPlansReq;
import ru.telecom.gateway.controller.get.dto.res.GetTariffPlansRes;
import ru.telecom.gateway.service.Service;

public interface GetService extends Service {
    GetTariffPlansRes getTariffPlans(GetTariffPlansReq req);
}
