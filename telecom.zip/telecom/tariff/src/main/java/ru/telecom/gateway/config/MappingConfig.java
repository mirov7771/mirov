package ru.telecom.gateway.config;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

@Component
@ConfigurationProperties(prefix = "application.telecom")
@Getter @Setter
@Slf4j
public class MappingConfig {

    private Map<String, String> system;

    public String getSystemCode(){
        String subSystem = ThreadContext.get(SUBSYSTEM_CODE);
        String queue = this.system.get(subSystem) != null ? this.system.get(subSystem) : subSystem;
        log.info("Request Queue: {}", queue);
        return queue;
    }

}
