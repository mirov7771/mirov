package ru.telecom.gateway.controller.base.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Структура запроса", example = "{\n"
        + "  \"paramName\": \"ONLY_HOME_REG\",\n"
        + "  \"paramValue\": \"FALSE\"\n"
        + "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Entry {
    @Schema(maxLength = 32, example = "ONLY_HOME_REG", pattern = "^(.*){32}$", description = "Название параметра", allowableValues = {
            "ONLY_HOME_REG",
            "USERGRP_CODE",
            "TRANSFER_RESTS",
            "ECOSYSTEM",
            "FINAL_PROFILE_STATUS",
            "FIRST_INSTALL_DATE",
            "OPERATOR_ID",
            "PROFILE_STATUS",
            "SMDP_ADDRESS",
            "CLIENT_IDENTIFIED",
            "SERVICE_NAME",
            "ACCOUNT_NUMBER",
            "CONTRACT_DATE",
            "CONTRACT_NUM",
            "SBERBANK_ID",
            "ICCID",
            "MSISDN"
    })
    private String paramName;
    @Schema(maxLength = 250, example = "FALSE", pattern = "^(.*){250}$", description = "Значние параметра")
    private String paramValue;
}
