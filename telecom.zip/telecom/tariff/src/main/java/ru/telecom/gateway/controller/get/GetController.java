package ru.telecom.gateway.controller.get;

import static ru.telecom.gateway.constant.Constants.APPLICATION_JSON_VALUE;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.base.support.SberApiError;
import ru.telecom.gateway.controller.get.dto.req.GetTariffPlansReq;
import ru.telecom.gateway.controller.get.dto.res.GetTariffPlansRes;
import ru.telecom.gateway.service.get.GetService;

import javax.validation.Valid;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Tag(name = "Get Methods")
public class GetController {

    private final GetService service;

    @Operation(summary = "Метод получения Тарифных Планов", description = "Операция для получения Тарифных Планов для подключения Абоненту", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetTariffPlansRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    },\n" +
                                    "    \"tariff\": [\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 220,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 220,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1295,\n" +
                                    "            \"serviceName\": \"Комьюнити_1\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 5\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 150\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 250,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 250,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1296,\n" +
                                    "            \"serviceName\": \"Комьюнити_2\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 10\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 150\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 290,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 290,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1297,\n" +
                                    "            \"serviceName\": \"Комьюнити_3\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 20\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 150\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 350,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 350,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1298,\n" +
                                    "            \"serviceName\": \"Комьюнити_4\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 30\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 150\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 250,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 250,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1299,\n" +
                                    "            \"serviceName\": \"Комьюнити_5\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 5\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 300\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 290,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 290,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1300,\n" +
                                    "            \"serviceName\": \"Комьюнити_6\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 10\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 300\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 330,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 330,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1301,\n" +
                                    "            \"serviceName\": \"Комьюнити_7\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 20\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 300\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 400,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 400,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1302,\n" +
                                    "            \"serviceName\": \"Комьюнити_8\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 30\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 300\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 320,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 320,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1303,\n" +
                                    "            \"serviceName\": \"Комьюнити_9\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 5\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 600\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 350,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 350,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1304,\n" +
                                    "            \"serviceName\": \"Комьюнити_10\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 10\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 600\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 400,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 400,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1305,\n" +
                                    "            \"serviceName\": \"Комьюнити_11\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 20\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 600\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 450,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 450,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1306,\n" +
                                    "            \"serviceName\": \"Комьюнити_12\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 30\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 600\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 550,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 550,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1307,\n" +
                                    "            \"serviceName\": \"Комьюнити_13\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 5\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 1500\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 600,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 600,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1308,\n" +
                                    "            \"serviceName\": \"Комьюнити_14\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 10\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 1500\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": []\n" +
                                    "            }\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"bonus\": {\n" +
                                    "                \"bonusPercent\": 40,\n" +
                                    "                \"promoText\": \"Вернем до 40% бонусами СПАСИБО\"\n" +
                                    "            },\n" +
                                    "            \"clientTariffType\": \"B2C\",\n" +
                                    "            \"firstMonth\": 650,\n" +
                                    "            \"messengers\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Facebook Messenger\",\n" +
                                    "                    \"Viber\",\n" +
                                    "                    \"WhatsApp\",\n" +
                                    "                    \"Skype\",\n" +
                                    "                    \"Telegram\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"music\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Apple Music\",\n" +
                                    "                    \"Shazam\",\n" +
                                    "                    \"Google Music\",\n" +
                                    "                    \"Я.Музыка\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"nextMonth\": 650,\n" +
                                    "            \"notes\": \"Рег.\",\n" +
                                    "            \"ratePlanId\": 43,\n" +
                                    "            \"rating\": 0,\n" +
                                    "            \"regionType\": \"MEDIUM\",\n" +
                                    "            \"serviceId\": 1309,\n" +
                                    "            \"serviceName\": \"Комьюнити_15\",\n" +
                                    "            \"social\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"ВКонтакте\",\n" +
                                    "                    \"Instagram\",\n" +
                                    "                    \"Facebook\",\n" +
                                    "                    \"Одноклассники\",\n" +
                                    "                    \"Twitter\"\n" +
                                    "                ]\n" +
                                    "            },\n" +
                                    "            \"traffic\": {\n" +
                                    "                \"data\": {\n" +
                                    "                    \"measure\": \"GB\",\n" +
                                    "                    \"quantity\": 20\n" +
                                    "                },\n" +
                                    "                \"sms\": {\n" +
                                    "                    \"measure\": \"SMS\",\n" +
                                    "                    \"quantity\": 50\n" +
                                    "                },\n" +
                                    "                \"voice\": {\n" +
                                    "                    \"measure\": \"MINUTES\",\n" +
                                    "                    \"quantity\": 1500\n" +
                                    "                }\n" +
                                    "            },\n" +
                                    "            \"video\": {\n" +
                                    "                \"provider\": [\n" +
                                    "                    \"Youtube\",\n" +
                                    "                    \"Twitch\",\n" +
                                    "                    \"Rutube\"\n" +
                                    "                ]\n" +
                                    "            }\n" +
                                    "        }\n" +
                                    "    ]\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetTariffPlansReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branchId\": \"6\",\n" +
                                    "    \"channel\": \"MAP_SBOL\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getTariffPlans", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetTariffPlansRes> getTariffPlans(@Valid @RequestBody GetTariffPlansReq req) {
        return ResponseBuilder.build(service.getTariffPlans(req));
    }

}
