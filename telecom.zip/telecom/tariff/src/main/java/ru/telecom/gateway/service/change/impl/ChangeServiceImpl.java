package ru.telecom.gateway.service.change.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.change.dto.req.ChangeSubscriberServiceStatusReq;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.change.ChangeService;
import ru.telecom.gateway.xml.tariff.ChangeStatusRequest;
import ru.telecom.gateway.xml.tariff.ChangeSubsServStatus;
import ru.telecom.gateway.xml.tariff.ChangeSubsServStatusResponse;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChangeServiceImpl implements ChangeService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;

    @Override
    public BaseRes changeSubscriberServiceStatus(ChangeSubscriberServiceStatusReq req) {
        BaseRes res = new BaseRes();
        ChangeSubsServStatus input = new ChangeSubsServStatus();
        ChangeStatusRequest request = new ChangeStatusRequest();
        request.setMsisdn(req.getMsisdn());
        request.setServiceId(req.getServiceId());
        request.setServiceStatus(req.getServiceStatus());
        if (req.getChargeOrder() != null)
            request.setChargeOrder(req.getChargeOrder());
        if (req.getTargetDate() != null)
            request.setTargetDate(dateBuilder.convertDate(req.getTargetDate()));
        input.setChangeStatusRequest(request);
        ChangeSubsServStatusResponse output = soapAPIGate.changeSubscriberServiceStatus(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException("ERROR", HttpStatus.BAD_REQUEST, "Ошибка выполнения внешней операции", "Получен запрос changeSubscriberService(Ошибка при изменении статуса услуги абонента updateSubscriberService - SQLException(message=err_service_is_not_allowed,code=-109);");
        res.setResult(new ResultDto(output.getReturn().getCode(), output.getReturn().getMessageUser()));
        return res;
    }

}
