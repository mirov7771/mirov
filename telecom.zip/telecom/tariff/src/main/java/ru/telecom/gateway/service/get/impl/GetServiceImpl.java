package ru.telecom.gateway.service.get.impl;

import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.GetTariffPlansReq;
import ru.telecom.gateway.controller.get.dto.res.GetTariffPlansRes;
import ru.telecom.gateway.controller.get.dto.res.GetTariffPlansRes.Tariff;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.xml.tariff.*;

import static ru.telecom.gateway.constant.Constants.Params.STUB_GTP;
import static ru.telecom.gateway.constant.Constants.Params.Y;

@Service
@RequiredArgsConstructor
@Slf4j
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;

    @Override
    public GetTariffPlansRes getTariffPlans(GetTariffPlansReq req) {
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(STUB_GTP, mappingConfig.getSystemCode());
        log.info("Check if stub is On");
        if (param.isPresent() && Y.equals(param.get().getValue())){
            log.info("Stub Error On");
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения запроса", null);
        }

        log.info("Stub is Off");
        GetTariffPlans soapReq = new GetTariffPlans();
        TariffParams tariffParams = new TariffParams();
        if (req.getBranchId() != null)
            tariffParams.setBranchId(req.getBranchId());

        if (StringUtils.hasText(req.getChannel()))
            tariffParams.setChannel(req.getChannel());

        if (!CollectionUtils.isEmpty(req.getEntries())){
            TariffParams.AddParams params = new TariffParams.AddParams();
            params.getEntries().addAll(req.getEntries().stream().map(i -> {
                TariffParams.AddParams.Entry entry = new TariffParams.AddParams.Entry();
                entry.setKey(i.getParamName());
                entry.setValue(i.getParamValue());
                return entry;
            }).collect(Collectors.toList()));
            tariffParams.setAddParams(params);
        }
        soapReq.setTariffParams(tariffParams);
        GetTariffPlansResponse soapRes = soapAPIGate.getTariffPlans(soapReq);
        if (soapRes == null || soapRes.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения запроса", null);

        GetTariffPlansRes res = new GetTariffPlansRes();
        TariffPlanData soapResReturn = soapRes.getReturn();
        Result result = soapResReturn.getResult();
        res.setResult(new ResultDto(result.getCode(), result.getMessageUser()));
        res.setTariff(soapResReturn.getTarifves().stream().map(Tariff::new).collect(Collectors.toList()));
        return res;
    }
}
