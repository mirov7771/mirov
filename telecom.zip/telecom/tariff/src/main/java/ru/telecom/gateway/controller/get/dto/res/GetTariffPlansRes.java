package ru.telecom.gateway.controller.get.dto.res;

import static ru.telecom.gateway.constant.Constants.Keys.ECOSYSTEM;
import static ru.telecom.gateway.constant.Constants.Keys.ONLY_HOME_REG;
import static ru.telecom.gateway.constant.Constants.Keys.TRANSFER_RESTS;
import static ru.telecom.gateway.constant.Constants.Keys.USERGRP_CODE;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.get.dto.support.Bonus;
import ru.telecom.gateway.controller.get.dto.support.Provider;
import ru.telecom.gateway.controller.get.dto.support.Traffic;
import ru.telecom.gateway.xml.tariff.TariffPlan;

@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetTariffPlansRes extends BaseRes {
    @ArraySchema(minItems = 0, maxItems = 2048, schema = @Schema(implementation = Tariff.class))
    private List<Tariff> tariff;

    @Schema(description = "Тарифный план", example = "{\n"
            + "      \"clientTariffType\": \"B2C\",\n"
            + "      \"firstMonth\": 250,\n"
            + "      \"ratePlanId\": 37,\n"
            + "      \"serviceId\": 1865,\n"
            + "      \"regionType\": \"FULL\",\n"
            + "      \"serviceName\": \"То что нужно. Стартовый\",\n"
            + "      \"rating\": 0,\n"
            + "      \"nextMonth\": 250,\n"
            + "      \"bonus\": {\n"
            + "        \"bonusPercent\": 1,\n"
            + "        \"promoText\": \"Возврат до 1% СПАСИБО\"\n"
            + "      },\n"
            + "      \"messengers\": {\n"
            + "        \"provider\": [\n"
            + "          \"Facebook Messenger\",\n"
            + "          \"Viber\",\n"
            + "          \"WhatsApp\",\n"
            + "          \"Skype\",\n"
            + "          \"Telegram\"\n"
            + "        ]\n"
            + "      },\n"
            + "      \"traffic\": {\n"
            + "        \"voice\": {\n"
            + "          \"measure\": 250,\n"
            + "          \"quantity\": \"MINUTES\"\n"
            + "        }\n"
            + "      },\n"
            + "      \"transferRests\": \"N\",\n"
            + "      \"ecoSystem\": \"N\",\n"
            + "      \"onlyHomeReq\": \"FALSE\"\n"
            + "    }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Tariff {
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "B2C", description = "Тип клиента для этого тарифного плана", nullable = true)
        private String clientTariffType;
        @Schema(minimum = "0", maximum = "100000000000", example = "250", description = "Стоимость подключения", nullable = true)
        private BigDecimal firstMonth;
        @Schema(minimum = "0", maximum = "100000000000", example = "37", description = "Id тарифного плана-подложки", nullable = true)
        private BigDecimal ratePlanId;
        @Schema(minimum = "0", maximum = "100000000000", example = "1865", description = "Id тарифного плана (услуги)", nullable = true)
        private BigDecimal serviceId;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "FULL", description = "Признак типа региона для тарифного плана", nullable = true)
        private String regionType;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "То что нужно. Стартовый", description = "Наименование тарифного плана (услуги)", nullable = true)
        private String serviceName;
        @Schema(minimum = "0", maximum = "1000", example = "0", description = "Рейтинг тарифного плана", nullable = true)
        private BigDecimal rating;
        @Schema(minimum = "0", maximum = "100000000000", example = "250", description = "Стоимость продления на следующий период", nullable = true)
        private BigDecimal nextMonth;
        private Bonus bonus;
        @Schema(implementation = Provider.class, description = "Мессенджеры", example = "{\n"
                + "        \"provider\": [\n"
                + "          \"Facebook Messenger\",\n"
                + "          \"Viber\",\n"
                + "          \"WhatsApp\",\n"
                + "          \"Skype\",\n"
                + "          \"Telegram\"\n"
                + "        ]\n"
                + "      }", nullable = true)
        private Provider messengers;
        @Schema(implementation = Provider.class, description = "Музыка", nullable = true)
        private Provider music;
        @Schema(implementation = Provider.class, description = "Социальные сети", nullable = true)
        private Provider social;
        @Schema(implementation = Provider.class, description = "Видео", nullable = true)
        private Provider video;
        @Schema(implementation = Traffic.class, description = "Тип трафика и его объемы входящие в тариф", nullable = true)
        private Traffic traffic;
        @Schema(maxLength = 520, pattern = "^(.*){520}$", nullable = true, example = "123", description = "USE_GRP_CODE")
        private String useGrpCode;
        @Schema(maxLength = 520, pattern = "^(.*){520}$", example = "N", nullable = true, description = "TRANSFER_RESTS")
        private String transferRests;
        @Schema(maxLength = 520, pattern = "^(.*){520}$", example = "N", nullable = true, description = "ECO_SYSTEM")
        private String ecoSystem;
        @Schema(maxLength = 520, pattern = "^(.*){520}$", example = "FALSE", nullable = true, description = "ONLY_HOME_REQ")
        private String onlyHomeReq;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "LINE0920", nullable = true, description = "Признак ТП")
        private String tariffType;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "MAP_SBOL", nullable = true, description = "Канал обслуживания MAP_SBOL, AS_FS и т.п.")
        private String channel;
        @Schema(maxLength = 255, pattern = "^(.*){255}$", example = "LINE0920", nullable = true, description = "Промо-текст")
        private String notes;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "MIN", nullable = true, description = "Много-Средне-Мало Минут")
        private String scaleMinutes;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "AVG", nullable = true, description = "Много-Средне-Мало Данных")
        private String scaleData;
        @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "MAX", nullable = true, description = "Много-Средне-Мало SMS")
        private String scaleSms;

        public Tariff(TariffPlan plan) {
            this.clientTariffType = plan.getClientTariffType();
            this.firstMonth = plan.getFirstMonth();
            this.ratePlanId = plan.getRatePlanId();
            this.serviceId = plan.getServiceId();
            this.regionType = plan.getRegionType();
            this.serviceName = plan.getServiceName();
            this.rating = plan.getRating();
            this.nextMonth = plan.getNextMonth();
            this.tariffType = plan.getTariffType();
            this.channel = plan.getChannel();
            if (StringUtils.hasText(plan.getNotes()))
                this.notes = plan.getNotes().substring(0, Math.min(plan.getNotes().length(), 255));
            this.scaleMinutes = plan.getScaleMinutes();
            this.scaleData = plan.getScaleData();
            this.scaleSms = plan.getScaleSms();
            if (plan.getBonus() != null) {
                this.bonus = new Bonus(plan.getBonus());
            }
            if (plan.getMessengers() != null) {
                this.messengers = new Provider(plan.getMessengers().getProviders());
            }
            if (plan.getMusic() != null) {
                this.music = new Provider(plan.getMusic().getProviders());
            }
            if (plan.getSocial() != null) {
                this.social = new Provider(plan.getSocial().getProviders());
            }
            if (plan.getVideo() != null) {
                this.video = new Provider(plan.getVideo().getProviders());
            }
            if (plan.getTraffic() != null) {
                this.traffic = new Traffic(plan.getTraffic());
            }
            if (plan.getAddParams() != null
                    && !CollectionUtils.isEmpty(plan.getAddParams().getEntries())) {
                for(TariffPlan.AddParams.Entry entry : plan.getAddParams().getEntries()){
                    if (ONLY_HOME_REG.equals(entry.getKey())){
                        this.onlyHomeReq = entry.getValue();
                    }
                    if (USERGRP_CODE.equals(entry.getKey())){
                        this.useGrpCode = entry.getValue();
                    }
                    if (TRANSFER_RESTS.equals(entry.getKey())){
                        this.transferRests = entry.getValue();
                    }
                    if (ECOSYSTEM.equals(entry.getKey())){
                        this.ecoSystem = entry.getValue();
                    }
                }
            }
        }
    }
}
