package ru.telecom.gateway.gate;

import ru.telecom.gateway.xml.tariff.ChangeSubsServStatus;
import ru.telecom.gateway.xml.tariff.ChangeSubsServStatusResponse;
import ru.telecom.gateway.xml.tariff.GetTariffPlans;
import ru.telecom.gateway.xml.tariff.GetTariffPlansResponse;

public interface SoapAPIGate {
    default GetTariffPlansResponse getTariffPlans(GetTariffPlans req) {
        return null;
    }
    default ChangeSubsServStatusResponse changeSubscriberServiceStatus(ChangeSubsServStatus req) {
        return null;
    }
}
