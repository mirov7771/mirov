package ru.telecom.gateway.database.model;

import lombok.Getter;
import lombok.Setter;
import ru.telecom.gateway.database.pk.OstSystemParamPk;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "OS_T_SYSTEM_PARAM")
@Getter
@Setter
@IdClass(OstSystemParamPk.class)
public class OstSystemParam implements Serializable {


    private static final long serialVersionUID = -3803769546922859609L;

    @Id
    @Column(name = "CODE")
    private String code;
    @Id
    @Column(name = "OUTSYSTEM_CODE")
    private String outSystemCode;
    @Column(name = "VALUE")
    private String value;

}
