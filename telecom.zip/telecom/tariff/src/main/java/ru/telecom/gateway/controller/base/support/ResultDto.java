package ru.telecom.gateway.controller.base.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.exception.TelecomException;

@Schema(description = "структура объекта",
        example = "{\n" +
                "    \"code\": \"OK\",\n" +
                "    \"messageUser\": \"Выполнено успешно\"\n" +
                "}")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
public class ResultDto {

    @Schema(maxLength = 520, example = "OK", pattern = "^(.*){520}$", description = "Символьный код результата обработки запроса")
    private String code;
    @Schema(maxLength = 520, example = "OK", pattern = "^(.*){520}$", description = "Текст с информацией об отработке запроса")
    private String messageUser;
    @Schema(maxLength = 520, example = "OK", pattern = "^(.*){520}$", description = "Детальное описание ответа")
    private String description;
    @Schema(maxLength = 520, example = "OK", pattern = "^(.*){520}$", description = "Система вернувшая ответ")
    private String messageSystem;

    public ResultDto(String code, String messageUser)
    {
        if (!Constants.OK.equalsIgnoreCase(code))
            throw new TelecomException(code, HttpStatus.BAD_REQUEST, messageUser, null);
        this.code = code;
        this.messageUser = prepareString(messageUser);
    }

    public ResultDto(String code, String messageUser, String description)
    {
        this.code = code;
        this.messageUser = prepareString(messageUser);
        this.description = prepareString(description);
    }

    private String prepareString(String value){
        if (StringUtils.hasText(value) && value.length() > 250){
            return value.substring(0, 249);
        }
        return value;
    }

}
