package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Data;
import ru.telecom.gateway.controller.base.support.Entry;

@Data
@Schema(description = "Структура запроса", example = "{\n"
        + "  \"branchId\": \"2\",\n"
        + "  \"channel\": \"AS_FS\"\n"
        + "}")
public class GetTariffPlansReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "965", description = "Id Филиала")
    private BigDecimal branchId;
    @NotNull
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "AS_FS", description = "Канал")
    private String channel;
    @ArraySchema(maxItems = 128, minItems = 0, schema = @Schema(implementation = Entry.class))
    private List<Entry> entries;
}
