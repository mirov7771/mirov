package ru.telecom.gateway.service.change;

import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.change.dto.req.ChangeSubscriberServiceStatusReq;
import ru.telecom.gateway.service.Service;

public interface ChangeService extends Service {
    BaseRes changeSubscriberServiceStatus(ChangeSubscriberServiceStatusReq req);
}
