package ru.telecom.gateway.constant;

import java.util.List;

public class Constants {

    public static final String SUB_MOCK = "SBOL_PRO_SBER_API_TEST_MOCKSANEK";

    public static final String OK = "OK";
    public static final String ERROR = "ERROR";
    public static final String MISSING_REQUIRED_PARAMS = "Ошибка запроса.: Не переданы обязательные параметры";
    public static final String SERVICE_NOT_AVAILABLE = "Ошибка сервиса.: Сервис временно недоступен";
    public static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    public static class Headers {
        public static final String RQ_UID = "RqUID";
        public static final String RQ_TM = "RqTm";
            public static final String SUBSYSTEM_CODE = "SubsystemCode";
    }

    public static class Keys {
        public static final String ONLY_HOME_REG = "ONLY_HOME_REG";
        public static final String USERGRP_CODE = "USERGRP_CODE";
        public static final String TRANSFER_RESTS = "TRANSFER_RESTS";
        public static final String ECOSYSTEM = "ECOSYSTEM";
    }

    public static class Params {
        public static final String STUB_GTP = "STUB_GTP";
        public static final String Y = "Y";
    }

}
