###Proxy Сервис для методов из TariffServicesPortBinding

- SOAP: GetTariffPlans --> REST: /sbermobile/api/v1/getTariffPlans
- SOAP: changeSubsServStatus --> REST: /sbermobile/api/v1/changeSubscriberServiceStatus

####Properties
- application.telecom.url - урл вэб-сервиса (soap)
- application.telecom.service - название эндпоинта вэб-сервиса (soap)
- application.telecom.timeout -  время ожидания ответа от вэб-сервиса (soap)
- application.telecom.system -  очередь