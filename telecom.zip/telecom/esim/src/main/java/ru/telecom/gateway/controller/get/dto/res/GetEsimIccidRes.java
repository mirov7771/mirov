package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.Entry;

@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Получить и зарезервировать свободный ICCID для eSIM")
public class GetEsimIccidRes extends BaseRes {

    private EsimIccid esimIccid;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @Schema(description = "",example = "{\n"
            + "    \"iccId\": \"89701501077122810418\"\n"
            + "  }")
    public static class EsimIccid {
        @Schema(maxLength = 20, pattern = "^(.*){20}$", example = "89701501077122808008", description = "Открытый номер SIM-карты")
        private String iccId;
        @ArraySchema(maxItems = 128, minItems = 0, schema = @Schema(implementation = Entry.class))
        private List<Entry> entries;
    }
}
