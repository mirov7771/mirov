package ru.telecom.gateway.controller.reserve.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "Возврат зарезервированного ICCID в пул доступных номеров", example = "{\n"
        + "  \"channel\": \"MAP_SBOL_ESIM\",\n"
        + "  \"iccId\": \"89701501077122808008\"\n"
        + "}")
public class ReserveEsimIccidReturnReq {
    @NotNull
    @Schema(maxLength = 20, pattern = "^(.*){20}$", example = "89701501077122808008", description = "Открытый номер SIM-карты")
    private String iccId;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "MAP_SBOL_ESIM", description = "Код канала продаж")
    private String channel;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "active", description = "FINAL_PROFILE_STATUS")
    private String finalProfileStatus;
}
