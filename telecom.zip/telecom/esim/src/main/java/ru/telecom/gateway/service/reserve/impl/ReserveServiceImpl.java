package ru.telecom.gateway.service.reserve.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveEsimIccidReturnReq;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.reserve.ReserveService;
import ru.telecom.gateway.xml.esim.ReserveEsimIccidReturn;
import ru.telecom.gateway.xml.esim.ReserveEsimIccidReturnParams;
import ru.telecom.gateway.xml.esim.ReserveEsimIccidReturnResponse;
import ru.telecom.gateway.xml.esim.Result;

import java.util.Optional;

import static ru.telecom.gateway.constant.Constants.Keys.FINAL_PROFILE_STATUS;
import static ru.telecom.gateway.constant.Constants.Params.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReserveServiceImpl implements ReserveService {

    private final SoapAPIGate soapAPIGate;
    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;

    @Override
    public BaseRes reserveEsimIccidReturn(ReserveEsimIccidReturnReq req) {
        log.info("Check if stub is On");
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(STUB_RESIMR, mappingConfig.getSystemCode());
        if (param.isPresent() && Y.equalsIgnoreCase(param.get().getValue())){
            log.info("Stub Error On");
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения операции", null);
        }

        log.info("Stub is Off");
        ReserveEsimIccidReturn soapReq = new ReserveEsimIccidReturn();
        ReserveEsimIccidReturnParams params = new ReserveEsimIccidReturnParams();
        if (StringUtils.hasText(req.getChannel())) {
            params.setChannel(req.getChannel());
        }
        if (StringUtils.hasText(req.getIccId())) {
            params.setIccId(req.getIccId());
        }
        if (StringUtils.hasText(req.getFinalProfileStatus())){
            ReserveEsimIccidReturnParams.AddParams addParams = new ReserveEsimIccidReturnParams.AddParams();
            ReserveEsimIccidReturnParams.AddParams.Entry entry = new ReserveEsimIccidReturnParams.AddParams.Entry();
            entry.setKey(FINAL_PROFILE_STATUS);
            entry.setValue(req.getFinalProfileStatus());
            addParams.getEntries().add(entry);
            params.setAddParams(addParams);
        }
        soapReq.setReserveEsimIccidReturnParams(params);
        ReserveEsimIccidReturnResponse reserveEsimIccidReturnResponse = soapAPIGate.reserveEsimIccid(
                soapReq);
        if (reserveEsimIccidReturnResponse == null || reserveEsimIccidReturnResponse.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Ошибка выполнения операции", null);

        Result result = reserveEsimIccidReturnResponse.getReturn();
        BaseRes res = new BaseRes();
        res.setResult(new ResultDto(
                result.getCode(), result.getMessageUser()));
        return res;
    }

}