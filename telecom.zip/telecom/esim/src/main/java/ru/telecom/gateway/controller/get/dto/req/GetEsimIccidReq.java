package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Data;
import ru.telecom.gateway.controller.base.support.Entry;

@Schema(description = "Получить и зарезервировать свободный ICCID для eSIM", example = "{\n"
        + "  \"branchId\": \"0\",\n"
        + "  \"channel\": \"MAP_SBOL_ESIM\"\n"
        + "}")
@Data
public class GetEsimIccidReq {
    @NotNull
    @Schema(minimum = "0", maximum = "100000000000", example = "0", description = "Id Филиала")
    private BigDecimal branchId;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "MAP_SBOL_ESIM", description = "Канал")
    private String channel;
    @ArraySchema(maxItems = 128, minItems = 0, schema = @Schema(implementation = Entry.class))
    private List<Entry> entries;
}
