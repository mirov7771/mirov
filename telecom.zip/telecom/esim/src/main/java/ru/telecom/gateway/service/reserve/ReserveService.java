package ru.telecom.gateway.service.reserve;

import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.reserve.dto.req.ReserveEsimIccidReturnReq;
import ru.telecom.gateway.service.Service;

public interface ReserveService extends Service {

    BaseRes reserveEsimIccidReturn(ReserveEsimIccidReturnReq req);

}
