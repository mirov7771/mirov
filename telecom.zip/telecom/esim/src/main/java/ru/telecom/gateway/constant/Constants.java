package ru.telecom.gateway.constant;

public class Constants {

    public static final String OK = "OK";
    public static final String ERROR = "ERROR";
    public static final String WARN = "WARN";
    public static final String MISSING_REQUIRED_PARAMS = "Ошибка запроса.: Не переданы обязательные параметры";
    public static final String SERVICE_NOT_AVAILABLE = "Ошибка сервиса.: Сервис временно недоступен";
    public static final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";
    public static final String SUCCESS_MESSAGE = "Операция выполнена успешно";
    public static final String GET_ESIM_ERROR = "Ошибка определения SUBSCRIBER_ID";

    public static class Headers {
        public static final String RQ_UID = "RqUID";
        public static final String RQ_TM = "RqTm";
            public static final String SUBSYSTEM_CODE = "SubsystemCode";
    }

    public static class Keys {
        public static final String PROFILE_STATUS = "PROFILE_STATUS";
        public static final String SMDP_ADDRESS = "SMDP_ADDRESS";
        public static final String SUBPRIME = "SUBPRIME";
        public static final String PROMOCODE = "PROMOCODE";
        public static final String SERVID = "SERVID";
        public static final String FINAL_PROFILE_STATUS = "FINAL_PROFILE_STATUS";
    }

    public static class Params {
        public static final String STUB_GEID = "STUB_GEID";
        public static final String STUB_GEP = "STUB_GEP";
        public static final String STUB_RESIMR = "STUB_RESIMR";
        public static final String STUB_GESIM = "STUB_GESIM";
        public static final String Y = "Y";
        public static final String N = "N";
    }

}
