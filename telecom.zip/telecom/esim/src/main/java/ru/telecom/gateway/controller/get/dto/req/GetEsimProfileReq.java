package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.Data;
import ru.telecom.gateway.controller.base.support.Entry;

@Data
@Schema(description = "Получить информацию (\"matching ID\"\\\"ссылку\") для установки пользователю\n"
        + "        eSIM", example = "{\n"
        + "  \"channel\": \"MAP_SBOL_ESIM\",\n"
        + "  \"iccId\": \"89701501077122808008\"\n"
        + "}")
public class GetEsimProfileReq {
    @NotNull
    @Schema(maxLength = 20, pattern = "^(.*){20}$", example = "89701501077122808008", description = "Открытый номер SIM-карты")
    private String iccId;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "AS_FS", description = "Код канала продаж")
    private String channel;
    @ArraySchema(maxItems = 128, minItems = 0, schema = @Schema(implementation = Entry.class))
    private List<Entry> entries;
}
