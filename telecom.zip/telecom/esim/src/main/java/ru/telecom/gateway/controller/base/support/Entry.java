package ru.telecom.gateway.controller.base.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Schema(description = "Структура запроса", example = "{\n"
        + "  \"paramName\": \"ONLY_HOME_REG\",\n"
        + "  \"paramValue\": \"FALSE\"\n"
        + "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Entry {
    @Schema(maxLength = 32, example = "ONLY_HOME_REG", pattern = "^(.*){32}$", description = "Название параметра")
    private String paramName;
    @Schema(maxLength = 250, example = "FALSE", pattern = "^(.*){250}$", description = "Значние параметра")
    private String paramValue;
}
