package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.controller.base.support.Entry;

import java.util.List;

@Schema(description = "Структура запроса", example = "{\n"
        + "  \"msisdn\": \"9645173535\",\n"
        + "  \"sberId\": \"f585931476ef8186897400e4846e8df529c8eb52fa3ca293c56dd3767ec785d2fce554cc208a0dcf\",\n"
        + "  \"channel\": \"MAP_SBOL_ESIM\",\n"
        + "  \"iccId\": \"89701501077122808008\"\n"
        + "}")
@Data
public class GetEsimReq {
    @Schema(maxLength = 20, pattern = "^(.*){20}$", example = "89701501077122808008", description = "Открытый номер SIM-карты")
    private String iccId;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1356", description = "Идентификатор клиента банка")
    private String sberId;
    @Schema(maxLength = 32, pattern = "^(.*){32}$", example = "MAP_SBOL_ESIM", description = "Канал")
    private String channel;
    @ArraySchema(maxItems = 128, minItems = 0, schema = @Schema(implementation = Entry.class))
    private List<Entry> entries;
}
