package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
@Schema(description = "Информация (\"matching ID\"\\\"ссылку\") для установки пользователю eSIM")
public class GetEsimProfileRes extends BaseRes {

    private EsimProfile esimProfile;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @Schema(example = "{\n"
            + "    \"matchingId\": \"5E-1GGJKI-1A87MWZ\",\n"
            + "    \"profileStatus\": \"Released\",\n"
            + "    \"smdpAddress\": \"rsp.truphone.com\"\n"
            + "  }")
    public static class EsimProfile {
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "5E-1GGJKI-1A87MWZ", description = "Ссылка для дальнейшей установки пользователю eSIM")
        private String matchingId;
        @Schema(maxLength = 250, example = "Released", pattern = "^(.*){250}$", description = "PROFILE_STATUS")
        private String profileStatus;
        @Schema(maxLength = 250, example = "rsp.truphone.com", pattern = "^(.*){250}$", description = "SMDP_ADDRESS")
        private String smdpAddress;
    }
}
