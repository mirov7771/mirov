package ru.telecom.gateway.gate.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.telecom.gateway.config.WsHttpHeaderCallback;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.xml.esim.*;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.telecom.service}")
    private String serviceUrl;

    @Override
    public GetEsimIccidResponse getEsimIccid(GetEsimIccid req) {
        return (GetEsimIccidResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req, new WsHttpHeaderCallback());
    }

    @Override
    public GetEsimProfileResponse getEsimProfile(GetEsimProfile req) {
        return (GetEsimProfileResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req, new WsHttpHeaderCallback());
    }

    @Override
    public ReserveEsimIccidReturnResponse reserveEsimIccid(ReserveEsimIccidReturn req) {
        return (ReserveEsimIccidReturnResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req, new WsHttpHeaderCallback());
    }

    @Override
    public GetEsimResponse getEsim(GetEsim req) {
        return (GetEsimResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req, new WsHttpHeaderCallback());
    }
}
