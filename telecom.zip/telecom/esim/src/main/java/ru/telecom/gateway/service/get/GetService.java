package ru.telecom.gateway.service.get;

import ru.telecom.gateway.controller.get.dto.req.GetEsimIccidReq;
import ru.telecom.gateway.controller.get.dto.req.GetEsimProfileReq;
import ru.telecom.gateway.controller.get.dto.req.GetEsimReq;
import ru.telecom.gateway.controller.get.dto.res.GetEsimIccidRes;
import ru.telecom.gateway.controller.get.dto.res.GetEsimProfileRes;
import ru.telecom.gateway.controller.get.dto.res.GetEsimRes;
import ru.telecom.gateway.service.Service;

public interface GetService extends Service {
    GetEsimIccidRes getEsimIccid(GetEsimIccidReq req);
    GetEsimProfileRes getEsimProfile(GetEsimProfileReq req);
    GetEsimRes getEsim(GetEsimReq req);
}
