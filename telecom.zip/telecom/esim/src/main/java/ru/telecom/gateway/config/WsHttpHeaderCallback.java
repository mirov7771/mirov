package ru.telecom.gateway.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import javax.xml.namespace.QName;
import javax.xml.soap.*;
import javax.xml.transform.TransformerException;
import java.io.IOException;

import static ru.telecom.gateway.constant.Constants.Headers.*;

@Slf4j
public class WsHttpHeaderCallback implements WebServiceMessageCallback {

    @Override
    public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
        try {
            SaajSoapMessage saajSoapMessage = (SaajSoapMessage) message;
            SOAPMessage soapMessage = saajSoapMessage.getSaajMessage();
            SOAPPart soapPart = soapMessage.getSOAPPart();
            SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
            SOAPHeader soapHeader = soapEnvelope.getHeader();
            SOAPElement rqUidElement = soapHeader.addChildElement(new QName("http://www.sberbank-tele.com/soap/services/", RQ_UID));
            rqUidElement.addTextNode(ThreadContext.get(RQ_UID));
            SOAPElement rqTmElement = soapHeader.addChildElement(new QName("http://www.sberbank-tele.com/soap/services/", RQ_TM));
            rqTmElement.addTextNode(ThreadContext.get(RQ_TM));
            SOAPElement scElement = soapHeader.addChildElement(new QName("http://www.sberbank-tele.com/soap/services/", SUBSYSTEM_CODE));
            scElement.addTextNode(ThreadContext.get(SUBSYSTEM_CODE));
            soapMessage.saveChanges();
        } catch (SOAPException e){
            log.error("SOAPException ", e);
        }
    }

}
