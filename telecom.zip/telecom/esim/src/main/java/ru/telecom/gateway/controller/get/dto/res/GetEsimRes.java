package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.Entry;

import java.util.List;

@Schema(description = "Структура ответа",
        example = "{\n" +
                "    \"esim\": [{\n" +
                "        \"entries\": [\n" +
                "            {\n" +
                "                \"key\": \"SMDP_ADDRESS\",\n" +
                "                \"value\": \"rsp.truphone.com\"\n" +
                "            },\n" +
                "            {\n" +
                "                \"key\": \"PROFILE_STATUS\",\n" +
                "                \"value\": \"Released\"\n" +
                "            }\n" +
                "        ],\n" +
                "        \"matchingId\": \"5E-K43SN-1P9SY7N\"\n" +
                "    }],\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                "    }\n" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetEsimRes extends BaseRes {
    @ArraySchema(maxItems = 10000, minItems = 0, schema = @Schema(implementation = Esim.class))
    private List<Esim> esim;

    @Schema(description = "Структура объекта",
            example = "{\n" +
            "        \"entries\": [\n" +
            "            {\n" +
            "                \"key\": \"SMDP_ADDRESS\",\n" +
            "                \"value\": \"rsp.truphone.com\"\n" +
            "            },\n" +
            "            {\n" +
            "                \"key\": \"PROFILE_STATUS\",\n" +
            "                \"value\": \"Released\"\n" +
            "            }\n" +
            "        ],\n" +
            "        \"matchingId\": \"5E-K43SN-1P9SY7N\"\n" +
            "    }")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Esim {
        @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "5E-K391H-1VKPD2T", description = "Ссылка для дальнейшей установки пользователю eSIM")
        private String matchingId;
        @ArraySchema(maxItems = 128, minItems = 0, schema = @Schema(implementation = Entry.class))
        private List<Entry> entries;
    }
}
