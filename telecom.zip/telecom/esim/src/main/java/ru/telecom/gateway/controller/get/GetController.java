package ru.telecom.gateway.controller.get;

import static ru.telecom.gateway.constant.Constants.APPLICATION_JSON_VALUE;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.base.support.SberApiError;
import ru.telecom.gateway.controller.get.dto.req.GetEsimIccidReq;
import ru.telecom.gateway.controller.get.dto.req.GetEsimProfileReq;
import ru.telecom.gateway.controller.get.dto.req.GetEsimReq;
import ru.telecom.gateway.controller.get.dto.res.GetEsimIccidRes;
import ru.telecom.gateway.controller.get.dto.res.GetEsimProfileRes;
import ru.telecom.gateway.controller.get.dto.res.GetEsimRes;
import ru.telecom.gateway.service.get.GetService;

import javax.validation.Valid;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Tag(name = "Get Methods")
public class GetController {

    private final GetService service;

    @Operation(summary = "Метод получения профиля SIM-карты", description = "Получение профиля и резервирование SIM-карты в АСР Беркут, получение профиля и резервирование eSIM-карты в Truphone", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetEsimIccidRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"esimIccid\": {\n" +
                                    "        \"iccId\": \"89701501078000004280\"\n" +
                                    "    },\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetEsimIccidReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branchId\": \"965\",\n" +
                                    "    \"channel\": \"MAP_SBOL_ESIM\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getEsimIccid", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetEsimIccidRes> getEsimIccid(@Valid @RequestBody GetEsimIccidReq req) {
        return ResponseBuilder.build(service.getEsimIccid(req));
    }

    @Operation(summary = "Метод получения информации для установки eSIM", description = "Получить информацию (\"matching ID\"\\\"ссылку\") для установки пользователю eSIM", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetEsimProfileRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"esimProfile\": {\n" +
                                    "        \"entry\": [\n" +
                                    "            {\n" +
                                    "                \"key\": \"SMDP_ADDRESS\",\n" +
                                    "                \"value\": \"rsp.truphone.com\"\n" +
                                    "            },\n" +
                                    "            {\n" +
                                    "                \"key\": \"PROFILE_STATUS\",\n" +
                                    "                \"value\": \"Released\"\n" +
                                    "            }\n" +
                                    "        ],\n" +
                                    "        \"matchingId\": \"5E-K43SN-1P9SY7N\"\n" +
                                    "    },\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetEsimProfileReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"iccId\": \"89701501078000004280\",\n" +
                                    "    \"channel\": \"MAP_SBOL_ESIM\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getEsimProfile", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetEsimProfileRes> getEsimProfile(@Valid @RequestBody GetEsimProfileReq req) {
        return ResponseBuilder.build(service.getEsimProfile(req));
    }


    @Operation(summary = "Метод получения актуального статуса SIM", description = "Возвращается актуальный статус SIM из АСР Беркут и eSIM с платформы Truphone (по одной\\нескольким eSIM абонента).", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetEsimRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"esim\": [{\n" +
                                    "        \"entries\": [\n" +
                                    "            {\n" +
                                    "                \"key\": \"SMDP_ADDRESS\",\n" +
                                    "                \"value\": \"rsp.truphone.com\"\n" +
                                    "            },\n" +
                                    "            {\n" +
                                    "                \"key\": \"PROFILE_STATUS\",\n" +
                                    "                \"value\": \"Released\"\n" +
                                    "            }\n" +
                                    "        ],\n" +
                                    "        \"matchingId\": \"5E-K43SN-1P9SY7N\"\n" +
                                    "    }],\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetEsimReq.class),
                            examples = @ExampleObject(value = "{\n"
                                    + "  \"msisdn\": \"9645173535\",\n"
                                    + "  \"sberId\": \"f585931476ef8186897400e4846e8df529c8eb52fa3ca293c56dd3767ec785d2fce554cc208a0dcf\",\n"
                                    + "  \"channel\": \"MAP_SBOL_ESIM\",\n"
                                    + "  \"iccId\": \"89701501077122808008\"\n"
                                    + "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getEsim", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetEsimRes> getEsim(@Valid @RequestBody GetEsimReq req) {
        return ResponseBuilder.build(service.getEsim(req));
    }

}
