package ru.telecom.gateway.gate;

import ru.telecom.gateway.xml.esim.*;

public interface SoapAPIGate {

    default GetEsimIccidResponse getEsimIccid(GetEsimIccid req) {
        return null;
    }
    default GetEsimProfileResponse getEsimProfile(GetEsimProfile req) {
        return null;
    }
    default ReserveEsimIccidReturnResponse reserveEsimIccid(ReserveEsimIccidReturn req) {
        return null;
    }
    default GetEsimResponse getEsim(GetEsim req) {
        return null;
    }

}
