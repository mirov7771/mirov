package ru.telecom.gateway.service.get.impl;

import static ru.telecom.gateway.constant.Constants.GET_ESIM_ERROR;
import static ru.telecom.gateway.constant.Constants.Keys.PROFILE_STATUS;
import static ru.telecom.gateway.constant.Constants.Keys.SMDP_ADDRESS;
import static ru.telecom.gateway.constant.Constants.Params.*;
import static ru.telecom.gateway.constant.Constants.WARN;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.Entry;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.GetEsimIccidReq;
import ru.telecom.gateway.controller.get.dto.req.GetEsimProfileReq;
import ru.telecom.gateway.controller.get.dto.req.GetEsimReq;
import ru.telecom.gateway.controller.get.dto.res.GetEsimIccidRes;
import ru.telecom.gateway.controller.get.dto.res.GetEsimProfileRes;
import ru.telecom.gateway.controller.get.dto.res.GetEsimRes;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.xml.esim.*;

@Service
@RequiredArgsConstructor
@Slf4j
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;

    @Override
    public GetEsimIccidRes getEsimIccid(GetEsimIccidReq req) {
        log.info("Check if stub is On");
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(STUB_GEID, mappingConfig.getSystemCode());
        if (param.isPresent() && Y.equalsIgnoreCase(param.get().getValue())) {
            log.info("Stub Error On");
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Нет доступных esimIccid", null);
        }

        log.info("Stub is Off");
        GetEsimIccidRes res = new GetEsimIccidRes();
        GetEsimIccid input = new GetEsimIccid();
        EsimIccidParams params = new EsimIccidParams();
        params.setBranchId(req.getBranchId());
        if (StringUtils.hasText(req.getChannel()))
            params.setChannel(req.getChannel());
        if (!CollectionUtils.isEmpty(req.getEntries())){
            EsimIccidParams.AddParams addParams = new EsimIccidParams.AddParams();
            for(Entry entry : req.getEntries()){
                EsimIccidParams.AddParams.Entry e = new EsimIccidParams.AddParams.Entry();
                e.setKey(entry.getParamName());
                e.setValue(entry.getParamValue());
                addParams.getEntries().add(e);
            }
            params.setAddParams(addParams);
        }
        input.setEsimIccidParams(params);
        GetEsimIccidResponse output = soapAPIGate.getEsimIccid(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Нет доступных esimIccid", null);

        EsimIccidData returnData = output.getReturn();
        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        if (returnData.getEsimIccid() != null) {
            GetEsimIccidRes.EsimIccid esimIccid = new GetEsimIccidRes.EsimIccid();
            esimIccid.setIccId(returnData.getEsimIccid().getIccId());
            if (returnData.getEsimIccid().getAddParams() != null
                    && !CollectionUtils.isEmpty(returnData.getEsimIccid().getAddParams().getEntries())){
                List<Entry> entries = new ArrayList<>();
                for(EsimIccid.AddParams.Entry addParams : returnData.getEsimIccid().getAddParams().getEntries()){
                    Entry ent = new Entry();
                    ent.setParamValue(addParams.getValue());
                    ent.setParamName(addParams.getKey());
                    entries.add(ent);
                }
                esimIccid.setEntries(entries);
            }
            res.setEsimIccid(esimIccid);
        }
        return res;
    }

    @Override
    public GetEsimProfileRes getEsimProfile(GetEsimProfileReq req) {
        log.info("Check if stub is On");
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(STUB_GEP, mappingConfig.getSystemCode());
        if (param.isPresent() && Y.equalsIgnoreCase(param.get().getValue())){
            log.info("Stub Error On");
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "ПрофильSIM-карты не найден", null);
        }

        log.info("Stub is Off");
        GetEsimProfileRes res = new GetEsimProfileRes();
        GetEsimProfile input = new GetEsimProfile();
        EsimProfileParams params = new EsimProfileParams();
        params.setIccId(req.getIccId());
        if (!StringUtils.isEmpty(req.getChannel()))
            params.setChannel(req.getChannel());
        if (!CollectionUtils.isEmpty(req.getEntries())){
            EsimProfileParams.AddParams addParams = new EsimProfileParams.AddParams();
            addParams.getEntries().addAll(req.getEntries()
                    .stream()
                    .map(entry -> {
                        EsimProfileParams.AddParams.Entry e = new EsimProfileParams.AddParams.Entry();
                        e.setKey(entry.getParamName());
                        e.setValue(entry.getParamValue());
                        return e;
                    })
                    .collect(Collectors.toList()));
            params.setAddParams(addParams);
        }
        input.setEsimProfileParams(params);
        GetEsimProfileResponse output = soapAPIGate.getEsimProfile(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "ПрофильSIM-карты не найден", null);

        EsimProfileData returnData = output.getReturn();
        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        if (returnData.getEsimProfile() != null){
            GetEsimProfileRes.EsimProfile esimProfile = new GetEsimProfileRes.EsimProfile();
            esimProfile.setMatchingId(returnData.getEsimProfile().getMatchingId());

            if (returnData.getEsimProfile().getAddParams() != null
                    && !CollectionUtils.isEmpty(returnData.getEsimProfile().getAddParams().getEntries()))
            {
                for(EsimProfile.AddParams.Entry e : returnData.getEsimProfile().getAddParams().getEntries()){
                    if (PROFILE_STATUS.equalsIgnoreCase(e.getKey())){
                        esimProfile.setProfileStatus(e.getValue());
                    }
                    if (SMDP_ADDRESS.equalsIgnoreCase(e.getKey())){
                        esimProfile.setSmdpAddress(e.getValue());
                    }
                }
            }

            res.setEsimProfile(esimProfile);
        }
        return res;
    }

    @Override
    public GetEsimRes getEsim(GetEsimReq req) {
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode(STUB_GESIM, mappingConfig.getSystemCode());
        if (param.isPresent() && Y.equalsIgnoreCase(param.get().getValue())) {
            log.info("Stub Error On");
            throw new TelecomException(WARN, HttpStatus.BAD_REQUEST, GET_ESIM_ERROR, null);
        }
        GetEsimRes res = new GetEsimRes();
        GetEsim input = new GetEsim();
        EsimParams esimParams = new EsimParams();
        if (StringUtils.hasText(req.getMsisdn()))
            esimParams.setMsisdn(req.getMsisdn());
        if (StringUtils.hasText(req.getSberId()))
            esimParams.setSberId(req.getSberId());
        if (StringUtils.hasText(req.getChannel()))
            esimParams.setChannel(req.getChannel());
        if (StringUtils.hasText(req.getIccId()))
            esimParams.setIccId(req.getIccId());
        if (!CollectionUtils.isEmpty(req.getEntries())){
            EsimParams.AddParams addParams = new EsimParams.AddParams();
            addParams.getEntries().addAll(req.getEntries().stream()
                    .map(i -> {
                        EsimParams.AddParams.Entry entry = new EsimParams.AddParams.Entry();
                        entry.setKey(i.getParamName());
                        entry.setValue(i.getParamValue());
                        return entry;
                    }).collect(Collectors.toList()));
        }
        input.setEsimParams(esimParams);
        GetEsimResponse output = soapAPIGate.getEsim(input);
        if (output == null || output.getReturn() == null || output.getReturn().getResult() == null)
            throw new TelecomException(WARN, HttpStatus.BAD_REQUEST, GET_ESIM_ERROR, null);
        res.setResult(new ResultDto(output.getReturn().getResult().getCode(), output.getReturn().getResult().getMessageUser()));

        if (!CollectionUtils.isEmpty(output.getReturn().getEsims())){
            res.setEsim(output.getReturn().getEsims().stream().map(
                    i -> {
                        GetEsimRes.Esim esim = new GetEsimRes.Esim();
                        esim.setMatchingId(i.getMatchingId());
                        if (i.getAddParams() != null && !CollectionUtils.isEmpty(i.getAddParams().getEntries())) {
                            esim.setEntries(new ArrayList<>());
                            for(Esim.AddParams.Entry entry : i.getAddParams().getEntries()){
                                Entry e = new Entry();
                                e.setParamName(entry.getKey());
                                e.setParamValue(entry.getValue());
                                esim.getEntries().add(e);
                            }
                        }
                        return esim;
                    }
            ).collect(Collectors.toList()));
        }
        return res;
    }
}
