###Proxy Сервис для методов из EsimServicesPort

- SOAP: GetEsimIccid --> REST: /sbermobile/api/v1/getEsimIccid
- SOAP: GetEsimProfile --> REST: /sbermobile/api/v1/getEsimProfile
- SOAP: ReserveEsimIccidReturn --> REST: /sbermobile/api/v1/reserveEsimIccidReturn

####Properties
- application.telecom.url - урл вэб-сервиса (soap)
- application.telecom.service - название эндпоинта вэб-сервиса (soap)
- application.telecom.timeout -  время ожидания ответа от вэб-сервиса (soap)
- application.telecom.system -  очередь