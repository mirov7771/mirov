package ru.telecom.gateway.controller.get.dto.req;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Schema(description = "структура запроса",
        example =  "{" +
                "\"number\":\"9876543210\"," +
                "\"portingDate\":\"2000-08-30T13:13:13.000+0300\"," +
                "\"portingDate\":\"2000-08-30T13:13:13.000+0300\"," +
                "\"recipientOperatorCode\":\"965\"" +
                "}")
@Data
public class GetPortingTimeslotReq {
    @NotNull
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Переносимый MSISDN")
    private String number;
    @NotNull
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Начальная дата проверяемого диапазона")
    private Date dateFrom;
    @NotNull
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Конечная дата проверяемого диапазона")
    private Date dateTo;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1205", description = "Код оператора реципиента")
    private String recipientOperatorCode;
}
