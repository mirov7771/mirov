package ru.telecom.gateway.util;

import java.util.*;

public class Utils {

    public static int getDaysDiff(Date date1, Date date2){
        long milliseconds = date1.getTime() - date2.getTime();
        return  (int) (milliseconds / (24 * 60 * 60 * 1000));
    }

}
