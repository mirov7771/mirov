package ru.telecom.gateway.service.get.impl;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.GetNumberInfoExReq;
import ru.telecom.gateway.controller.get.dto.req.GetNumberInfoReq;
import ru.telecom.gateway.controller.get.dto.req.GetPortingTimeslotReq;
import ru.telecom.gateway.controller.get.dto.res.GetNumberInfoExRes;
import ru.telecom.gateway.controller.get.dto.res.GetNumberInfoRes;
import ru.telecom.gateway.controller.get.dto.res.GetPortingTimeslotRes;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.util.Utils;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.mnp.*;

import javax.xml.datatype.XMLGregorianCalendar;

import static ru.telecom.gateway.constant.Constants.*;
import static ru.telecom.gateway.constant.Constants.Params.STUB_GPT;

@Service
@RequiredArgsConstructor
@Slf4j
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;
    private final RequestValidator requestValidator;
    private final RestAPIGate restAPIGate;

    @Override
    public GetPortingTimeslotRes getPortingTimeslot(GetPortingTimeslotReq req) {
        requestValidator.validate(STUB_GPT, ERROR, SERVICE_NOT_AVAILABLE);
        GetPortingTimeslotRes res = new GetPortingTimeslotRes();
        GetPortingTimeslotRequest input = new GetPortingTimeslotRequest();
        input.getNumbers().add(req.getNumber());
        if (StringUtils.hasText(req.getRecipientOperatorCode()))
            input.setRecipientOperatorCode(req.getRecipientOperatorCode());

        input.setDateFrom(dateBuilder.convertDate(req.getDateFrom()));
        input.setDateTo(dateBuilder.convertDate(req.getDateTo()));

        List<GetPortingTimeslotRes.Timeslot> timeslots = getTimeslotsByDates(input, req.getDateFrom(), req.getDateTo());
        if (!CollectionUtils.isEmpty(timeslots)) {
            res.setTimeslots(timeslots);
            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
        } else {
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, SERVICE_NOT_AVAILABLE, null);
        }
        return res;
    }

    @Override
    public GetNumberInfoExRes getNumberInfoEx(GetNumberInfoExReq req) {
        requestValidator.validate("STUB_GNI", ERROR, SERVICE_NOT_AVAILABLE);
        return restAPIGate.getNumberInfoEx(req.getTemporaryNumber());
    }

    @Override
    public GetNumberInfoRes getNumberInfo(GetNumberInfoReq req) {
        requestValidator.validate("STUB_GNIEX", ERROR, SERVICE_NOT_AVAILABLE);
        GetNumberInfoRes res = new GetNumberInfoRes();
        GetNumberInfoRequest input = new GetNumberInfoRequest();
        input.setTemporaryNumber(req.getTemporaryNumber());
        GetNumberInfoResponse output = soapAPIGate.getNumberInfo(input);
        if (output == null)
            throw new TelecomException(ERROR, HttpStatus.BAD_REQUEST, SERVICE_NOT_AVAILABLE, "GetNumberInfoRes Error");
        res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
        res.setMnc(output.getMnc());
        res.setRegionId(output.getRegionId());
        res.setRegionName(output.getRegionName());
        res.setBranchId(output.getBranchId());
        res.setBranchName(output.getBranchName());
        res.setOperatorCode(output.getOperatorCode());
        res.setOperatorName(output.getOperatorName());
        res.setRecipientAddress(output.getRecipientAddress());
        return res;
    }

    private List<GetPortingTimeslotRes.Timeslot> getTimeslotsByDates(GetPortingTimeslotRequest input, Date dateStart, Date dateEnd) {
        if (Utils.getDaysDiff(dateEnd, dateStart) < 10) {
            input.setDateFrom(dateBuilder.convertDate(dateStart));
            input.setDateTo(dateBuilder.convertDate(dateEnd));
            return getTimeslots(input);
        } else {
            List<DateInterval> dateInterval = getDateInterval(dateStart, dateEnd);
            if (!CollectionUtils.isEmpty(dateInterval)) {
                List<GetPortingTimeslotRes.Timeslot> res = new ArrayList<>();
                dateInterval.forEach(i -> {
                    input.setDateFrom(i.getFrom());
                    input.setDateTo(i.getTo());
                    List<GetPortingTimeslotRes.Timeslot> timeslots = getTimeslots(input);
                    if (!CollectionUtils.isEmpty(timeslots))
                        res.addAll(timeslots);
                });
                return res;
            }
        }
        return null;
    }

    private List<GetPortingTimeslotRes.Timeslot> getTimeslots(GetPortingTimeslotRequest input) {
        GetPortingTimeslotResponse output = soapAPIGate.getPortingTimeslot(input);
        List<GetPortingTimeslotRes.Timeslot> response = new ArrayList<>();
        if (output != null
                && output.getTimeslots() != null
                && !CollectionUtils.isEmpty(output.getTimeslots().getTimeslots())) {
            for(TimeslotsType.Timeslot tt : output.getTimeslots().getTimeslots()){
                GetPortingTimeslotRes.Timeslot resTT = new GetPortingTimeslotRes.Timeslot();
                final Date date = dateBuilder.convertDate(tt.getDate());
                log.info("DATE !!! {}", date);
                resTT.setDate(dateBuilder.convertDate(tt.getDate()));
                if (!CollectionUtils.isEmpty(tt.getTimeslots())){
                    resTT.setTimeslots(tt.getTimeslots().stream().map(i -> {
                        GetPortingTimeslotRes.Timeslot.Timeslots tm = new GetPortingTimeslotRes.Timeslot.Timeslots();
                        tm.setHour(i.getHour());
                        tm.setFreeSlots(i.getFreeSlots());
                        tm.setTotalSlots(i.getTotalSlots());
                        return tm;
                    }).collect(Collectors.toList()));
                }
                response.add(resTT);
            }
        }
        return response;
    }

    private List<DateInterval> getDateInterval(Date start, Date end) {
        LocalDate lFrom = Instant.ofEpochMilli(start.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        LocalDate lTo = Instant.ofEpochMilli(end.getTime())
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        List<DateInterval> dates = new ArrayList<>();
        for(LocalDate date = lFrom; date.isBefore(lTo); date = date.plusDays(9)) {
            DateInterval dates1 = new DateInterval();
            dates1.setFrom(dateBuilder.convertDate(Date.from(date.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant())));
            LocalDate endDate = date.plusDays(8);
            dates1.setTo(dateBuilder.convertDate(Date.from((endDate.isBefore(lTo) ? endDate : lTo).atStartOfDay().atZone(ZoneId.systemDefault()).toInstant())));
            dates.add(dates1);
        }
        return dates;
    }

    @Setter @Getter
    private static class DateInterval {
        private XMLGregorianCalendar to;
        private XMLGregorianCalendar from;
    }
}
