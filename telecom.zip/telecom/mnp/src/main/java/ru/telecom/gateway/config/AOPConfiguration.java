package ru.telecom.gateway.config;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.stream.Collectors;

@Component
@EnableAspectJAutoProxy
@Aspect
@Slf4j
public class AOPConfiguration {


    @Pointcut("execution(public * ru.telecom.gateway.service..*(..))")
    public void logger(){

    }

    @Before("logger()")
    public void logBeforeMethodStart(JoinPoint jp){
        String args = null;
        if (jp.getArgs() != null)
            args = Arrays.stream(jp.getArgs())
                            .map(Object::toString)
                                    .collect(Collectors.joining(","));
        log.info("Start method [{}] with request [{}]",
                jp,
                args);
    }

    @AfterReturning(value = "logger()", returning = "response")
    public void logAfterMethodEnd(JoinPoint jp, Object response){
        log.info("End method [{}] with result [{}]",
                jp,
                response);
    }

}
