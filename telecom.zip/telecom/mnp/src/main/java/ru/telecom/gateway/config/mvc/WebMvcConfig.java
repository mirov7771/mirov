package ru.telecom.gateway.config.mvc;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ru.telecom.gateway.config.mvc.interceptors.RequestInterceptor;

@Configuration
@RequiredArgsConstructor
public class WebMvcConfig implements WebMvcConfigurer {

    private final RequestInterceptor requestIdInterceptor;

    @Value("${spring.application.name}")
    private String rootPath;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry
                .addInterceptor(requestIdInterceptor)
                .addPathPatterns("/" + rootPath + "/**")
                .excludePathPatterns("/" + rootPath + "/health/live")
                .excludePathPatterns("/" + rootPath + "/health/read")
                .excludePathPatterns("/" + rootPath + "/health/version")
                .excludePathPatterns("/" + rootPath + "/docs/**");
    }

}
