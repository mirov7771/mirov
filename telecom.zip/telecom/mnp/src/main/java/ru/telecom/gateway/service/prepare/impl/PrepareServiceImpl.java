package ru.telecom.gateway.service.prepare.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.prepare.dto.req.PrepareCreateRequestReq;
import ru.telecom.gateway.controller.prepare.dto.res.PrepareCreateRequestRes;
import ru.telecom.gateway.database.service.SaveService;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.prepare.PrepareService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.mnp.PrepareCreateRequestRequest;
import ru.telecom.gateway.xml.mnp.PrepareCreateRequestResponse;

import static ru.telecom.gateway.constant.Constants.OK;
import static ru.telecom.gateway.constant.Constants.Params.*;
import static ru.telecom.gateway.constant.Constants.SUCCESS_MESSAGE;

@Service
@RequiredArgsConstructor
@Slf4j
public class PrepareServiceImpl implements PrepareService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;
    private final RequestValidator requestValidator;
    private final SaveService saveService;

    @Override
    public PrepareCreateRequestRes prepareCreateRequest(PrepareCreateRequestReq req) {
        requestValidator.validate(STUB_PCR_ERR, "ERR_BUISNES_PROCESS", null);
        PrepareCreateRequestRes res = new PrepareCreateRequestRes();
        if (Y.equalsIgnoreCase(requestValidator.getSystemParam(STUB_PCR))){
            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
            res.setRequestId(STUB_BILLING_REQUEST_ID);
            res.setPublicKey("1111");
            res.setOperatorName("Stub-Telecom");
            res.setOperatorCode("mSTUB");
            return res;
        }
        PrepareCreateRequestRequest input = new PrepareCreateRequestRequest();
        input.getNumbers().add(req.getNumber());
        if (StringUtils.hasText(req.getRequestId()))
            input.setRequestId(req.getRequestId());
        if (StringUtils.hasText(req.getParentRequestId()))
            input.setParentRequestId(req.getParentRequestId());
        if (StringUtils.hasText(req.getRecipientOperatorCode()))
            input.setRecipientOperatorCode(req.getRecipientOperatorCode());
        if (req.getIsGovernment() != null)
            input.setIsGovernment(req.getIsGovernment());
        if (req.getPortingDate() != null)
            input.setPortingDate(dateBuilder.convertDate(req.getPortingDate()));
        try {
            PrepareCreateRequestResponse output = soapAPIGate.prepareCreateRequest(input);
            if (output != null) {
                if (StringUtils.hasText(output.getRequestId())) {
                    res.setResult(new ResultDto(Constants.OK, Constants.SUCCESS_MESSAGE));
                    res.setRequestId(output.getRequestId());
                    res.setOperatorCode(output.getOperatorCode());
                    res.setOperatorName(output.getOperatorName());
                    res.setPublicKey(output.getPublicKey());
                    saveService.save(res, "PrepareCreateRequest", input, output, null);
                } else {
                    throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, Constants.SERVICE_NOT_AVAILABLE, null);
                }
            } else {
                throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, Constants.SERVICE_NOT_AVAILABLE, null);
            }
            return res;
        } catch (Exception e) {
            log.error("Error preparing request: ", e);
            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
            res.setRequestId("0");
            res.setPublicKey("0");
            res.setOperatorName("0");
            res.setOperatorCode("0");
            return res;
        }
    }

}
