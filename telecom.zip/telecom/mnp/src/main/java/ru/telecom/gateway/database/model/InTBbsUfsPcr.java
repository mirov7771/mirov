package ru.telecom.gateway.database.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Table(name = "IN_T_BBS_UFS_PCR")
@Entity
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InTBbsUfsPcr  implements Serializable {

    private static final long serialVersionUID = 2819654322030472254L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "in_q_bbs_ufs_pcr")
    @SequenceGenerator(name = "in_q_bbs_ufs_pcr", sequenceName = "in_q_bbs_ufs_pcr", allocationSize = 10)
    private Long id;
    @Column(name = "LOG_ID")
    private Long logId;
    @Column(name = "PHONE_NUMBER")
    private BigDecimal phoneNumber;
    @Column(name = "PORTING_DATE")
    private String portingDate;
    @Column(name = "REQUEST_ID")
    private String requestId;
    @Column(name = "OPERATOR_CODE")
    private String operatorCode;
    @Column(name = "OPERATOR_NAME")
    private String operatorName;
    @Column(name = "PUBLIC_KEY")
    private String publicKey;
}
