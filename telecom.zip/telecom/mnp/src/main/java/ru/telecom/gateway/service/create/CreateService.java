package ru.telecom.gateway.service.create;

import ru.telecom.gateway.controller.create.dto.req.CreateRequestReq;
import ru.telecom.gateway.controller.create.dto.res.CreateRequestRes;
import ru.telecom.gateway.service.Service;

public interface CreateService extends Service {
    CreateRequestRes createRequest(CreateRequestReq req);
}
