package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;

import java.util.Date;

@Schema(description = "Структура ответа", example = "{\n" +
        "\"mnc\": \"50\",\n" +
        "\"regionId\": \"77\",\n" +
        "\"regionName\": \"Г. Москва\",\n" +
        "\"branchId\": \"0\",\n" +
        "\"branchName\": \"0\",\n" +
        "\"operatorCode\": \"mSBERTEL\",\n" +
        "\"operatorName\": \"Сбербанк-Телеком ООО\",\n" +
        "\"recipientAddress\": \"Москва\",\n" +
        "\"portDate\": \"2018-03-18T07:00:07.000+03:00\",\n" +
        "\"authorizedNextPortDate\": \"2018-03-18T07:00:07.000+03:00\",\n" +
        "\"donorOperatorCode\": \"mMTS\",\n" +
        "\"donorOperatorName\": \"Мобильные ТелеСистемы ПАО\",\n" +
        "\"rangeHolderOperatorCode\": \"mMTS\",\n" +
        "\"rangeHolderOperatorName\": \"Мобильные ТелеСистемы ПАО\",\n" +
        "\"msisdn\": \"9645173535\"\t\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetNumberInfoExRes extends BaseRes {
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "mnc", example = "50")
    private String mnc;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код региона ЦНИС", example = "78")
    private String regionId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование региона", example = "Санкт-Петербург")
    private String regionName;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование филиала", example = "0")
    private String branchName;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код оператора в ЦБДПН. Пример: mMEGAFON", example = "mSBERTEL")
    private String operatorCode;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование оператора", example = "МегаФон")
    private String operatorName;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Адрес реципиента", example = "123346, Россия, г. Москва, Ленинградское шоссе, д. 11А, стр. 1")
    private String recipientAddress;
    @Schema(example = "1990-08-30T13:13:13.000+0300", description = "Дата портации")
    private String portDate;
    @Schema(example = "1990-08-30T13:13:13.000+0300", description = "Возможная дата следующей портации")
    private String authorizedNextPortDate;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код оператора от кого пришел абонен в ЦБДПН", example = "mTELE2")
    private String donorOperatorCode;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование оператора от кого пришел абонен", example = "Группа компаний TELE2")
    private String donorOperatorName;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код оператора которому принадлежит диапазонт", example = "mTELE2")
    private String rangeHolderOperatorCode;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование оператора которому принадлежит диапазонт", example = "Группа компаний TELE2")
    private String rangeHolderOperatorName;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String msisdn;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код филиала", example = "108")
    private String branchId;

    public void setErrorDto(){
        this.setResult(new ResultDto(Constants.ERROR, Constants.SERVICE_NOT_AVAILABLE, null));
        this.setMnc("0");
        this.setRegionId("0");
        this.setRegionName("0");
        this.setBranchId("0");
        this.setBranchName("0");
        this.setOperatorCode("0");
        this.setOperatorName("0");
        this.setDonorOperatorCode("0");
        this.setDonorOperatorName("0");
        this.setRangeHolderOperatorCode("0");
        this.setRangeHolderOperatorCode("0");
        this.setPortDate("0");
        this.setRecipientAddress("");
        this.setMsisdn("0");
    }
}
