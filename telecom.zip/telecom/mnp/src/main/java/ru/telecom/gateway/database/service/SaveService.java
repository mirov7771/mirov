package ru.telecom.gateway.database.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.database.model.InTBbsUfsCr;
import ru.telecom.gateway.database.model.InTBbsUfsLog;
import ru.telecom.gateway.database.model.InTBbsUfsPcr;
import ru.telecom.gateway.database.repository.InTBbsUfsCrRepository;
import ru.telecom.gateway.database.repository.InTBbsUfsLogRepository;
import ru.telecom.gateway.database.repository.InTBbsUfsPcrRepository;
import ru.telecom.gateway.xml.mnp.CreateRequestRequest;
import ru.telecom.gateway.xml.mnp.PrepareCreateRequestRequest;
import ru.telecom.gateway.xml.mnp.PrepareCreateRequestResponse;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

@Service
@RequiredArgsConstructor
@Slf4j
public class SaveService {

    private final InTBbsUfsLogRepository logRepository;
    private final InTBbsUfsPcrRepository pcrRepository;
    private final InTBbsUfsCrRepository crRepository;
    private final MappingConfig mappingConfig;

    public void save(BaseRes res,
                     String type,
                     PrepareCreateRequestRequest prepareCreateRequestRequest,
                     PrepareCreateRequestResponse prepareCreateRequestResponse,
                     CreateRequestRequest createRequestRequest) {
        try {
            String subSystemCode = ThreadContext.get(SUBSYSTEM_CODE) == null ? "MAP_SBOL" : ThreadContext.get(SUBSYSTEM_CODE);
            String currentSystem = getCurrentSystem() == null ? "UFS_QUEUE_PROM" : getCurrentSystem();
            InTBbsUfsLog logDb = logRepository.save(InTBbsUfsLog.builder()
                    .serviceName(type)
                    .errorStatus(res.getResult().getCode())
                    .errorText(res.getResult().getMessageUser())
                    .subsystemCode(subSystemCode)
                    .reqDate(new Date())
                    .resDate(new Date())
                    .timeOperations(1L)
                    .currentSystem(currentSystem)
                    .build());
            if (logDb.getId() != null) {
                if (type.equalsIgnoreCase("PrepareCreateRequest") && prepareCreateRequestRequest != null && prepareCreateRequestResponse != null) {
                    BigDecimal phoneNumber = new BigDecimal(prepareCreateRequestRequest.getNumbers().stream().findFirst().orElse("0"));
                    pcrRepository.save(InTBbsUfsPcr.builder()
                                    .logId(logDb.getId())
                                    .portingDate(getStringDate(prepareCreateRequestRequest.getPortingDate()))
                                    .phoneNumber(phoneNumber)
                                    .requestId(prepareCreateRequestRequest.getRequestId())
                                    .operatorCode(prepareCreateRequestResponse.getOperatorCode())
                                    .operatorName(prepareCreateRequestResponse.getOperatorName())
                                    .publicKey(prepareCreateRequestResponse.getOperatorName())
                            .build());
                } else if (type.equalsIgnoreCase("CreateRequest") && createRequestRequest != null) {
                    List<InTBbsUfsPcr> pcr = pcrRepository.findByRequestId(createRequestRequest.getRequestId());
                    if (!CollectionUtils.isEmpty(pcr)) {
                        crRepository.save(InTBbsUfsCr.builder()
                                        .logId(logDb.getId())
                                        .pcrId(pcr.get(0).getId())
                                        .requestId(createRequestRequest.getRequestId())
                                        .temporaryNumber(createRequestRequest.getTemporaryNumber())
                                        .portingDate(getStringDate(createRequestRequest.getPortingDate()))
                                        .emailForNotify(createRequestRequest.getEmailForNotify())
                                        .phoneForNotify(createRequestRequest.getPhoneForNotify())
                                .build());
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error saving in BD: ", e);
        }
    }

    private String getCurrentSystem() {
        return mappingConfig.getSystemCode();
    }

    private String getStringDate(XMLGregorianCalendar date) {
        if (date == null)
            return "";
        return date.toString();
    }

}
