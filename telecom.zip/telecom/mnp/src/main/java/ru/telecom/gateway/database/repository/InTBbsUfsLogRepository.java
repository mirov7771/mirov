package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import ru.telecom.gateway.database.model.InTBbsUfsLog;

public interface InTBbsUfsLogRepository extends CrudRepository<InTBbsUfsLog, Long> {
}
