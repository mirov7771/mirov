package ru.telecom.gateway.gate.http;

import ru.telecom.gateway.controller.get.dto.res.GetNumberInfoExRes;

public interface RestAPIGate {
    GetNumberInfoExRes getNumberInfoEx(String temporaryNumber);
}
