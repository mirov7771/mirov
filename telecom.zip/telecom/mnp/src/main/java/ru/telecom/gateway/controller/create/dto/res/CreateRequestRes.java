package ru.telecom.gateway.controller.create.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

@Schema(description = "структура ответа",
        example = "{\n" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Выполнено успешно\"\n" +
                "    }\n" +
                ",\"code\":\"OK\"" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class CreateRequestRes extends BaseRes {
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "OK", description = "Код")
    private String code;
}
