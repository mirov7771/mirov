package ru.telecom.gateway.service.mock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.res.GetPortingTimeslotRes;
import ru.telecom.gateway.controller.prepare.dto.res.PrepareCreateRequestRes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class MockService {

    public BaseRes createRequest() {
        BaseRes res = new BaseRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        return res;
    }

    public PrepareCreateRequestRes prepareCreateRequest() {
        PrepareCreateRequestRes res = new PrepareCreateRequestRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        res.setRequestId(StringUtils.repeat("1", 250));
        res.setOperatorCode(StringUtils.repeat("M", 250));
        res.setOperatorName(StringUtils.repeat("M", 250));
        res.setPublicKey(StringUtils.repeat("0", 250));
        return res;
    }

    public GetPortingTimeslotRes getPortingTimeslot() {
        GetPortingTimeslotRes res = new GetPortingTimeslotRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        res.setTimeslots(new ArrayList<>());

        GetPortingTimeslotRes.Timeslot timeslot = new GetPortingTimeslotRes.Timeslot();
        timeslot.setDate(new Date());
        timeslot.setTimeslots(new ArrayList<>());

        GetPortingTimeslotRes.Timeslot.Timeslots timeslots = new GetPortingTimeslotRes.Timeslot.Timeslots();
        timeslots.setTotalSlots(1000000000);
        timeslots.setFreeSlots(1000000000);
        timeslots.setHour(1000000000);

        timeslot.getTimeslots().addAll(Stream.generate(() -> timeslots).limit(500).collect(Collectors.toList()));
        res.getTimeslots().addAll(Stream.generate(() -> timeslot).limit(1).collect(Collectors.toList()));

        return res;
    }

}
