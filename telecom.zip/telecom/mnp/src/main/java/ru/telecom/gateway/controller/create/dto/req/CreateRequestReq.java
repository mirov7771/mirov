package ru.telecom.gateway.controller.create.dto.req;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;

import javax.validation.constraints.NotNull;

@Schema(description = "структура запроса",
        example = "{" +
                "\"requestId\":\"1205\"," +
                "\"portingDate\":\"2000-08-30T13:13:13.000+0300\"," +
                "\"phoneForNotify\":\"9876543210\"," +
                "\"emailForNotify\":\"mail@mail.ru\"," +
                "\"temporaryNumber\":\"9876543210\"" +
                "}")
@Data
public class CreateRequestReq {
    @NotNull
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1205", description = "Идентификатор заявки")
    private String requestId;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Желаемая дата и время переноса номера")
    private Date portingDate;
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Дополнительный телефонный номер для SMS-информирования о ходе переноса номера")
    private String phoneForNotify;
    @Schema(maxLength = 120, example = "mail@mail.ru", pattern = "^(.*){120}$", description = "Дополнительный email для информирования о ходе переноса номера")
    private String emailForNotify;
    @NotNull
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Временный MSISDN")
    private String temporaryNumber;
}
