package ru.telecom.gateway.builder;

import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;

import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

public class ResponseBuilder {

    public static <T> ResponseEntity<T> build(T data) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(RQ_UID, ThreadContext.get(RQ_UID));
        headers.add(RQ_TM, ThreadContext.get(RQ_TM));
        headers.add(SUBSYSTEM_CODE, ThreadContext.get(SUBSYSTEM_CODE));
        return ResponseEntity.ok().headers(headers).body(data);
    }

}
