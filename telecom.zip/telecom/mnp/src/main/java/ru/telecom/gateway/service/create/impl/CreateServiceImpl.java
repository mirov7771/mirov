package ru.telecom.gateway.service.create.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.create.dto.req.CreateRequestReq;
import ru.telecom.gateway.controller.create.dto.res.CreateRequestRes;
import ru.telecom.gateway.database.service.SaveService;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.create.CreateService;
import ru.telecom.gateway.validator.RequestValidator;
import ru.telecom.gateway.xml.mnp.CreateRequestRequest;
import ru.telecom.gateway.xml.mnp.CreateRequestResponse;

import static ru.telecom.gateway.constant.Constants.OK;
import static ru.telecom.gateway.constant.Constants.Params.*;
import static ru.telecom.gateway.constant.Constants.SUCCESS_MESSAGE;

@Service
@RequiredArgsConstructor
@Slf4j
public class CreateServiceImpl implements CreateService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;
    private final RequestValidator requestValidator;
    private final SaveService saveService;

    @Override
    public CreateRequestRes createRequest(CreateRequestReq req) {
        requestValidator.validate(STUB_CR_ERR, "ERR_BUISNES_PROCESS", null);
        CreateRequestRes res = new CreateRequestRes();
        if (Y.equalsIgnoreCase(requestValidator.getSystemParam(STUB_CR))){
            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
            res.setCode(OK);
            return res;
        }

        CreateRequestRequest input = new CreateRequestRequest();
        if (StringUtils.hasText(req.getRequestId()))
            input.setRequestId(req.getRequestId());
        if (StringUtils.hasText(req.getTemporaryNumber()))
            input.setTemporaryNumber(req.getTemporaryNumber());
        if (req.getPortingDate() != null)
            input.setPortingDate(dateBuilder.convertDate(req.getPortingDate()));
        if (StringUtils.hasText(req.getEmailForNotify()))
            input.setEmailForNotify(req.getEmailForNotify());
        CreateRequestResponse output = soapAPIGate.createRequest(input);

        if (output != null) {
            if (StringUtils.hasText(output.getCode())) {
                res.setCode(output.getCode());
                res.setResult(new ResultDto(OK, Constants.SUCCESS_MESSAGE));
                saveService.save(res, "CreateRequest", null, null, input);
            } else {
                throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, Constants.SERVICE_NOT_AVAILABLE, null);
            }
        } else {
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, Constants.SERVICE_NOT_AVAILABLE, null);
        }
        return res;
    }

}
