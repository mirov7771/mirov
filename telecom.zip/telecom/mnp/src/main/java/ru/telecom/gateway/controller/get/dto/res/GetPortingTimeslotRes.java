package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.config.MultiDateDeserializer;
import ru.telecom.gateway.controller.base.res.BaseRes;

@Schema(description = "структура ответа",
        example = "{" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Выполнено успешно\"\n" +
                "    }," +
                "\"timeslots\":[" +
                "{" +
                "\"date\":\"2000-08-30T13:13:13.000+0300\"," +
                "\"timeslots\":[" +
                "{" +
                "\"hour\": 0, " +
                "\"freeSlots\": 0, " +
                "\"totalSlots\": 0" +
                "}" +
                "]" +
                "}]}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetPortingTimeslotRes extends BaseRes {

    @ArraySchema(maxItems = 10000)
    private List<Timeslot> timeslots;

    @Schema(description = "структура объекта",
            example = "{" +
                    "\"date\":\"2000-08-30T13:13:13.000+0300\"," +
                    "\"timeslots\":\"[" +
                    "{" +
                    "\"hour\": 0, " +
                    "\"freeSlots\": 0, " +
                    "\"totalSlots\": 0" +
                    "}" +
                    "]\"" +
                    "}")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Timeslot {
        @JsonDeserialize(using = MultiDateDeserializer.class)
        @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Дата таймслота")
        private Date date;
        @ArraySchema(maxItems = 10000)
        private List<Timeslots> timeslots;

        @Schema(description = "структура объекта",
                example = "{" +
                        "\"hour\": 0, " +
                        "\"freeSlots\": 0, " +
                        "\"totalSlots\": 0" +
                        "}")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class Timeslots {
            @Schema(minimum = "0", maximum = "10000000000", example = "100", description = "Час таймслота")
            private Integer hour;
            @Schema(minimum = "0", maximum = "10000000000", example = "100", description = "Количество доступных переносов в этом таймслоте")
            private Integer freeSlots;
            @Schema(minimum = "0", maximum = "10000000000", example = "100", description = "Общее количество переносов в этом таймслоте")
            private Integer totalSlots;
        }
    }
}
