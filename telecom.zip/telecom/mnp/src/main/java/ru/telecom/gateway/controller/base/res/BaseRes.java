package ru.telecom.gateway.controller.base.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.telecom.gateway.controller.base.support.ResultDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BaseRes {

    private ResultDto result;

}
