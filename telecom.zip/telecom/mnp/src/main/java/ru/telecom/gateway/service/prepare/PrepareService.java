package ru.telecom.gateway.service.prepare;

import ru.telecom.gateway.controller.prepare.dto.req.PrepareCreateRequestReq;
import ru.telecom.gateway.controller.prepare.dto.res.PrepareCreateRequestRes;
import ru.telecom.gateway.service.Service;

public interface PrepareService extends Service {
    PrepareCreateRequestRes prepareCreateRequest(PrepareCreateRequestReq req);
}
