package ru.telecom.gateway.gate.http.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.res.GetNumberInfoExRes;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.http.client.RestGate;

import static ru.telecom.gateway.constant.Constants.OK;
import static ru.telecom.gateway.constant.Constants.SUCCESS_MESSAGE;

@Service
@RequiredArgsConstructor
@Slf4j
public class RestAPIGateImpl implements RestAPIGate {

    private final RestGate restGate;
    @Value("${application.telecom.rest.url}")
    private String url;

    private static final String REQUEST =
            "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:mnp=\"http://www.bercut.com/specs/aoi/mnp/Mnp\">" +
            "   <soapenv:Header/>" +
            "   <soapenv:Body>" +
            "      <mnp:GetNumberInfoExRequest>" +
            "         <temporaryNumber>%temporaryNumber%</temporaryNumber>" +
            "      </mnp:GetNumberInfoExRequest>" +
            "   </soapenv:Body>" +
            "</soapenv:Envelope>";

    @Override
    public GetNumberInfoExRes getNumberInfoEx(String temporaryNumber) {
        GetNumberInfoExRes res = new GetNumberInfoExRes();
        try {
            String request = REQUEST.replace("%temporaryNumber%", temporaryNumber);
            String response = restGate.call(String.class,
                    url,
                    null,
                    null,
                    request,
                    HttpMethod.POST,
                    null,
                    MediaType.TEXT_XML);
            log.info("response {}", response);
            if (!StringUtils.hasText(response)) {
                res.setErrorDto();
            } else {
                res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
                res.setMnc(getTagValue(response, "mnc"));
                res.setRegionId(getTagValue(response, "regionId"));
                res.setRegionName(getTagValue(response, "regionName"));
                res.setBranchId(getTagValue(response, "branchId"));
                res.setBranchName(getTagValue(response, "branchName"));
                res.setOperatorCode(getTagValue(response, "operatorCode"));
                res.setOperatorName(getTagValue(response, "operatorName"));
                res.setDonorOperatorCode(getTagValue(response, "donorOperatorCode"));
                res.setDonorOperatorName(getTagValue(response, "donorOperatorName"));
                res.setRangeHolderOperatorCode(getTagValue(response, "rangeHolderOperatorCode"));
                res.setRangeHolderOperatorName(getTagValue(response, "rangeHolderOperatorName"));
                res.setPortDate(getTagValue(response, "portDate"));
                res.setRecipientAddress(getTagValue(response, "recipientAddress"));
                res.setAuthorizedNextPortDate(getTagValue(response, "authorizedNextPortDate"));
                res.setMsisdn(getTagValue(response, "msisdn"));
            }
        } catch (Exception e) {
            log.error("Error calling getNumberInfoEx ", e);
            res.setErrorDto();
        }
        return res;
    }

    private static String getTagValue(String xml, String tag){
        if (xml.contains(tag) && xml.contains("/" + tag))
            return xml.split("<" + tag + ">")[1].split("</" + tag + ">")[0];
        return null;
    }
}
