package ru.telecom.gateway.controller.prepare.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

@Schema(description = "структура ответа",
        example = "{" +
                "    \"result\": {\n" +
                "        \"code\": \"OK\",\n" +
                "        \"messageUser\": \"Выполнено успешно\"\n" +
                "    }\n," +
                "\"requestId\":\"1205\"," +
                "\"operatorCode\":\"mMTS\"," +
                "\"operatorName\":\"Мобильные ТелеСистемы\"," +
                "\"publicKey\":\"0\"" +
                "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class PrepareCreateRequestRes extends BaseRes {
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1205", description = "Идентификатор заявки")
    private String requestId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "mMTS", description = "Код оператора в ЦБДПН")
    private String operatorCode;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "Мобильные ТелеСистемы", description = "Название оператора")
    private String operatorName;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "0", defaultValue = "0", description = "Открытый ключ. Данный ключ используется для шифрования zip-архива с документами")
    private String publicKey = "0";
}
