package ru.telecom.gateway.gate.soap.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.xml.mnp.*;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.telecom.service}")
    private String serviceUrl;

    @Override
    public CreateRequestResponse createRequest(CreateRequestRequest req) {
        return (CreateRequestResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetPortingTimeslotResponse getPortingTimeslot(GetPortingTimeslotRequest req) {
        return (GetPortingTimeslotResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public PrepareCreateRequestResponse prepareCreateRequest(PrepareCreateRequestRequest req) {
        return (PrepareCreateRequestResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetNumberInfoResponse getNumberInfo(GetNumberInfoRequest req) {
        return (GetNumberInfoResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }
}
