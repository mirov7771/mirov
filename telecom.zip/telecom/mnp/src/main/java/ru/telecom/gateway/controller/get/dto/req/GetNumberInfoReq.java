package ru.telecom.gateway.controller.get.dto.req;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Schema(description = "Структура запроса", example = "{\"temporaryNumber\": \"9127278877\"}")
@Data
public class GetNumberInfoReq {
    @NotNull
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Номер телефона (MSISDN)")
    private String temporaryNumber;
}
