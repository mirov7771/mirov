package ru.telecom.gateway.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
public class TelecomException extends RuntimeException {

    private static final long serialVersionUID = 8359430630502179416L;

    private final String code;
    private final String messageUser;
    private final HttpStatus status;
    private final String description;
    private final String messageSystem;

    public TelecomException(String code, HttpStatus status, String messageUser, String description)
    {
        super(messageUser);
        this.code = code;
        this.status = status;
        this.messageUser = messageUser;
        this.description = description;
        this.messageSystem = null;
    }

    public TelecomException(String code, HttpStatus status, String messageUser, String description, String messageSystem)
    {
        super(messageUser);
        this.code = code;
        this.status = status;
        this.messageUser = messageUser;
        this.description = description;
        this.messageSystem = messageSystem;
    }
}
