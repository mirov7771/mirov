package ru.telecom.gateway.service.get;

import ru.telecom.gateway.controller.get.dto.req.GetNumberInfoExReq;
import ru.telecom.gateway.controller.get.dto.req.GetNumberInfoReq;
import ru.telecom.gateway.controller.get.dto.req.GetPortingTimeslotReq;
import ru.telecom.gateway.controller.get.dto.res.GetNumberInfoExRes;
import ru.telecom.gateway.controller.get.dto.res.GetNumberInfoRes;
import ru.telecom.gateway.controller.get.dto.res.GetPortingTimeslotRes;
import ru.telecom.gateway.service.Service;

public interface GetService extends Service {
    GetPortingTimeslotRes getPortingTimeslot(GetPortingTimeslotReq req);
    GetNumberInfoExRes getNumberInfoEx(GetNumberInfoExReq req);
    GetNumberInfoRes getNumberInfo(GetNumberInfoReq req);
}
