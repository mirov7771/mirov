package ru.telecom.gateway.database.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "in_t_bbs_ufs_log")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
public class InTBbsUfsLog implements Serializable {

    private static final long serialVersionUID = -6264113049382033830L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "in_q_bbs_ufs_log")
    @SequenceGenerator(name = "in_q_bbs_ufs_log", sequenceName = "in_q_bbs_ufs_log", allocationSize = 10)
    private Long id;
    @Column(name = "SERVICE_NAME")
    private String serviceName;
    @Column(name = "SC_NAME")
    private String scName;
    @Column(name = "RQ_UID")
    private String rqUid;
    @Column(name = "RQ_TM")
    private String rqTm;
    @Column(name = "SP_NAME")
    private String spName;
    @Column(name = "REQ_IN")
    private String reqIn;
    @Column(name = "RES_OUT")
    private String resOut;
    @Column(name = "ERROR_TEXT")
    private String errorText;
    @Column(name = "ERROR_STATUS")
    private String errorStatus;
    @Column(name = "REQ_DATE")
    private Date reqDate;
    @Column(name = "RES_DATE")
    private Date resDate;
    @Column(name = "CUSTOM_1")
    private String custom1;
    @Column(name = "SC_NAME_OUT")
    private String scNameOut;
    @Column(name = "RQ_TM_OUT")
    private String rqTmOut;
    @Column(name = "SP_NAME_OUT")
    private String spNameOut;
    @Column(name = "REQUEST_DATA")
    private String requestData;
    @Column(name = "RESPONSE_DATA")
    private String responseData;
    @Column(name = "CURRENT_SYSTEM")
    private String currentSystem;;
    @Column(name = "REQ_WSDL")
    private String reqWsdl;
    @Column(name = "STANDALONE")
    private String standalone;
    @Column(name = "TIME_OPERATION")
    private Long timeOperations;
    @Column(name = "OPERATION_NAME")
    private String operationName;
    @Column(name = "PROVIDER_ID")
    private String providerId;
    @Column(name = "SERVICE_VERSION")
    private String serviceVersion;
    @Column(name = "CORRELATION_ID")
    private String correlationId;
    @Column(name = "DESTINATION")
    private String destination;
    @Column(name = "EXPIRATION")
    private Long expiration;
    @Column(name = "MESSAGE_ID")
    private String messageId;
    @Column(name = "REPLY_TO")
    private String replyTo;
    @Column(name = "OPERATION_STEP_ID")
    private String operationStypeId;
    @Column(name = "QUEUE_GROUP_ID")
    private String queueGroupId;
    @Column(name = "REPLY_TO_CORREL_ID")
    private String replyToCorrelId;
    @Column(name = "JMSX_GROUP_ID")
    private String jmsxGroupId;
    @Column(name = "BREADCRUMB_ID")
    private String bradCrumbId;
    @Column(name = "REPLY_TO_QMGRORIG")
    private String replyToQmgrorig;
    @Column(name = "MSG_FLAGS")
    private String msgFlags;
    @Column(name = "REPLY_TO_QORIG")
    private String replyToQorig;
    @Column(name = "REQ_RAW_MSG")
    private String reqRawMsg;
    @Column(name = "RES_RAW_MSG")
    private String resRawMsg;
    @Column(name = "ESB_SYSTEM_DATA")
    private String esbSystemData;
    @Column(name = "SUBSYSTEM_CODE")
    private String subsystemCode;

}
