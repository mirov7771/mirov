package ru.telecom.gateway.database.pk;

import lombok.Data;

import java.io.Serializable;

@Data
public class OstSystemParamPk implements Serializable {

    private static final long serialVersionUID = -7585936422892410364L;

    private String code;
    private String outSystemCode;
}
