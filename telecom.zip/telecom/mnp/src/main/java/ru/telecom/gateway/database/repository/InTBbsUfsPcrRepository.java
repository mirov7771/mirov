package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.telecom.gateway.database.model.InTBbsUfsPcr;

import java.util.List;

@Repository
public interface InTBbsUfsPcrRepository extends CrudRepository<InTBbsUfsPcr, Long> {
    List<InTBbsUfsPcr> findByRequestId(String requestId);
}
