package ru.telecom.gateway.controller.get.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.telecom.gateway.controller.base.res.BaseRes;

@Schema(description = "Структура ответа", example = "{\n" +
        "\"mnc\": \"50\",\n" +
        "\"regionId\": \"77\",\n" +
        "\"regionName\": \"Г. Москва\",\n" +
        "\"branchId\": \"0\",\n" +
        "\"branchName\": \"0\",\n" +
        "\"operatorCode\": \"mSBERTEL\",\n" +
        "\"operatorName\": \"Сбербанк-Телеком ООО\",\n" +
        "\"recipientAddress\": \"Москва\"\n" +
        "}")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
public class GetNumberInfoRes extends BaseRes {
    @Schema(maxLength = 50, pattern = "^(.*){50}$", description = "mnc", example = "")
    private String mnc;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код региона ЦНИС", example = "78")
    private String regionId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование региона", example = "Санкт-Петербург")
    private String regionName;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код филиала", example = "108")
    private String branchId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование филиала", example = "0")
    private String branchName;
    @Schema(maxLength = 150, pattern = "^(.*){150}$", description = "Код оператора в ЦБДПН. Пример: mMEGAFON", example = "mSBERTEL")
    private String operatorCode;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Наименование оператора", example = "МегаФон")
    private String operatorName;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", description = "Адрес реципиента", example = "123346, Россия, г. Москва, Ленинградское шоссе, д. 11А, стр. 1")
    private String recipientAddress;
}
