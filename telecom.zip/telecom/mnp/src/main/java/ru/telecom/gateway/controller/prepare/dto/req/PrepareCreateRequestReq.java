package ru.telecom.gateway.controller.prepare.dto.req;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;

import javax.validation.constraints.NotNull;

@Schema(description = "структура запроса",
        example = "{" +
                "\"number\":\"9876543210\"," +
                "\"portingDate\":\"2000-08-30T13:13:13.000+0300\"," +
                "\"parentRequestId\":\"89701501077100009363\"," +
                "\"recipientOperatorCode\":\"965\"," +
                "\"isGovernment\":\"true\"," +
                "\"requestId\":\"1205\"" +
                "}")
@Data
public class PrepareCreateRequestReq {
    @NotNull
    @Schema(maxLength = 20, example = "9876543210", pattern = "^(([0-9]){10,20})$", description = "Переносимый MSISDN")
    private String number;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "89701501077100009363", description = "Если абонент подавал заявление, и его отклонили – это идентификатор предыдущего отклоненного заявления")
    private String parentRequestId;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "0104", description = "Код оператора реципиента от имени, которого будет создана заявка")
    private String recipientOperatorCode;
    @Schema(description = "Наименование электронной торговой площадки")
    private Boolean isGovernment;
    @Schema(maxLength = 250, pattern = "^(.*){250}$", example = "1205", description = "Идентификатор заявки")
    private String requestId;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @Schema(example = "2000-08-30T13:13:13.000+0300", description = "Желаемая дата и время переноса номера")
    private Date portingDate;
}
