package ru.telecom.gateway.database.model;

import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "IN_T_BBS_UFS_CR")
@Entity
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InTBbsUfsCr implements Serializable {

    private static final long serialVersionUID = -8156431769020475059L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "in_q_bbs_ufs_cr")
    @SequenceGenerator(name = "in_q_bbs_ufs_cr", sequenceName = "in_q_bbs_ufs_cr", allocationSize = 10)
    private Long id;
    @Column(name = "LOG_ID")
    private Long logId;
    @Column(name = "PCR_ID")
    private Long pcrId;
    @Column(name = "REQUEST_ID")
    private String requestId;
    @Column(name = "TEMPORARY_NUMBER")
    private String temporaryNumber;
    @Column(name = "PORTING_DATE")
    private String portingDate;
    @Column(name = "EMAIL_FOR_NOTIFY")
    private String emailForNotify;
    @Column(name = "PHONE_FOR_NOTIFY")
    private String phoneForNotify;
}
