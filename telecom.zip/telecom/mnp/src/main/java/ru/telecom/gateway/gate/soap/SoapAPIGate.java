package ru.telecom.gateway.gate.soap;

import ru.telecom.gateway.xml.mnp.*;

public interface SoapAPIGate {
    default CreateRequestResponse createRequest(CreateRequestRequest req) {
        return null;
    }
    default GetPortingTimeslotResponse getPortingTimeslot(GetPortingTimeslotRequest req) {
        return null;
    }
    default PrepareCreateRequestResponse prepareCreateRequest(PrepareCreateRequestRequest req) {
        return null;
    }
    default GetNumberInfoResponse getNumberInfo(GetNumberInfoRequest req) {
        return null;
    }
}
