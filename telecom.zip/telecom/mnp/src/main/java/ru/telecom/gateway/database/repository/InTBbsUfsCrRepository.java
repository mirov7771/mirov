package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.telecom.gateway.database.model.InTBbsUfsCr;

@Repository
public interface InTBbsUfsCrRepository extends CrudRepository<InTBbsUfsCr, Long> {
}
