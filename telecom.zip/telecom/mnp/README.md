###Proxy Сервис для методов из DSI_CRM_AccountManagementBinding

- SOAP: PrepareCreateRequest --> REST: sbermobile/api/v1/prepareCreateRequest
- SOAP: GetPortingTimeslot --> REST: sbermobile/api/v1/getPortingTimeslot
- SOAP: CreateRequest --> REST: sbermobile/api/v1/CreateRequest

####Properties
- application.telecom.url - урл вэб-сервиса (soap)
- application.telecom.service - название эндпоинта вэб-сервиса (soap)
- application.telecom.timeout -  время ожидания ответа от вэб-сервиса (soap)
- application.telecom.system -  очередь