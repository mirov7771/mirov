package webservice;

import com.sbtele.infoexchange.repository.model.RemovedSubscriber;

import java.util.Date;
import java.util.Random;

import static com.sbtele.infoexchange.repository.model.SubscriberEventPriority.PRIORITY_NORMAL;
import static com.sbtele.infoexchange.repository.model.SubscriberEventReason.REASON_CONTRACT_CLOSE;

public class RemovedSubscriberStub extends RemovedSubscriber {
    @Override
    public String getMsisdn() {
        return super.getMsisdn();
    }

    @Override
    public Long getReason() {
        return REASON_CONTRACT_CLOSE.get();
    }

    @Override
    public Integer getPriority() {
        return PRIORITY_NORMAL.get();
    }

    @Override
    public Date getDisconnectedAt() {
        return new Date();
    }

    @Override
    public Date getAvailableAt() {
        return new Date();
    }

    @Override
    public Long getRequestId() {
        return new Random().nextLong();
    }
}
