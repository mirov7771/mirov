package webservice;

import com.sbtele.infoexchange.billing.BillingService;
import com.sbtele.infoexchange.csv.SnapshotManager;
import com.sbtele.infoexchange.repository.MsisdnLocalStore;
import com.sbtele.infoexchange.repository.WatchListRepository;
import com.sbtele.infoexchange.repository.model.Client;
import com.sbtele.infoexchange.webservice.CredentialsValidator;
import com.sbtele.infoexchange.webservice.NewClientsService;
import com.sbtele.infoexchange.webservice.NewClientsServiceImpl;
import com.sbtele.infoexchange.xml.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.Random;

import static com.sbtele.infoexchange.xml.XmlConstants.ClientOperationResults.*;
import static com.sbtele.infoexchange.xml.XmlConstants.NewClientsOperationResults.OPERATION_RESULT_CREDENTIALS_ERROR;
import static com.sbtele.infoexchange.xml.XmlConstants.NewClientsOperationResults.OPERATION_RESULT_SUCCESS;
import static junit.framework.TestCase.assertEquals;

@RunWith(SpringRunner.class)
public class NewClientsServiceTest {

    private NewClientsRequestInfo requestInfo;

    @MockBean
    private WatchListRepository watchListRepository;

    @MockBean
    private BillingService billingService;

    @MockBean
    private SnapshotManager snapshotManager;

    @MockBean
    private CredentialsValidator credentialsValidator;

    @MockBean
    private MsisdnLocalStore msisdnLocalStore;

    @Autowired
    private NewClientsService newClientsService;

    @TestConfiguration
    static class NewClientsServiceTestContextConfiguration {

        @Bean
        public NewClientsService newClientsService() {
            return new NewClientsServiceImpl();
        }
    }

    @Before
    public void setUp() {
        ClientToAdd clientToAdd = new ClientToAdd();
        clientToAdd.setMsisdn("1234567890");
        clientToAdd.setChangedAt(new Date());

        ClientsToAdd clients = new ClientsToAdd();
        clients.setClients(new ArrayList<ClientToAdd>() {
            {
                add(clientToAdd);
            }
        });

        requestInfo = new NewClientsRequestInfo();
        NewClientRequestBody body = new NewClientRequestBody();
        body.setRequestId(new Random().nextLong());
        body.setLogin("login");
        body.setPassword("password");
        body.setFullListNeeded(0L);
        body.setClientsToAdd(clients);
        requestInfo.setBody(body);

        Mockito.when(credentialsValidator.isCredentialsValid(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        Mockito.when(billingService.isSubscriberExist(Mockito.anyString())).thenReturn(true);
        Mockito.when(msisdnLocalStore.exist(Mockito.anyString())).thenReturn(true);
        snapshotManager = Mockito.mock(SnapshotManager.class);
        Mockito.doNothing().when(snapshotManager).doSnapshot();
    }

    @Test
    public void testAddNewClients_addNewClients() {
        NewClientsResponseInfo response = newClientsService.addNewClients(requestInfo);
        assertEquals(OPERATION_RESULT_SUCCESS, response.getBody().getOperationResult());
        assertEquals(requestInfo.getBody().getClientsToAdd().getClients().size(), response.getBody().getClientResults().getResults().size());
        assertEquals(CLIENT_RESULT_SUCCESS, (long) response.getBody().getClientResults().getResults().get(0).getResult());
    }

    @Test
    public void testAddNewClients_CredentialsError() {
        Mockito.when(credentialsValidator.isCredentialsValid(Mockito.anyString(), Mockito.anyString())).thenReturn(false);
        NewClientsResponseInfo responseInfo = newClientsService.addNewClients(requestInfo);
        assertEquals(OPERATION_RESULT_CREDENTIALS_ERROR, responseInfo.getBody().getOperationResult());
    }

    @Test
    public void testAddNewClients_ClientMsisdnError() {
        ClientToAdd client = requestInfo.getBody().getClientsToAdd().getClients().get(0);
        client.setMsisdn("a123");
        NewClientsResponseInfo responseInfo = newClientsService.addNewClients(requestInfo);
        assertEquals(CLIENT_RESULT_ERROR_WRONG_MSISDN_FORMAT, (long)responseInfo.getBody().getClientResults().getResults().get(0).getResult());
    }

    @Test
    public void testAddNewClients_ClientDateError() {
        ClientToAdd client = requestInfo.getBody().getClientsToAdd().getClients().get(0);
        client.setChangedAt(null);
        NewClientsResponseInfo responseInfo = newClientsService.addNewClients(requestInfo);
        assertEquals(CLIENT_RESULT_ERROR_WRONG_DATE_FORMAT, (long)responseInfo.getBody().getClientResults().getResults().get(0).getResult());
    }

    @Test
    public void testAddNewClients_MsisdnAlreadyInWatchList() {
        Mockito.when(watchListRepository.findByMsisdnAndEndWatchIsNull(Mockito.anyString())).thenReturn(Optional.of(new Client()));
        NewClientsResponseInfo responseInfo = newClientsService.addNewClients(requestInfo);
        assertEquals(CLIENT_RESULT_ERROR_MSISDN_EXIST, (long)responseInfo.getBody().getClientResults().getResults().get(0).getResult());
    }

    @Test
    public void testAddNewClients_SubscriberUnknown() {
        Mockito.when(msisdnLocalStore.exist(Mockito.anyString())).thenReturn(false);
        Mockito.when(billingService.isSubscriberExist(Mockito.anyString())).thenReturn(false);
        NewClientsResponseInfo responseInfo = newClientsService.addNewClients(requestInfo);
        assertEquals(CLIENT_RESULT_ERROR_UNKNOWN_SUBSCRIBER, (long)responseInfo.getBody().getClientResults().getResults().get(0).getResult());
    }
}
