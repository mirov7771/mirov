package webservice;

import com.sbtele.infoexchange.repository.SubscriberEventsRepository;
import com.sbtele.infoexchange.repository.model.RemovedSubscriber;
import com.sbtele.infoexchange.webservice.CredentialsValidator;
import com.sbtele.infoexchange.webservice.DisconnectedSubscribersService;
import com.sbtele.infoexchange.webservice.DisconnectedSubscribersServiceImpl;
import com.sbtele.infoexchange.xml.DisconnectedSubscribersRequestBody;
import com.sbtele.infoexchange.xml.DisconnectedSubscribersRequestInfo;
import com.sbtele.infoexchange.xml.DisconnectedSubscribersResponseInfo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static com.sbtele.infoexchange.xml.XmlConstants.DisconnectedSubscribersOperationResults.*;
import static junit.framework.TestCase.assertEquals;

@RunWith(SpringRunner.class)
public class DisconnectedSubscribersServiceTest {

    @Autowired
    private DisconnectedSubscribersService disconnectedSubscribersService;

    @MockBean
    private SubscriberEventsRepository subscriberEventsRepository;

    @MockBean
    private CredentialsValidator credentialsValidator;

    private DisconnectedSubscribersRequestInfo disconnectedSubscribersRequestInfo;
    private DisconnectedSubscribersRequestBody requestBody;

    @TestConfiguration
    static class DisconnectedSubscribersRequestInfoTestContextConfiguration {

        @Bean
        public DisconnectedSubscribersService disconnectedSubscribersService() {
            return new DisconnectedSubscribersServiceImpl();
        }
    }

    @Before
    public void setUp() {
        disconnectedSubscribersRequestInfo = new DisconnectedSubscribersRequestInfo();
        requestBody.setLogin("login");
        requestBody.setPassword("pwd");
        requestBody.setOldRquestId(0L);
        requestBody.setRequestId(new Random().nextLong());
        disconnectedSubscribersRequestInfo.setBody(requestBody);
    }

    @Test
    public void testGetDisconnectedSubscribers_CredentialsError() {
        Mockito.when(credentialsValidator.isCredentialsValid(Mockito.anyString(), Mockito.anyString())).thenReturn(false);

        requestBody.setLogin("");
        requestBody.setPassword("");
        disconnectedSubscribersRequestInfo.setBody(requestBody);

        DisconnectedSubscribersResponseInfo disconnectedSubscribersResponseInfo = disconnectedSubscribersService
                .getDisconnectedSubscribers(disconnectedSubscribersRequestInfo);

        assertEquals(OPERATION_RESULT_CREDENTIALS_ERROR, disconnectedSubscribersResponseInfo.getBody().getOperationResult());
    }

    @Test
    public void testGetDisconnectedSubscribers_RequestIdError() {
        requestBody.setRequestId(null);
        disconnectedSubscribersRequestInfo.setBody(requestBody);

        DisconnectedSubscribersResponseInfo disconnectedSubscribersResponseInfo = disconnectedSubscribersService
                .getDisconnectedSubscribers(disconnectedSubscribersRequestInfo);

        assertEquals(OPERATION_RESULT_OTHER_ERROR, disconnectedSubscribersResponseInfo.getBody().getOperationResult());
        assertEquals(OPERATION_RESULT_ID_ERROR_DESCRIPTION, disconnectedSubscribersResponseInfo.getBody().getErrorDescription());
    }

    @Test
    public void testGetDisconnectedSubscribers_OldRequestIdError() {
        requestBody.setOldRquestId(null);
        disconnectedSubscribersRequestInfo.setBody(requestBody);

        DisconnectedSubscribersResponseInfo disconnectedSubscribersResponseInfo = disconnectedSubscribersService
                .getDisconnectedSubscribers(disconnectedSubscribersRequestInfo);

        assertEquals(OPERATION_RESULT_OTHER_REPEAT_ERROR, disconnectedSubscribersResponseInfo.getBody().getOperationResult());
        assertEquals(OPERATION_RESULT_OLD_ID_ERROR_DESCRIPTION, disconnectedSubscribersResponseInfo.getBody().getErrorDescription());
    }

    @Test
    public void testGetDisconnectedSubscribers_getDisconnectedSubscribers() {
        Mockito.when(credentialsValidator.isCredentialsValid(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        List<RemovedSubscriber> events = new ArrayList<>();
        final int counter = 3;

        for (int i = 0; i < counter; i++) {
            events.add(new RemovedSubscriberStub());
        }

        Mockito.when(subscriberEventsRepository.findSubscriberEvents(Mockito.any())).thenReturn(events);

        DisconnectedSubscribersResponseInfo disconnectedSubscribersResponseInfo = disconnectedSubscribersService
                .getDisconnectedSubscribers(disconnectedSubscribersRequestInfo);

        assertEquals(counter, (long)disconnectedSubscribersResponseInfo.getBody().getSubscribersCount());
    }

    @Test
    public void testGetDisconnectedSubscribers_FindByOldRequest() {
        Mockito.when(credentialsValidator.isCredentialsValid(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        requestBody.setOldRquestId(new Random().nextLong());
        disconnectedSubscribersRequestInfo.setBody(requestBody);
        List<RemovedSubscriber> events = new ArrayList<>();
        final int counter = 3;

        for (int i = 0; i < counter; i++) {
            events.add(new RemovedSubscriberStub());
        }

        Mockito.when(subscriberEventsRepository.findByRequestId(Mockito.any())).thenReturn(events);

        DisconnectedSubscribersResponseInfo disconnectedSubscribersResponseInfo = disconnectedSubscribersService
                .getDisconnectedSubscribers(disconnectedSubscribersRequestInfo);

        assertEquals(counter, (long)disconnectedSubscribersResponseInfo.getBody().getSubscribersCount());
    }

    @Test
    public void testGetDisconnectedSubscribers_FindByOldRequestError() {
        Mockito.when(credentialsValidator.isCredentialsValid(Mockito.anyString(), Mockito.anyString())).thenReturn(true);
        requestBody.setOldRquestId(new Random().nextLong());
        disconnectedSubscribersRequestInfo.setBody(requestBody);
        Mockito.when(subscriberEventsRepository.findByRequestId(Mockito.any())).thenReturn(Collections.emptyList());

        DisconnectedSubscribersResponseInfo disconnectedSubscribersResponseInfo = disconnectedSubscribersService
                .getDisconnectedSubscribers(disconnectedSubscribersRequestInfo);

        assertEquals(INITIAL_REQUEST_NOT_FOUND_ERROR, disconnectedSubscribersResponseInfo.getBody().getOperationResult());
    }
}
