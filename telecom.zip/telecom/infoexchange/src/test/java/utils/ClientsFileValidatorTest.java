package utils;

import com.sbtele.infoexchange.utils.ClientsFileValidationResult;
import com.sbtele.infoexchange.utils.ClientsFileValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static com.sbtele.infoexchange.utils.ClientsFileValidationErrorCode.*;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

@RunWith(SpringRunner.class)
public class ClientsFileValidatorTest {

    private Path filename = Paths.get("X.00000000000002.000000000.clients");
    private String currentVersion =  "00000000000001";

    @Test
    public void testValidate() throws Exception {
        Files.createFile(filename);
        ClientsFileValidationResult validationResult = ClientsFileValidator.validate(filename, currentVersion);
        assertTrue(validationResult.isValid());
        Files.deleteIfExists(filename);
    }

    @Test
    public void testValidate_VersionError() {
        currentVersion = "00000000000003";
        ClientsFileValidationResult validationResult = ClientsFileValidator.validate(filename, currentVersion);
        assertEquals(FILE_VERSION_ERROR.getErrorCode(), validationResult.getErrorCode());
        assertEquals(FILE_VERSION_ERROR.getErrorDescription(), validationResult.getErrorDescription());
    }

    @Test
    public void testValidate_PatternError() {
        filename = Paths.get("X.00000000000002.000.clients");
        ClientsFileValidationResult validationResult = ClientsFileValidator.validate(filename, currentVersion);
        assertEquals(FILE_NAME_PATTERN_ERROR.getErrorCode(), validationResult.getErrorCode());
        assertEquals(FILE_NAME_PATTERN_ERROR.getErrorDescription(), validationResult.getErrorDescription());
    }

    @Test
    public void testValidate_LineNumberError() throws Exception {
        filename = Paths.get("X.00000000000002.000000001.clients");
        Files.createFile(filename);
        ClientsFileValidationResult validationResult = ClientsFileValidator.validate(filename, currentVersion);
        assertEquals(MISMATCHED_LINES_NUMBER_ERROR.getErrorCode(), validationResult.getErrorCode());
        assertEquals(MISMATCHED_LINES_NUMBER_ERROR.getErrorDescription(), validationResult.getErrorDescription());
        Files.deleteIfExists(filename);
    }

    @Test
    public void testValidate_IoError() {
        ClientsFileValidationResult validationResult = ClientsFileValidator.validate(filename, currentVersion);
        assertEquals(FILE_IO_ERROR.getErrorCode(), validationResult.getErrorCode());
        assertEquals(FILE_IO_ERROR.getErrorDescription(), validationResult.getErrorDescription());
    }
}
