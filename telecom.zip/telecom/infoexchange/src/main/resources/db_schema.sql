create table bl_t_inex_system_users (
    id number(20) not null,
    login varchar2(32) not null unique,
    password varchar2(256) not null,
    description varchar2(256),
    created_at timestamp default sysdate not null,
    constraint inex_system_users_pk primary key (id)
);

CREATE SEQUENCE bl_q_inex_system_users
  MINVALUE 1
  MAXVALUE 9999999999
  START WITH 1
  INCREMENT BY 1;

create table bl_t_inex_sbb_watchlist (
    id number(20) not null,
    msisdn number(20) not null,
    changed_at timestamp not null,
    start_watch timestamp not null,
    end_watch timestamp null,
    csv_version varchar2(32) not null,
    constraint inex_sbb_watchlist_pk primary key (id)
);

create index inex_sbb_watchlist_uk_i on bl_t_inex_sbb_watchlist (msisdn);

CREATE SEQUENCE bl_q_inex_sbb_watchlist
  MINVALUE 1
  MAXVALUE 9999999999
  START WITH 1
  INCREMENT BY 1;

create table bl_t_inex_sbb_subscriber_events (
    id number(20) not null,
    msisdn number(20) not null,
    reason number(20) not null,
    priority number(1) not null,
    disconnected_at timestamp not null,
    available_at timestamp not null,
    request_id number(20),
    constraint inex_sbb_subscriber_events_pk primary key (id)
);

CREATE SEQUENCE bl_q_inex_sbb_subscriber_events
  MINVALUE 1
  MAXVALUE 9999999999
  START WITH 1
  INCREMENT BY 1;

create table bl_t_inex_sbb_billed_msisdn(
    id number(20) not null,
    msisdn number(20) not null unique,
    constraint inex_sbb_billed_msisdn_pk primary key (id)
);

create index inex_sbb_billed_msisdn_uk_i on bl_t_inex_sbb_billed_msisdn (msisdn);

CREATE SEQUENCE bl_q_inex_sbb_billed_msisdn
  MINVALUE 1
  MAXVALUE 9999999999
  START WITH 1
  INCREMENT BY 1;

commit;