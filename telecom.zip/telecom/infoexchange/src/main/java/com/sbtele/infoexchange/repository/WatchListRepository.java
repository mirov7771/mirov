package com.sbtele.infoexchange.repository;

import com.sbtele.infoexchange.repository.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface WatchListRepository extends JpaRepository<Client, Long> {
    Optional<Client> findByMsisdnAndEndWatchIsNull(String msisdn);
    Optional<Client> findTopByOrderByCsvVersionDesc();

    @Transactional void deleteByEndWatchBefore(Date beforeDate);

    @Query("FROM Client c WHERE c.csvVersion <> ?1 AND c.startWatch < ?2 AND c.endWatch IS NULL")
    List<Client> findAllEndWatchClients(String version, Date startCsvProcessingTime);

    @Query(value = "select * from BL_T_INEX_SBB_WATCHLIST where MSISDN in (:msisdns) and END_WATCH is null", nativeQuery = true)
    List<Client> findByMsisdnInAndEndWatchIsNull(List<String> msisdns);
}