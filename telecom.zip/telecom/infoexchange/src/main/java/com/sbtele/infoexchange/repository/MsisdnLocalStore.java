package com.sbtele.infoexchange.repository;

import com.sbtele.infoexchange.config.CsvProperties;
import com.sbtele.infoexchange.repository.model.BilledMsisdn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class MsisdnLocalStore {
    private static final Logger LOGGER = LoggerFactory.getLogger(MsisdnLocalStore.class);

    @Autowired
    private CsvProperties csvProperties;

    @Autowired
    private MsisdnRepository msisdnRepository;

    @PostConstruct
    public void postConstruct() throws IOException {
        Optional<BilledMsisdn> optMsisdn = msisdnRepository.findTopByOrderByMsisdn();

        if(optMsisdn.isPresent()) {
            LOGGER.info("Skip MSISDN import from file, already done");
        } else {
            LOGGER.info("Start MSISDN import from file ...");
            Stream<String> stream = Files.lines(Paths.get(csvProperties.getDirectory(), csvProperties.getMsisdnImportFile()));
            stream.forEach(s -> msisdnRepository.save(new BilledMsisdn(s)));
            LOGGER.info("Complete MSISDN import from file");
        }
    }

    public void add(String msisdn) {
        LOGGER.debug("Add MSISDN [{}]", msisdn);
        msisdnRepository.save(new BilledMsisdn(msisdn));
    }

    public void addAll(List<String> msisdns){
        LOGGER.debug("Add MSISDNs [{}]", msisdns);
        List<BilledMsisdn> list = msisdnRepository.findByMsisdnIn(msisdns);
        if (!CollectionUtils.isEmpty(list)) {
            List<String> listDb = list.stream().map(BilledMsisdn::getMsisdn).collect(Collectors.toList());
            msisdns = msisdns.stream().filter(i -> !listDb.contains(i)).collect(Collectors.toList());
        }
        msisdnRepository.saveAll(msisdns.stream().map(BilledMsisdn::new).collect(Collectors.toList()));
    }

    public void remove(String msisdn) {
        LOGGER.debug("Remove MSISDN [{}]", msisdn);
        msisdnRepository.deleteByMsisdn(msisdn);
    }

    public boolean exist(String msisdn) {
        boolean result = false;
        Optional<BilledMsisdn> optMsisdn = msisdnRepository.findByMsisdn(msisdn);

        if(optMsisdn.isPresent()) {
            result = true;
        }
        LOGGER.debug("MSISDN [{}] exist in local store: {}", msisdn, result);
        return result;
    }

    public List<BilledMsisdn> findList(List<String> msisdns){
        return msisdnRepository.findByMsisdnIn(msisdns);
    }
}
