package com.sbtele.infoexchange.csv;

import com.sbtele.infoexchange.csv.model.CsvRow;

public interface CsvWriter {
    public void write(CsvRow csvRow);
}
