package com.sbtele.infoexchange.utils;

public class ClientsFileValidationResult {
    private boolean isValid;
    private long errorCode;
    private String errorDescription;

    public boolean isValid() {
        return isValid;
    }

    public ClientsFileValidationResult setValid(boolean isValid) {
        this.isValid = isValid;
        return this;
    }

    public long getErrorCode() {
        return errorCode;
    }

    public ClientsFileValidationResult setErrorCode(long errorCode) {
        this.errorCode = errorCode;
        return this;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public ClientsFileValidationResult setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
        return this;
    }

    public ClientsFileValidationResult setError(ClientsFileValidationErrorCode error) {
        this.errorCode = error.getErrorCode();
        this.errorDescription = error.getErrorDescription();
        return this;
    }

    @Override
    public String toString() {
        return "ValidationResult{" +
                "isValid=" + isValid +
                ", errorCode=" + errorCode +
                ", errorDescription='" + errorDescription + '\'' +
                '}';
    }
}
