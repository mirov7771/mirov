package com.sbtele.infoexchange.webservice;

import com.sbtele.infoexchange.repository.SubscriberEventsRepository;
import com.sbtele.infoexchange.repository.model.RemovedSubscriber;
import com.sbtele.infoexchange.xml.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.jws.WebService;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static com.sbtele.infoexchange.xml.XmlConstants.DisconnectedSubscribersOperationResults.*;

@Service
@WebService(name = "Sberbank_GetDisconnectedSubscribers",
        portName = "Sberbank_GetDisconnectedSubscribersPort",
        endpointInterface = "com.sbtele.infoexchange.webservice.DisconnectedSubscribersService")
public class DisconnectedSubscribersServiceImpl implements DisconnectedSubscribersService {
    private static final Long INITIAL_REQUEST = 0L;
    private static final int PAGE_SIZE = 10_000;
    private static final Logger LOGGER = LoggerFactory.getLogger(DisconnectedSubscribersService.class);

    @Autowired
    private CredentialsValidator credentialsValidator;

    @Autowired
    private SubscriberEventsRepository subscriberEventsRepository;

    @Override
    public DisconnectedSubscribersResponseInfo getDisconnectedSubscribers(DisconnectedSubscribersRequestInfo requestInfo) {
        DisconnectedSubscribersResponseInfo responseInfo = new DisconnectedSubscribersResponseInfo();
        DisconnectedSubscribersResponseBody body = new DisconnectedSubscribersResponseBody();

        if(null == requestInfo.getBody().getRequestId()) {
            body.setOperationResult(OPERATION_RESULT_OTHER_ERROR);
            body.setErrorDescription(OPERATION_RESULT_ID_ERROR_DESCRIPTION);
            responseInfo.setBody(body);
            return responseInfo;
        }

        if(null == requestInfo.getBody().getOldRquestId()) {
            body.setOperationResult(OPERATION_RESULT_OTHER_REPEAT_ERROR);
            body.setErrorDescription(OPERATION_RESULT_OLD_ID_ERROR_DESCRIPTION);
            responseInfo.setBody(body);
            return responseInfo;
        }

        if (!credentialsValidator.isCredentialsValid(requestInfo.getBody().getLogin(), requestInfo.getBody().getPassword())) {
            if (requestInfo.getBody().getOldRquestId().equals(0L)) {
                body.setOperationResult(OPERATION_RESULT_CREDENTIALS_ERROR);
            } else {
                body.setOperationResult(OPERATION_RESULT_CREDENTIALS_REPEAT_ERROR);
            }
            body.setErrorDescription(OPERATION_RESULT_CREDENTIALS_ERROR_DESCRIPTION);
            LOGGER.warn("Incorrect credentials web service access attempt: {}/{}", requestInfo.getBody().getLogin(), requestInfo.getBody().getPassword());
            responseInfo.setBody(body);
            return responseInfo;
        }

        processDisconnectedSubscribers(requestInfo, body);
        responseInfo.setBody(body);
        return responseInfo;
    }

    private void processDisconnectedSubscribers(DisconnectedSubscribersRequestInfo requestInfo,
                                                DisconnectedSubscribersResponseBody responseInfo) {
        Long requestId = requestInfo.getBody().getRequestId();
        Long oldRequestId = requestInfo.getBody().getOldRquestId();
        boolean isInitialRequest = INITIAL_REQUEST.equals(oldRequestId);
        List<Subscriber> disconnectedSubscribers;

        if(isInitialRequest) {
            disconnectedSubscribers = processInitialRequest(requestId);
            setResponseInfo(responseInfo, disconnectedSubscribers);
            return;
        }

        disconnectedSubscribers = processRepeatRequest(oldRequestId);
        if(0 == disconnectedSubscribers.size()) {
            responseInfo.setOperationResult(INITIAL_REQUEST_NOT_FOUND_ERROR);
            LOGGER.debug("Initial request {} not found", oldRequestId);
            return;
        }

        setResponseInfo(responseInfo, disconnectedSubscribers);
    }

    private List<Subscriber> processInitialRequest(Long requestId) {
        Pageable firstPage = PageRequest.of(0, PAGE_SIZE);
        List<RemovedSubscriber> disconnectedRemoveSubscriberEvents = subscriberEventsRepository.findSubscriberEvents(firstPage);
        List<Subscriber> disconnectedSubscribers = new ArrayList<>();

        if (!CollectionUtils.isEmpty(disconnectedRemoveSubscriberEvents)) {
            List<RemovedSubscriber> listForUpdate = new ArrayList<>();
            disconnectedRemoveSubscriberEvents.sort(Comparator.comparing(RemovedSubscriber::getPriority));
            for (RemovedSubscriber removeSubscriberEvent : disconnectedRemoveSubscriberEvents) {
                Subscriber subscriber = new Subscriber(removeSubscriberEvent);
                disconnectedSubscribers.add(subscriber);
                removeSubscriberEvent.setRequestId(requestId);
                listForUpdate.add(removeSubscriberEvent);
            }

            CompletableFuture.runAsync(() -> subscriberEventsRepository.saveAll(listForUpdate));
        }

        return disconnectedSubscribers;
    }

    private List<Subscriber> processRepeatRequest(Long oldRequestId) {
        List<RemovedSubscriber> disconnectedRemoveSubscriberEvents = subscriberEventsRepository.findByRequestId(oldRequestId);
        List<Subscriber> disconnectedSubscribers = new ArrayList<>();

        if (!CollectionUtils.isEmpty(disconnectedRemoveSubscriberEvents)) {
            disconnectedRemoveSubscriberEvents.sort(Comparator.comparing(RemovedSubscriber::getPriority));
            for (RemovedSubscriber removeSubscriberEvent : disconnectedRemoveSubscriberEvents) {
                Subscriber subscriber = new Subscriber(removeSubscriberEvent);
                disconnectedSubscribers.add(subscriber);
            }
        }

        return disconnectedSubscribers;
    }

    private void setResponseInfo(DisconnectedSubscribersResponseBody responseInfo,
                                 List<Subscriber> disconnectedSubscribers) {
        Subscribers subscribers = new Subscribers();
        subscribers.setSubscribers(disconnectedSubscribers);
        responseInfo.setOperationResult(OPERATION_RESULT_SUCCESS);
        responseInfo.setSubscribers(subscribers);
        responseInfo.setSubscribersCount((long) disconnectedSubscribers.size());
    }
}