package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.*;

@XmlRootElement(namespace = "http://webserv.my/")
@XmlType(propOrder = {"body"})
@XmlAccessorType(XmlAccessType.FIELD)
public class NewClientsRequestInfo {
	@XmlElement(name="body", required=true)
	private NewClientRequestBody body;

	public NewClientRequestBody getBody() {
		return body;
	}

	public void setBody(NewClientRequestBody body) {
		this.body = body;
	}
}
