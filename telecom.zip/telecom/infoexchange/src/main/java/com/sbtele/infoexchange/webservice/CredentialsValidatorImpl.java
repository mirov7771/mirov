package com.sbtele.infoexchange.webservice;

import com.sbtele.infoexchange.repository.SystemRepository;
import com.sbtele.infoexchange.repository.model.SystemUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CredentialsValidatorImpl implements CredentialsValidator{
    @Autowired
    private SystemRepository systemRepository;

    public boolean isCredentialsValid(String login, String password) {
        Optional<SystemUser> user = systemRepository.findByLoginAndPassword(login, password);
        return user.isPresent();
    }
}
