package com.sbtele.infoexchange.csv;

public class CsvConstants {
    public static final char SEPARATOR = ',';
    public static final String CLIENTS_EXTENSION = ".clients";
    public static final String ERROR_EXTENSION = ".error";
    public static final String RESULTS_EXTENSION = ".results";
    public static final String SNAPSHOT_EXTENSION = ".snapshot";
    public static final String TMP_EXTENSION = ".tmp";
    public static final String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String LINE_NUMBER_FORMAT = ".%09d";

    private CsvConstants() {
        throw new IllegalStateException("Can't instantiate Constants class");
    }
}
