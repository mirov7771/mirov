package com.sbtele.infoexchange.repository.model;

public interface BillingItem {
}
