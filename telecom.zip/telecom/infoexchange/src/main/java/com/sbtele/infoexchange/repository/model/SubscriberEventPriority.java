package com.sbtele.infoexchange.repository.model;

public enum SubscriberEventPriority {
    PRIORITY_HIGH(0),
    PRIORITY_NORMAL(1),
    PRIORITY_LOW(2);

    private Integer priority;

    SubscriberEventPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer get() {
        return priority;
    }
}
