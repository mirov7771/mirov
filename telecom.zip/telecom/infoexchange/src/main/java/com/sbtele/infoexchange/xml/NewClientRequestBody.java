package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.*;

@XmlRootElement(namespace = "http://webserv.my/")
@XmlType(propOrder = {"login", "password", "requestId", "fullListNeeded", "clientsToAdd"})
@XmlAccessorType(XmlAccessType.FIELD)
public class NewClientRequestBody {

    @XmlElement(name="Login", required=true)
    private String login;

    @XmlElement(name="Pwd", required=true)
    private String password;

    @XmlElement(name="RequestId", required=true)
    private long requestId;

    @XmlElement(name="FullListNeeded", required=true)
    private long fullListNeeded;

    @XmlElement(name="ClientsToAdd", required=true)
    private ClientsToAdd clientsToAdd;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getRequestId() {
        return requestId;
    }

    public void setRequestId(long requestId) {
        this.requestId = requestId;
    }

    public long getFullListNeeded() {
        return fullListNeeded;
    }

    public void setFullListNeeded(long fullListNeeded) {
        this.fullListNeeded = fullListNeeded;
    }

    public ClientsToAdd getClientsToAdd() {
        return clientsToAdd;
    }

    public void setClientsToAdd(ClientsToAdd clientsToAdd) {
        this.clientsToAdd = clientsToAdd;
    }

    @Override
    public String toString() {
        return "NewClientRequestBody{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", requestId=" + requestId +
                ", fullListNeeded=" + fullListNeeded +
                ", clientsToAdd=" + clientsToAdd +
                '}';
    }
}
