package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class ClientResult {
	@XmlElement(name="MSISDN")
	private String msisdn;

	@XmlElement(name="Result")
	private Long result;


	public String getMsisdn() {
		return msisdn;
	}
	
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public Long getResult() {
		return result;
	}
	
	public void setResult(Long result) {
		this.result = result;
	}
	
	@Override
	public String toString() {
		return "ClientResult [MSISDN=" + msisdn + ", result=" + result + "]";
	}
}
