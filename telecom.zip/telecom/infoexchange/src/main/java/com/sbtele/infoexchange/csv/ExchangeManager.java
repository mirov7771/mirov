package com.sbtele.infoexchange.csv;

import com.sbtele.infoexchange.billing.BillingService;
import com.sbtele.infoexchange.config.CsvProperties;
import com.sbtele.infoexchange.csv.model.ClientsRow;
import com.sbtele.infoexchange.csv.model.ClientsRowInfo;
import com.sbtele.infoexchange.csv.model.ResultsRowInfo;
import com.sbtele.infoexchange.repository.MsisdnLocalStore;
import com.sbtele.infoexchange.repository.WatchListRepository;
import com.sbtele.infoexchange.repository.model.Client;
import com.sbtele.infoexchange.utils.ClientsFileValidationResult;
import com.sbtele.infoexchange.utils.ClientsFileValidator;
import com.sbtele.infoexchange.utils.FormatValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static com.sbtele.infoexchange.csv.CsvConstants.*;
import static com.sbtele.infoexchange.csv.model.ClientResultCode.*;
import static com.sbtele.infoexchange.utils.ClientsFileValidationErrorCode.FILE_IO_ERROR;
import static com.sbtele.infoexchange.utils.ClientsFileValidationErrorCode.UNSATISFACTORY_RATIO_EXCEED_ERROR;
import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

@Service
public class ExchangeManager {

    @Autowired
    private CsvProperties csvProperties;

    @Autowired
    private WatchListRepository watchListRepository;

    @Autowired
    private BillingService billingService;

    @Autowired
    private MsisdnLocalStore msisdnLocalStore;

    private static final String INITIAL_VERSION = "0";
    private String newVersion;
    private Date startCsvProcessingTime;
    private static double unsuccessfulRequests = 0L;
    private static long totalRequests = 0L;

    private static final Logger LOGGER = LoggerFactory.getLogger(ExchangeManager.class);

    @Async
    public void doExchange(Path fullPath) {
        String filename = fullPath.getFileName().toString();
        startCsvProcessingTime = new Date();

        if (!filename.endsWith(CLIENTS_EXTENSION)) {
            return;
        }

        String currentVersion = INITIAL_VERSION;
        Optional<Client> optClient = watchListRepository.findTopByOrderByCsvVersionDesc();
        if (optClient.isPresent()) {
            currentVersion = optClient.get().getCsvVersion();
            LOGGER.info("Version set to {}", currentVersion);
        } else {
            LOGGER.warn("No data found in watch list. Version set to {}", INITIAL_VERSION);
        }

        ClientsFileValidationResult clientsFileValidationResult = ClientsFileValidator.validate(fullPath, currentVersion);
        LOGGER.debug("File name validation result is: {}", clientsFileValidationResult.toString());

        if(!clientsFileValidationResult.isValid()) {
            writeError(filename, clientsFileValidationResult);
            LOGGER.error("File {} has validation error {}", filename, clientsFileValidationResult);
            return;
        }

        newVersion = filename.split("[.]")[1];
        processClientsCsv(filename);
    }

    private void processClientsCsv(String clientsFilename) {
        LOGGER.info("Start clients csv processing ...");
        Path readPath = Paths.get(csvProperties.getDirectory(), clientsFilename);
        String tmpFilename = clientsFilename.replaceAll(CLIENTS_EXTENSION, TMP_EXTENSION);
        Path tmpPath = Paths.get(csvProperties.getDirectory(), tmpFilename);

        try(CsvFileReader csvFileReader = new CsvFileReader(readPath, ClientsRow.class);
            CsvFileWriter csvFileWriter = new CsvFileWriter(tmpPath)) {
            writeActiveClients(csvFileReader, csvFileWriter);
            writeEndWatchClients(csvFileWriter);
        } catch (UncheckedIOException ioe) {
            ClientsFileValidationResult clientsFileValidationResult = new ClientsFileValidationResult()
                    .setError(FILE_IO_ERROR);
            writeError(clientsFilename, clientsFileValidationResult);
        } catch(UnsatisfactoryRequestsRatioException ex) {
            ClientsFileValidationResult clientsFileValidationResult = new ClientsFileValidationResult()
                    .setError(UNSATISFACTORY_RATIO_EXCEED_ERROR);
            writeError(clientsFilename, clientsFileValidationResult);
        } finally {
            if (Files.exists(tmpPath)) {
                copyFile(tmpFilename);
                deleteFile(tmpFilename);
            }
            LOGGER.info("End clients csv processing ...");
        }
    }

    private void writeActiveClients(CsvFileReader csvFileReader, CsvFileWriter csvFileWriter)
            throws UnsatisfactoryRequestsRatioException {
        ClientsRowInfo clientsRowInfo = new ClientsRowInfo();
        while(csvFileReader.hasNext()) {
            clientsRowInfo.setRow(csvFileReader.next());
            ResultsRowInfo resultsRowInfo = processClient(clientsRowInfo);

            if (!isSatisfactoryUnknownRequestsRatio()) {
                throw new UnsatisfactoryRequestsRatioException();
            }
            csvFileWriter.write(resultsRowInfo.getResultsRow());
        }
    }

    private ResultsRowInfo processClient(ClientsRowInfo clientsRowInfo) {
        String msisdn = clientsRowInfo.getMsisdn();
        Date changedAt = clientsRowInfo.getChangedAt();

        if(null == changedAt) {
            return new ResultsRowInfo()
                    .setMsisdn(msisdn)
                    .setClientResult(WRONG_DATE_FORMAT);
        }

        if(!FormatValidator.isMsisdnValid(msisdn)) {
            return new ResultsRowInfo()
                    .setMsisdn(msisdn)
                    .setClientResult(MSISDN_INCORRECT_FORMAT);
        }

        return saveOrUpdateClient(clientsRowInfo);
    }

    private ResultsRowInfo saveOrUpdateClient(ClientsRowInfo clientsRowInfo) {
        String msisdn = clientsRowInfo.getMsisdn();
        Date changedAt = clientsRowInfo.getChangedAt();
        Optional<Client> optClient = watchListRepository.findByMsisdnAndEndWatchIsNull(msisdn);

        if (optClient.isPresent()) {
            LOGGER.debug("Update subscriber with MSISDN [{}]", msisdn);
            Client client = optClient.get();
            if (changedAt.after(client.getChangedAt())) {
                client.setChangedAt(changedAt);
            }

            client.setCsvVersion(newVersion);
            watchListRepository.save(client);
            return new ResultsRowInfo()
                    .setMsisdn(msisdn)
                    .setClientResult(SUCCESS_ALREADY_EXIST);
        }

        if (!isMsisdnExist(msisdn)) {
            LOGGER.debug("Subscriber with MSISDN [{}] does not exist", msisdn);
            return new ResultsRowInfo()
                    .setMsisdn(msisdn)
                    .setClientResult(UNKNOWN_SUBSCRIBER);
        }

        LOGGER.debug("Add subscriber with MSISDN [{}]", msisdn);
        Client client = new Client();
        client.setMsisdn(msisdn);
        client.setChangedAt(changedAt);
        client.setStartWatch(new Date());
        client.setCsvVersion(newVersion);
        watchListRepository.save(client);
        return new ResultsRowInfo()
                .setMsisdn(msisdn)
                .setChangedAt(new Date())
                .setClientResult(SUCCESS_ADDED_TO_LIST);
    }

    private void writeEndWatchClients(CsvFileWriter csvFileWriter) {
        List<Client> clientsToEndWatch = watchListRepository.findAllEndWatchClients(newVersion, startCsvProcessingTime);
        ResultsRowInfo resultsRowInfo = new ResultsRowInfo();

        for(Client clientToEndWatch : clientsToEndWatch) {
            clientToEndWatch.setEndWatch(new Date());
            watchListRepository.save(clientToEndWatch);
            resultsRowInfo.setMsisdn(clientToEndWatch.getMsisdn())
                    .setChangedAt(new Date())
                    .setClientResult(SUCCESS_REMOVED_FROM_LIST);
            csvFileWriter.write(resultsRowInfo.getResultsRow());
        }
    }

    private void writeError(String filename, ClientsFileValidationResult clientsFileValidationResult) {
        String errorFilename = filename.replaceAll(CLIENTS_EXTENSION, ERROR_EXTENSION);
        Path errorFilePath = Paths.get(csvProperties.getDirectory(), errorFilename);

        try(CsvFileWriter csvFileWriter = new CsvFileWriter(errorFilePath)) {
            ResultsRowInfo errorInfo = new ResultsRowInfo();
            errorInfo.setResultCode(clientsFileValidationResult.getErrorCode()).setErrorDescription(clientsFileValidationResult.getErrorDescription());
            csvFileWriter.write(errorInfo.getResultsRow());
        }
    }

    private void copyFile(String filename) {
        String resultsFilename = filename.replaceAll(TMP_EXTENSION, RESULTS_EXTENSION);
        Path resultsPath = Paths.get(csvProperties.getDirectory(), resultsFilename);
        Path tmpPath = Paths.get(csvProperties.getDirectory(), filename);

        try {
            Files.copy(tmpPath, resultsPath, REPLACE_EXISTING);
        } catch (IOException ioe) {
            LOGGER.error("Error moving file {} to {}", filename, resultsFilename);
            throw new UncheckedIOException(ioe);
        }
    }

    private void deleteFile(String filename) {
        Path path = Paths.get(csvProperties.getDirectory(), filename);

        try {
            Files.delete(path);
        } catch (IOException ioe) {
            LOGGER.error("Failed to delete file {}", filename, ioe);
        }
    }

    private boolean isMsisdnExist(String msisdn) {
        totalRequests++;
        if(msisdnLocalStore.exist(msisdn)) {
            return true;
        }

        if(billingService.isSubscriberExist(msisdn)) {
            msisdnLocalStore.add(msisdn);
            return true;
        }

        unsuccessfulRequests++;
        return false;
    }

    // Protection method against file with non-SberMobile subscribers
    private boolean isSatisfactoryUnknownRequestsRatio() {
        boolean result = true;
        double thresholdRatio = csvProperties.getSuccessThreshold();

        if (totalRequests >= csvProperties.getLinesToCheck()) {
                double currentRatio = 1 - unsuccessfulRequests/totalRequests;
                LOGGER.debug("Current unknown MSISDN ratio: {}, thresholdRatio: {}", currentRatio, thresholdRatio);
                result =  currentRatio > thresholdRatio;
                totalRequests = 0L;
                unsuccessfulRequests = 0;
        }
        return result;
    }
}
