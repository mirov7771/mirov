package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.*;

@XmlRootElement(namespace = "http://webserv.my/")
@XmlType(propOrder = {"body"})
@XmlAccessorType(XmlAccessType.FIELD)
public class DisconnectedSubscribersRequestInfo {
	@XmlElement(name="body", required=true)
	private DisconnectedSubscribersRequestBody body;

	public DisconnectedSubscribersRequestBody getBody() {
		return body;
	}

	public void setBody(DisconnectedSubscribersRequestBody body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return "DisconnectedSubscribersRequestInfo{" +
				"body=" + body +
				'}';
	}
}
