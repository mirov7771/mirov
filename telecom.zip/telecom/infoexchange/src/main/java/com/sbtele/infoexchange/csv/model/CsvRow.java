package com.sbtele.infoexchange.csv.model;

public interface CsvRow {
}
