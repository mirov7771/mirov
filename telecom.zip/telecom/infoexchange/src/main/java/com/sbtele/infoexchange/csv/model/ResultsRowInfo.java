package com.sbtele.infoexchange.csv.model;

import com.sbtele.infoexchange.utils.StringDateConverter;

import java.util.Date;

public class ResultsRowInfo {
    private ResultsRow resultsRow = new ResultsRow();

    public String getMsisdn() {
        return resultsRow.getMsisdnColumn();
    }

    public ResultsRowInfo setMsisdn(String msisdnColumn) {
        resultsRow.setMsisdnColumn(msisdnColumn);
        return this;
    }

    public String getChangedAt() {
        return resultsRow.getChangedAtColumn();
    }

    public ResultsRowInfo setChangedAt(String changedAtColumn) {
        resultsRow.setChangedAtColumn(changedAtColumn);
        return this;
    }

    public long getResultCode() {
        return resultsRow.getResultCodeColumn();
    }

    public ResultsRowInfo setResultCode(long resultCode) {
        resultsRow.setResultCodeColumn(resultCode);
        return this;
    }

    public String getErrorDescription() {
        return resultsRow.getErrorDescriptionColumn();
    }

    public ResultsRowInfo setErrorDescription(String errorDescriptionColumn) {
        resultsRow.setErrorDescriptionColumn(errorDescriptionColumn);
        return this;
    }

    public ResultsRowInfo setChangedAt(Date changedAt) {
        resultsRow.setChangedAtColumn(StringDateConverter.dateToString(changedAt));
        return this;
    }

    public ResultsRowInfo setClientResult(ClientResultCode clientResultCode) {
        resultsRow.setResultCodeColumn(clientResultCode.getCode());
        resultsRow.setErrorDescriptionColumn(clientResultCode.getErrorDescription());
        return this;
    }

    public ResultsRow getResultsRow() {
        return resultsRow;
    }
}


