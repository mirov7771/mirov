package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class DisconnectedSubscribersResponseInfo {
	@XmlElement(name="body")
	private DisconnectedSubscribersResponseBody body;

	public DisconnectedSubscribersResponseBody getBody() {
		return body;
	}

	public void setBody(DisconnectedSubscribersResponseBody body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return "DisconnectedSubscribersResponseInfo{" +
				"body=" + body +
				'}';
	}
}
