package com.sbtele.infoexchange.csv.model;

import com.opencsv.bean.CsvBindByPosition;

public class ClientsRow implements CsvRow {

    @CsvBindByPosition(position = 0)
    private String msisdnColumn;

    @CsvBindByPosition(position = 1)
    private String changedAtColumn;

    String getMsisdnColumn() {
        return msisdnColumn;
    }

    void setMsisdnColumn(String msisdnColumn) {
        this.msisdnColumn = msisdnColumn;
    }

    String getChangedAtColumn() {
        return changedAtColumn;
    }

    void setChangedAtColumn(String changedAtColumn) {
        this.changedAtColumn = changedAtColumn;
    }
}
