package com.sbtele.infoexchange.csv;

public class UnsatisfactoryRequestsRatioException extends Exception {
    public UnsatisfactoryRequestsRatioException() {
        super();
    }
}
