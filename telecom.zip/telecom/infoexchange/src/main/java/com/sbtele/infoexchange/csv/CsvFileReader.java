package com.sbtele.infoexchange.csv;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.sbtele.infoexchange.csv.model.ClientsRow;
import com.sbtele.infoexchange.csv.model.CsvRow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class CsvFileReader implements CsvReader, AutoCloseable {
    private Iterator<?> readIterator;
    private Reader reader;
    private Path fullPath;

    private static final Logger LOGGER = LoggerFactory.getLogger(CsvFileReader.class);

    public CsvFileReader(Path fullPath, Class<? extends CsvRow> csvTemplate) {
        this.fullPath = fullPath;

        try {
            reader = Files.newBufferedReader(fullPath);
            LOGGER.debug("Reading file {}", fullPath.toString());
        } catch(IOException ioe) {
            LOGGER.error("Input file [" + fullPath.toString() + "] read error", ioe);
            throw new UncheckedIOException(ioe);
        }

        CsvToBean<?> csvToBeanBuilder = new CsvToBeanBuilder<>(reader)
                .withType(csvTemplate)
                .withSeparator(CsvConstants.SEPARATOR)
                .withIgnoreLeadingWhiteSpace(true)
                .build();

        readIterator = csvToBeanBuilder.iterator();
    }

    @Override
    public ClientsRow next() {
        if(readIterator.hasNext()) {
            return (ClientsRow) readIterator.next();
        } else {
            LOGGER.error("No data available for next iteration");
            throw new NoSuchElementException();
        }
    }

    @Override
    public boolean hasNext() {
        return readIterator.hasNext();
    }

    @Override
    public void close() {
        try{
             reader.close();
        } catch(IOException ioe) {
            LOGGER.error("Input file [" + fullPath.toString() + "] error on close attempt", ioe);
            throw new UncheckedIOException(ioe);
        }
    }
}
