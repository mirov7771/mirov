package com.sbtele.infoexchange.billing;

import com.bercut.schema.dsi_crm_accountmanagement.GetSubscriberInfoRequest;
import com.bercut.schema.dsi_crm_accountmanagement.GetSubscriberInfoResponse;
import com.bercut.schema.dsi_crm_simpleelements.FilterSubscriber;
import com.bercut.wsdl.dsi_crm_accountmanagement.AccountManagementPortType;
import com.bercut.wsdl.dsi_crm_accountmanagement.AccountManagementPortTypeService;
import com.bercut.wsdl.dsi_crm_accountmanagement.ExceptionCRM;
import com.sbtele.infoexchange.config.BillingProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.xml.ws.WebServiceException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;

@Service
public class BercutWSClient {
    private static int NORMALIZED_MSISDN_LENGTH = 10;
    private static BigDecimal BRANCH_ID = new BigDecimal(0);
    private static final Logger LOGGER = LoggerFactory.getLogger(BercutWSClient.class);

    @Autowired
    private BillingProperties billingProperties;
    private AccountManagementPortType serverPort;

    public GetSubscriberInfoResponse getSubscriberInfo(String inMsisdn) throws ExceptionCRM {
        String msisdn = normalizeMsisdn(inMsisdn);
        GetSubscriberInfoRequest parameters = new GetSubscriberInfoRequest();
        parameters.setBranchId(BRANCH_ID);
        FilterSubscriber filterSubscriber = new FilterSubscriber();
        filterSubscriber.setMsisdn(msisdn);
        parameters.setFilterSubscriber(filterSubscriber);
        return serverPort.getSubscriberInfo(parameters);
    }

    /**
     * Normalize MSISDN to NDC+SN format (10 digits in Russia), according to Bercut API requirement
     */
    private String normalizeMsisdn(String inMsisdn) {
        String normalized = "";

        if (inMsisdn.length() > NORMALIZED_MSISDN_LENGTH) {
            normalized = inMsisdn.substring(inMsisdn.length() - NORMALIZED_MSISDN_LENGTH);
        } else {
            normalized = inMsisdn;
        }

        return normalized;
    }

    @PostConstruct
    private void postConstruct() {
        URL wsUrl = null;

        try {
            wsUrl = new URL(billingProperties.getBercutWsdlLocation());
            serverPort = new AccountManagementPortTypeService(wsUrl).getAccountManagementPortTypePort();
        } catch (MalformedURLException ex) {
            LOGGER.error("Cannot start service due to malformed URL");
            throw new IllegalStateException(ex);
        } catch (WebServiceException wse) {
            LOGGER.error("Can't connect to {}", wsUrl);
            throw new IllegalStateException(wse);
        }
    }
}
