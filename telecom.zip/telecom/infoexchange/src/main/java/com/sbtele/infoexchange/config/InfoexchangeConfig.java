package com.sbtele.infoexchange.config;

import com.sbtele.infoexchange.billing.JmsErrorHandler;
import com.sbtele.infoexchange.webservice.DisconnectedSubscribersService;
import com.sbtele.infoexchange.webservice.NewClientsService;
import com.sbtele.infoexchange.xml.BillingMessage;
import com.sun.xml.ws.transport.http.servlet.SpringBinding;
import org.jvnet.jax_ws_commons.spring.SpringService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.annotation.EnableAsync;

import javax.jms.ConnectionFactory;
import javax.servlet.*;

@Configuration
@EnableAsync
public class InfoexchangeConfig {

	@Autowired
	private NewClientsService newClients;
	
	@Autowired
	private DisconnectedSubscribersService disconnectedSubscribers;

	@Value("${application.url.new-clients}")
	private String newClientsUrl;

	@Value("${application.url.disconnected-subscribers}")
	private String disconnectedSubscribersUrl;

	@Value("${application.url.mapping}")
	private String servletUrlMapping;

	@Bean
	public Servlet servlet() {
		return new CustomWSSpringServlet();
	}
	
	@Bean
	public ServletRegistrationBean<Servlet> servletRegistrationBean(){
		return new ServletRegistrationBean<Servlet>(servlet(), servletUrlMapping);
	}
	
	@Bean
	public SpringBinding bindNewClientsService() throws Exception {
		SpringService service=new SpringService();
		service.setBean(newClients);
		SpringBinding binding = new SpringBinding();
		binding.setService(service.getObject());
		binding.setUrl(newClientsUrl);
		return binding;
	}
	
	@Bean
	public SpringBinding bindDisconnectedSubscribersService() throws Exception {
		SpringService service=new SpringService();
		service.setBean(disconnectedSubscribers);
		SpringBinding binding=new SpringBinding();
		binding.setService(service.getObject());
		binding.setUrl(disconnectedSubscribersUrl);
		return binding;
	}

	@Bean
	public JmsListenerContainerFactory<?> jmsFactory(ConnectionFactory connectionFactory,
													 DefaultJmsListenerContainerFactoryConfigurer configurer) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setPubSubDomain(true);
		factory.setErrorHandler(new JmsErrorHandler());
		configurer.configure(factory, connectionFactory);
		return factory;
	}

	@Bean
	static MessageConverter messageConverter() {
		MarshallingMessageConverter converter = new MarshallingMessageConverter();
		converter.setMarshaller(marshaller());
		converter.setUnmarshaller(marshaller());
		return converter;
	}

	@Bean
	static Jaxb2Marshaller marshaller() {
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		marshaller.setClassesToBeBound(BillingMessage.class);
		return marshaller;
	}

}