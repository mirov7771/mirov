package com.sbtele.infoexchange.csv.model;

public enum ClientResultCode {
    SUCCESS_ALREADY_EXIST(0, ""),
    SUCCESS_ADDED_TO_LIST(1, ""),
    SUCCESS_REMOVED_FROM_LIST(2, ""),
    MSISDN_INCORRECT_FORMAT(9, "Incorrect MSISDN format"),
    WRONG_DATE_FORMAT(9, "Wrong date format"),
    UNKNOWN_SUBSCRIBER(9, "Subscriber is unknown");

    private long code;
    private String errorDescription;

    ClientResultCode(long code, String dsecription) {
        this.code = code;
        this.errorDescription = dsecription;
    }

    public long getCode() {
        return code;
    }

    public String getErrorDescription() {
        return errorDescription;
    }
}
