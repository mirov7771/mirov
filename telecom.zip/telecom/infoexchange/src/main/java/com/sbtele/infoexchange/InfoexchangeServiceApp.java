package com.sbtele.infoexchange;

import com.sbtele.infoexchange.csv.PathWatcher;
import com.sbtele.infoexchange.repository.DBScheduledCleaner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.jms.annotation.EnableJms;

import javax.annotation.PostConstruct;

@SpringBootApplication
@EnableConfigurationProperties
@EnableJms
public class InfoexchangeServiceApp {
	@Autowired
	private PathWatcher pathWatcher;

	@Autowired
	private DBScheduledCleaner dbCleaner;

	public static void main(String[] args) {
		SpringApplication.run(InfoexchangeServiceApp.class, args);
	}

	@PostConstruct
	private void postConstruct() {
		pathWatcher.start();
		dbCleaner.start();
	}
}