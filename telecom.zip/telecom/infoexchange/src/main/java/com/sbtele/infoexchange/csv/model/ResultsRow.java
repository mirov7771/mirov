package com.sbtele.infoexchange.csv.model;

import com.opencsv.bean.CsvBindByPosition;

class ResultsRow implements CsvRow {

    @CsvBindByPosition(position = 0)
    private String msisdnColumn;

    @CsvBindByPosition(position = 1)
    private String changedAtColumn;

    @CsvBindByPosition(position = 2)
    private long resultCodeColumn;

    @CsvBindByPosition(position = 3)
    private String errorDescriptionColumn;

    String getMsisdnColumn() {
        return msisdnColumn;
    }

    void setMsisdnColumn(String msisdnColumn) {
        this.msisdnColumn = msisdnColumn;
    }

    String getChangedAtColumn() {
        return changedAtColumn;
    }

    void setChangedAtColumn(String changedAtColumn) {
        this.changedAtColumn = changedAtColumn;
    }

    long getResultCodeColumn() {
        return resultCodeColumn;
    }

    void setResultCodeColumn(long resultCodeColumn) {
        this.resultCodeColumn = resultCodeColumn;
    }

    String getErrorDescriptionColumn() {
        return errorDescriptionColumn;
    }

    void setErrorDescriptionColumn(String errorDescriptionColumn) {
        this.errorDescriptionColumn = errorDescriptionColumn;
    }
}
