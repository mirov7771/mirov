package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class ClientsToAdd {
	@XmlElement(name="ClientToAdd", required=true)
	private List<ClientToAdd> clients = new ArrayList<>();

	public List<ClientToAdd> getClients() {
		return clients;
	}

	public void setClients(List<ClientToAdd> clients) {
		this.clients = clients;
	}

	public String toString() {
		return clients.toString();
	}
}
