package com.sbtele.infoexchange.csv.model;

import com.sbtele.infoexchange.utils.StringDateConverter;

import java.util.Date;

public class SnapshotRowInfo {
    private SnapshotRow snapshotRow = new SnapshotRow();

    public String getMsisdn() {
        return snapshotRow.getMsisdnColumn();
    }

    public SnapshotRowInfo setMsisdn(String msisdnColumn) {
        snapshotRow.setMsisdnColumn(msisdnColumn);
        return this;
    }

    public SnapshotRowInfo setStartWatch(Date startWatch) {
        snapshotRow.setStartWatchColumn(StringDateConverter.dateToString(startWatch));
        return this;
    }

    public SnapshotRowInfo setEndWatch(Date endWatch) {
        snapshotRow.setEndWatchColumn(StringDateConverter.dateToString(endWatch));
        return this;
    }

    public SnapshotRowInfo setChangedAt(Date changedAt) {
        snapshotRow.setChangedAtColumn(StringDateConverter.dateToString(changedAt));
        return this;
    }

    public SnapshotRow getSnapshotRow() {
        return snapshotRow;
    }
}
