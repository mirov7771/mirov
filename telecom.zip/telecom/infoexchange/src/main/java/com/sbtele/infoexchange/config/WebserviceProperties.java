package com.sbtele.infoexchange.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="application.service")
public class WebserviceProperties {
    private int maxDbStoreDays;
    private int dbCleanPeriod;

    public int getMaxDbStoreDays() {
        return maxDbStoreDays;
    }

    public int getDbCleanPeriod() {
        return dbCleanPeriod;
    }

    public void setMaxDbStoreDays(int maxDbStoreDays) {
        this.maxDbStoreDays = maxDbStoreDays;
    }

    public void setDbCleanPeriod(int dbCleanPeriod) {
        this.dbCleanPeriod = dbCleanPeriod;
    }
}
