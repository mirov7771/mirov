package com.sbtele.infoexchange.repository.model;

public enum SubscriberEventReason {
    REASON_SUBSCRIBER_CHANGE_MSISDN(1L),
    REASON_OPERATOR_SUBSCRIBER_CLOSE(2L),
    REASON_CONTRACT_CLOSE(3L),
    REASON_MSISDN_CHANGE(4L),
    REASON_OWNER_CHANGE(5L),
    REASON_IMSI_CHANGE(6L),
    REASON_MNP(10L),
    REASON_OS_CHANGE_ANDROID_ANDROID(21L),
    REASON_OS_CHANGE_ANDROID_OTHER(22L),
    REASON_OS_CHANGE_OTHER_ANDROID(23L),
    REASON_OS_CHANGE_OTHER_OTHER(24L),
    REASON_IMEI_CHANGE(25L),
    REASON_MALWARE_SUSPECT(31L),
    REASON_MALWARE_SUSPECT_CANCEL(32L),
    REASON_CALL_FORWARD_ON(40L),
    REASON_CALL_FORWARD_OFF(41L);

    private Long reason;

    SubscriberEventReason(Long reason) {
        this.reason = reason;
    }

    public long get() {
        return reason;
    }
}
