package com.sbtele.infoexchange.csv.model;

import com.sbtele.infoexchange.utils.StringDateConverter;

import java.util.Date;

public class ClientsRowInfo {
    private ClientsRow clientsRow = new ClientsRow();

    public String getMsisdn() {
        return clientsRow.getMsisdnColumn();
    }

    public Date getChangedAt() {
        return StringDateConverter.stringToDate(clientsRow.getChangedAtColumn());
    }

    public void setRow(ClientsRow clientsRow) {
        this.clientsRow = clientsRow;
    }
}
