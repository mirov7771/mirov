package com.sbtele.infoexchange.xml;

import org.springframework.util.StringUtils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
public class ClientToAdd {
	@XmlElement(name="MSISDN", required=true)
	private String msisdn;

	// have to use java.util.Date to simplify parsing
	@XmlElement(name="ChangedAt", required=true)
	private Date changedAt;

	public ClientToAdd() {}

	public ClientToAdd(String msisdn, Date changedAt) {
		this.msisdn = msisdn;
		this.changedAt = changedAt;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public String getMsisdnFormatted(){
		if (StringUtils.hasText(msisdn))
			return msisdn.replaceAll("[^0-9.]", "");
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public Date getChangedAt() {
		return changedAt;
	}

	public void setChangedAt(Date changedAt) {
		this.changedAt = changedAt;
	}

	@Override
	public String toString() {
		return "ClientToAdd [MSISDN=" + msisdn + ", changedAt=" + changedAt + "]";
	}
}
