package com.sbtele.infoexchange.repository.model;

import com.sbtele.infoexchange.xml.ClientToAdd;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="BL_T_INEX_SBB_WATCHLIST")
public class Client {

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BL_Q_INEX_SBB_WATCHLIST")
    @SequenceGenerator(sequenceName = "BL_Q_INEX_SBB_WATCHLIST", allocationSize = 1, name = "BL_Q_INEX_SBB_WATCHLIST")
    private Long Id;

    @Column(name="MSISDN")
    private String msisdn;

    @Column(name="CHANGED_AT")
    private Date changedAt;

    @Column(name="START_WATCH")
    private Date startWatch;

    @Column(name="END_WATCH")
    private Date endWatch;

    @Column(name="CSV_VERSION")
    private String csvVersion;

    public Long getId() {
        return Id;
    }

    public Client setId(Long id) {
        this.Id = id;
        return this;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public Client setMsisdn(String msisdn) {
        this.msisdn = msisdn;
        return this;
    }

    public Date getChangedAt() {
        return changedAt;
    }

    public Client setChangedAt(Date changedAt) {
        this.changedAt = changedAt;
        return this;
    }

    public Date getStartWatch() {
        return startWatch;
    }

    public Client setStartWatch(Date startWatch) {
        this.startWatch = startWatch;
        return this;
    }

    public Date getEndWatch() {
        return endWatch;
    }

    public Client setEndWatch(Date endWatch) {
        this.endWatch = endWatch;
        return this;
    }

    public String getCsvVersion() {
        return csvVersion;
    }

    public Client setCsvVersion(String csvVersion) {
        this.csvVersion = csvVersion;
        return this;
    }

    public static Client of(ClientToAdd clientToAdd) {
        return new Client().setMsisdn(clientToAdd.getMsisdn())
                .setChangedAt(clientToAdd.getChangedAt())
                .setStartWatch(new Date())
                .setCsvVersion("0");
    }

    @Override
    public String toString() {
        return "Client{" +
                "Id=" + Id +
                ", msisdn='" + msisdn + '\'' +
                ", changedAt=" + changedAt +
                ", startWatch=" + startWatch +
                ", endWatch=" + endWatch +
                ", csvVersion='" + csvVersion + '\'' +
                '}';
    }
}
