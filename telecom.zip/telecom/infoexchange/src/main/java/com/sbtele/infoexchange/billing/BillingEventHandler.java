package com.sbtele.infoexchange.billing;

import com.sbtele.infoexchange.repository.MsisdnLocalStore;
import com.sbtele.infoexchange.repository.SubscriberEventsRepository;
import com.sbtele.infoexchange.repository.WatchListRepository;
import com.sbtele.infoexchange.repository.model.BilledMsisdn;
import com.sbtele.infoexchange.repository.model.BillingItem;
import com.sbtele.infoexchange.repository.model.Client;
import com.sbtele.infoexchange.repository.model.RemovedSubscriber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class BillingEventHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(BillingEventHandler.class);

    @Autowired
    private SubscriberEventsRepository subscriberEventsRepository;

    @Autowired
    private WatchListRepository watchListRepository;

    @Autowired
    private MsisdnLocalStore msisdnLocalStore;

    @Async
    public void process(BillingItem billingItem) {
        if(billingItem instanceof RemovedSubscriber) {
            RemovedSubscriber removedSubscriber = (RemovedSubscriber) billingItem;
            String msisdn = removedSubscriber.getMsisdn();
            Optional<Client> optClient = watchListRepository.findByMsisdnAndEndWatchIsNull(msisdn);

            if (optClient.isPresent()) {
                subscriberEventsRepository.save(removedSubscriber);
                LOGGER.debug("Saving event: {}", removedSubscriber);
            } else {
                LOGGER.debug("Subscriber with MSISDN [{}] not found in watch list, event NOT saved", msisdn);
            }

            msisdnLocalStore.remove(msisdn);
        } else if (billingItem instanceof BilledMsisdn) {
            BilledMsisdn billedMsisdn = (BilledMsisdn) billingItem;
            String msisdn = billedMsisdn.getMsisdn();
            if(msisdnLocalStore.exist(msisdn)) {
                LOGGER.debug("MSISDN [{}] already exist, skip operation", msisdn);
            } else {
                msisdnLocalStore.add(msisdn);
            }
        }
    }
}
