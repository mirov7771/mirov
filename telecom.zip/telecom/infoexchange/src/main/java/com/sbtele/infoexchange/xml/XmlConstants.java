package com.sbtele.infoexchange.xml;

public final class XmlConstants {
    private XmlConstants() {

    }

    public static final class ClientOperationResults {
        public static final long CLIENT_RESULT_SUCCESS = 0;
        public static final long CLIENT_RESULT_ERROR_UNKNOWN_SUBSCRIBER = 1205230001;
        public static final long CLIENT_RESULT_ERROR_WRONG_MSISDN_FORMAT = 1205230002;
        public static final long CLIENT_RESULT_ERROR_WRONG_DATE_FORMAT = 1205230003;
        public static final long CLIENT_RESULT_ERROR_MSISDN_EXIST = 1205230004;
        public static final long CLIENT_RESULT_ERROR_OTHER_MBK_ERROR = 1205230005;
        public static final long CLIENT_RESULT_ERROR_OTHER_ERROR = 1205238888;

        private ClientOperationResults() {

        }
    }

    public static final class DisconnectedSubscribersOperationResults {
        public static final long OPERATION_RESULT_SUCCESS = 0;
        public static final long OPERATION_RESULT_SYSTEM_ERROR = 1205251111;
        public static final long OPERATION_RESULT_CREDENTIALS_ERROR = 1205251112;
        public static final long OPERATION_RESULT_OTHER_ERROR = 1205251119;
        public static final long OPERATION_RESULT_SYSTEM_REPEAT_ERROR = 1205210001;
        public static final long OPERATION_RESULT_CREDENTIALS_REPEAT_ERROR = 1205210002;
        public static final long INITIAL_REQUEST_NOT_FOUND_ERROR = 1205210003;
        public static final long OPERATION_RESULT_OTHER_REPEAT_ERROR = 1205210009;

        public static final String OPERATION_RESULT_CREDENTIALS_ERROR_DESCRIPTION = "В запросе передан некорректный логин или пароль";
        public static final String OPERATION_RESULT_ID_ERROR_DESCRIPTION = "Некорректный формат RequestId";
        public static final String OPERATION_RESULT_OLD_ID_ERROR_DESCRIPTION = "Некорректный формат OldRequestId";

        private DisconnectedSubscribersOperationResults() {

        }
    }

    public static final class NewClientsOperationResults {
        public static final long OPERATION_RESULT_SUCCESS = 0;
        public static final long OPERATION_RESULT_SYSTEM_ERROR = 1205241111;
        public static final long OPERATION_RESULT_CREDENTIALS_ERROR = 1205242222;
        public static final long OPERATION_RESULT_OTHER_ERROR = 1205242229;

        public static final String OPERATION_RESULT_CREDENTIALS_ERROR_DESCRIPTION = "В запросе передан некорректный логин или пароль";

        private NewClientsOperationResults() {

        }
    }
}
