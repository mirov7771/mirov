package com.sbtele.infoexchange.webservice;

public interface CredentialsValidator {
    public boolean isCredentialsValid(String login, String password);
}
