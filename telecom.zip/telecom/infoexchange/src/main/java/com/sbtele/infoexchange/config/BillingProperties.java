package com.sbtele.infoexchange.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="application.billing")
public class BillingProperties {
    private  String bercutWsdlLocation;

    public String getBercutWsdlLocation() {
        return bercutWsdlLocation;
    }

    public void setBercutWsdlLocation(String bercutWsdlLocation) {
        this.bercutWsdlLocation = bercutWsdlLocation;
    }
}
