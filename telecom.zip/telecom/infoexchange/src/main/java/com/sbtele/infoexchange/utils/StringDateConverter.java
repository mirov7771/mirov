package com.sbtele.infoexchange.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.sbtele.infoexchange.csv.CsvConstants.DATE_FORMAT_PATTERN;

public class StringDateConverter {
    private static final Logger LOGGER = LoggerFactory.getLogger(StringDateConverter.class);

    public static Date stringToDate(String source) {
        Date date = null;

        try {
            date = new SimpleDateFormat(DATE_FORMAT_PATTERN).parse(source);
        } catch (ParseException pe) {
            LOGGER.warn("Error parsing date '{}': {}", source, pe.getMessage());
        }

        return date;
    }

    public static String dateToString(Date source) {
        return new SimpleDateFormat(DATE_FORMAT_PATTERN).format(source);
    }
}