package com.sbtele.infoexchange.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;

import static com.sbtele.infoexchange.utils.ClientsFileValidationErrorCode.*;

public class ClientsFileValidator {
    private static final String CSV_NAME_PATTERN = "[a-zA-Z][.]\\d{14}[.]\\d{9}[.]clients";
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientsFileValidator.class);

    public static ClientsFileValidationResult validate(Path fullPath, String currentVersion) {
        ClientsFileValidationResult clientsFileValidationResult = new ClientsFileValidationResult();
        String filename = fullPath.getFileName().toString();

        if(!filename.matches(CSV_NAME_PATTERN)) {
            return clientsFileValidationResult.setValid(false).setError(FILE_NAME_PATTERN_ERROR);
        }

        String[] tokens = filename.split("[.]");
        String newVersion = tokens[1];

        if(currentVersion.compareTo(newVersion) > 0) {
            return clientsFileValidationResult.setValid(false).setError(FILE_VERSION_ERROR);
        }

        Long fileLinesNumber = Long.parseLong(tokens[2]);
        Long linesCounter;

        try (Stream<String> stream = Files.lines(fullPath)) {
            linesCounter = stream.count();
        } catch (IOException | UncheckedIOException ioe) {
            LOGGER.error("File IOException", ioe);
            return clientsFileValidationResult.setValid(false).setError(FILE_IO_ERROR);
        }

        if(linesCounter.compareTo(fileLinesNumber) < 0) {
            return clientsFileValidationResult.setValid(false).setError(MISMATCHED_LINES_NUMBER_ERROR);
        }

        return clientsFileValidationResult.setValid(true);
    }
}
