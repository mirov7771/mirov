package com.sbtele.infoexchange.csv;

import com.sbtele.infoexchange.config.CsvProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.Objects;

import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;

@Service
public class PathWatcher {
    private WatchService watchService;

    private static final Logger LOGGER = LoggerFactory.getLogger(PathWatcher.class);

    @Autowired
    private ExchangeManager exchangeManager;

    @Autowired
    private CsvProperties csvProperties;

    @Async
    public void start() {
        WatchKey watchKey;
        String watchDirectory = csvProperties.getDirectory();
        LOGGER.info("Start path watcher for path: {}", watchDirectory);

        while(true) {
            try {
                watchKey = watchService.take();
            } catch (InterruptedException e) {
                LOGGER.error("Watch service interrupted error", e);
                break;
            }

            Objects.requireNonNull(watchKey, "watchKey cannot be NULL");
            List<WatchEvent<?>> watchEvents = watchKey.pollEvents();
            for (WatchEvent<?> watchEvent : watchEvents) {
                @SuppressWarnings("unchecked")
                WatchEvent<Path> pathWatchEvent = (WatchEvent<Path>) watchEvent;
                WatchEvent.Kind<Path> eventKind = pathWatchEvent.kind();

                if (ENTRY_CREATE == eventKind) {
                    Path file = pathWatchEvent.context().getFileName();
                    String fileName = file.toString();
                    Path fullPath = Paths.get(watchDirectory, fileName);
                    LOGGER.debug("Create event caught for {}", fileName);
                    if(fileName.endsWith(CsvConstants.CLIENTS_EXTENSION)) {
                        LOGGER.debug("Launched doExchange()");
                        exchangeManager.doExchange(fullPath);
                    }
                }
            }
            watchKey.reset();
        }

        try {
            watchService.close();
        } catch (IOException ioe) {
            LOGGER.error("Watch service close error", ioe);
        }
    }

    @PostConstruct
    private void postConstruct() {
        Path path = Paths.get(csvProperties.getDirectory());
        try {
            watchService = FileSystems.getDefault().newWatchService();
            path.register(watchService, ENTRY_CREATE);
        } catch(IOException ioe) {
            LOGGER.error("Cannot initialize watch service", ioe);
            throw new IllegalStateException();
        }
    }
}
