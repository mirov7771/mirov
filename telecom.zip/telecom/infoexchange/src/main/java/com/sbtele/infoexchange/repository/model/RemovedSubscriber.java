package com.sbtele.infoexchange.repository.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="BL_T_INEX_SBB_SUBSCRIBER_EVENTS")
public class RemovedSubscriber implements BillingItem {
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BL_Q_INEX_SBB_SUBSCRIBER_EVENTS")
    @SequenceGenerator(sequenceName = "BL_Q_INEX_SBB_SUBSCRIBER_EVENTS", allocationSize = 1, name = "BL_Q_INEX_SBB_SUBSCRIBER_EVENTS")
    private Long Id;

    @Column(name="MSISDN")
    private String msisdn;

    @Column(name="REASON")
    private Long reason;

    @Column(name="PRIORITY")
    private Integer priority;

    @Column(name = "DISCONNECTED_AT")
    private Date disconnectedAt;

    @Column(name = "AVAILABLE_AT")
    private Date availableAt;

    @Column(name = "REQUEST_ID")
    private Long requestId;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public Long getReason() {
        return reason;
    }

    public void setReason(Long reason) {
        this.reason = reason;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Date getDisconnectedAt() {
        return disconnectedAt;
    }

    public void setDisconnectedAt(Date disconnectedAt) {
        this.disconnectedAt = disconnectedAt;
    }

    public Date getAvailableAt() {
        return availableAt;
    }

    public void setAvailableAt(Date availableAt) {
        this.availableAt = availableAt;
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public void setPriority(SubscriberEventPriority subscriberEventPriority) {
        this.priority = subscriberEventPriority.get();
    }

    public void setReason(SubscriberEventReason subscriberEventReason) {
        this.reason = subscriberEventReason.get();
    }

    @Override
    public String toString() {
        return "SubscriberEvent{" +
                "Id=" + Id +
                ", msisdn='" + msisdn + '\'' +
                ", reason=" + reason +
                ", priority=" + priority +
                ", disconnectedAt=" + disconnectedAt +
                ", availableAt=" + availableAt +
                ", requestId=" + requestId +
                '}';
    }
}
