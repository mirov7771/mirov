package com.sbtele.infoexchange.csv;

import com.sbtele.infoexchange.csv.model.ClientsRow;

public interface CsvReader {
    public ClientsRow next();
    public boolean hasNext();
}
