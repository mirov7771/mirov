package com.sbtele.infoexchange.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.regex.Pattern;

public class FormatValidator {
    private static final int MSISDN_MAX_LENGTH = 15;
    private static final int MSISDN_MIN_LENGTH = 10;
    private static final Logger LOGGER = LoggerFactory.getLogger(FormatValidator.class);

    public static boolean isMsisdnValid(String msisdn) {
        boolean isValid = msisdn.length() >= MSISDN_MIN_LENGTH
                && msisdn.length() <= MSISDN_MAX_LENGTH
                && Pattern.matches("\\d+", msisdn);
        if(!isValid) {
            LOGGER.warn("Incorrect MSISDN format: {}", msisdn);
        }
        return isValid;
    }
}
