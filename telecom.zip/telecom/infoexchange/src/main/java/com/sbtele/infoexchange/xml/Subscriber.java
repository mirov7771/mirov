package com.sbtele.infoexchange.xml;

import com.sbtele.infoexchange.repository.model.RemovedSubscriber;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
public class Subscriber {
	@XmlElement(name="MSISDN", required=true)
	private String msisdn;

	@XmlElement(name="Reason", required=true)
	private long reason;

	@XmlElement(name="DisconnectedAt", required=true)
	private Date disconnectedAt;

	@XmlElement(name="AvailableAt", required=true)
	private Date availableAt;

	public Subscriber() {

	}

	public Subscriber (RemovedSubscriber removeSubscriberEvent) {
		this.msisdn = removeSubscriberEvent.getMsisdn();
		this.reason = removeSubscriberEvent.getReason();
		this.disconnectedAt = removeSubscriberEvent.getDisconnectedAt();
		this.availableAt = removeSubscriberEvent.getAvailableAt();
	}

	public String getMsisdn() {
		return msisdn;
	}
	
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public long getReason() {
		return reason;
	}
	
	public void setReason(long reason) {
		this.reason = reason;
	}

	public Date getDisconnectedAt() {
		return disconnectedAt;
	}
	
	public void setDisconnectedAt(Date disconnectedAt) {
		this.disconnectedAt = disconnectedAt;
	}

	public Date getAvailableAt() {
		return availableAt;
	}

	public void setAvailableAt(Date availableAt) {
		this.availableAt = availableAt;
	}
	
	@Override
	public String toString() {
		return "Subscriber [MSISDN=" + msisdn + ", reason=" + reason + ", disconnectedAt=" + disconnectedAt
				+ ", availableAt=" + availableAt + "]";
	}
}
