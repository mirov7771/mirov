package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.*;

@XmlRootElement(namespace = "http://webserv.my/")
@XmlType(propOrder = {"login", "password", "requestId", "oldRquestId"})
@XmlAccessorType(XmlAccessType.FIELD)
public class DisconnectedSubscribersRequestBody {
	@XmlElement(name="Login", required=true)
	private String login;

	@XmlElement(name="Pwd", required=true)
	private String password;

	@XmlElement(name="RequestID", required=true)
	private Long requestId;

	@XmlElement(name="OldRequestID", required=true)
	private Long oldRquestId;

	public String getLogin() {
		return login;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public Long getOldRquestId() {
		return oldRquestId;
	}
	
	public void setOldRquestId(Long oldRquestId) {
		this.oldRquestId = oldRquestId;
	}

	@Override
	public String toString() {
		return "DisconnectedSubscribersRequestInfo{" +
				"login='" + login + '\'' +
				", password='" + password + '\'' +
				", requestId=" + requestId +
				", oldRquestId=" + oldRquestId +
				'}';
	}
}
