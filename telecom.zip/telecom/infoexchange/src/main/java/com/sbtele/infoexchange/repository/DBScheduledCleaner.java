package com.sbtele.infoexchange.repository;

import com.sbtele.infoexchange.config.WebserviceProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
public class DBScheduledCleaner {
    private ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
    private static final Logger LOGGER = LoggerFactory.getLogger(DBScheduledCleaner.class);

    @Autowired
    private WebserviceProperties webserviceProperties;

    @Autowired
    private WatchListRepository watchListRepository;

    @Autowired
    private SubscriberEventsRepository subscriberEventsRepository;

    public void start() {
        int cleanPeriod = webserviceProperties.getDbCleanPeriod();
        LOGGER.info("Startup scheduled clean service ...");
        executorService.scheduleAtFixedRate(this::cleanDB, cleanPeriod, cleanPeriod, TimeUnit.HOURS);
    }

    private void cleanDB() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -webserviceProperties.getMaxDbStoreDays());
        Date cleanDate = calendar.getTime();
        LOGGER.info("Start subscribers repository scheduled clean ...");

        try {
            watchListRepository.deleteByEndWatchBefore(cleanDate);
            subscriberEventsRepository.deleteByAvailableAtBefore(cleanDate);
            LOGGER.info("Repositories clean complete ...");
        } catch (DataAccessException dae) {
            LOGGER.error("Repositories clean error", dae);
        }
    }

    public void close() {
        executorService.shutdown();
    }
}
