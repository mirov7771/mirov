package com.sbtele.infoexchange.utils;

public enum ClientsFileValidationErrorCode {
    FILE_NAME_PATTERN_ERROR(1205281000, "File name pattern is incorrect"),
    FILE_VERSION_ERROR(1205281000, "Provided file has older version than current"),
    FILE_IO_ERROR(1205281000, "File IO error"),
    MISMATCHED_LINES_NUMBER_ERROR(1205281000, "Mismatched number of records"),
    UNSATISFACTORY_RATIO_EXCEED_ERROR(1205281000, "Too many unknown MSISDN. Please check if input file is correct");

    private long errorCode;
    private String errorDescription;

    ClientsFileValidationErrorCode(long errorCode, String errorDescription) {
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    public long getErrorCode() {
        return errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }
}
