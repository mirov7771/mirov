package com.sbtele.infoexchange.csv;

import com.opencsv.CSVWriter;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import com.sbtele.infoexchange.csv.model.CsvRow;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class CsvFileWriter implements CsvWriter, AutoCloseable{
    private StatefulBeanToCsv<CsvRow> beanToCsv;
    private Writer writer;
    private Path fullPath;

    private static final Logger LOGGER = LoggerFactory.getLogger(CsvFileWriter.class);

    public CsvFileWriter(Path fullPath) {
        this.fullPath = fullPath;

        try {
            writer = Files.newBufferedWriter(fullPath);
            LOGGER.debug("Writing to file {}", fullPath.toString());
        } catch (IOException ioe) {
            LOGGER.error("Output file [" + fullPath.toString() + "] write error", ioe);
            throw new UncheckedIOException(ioe);
        }

        beanToCsv = new StatefulBeanToCsvBuilder<CsvRow>(writer)
                .withQuotechar(CSVWriter.NO_QUOTE_CHARACTER)
                .build();
    }

    @Override
    public void write(CsvRow csvRow) {
        try {
            beanToCsv.write(csvRow);
        } catch (CsvRequiredFieldEmptyException | CsvDataTypeMismatchException e) {
            LOGGER.error("Error writing row to csv", e);
        }
    }

    @Override
    public void close() {
        try{
            writer.close();
        } catch(IOException ioe) {
            LOGGER.error("Error closing file", ioe);
            throw new UncheckedIOException("Output file [" + fullPath.toString() + "] error on close attempt", ioe);
        }
    }
}
