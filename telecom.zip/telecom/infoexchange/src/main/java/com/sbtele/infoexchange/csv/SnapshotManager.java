package com.sbtele.infoexchange.csv;

import com.sbtele.infoexchange.config.CsvProperties;
import com.sbtele.infoexchange.csv.model.SnapshotRowInfo;
import com.sbtele.infoexchange.repository.WatchListRepository;
import com.sbtele.infoexchange.repository.model.Client;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.sbtele.infoexchange.csv.CsvConstants.*;

@Service
public class SnapshotManager {

    @Autowired
    private WatchListRepository watchListRepository;

    @Autowired
    private CsvProperties csvProperties;

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("YYYYMMddHHmmss");
    private static final Logger LOGGER = LoggerFactory.getLogger(SnapshotManager.class);

    @Async
    public void doSnapshot() {
        LOGGER.info("Start snapshot processing ...");
        int pageCounter = 0;
        int lineCounter = 0;
        String tmpFilename = DATE_FORMAT.format(new Date()) + TMP_EXTENSION;
        Path fullPath = Paths.get(csvProperties.getDirectory(), tmpFilename);

        try (CsvFileWriter csvFileWriter = new CsvFileWriter(fullPath)) {
            List<Client> clients;

            do {
                Page<Client> clientsPage = watchListRepository.findAll(PageRequest.of(pageCounter, csvProperties.getPageSize()));
                clients = clientsPage.getContent();

                if (0 == clients.size()) {
                    break;
                } else {
                    for (Client client : clients) {
                        SnapshotRowInfo snapshotRowInfo = new SnapshotRowInfo()
                                .setMsisdn(client.getMsisdn())
                                .setChangedAt(client.getChangedAt())
                                .setStartWatch(client.getStartWatch());

                        Date endWatch = client.getEndWatch();
                        if (null != endWatch) {
                            snapshotRowInfo.setEndWatch(endWatch);
                        }

                        csvFileWriter.write(snapshotRowInfo.getSnapshotRow());
                        lineCounter++;
                    }
                    pageCounter++;
                }
            } while (0 != clients.size());
        }

        String newFileName = DATE_FORMAT.format(new Date());
        String numberOfLines = String.format(LINE_NUMBER_FORMAT, lineCounter);
        String snapshotFilename = newFileName + numberOfLines + SNAPSHOT_EXTENSION;
        try {
            Files.move(Paths.get(csvProperties.getDirectory(), tmpFilename), Paths.get(csvProperties.getDirectory(), snapshotFilename));
        } catch (IOException ioe) {
            LOGGER.error("Error moving file {} to {}", tmpFilename, snapshotFilename);
        }
        LOGGER.info("End snapshot processing ...");
    }
}
