package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.*;
import java.util.Date;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name="event")
public class BillingMessage {
    @XmlAttribute(name="type")
    private String type;

    @XmlElement(name="timestamp")
    private Date timestamp;

    @XmlElement(name="subscriberId")
    private String subscriberId;

    @XmlElement(name="imsi")
    private String imsi;

    @XmlElement(name="isdn")
    private String isdn;

    @XmlElement(name="payload")
    private Payload payload;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getImsi() {
        return imsi;
    }

    public void setImsi(String imsi) {
        this.imsi = imsi;
    }

    public String getIsdn() {
        return isdn;
    }

    public void setIsdn(String isdn) {
        this.isdn = isdn;
    }

    public Payload getPayload() {
        return payload;
    }

    public void setPayload(Payload payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "BillingMessage{" +
                "type='" + type + '\'' +
                ", timestamp=" + timestamp +
                ", subscriberId='" + subscriberId + '\'' +
                ", imsi='" + imsi + '\'' +
                ", isdn='" + isdn + '\'' +
                ", payload=" + payload +
                '}';
    }
}
