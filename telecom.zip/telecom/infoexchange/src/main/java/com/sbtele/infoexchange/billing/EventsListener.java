package com.sbtele.infoexchange.billing;

import com.sbtele.infoexchange.repository.model.BillingItem;
import com.sbtele.infoexchange.xml.BillingMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EventsListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(EventsListener.class);

    @Autowired
    private BillingEventHandler billingEventHandler;

    @JmsListener(destination="${application.jms.destination}", containerFactory = "jmsFactory")
    public void receiveEvent(BillingMessage billingMessage){
        LOGGER.debug("Billing message received: {}", billingMessage.toString());
        Optional<BillingItem> optInfo = BillingItemFactory.of(billingMessage);
        optInfo.ifPresent(billingEventHandler::process);
    }
}
