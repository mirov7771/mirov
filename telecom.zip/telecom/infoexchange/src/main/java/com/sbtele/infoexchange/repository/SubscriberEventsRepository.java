package com.sbtele.infoexchange.repository;

import com.sbtele.infoexchange.repository.model.RemovedSubscriber;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

public interface SubscriberEventsRepository extends JpaRepository<RemovedSubscriber, Long> {

    // select unique phones and take the first not handled
    @Query(
            value = "SELECT t.id, t.msisdn, t.reason, t.priority, t.disconnected_at, t.available_at, t.request_id " +
                    "FROM ( " +
                        "SELECT s.*, row_number() over (partition by msisdn order by priority, disconnected_at, id asc) as rn from bl_t_inex_sbb_subscriber_events s " +
                        "WHERE s.request_id IS NULL" +
                    ") t " +
                    "WHERE t.rn = 1",
            countQuery = "SELECT count(*) " +
                    "FROM ( " +
                        "SELECT s.*, row_number() over (partition by msisdn order by priority, disconnected_at, id asc) as rn from bl_t_inex_sbb_subscriber_events s " +
                        "WHERE s.request_id IS NULL" +
                    ") t " +
                    "WHERE t.rn = 1",
            nativeQuery = true
    )
    List<RemovedSubscriber> findSubscriberEvents(Pageable pageable);
    List<RemovedSubscriber> findByRequestId(Long requestId);

    @Transactional
    void deleteByAvailableAtBefore(Date beforeDate);
}
