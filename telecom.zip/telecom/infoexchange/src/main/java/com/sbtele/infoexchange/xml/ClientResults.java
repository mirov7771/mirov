package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class ClientResults {
	@XmlElement(name="ClientResult")
	private List<ClientResult> results = new ArrayList<>();

	public List<ClientResult> getResults() {
		return results;
	}

	public void setResults(List<ClientResult> results) {
		this.results = results;
	}

	@Override
	public String toString() {
		return "ClientResults{" +
				"clientResults=" + results +
				'}';
	}
}
