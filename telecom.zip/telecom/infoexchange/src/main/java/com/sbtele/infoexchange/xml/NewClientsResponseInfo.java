package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class NewClientsResponseInfo {

	@XmlElement(name = "body")
	private NewClientsResponseBody body;

	public NewClientsResponseBody getBody() {
		return body;
	}

	public void setBody(NewClientsResponseBody body) {
		this.body = body;
	}

	@Override
	public String toString() {
		return "NewClientsResponseInfo{" +
				"body=" + body +
				'}';
	}

}
