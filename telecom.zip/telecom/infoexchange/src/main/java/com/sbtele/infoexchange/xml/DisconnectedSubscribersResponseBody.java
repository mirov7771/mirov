package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class DisconnectedSubscribersResponseBody {
	@XmlElement(name="OperationResult")
	private Long operationResult;

	@XmlElement(name="SubscribersCount")
	private Long subscribersCount;

	@XmlElement(name="SubscriberS")
	private Subscribers subscribers;

	@XmlElement(name="ErrorDescription")
	private String errorDescription;

	public long getOperationResult() {
		return operationResult;
	}
	
	public void setOperationResult(long operationResult) {
		this.operationResult = operationResult;
	}

	public Long getSubscribersCount() {
		return subscribersCount;
	}

	public void setSubscribersCount(Long subscribersCount) {
		this.subscribersCount = subscribersCount;
	}

	public Subscribers getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(Subscribers subscribers) {
		this.subscribers = subscribers;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	@Override
	public String toString() {
		return "DisconnectedSubscribersResponseInfo{" +
				"operationResult=" + operationResult +
				", subscribersCount=" + subscribersCount +
				", subscribers=" + subscribers +
				", errorDescription='" + errorDescription + '\'' +
				'}';
	}
}
