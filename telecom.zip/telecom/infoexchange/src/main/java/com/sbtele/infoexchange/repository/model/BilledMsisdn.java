package com.sbtele.infoexchange.repository.model;

import javax.persistence.*;

@Entity
@Table(name="BL_T_INEX_SBB_BILLED_MSISDN")
public class BilledMsisdn implements BillingItem {

    @Id
    @GeneratedValue(strategy= GenerationType.SEQUENCE, generator="BL_Q_INEX_SBB_BILLED_MSISDN")
    @SequenceGenerator(sequenceName = "BL_Q_INEX_SBB_BILLED_MSISDN", allocationSize = 1, name = "BL_Q_INEX_SBB_BILLED_MSISDN")
    private Long Id;

    @Column(name="MSISDN")
    private String msisdn;

    public BilledMsisdn() {

    }

    public BilledMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
}
