package com.sbtele.infoexchange.csv.model;

import com.opencsv.bean.CsvBindByPosition;

public class SnapshotRow implements CsvRow {
    @CsvBindByPosition(position = 0)
    private String msisdnColumn;

    @CsvBindByPosition(position = 1)
    private String startWatchColumn;

    @CsvBindByPosition(position = 2)
    private String endWatchColumn;

    @CsvBindByPosition(position = 3)
    private String changedAtColumn;

    String getMsisdnColumn() {
        return msisdnColumn;
    }

    void setMsisdnColumn(String msisdnColumn) {
        this.msisdnColumn = msisdnColumn;
    }

    String getStartWatchColumn() {
        return startWatchColumn;
    }

    void setStartWatchColumn(String startWatchColumn) {
        this.startWatchColumn = startWatchColumn;
    }

    String getEndWatchColumn() {
        return endWatchColumn;
    }

    void setEndWatchColumn(String endWatchColumn) {
        this.endWatchColumn = endWatchColumn;
    }

    String getChangedAtColumn() {
        return changedAtColumn;
    }

    void setChangedAtColumn(String changedAtColumn) {
        this.changedAtColumn = changedAtColumn;
    }
}
