package com.sbtele.infoexchange.repository;

import com.sbtele.infoexchange.repository.model.BilledMsisdn;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
interface MsisdnRepository extends CrudRepository<BilledMsisdn, Long>{
    Optional<BilledMsisdn> findByMsisdn(String msisdn);
    Optional<BilledMsisdn> findTopByOrderByMsisdn();
    @Transactional void deleteByMsisdn(String msisdn);
    List<BilledMsisdn> findByMsisdnIn(List<String> msisdns);
}

