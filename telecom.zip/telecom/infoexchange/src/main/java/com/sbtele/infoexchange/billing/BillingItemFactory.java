package com.sbtele.infoexchange.billing;

import com.sbtele.infoexchange.repository.model.BilledMsisdn;
import com.sbtele.infoexchange.repository.model.BillingItem;
import com.sbtele.infoexchange.repository.model.RemovedSubscriber;
import com.sbtele.infoexchange.xml.BillingMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.Optional;

import static com.sbtele.infoexchange.repository.model.SubscriberEventPriority.PRIORITY_HIGH;
import static com.sbtele.infoexchange.repository.model.SubscriberEventPriority.PRIORITY_NORMAL;
import static com.sbtele.infoexchange.repository.model.SubscriberEventReason.*;

public class BillingItemFactory {
    private static final Logger LOGGER = LoggerFactory.getLogger(BillingItemFactory.class);
    private static final String DELETE_SUBSCRIBER = "DeleteSubscriber";
    private static final String CHANGE_SIM = "ChangeSIM";
    private static final String MNP = "MNP";
    private static final String ADD_MSISDN = "CreateSubscriber";

    public static Optional<BillingItem> of(BillingMessage billingMessage) {
        RemovedSubscriber removedSubscriber;
        BilledMsisdn billedMsisdn;

        switch(billingMessage.getType()) {
            case DELETE_SUBSCRIBER:
                removedSubscriber = initRemoveSubscriberInfo(billingMessage);
                removedSubscriber.setReason(REASON_CONTRACT_CLOSE);
                removedSubscriber.setPriority(PRIORITY_NORMAL);
                return Optional.of(removedSubscriber);
            case CHANGE_SIM:
                removedSubscriber = initRemoveSubscriberInfo(billingMessage);
                removedSubscriber.setReason(REASON_IMSI_CHANGE);
                removedSubscriber.setPriority(PRIORITY_HIGH);
                return Optional.of(removedSubscriber);
            case MNP:
                removedSubscriber = initRemoveSubscriberInfo(billingMessage);
                removedSubscriber.setReason(REASON_MNP);
                removedSubscriber.setPriority(PRIORITY_NORMAL);
                return Optional.of(removedSubscriber);
            case ADD_MSISDN:
                billedMsisdn = new BilledMsisdn();
                billedMsisdn.setMsisdn(billingMessage.getIsdn());
                return Optional.of(billedMsisdn);
            default:
                LOGGER.warn("Unrecognized event type: {}", billingMessage.getType());
                return Optional.empty();
        }
    }

    private static RemovedSubscriber initRemoveSubscriberInfo(BillingMessage billingMessage) {
        RemovedSubscriber removedSubscriber = new RemovedSubscriber();
        removedSubscriber.setMsisdn(billingMessage.getIsdn());
        removedSubscriber.setDisconnectedAt(billingMessage.getTimestamp());
        removedSubscriber.setAvailableAt(new Date());
        return removedSubscriber;
    }
}
