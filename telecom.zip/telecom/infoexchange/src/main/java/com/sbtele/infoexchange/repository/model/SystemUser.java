package com.sbtele.infoexchange.repository.model;

import javax.persistence.*;

@Entity
@Table(name="BL_T_INEX_SYSTEM_USERS")
public class SystemUser {
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BL_Q_INEX_SYSTEM_USERS")
    @SequenceGenerator(sequenceName = "BL_Q_INEX_SYSTEM_USERS", allocationSize = 1, name = "BL_Q_INEX_SYSTEM_USERS")
    private Long id;

    @Column
    private String login;

    @Column
    private String password;

    @Column
    private String description;

    @Column(name="CREATED_AT")
    private String createdAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
