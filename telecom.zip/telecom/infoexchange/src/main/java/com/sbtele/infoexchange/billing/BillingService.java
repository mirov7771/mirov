package com.sbtele.infoexchange.billing;

import com.sbtele.infoexchange.repository.model.BilledMsisdn;
import com.sbtele.infoexchange.repository.model.Client;
import com.sbtele.infoexchange.xml.ClientResult;
import com.sbtele.infoexchange.xml.ClientToAdd;

import java.util.List;

public interface BillingService {
    boolean isSubscriberExist(String msisdn);
    List<ClientResult> validate(List<ClientToAdd> clients,
                                List<Client> watchList,
                                List<BilledMsisdn> msisdnList);
}
