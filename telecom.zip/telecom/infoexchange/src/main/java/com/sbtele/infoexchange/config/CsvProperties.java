package com.sbtele.infoexchange.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="application.csv")
public class CsvProperties {
    private String directory;
    private int pageSize;
    private String msisdnImportFile;
    private String msisdnStoreFile;
    private long linesToCheck;
    private double successThreshold;

    public String getDirectory() {
        return directory;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getMsisdnImportFile() {
        return msisdnImportFile;
    }

    public void setMsisdnImportFile(String msisdnImportFile) {
        this.msisdnImportFile = msisdnImportFile;
    }

    public String getMsisdnStoreFile() {
        return msisdnStoreFile;
    }

    public void setMsisdnStoreFile(String msisdnStoreFile) {
        this.msisdnStoreFile = msisdnStoreFile;
    }

    public long getLinesToCheck() {
        return linesToCheck;
    }

    public void setLinesToCheck(long linesToCheck) {
        this.linesToCheck = linesToCheck;
    }

    public double getSuccessThreshold() {
        return successThreshold;
    }

    public void setSuccessThreshold(double successThreshold) {
        this.successThreshold = successThreshold;
    }
}
