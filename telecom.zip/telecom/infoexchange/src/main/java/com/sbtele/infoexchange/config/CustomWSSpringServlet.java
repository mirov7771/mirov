package com.sbtele.infoexchange.config;

import com.sun.xml.ws.transport.http.servlet.WSSpringServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomWSSpringServlet extends WSSpringServlet {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomWSSpringServlet.class);

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		try {
            RequestWrapper rq = new RequestWrapper(request);
            LOGGER.info("request {}", rq.getBody());
            ResponseWriter rw = new ResponseWriter(response);
            super.doPost(rq, rw);
            String responseMessage = new String(rw.getWrapperBytes());
            LOGGER.info("response {}", responseMessage);
            if (StringUtils.hasText(responseMessage) && responseMessage.contains("return>")) {
                String strToEscape = responseMessage.substring(responseMessage.indexOf("<return>") + 8, responseMessage.indexOf("</return>"));
                if (StringUtils.hasText(strToEscape)) {
                    LOGGER.info("formatted part {}", strToEscape);
                    String strEscaped = strToEscape.replace("&", "&amp;")
                               .replace("<", "&lt;")
                               .replace(">", "&gt;")
                               .replace("\"", "&quot;")
                               .replace("'", "&apos;");
                    responseMessage = responseMessage.replace(strToEscape, strEscaped);
                    LOGGER.info("response formatted {}", responseMessage);
                }
            }
            response.getOutputStream().write(responseMessage.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
