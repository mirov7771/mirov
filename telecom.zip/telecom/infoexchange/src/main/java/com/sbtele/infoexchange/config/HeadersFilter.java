package com.sbtele.infoexchange.config;

import org.springframework.stereotype.Component;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class HeadersFilter implements Filter {

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain fc) throws IOException, ServletException {
        if(servletResponse instanceof HttpServletResponse
                && servletRequest instanceof HttpServletRequest) {
            HttpServletResponse response = (HttpServletResponse) servletResponse;
            ContentCachingResponseWrapper responseWrapper = new ContentCachingResponseWrapper(response);
            fc.doFilter(servletRequest, responseWrapper);
            responseWrapper.copyBodyToResponse();
        } else {
            fc.doFilter(servletRequest, servletResponse);
        }
    }

}
