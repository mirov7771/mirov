package com.sbtele.infoexchange.webservice;

import com.sbtele.infoexchange.xml.DisconnectedSubscribersRequestInfo;
import com.sbtele.infoexchange.xml.DisconnectedSubscribersResponseInfo;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

@WebService(targetNamespace = "http://webserv.my/")
@SOAPBinding(style = Style.RPC, use = Use.LITERAL)
public interface DisconnectedSubscribersService {

	@WebMethod(operationName="XMLmessage")
	DisconnectedSubscribersResponseInfo getDisconnectedSubscribers(DisconnectedSubscribersRequestInfo name);

}