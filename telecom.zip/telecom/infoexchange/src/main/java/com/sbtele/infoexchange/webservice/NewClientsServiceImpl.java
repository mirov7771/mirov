package com.sbtele.infoexchange.webservice;

import com.sbtele.infoexchange.billing.BillingService;
import com.sbtele.infoexchange.csv.SnapshotManager;
import com.sbtele.infoexchange.repository.MsisdnLocalStore;
import com.sbtele.infoexchange.repository.WatchListRepository;
import com.sbtele.infoexchange.repository.model.Client;
import com.sbtele.infoexchange.utils.FormatValidator;
import com.sbtele.infoexchange.xml.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.jws.WebService;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static com.sbtele.infoexchange.xml.XmlConstants.ClientOperationResults.*;
import static com.sbtele.infoexchange.xml.XmlConstants.NewClientsOperationResults.*;

@Service
@WebService(name = "Sberbank_SetNewClients",
        portName = "Sberbank_SetNewClientsPort",
        endpointInterface = "com.sbtele.infoexchange.webservice.NewClientsService")
public class NewClientsServiceImpl implements NewClientsService {
    private final static long FULL_LIST_EXPORT_NEEDED = 1;
    private static final Logger LOGGER = LoggerFactory.getLogger(NewClientsService.class);

    @Autowired
    private CredentialsValidator credentialsValidator;

    @Autowired
    private WatchListRepository watchListRepository;

    @Autowired
    private BillingService billingService;

    @Autowired
    private SnapshotManager snapshotManager;

    @Autowired
    private MsisdnLocalStore msisdnLocalStore;

    @Override
    public NewClientsResponseInfo addNewClients(NewClientsRequestInfo request) {
        LOGGER.info("[NewClientsServiceImpl.addNewClients] request {}", request);
        NewClientRequestBody requestInfo = request.getBody();
        LOGGER.info("[NewClientsServiceImpl.addNewClients] request {}", requestInfo);
        NewClientsResponseBody body = new NewClientsResponseBody();
        NewClientsResponseInfo responseInfo = new NewClientsResponseInfo();

        if (!credentialsValidator.isCredentialsValid(requestInfo.getLogin(), requestInfo.getPassword())) {
            body.setOperationResult(OPERATION_RESULT_CREDENTIALS_ERROR);
            body.setErrorDescription(OPERATION_RESULT_CREDENTIALS_ERROR_DESCRIPTION);
            LOGGER.warn("Incorrect credentials web service access attempt: {}/{}", requestInfo.getLogin(), requestInfo.getPassword());
            responseInfo.setBody(body);
            return responseInfo;
        }

        if (FULL_LIST_EXPORT_NEEDED == requestInfo.getFullListNeeded()) {
            snapshotManager.doSnapshot();
        }

        if (requestInfo.getClientsToAdd() == null || requestInfo.getClientsToAdd().getClients().isEmpty()) {
            body.setOperationResult(OPERATION_RESULT_OTHER_ERROR);
            responseInfo.setBody(body);
            return responseInfo;
        }

        processAddClients(requestInfo.getClientsToAdd(), body);
        body.setOperationResult(OPERATION_RESULT_SUCCESS);
        responseInfo.setBody(body);
        return responseInfo;
    }

    private void processAddClients(ClientsToAdd clientsToAdd, NewClientsResponseBody body) {
        ClientResults clientResults = new ClientResults();
        List<ClientResult> results = clientResults.getResults();
        List<ClientToAdd> clients = clientsToAdd.getClients().stream().limit(1000).collect(Collectors.toList());
//        for(ClientToAdd clientToAdd : clients) {
//            results.add(processClient(msisdns, list, clientToAdd));
//        }

        if (!CollectionUtils.isEmpty(clients)){
            List<String> msisdns = clients.stream().map(ClientToAdd::getMsisdnFormatted).collect(Collectors.toList());
            List<Client> list = new ArrayList<>();
            results.addAll(billingService.validate(clients,
                    watchListRepository.findByMsisdnInAndEndWatchIsNull(msisdns),
                    msisdnLocalStore.findList(msisdns)));

            if (!CollectionUtils.isEmpty(results)){
                list.addAll(clients.stream().filter(i -> results.stream().anyMatch(result -> result.getMsisdn().equals(i.getMsisdn())
                        && result.getResult().equals(CLIENT_RESULT_SUCCESS))).map(Client::of).collect(Collectors.toList()));
            }
            CompletableFuture.runAsync(() -> insertLists(list));
        }

        body.setClientResults(clientResults);
    }

    private void insertLists(List<Client> list){
        if (!CollectionUtils.isEmpty(list)) {
            watchListRepository.saveAll(list);
            msisdnLocalStore.addAll(list.stream().map(Client::getMsisdn).collect(Collectors.toList()));
        }
    }

    private ClientResult processClient(List<String> msisdns, List<Client> list, ClientToAdd clientToAdd) {
        ClientResult clientResult = new ClientResult();
        String msisdn = clientToAdd.getMsisdn();
        clientResult.setMsisdn(msisdn);
        try {
            long clientValidationResult = validateClient(msisdns, clientToAdd);
            if (CLIENT_RESULT_SUCCESS == clientValidationResult) {
                clientValidationResult = addToWatchList(list, clientToAdd);
            }
            clientResult.setResult(clientValidationResult);
        } catch (Exception e){
            LOGGER.error("Error working with db: ", e);
            clientResult.setResult(CLIENT_RESULT_ERROR_OTHER_ERROR);
        }
        return clientResult;
    }

    private long validateClient(List<String> msisdns, ClientToAdd client) {
        String msisdn = client.getMsisdn();

        if (null == client.getChangedAt()) {
            return CLIENT_RESULT_ERROR_WRONG_DATE_FORMAT;
        }

        if (!FormatValidator.isMsisdnValid(msisdn)) {
            return CLIENT_RESULT_ERROR_WRONG_MSISDN_FORMAT;
        }

        if(isMsisdnInWatchList(msisdn)) {
            return CLIENT_RESULT_ERROR_MSISDN_EXIST;
        }

        if (client.getMsisdn().startsWith("000000000"))
            return CLIENT_RESULT_ERROR_OTHER_ERROR;

        if (!msisdnLocalStore.exist(msisdn)) {
            if(!billingService.isSubscriberExist(msisdn)) {
                return CLIENT_RESULT_ERROR_UNKNOWN_SUBSCRIBER;
            } else {
                msisdns.add(msisdn);
            }
        }

        return CLIENT_RESULT_SUCCESS;
    }

    private boolean isMsisdnInWatchList(String msisdn) {
        Optional<Client> client = watchListRepository.findByMsisdnAndEndWatchIsNull(msisdn);
        return client.isPresent();
    }

    private long addToWatchList(List<Client> list, ClientToAdd clientToAdd) {
        Client client = Client.of(clientToAdd);
        long result = CLIENT_RESULT_SUCCESS;

        try {
            list.add(client);
        } catch (DataAccessException e) {
            LOGGER.error("Error saving client {}", client.toString(), e);
            result = CLIENT_RESULT_ERROR_OTHER_ERROR;
        }

        return result;
    }
}