package com.sbtele.infoexchange.billing;

import com.bercut.wsdl.dsi_crm_accountmanagement.ExceptionCRM;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.sbtele.infoexchange.config.http.client.RestGate;
import com.sbtele.infoexchange.repository.model.BilledMsisdn;
import com.sbtele.infoexchange.repository.model.Client;
import com.sbtele.infoexchange.utils.FormatValidator;
import com.sbtele.infoexchange.xml.ClientResult;
import com.sbtele.infoexchange.xml.ClientToAdd;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.sbtele.infoexchange.xml.XmlConstants.ClientOperationResults.*;

@Service
public class BillingServiceImpl implements BillingService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BillingServiceImpl.class);

    @Autowired
    private BercutWSClient bercutWSClient;
    @Autowired
    private RestGate restGate;
    @Value("${application.invoice.url}")
    private String infoServiceUrl;

    @Override
    public boolean isSubscriberExist(String msisdn) {
        boolean result = true;
        try{
            LOGGER.debug("Sending request to billing service for MSISDN [{}]", msisdn);
            bercutWSClient.getSubscriberInfo(msisdn);
        } catch (ExceptionCRM ex) {
            LOGGER.error("MSISDN [{}] not exist in billing", msisdn);
            result = false;
        }
        return result;
    }

    @Override
    public List<ClientResult> validate(List<ClientToAdd> clients,
                                       List<Client> watchList,
                                       List<BilledMsisdn> msisdnList) {
        List<ClientResult> res = new ArrayList<>();
        if (!CollectionUtils.isEmpty(clients)){
            res.addAll(clients.stream().map(i -> {
                ClientResult clientResult = new ClientResult();
                clientResult.setMsisdn(i.getMsisdn());
                if (i.getChangedAt() == null)
                    clientResult.setResult(CLIENT_RESULT_ERROR_WRONG_DATE_FORMAT);
                else if (!FormatValidator.isMsisdnValid(i.getMsisdn()))
                    clientResult.setResult(CLIENT_RESULT_ERROR_WRONG_MSISDN_FORMAT);
                else if (!CollectionUtils.isEmpty(watchList) && watchList.stream().anyMatch(w -> w.getMsisdn().equals(i.getMsisdn())))
                    clientResult.setResult(CLIENT_RESULT_ERROR_MSISDN_EXIST);
                else if (i.getMsisdn().startsWith("000000000"))
                    clientResult.setResult(CLIENT_RESULT_ERROR_OTHER_ERROR);
                else
                    clientResult.setResult(CLIENT_RESULT_SUCCESS);
                return clientResult;
            }).collect(Collectors.toList()));
        }

        List<ClientResult> successList = res.stream().filter(i -> i.getResult().equals(CLIENT_RESULT_SUCCESS)
                && msisdnList.stream().noneMatch(m -> m.getMsisdn().equals(i.getMsisdn()))).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(successList)){
            HttpHeaders headers = new HttpHeaders();
            headers.add("RqUID", UUID.randomUUID().toString());
            headers.add("RqTm", new Date().toString());
            headers.add("SubsystemCode", "GATE");

            Map<String, Object> body = new HashMap<>();
            body.put("channel", "GATE");
            body.put("msisdn", successList.stream().map(i -> normalizePhone(i.getMsisdn())).collect(Collectors.toList()));
            try {
                SubscribersDetailsRes subscribersdetails = restGate.call(SubscribersDetailsRes.class,
                        infoServiceUrl,
                        "subscribersdetails",
                        null,
                        body,
                        HttpMethod.POST,
                        headers,
                        MediaType.APPLICATION_JSON);
                if (subscribersdetails != null){
                    successList.forEach(i -> {
                        if (!CollectionUtils.isEmpty(subscribersdetails.getSubscribers()) && subscribersdetails.getSubscribers().stream().anyMatch(s -> s.getMsisdn().equals(normalizePhone(i.getMsisdn()))))
                            i.setResult(CLIENT_RESULT_SUCCESS);
                        else
                            i.setResult(CLIENT_RESULT_ERROR_UNKNOWN_SUBSCRIBER);
                    });
                }
            } catch (Exception e){
                LOGGER.error("Error: ", e);
            }

            res.removeAll(successList);
            res.addAll(successList);
        }
        return res;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private static class SubscribersDetailsRes {
        private List<Subscriber> subscribers;
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        private static class Subscriber {
            private String msisdn;
            public String getMsisdn() {
                return msisdn;
            }

            public void setMsisdn(String msisdn) {
                this.msisdn = msisdn;
            }
        }

        public List<Subscriber> getSubscribers() {
            return subscribers;
        }

        public void setSubscribers(List<Subscriber> subscribers) {
            this.subscribers = subscribers;
        }
    }

    private String normalizePhone(String phone){
        if (phone.length() > 10 && (phone.startsWith("7") || phone.startsWith("8")))
            return phone.substring(1, 11);
        return phone;
    }
}