package com.sbtele.infoexchange.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class NewClientsResponseBody {
	@XmlElement(name="OperationResult")
	private long operationResult;

	@XmlElement(name="ClientResultS")
	private ClientResults clientResults;

	@XmlElement(name="ErrorDescription")
	private String errorDescription;

	public long getOperationResult() {
		return operationResult;
	}
	
	public void setOperationResult(long operationResult) {
		this.operationResult = operationResult;
	}

	public ClientResults getClientResults() {
		return clientResults;
	}
	
	public void setClientResults(ClientResults clientResults) {
		this.clientResults = clientResults;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	@Override
	public String toString() {
		return "NewClientsResponseInfo{" +
				"operationResult=" + operationResult +
				", clientResults=" + clientResults +
				", errorDescription='" + errorDescription + '\'' +
				'}';
	}
}
