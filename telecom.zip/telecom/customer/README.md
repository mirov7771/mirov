###Proxy Сервис для методов из CustomerServicesPort

- SOAP: GetBranch --> REST: sbermobile/api/v1/getBranch
- SOAP: GetAvailableServicesByRatePlan --> REST: sbermobile/api/v1/getAvailableServicesByRatePlan

####Properties
- application.telecom.url - урл вэб-сервиса (soap)
- application.telecom.service - название эндпоинта вэб-сервиса (soap)
- application.telecom.timeout -  время ожидания ответа от вэб-сервиса (soap)
- application.telecom.system -  очередь
- application.stub.branchid - заглушка branchid (при application.stub.branch = true)
- application.stub.userlogin - заглушка userlogin (при application.stub.branch = true)