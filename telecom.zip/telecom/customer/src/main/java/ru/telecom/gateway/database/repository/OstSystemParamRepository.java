package ru.telecom.gateway.database.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.telecom.gateway.database.model.OstSystemParam;

import java.util.List;
import java.util.Optional;

@Repository
public interface OstSystemParamRepository extends CrudRepository<OstSystemParam, String> {
    List<OstSystemParam> findByCodeInAndOutSystemCode(List<String> code, String outSystemCode);
    Optional<OstSystemParam> findByCodeAndOutSystemCode(String code, String outSystemCode);
}
