package ru.telecom.gateway.service.get.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.constant.Constants;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.req.GetAvailableServicesByRatePlanReq;
import ru.telecom.gateway.controller.get.dto.req.GetBranchReq;
import ru.telecom.gateway.controller.get.dto.req.GetCustomerCreditPaymentsCorrectionsReq;
import ru.telecom.gateway.controller.get.dto.req.GetCustomerProfileReq;
import ru.telecom.gateway.controller.get.dto.res.GetAvailableServicesByRatePlanRes;
import ru.telecom.gateway.controller.get.dto.res.GetBranchRes;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerCreditPaymentsCorrectionsRes;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerProfileRes;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.http.dto.CustomerProfileResponse;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.xml.customer.*;

import static ru.telecom.gateway.constant.Constants.Params.*;
import static ru.telecom.gateway.util.ObjectUtils.nvl;

@Service
@RequiredArgsConstructor
@Slf4j
public class GetServiceImpl implements GetService {

    private final SoapAPIGate soapAPIGate;
    private final RestAPIGate restAPIGate;
    private final OstSystemParamRepository ostSystemParamRepository;
    private final MappingConfig mappingConfig;
    private final DateBuilder dateBuilder;

    @Value("${application.stub.branchid:0}")
    private String stubBranchId;
    @Value("${application.stub.userlogin:0}")
    private String stubUserLogin;

    @Override
    public GetBranchRes getBranch(GetBranchReq req) {
        GetBranchRes res = new GetBranchRes();

        List<OstSystemParam> params = ostSystemParamRepository.findByCodeInAndOutSystemCode(CODES, mappingConfig.getSystemCode());

        log.info("Check if stub is On");
        if (!CollectionUtils.isEmpty(params)) {
            if (Boolean.TRUE.equals(params.stream().anyMatch(i -> STUB_GB.equalsIgnoreCase(i.getCode()) && Y.equalsIgnoreCase(i.getValue())))) {
                log.info("Stub Error On");
                throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Указаны не все обязательные атрибуты для поиска.", null);
            }

            if (Boolean.TRUE.equals(params.stream().anyMatch(i -> SUBST_BRANCH_965.equalsIgnoreCase(i.getCode()) && Y.equalsIgnoreCase(i.getValue())))) {
                log.info("Stub Branch On");
                res.setResult(new ResultDto(Constants.OK, Constants.SUCCESS_MESSAGE));
                res.setBranch(List.of(new GetBranchRes.BranchDto() {{
                    setBranchId(new BigDecimal(stubBranchId));
                    setUserLogin(stubUserLogin);
                }}));

                return res;
            }
        }

        log.info("Stub is Off");
        GetBranch input = new GetBranch();
        if (StringUtils.hasText(req.getOkatoCode())) {
            input.setOkatoCode(req.getOkatoCode());
        }
        if (StringUtils.hasText(req.getOsbCode())) {
            input.setOsbCode(req.getOsbCode());
        }
        if (StringUtils.hasText(req.getTerrBankCode())) {
            input.setTerrBankCode(req.getTerrBankCode());
        }
        GetBranchResponse output = soapAPIGate.getBranch(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "Указаны не все обязательные атрибуты для поиска.", null);

        BranchData returnData = output.getReturn();
        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        if (!CollectionUtils.isEmpty(returnData.getBranches())){
            res.setBranch(returnData.getBranches()
                    .stream()
                    .map(i -> {
                        GetBranchRes.BranchDto dto = new GetBranchRes.BranchDto();
                        dto.setBranchId(i.getBranchId());
                        dto.setUserLogin(i.getUserLogin());
                        return dto;
                    })
                    .collect(Collectors.toList()));
        }
        return res;
    }

    @Override
    public GetAvailableServicesByRatePlanRes getAvailableServicesByRatePlan(GetAvailableServicesByRatePlanReq req) {
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode("STUB_GASBRP", mappingConfig.getSystemCode());
        if (param.isPresent() && "Y".equalsIgnoreCase(param.get().getValue())){
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "По указанному тарифному плану нет данных для отображения", null);
        }
        GetAvailableServicesByRatePlanRes res = new GetAvailableServicesByRatePlanRes();
        GetAvailableServicesByRatePlan input = new GetAvailableServicesByRatePlan();
        input.setBranchId(req.getBranchId());
        GetAvailableServicesByRatePlanResponse output = soapAPIGate.getAvailableServicesByRatePlan(input);

        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "По указанному тарифному плану нет данных для отображения", null);

        AvailableServicesByRatePlanData returnData = output.getReturn();
        if (returnData.getResult() != null)
            res.setResult(new ResultDto(returnData.getResult().getCode(), returnData.getResult().getMessageUser()));
        if (!CollectionUtils.isEmpty(returnData.getAvailableServicesByRatePlen())){
            res.setAvailableServicesByRatePlan(returnData.getAvailableServicesByRatePlen()
                    .stream()
                    .map(i -> {
                        GetAvailableServicesByRatePlanRes.AvailableServicesByRatePlan dto = new GetAvailableServicesByRatePlanRes.AvailableServicesByRatePlan();
                        dto.setServiceId(i.getServiceId());
                        dto.setRatePlanId(i.getRatePlanId());
                        dto.setServiceName(i.getServiceName());
                        dto.setFirstMonth(i.getFirstMonth());
                        dto.setNextMonth(i.getNextMonth());
                        return dto;
                    })
                    .collect(Collectors.toList()));
        }
        return res;
    }

    @Override
    public GetCustomerCreditPaymentsCorrectionsRes getCustomerCreditPaymentsCorrections(GetCustomerCreditPaymentsCorrectionsReq req) {
        Optional<OstSystemParam> param = ostSystemParamRepository.findByCodeAndOutSystemCode("STUB_CUSTCREDPAYCORR", mappingConfig.getSystemCode());
        if (param.isPresent() && "Y".equalsIgnoreCase(param.get().getValue())){
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "За указанный период нет данных для отображения", null);
        }
        GetCustomerCreditPaymentsCorrections input = new GetCustomerCreditPaymentsCorrections();
        input.setMsisdn(req.getMsisdn());
        input.setDateFrom(dateBuilder.convertDate(req.getDateFrom()));
        input.setDateTo(dateBuilder.convertDate(req.getDateTo()));
        GetCustomerCreditPaymentsCorrectionsResponse output = soapAPIGate.getCustomerCreditPaymentsCorrections(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, "За указанный период нет данных для отображения", null);
        GetCustomerCreditPaymentsCorrectionsRes res = new GetCustomerCreditPaymentsCorrectionsRes();
        if (output.getReturn().getResult() != null)
            res.setResult(new ResultDto(output.getReturn().getResult().getCode(), output.getReturn().getResult().getMessageUser()));
        if (!CollectionUtils.isEmpty(output.getReturn().getCustomerCreditPaymentsCorrections())){
            res.setCustomerCreditPaymentsCorrections(output.getReturn().getCustomerCreditPaymentsCorrections()
                    .stream()
                    .map(i -> {
                        GetCustomerCreditPaymentsCorrectionsRes.CustomerCreditPaymentsCorrections paymentsCorrections
                                = new GetCustomerCreditPaymentsCorrectionsRes.CustomerCreditPaymentsCorrections();
                        paymentsCorrections.setCorrectionId(i.getCorrectionId());
                        paymentsCorrections.setCorrectionType(i.getCorrectionType());
                        paymentsCorrections.setCorrectionSubType(i.getCorrectionSubType());
                        paymentsCorrections.setCorrectionValue(i.getCorrectionValue());
                        paymentsCorrections.setCorrectionDate(dateBuilder.convertDate(i.getCorrectionDate()));
                        paymentsCorrections.setCreUser(i.getCreUser());
                        paymentsCorrections.setCreDate(dateBuilder.convertDate(i.getCreDate()));
                        paymentsCorrections.setDelUser(i.getDelUser());
                        paymentsCorrections.setDelDate(dateBuilder.convertDate(i.getDelDate()));
                        paymentsCorrections.setBillingId(i.getBillingId());
                        paymentsCorrections.setBalanceName(i.getBalanceName());
                        paymentsCorrections.setCreUserId(i.getCreUserId());
                        paymentsCorrections.setDelUserId(i.getDelUserId());
                        paymentsCorrections.setReason(i.getReason());
                        paymentsCorrections.setItgcId(i.getItgcId());
                        paymentsCorrections.setQuotaId(i.getQuotaId());
                        paymentsCorrections.setCorrectionTypeId(i.getCorrectionTypeId());
                        paymentsCorrections.setAccount(i.getAccount());
                        return paymentsCorrections;
                    })
                    .collect(Collectors.toList()));
        }
        return res;
    }

    @Override
    public GetCustomerProfileRes getCustomerProfile(GetCustomerProfileReq req) {
        GetCustomerProfileRes res = new GetCustomerProfileRes();
        CustomerProfileResponse output = restAPIGate.customerProfile(req.getMsisdn());
        if (output == null)
            throw new TelecomException(Constants.ERROR, HttpStatus.BAD_REQUEST, Constants.SERVICE_NOT_AVAILABLE, null);
        res.setResult(new ResultDto(nvl(output.getErrorCode(), Constants.OK), nvl(output.getErrorText(), Constants.SUCCESS_MESSAGE)));
        GetCustomerProfileRes.CustomerProfile profile = new GetCustomerProfileRes.CustomerProfile();
        if (CollectionUtils.isEmpty(output.getLinks()))
            profile.setLinks(output.getLinks().stream()
                    .map(i -> {
                        GetCustomerProfileRes.CustomerProfile.Link link = new GetCustomerProfileRes.CustomerProfile.Link();
                        link.setHref(i.getHref());
                        link.setName(i.getName());
                        link.setRel(i.getRel());
                        link.setKind(i.getKind());
                        return link;
                    })
                    .collect(Collectors.toList()));

        profile.setMsisdn(output.getMsisdn());
        profile.setIsEsim(output.getIsEsim());
        profile.setClientIdentified(output.getClientIdentified());
        profile.setBranchId(output.getBranchId());
        profile.setDealerId(output.getDealerId());
        profile.setDealerName(output.getDealerName());
        profile.setClntId(output.getClntId());
        profile.setSubsId(output.getSubsId());
        profile.setClntJurTypeId(output.getClntJurTypeId());
        profile.setClntJurTypeName(output.getClntJurTypeName());
        profile.setClntPayTypeId(output.getClntPayTypeId());
        profile.setClntPayTypeName(output.getClntPayTypeName());
        profile.setSubsTypeId(output.getSubsTypeId());
        profile.setSubsTypeName(output.getSubsTypeName());
        profile.setIcc(output.getIcc());
        profile.setImsi(output.getImsi());
        profile.setChangeSimCount(output.getChangeSimCount());
        profile.setStateId(output.getStateId());
        profile.setStateName(output.getStateName());
        profile.setContractNum(output.getContractNum());
        profile.setAccount(output.getAccount());
        profile.setSignDate(output.getSignDate());
        profile.setRegistrationDate(output.getRegistrationDate());
        profile.setActivationDate(output.getActivationDate());
        profile.setBlockDate(output.getBlockDate());
        profile.setBalance(output.getBalance());
        profile.setTarPlanId(output.getTarPlanId());
        profile.setTarPlanName(output.getTarPlanName());
        profile.setServiceId(output.getServiceId());
        profile.setServiceName(output.getServiceName());
        profile.setClntName(output.getClntName());
        profile.setLastName(output.getLastName());
        profile.setFirstName(output.getFirstName());
        profile.setMiddleName(output.getMiddleName());
        profile.setDateOfBirth(output.getDateOfBirth());
        profile.setPlaceOfBirth(output.getPlaceOfBirth());
        profile.setGenderId(output.getGenderId());
        profile.setGenderName(output.getGenderName());
        profile.setPassport(output.getPassport());
        profile.setDocId(output.getDocId());
        profile.setDocName(output.getDocName());
        profile.setDocSeries(output.getDocSeries());
        profile.setDocNumber(output.getDocNumber());
        profile.setDocAuthority(output.getDocAuthority());
        profile.setDocDate(output.getDocDate());
        profile.setDocDivisionCode(output.getDocDivisionCode());
        profile.setClntAddress(output.getClntAddress());
        profile.setPostCode(output.getPostCode());
        profile.setCountry(output.getCountry());
        profile.setRegion(output.getRegion());
        profile.setSubregion(output.getSubregion());
        profile.setCity(output.getCity());
        profile.setStreet(output.getStreet());
        profile.setHouse(output.getHouse());
        profile.setBuilding(output.getBuilding());
        profile.setApartment(output.getApartment());
        profile.setInn(output.getInn());
        profile.setContactPhone(output.getContactPhone());
        profile.setEmail(output.getEmail());
        profile.setFax(output.getFax());
        profile.setSberBankId(output.getSberBankId());
        profile.setSaleChannel(output.getSaleChannel());
        profile.setMnpOperatorName(output.getMnpOperatorName());
        profile.setMnpPortingDate(output.getMnpPortingDate());
        profile.setDeviceModel(output.getDeviceModel());
        profile.setErrorCode(output.getErrorCode());
        profile.setErrorText(output.getErrorText());

        res.setCustomerProfile(profile);
        return res;
    }
}
