package ru.telecom.gateway.controller.get;

import static ru.telecom.gateway.constant.Constants.APPLICATION_JSON_VALUE;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_TM;
import static ru.telecom.gateway.constant.Constants.Headers.RQ_UID;
import static ru.telecom.gateway.constant.Constants.Headers.SUBSYSTEM_CODE;
import static ru.telecom.gateway.constant.Constants.SUB_MOCK;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.telecom.gateway.builder.ResponseBuilder;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.base.support.SberApiError;
import ru.telecom.gateway.controller.get.dto.req.GetAvailableServicesByRatePlanReq;
import ru.telecom.gateway.controller.get.dto.req.GetBranchReq;
import ru.telecom.gateway.controller.get.dto.req.GetCustomerCreditPaymentsCorrectionsReq;
import ru.telecom.gateway.controller.get.dto.req.GetCustomerProfileReq;
import ru.telecom.gateway.controller.get.dto.res.GetAvailableServicesByRatePlanRes;
import ru.telecom.gateway.controller.get.dto.res.GetBranchRes;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerCreditPaymentsCorrectionsRes;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerProfileRes;
import ru.telecom.gateway.service.get.GetService;
import ru.telecom.gateway.service.mock.MockService;

import javax.validation.Valid;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
@Tag(name = "Get Methods")
public class GetController {

    private final GetService service;
    private final MockService mockService;

    @Operation(summary = "Метод получения филиала", description = "Операция предназначена для получения Идентификатора Филиала в АСР Invoice и привязанного к нему Системного пользователя", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetBranchRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"branch\": [\n" +
                                    "        {\n" +
                                    "            \"branchId\": 996,\n" +
                                    "            \"userLogin\": \"UFS_SAMARA\"\n" +
                                    "        }\n" +
                                    "    ],\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetBranchReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"terrBankCode\": \"111\",\n" +
                                    "    \"osbCode\": \"1212\",\n" +
                                    "    \"okatoCode\": \"12345678901\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getBranch", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetBranchRes> getBranch(@RequestBody GetBranchReq req) {
        return ResponseBuilder.build(service.getBranch(req));
    }


    @Operation(summary = "Метод получения списка доступных тарифов/пакетов/услуг", description = "Получение списка доступных тарифов/пакетов/услуг для подключения клиенту/абоненту по Id филиала", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetAvailableServicesByRatePlanRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"availableServicesByRatePlan\": [\n" +
                                    "        {\n" +
                                    "           \"ratePlanId\": 996,\n" +
                                    "           \"serviceId\": 1440,\n" +
                                    "           \"serviceName\": \"MINUTES:1500\",\n" +
                                    "           \"firstMonth\": 200,\n" +
                                    "           \"nextMonth\": 499\n" +
                                    "        }\n" +
                                    "    ],\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetAvailableServicesByRatePlanReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"branchId\": 2\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getAvailableServicesByRatePlan", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetAvailableServicesByRatePlanRes> getAvailableServicesByRatePlan(@Valid @RequestBody GetAvailableServicesByRatePlanReq req){
        return ResponseBuilder.build(service.getAvailableServicesByRatePlan(req));
    }

    @Operation(summary = "Метод получения корректировок по клиенту/абоненту за период", description = "Получение корректировок по клиенту/абоненту за период", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetCustomerCreditPaymentsCorrectionsRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"customerCreditPaymentsCorrections\": [\n" +
                                    "        {\n" +
                                    "            \"correctionId\": 592,\n" +
                                    "            \"correctionType\": \"Корр. услуг\",\n" +
                                    "            \"correctionSubType\": \"Возврат средств\",\n" +
                                    "            \"correctionValue\": 355.0004,\n" +
                                    "            \"correctionDate\": \"1990-08-30T13:13:13.000+0300\",\n" +
                                    "            \"creUser\": \"Хозяин схемы\",\n" +
                                    "            \"creDate\": \"1990-08-30T13:13:13.000+0300\",\n" +
                                    "            \"delUser\": \"Test\",\n" +
                                    "            \"delDate\": \"1990-08-30T13:13:13.000+0300\",\n" +
                                    "            \"billingId\": 6433510,\n" +
                                    "            \"balanceName\": \"Административный\",\n" +
                                    "            \"creUserId\": 1,\n" +
                                    "            \"delUserId\": 2,\n" +
                                    "            \"reason\": \"перенос отрицательного баланса\",\n" +
                                    "            \"itgcId\": 215,\n" +
                                    "            \"quotaId\": 996,\n" +
                                    "            \"correctionTypeId\": 1,\n" +
                                    "            \"account\": 3203\n" +
                                    "        }\n" +
                                    "    ],\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetCustomerCreditPaymentsCorrectionsReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"msisdn\": \"9876543210\",\n" +
                                    "  \"dateFrom\": \"1990-08-30T13:13:13.000+0300\",\n" +
                                    "  \"dateTo\": \"1990-08-30T13:13:13.000+0300\"\n" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getCustomerCreditPaymentsCorrections", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetCustomerCreditPaymentsCorrectionsRes> getCustomerCreditPaymentsCorrections(@Valid @RequestBody GetCustomerCreditPaymentsCorrectionsReq req){
        return ResponseBuilder.build(service.getCustomerCreditPaymentsCorrections(req));
    }

    @Operation(summary = "Метод получения полного профиля Клиента/Абонента", description = "Операция получения полного профиля Клиента/Абонента", responses = {
            @ApiResponse(responseCode = "200", description = "ok", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetCustomerProfileRes.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "    \"customerProfile\": {\n" +
                                    "    \"msisdn\": \"9303349082\",\n" +
                                    "    \"isEsim\": \"Y\",\n" +
                                    "    \"clientIdentified\": \"Y\",\n" +
                                    "    \"branchId\": 965,\n" +
                                    "    \"dealerId\": 108,\n" +
                                    "    \"dealerName\": \"Дилер ЕФС\",\n" +
                                    "    \"clntId\": 4562317,\n" +
                                    "    \"subsId\": 4584078,\n" +
                                    "    \"clntJurTypeId\": 1,\n" +
                                    "    \"clntJurTypeName\": \"Физ. лицо\",\n" +
                                    "    \"clntPayTypeId\": 1,\n" +
                                    "    \"clntPayTypeName\": \"Авансовый\",\n" +
                                    "    \"subsTypeId\": 1,\n" +
                                    "    \"subsTypeName\": \"PREPAID\",\n" +
                                    "    \"icc\": \"89701501077122546533\",\n" +
                                    "    \"imsi\": \"250507712254653\",\n" +
                                    "    \"changeSimCount\": 1,\n" +
                                    "    \"stateId\": 1,\n" +
                                    "    \"stateName\": \"Активен\",\n" +
                                    "    \"contractNum\": \"419656\",\n" +
                                    "    \"account\": 9533400,\n" +
                                    "    \"signDate\": \"2022-01-12T11:24:37+03:00\",\n" +
                                    "    \"registrationDate\": null,\n" +
                                    "    \"activationDate\": \"2022-01-27T17:32:15+03:00\",\n" +
                                    "    \"blockDate\": null,\n" +
                                    "    \"balance\": 0,\n" +
                                    "    \"tarPlanId\": 37,\n" +
                                    "    \"tarPlanName\": \"Москва\",\n" +
                                    "    \"serviceId\": null,\n" +
                                    "    \"serviceName\": null,\n" +
                                    "    \"clntName\": \"ВЫХУХОЛЕВ КАПИБАРА УТКОНОСОВИЧ\",\n" +
                                    "    \"lastName\": \"ВЫХУХОЛЕВ\",\n" +
                                    "    \"firstName\": \"КАПИБАРА\",\n" +
                                    "    \"middleName\": \"УТКОНОСОВИЧ\",\n" +
                                    "    \"dateOfBirth\": \"1990-01-01T12:12:12+03:00\",\n" +
                                    "    \"placeOfBirth\": \"г. Астрахань\",\n" +
                                    "    \"genderId\": 1,\n" +
                                    "    \"genderName\": \"Женский\",\n" +
                                    "    \"passport\": \"1205 987865 01.01.90 СОВЕТСКИМ РОВД Г. АСТРАХАНИ\",\n" +
                                    "    \"docId\": 1,\n" +
                                    "    \"docName\": \"Паспорт гражданина РФ\",\n" +
                                    "    \"docSeries\": \"1205\",\n" +
                                    "    \"docNumber\": \"987865\",\n" +
                                    "    \"docAuthority\": \"СОВЕТСКИМ РОВД Г. АСТРАХАНИ\",\n" +
                                    "    \"docDate\": \"1990-01-01T00:00:00+03:00\",\n" +
                                    "    \"docDivisionCode\": \"302-005\",\n" +
                                    "    \"clntAddress\": \"414024, АСТРАХАНСКАЯ, СОВЕТСКИЙ МКРН., АСТРАХАНЬ, ЮЖНАЯ, 1, 1\",\n" +
                                    "    \"postCode\": \"414024\",\n" +
                                    "    \"country\": null,\n" +
                                    "    \"region\": \"АСТРАХАНСКАЯ\",\n" +
                                    "    \"subregion\": \"СОВЕТСКИЙ МКРН.\",\n" +
                                    "    \"city\": \"АСТРАХАНЬ\",\n" +
                                    "    \"street\": \"ЮЖНАЯ\",\n" +
                                    "    \"house\": \"1\",\n" +
                                    "    \"building\": null,\n" +
                                    "    \"apartment\": \"1\",\n" +
                                    "    \"inn\": null,\n" +
                                    "    \"contactPhone\": null,\n" +
                                    "    \"email\": \"ETATARINTSEV@SBERBANK-TELE.COM\",\n" +
                                    "    \"fax\": null,\n" +
                                    "    \"sberBankId\": \"db1fc658b7a0dae8eff23ed947798cd28e99c0a3a7bd5d82d1030a35e3ad5d114a4e397a0ee15da4\",\n" +
                                    "    \"saleChannel\": \"MAP_SBOL_ESIM\",\n" +
                                    "    \"mnpOperatorName\": null,\n" +
                                    "    \"mnpPortingDate\": null,\n" +
                                    "    \"deviceModel\": null,\n" +
                                    "    \"errorCode\": \"OK\",\n" +
                                    "    \"errorText\": \"Операция выполнена успешно\",\n" +
                                    "    \"links\": [\n" +
                                    "        {\n" +
                                    "            \"rel\": \"self\",\n" +
                                    "            \"href\": \"http://10.77.35.234:7003/CustomerManager/rest/v1/CustomerProfile/9303349082\",\n" +
                                    "            \"name\": \"CustomerProfile\",\n" +
                                    "            \"kind\": \"item\"\n" +
                                    "        },\n" +
                                    "        {\n" +
                                    "            \"rel\": \"canonical\",\n" +
                                    "            \"href\": \"http://10.77.35.234:7003/CustomerManager/rest/v1/CustomerProfile/9303349082\",\n" +
                                    "            \"name\": \"CustomerProfile\",\n" +
                                    "            \"kind\": \"item\"\n" +
                                    "        }\n" +
                                    "    ]\n" +
                                    "    },\n" +
                                    "    \"result\": {\n" +
                                    "        \"code\": \"OK\",\n" +
                                    "        \"messageUser\": \"Операция выполнена успешно\"\n" +
                                    "    }\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "400", description = "Bad Request", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка запроса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "401", description = "Unauthorized", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"401\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "403", description = "Forbidden", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"403\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "404", description = "Not Found", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"404\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "405", description = "Method Not Allowed", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"405\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "429", description = "Too Many Requests", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = SberApiError.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"httpCode\": \"429\",\n" +
                                    "  \"httpMessage\": \"Error\",\n" +
                                    "  \"moreInformation\": \"Error\"\n" +
                                    "}"))
            }),
            @ApiResponse(responseCode = "500", description = "Internal server error", content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = ResultDto.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"code\": \"ERROR\",\n" +
                                    "  \"messageUser\": \"Ошибка сервиса.: Текст возникшей ошибки\"\n" +
                                    "}"))
            }, headers = {
                    @Header(name = RQ_UID, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema(type = "string", pattern = "^(([0-9]|[a-f]|[A-F]){32})$", maxLength = 32, example = "d0c5d5d03e074ad7ba2e2e248eef7e9c")),
                    @Header(name = RQ_TM, description = "Время осуществления транзакции", required = true, schema = @Schema(type = "string", pattern = "^(.*){29}$", maxLength = 29, example = "2020-08-05T10:31:12+0300")),
                    @Header(name = SUBSYSTEM_CODE, description = "Код витрины потребителя", required = true, schema = @Schema(type = "string", pattern = "^(.*){32}$", maxLength = 32, example = "SBOL_PRO"))
            }),
            @ApiResponse(responseCode = "503", description = "Service Unavailable", content = {@Content(examples = @ExampleObject())}),
            @ApiResponse(responseCode = "504", description = "Gateway Timeout", content = {@Content(examples = @ExampleObject())})
    })
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
            description = "Запрос метода",
            content = {
                    @Content(mediaType = APPLICATION_JSON_VALUE, schema = @Schema(implementation = GetCustomerProfileReq.class),
                            examples = @ExampleObject(value = "{\n" +
                                    "  \"msisdn\": \"9876543210\"" +
                                    "}"))
            }
    )
    @Parameters(
            value = {
                    @Parameter(name = RQ_UID, in = ParameterIn.HEADER, description = "Сквозной идентификатор транзакции", required = true, schema = @Schema
                            (example = "d0c5d5d03e074ad7ba2e2e248eef7e9c", maxLength = 32, pattern = "^(([0-9]|[a-f]|[A-F]){32})$", type = "string")),
                    @Parameter(name = RQ_TM, in = ParameterIn.HEADER, description = "Время осуществления транзакции", required = true, schema = @Schema
                            (example = "2020-08-05T10:31:12+0300", maxLength = 29, pattern = "^(.*){29}$", type = "string")),
                    @Parameter(name = SUBSYSTEM_CODE, in = ParameterIn.HEADER, description = "Код витрины потребителя", required = true, schema = @Schema
                            (example = "SBOL_PRO", maxLength = 32, pattern = "^(.*){32}$", type = "string"))
            }
    )
    @PostMapping(value = "getCustomerProfile", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetCustomerProfileRes> getCustomerProfile(@RequestHeader(SUBSYSTEM_CODE) String subsystemCode,
                                                                    @Valid @RequestBody GetCustomerProfileReq req) {
        if (SUB_MOCK.equalsIgnoreCase(subsystemCode))
            return ResponseBuilder.build(mockService.getCustomerProfile());
        else
            return ResponseBuilder.build(service.getCustomerProfile(req));
    }

}
