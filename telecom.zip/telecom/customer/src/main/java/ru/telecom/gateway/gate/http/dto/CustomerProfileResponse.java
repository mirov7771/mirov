package ru.telecom.gateway.gate.http.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.Data;
import ru.telecom.gateway.config.MultiDateDeserializer;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerProfileRes;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CustomerProfileResponse {
    @JsonProperty("Msisdn")
    private String msisdn;
    @JsonProperty("IsEsim")
    private String isEsim;
    @JsonProperty("ClientIdentified")
    private String clientIdentified;
    @JsonProperty("BranchId")
    private BigDecimal branchId;
    @JsonProperty("DealerId")
    private BigDecimal dealerId;
    @JsonProperty("DealerName")
    private String dealerName;
    @JsonProperty("ClntId")
    private BigDecimal clntId;
    @JsonProperty("SubsId")
    private BigDecimal subsId;
    @JsonProperty("ClntJurTypeId")
    private BigDecimal clntJurTypeId;
    @JsonProperty("ClntJurTypeName")
    private String clntJurTypeName;
    @JsonProperty("ClntPayTypeId")
    private BigDecimal clntPayTypeId;
    @JsonProperty("ClntPayTypeName")
    private String clntPayTypeName;
    @JsonProperty("SubsTypeId")
    private BigDecimal subsTypeId;
    @JsonProperty("SubsTypeName")
    private String subsTypeName;
    @JsonProperty("Icc")
    private String icc;
    @JsonProperty("Imsi")
    private String imsi;
    @JsonProperty("ChangeSimCount")
    private BigDecimal changeSimCount;
    @JsonProperty("StateId")
    private BigDecimal stateId;
    @JsonProperty("StateName")
    private String stateName;
    @JsonProperty("ContractNum")
    private String contractNum;
    @JsonProperty("Account")
    private String account;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("SignDate")
    private Date signDate;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("RegistrationDate")
    private Date registrationDate;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("ActivationDate")
    private Date activationDate;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("BlockDate")
    private Date blockDate;
    @JsonProperty("Balance")
    private BigDecimal balance;
    @JsonProperty("TarplanId")
    private BigDecimal tarPlanId;
    @JsonProperty("TarplanName")
    private String tarPlanName;
    @JsonProperty("ServiceId")
    private BigDecimal serviceId;
    @JsonProperty("ServiceName")
    private String serviceName;
    @JsonProperty("ClntName")
    private String clntName;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("MiddleName")
    private String middleName;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("DateOfBirth")
    private Date dateOfBirth;
    @JsonProperty("PlaceOfBirth")
    private String placeOfBirth;
    @JsonProperty("GenderId")
    private BigDecimal genderId;
    @JsonProperty("GenderName")
    private String genderName;
    @JsonProperty("Pasport")
    private String passport;
    @JsonProperty("DocId")
    private BigDecimal docId;
    @JsonProperty("DocName")
    private String docName;
    @JsonProperty("DocSeries")
    private String docSeries;
    @JsonProperty("DocNumber")
    private String docNumber;
    @JsonProperty("DocAuthority")
    private String docAuthority;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("DocDate")
    private Date docDate;
    @JsonProperty("DocDivisionCode")
    private String docDivisionCode;
    @JsonProperty("ClntAddress")
    private String clntAddress;
    @JsonProperty("Postcode")
    private String postCode;
    @JsonProperty("Country")
    private String country;
    @JsonProperty("Region")
    private String region;
    @JsonProperty("Subregion")
    private String subregion;
    @JsonProperty("City")
    private String city;
    @JsonProperty("Street")
    private String street;
    @JsonProperty("House")
    private String house;
    @JsonProperty("Building")
    private String building;
    @JsonProperty("Apartment")
    private String apartment;
    @JsonProperty("Inn")
    private String inn;
    @JsonProperty("ContactPhone")
    private String contactPhone;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("Fax")
    private String fax;
    @JsonProperty("SberbankId")
    private String sberBankId;
    @JsonProperty("SaleChannel")
    private String saleChannel;
    @JsonProperty("MnpOperatorName")
    private String mnpOperatorName;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("MnpPortingDate")
    private Date mnpPortingDate;
    @JsonProperty("DeviceModel")
    private String deviceModel;
    @JsonProperty("ErrorCode")
    private String errorCode;
    @JsonProperty("ErrorText")
    private String errorText;
    @JsonProperty("links")
    private List<GetCustomerProfileRes.CustomerProfile.Link> links;

    @Data
    public static class Link {
        @JsonProperty("rel")
        private String rel;
        @JsonProperty("href")
        private String href;
        @JsonProperty("name")
        private String name;
        @JsonProperty("kind")
        private String kind;
    }
}
