package ru.telecom.gateway.gate.http;

import ru.telecom.gateway.gate.http.dto.CustomerProfileResponse;

public interface RestAPIGate {
    CustomerProfileResponse customerProfile(String msisdn);
}
