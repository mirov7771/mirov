package ru.telecom.gateway.service.change.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.builder.DateBuilder;
import ru.telecom.gateway.config.MappingConfig;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.change.dto.req.ChangeSubscriberServiceStatusReq;
import ru.telecom.gateway.controller.change.dto.res.ChangeSubscriberServiceStatusRes;
import ru.telecom.gateway.database.model.OstSystemParam;
import ru.telecom.gateway.database.procedure.ProcedureCaller;
import ru.telecom.gateway.database.repository.OstSystemParamRepository;
import ru.telecom.gateway.exception.TelecomException;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.service.change.ChangeService;
import ru.telecom.gateway.util.ObjectUtils;
import ru.telecom.gateway.xml.customer.ChangeSubscriberServiceStatus;
import ru.telecom.gateway.xml.customer.ChangeSubscriberServiceStatusResponse;
import ru.telecom.gateway.xml.customer.ServiceStatus;
import ru.telecom.gateway.xml.customer.ServiceStatusOperation;

import java.math.BigDecimal;
import java.util.*;

import static ru.telecom.gateway.constant.Constants.OK;
import static ru.telecom.gateway.constant.Constants.SUCCESS_MESSAGE;

@Service
@RequiredArgsConstructor
@Slf4j
public class ChangeServiceImpl implements ChangeService {

    private final SoapAPIGate soapAPIGate;
    private final DateBuilder dateBuilder;
    private final OstSystemParamRepository ostSystemParamRepository;
    private final ProcedureCaller procedureCaller;
    private final MappingConfig mappingConfig;

    @Override
    public ChangeSubscriberServiceStatusRes changeSubscriberServiceStatus(ChangeSubscriberServiceStatusReq req) {
        List<OstSystemParam> params = ostSystemParamRepository.findByCodeInAndOutSystemCode(List.of("STUB_CSSS", "CSSS_REMAP", "CSSS_MAP_FULL", "CSSS_MAP_MEDIUM"), mappingConfig.getSystemCode());
        ChangeSubscriberServiceStatusRes res = new ChangeSubscriberServiceStatusRes();
        if (!CollectionUtils.isEmpty(params)) {
            log.debug("Params found {}", params);
            if (params.stream().anyMatch(i -> "STUB_CSSS".equalsIgnoreCase(i.getCode()) && "Y".equalsIgnoreCase(i.getValue())))
                throw new TelecomException("external_operation_error", HttpStatus.BAD_REQUEST, "Ошибка выполнения внешней операции", "Получен запрос changeSubscriberService(Ошибка при изменении статуса услуги абонента updateSubscriberService - SQLException(message=err_service_is_not_allowed,code=-109);");
            if (params.stream().anyMatch(i -> "CSSS_REMAP".equalsIgnoreCase(i.getCode()) && "Y".equalsIgnoreCase(i.getValue()))) {
                log.debug("Start remap servId {}", req.getServiceId());
                if (BigDecimal.valueOf(31).equals(req.getServiceId())
                        && req.getSubscriberId() != null
                        && StringUtils.hasText(req.getMsisdn())){
                    log.debug("Start call changeSubsServStatusAsfs");
                    Map<String, String> asfs = procedureCaller.changeSubsServStatusAsfs(req.getMsisdn(), req.getSubscriberId(), mappingConfig.getSystemCode());
                    log.debug("End call changeSubsServStatusAsfs [{}]", asfs);
                    if (StringUtils.hasText(asfs.get("o_err_code"))){
                        if (OK.equalsIgnoreCase(asfs.get("o_err_code"))){
                            res.setResult(new ResultDto(OK, SUCCESS_MESSAGE));
                            res.setServiceOrderId(new BigDecimal("31"));
                            if (StringUtils.hasText(asfs.get("o_err_text")))
                                res.setLog(asfs.get("o_err_text").substring(0, 200));
                            return res;
                        } else {
                            throw new TelecomException("WARNING", HttpStatus.BAD_REQUEST, "Ошибка выполения внешней операции", asfs.get("o_err_text"));
                        }
                    }
                }

                BigDecimal ratePlanId = null;
                if (req.getSubscriberId() != null){
                    ratePlanId = procedureCaller.getRatePlanId(req.getSubscriberId());
                } else if (StringUtils.hasText(req.getMsisdn())){
                    BigDecimal subscriberId = procedureCaller.getSubscriberId(req.getMsisdn());
                    log.debug("SubscriberId {}", subscriberId);
                    if (subscriberId != null)
                        ratePlanId = procedureCaller.getRatePlanId(subscriberId);
                }

                log.debug("RatePlanId {}", ratePlanId);

                if (ratePlanId != null){
                    if (Boolean.TRUE.equals(isFull(ratePlanId))){
                        log.debug("CSSS_MAP_FULL check");
                        params.stream().filter(i ->
                            "CSSS_MAP_FULL".equalsIgnoreCase(i.getCode()) && StringUtils.hasText(i.getValue())
                        ).findFirst()
                                .ifPresent(ostSystemParam -> req.setServiceId(ObjectUtils.getRemapServId(req.getServiceId(), ostSystemParam.getValue())));
                    } else {
                        log.debug("CSSS_MAP_MEDIUM check");
                        params.stream().filter(i ->
                                "CSSS_MAP_MEDIUM".equalsIgnoreCase(i.getCode()) && StringUtils.hasText(i.getValue())
                        ).findFirst()
                                .ifPresent(ostSystemParam -> req.setServiceId(ObjectUtils.getRemapServId(req.getServiceId(), ostSystemParam.getValue())));
                    }
                }
            }
        }
        ChangeSubscriberServiceStatus input = new ChangeSubscriberServiceStatus();
        input.setMsisdn(req.getMsisdn());
        input.setServiceId(req.getServiceId());
        ServiceStatusOperation operation = new ServiceStatusOperation();
        operation.setSerivceStaus(ServiceStatus.fromValue(req.getServiceStatus()));
        input.setServiceOperation(operation);
        input.setChargeOrder(req.getChargeOrder());
        if (req.getTargetDate() != null)
            input.setTargetDate(dateBuilder.convertDate(req.getTargetDate()));
        ChangeSubscriberServiceStatusResponse output = soapAPIGate.changeSubscriberServiceStatus(input);
        if (output == null || output.getReturn() == null)
            throw new TelecomException("external_operation_error", HttpStatus.BAD_REQUEST, "Ошибка выполнения внешней операции", "Получен запрос changeSubscriberService(Ошибка при изменении статуса услуги абонента updateSubscriberService - SQLException(message=err_service_is_not_allowed,code=-109);");
        res.setResult(new ResultDto(output.getReturn().getCode(), output.getReturn().getMessageUser()));
        return res;
    }

    private boolean isFull(BigDecimal ratePlanId) {
        List<OstSystemParam> rates = ostSystemParamRepository.findByCodeInAndOutSystemCode( List.of("RATE_PLAN_ID_BY_REGION_TYPE"), "INVOICE_API");
        if (!CollectionUtils.isEmpty(rates) && StringUtils.hasText(rates.get(0).getValue())) {
            List<String> ratePlanIdList = new ArrayList<>(Arrays.asList(rates.get(0).getValue().split(",")));
            for (String s : ratePlanIdList) {
                if (ratePlanId.compareTo(new BigDecimal(s)) == 0) {
                    return true;
                }
            }
        }
        return false;
    }

}
