package ru.telecom.gateway.database.procedure;

import lombok.extern.slf4j.Slf4j;
import org.hibernate.procedure.ProcedureOutputs;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.telecom.gateway.util.ObjectUtils;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class ProcedureCaller {

    @PersistenceContext
    private EntityManager entityManager;

    public Map<String, String> changeSubsServStatusAsfs(String iMsisdn, BigDecimal iSubsId, String iCurrentSystem){
        Map<String, String> retMap = new HashMap<>();
        StoredProcedureQuery query = entityManager
                .createStoredProcedureQuery("IN_P_CUSTOMER.change_subs_serv_status_asfs")
                .registerStoredProcedureParameter(1, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(2, BigDecimal.class, ParameterMode.IN)
                .registerStoredProcedureParameter(3, String.class, ParameterMode.IN)
                .registerStoredProcedureParameter(4, String.class, ParameterMode.OUT)
                .registerStoredProcedureParameter(5, String.class, ParameterMode.OUT)
                .setParameter(1, iMsisdn)
                .setParameter(2, iSubsId)
                .setParameter(3, iCurrentSystem);

        try {
            query.execute();

            String errCode = (String) query.getOutputParameterValue(4);
            String errText = (String) query.getOutputParameterValue(5);
            if (StringUtils.hasText(errCode))
                retMap.put("o_err_code", errCode);
            if (StringUtils.hasText(errCode))
                retMap.put("o_err_text", errText);
        } catch (Exception e) {
            log.error("Error calling procedure IN_P_CUSTOMER.change_subs_serv_status_asfs: ", e);
        } finally {
            query.unwrap(ProcedureOutputs.class).release();
        }
        return retMap;
    }

    public BigDecimal getSubscriberId(String msisdn){
        return ObjectUtils.getBigDecimal(entityManager
                .createNativeQuery("SELECT IN_P_CUSTOMER.GET_SUBS_ID(:MSISDN, null) FROM DUAL")
                .setParameter("MSISDN", msisdn)
                .getSingleResult());
    }

    public BigDecimal getRatePlanId(BigDecimal subscriberId){
        return ObjectUtils.getBigDecimal(entityManager
                .createNativeQuery("SELECT IN_P_CUSTOMER.GET_RATE_PLAN_ID(:SUBS_ID, null) FROM DUAL")
                .setParameter("SUBS_ID", subscriberId)
                .getSingleResult());
    }

}
