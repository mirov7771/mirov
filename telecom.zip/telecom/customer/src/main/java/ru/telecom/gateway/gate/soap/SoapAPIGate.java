package ru.telecom.gateway.gate.soap;

import ru.telecom.gateway.xml.customer.*;

public interface SoapAPIGate {
    default GetBranchResponse getBranch(GetBranch req) {
        return null;
    }
    default GetAvailableServicesByRatePlanResponse getAvailableServicesByRatePlan(GetAvailableServicesByRatePlan req) {
        return null;
    }
    default ChangeSubscriberServiceStatusResponse changeSubscriberServiceStatus(ChangeSubscriberServiceStatus req) {
        return null;
    }
    default GetCustomerCreditPaymentsCorrectionsResponse getCustomerCreditPaymentsCorrections(GetCustomerCreditPaymentsCorrections req) {
        return null;
    }
}
