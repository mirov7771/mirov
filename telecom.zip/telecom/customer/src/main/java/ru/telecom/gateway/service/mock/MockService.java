package ru.telecom.gateway.service.mock;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.controller.base.res.BaseRes;
import ru.telecom.gateway.controller.base.support.ResultDto;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerProfileRes;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class MockService {

    public BaseRes execute() {
        BaseRes res = new BaseRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        return res;
    }

    public GetCustomerProfileRes getCustomerProfile() {
        GetCustomerProfileRes res = new GetCustomerProfileRes();
        res.setResult(new ResultDto(
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125),
                StringUtils.repeat("OK", 125)
        ));
        BigDecimal maxNum = new BigDecimal("100000000000");
        GetCustomerProfileRes.CustomerProfile customerProfile = new GetCustomerProfileRes.CustomerProfile();
        customerProfile.setMsisdn("00000000000000000000");
        customerProfile.setContactPhone("00000000000000000000");
        customerProfile.setIsEsim("Y");
        customerProfile.setClientIdentified("Y");
        customerProfile.setBranchId(maxNum);
        customerProfile.setDealerId(maxNum);
        customerProfile.setDealerName(StringUtils.repeat("OK", 125));
        customerProfile.setClntId(maxNum);
        customerProfile.setSubsId(maxNum);
        customerProfile.setClntJurTypeId(maxNum);
        customerProfile.setClntJurTypeName(StringUtils.repeat("OK", 125));
        customerProfile.setClntPayTypeId(maxNum);
        customerProfile.setClntPayTypeName(StringUtils.repeat("OK", 125));
        customerProfile.setSubsTypeId(maxNum);
        customerProfile.setSubsTypeName(StringUtils.repeat("OK", 125));
        customerProfile.setIcc(StringUtils.repeat("1", 250));
        customerProfile.setImsi(StringUtils.repeat("1", 250));
        customerProfile.setChangeSimCount(maxNum);
        customerProfile.setStateId(maxNum);
        customerProfile.setStateName(StringUtils.repeat("OK", 125));
        customerProfile.setContractNum(StringUtils.repeat("0", 250));
        customerProfile.setAccount(StringUtils.repeat("0", 250));
        customerProfile.setSignDate(new Date());
        customerProfile.setRegistrationDate(new Date());
        customerProfile.setActivationDate(new Date());
        customerProfile.setBlockDate(new Date());
        customerProfile.setBalance(maxNum);
        customerProfile.setTarPlanId(maxNum);
        customerProfile.setTarPlanName(StringUtils.repeat("0", 250));
        customerProfile.setServiceId(maxNum);
        customerProfile.setServiceName(StringUtils.repeat("0", 250));
        customerProfile.setClntName(StringUtils.repeat("F", 250));
        customerProfile.setLastName(StringUtils.repeat("F", 250));
        customerProfile.setFirstName(StringUtils.repeat("F", 250));
        customerProfile.setMiddleName(StringUtils.repeat("F", 250));
        customerProfile.setDateOfBirth(new Date());
        customerProfile.setPlaceOfBirth(StringUtils.repeat("F", 250));
        customerProfile.setGenderId(maxNum);
        customerProfile.setGenderName(StringUtils.repeat("F", 250));
        customerProfile.setPassport(StringUtils.repeat("F", 250));
        customerProfile.setDocId(maxNum);
        customerProfile.setDocName(StringUtils.repeat("P", 250));
        customerProfile.setDocSeries(StringUtils.repeat("1", 250));
        customerProfile.setDocNumber(StringUtils.repeat("1", 250));
        customerProfile.setDocAuthority(StringUtils.repeat("1", 250));
        customerProfile.setDocDate(new Date());
        customerProfile.setDocDivisionCode(StringUtils.repeat("1", 250));
        customerProfile.setClntAddress(StringUtils.repeat("A", 250));
        customerProfile.setPostCode(StringUtils.repeat("2", 250));
        customerProfile.setCountry(StringUtils.repeat("A", 250));
        customerProfile.setRegion(StringUtils.repeat("A", 250));
        customerProfile.setSubregion(StringUtils.repeat("A", 250));
        customerProfile.setCity(StringUtils.repeat("A", 250));
        customerProfile.setStreet(StringUtils.repeat("A", 250));
        customerProfile.setHouse(StringUtils.repeat("1", 250));
        customerProfile.setBuilding(StringUtils.repeat("2", 250));
        customerProfile.setApartment(StringUtils.repeat("3", 250));
        customerProfile.setInn(StringUtils.repeat("3", 250));
        customerProfile.setEmail(StringUtils.repeat("3", 250));
        customerProfile.setFax(StringUtils.repeat("3", 250));
        customerProfile.setSberBankId(StringUtils.repeat("3", 250));
        customerProfile.setSaleChannel(StringUtils.repeat("3", 250));
        customerProfile.setMnpOperatorName(StringUtils.repeat("O", 250));
        customerProfile.setMnpPortingDate(new Date());
        customerProfile.setDeviceModel(StringUtils.repeat("O", 250));
        customerProfile.setErrorCode(StringUtils.repeat("O", 250));
        customerProfile.setErrorText(StringUtils.repeat("O", 250));
        customerProfile.setLinks(new ArrayList<>());
        GetCustomerProfileRes.CustomerProfile.Link link = new GetCustomerProfileRes.CustomerProfile.Link();
        link.setRel(StringUtils.repeat("O", 150));
        link.setKind(StringUtils.repeat("O", 150));
        link.setName(StringUtils.repeat("O", 250));
        link.setHref(StringUtils.repeat("O", 250));
        customerProfile.getLinks().addAll(Stream.generate(() -> link).limit(120).collect(Collectors.toList()));
        res.setCustomerProfile(customerProfile);
        return res;
    }

}
