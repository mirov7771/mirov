package ru.telecom.gateway.service.get;

import ru.telecom.gateway.controller.get.dto.req.GetAvailableServicesByRatePlanReq;
import ru.telecom.gateway.controller.get.dto.req.GetBranchReq;
import ru.telecom.gateway.controller.get.dto.req.GetCustomerCreditPaymentsCorrectionsReq;
import ru.telecom.gateway.controller.get.dto.req.GetCustomerProfileReq;
import ru.telecom.gateway.controller.get.dto.res.GetAvailableServicesByRatePlanRes;
import ru.telecom.gateway.controller.get.dto.res.GetBranchRes;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerCreditPaymentsCorrectionsRes;
import ru.telecom.gateway.controller.get.dto.res.GetCustomerProfileRes;
import ru.telecom.gateway.service.Service;

public interface GetService extends Service {
    GetBranchRes getBranch(GetBranchReq req);
    GetAvailableServicesByRatePlanRes getAvailableServicesByRatePlan(GetAvailableServicesByRatePlanReq req);
    GetCustomerCreditPaymentsCorrectionsRes getCustomerCreditPaymentsCorrections(GetCustomerCreditPaymentsCorrectionsReq req);
    GetCustomerProfileRes getCustomerProfile(GetCustomerProfileReq req);
}
