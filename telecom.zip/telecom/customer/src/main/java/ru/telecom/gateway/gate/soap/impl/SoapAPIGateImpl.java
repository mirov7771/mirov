package ru.telecom.gateway.gate.soap.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import ru.telecom.gateway.gate.soap.SoapAPIGate;
import ru.telecom.gateway.xml.customer.*;

public class SoapAPIGateImpl extends WebServiceGatewaySupport implements SoapAPIGate {

    @Value("${application.telecom.service}")
    private String serviceUrl;

    @Override
    public GetBranchResponse getBranch(GetBranch req) {
        return (GetBranchResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetAvailableServicesByRatePlanResponse getAvailableServicesByRatePlan(GetAvailableServicesByRatePlan req) {
        return (GetAvailableServicesByRatePlanResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public ChangeSubscriberServiceStatusResponse changeSubscriberServiceStatus(ChangeSubscriberServiceStatus req) {
        return (ChangeSubscriberServiceStatusResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }

    @Override
    public GetCustomerCreditPaymentsCorrectionsResponse getCustomerCreditPaymentsCorrections(GetCustomerCreditPaymentsCorrections req) {
        return (GetCustomerCreditPaymentsCorrectionsResponse) getWebServiceTemplate()
                .marshalSendAndReceive(serviceUrl, req);
    }
}
