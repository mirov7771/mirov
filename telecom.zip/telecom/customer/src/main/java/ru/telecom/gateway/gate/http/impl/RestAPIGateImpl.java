package ru.telecom.gateway.gate.http.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import ru.telecom.gateway.gate.http.RestAPIGate;
import ru.telecom.gateway.gate.http.client.RestGate;
import ru.telecom.gateway.gate.http.dto.CustomerProfileResponse;

@Service
@RequiredArgsConstructor
public class RestAPIGateImpl implements RestAPIGate {

    private final RestGate restGate;
    @Value("${application.telecom.rest.url}")
    private String url;
    @Value("${application.telecom.rest.user}")
    private String user;
    @Value("${application.telecom.rest.password}")
    private String password;

    @Override
    public CustomerProfileResponse customerProfile(String msisdn) {
        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(user, password);
        return restGate.call(CustomerProfileResponse.class,
                url,
                msisdn,
                null,
                null,
                HttpMethod.GET,
                headers,
                MediaType.parseMediaType("application/vnd.oracle.adf.action+json"));
    }
}
