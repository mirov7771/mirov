package ru.telecom.gateway.util;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class ObjectUtils {

    public static Map<String, String> stringToMap(String string, String keyValueDelimiter, String entryDelimiter) {
        Map<String, String> map = new HashMap<>();
        String[] pairs = string.split(entryDelimiter);
        for (String pair : pairs) {
            String[] keyValue = pair.split(keyValueDelimiter);
            map.put(keyValue[0].trim(), keyValue[1].trim());
        }
        return map;
    }

    public static BigDecimal getRemapServId(BigDecimal servId, String remapValue) {
        log.debug("Start getRemapServId with params {}, {}", servId, remapValue);
        BigDecimal remapServId = servId;
        Map<String, String> servMap = ObjectUtils.stringToMap(remapValue, ":", ";");
        for (Map.Entry<String, String> entry : servMap.entrySet()) {
            BigDecimal key = getBigDecimal(entry.getKey());
            if (key.compareTo(servId) == 0) {
                remapServId = getBigDecimal(entry.getValue());
                break;
            }
        }
        log.debug("End getRemapServId with param {}", remapServId);
        return remapServId;
    }

    public static BigDecimal getBigDecimal(Object value) {
        BigDecimal ret = null;
        if (value != null) {
            if (value instanceof BigDecimal) {
                ret = (BigDecimal)value;
            } else if (value instanceof String) {
                ret = new BigDecimal((String)value);
            } else if (value instanceof BigInteger) {
                ret = new BigDecimal((BigInteger)value);
            } else {
                if (!(value instanceof Number)) {
                    throw new ClassCastException("Not possible to coerce [" + value + "] from class " + value.getClass() + " into a BigDecimal.");
                }
                ret = BigDecimal.valueOf(((Number) value).doubleValue());
            }
        }
        return ret;
    }

    public static <T> T nvl(T a, T b) {
        return a != null? a : b;
    }
}
