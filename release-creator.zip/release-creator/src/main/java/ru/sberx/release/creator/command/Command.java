package ru.sberx.release.creator.command;

import java.util.Map;

public interface Command {
    void execute(Map<String, String> commands);
}
