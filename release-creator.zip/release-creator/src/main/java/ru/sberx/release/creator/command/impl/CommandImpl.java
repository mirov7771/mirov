package ru.sberx.release.creator.command.impl;

import lombok.RequiredArgsConstructor;
import org.eclipse.jgit.api.CreateBranchCommand;
import org.eclipse.jgit.api.Git;
import org.springframework.stereotype.Component;
import ru.sberx.release.creator.command.Command;
import ru.sberx.release.creator.config.ProjectConfiguration;
import ru.sberx.release.creator.utils.GitUtils;

import java.util.Map;

@Component
@RequiredArgsConstructor
public class CommandImpl implements Command {

    private final GitUtils gitUtils;
    private final ProjectConfiguration configuration;

    @Override
    public void execute(Map<String, String> commands) {

        String branch = commands.get("branch");
        String path = commands.get("path");
        String gitUri = commands.get("git");
        configuration.getProjects().forEach(i -> {
            try {
                Git git = new Git(gitUtils.getGitRepo(path + i));
                CreateBranchCommand createBranch = git.branchCreate();
                createBranch.setName(branch);
                createBranch.setForce(true);
                createBranch.setStartPoint("origin/develop");
                createBranch.call();

                gitUtils.push(gitUri + i + ".git", path + i, branch);
            } catch (Exception e) {
                throw new RuntimeException("Unable to create branch " + commands.get("branch"), e);
            }
        });
    }
}
