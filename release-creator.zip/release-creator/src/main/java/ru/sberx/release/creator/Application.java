package ru.sberx.release.creator;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import ru.sberx.release.creator.command.Command;

import java.util.Map;

@SpringBootApplication
@ConfigurationPropertiesScan
@RequiredArgsConstructor
public class Application implements ApplicationRunner {

	private final Command command;

	@Value("${branch}")
	private String branch;
	@Value("${path}")
	private String path;
	@Value("${application.git.uri}")
	private String uri;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		command.execute(Map.of(
				"branch", branch,
				"path", path,
				"git", uri
		));
	}
}
