package ru.sberx.release.creator.utils;

import com.cdancy.jenkins.rest.JenkinsClient;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PushCommand;
import org.eclipse.jgit.errors.UnsupportedCredentialItem;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.transport.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Component
public class GitUtils {

    @Value("${application.git.user}")
    private String user;
    @Value("${application.git.password}")
    private String password;

    public Repository getGitRepo(String overrideDirectory) throws IOException {
        File dir = new File(overrideDirectory);
        if (!dir.exists()) {
            throw new RuntimeException("Directory " + dir.getAbsolutePath() + " does not exists");
        }
        FileRepositoryBuilder builder = new FileRepositoryBuilder();
        builder.setWorkTree(dir);
        return builder.build();
    }

    public void push(String remote,
                     String overrideDirectory,
                     String branch) {
        try {

            CredentialsProvider token = new UsernamePasswordCredentialsProvider(user, password);
            CredentialsProvider ssl = new CredentialsProvider() {
                @Override
                public boolean supports(CredentialItem... items) {
                    for ( CredentialItem item : items ) {
                        if ( (item instanceof CredentialItem.YesNoType) ) {
                            return true;
                        }
                    }
                    return false;
                }

                @Override
                public boolean get(URIish uri, CredentialItem... items) throws UnsupportedCredentialItem {
                    for ( CredentialItem item : items ) {
                        if ( item instanceof CredentialItem.YesNoType ) {
                            (( CredentialItem.YesNoType ) item).setValue(true);
                            return true;
                        }
                    }
                    return false;
                }

                @Override
                public boolean isInteractive() {
                    return false;
                }
            };

            CredentialsProvider cp = new ChainingCredentialsProvider(ssl, token);

            Git git = new Git(getGitRepo(overrideDirectory));
            PushCommand push = git.push();
            push.setRemote(remote);
            push.setForce(true);
            push.setCredentialsProvider(cp);

            push.setRefSpecs(new RefSpec(branch + ":" + branch));
            push.call();

            Thread.sleep(500);
            startBuild();
        } catch (Exception e) {
            throw new RuntimeException("Unable to push to " + remote, e);
        }
    }

    private void startBuild(){
        JenkinsClient client = JenkinsClient.builder()
                .endPoint("http://127.0.0.1:8080")
                .credentials(user + ":" + password)
                .build();
        client.api().jobsApi().buildWithParameters(null,
                "sberx-audit_develop_check",
                Map.of("delay", List.of("0sec"), "CUSTOM_BRANCH", List.of("release/D-01.028.01")));
    }

}
