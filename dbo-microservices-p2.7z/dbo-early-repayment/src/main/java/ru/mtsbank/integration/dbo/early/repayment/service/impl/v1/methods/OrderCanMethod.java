package ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.early.repayment.builders.OrderCreateUpdateBuilder;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.OrderCanReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.OrderCanRes;
import ru.mtsbank.integration.mts.xsd.orderCanRq.BankSvcRq;
import ru.mtsbank.integration.mts.xsd.orderCanRq.OrderCanRq;
import ru.mtsbank.integration.mts.xsd.orderCanRq.OrderInfo;
import ru.mtsbank.integration.mts.xsd.orderCanRq.ServerInfoType;
import ru.mtsbank.integration.mts.xsd.orderCanRs.OrderCanRs;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@Component("ordercan")
@Slf4j
public class OrderCanMethod {

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private OrderCreateUpdateBuilder orderCreateUpdateBuilder;

    public OrderCanRes call(OrderCanReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start ordercan service", uid);
        OrderCanRes res = new OrderCanRes();
        try {
            String operId = req.getOperationID().toString();
            Map<String, Object> orderMap = orderCreateUpdateBuilder.getOrderInfoByOperId(operId);
            Long orderId = null;
            String state = "";
            if (!orderMap.isEmpty()) {
                orderId = (Long) orderMap.get("OrderId");
                state = (String) orderMap.get("State");
            }
            if (state.equalsIgnoreCase("cancel")) {
                res.createError(1004, "Заявка на досрочное погашение уже аннулирована", 409, null, null, "OrderCan", uid);
            } else if (state.equalsIgnoreCase("done")) {
                res.createError(1004, "Заявка на досрочное погашение уже аннулирована", 409, null, "OrderCan запрос повторной отмены заявки", "OrderCan", uid);
            } else {

                OrderCanRq rq = new OrderCanRq();
                ServerInfoType serverInfoType = new ServerInfoType();

                serverInfoType.setSPName("MTS_EIP_UMP");
                serverInfoType.setMsgReceiver("RBO");
                serverInfoType.setMsgUID(uid);
                serverInfoType.setRqUID(uid);
                serverInfoType.setBpId("MTS_DBO_DP_CAN");
                serverInfoType.setServerDt(getXmlGregorianCalendar(new Date()));
                serverInfoType.setMsgType("OrderCanRq");
                rq.setServerInfo(serverInfoType);

                BankSvcRq bankSvcRq = new BankSvcRq();
                OrderInfo orderInfo = new OrderInfo();
                orderInfo.setOrderId(operId);
                bankSvcRq.setOrderInfo(orderInfo);
                rq.setBankSvcRq(bankSvcRq);

                String messageXml = xmlUnmarshaler.createXml(rq);

                String answerXml = esbGate.sendInfoMessageWithAnswer(messageXml);

                OrderCanRs rs = xmlUnmarshaler.parse(OrderCanRs.class, answerXml);
                if (rs == null || rs.getBankSvcRs() == null || rs.getBankSvcRs().getStatus() == null) {
                    res.createError(501, "Сервис временно недоступен", 400, null, "PmtSchedule РБО недоступен", "OrderCan", uid);
                } else {
                    String sc = rs.getBankSvcRs().getStatus().getStatusCode();
                    if (sc.equals("0")) {
                        res.setOperationDescription(rs.getBankSvcRs().getStatus().getStatusDesc());
                        res.setRequestId(uid);
                        if (orderId != null) {
                            orderCreateUpdateBuilder.updateOrder(orderId, 2, null, null, null, null);
                        }
                    } else {
                        res.createError(sc.equals("1") ? 1004 : 501
                                , sc.equals("1") ? "Заявка на досрочное погашение уже аннулирована" : "Сервис временно недоступен"
                                , sc.equals("1") ? 409 : 400
                                , null
                                , sc.equals("1") ? "OrderCan запрос повторной отмены заявки" : rs.getBankSvcRs().getStatus().getStatusDesc()
                                , "OrderCan", uid);
                    }
                }
            }
        } catch (IOException e){
            log.error("{} Error in ordercan service {}", uid, Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен", 400, null, null, "ordercan", null);
        }
        log.info("{} End ordercan service", uid);
        return res;
    }

}
