package ru.mtsbank.integration.dbo.early.repayment.notifications;

public interface NotificationService {

    void handleRequest(String xmlRequest) throws Exception;

}
