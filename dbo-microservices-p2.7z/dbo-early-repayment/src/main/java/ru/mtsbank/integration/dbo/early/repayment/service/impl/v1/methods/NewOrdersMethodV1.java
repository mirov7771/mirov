package ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.NewOrdersRes;
import ru.mtsbank.integration.dbo.early.repayment.service.general.NewOrdersMethod;

import java.util.UUID;

import static ru.mts.dbo.utils.Utils.nvl;

@Component
@Slf4j
public class NewOrdersMethodV1 extends NewOrdersMethod {

    @Override
    public NewOrdersRes call(NewOrdersReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start neworders service",uid);
        NewOrdersRes res = new NewOrdersRes();
        String clientId = nvl(req.getClientId(), "").toLowerCase();
        if (req.getPrepaymentKind() == 1 && !clientId.contains("ios")){
            res.createError(1003
                    , "Частичное досрочное погашение будет недоступно до следующего обновления приложения — приносим извинения. Вы можете воспользоваться этой опцией на сайте банка: online.mtsbank.ru."
                    , 409
                    , null
                    , null
                    , "NewOrders"
                    , uid);
        } else {
            send(req, res, uid);
        }
        log.info("{} End neworders service",uid);
        return res;
    }

}
