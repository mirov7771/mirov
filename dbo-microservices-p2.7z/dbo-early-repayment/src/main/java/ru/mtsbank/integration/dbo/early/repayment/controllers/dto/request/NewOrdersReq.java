package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

@Getter @Setter
public class NewOrdersReq extends BaseRequest {

    @JsonProperty("prepaymentKind")
    @NotNull
    private Integer prepaymentKind;
    @JsonProperty("amount")
    @NotNull
    private BigDecimal amount;
    @JsonProperty("recalcMode")
    private Integer recalcMode;
    @JsonProperty("contractCreditID")
    @NotNull
    private Long contractCreditID;
    @JsonProperty("channelSysName")
    private String channelSysName;
    @JsonProperty("date")
    @NotNull
    private Date date;
    @JsonProperty("contractCreditNumber")
    @NotNull
    private String contractCreditNumber;
    @JsonProperty("otpToken")
    private String otpToken;
    @JsonProperty("clientId")
    private String clientId;

}
