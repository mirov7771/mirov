package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class NewOrdersRes extends BaseResponse {

    @JsonProperty("operationID")
    private Long operationID;
    @JsonProperty("expiryDate")
    private String expiryDate;

}
