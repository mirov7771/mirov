package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

@Getter
public class PmtOrdersReq extends BaseRequest {

    @JsonProperty("state")
    private String state;
    @JsonProperty("contractCreditID")
    private Long contractCreditID;

}
