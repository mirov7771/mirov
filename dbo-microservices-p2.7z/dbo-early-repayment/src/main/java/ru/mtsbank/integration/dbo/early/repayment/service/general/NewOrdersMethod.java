package ru.mtsbank.integration.dbo.early.repayment.service.general;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.gates.SmsGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.early.repayment.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.early.repayment.builders.OrderCreateUpdateBuilder;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.NewOrdersRes;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.CustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.IdentityCardType;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.PersonInfoTypeCustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.orderAddRq.*;
import ru.mtsbank.integration.mts.xsd.orderAddRs.BankSvcRs;
import ru.mtsbank.integration.mts.xsd.orderAddRs.OrderAddRs;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

import static ru.mts.dbo.utils.Utils.*;

@Component
@Slf4j
public abstract class NewOrdersMethod {

    @Autowired
    public EsbGate esbGate;
    @Autowired
    public CustSearchInqRqBuilder custSearchInqRqBuilder;
    @Autowired
    public XmlUnmarshaler xmlUnmarshaler;
    @Autowired
    public OrderCreateUpdateBuilder orderCreateUpdateBuilder;
    @Autowired
    public SmsGate smsGate;

    public abstract NewOrdersRes call(NewOrdersReq req);

    protected void send(NewOrdersReq req, NewOrdersRes res, String uid){
        try {
            String checkOtpTokenStatus = smsGate.execute(req.getOtpToken(), "earlyrepayment", req.getRboID());
            if (checkOtpTokenStatus.equals("GOOD_ANSWER")) {
                Long extOrderId = orderCreateUpdateBuilder.saveOrder(req);

                String custSearchXml = xmlUnmarshaler.createXml(custSearchInqRqBuilder.createCustSearchInqRq(req.getRboID().toString(), uid));
                String custSearchAnswerXml = esbGate.sendSalesMessageWithAnswer(custSearchXml);
                CustSearchInqRs custSearchInqRs = xmlUnmarshaler.parse(CustSearchInqRs.class, custSearchAnswerXml);

                OrderAddRq rq = new OrderAddRq();
                ServerInfoType serverInfoType = new ServerInfoType();

                serverInfoType.setSPName("MTS_EIP_UMP");
                serverInfoType.setMsgReceiver("RBO");
                serverInfoType.setMsgUID(uid);
                serverInfoType.setRqUID(uid);
                serverInfoType.setMsgType("OrderAddRq");
                serverInfoType.setBpId("MTS_CREATE_CHDP");
                serverInfoType.setServerDt(getXmlGregorianCalendar(new Date()));
                rq.setServerInfo(serverInfoType);
                BankSvcRq bankSvcRq = new BankSvcRq();
                OrderInfo orderInfo = new OrderInfo();
                orderInfo.setRegDt(getFdxDate(new Date()));
                orderInfo.setPlanDt(getFdxDate(req.getDate()));
                switch (req.getPrepaymentKind()) {
                    case 0:
                        orderInfo.setOrderType("ПОЛН_ДОС_ГАШ");
                        break;
                    case 1:
                        orderInfo.setOrderType("ЧАСТ_ДОС_ГАШ");
                        break;
                }
                CurrencyAmount currencyAmount = new CurrencyAmount();
                currencyAmount.setAmt(req.getAmount());
                orderInfo.setCurAmt(currencyAmount);
                if (!req.getPrepaymentKind().equals(0)) {
                    int recalcMode = req.getRecalcMode() == null ? 0 : req.getRecalcMode();
                    switch (recalcMode) {
                        case 0:
                            orderInfo.setPmtReduction(true);
                            break;
                        case 1:
                            orderInfo.setPmtReduction(false);
                            break;
                    }
                }
                if (extOrderId != null)
                    orderInfo.setExtOrderId(extOrderId.toString());
                String channelSysName = req.getChannelSysName();
                String channel = "EK.IB";
                if (!StringUtils.isEmpty(channelSysName)) {
                    if (channelSysName.equalsIgnoreCase("IOS")) {
                        channel = "EK.IOS";
                    } else if (channelSysName.equalsIgnoreCase("ANDROID")) {
                        channel = "EK.ANDR";
                    }
                }
                orderInfo.setChannel(channel);
                bankSvcRq.setOrderInfo(orderInfo);
                LoanInfo loanInfo = new LoanInfo();
                loanInfo.setAgreemtNum(req.getContractCreditNumber());
                loanInfo.setLoanId(req.getContractCreditID().toString());
                bankSvcRq.setLoanInfo(loanInfo);
                CustInfo custInfo = new CustInfo();
                PersonInfo personInfo = new PersonInfo();
                if (custSearchInqRs != null
                        && custSearchInqRs.getBankSvcRs() != null
                        && custSearchInqRs.getBankSvcRs().getCustInfo() != null
                        && custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo() != null) {
                    PersonInfoTypeCustSearchInqRs custPersonInfo = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo();
                    personInfo.setFullName(custPersonInfo.getFullName());
                    IdentityCard identityCard = new IdentityCard();
                    if (custPersonInfo.getIdentityCard() != null && isNotEmpty(custPersonInfo.getIdentityCard())) {
                        for (IdentityCardType docItem : custPersonInfo.getIdentityCard()) {
                            String idType = docItem.getIdType();
                            Boolean isPrimary = docItem.isPrimary();
                            if (idType.equals("21") && Boolean.TRUE.equals(isPrimary)) {
                                identityCard.setIdType("PassportRF");
                                identityCard.setIdSeries(docItem.getIdSeries());
                                identityCard.setIdNum(docItem.getIdNum());
                                identityCard.setIssuedBy(docItem.getIssuedBy());
                                identityCard.setIssuedByCode(docItem.getIssuedByCode());
                                ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FdxDate issDate = docItem.getIssueDt();
                                if (issDate != null) {
                                    FdxDate issueDate = new FdxDate();
                                    issueDate.setDay(issDate.getDay());
                                    issueDate.setYear(issDate.getYear());
                                    issueDate.setMonth(issDate.getMonth());
                                    identityCard.setIssueDt(issueDate);
                                }
                                identityCard.setPrimary(true);
                                break;
                            }
                        }
                    }
                    personInfo.setIdentityCard(identityCard);
                }
                custInfo.setPersonInfo(personInfo);
                bankSvcRq.setCustInfo(custInfo);

                rq.setBankSvcRq(bankSvcRq);

                String messageXml = xmlUnmarshaler.createXml(rq);

                log.info("Send message to mq: " + messageXml);
                String answerXml = esbGate.sendInfoMessageWithAnswer(messageXml);

                OrderAddRs rs = xmlUnmarshaler.parse(OrderAddRs.class, answerXml);
                if (rs == null || rs.getBankSvcRs() == null || rs.getBankSvcRs().getOrderInfo() == null) {
                    res.createError(501, "Сервис временно недоступен", 400, null, "OrderAdd РБО недоступен", "NewOrders", uid);
                } else {
                    BankSvcRs bankSvcRs = rs.getBankSvcRs();
                    String orderId = bankSvcRs.getOrderInfo().getOrderId();
                    BigDecimal newMonthAmt = null;
                    Date newExpDate = null;
                    Long newTerm = null;
                    if (isDigits(orderId))
                        res.setOperationID(Long.parseLong(orderId));
                    if (bankSvcRs.getOrderInfo().getExpiryDt() != null) {
                        ru.mtsbank.integration.mts.xsd.orderAddRs.FdxDate fdxExpDate = bankSvcRs.getOrderInfo().getExpiryDt();
                        newExpDate = createJavaDate(fdxExpDate);
                        res.setExpiryDate(createJavaDateToStr(fdxExpDate));
                    }
                    if (bankSvcRs.getOrderInfo().getMonthlyAmt() != null) {
                        newMonthAmt = bankSvcRs.getOrderInfo().getMonthlyAmt().getAmt();
                    }
                    if (bankSvcRs.getOrderInfo().getTerm() != null) {
                        newTerm = bankSvcRs.getOrderInfo().getTerm().getCount();
                    }
                    Long errorCode = 0L;
                    if (bankSvcRs.getStatus() != null) {
                        String statusCode = bankSvcRs.getStatus().getStatusCode();
                        String statusDesc = nvl(bankSvcRs.getStatus().getStatusDesc(), "");
                        boolean noCred = statusDesc.contains("не найден, тип [PR_CRED]");
                        if (statusCode != null && !statusCode.equals("0")) {
                            if (statusCode.equals("100")) {
                                res.createError(501
                                        , "Уже существует заявка на досрочное погашение, создание повторной заявки невозможно."
                                        , 409
                                        , "100"
                                        , "OrderAdd попытка создания второй заявки на досрочное погашение"
                                        , "NewOrders", uid);
                            } else {
                                res.createError(Boolean.TRUE.equals(noCred) ? 1002 : 501
                                        , Boolean.TRUE.equals(noCred) ? String.format("Не найден кредит с ID %s", req.getContractCreditID()) : "Сервис временно недоступен"
                                        , Boolean.TRUE.equals(noCred) ? 406 : 400
                                        , null
                                        , Boolean.TRUE.equals(noCred) ? "OrderAdd попытка создания второй заявки на досрочное погашение" : statusDesc
                                        , "NewOrders", uid);
                            }
                            errorCode = 1L;
                        } else {
                            res.setRequestId(uid);
                        }
                    }
                    orderCreateUpdateBuilder.updateOrder(extOrderId, errorCode.equals(0L) ? 0 : 2, newMonthAmt, newExpDate, newTerm, orderId);
                }
            } else {
                res.createError(1020, "Передан неверный код подтверждения операции", 403, null, null, "NewOrders", uid);
            }
        } catch (IOException e){
            log.error("{} Error in new orders service {}", uid, Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен", 400, null, null, "neworders", null);
        }
    }

    protected FdxDate getFdxDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        FdxDate fdxDate = new FdxDate();
        fdxDate.setYear(year);
        fdxDate.setMonth(month+1);
        fdxDate.setDay(day);
        return fdxDate;
    }


    protected String createJavaDateToStr(ru.mtsbank.integration.mts.xsd.orderAddRs.FdxDate fdxDate) {
        Date date;
        String retDate = null;
        if(fdxDate != null) {
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            calendar.set(fdxDate.getYear(), fdxDate.getMonth()-1, fdxDate.getDay());
            date = calendar.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            retDate = sdf.format(date);
            retDate += "T00:00:00.000+0000";
        }
        return retDate;
    }

    protected Date createJavaDate(ru.mtsbank.integration.mts.xsd.orderAddRs.FdxDate fdxDate) {
        Date date = null;
        if(fdxDate != null) {
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            calendar.set(fdxDate.getYear(), fdxDate.getMonth()-1, fdxDate.getDay());
            date = calendar.getTime();
        }
        return date;
    }

}