package ru.mtsbank.integration.dbo.early.repayment.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.OrderCanReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtScheduleReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.*;
import ru.mtsbank.integration.dbo.early.repayment.service.Service;

import javax.validation.Valid;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Tag(name = "EarlyRepayment")
@RestController
@RequestMapping("dbo-early-repayment")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/PmtSchedule", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "получение доступных операционных дней для заявки ЧДП/ПДП"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = PmtScheduleRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> pmtSchedule(@PathVariable final String version
                                                   ,@Valid @RequestBody PmtScheduleReq req)
    {
        return ResponseBuilder.build(services.get(version).pmtSchedule(req));
    }

    @PostMapping(value = "{version}/OrderCan", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "отзыв ранее созданной заявки ЧДП/ПДП"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = OrderCanRes.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> orderCan(@PathVariable final String version
                                                ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                ,@RequestHeader(value = "authorization", required = false) String authorization
                                                ,@Valid @RequestBody OrderCanReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).orderCan(req));
    }

    @PostMapping(value = "{version}/NewOrders", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "формирование новой заявки ЧДП/ПДП"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = NewOrdersRes.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1","v2"}))
    public ResponseEntity<BaseResponse> newOrder(@PathVariable final String version
                                                ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                ,@RequestHeader(value = "client-id", required = false) String clientId
                                                ,@RequestHeader(value = "authorization", required = false) String authorization
                                                ,@Valid @RequestBody NewOrdersReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        if (req.getClientId() == null)
            req.setClientId(clientId);
        return ResponseBuilder.build(services.get(version).newOrder(req));
    }

    @PostMapping(value = "{version}/PmtOrders", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "получение заявок оформленных в канале ДБО"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = PmtOrdersRes.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> pmtOrders(@PathVariable final String version
                                                 ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                 ,@RequestHeader(value = "authorization", required = false) String authorization
                                                 ,@Valid @RequestBody PmtOrdersReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).pmtOrders(req));
    }

}
