package ru.mtsbank.integration.dbo.early.repayment.service.impl.v2.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.NewOrdersRes;
import ru.mtsbank.integration.dbo.early.repayment.service.general.NewOrdersMethod;

import java.util.UUID;

@Component
@Slf4j
public class NewOrdersMethodV2 extends NewOrdersMethod {

    @Override
    public NewOrdersRes call(NewOrdersReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start neworders service v2",uid);
        NewOrdersRes res = new NewOrdersRes();
        send(req, res, uid);
        log.info("{} End neworders service v2",uid);
        return res;
    }

}
