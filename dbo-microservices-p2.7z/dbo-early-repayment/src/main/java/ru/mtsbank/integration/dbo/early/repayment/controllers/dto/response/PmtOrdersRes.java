package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support.Order;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class PmtOrdersRes extends BaseResponse {

    @JsonProperty("orderList")
    private List<Order> orderList;

}
