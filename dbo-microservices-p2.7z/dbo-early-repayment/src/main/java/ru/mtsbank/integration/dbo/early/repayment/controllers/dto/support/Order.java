package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class Order {

    @JsonProperty("orderID")
    private Long orderID;
    @JsonProperty("operationID")
    private String operationID;
    @JsonProperty("contractCreditID")
    private Long contractCreditID;
    @JsonProperty("contractCreditNumber")
    private String contractCreditNumber;
    @JsonProperty("ownerID")
    private Long ownerID;
    @JsonProperty("channelSysName")
    private String channelSysName;
    @JsonProperty("prepaymentKind")
    private Integer prepaymentKind;
    @JsonProperty("recalcMode")
    private Integer recalcMode;
    @JsonProperty("creationDate")
    private Date creationDate;
    @JsonProperty("orderDate")
    private Date orderDate;
    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("orderState")
    private String orderState;
    @JsonProperty("newMontlyAmount")
    private BigDecimal newMontlyAmount;
    @JsonProperty("newExpDate")
    private Date newExpDate;
    @JsonProperty("newTerm")
    private Long newTerm;

}
