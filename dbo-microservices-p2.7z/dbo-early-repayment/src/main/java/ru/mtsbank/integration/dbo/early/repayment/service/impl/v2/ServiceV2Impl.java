package ru.mtsbank.integration.dbo.early.repayment.service.impl.v2;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.NewOrdersRes;
import ru.mtsbank.integration.dbo.early.repayment.service.Service;
import ru.mtsbank.integration.dbo.early.repayment.service.impl.v2.methods.NewOrdersMethodV2;

@RequiredArgsConstructor
@Component("v2")
public class ServiceV2Impl implements Service {

    private final NewOrdersMethodV2 newOrdersMethod;

    @Override
    public NewOrdersRes newOrder(NewOrdersReq req) {
        return newOrdersMethod.call(req);
    }

}
