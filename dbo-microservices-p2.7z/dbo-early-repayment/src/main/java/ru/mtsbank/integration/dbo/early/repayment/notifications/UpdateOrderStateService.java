package ru.mtsbank.integration.dbo.early.repayment.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.early.repayment.builders.OrderCreateUpdateBuilder;
import ru.mtsbank.integration.mts.xsd.OrderStatusMod.OrderStatusModNf;

@Component("dbo.earlyrepayment")
@Slf4j
public class UpdateOrderStateService implements NotificationService {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private OrderCreateUpdateBuilder orderCreateUpdateBuilder;

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start updateorderstate service");
        OrderStatusModNf nf = xmlUnmarshaler.parse(OrderStatusModNf.class, xmlRequest);
        if (nf != null
                && nf.getBankSvcRq() != null
                && nf.getBankSvcRq().getOrderInfo() != null
                && nf.getBankSvcRq().getOrderInfo().getOrderStatus() != null) {
            String operationId = nf.getBankSvcRq().getOrderInfo().getOrderId();
            String status = nf.getBankSvcRq().getOrderInfo().getOrderStatus().getStatusCode();
            Long orderId = orderCreateUpdateBuilder.getOrderByOperId(operationId);
            if (orderId != null) {
                orderCreateUpdateBuilder.updateOrder(orderId
                        , status.equalsIgnoreCase("PROV") ? 1 : 2
                        , null
                        , null
                        , null
                        , operationId);
            }
        }
        log.info("End updateorderstate service");
    }

}
