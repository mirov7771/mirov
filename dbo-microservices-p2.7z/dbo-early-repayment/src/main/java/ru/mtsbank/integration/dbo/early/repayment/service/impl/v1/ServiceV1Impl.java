package ru.mtsbank.integration.dbo.early.repayment.service.impl.v1;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.OrderCanReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtScheduleReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.NewOrdersRes;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.OrderCanRes;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.PmtOrdersRes;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.PmtScheduleRes;
import ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods.NewOrdersMethodV1;
import ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods.OrderCanMethod;
import ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods.PmtOrdersMethod;
import ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods.PmtScheduleMethod;
import ru.mtsbank.integration.dbo.early.repayment.service.Service;

@RequiredArgsConstructor
@Component("v1")
public class ServiceV1Impl implements Service {

    private final NewOrdersMethodV1 newOrdersMethod;
    private final OrderCanMethod orderCanMethod;
    private final PmtOrdersMethod pmtOrdersMethod;
    private final PmtScheduleMethod pmtScheduleMethod;

    @Override
    public NewOrdersRes newOrder(NewOrdersReq req) {
        return newOrdersMethod.call(req);
    }

    @Override
    public OrderCanRes orderCan(OrderCanReq req) {
        return orderCanMethod.call(req);
    }

    @Override
    public PmtOrdersRes pmtOrders(PmtOrdersReq req) {
        return pmtOrdersMethod.call(req);
    }

    @Override
    public PmtScheduleRes pmtSchedule(PmtScheduleReq req) {
        return pmtScheduleMethod.call(req);
    }
}
