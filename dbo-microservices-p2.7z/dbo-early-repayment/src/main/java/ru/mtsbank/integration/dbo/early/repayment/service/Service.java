package ru.mtsbank.integration.dbo.early.repayment.service;

import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.OrderCanReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtScheduleReq;

public interface Service {

    default BaseResponse newOrder(NewOrdersReq req){return null;}
    default BaseResponse orderCan(OrderCanReq req){return null;}
    default BaseResponse pmtOrders(PmtOrdersReq req){return null;}
    default BaseResponse pmtSchedule(PmtScheduleReq req){return null;}

}
