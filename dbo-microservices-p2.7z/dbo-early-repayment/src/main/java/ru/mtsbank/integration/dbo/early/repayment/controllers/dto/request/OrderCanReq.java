package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;

@Getter
public class OrderCanReq extends BaseRequest {

    @JsonProperty("operationID")
    @NotNull
    private Long operationID;

}
