package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class Operation {

    @JsonProperty("operationID")
    private String operationID;
    @JsonProperty("creationDate")
    private String creationDate;
    @JsonProperty("planDate")
    private String planDate;
    @JsonProperty("operationAmount")
    private BigDecimal operationAmount;
    @JsonProperty("operationKind")
    private String operationKind;
    @JsonProperty("orderID")
    private Long orderId;

}
