package ru.mtsbank.integration.dbo.early.repayment.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.early.repayment.dao.model.Orders;

import java.util.Date;
import java.util.List;

@Repository
public interface OrdersRepository extends CrudRepository<Orders, String> {

    List<Orders> findByOwnerId(Long ownerId);
    List<Orders> findByOwnerIdAndOrderState(Long ownerId, String orderState);
    List<Orders> findByOwnerIdAndContractCreditId(Long ownerId, Long contractCreditId);
    List<Orders> findByOwnerIdAndOrderStateAndContractCreditId(Long ownerId, String orderState, Long contractCreditId);
    Orders findByOrderId(Long orderId);
    Orders findByOperationId(String operationId);
    List<Orders> findByContractCreditIdAndOrderState(Long contractCreditId, String orderState);

    @Query(value = "SELECT * FROM orders WHERE contractcreditid = :contractCreditId AND orderstate = 'processing' AND (orderdate >= :orderDate OR orderdate is null)",
    nativeQuery = true)
    List<Orders> getOrders(@Param("contractCreditId") Long contractCreditId, @Param("orderDate") Date orderDate);

}
