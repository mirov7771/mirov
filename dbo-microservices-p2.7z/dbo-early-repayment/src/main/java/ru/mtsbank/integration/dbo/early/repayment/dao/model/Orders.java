package ru.mtsbank.integration.dbo.early.repayment.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "ORDERS")
@Getter @Setter
public class Orders implements Serializable {

    private static final long serialVersionUID = -6117320102043250239L;

    @Id
    @Column(name = "ORDERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;
    @Column(name = "OPERATIONID")
    private String operationId;
    @Column(name = "CONTRACTCREDITID")
    private Long contractCreditId;
    @Column(name = "CONTRACTCREDITNUMBER")
    private String contractCreditNumber;
    @Column(name = "OWNERID")
    private Long ownerId;
    @Column(name = "CHANNELSYSNAME")
    private String channelSysName;
    @Column(name = "PREPAYMENTKIND")
    private Integer prepaymentKind;
    @Column(name = "RECALCMODE")
    private Integer recalcMode;
    @Column(name = "CREATIONDATE")
    private Date creationDate;
    @Column(name = "ORDERDATE")
    private Date orderDate;
    @Column(name = "AMOUNT")
    private BigDecimal amount;
    @Column(name = "ORDERSTATE")
    private String orderState;
    @Column(name = "NEWMONTHLYAMOUNT")
    private BigDecimal newMontlyAmount;
    @Column(name = "NEWEXPDATE")
    private Date newExpDate;
    @Column(name = "NEWTERM")
    private Long newTerm;

}
