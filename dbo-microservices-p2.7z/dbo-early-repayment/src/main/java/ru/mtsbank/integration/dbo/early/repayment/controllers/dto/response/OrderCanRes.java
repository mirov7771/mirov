package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class OrderCanRes extends BaseResponse {

    @JsonProperty("operationDescription")
    private String operationDescription;

}
