package ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.PmtOrdersRes;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support.Order;
import ru.mtsbank.integration.dbo.early.repayment.dao.model.Orders;
import ru.mtsbank.integration.dbo.early.repayment.dao.OrdersRepository;

import java.util.ArrayList;
import java.util.List;

@Component("pmtorders")
@Slf4j
public class PmtOrdersMethod {

    @Autowired
    private OrdersRepository ordersRepository;

    public PmtOrdersRes call(PmtOrdersReq req){
        log.info("Start pmtorders service");
        PmtOrdersRes res = new PmtOrdersRes();
        Long reqLoanId = req.getContractCreditID();
        if (req.getRboID() != null) {
            List<Orders> ordersList;
            if (req.getState() != null && !req.getState().equals("")) {
                if (reqLoanId != null && !reqLoanId.equals(0L)) {
                    ordersList = ordersRepository.findByOwnerIdAndOrderStateAndContractCreditId(req.getRboID(), req.getState(), reqLoanId);
                } else {
                    ordersList = ordersRepository.findByOwnerIdAndOrderState(req.getRboID(), req.getState());
                }
            } else {
                if (reqLoanId != null && !reqLoanId.equals(0L)) {
                    ordersList = ordersRepository.findByOwnerIdAndContractCreditId(req.getRboID(), reqLoanId);
                } else {
                    ordersList = ordersRepository.findByOwnerId(req.getRboID());
                }
            }
            List<Order> resOrdersList = new ArrayList<>();
            if (ordersList != null && ordersList.size() > 0) {
                for (Orders order : ordersList) {
                    Long loanId = order.getContractCreditId();
                    Order item = new Order();
                    item.setOrderID(order.getOrderId());
                    item.setOperationID(order.getOperationId());
                    item.setContractCreditID(loanId);
                    item.setContractCreditNumber(order.getContractCreditNumber());
                    item.setOwnerID(order.getOwnerId());
                    item.setChannelSysName(order.getChannelSysName());
                    item.setPrepaymentKind(order.getPrepaymentKind());
                    item.setRecalcMode(order.getRecalcMode());
                    item.setCreationDate(order.getCreationDate());
                    item.setOrderDate(order.getOrderDate());
                    item.setAmount(order.getAmount());
                    item.setOrderState(order.getOrderState());
                    item.setNewMontlyAmount(order.getNewMontlyAmount());
                    item.setNewExpDate(order.getNewExpDate());
                    item.setNewTerm(order.getNewTerm());
                    resOrdersList.add(item);
                }
            }
            res.setOrderList(resOrdersList);
        } else {
            res.createError(501, "Сервис временно недоступен", 400, null, "Не передан идентификатор клиента", "pmtorders", null);
        }
        log.info("End pmtorders service");
        return res;
    }

}
