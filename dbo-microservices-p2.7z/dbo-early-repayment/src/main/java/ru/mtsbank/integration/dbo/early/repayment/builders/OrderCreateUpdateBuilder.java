package ru.mtsbank.integration.dbo.early.repayment.builders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.NewOrdersReq;
import ru.mtsbank.integration.dbo.early.repayment.dao.model.Orders;
import ru.mtsbank.integration.dbo.early.repayment.dao.OrdersRepository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
public class OrderCreateUpdateBuilder {

    @Autowired
    private OrdersRepository ordersRepository;

    public Long saveOrder(NewOrdersReq req){
        Long orderId = null;
        Orders order = new Orders();
        order.setContractCreditId(req.getContractCreditID());
        order.setContractCreditNumber(req.getContractCreditNumber());
        order.setOwnerId(req.getRboID());
        order.setChannelSysName(req.getChannelSysName());
        order.setPrepaymentKind(req.getPrepaymentKind());
        order.setRecalcMode(req.getRecalcMode());
        order.setCreationDate(new Date());
        order.setOrderState(OrderStates.draft.toString());
        order.setAmount(req.getAmount());
        order.setOrderDate(req.getDate());
        Orders newOrder = ordersRepository.save(order);
        if (newOrder != null)
            orderId = newOrder.getOrderId();
        return orderId;
    }

    public void updateOrder(Long orderId, Integer state, BigDecimal newMontlyAmount, Date newExpDate, Long newTerm, String operationId){
        Orders order = ordersRepository.findByOrderId(orderId);
        if (order != null) {
            if (state.equals(0)) {
                order.setOrderState(OrderStates.processing.toString());
                order.setNewMontlyAmount(newMontlyAmount);
                order.setNewExpDate(newExpDate);
                order.setOperationId(operationId);
                order.setNewTerm(newTerm);
            } else if (state.equals(1)) {
                order.setOrderState(OrderStates.done.toString());
            } else if (state.equals(2)) {
                order.setOrderState(OrderStates.cancel.toString());
                if (operationId != null)
                    order.setOperationId(operationId);
            }
            ordersRepository.save(order);
        }
    }

    public Long getOrderByOperId(String operId){
        Long orderId = null;
        Orders order = ordersRepository.findByOperationId(operId);
        if (order != null)
            orderId = order.getOrderId();
        return orderId;
    }

    public Map<String, Object> getOrderInfoByOperId(String operId){
        Map<String, Object> out = new HashMap<>();
        Orders order = ordersRepository.findByOperationId(operId);
        if (order != null) {
            out.put("OrderId",order.getOrderId());
            out.put("State",order.getOrderState());
        }
        return out;
    }

    enum OrderStates{
        draft,
        processing,
        done,
        cancel;
    }

}
