package ru.mtsbank.integration.dbo.early.repayment.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.request.PmtScheduleReq;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.response.PmtScheduleRes;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support.Operation;
import ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support.PrepaymentSchedule;
import ru.mtsbank.integration.dbo.early.repayment.dao.model.Orders;
import ru.mtsbank.integration.dbo.early.repayment.dao.OrdersRepository;
import ru.mtsbank.integration.mts.xsd.PmtSchedInq.*;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component("pmtschedule")
@Slf4j
public class PmtScheduleMethod {

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private OrdersRepository ordersRepository;

    public PmtScheduleRes call(PmtScheduleReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start pmtschedule service", uid);
        PmtScheduleRes res = new PmtScheduleRes();
        try {
            if (req.getStartDate().after(req.getEndDate())) {
                res.createError(1084, "Неверный интервал дат для заявления", 400, null, null, "PmtSchedule", uid);
            } else {
                Long contractCreditId = req.getContractCreditID();
                List<Orders> ordersList = ordersRepository.getOrders(contractCreditId, new Date());
                List<Operation> operationList = new ArrayList<>();
                if (!CollectionUtils.isEmpty(ordersList)) {
                    for (Orders item : ordersList) {
                        Operation oper = new Operation();
                        oper.setCreationDate(Utils.createJavaDate(item.getCreationDate()));
                        oper.setOperationID(item.getOperationId());
                        oper.setPlanDate(Utils.createJavaDate(item.getOrderDate()));
                        switch (item.getPrepaymentKind()) {
                            case 0:
                                oper.setOperationKind("ПОЛН_ДОС_ГАШ");
                                break;
                            case 1:
                                oper.setOperationKind("ЧАСТ_ДОС_ГАШ");
                                break;
                        }
                        oper.setOperationAmount(item.getAmount());
                        oper.setOrderId(item.getOrderId());
                        operationList.add(oper);
                    }
                    res.setOperationList(operationList);
                    res.setContractCreditID(contractCreditId);
                } else {
                    //Prepare PmtSchedInqRq
                    PmtSchedInqRq rq = new PmtSchedInqRq();
                    //filling BankSvcRq
                    BankSvcRq bankSvcRq = new BankSvcRq();
                    LoanInfo loanInfo = new LoanInfo();
                    loanInfo.setLoanId(contractCreditId.toString());
                    bankSvcRq.setLoanInfo(loanInfo);
                    bankSvcRq.setSchedType("PMT");
                    SelRangeDt selRangeDt = new SelRangeDt();
                    selRangeDt.setStartDt(getFdxDate(req.getStartDate()));
                    selRangeDt.setEndDt(getFdxDate(req.getEndDate()));
                    bankSvcRq.setSelRangeDt(selRangeDt);
                    rq.setBankSvcRq(bankSvcRq);
                    //filling ServerInfo
                    ServerInfoType serverInfoType = new ServerInfoType();
                    serverInfoType.setSPName("MTS_EIP_UMP");
                    serverInfoType.setMsgReceiver("RBO");
                    serverInfoType.setMsgUID(uid);
                    serverInfoType.setRqUID(uid);
                    serverInfoType.setBpId("MTS_DBO_LOANPMT");
                    serverInfoType.setMsgType("PmtSchedInqRq");
                    serverInfoType.setServerDt(Utils.getXmlGregorianCalendar(new Date()));
                    rq.setServerInfo(serverInfoType);

                    //create xml for mq
                    String messageXml = xmlUnmarshaler.createXml(rq);

                    //send xml to mq
                    log.info("Send message to mq: " + messageXml);
                    String answerXml = esbGate.sendInfoMessageWithAnswer(messageXml);

                    //get response
                    PmtSchedInqRs rs = xmlUnmarshaler.parse(PmtSchedInqRs.class, answerXml);
                    if (rs == null || rs.getBankSvcRs() == null || rs.getBankSvcRs().getStatus() == null) {
                        res.createError(501, "Сервис временно недоступен", 400, null, "PmtSchedule РБО недоступен", "PmtSchedule", uid);
                    } else {
                        BankSvcRs bankSvcRs = rs.getBankSvcRs();
                        String statusCode = bankSvcRs.getStatus().getStatusCode();
                        String statusDesc = bankSvcRs.getStatus().getStatusDesc();
                        if (statusCode.equals("0")) {
                            res.setRequestId(uid);
                            if (bankSvcRs.getLoanInfo() != null) {
                                String loandId = bankSvcRs.getLoanInfo().getLoanId();
                                res.setContractCreditID(Long.valueOf(loandId));
                            }

                            if (bankSvcRs.getOrderList() != null && Utils.isNotEmpty(bankSvcRs.getOrderList().getOrderRec())) {
                                for (OrderRec rec : bankSvcRs.getOrderList().getOrderRec()) {
                                    Operation oper = new Operation();
                                    oper.setCreationDate(createJavaDate(rec.getRegDt()));
                                    CurrencyAmount currencyAmount = rec.getCurAmt();
                                    if (currencyAmount != null)
                                        oper.setOperationAmount(currencyAmount.getAmt());
                                    oper.setOperationID(rec.getOrderId());
                                    oper.setOperationKind(rec.getOrderType());
                                    oper.setPlanDate(createJavaDate(rec.getPlanDt()));
                                    operationList.add(oper);
                                }
                                res.setOperationList(operationList);
                            }
                            if (bankSvcRs.getPmtSchedList() != null && Utils.isNotEmpty(bankSvcRs.getPmtSchedList().getPmtSchedRec())) {
                                List<PrepaymentSchedule> prepaymentScheduleList = new ArrayList<>();
                                for (PmtSchedRec rec : bankSvcRs.getPmtSchedList().getPmtSchedRec()) {
                                    PrepaymentSchedule sched = new PrepaymentSchedule();
                                    sched.setDate(createJavaDate(rec.getDueDt()));
                                    CurrencyAmount currencyAmount = rec.getCurAmt();
                                    if (currencyAmount != null) {
                                        sched.setAmount(currencyAmount.getAmt());
                                        sched.setCurrencyCode(currencyAmount.getCurCode());
                                    }
                                    prepaymentScheduleList.add(sched);
                                }
                                res.setPrepaymentScheduleList(prepaymentScheduleList);
                            }
                        } else {
                            boolean noCred = statusDesc.contains("не найден, тип [PR_CRED]");
                            res.createError(Boolean.TRUE.equals(noCred) ? 1002 : 501
                                    , Boolean.TRUE.equals(noCred) ? String.format("Не найден кредит с ID %s", req.getContractCreditID()) : "Сервис временно недоступен"
                                    , Boolean.TRUE.equals(noCred) ? 406 : 400
                                    , null
                                    , statusDesc
                                    , "PmtSchedule", uid);
                        }
                    }
                }
            }
        } catch (IOException e){
            log.error("{} Error in pmtschedule service {}", uid, Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен", 400, null, null, "pmtschedule", null);
        }
        log.info("{} End pmtschedule service", uid);
        return res;
    }

    private FdxDate getFdxDate(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        FdxDate fdxDate = new FdxDate();
        fdxDate.setYear(year);
        fdxDate.setMonth(month+1);
        fdxDate.setDay(day);
        return fdxDate;
    }

    private String createJavaDate(FdxDate fdxDate) {
        Date date;
        String retDate = null;
        if(fdxDate != null) {
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            calendar.set(fdxDate.getYear(), fdxDate.getMonth()-1, fdxDate.getDay());
            date = calendar.getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            retDate = sdf.format(date);
            retDate += "T00:00:00.000+0000";
        }
        return retDate;
    }

}
