package ru.mtsbank.integration.dbo.early.repayment.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
public class PrepaymentSchedule {

    @JsonProperty("date")
    private String date;
    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("currencyCode")
    private String currencyCode;

}
