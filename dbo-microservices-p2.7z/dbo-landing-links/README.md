# DBO-LANDING-LINKS

### Требования к реализации: 

- Реализовать сервис получения запросов [OfferDataJson](src/main/java/ru/mtsbank/integration/dbo/landing/links/controllers/dto/response/OfferDataRs.java)
 от канала "Лэндинг" (JSON формат обмена данными, по средствам REST) 
- Реализовать сервис отправки и получения [OfferDataXml](src/main/resources/xsd/OfferData.xsd) по протоколу SOAP от Siebel CRM 
- Обеспечить конвертацию XML-JSON ([OfferDataXml](src/main/resources/xsd/OfferData.xsd) => 
[OfferDataJson](src/main/java/ru/mtsbank/integration/dbo/landing/links/controllers/dto/response/OfferDataRs.java))  
- Обеспечить мапинг полей
[OfferDataJson](src/main/java/ru/mtsbank/integration/dbo/landing/links/controllers/dto/response/OfferDataRs.java)- 
[OfferDataXml](src/main/resources/xsd/OfferData.xsd) 

### Основной успешный сценарий:  

- Канал "Лэндинг" вызывает сервис с параметром ID 
- UMP сервис вызывает сервис [OfferDataXml](src/main/resources/xsd/OfferData.xsd) Siebel CRM   
- Siebel CRM обрабатывает сообщение 
- Siebel CRM возвращает в ответе данные по предложению   
- UMP сервис производит мапинг полей мапинг полей [OfferDataXml](src/main/resources/xsd/OfferData.xsd) => 
[OfferDataJson](src/main/java/ru/mtsbank/integration/dbo/landing/links/controllers/dto/response/OfferDataRs.java)
- UMP-сервис  возвращает ответ в Канал "Лэндинг"
 
### Альтернативный сценарий: 

- В случая таймаута от Siebel CRM (ожидание ответа более 3 секунд), возвращать на front HTTP 500. 
- В случае не корректного ответа от Siebel CRM возвращать на front HTTP 404 - сущность не найдена.   
- В случае неправильного запроса от front возвращать HTTP 400 - неправильный запрос.
 
### Дополнительные требования: 

- Необходимо разработать кэш формируемых ответов для фронт. Кэш должен:
- При получении ответа [OfferDataXml](src/main/resources/xsd/OfferData.xsd) от Siebel CRM данные конвертируются в OfferData,тело запроса добавляется в кэш. 
- При получении 
[OfferDataJson](src/main/java/ru/mtsbank/integration/dbo/landing/links/controllers/dto/response/OfferDataRs.java)
с таким же ID не отправлять запрос в Siebel CRM, а возвращать из кэша. 
- Через тело JSON ответа хранится в кэше 45 секунд, далее удаляется. 
- При заполнении кэша, данные в кэше очищаются (отдельной командой). 
