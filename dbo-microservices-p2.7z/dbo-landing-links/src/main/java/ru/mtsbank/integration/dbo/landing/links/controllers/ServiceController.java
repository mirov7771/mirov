package ru.mtsbank.integration.dbo.landing.links.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mtsbank.integration.dbo.landing.links.controllers.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.landing.links.controllers.dto.response.OfferDataRs;
import ru.mtsbank.integration.dbo.landing.links.service.Service;

import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Tag(name = "LandingLinks")
@RestController
@RequestMapping("dbo-landing-links")
@Slf4j
public class ServiceController {

    private final Map<String, Service> services;

    public ServiceController(Map<String, Service> services) {
        this.services = services;
    }

    @Cacheable(value = "offerData", sync = true)
    @GetMapping(value = "{version}/getOfferData", produces = APPLICATION_JSON_VALUE)
    @ResponseBody
    @Operation(summary = "Сервис возвращает ответ на запрос от канала \"Лендинг\" в UMP для получения данных по предложению."
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = OfferDataRs.class))
            })
    })
    public ResponseEntity<OfferDataRs> getOfferData(@PathVariable final String version, @RequestParam String id) {
        return ResponseBuilder.build(services.get(version).getOfferData(id));
    }


}
