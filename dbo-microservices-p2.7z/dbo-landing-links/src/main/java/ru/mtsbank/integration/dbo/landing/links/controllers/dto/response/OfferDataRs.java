package ru.mtsbank.integration.dbo.landing.links.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.mtsbank.integration.dbo.landing.links.controllers.dto.base.BaseResponse;

@EqualsAndHashCode(callSuper = true)
@Data
public class OfferDataRs extends BaseResponse {
    @JsonProperty("OfferData")
    private OfferData offerData;

    @Data
    public static class OfferData {
        @JsonProperty("PersonName")
        private PersonName personName;
        @JsonProperty("OfferDate")
        private OfferDate offerDate;
        @JsonProperty("OfferDet")
        private OfferDet offerDet;

        @Data
        public static class PersonName {
            @JsonProperty("LastName")
            private String lastName;
            @JsonProperty("FirstName")
            private String firstName;
            @JsonProperty("MiddleName")
            private String middleName;

        }

        @Data
        public static class OfferDate {
            @JsonProperty("StartDt")
            private Date startDt;
            @JsonProperty("EndDt")
            private Date endDt;

            @Data
            public static class Date {
                @JsonProperty("Year")
                private String year;
                @JsonProperty("Month")
                private String month;
                @JsonProperty("Day")
                private String day;
            }
        }

        @Data
        public static class OfferDet {
            @JsonProperty("OfferId")
            private String offerId;
            @JsonProperty("CampType")
            private String campType;
            @JsonProperty("ProdNum")
            private String prodNum;
            @JsonProperty("MonPay")
            private String monPay;
            @JsonProperty("MaxMonPay")
            private String maxMonPay;
            @JsonProperty("MaxRate")
            private String maxRate;
            @JsonProperty("MaxTerm")
            private String maxTerm;
            @JsonProperty("Sum")
            private String sum;
            @JsonProperty("Rate")
            private String rate;
            @JsonProperty("Term")
            private String term;
            @JsonProperty("FIELD1")
            private String field1;
            @JsonProperty("FIELD2")
            private String field2;
            @JsonProperty("FIELD3")
            private String field3;
            @JsonProperty("FIELD4")
            private String field4;
            @JsonProperty("FIELD5")
            private String field5;
        }
    }

}
