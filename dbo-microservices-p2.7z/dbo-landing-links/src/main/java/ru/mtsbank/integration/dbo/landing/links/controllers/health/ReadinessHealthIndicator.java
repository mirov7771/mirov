package ru.mtsbank.integration.dbo.landing.links.controllers.health;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ReadinessHealthIndicator implements HealthIndicator {

    public ReadinessHealthIndicator() {
    }

    @Override
    public Health health() {
        return Health.up().build();
    }
}
