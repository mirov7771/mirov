package ru.mtsbank.integration.dbo.landing.links.converters;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import ru.mtsbank.integration.dbo.landing.links.controllers.dto.response.OfferDataRs;
import ru.mtsbank.integration.mts.xsd.offer.data.*;

@Slf4j
public class OfferDataConverters {

    public static OfferDataRs convertXmlToJSON(GetOfferDataLendWSOutput output) {
        log.trace("Converter input: {}", output);
        if (output == null || output.getListOfGetOfferDataLendReceive() == null || output.getListOfGetOfferDataLendReceive().getOfferData() == null) {
            OfferDataRs emptyOfferDataRs = new OfferDataRs();
            emptyOfferDataRs.setError(null, "Empty answer from Siebel", HttpStatus.NO_CONTENT.value(), null, null, "dbo-landing-links");
            return emptyOfferDataRs;
        }
        OfferDataRs offerDataRs = new OfferDataRs();
        OfferDataRs.OfferData offerData = new OfferDataRs.OfferData();
        OfferData data = output.getListOfGetOfferDataLendReceive().getOfferData();
        offerData.setPersonName(createPersonName(data.getPersonName()));
        offerData.setOfferDate(createOfferDate(data.getOfferDate()));
        offerDataRs.setOfferData(offerData);
        offerData.setOfferDet(createOfferDet(data.getOfferDet()));
        log.debug("Created OfferDataRs: {}", offerDataRs);
        return offerDataRs;
    }

    private static OfferDataRs.OfferData.PersonName createPersonName(PersonName pn) {
        OfferDataRs.OfferData.PersonName personName = new OfferDataRs.OfferData.PersonName();
        personName.setFirstName(pn.getFirstName());
        personName.setLastName(pn.getLastName());
        personName.setMiddleName(pn.getMiddleName());
        log.debug("Created PersonName: {}", personName);
        return personName;
    }

    private static OfferDataRs.OfferData.OfferDate createOfferDate(OfferDate od) {
        OfferDataRs.OfferData.OfferDate.Date startDt = new OfferDataRs.OfferData.OfferDate.Date();
        StartDt odStartDt = od.getStartDt();
        startDt.setYear(String.valueOf(odStartDt.getYear()));
        startDt.setMonth(String.valueOf(odStartDt.getMonth()));
        startDt.setDay(String.valueOf(odStartDt.getDay()));
        OfferDataRs.OfferData.OfferDate.Date endDt = new OfferDataRs.OfferData.OfferDate.Date();
        EndDt odEndDt = od.getEndDt();
        endDt.setYear(String.valueOf(odEndDt.getYear()));
        endDt.setMonth(String.valueOf(odEndDt.getMonth()));
        endDt.setDay(String.valueOf(odEndDt.getDay()));
        OfferDataRs.OfferData.OfferDate offerDate = new OfferDataRs.OfferData.OfferDate();
        offerDate.setEndDt(endDt);
        offerDate.setStartDt(startDt);
        log.debug("Created OfferDate: {}", offerDate);
        return offerDate;
    }

    private static OfferDataRs.OfferData.OfferDet createOfferDet(OfferDet od) {
        OfferDataRs.OfferData.OfferDet offerDet = new OfferDataRs.OfferData.OfferDet();
        offerDet.setOfferId(od.getOfferId());
        offerDet.setCampType(od.getCampType());
        offerDet.setProdNum(notEmptyString(od.getProdNum()));
        offerDet.setMonPay(notEmptyString(od.getMonPay()));
        offerDet.setMaxMonPay(notEmptyString(od.getMaxMonPay()));
        offerDet.setMaxRate(notEmptyString(od.getMaxRate()));
        offerDet.setMaxTerm(notEmptyString(od.getMaxTerm()));
        offerDet.setSum(notEmptyString(od.getSum()));
        offerDet.setRate(notEmptyString(od.getRate()));
        offerDet.setTerm(notEmptyString(od.getTerm()));
        offerDet.setField1(notEmptyString(od.getFIELD1()));
        offerDet.setField2(notEmptyString(od.getFIELD2()));
        offerDet.setField3(notEmptyString(od.getFIELD3()));
        offerDet.setField4(notEmptyString(od.getFIELD4()));
        offerDet.setField5(notEmptyString(od.getFIELD5()));
        log.debug("Created OfferDet: {}", offerDet);
        return offerDet;
    }

    private static String notEmptyString(String s) {
        if (s == null || s.equals("")) {
            return null;
        }
        return s;
    }
}
