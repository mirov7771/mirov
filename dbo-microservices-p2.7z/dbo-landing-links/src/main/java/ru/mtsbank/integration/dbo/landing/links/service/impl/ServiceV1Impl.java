package ru.mtsbank.integration.dbo.landing.links.service.impl;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapHeaderElement;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import ru.mtsbank.integration.dbo.landing.links.controllers.dto.response.OfferDataRs;
import ru.mtsbank.integration.dbo.landing.links.converters.OfferDataConverters;
import ru.mtsbank.integration.dbo.landing.links.jaxb.XmlUnmarshaller;
import ru.mtsbank.integration.dbo.landing.links.service.Service;
import ru.mtsbank.integration.mts.xsd.offer.data.GetOfferDataLendWSInput;
import ru.mtsbank.integration.mts.xsd.offer.data.GetOfferDataLendWSOutput;

import javax.xml.namespace.QName;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component("v1")
public class ServiceV1Impl implements Service {

    private final WebServiceTemplate webServiceTemplate;
    private final WebServiceMessageCallback webServiceMessageCallback;
    private final String siebelUrl;
    private final XmlUnmarshaller xmlUnmarshaller;

    public ServiceV1Impl(WebServiceTemplate webServiceTemplate,
                         @Value("${siebel.url}") String siebelUrl,
                         @Value("${siebel.action}") String action,
                         @Value("${siebel.username}") String username,
                         @Value("${siebel.password}") String password, XmlUnmarshaller xmlUnmarshaller) {
        this.webServiceTemplate = webServiceTemplate;
        this.siebelUrl = siebelUrl;
        this.xmlUnmarshaller = xmlUnmarshaller;

        List<ClientInterceptor> intercepters = new ArrayList<>(List.of(webServiceTemplate.getInterceptors()));
        this.webServiceTemplate.setInterceptors(intercepters.toArray(new ClientInterceptor[]{}));
        this.webServiceMessageCallback = new SoapActionCallback(action) {
            @SneakyThrows
            @Override
            public void doWithMessage(WebServiceMessage message) throws IOException {
                super.doWithMessage(message);
                SoapMessage soapMessage = (SoapMessage) message;
                SoapHeader header = soapMessage.getSoapHeader();
                QName qNameUsernameToken = new QName("http://siebel.com/webservices", "UsernameToken");
                SoapHeaderElement usernameToken = header.addHeaderElement(qNameUsernameToken);
                usernameToken.setText(username);
                QName qNamePasswordText = new QName("http://siebel.com/webservices", "PasswordText");
                SoapHeaderElement passwordText = header.addHeaderElement(qNamePasswordText);
                passwordText.setText(password);
            }
        };
    }

    @Override
    public OfferDataRs getOfferData(String offerId) {
        GetOfferDataLendWSInput req = new GetOfferDataLendWSInput();
        req.setOfferId(offerId);
        GetOfferDataLendWSOutput res;
        try {
            res = (GetOfferDataLendWSOutput) webServiceTemplate.marshalSendAndReceive(siebelUrl, req, webServiceMessageCallback);
        } catch (Exception e) {
            log.error("Exception while getting response from Siebel", e);
            OfferDataRs errorResponse = new OfferDataRs();
            errorResponse.setError(null, "Bad answer from Siebel", HttpStatus.NOT_ACCEPTABLE.value(), null, e.getMessage(), "dbo-landing-links");
            return errorResponse;
        }
        return OfferDataConverters.convertXmlToJSON(res);
    }
}
