package ru.mtsbank.integration.dbo.landing.links.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.webservices.client.WebServiceTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.transport.http.HttpsUrlConnectionMessageSender;
import ru.mtsbank.integration.dbo.landing.links.config.interceptors.LogSoapInterceptor;
import ru.mtsbank.integration.mts.xsd.offer.data.GetOfferDataLendWSInput;
import ru.mtsbank.integration.mts.xsd.offer.data.GetOfferDataLendWSOutput;

import javax.net.ssl.TrustManager;

@Configuration
public class SoapConfiguration {

    @Value("${siebel.username}")
    private String username;
    @Value("${siebel.password}")
    private String password;


    @Bean
    @Scope("prototype")
    public Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setClassesToBeBound(GetOfferDataLendWSInput.class, GetOfferDataLendWSOutput.class);
        return marshaller;
    }

    @Bean
    @Scope("prototype")
    public Unmarshaller unmarshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setClassesToBeBound(GetOfferDataLendWSInput.class, GetOfferDataLendWSOutput.class);
        return marshaller;
    }

    @Bean
    public MarshallingHttpMessageConverter marshallingHttpMessageConverter(Marshaller marshaller) {
        return new MarshallingHttpMessageConverter(marshaller);
    }



    @Bean
    @Scope("prototype")
    public WebServiceTemplate webServiceTemplate(Marshaller marshaller,
                                                 Unmarshaller unmarshaller,
                                                 LogSoapInterceptor logSoapInterceptor,
                                                 WebServiceTemplateBuilder webServiceTemplateBuilder) {
        WebServiceTemplate template = webServiceTemplateBuilder
                .setMarshaller(marshaller)
                .setUnmarshaller(unmarshaller)
                .interceptors(logSoapInterceptor)
                .build();
        HttpsUrlConnectionMessageSender sender = new HttpsUrlConnectionMessageSender();
        sender.setTrustManagers(new TrustManager[] {
                new UnTrustworthyTrustManager()
        });
        template.setMessageSender(sender);
        return template;
    }
}
