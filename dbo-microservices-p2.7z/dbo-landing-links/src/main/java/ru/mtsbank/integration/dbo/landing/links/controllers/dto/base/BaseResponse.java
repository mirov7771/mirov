package ru.mtsbank.integration.dbo.landing.links.controllers.dto.base;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Slf4j
public class BaseResponse {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Error error;

    public void setError(Integer code, String message, int httpCode, String externalCode, String details, String service) {
        String uid = UUID.randomUUID().toString();
        this.error = new Error(code, message, uid, externalCode, details, httpCode);
        log.error("Error in service {}: {}", service, this.error);
    }

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Error {
        @JsonProperty("code")
        private final Integer code;
        @JsonProperty("message")
        private final String message;
        @JsonProperty("uuid")
        private final String uuid;
        @JsonProperty("externalCode")
        private final String externalCode;
        @JsonProperty("details")
        private final String details;
        @JsonIgnore
        private final int httpCode;
    }

}
