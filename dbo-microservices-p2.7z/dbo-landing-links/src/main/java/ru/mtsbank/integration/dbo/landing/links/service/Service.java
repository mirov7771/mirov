package ru.mtsbank.integration.dbo.landing.links.service;

import ru.mtsbank.integration.dbo.landing.links.controllers.dto.response.OfferDataRs;

public interface Service {
    OfferDataRs getOfferData(String offerId);
}
