package ru.mtsbank.integration.dbo.landing.links.controllers;

import org.springframework.boot.actuate.health.Health;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import ru.mtsbank.integration.dbo.landing.links.controllers.health.LivenessHealthIndicator;
import ru.mtsbank.integration.dbo.landing.links.controllers.health.ReadinessHealthIndicator;


@RestController
@RequestMapping("dbo-landing-links")
public class HealthController {

    private final ReadinessHealthIndicator readinessHealthIndicator;
    private final LivenessHealthIndicator livenessHealthIndicator;

    public HealthController(ReadinessHealthIndicator readinessHealthIndicator, LivenessHealthIndicator livenessHealthIndicator) {
        this.readinessHealthIndicator = readinessHealthIndicator;
        this.livenessHealthIndicator = livenessHealthIndicator;
    }

    @RequestMapping(method = RequestMethod.GET)
    public String check() {
        return "Application dbo-landing-links is running";
    }

    @GetMapping(value = "/read")
    public Health readness() {
        return readinessHealthIndicator.health();
    }

    @GetMapping(value = "/live")
    public Health liveness() {
        return livenessHealthIndicator.health();
    }

}
