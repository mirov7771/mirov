package ru.mtsbank.integration.dbo.landing.links.config.interceptors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptorAdapter;
import org.springframework.ws.context.MessageContext;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Slf4j
@Component
public class LogSoapInterceptor extends ClientInterceptorAdapter {
    @Override
    public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
        try (ByteArrayOutputStream requestStream = new ByteArrayOutputStream()) {
            messageContext.getRequest().writeTo(requestStream);
            String request = requestStream.toString(StandardCharsets.UTF_8.name());
            log.debug("Sending SOAP request: {}", request);
        } catch (IOException e) {
            log.warn("Could not log SOAP request", e);
        }
        return super.handleRequest(messageContext);
    }

    @Override
    public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
        if (messageContext.hasResponse()) {
            try (ByteArrayOutputStream responseStream = new ByteArrayOutputStream()) {
                messageContext.getResponse().writeTo(responseStream);
                String response = responseStream.toString(StandardCharsets.UTF_8.name());
                log.debug("Recieving SOAP response: {}", response);
            } catch (IOException e) {
                log.warn("Could not log SOAP response", e);
            }
        }
        return super.handleResponse(messageContext);
    }
}
