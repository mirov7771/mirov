package ru.mtsbank.integration.dbo.landing.links.jaxb;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.xml.transform.StringSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

@Component
@Slf4j
public class XmlUnmarshaller {

    private final JaxbContextCache jaxbContextCache;

    public XmlUnmarshaller(JaxbContextCache jaxbContextCache) {
        this.jaxbContextCache = jaxbContextCache;
    }

    @SuppressWarnings("unchecked")
    public <T> T parse(Class<T> clazz, String xml) {

        if (StringUtils.isEmpty(xml)) {
            return null;
        }
        try {
            JAXBContext jaxbContext = jaxbContextCache.get(clazz);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            return (T) unmarshaller
                    .unmarshal(new StringSource(xml));
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    public <T> String createXml(T input) {

        try {
            Class<?> clazz = input.getClass();
            JAXBContext jaxbContext = jaxbContextCache.get(clazz);
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, StandardCharsets.UTF_8.displayName());
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            StringWriter sw = new StringWriter();
            marshaller.marshal(input, sw);
            return sw.toString();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }
}