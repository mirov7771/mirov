package ru.mtsbank.integration.dbo.landing.links.controllers.builder;

import org.springframework.http.ResponseEntity;
import ru.mtsbank.integration.dbo.landing.links.controllers.dto.base.BaseResponse;

public class ResponseBuilder {

    public static <T extends BaseResponse> ResponseEntity<T> build(T data) {
        if (data.getError() == null) {
            return ResponseEntity.ok(data);
        } else {
            return ResponseEntity.status(data.getError().getHttpCode()).body(data);
        }
    }

}
