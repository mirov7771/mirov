package ru.mtsbank.integration.dbo.landing.links.jaxb;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

@Component
public class JaxbContextCache {

    @Cacheable(cacheNames = "jaxbCache", sync = true)
    public JAXBContext get(Class<?> clazz) throws JAXBException {
        return JAXBContext.newInstance(clazz);
    }
}
