package ru.mtsbank.integration.dbo.landing.links;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import ru.mtsbank.integration.dbo.landing.links.controllers.dto.response.OfferDataRs;
import ru.mtsbank.integration.dbo.landing.links.converters.OfferDataConverters;
import ru.mtsbank.integration.mts.xsd.offer.data.GetOfferDataLendWSOutput;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

@SpringBootTest
@Slf4j
class ApplicationTests {


	@Test
	void contextLoads() {
	}

	@Test
	void offerDataConverterTest() throws JAXBException, FileNotFoundException, XMLStreamException, JsonProcessingException {
		XMLInputFactory xif = XMLInputFactory.newDefaultFactory();
		XMLStreamReader xsr = xif.createXMLStreamReader(new FileReader("src/test/resources/OfferDataRs.xml"));
		xsr.nextTag();
		xsr.nextTag();
		xsr.nextTag();
		JAXBContext jaxbContext = JAXBContext.newInstance(GetOfferDataLendWSOutput.class);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		GetOfferDataLendWSOutput xml = (GetOfferDataLendWSOutput) unmarshaller.unmarshal(xsr);
		OfferDataRs json = OfferDataConverters.convertXmlToJSON(xml);
		OfferDataRs correct = new OfferDataRs();
		OfferDataRs.OfferData offerData = new OfferDataRs.OfferData();
		OfferDataRs.OfferData.PersonName personName = new OfferDataRs.OfferData.PersonName();
		personName.setFirstName("АНДРЕЙ");
		personName.setMiddleName("ОЛЕГОВИЧ");
		personName.setLastName("ЕРШОВ");
		offerData.setPersonName(personName);
		OfferDataRs.OfferData.OfferDate offerDate = new OfferDataRs.OfferData.OfferDate();
		OfferDataRs.OfferData.OfferDate.Date startDate = new OfferDataRs.OfferData.OfferDate.Date();
		startDate.setYear("2020");
		startDate.setMonth("11");
		startDate.setDay("18");
		offerDate.setStartDt(startDate);
		OfferDataRs.OfferData.OfferDate.Date endDate = new OfferDataRs.OfferData.OfferDate.Date();
		endDate.setYear("2021");
		endDate.setMonth("01");
		endDate.setDay("31");
		offerDate.setEndDt(endDate);
		offerData.setOfferDate(offerDate);
		OfferDataRs.OfferData.OfferDet offerDet = new OfferDataRs.OfferData.OfferDet();
		offerDet.setOfferId("1-d5451b1");
		offerDet.setCampType("TOP_UP");
		offerDet.setField1("12");
		offerDet.setField2("xxx");
		offerDet.setField3("ввв");
		offerDet.setField4("456");
		offerDet.setField5("35");
		offerData.setOfferDet(offerDet);
		correct.setOfferData(offerData);
		Assertions.assertEquals(correct, json);
	}
}

