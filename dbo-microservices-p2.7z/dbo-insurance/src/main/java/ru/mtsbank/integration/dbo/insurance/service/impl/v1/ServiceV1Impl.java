package ru.mtsbank.integration.dbo.insurance.service.impl.v1;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.insurance.service.Service;
import ru.mtsbank.integration.dbo.insurance.service.impl.v1.methods.PoliciesMethod;
import ru.mtsbank.integration.dbo.insurance.service.impl.v1.methods.SummaryMethod;

@Component("v1")
@RequiredArgsConstructor
public class ServiceV1Impl implements Service {

    private final SummaryMethod summaryMethod;
    private final PoliciesMethod policiesMethod;

    @Override
    public BaseResponse summary(Long rboId, String msisdn) {
        return summaryMethod.call(rboId, msisdn);
    }

    @Override
    public BaseResponse policies(Long rboId, String msisdn) {
        return policiesMethod.call(rboId, msisdn);
    }
}
