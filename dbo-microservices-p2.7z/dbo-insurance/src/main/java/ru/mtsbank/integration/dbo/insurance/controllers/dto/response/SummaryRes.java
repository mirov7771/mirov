package ru.mtsbank.integration.dbo.insurance.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.support.ImgLinks;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.support.Link;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@ToString
public class SummaryRes extends BaseResponse {

    @JsonProperty("protectionLevel")
    private Integer protectionLevel;
    @JsonProperty("title")
    private String title;
    @JsonProperty("description")
    private String description;
    @JsonProperty("policiesTitle")
    private String policiesTitle;
    @JsonProperty("imgLinks")
    private List<ImgLinks> imgLinks;
    @JsonProperty("link")
    private Link link;

}
