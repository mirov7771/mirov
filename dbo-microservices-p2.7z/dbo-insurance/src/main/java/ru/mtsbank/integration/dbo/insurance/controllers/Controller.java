package ru.mtsbank.integration.dbo.insurance.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.response.PoliciesRes;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.response.SummaryRes;
import ru.mtsbank.integration.dbo.insurance.service.Service;

import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;
import static ru.mts.dbo.utils.Utils.getRboIdFromToken;
import static ru.mts.dbo.utils.Utils.getSrcPhoneFromToken;

@Tag(name = "Insurance")
@RestController
@RequestMapping("dbo-insurance")
@Slf4j
public class Controller {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/summary",produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "Метод для получения статической информации"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = SummaryRes.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> summary(@PathVariable final String version
                                               ,@RequestHeader(value = "authorization", required = false) String authorization)
    {
        return ResponseBuilder.build(services.get(version).summary(getRboIdFromToken(authorization), getSrcPhoneFromToken(authorization)));
    }

    @GetMapping(value = "{version}/policies",produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "Метод для получения информации о купленных полисах"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = PoliciesRes.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> policies(@PathVariable final String version
                                                ,@RequestHeader(value = "authorization", required = false) String authorization)
    {
        return ResponseBuilder.build(services.get(version).policies(getRboIdFromToken(authorization), getSrcPhoneFromToken(authorization)));
    }

}
