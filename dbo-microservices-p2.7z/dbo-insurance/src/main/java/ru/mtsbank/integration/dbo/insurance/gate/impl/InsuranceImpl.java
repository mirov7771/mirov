package ru.mtsbank.integration.dbo.insurance.gate.impl;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.insurance.config.CustomConfig;
import ru.mtsbank.integration.dbo.insurance.gate.Insurance;

@Service
public class InsuranceImpl implements Insurance {

    private final RestTemplate restTemplate;
    private String baseUrl;
    private String baseHost;

    public InsuranceImpl(RestTemplate restTemplate, CustomConfig customConfig) {
        this.restTemplate = restTemplate;
        if (customConfig != null && customConfig.getApp() != null){
            baseUrl = customConfig.getApp().getUrl();
            baseHost = customConfig.getApp().getHost();
        }
    }

    @Override
    public <T> T call(Class<T> answerClass, String method, String request, String token, String action) {
        String url = baseUrl+method;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("X-Source", "mtsb");
        headers.add(HttpHeaders.HOST, baseHost);
        if (!Utils.isEmpty(token))
            headers.add(HttpHeaders.AUTHORIZATION, token);
        HttpEntity<String> rq = new HttpEntity<>(request, headers);
        ResponseEntity<T> exchange = restTemplate.exchange(url, HttpMethod.resolve(action), rq, answerClass);
        return exchange.getBody();
    }
}
