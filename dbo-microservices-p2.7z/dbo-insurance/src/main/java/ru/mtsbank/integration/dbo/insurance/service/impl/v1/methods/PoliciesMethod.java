package ru.mtsbank.integration.dbo.insurance.service.impl.v1.methods;

import com.google.gson.JsonObject;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.utils.DboException;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.response.PoliciesRes;
import ru.mtsbank.integration.dbo.insurance.gate.Insurance;

import java.util.Date;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static ru.mts.dbo.utils.Utils.preCheckToken;

@Component
@Slf4j
@RequiredArgsConstructor
public class PoliciesMethod {

    private final Insurance insurance;

    public PoliciesRes call(Long rboId, String msisdn){
        String uid = UUID.randomUUID().toString();
        log.info("{} start policies method for {}",uid,msisdn);
        PoliciesRes res = new PoliciesRes();
        try {
            preCheckToken(rboId, msisdn, "balance", uid);
            res = insurance.call(PoliciesRes.class
                    , "policies/jwt"
                    , new JsonObject().toString()
                    , generateToken(msisdn, "MTSD-06102020-!!", 1)
                    , "GET");
            log.info("{} end policies method with answer {}", uid, res.toString());
        } catch (DboException e){
            throw new DboException(e.getType(),e.getSystem(),e.getUuid());
        }
        return res;
    }

    public static String generateToken(String userId, String secret, int expirationHours) {
        Claims claims = Jwts.claims();
        claims.put("uid", userId);

        Date expDate = new Date(System.currentTimeMillis() + TimeUnit.HOURS.toMillis(expirationHours));

        return Jwts.builder()
                .setClaims(claims)
                .setExpiration(expDate)
                .signWith(SignatureAlgorithm.HS512, secret.getBytes())
                .compact();
    }

}
