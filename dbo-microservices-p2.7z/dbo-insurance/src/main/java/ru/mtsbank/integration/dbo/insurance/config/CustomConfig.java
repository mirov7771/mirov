package ru.mtsbank.integration.dbo.insurance.config;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class CustomConfig {

    @JsonProperty("app")
    private App app;

    @Data
    public static class App{
        @JsonProperty("url")
        private String url;
        @JsonProperty("host")
        private String host;
    }

}
