package ru.mtsbank.integration.dbo.insurance.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.support.Policies;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@ToString
public class PoliciesRes extends BaseResponse {

    @JsonProperty("policies")
    private List<Policies> policies;

}
