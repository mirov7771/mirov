package ru.mtsbank.integration.dbo.insurance.service;

import ru.mts.dbo.dto.BaseResponse;

public interface Service {

    BaseResponse summary(Long rboId, String msisdn);
    BaseResponse policies(Long rboId, String msisdn);

}
