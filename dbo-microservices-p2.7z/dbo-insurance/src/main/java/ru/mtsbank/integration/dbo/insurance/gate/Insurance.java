package ru.mtsbank.integration.dbo.insurance.gate;

public interface Insurance {

    <T> T call(Class<T> answerClass, String method, String request, String token, String action);

}
