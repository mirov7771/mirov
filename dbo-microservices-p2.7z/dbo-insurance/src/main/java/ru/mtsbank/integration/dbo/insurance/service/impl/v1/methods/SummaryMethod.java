package ru.mtsbank.integration.dbo.insurance.service.impl.v1.methods;

import com.google.gson.JsonObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.utils.DboException;
import ru.mtsbank.integration.dbo.insurance.controllers.dto.response.SummaryRes;
import ru.mtsbank.integration.dbo.insurance.gate.Insurance;

import java.util.UUID;

import static ru.mts.dbo.utils.Utils.preCheckToken;

@Component
@Slf4j
@RequiredArgsConstructor
public class SummaryMethod {

    private final Insurance insurance;

    public SummaryRes call(Long rboId, String msisdn){
        String uid = UUID.randomUUID().toString();
        log.info("{} start summary method for {}",uid,msisdn);
        SummaryRes res = new SummaryRes();
        try {
            preCheckToken(rboId, msisdn, "balance", uid);
            JsonObject param = new JsonObject();
            param.addProperty("phoneNumber", msisdn);
            res = insurance.call(SummaryRes.class, "summary", param.toString(), null, "POST");
            log.info("{} end summary method with answer {}", uid, res.toString());
        } catch (DboException e){
            throw new DboException(e.getType(),e.getSystem(),e.getUuid());
        }
        return res;
    }

}
