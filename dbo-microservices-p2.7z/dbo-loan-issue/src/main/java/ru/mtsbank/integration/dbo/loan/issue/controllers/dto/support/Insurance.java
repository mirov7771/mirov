package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@ToString
public class Insurance {

    @JsonProperty("requestId")
    private Long requestId;
    @JsonProperty("insuranceId")
    private Long insuranceId;
    @JsonProperty("decisionId")
    private String decisionId;
    @JsonProperty("insuranceProgrammCode")
    private String insuranceProgrammCode;
    @JsonProperty("premiumAmount")
    private BigDecimal premiumAmount;
    @JsonProperty("insuranceType")
    private String insuranceType;
    @JsonProperty("insurancePercent")
    private BigDecimal insurancePercent;

}
