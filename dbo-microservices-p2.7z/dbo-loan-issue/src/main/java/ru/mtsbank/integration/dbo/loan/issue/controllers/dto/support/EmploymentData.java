package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static ru.mts.dbo.utils.Utils.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@ToString
public class EmploymentData {

    @JsonProperty("employmentFullName")
    private String employmentFullName;
    @JsonProperty("workStartDate")
    private String workStartDate;
    @JsonProperty("employmentPhone")
    private String employmentPhone;
    @JsonProperty("employmentAddress")
    private Address employmentAddress;
    @JsonProperty("position")
    private String position;
    @JsonProperty("employmentInn")
    private String employmentInn;
    @JsonProperty("workStartYear")
    private String workStartYear;
    @JsonProperty("workActivity")
    private RefData workActivity;
    @JsonProperty("positionLevel")
    private RefData positionLevel;
    @JsonProperty("okved")
    private String okved;

    public Map<String, String> toMap(){
        Map<String, String> map = new HashMap<>();
        map.put("employmentFullName",employmentFullName);
        map.put("workStartDate",workStartDate);
        map.put("employmentPhone",employmentPhone);
        map.put("position",position);
        map.put("employmentInn",employmentInn);
        map.put("workStartYear",workStartYear);
        map.put("okved", okved);

        if (employmentAddress != null)
            setAddrMap(map, employmentAddress.toMap(),"employmentAddress");
        if (workActivity != null)
            setRefMap(map, workActivity.toMap(), "workActivity");
        if (positionLevel != null)
            setRefMap(map, positionLevel.toMap(), "positionLevel");

        map.values().removeAll(Collections.singleton(null));
        return map;
    }

    @JsonIgnore
    public boolean isEmpty(){
        return workActivity == null;
    }

}
