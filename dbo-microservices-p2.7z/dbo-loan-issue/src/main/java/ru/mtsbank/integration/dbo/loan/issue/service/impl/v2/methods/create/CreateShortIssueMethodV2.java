package ru.mtsbank.integration.dbo.loan.issue.service.impl.v2.methods.create;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.CreateIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.service.general.CreateIssueMethod;

import java.io.IOException;
import java.text.ParseException;
import java.util.UUID;

@Component
@Slf4j
public class CreateShortIssueMethodV2 extends CreateIssueMethod {

    @Override
    public CreateIssueRes call(CreateIssueReq req){
        String uid = UUID.randomUUID().toString();
        log.info("{} Start create short issue service with params {}", uid, req.toString());
        CreateIssueRes res = new CreateIssueRes();
        try {
            Long issueId = req.getCreditData().getIssueId();
            Issues issue = issuesRepository.findByIssueId(issueId);
            if (issue != null
                    && !CollectionUtils.isEmpty(issue.getIssueAttributesList()))
            {
                process(issue, req, issueId, uid, true);
                Long requestId = null;
                for(int i=0;i<1000;i++){
                    Thread.sleep(50);
                    log.info("Start searching requestId {} , iteration {}",issueId,i);
                    requestId = issueOperations.getRequestIdByIssueId(issueId);
                    if (requestId != null && !requestId.equals(0L)) {
                        log.info("Get requestId {} for issueId {}", requestId, issueId);
                        break;
                    }
                }
                if (requestId != null && !requestId.equals(0L))
                    res.setRequestId(requestId.toString());
                else
                    res.createError(501, "Сервис временно недоступен",400, null, "Не получен RESPONSE_REQ_SIEBEL", "createshortissue", null);
            } else {
                res.createError(1002, "Заявки с переданным идентификатором не существует",409, null, null, "createshortissue", null);
            }
        } catch (IOException | ParseException | InterruptedException e) {
            log.error("{} Error in create short issue v2 {}", uid, Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен",400, null, null, "createshortissue", null);
        }
        log.info("End create short issue service");
        return res;
    }

}
