package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Entity
@Table(name = "OFFERS")
@Getter @Setter
public class Offers implements Serializable {

    private static final long serialVersionUID = -9170861622834425990L;

    @Id
    @Column(name = "DECISIONID")
    private String decisionId;
    @Column(name = "REQUESTID")
    private Long requestId;
    @Column(name = "CREDITSUM")
    private BigDecimal creditSum;
    @Column(name = "CREDITMINSUM")
    private BigDecimal creditMinSum;
    @Column(name = "RATE")
    private BigDecimal rate;
    @Column(name = "CREDITPERIOD")
    private BigInteger creditPeriod;
    @Column(name = "MONTHLYPAYMENT")
    private BigDecimal monthlyPayment;
    @Column(name = "DECISIONMODE")
    private String decisionMode;
    @Column(name = "PRODUCTCODE")
    private String productCode;
    @Column(name = "PRODUCTNAME")
    private String productName;
    @Column(name = "POSSISSUEDBO")
    private Integer possIssueDbo;
    @OneToMany(mappedBy = "decisionId", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<Insurances> insurancesList;

}
