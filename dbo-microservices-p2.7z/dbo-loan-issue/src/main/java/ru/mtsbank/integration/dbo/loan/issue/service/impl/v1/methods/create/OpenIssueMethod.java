package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.gates.HumanFactorGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.loan.issue.builders.SaveIssueAttributeBuilder;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.OpenIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.OpenIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.*;
import ru.mtsbank.integration.dbo.loan.issue.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.loan.issue.builders.IssueCardMBuilder;
import ru.mtsbank.integration.dbo.loan.issue.dao.*;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.*;
import ru.mtsbank.integration.dbo.loan.issue.dao.operations.IssueOperations;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.*;
import ru.mtsbank.integration.mts.xsd.IssueCardM.IssueCardM;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.*;

import static ru.mts.dbo.utils.Utils.*;
import static ru.mtsbank.integration.dbo.loan.issue.service.general.utils.LoanUtils.prepareAddressFromDb;

@Component("openissue")
@Slf4j
public class OpenIssueMethod {

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private CreditParamsRepository creditParamsRepository;

    @Autowired
    private InterestRatesRepository interestRatesRepository;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    @Autowired
    private IssueCardMBuilder issueCardMBuilder;

    @Autowired
    private IssueOperations issueOperations;

    @Autowired
    private HumanFactorGate humanFactorGate;

    @Autowired
    public SaveIssueAttributeBuilder saveIssueAttributeBuilder;

    @Autowired
    public IssueAttributeRepository issueAttributeRepository;

    public OpenIssueRes call(OpenIssueReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start openissue service {}", uid, req.toString());
        OpenIssueRes res = new OpenIssueRes();
        CreditData creditData = new CreditData();
        PassportData passportData = new PassportData();
        EmploymentData employmentData = new EmploymentData();
        ClientData clientData = new ClientData();
        ParamData paramData = new ParamData();
        Long rboId = req.getRboID();
        List<Issues> inputIssues = issuesRepository.findByOwnerIdAndStatusSysName(rboId, LoanStates.INPUT.getStatusSysName());
        if (!CollectionUtils.isEmpty(inputIssues)) {
            res.createError(1018, "У клиента с ID " + rboId + " есть не обработанные заявки",409, null, null, "openissue", uid);
        } else {
            try {
                 log.info("{} Prepare credit params", uid);
                 setCreditParams(paramData);
                 log.info("{} Prepare interest rates", uid);
                 setInterestRates(paramData);
                 log.info("{} Prepare client attributes", uid);
                 setAnswer(creditData, passportData, employmentData, clientData, rboId, req.getIssueId(), req.getShortForm(), uid);
                 if (Boolean.TRUE.equals(clientData.isEmpty())) {
                     res.createError(501, "Не получены клиентские данные по клиенту с id " + rboId, 400, null, null, "openissue", uid);
                 } else if ("WRONG_STATUS".equals(clientData.getFamily())) {
                     res.createError(501, "Не получен ответ от Зибеля на ISSUE_CARD_M", 400, null, null, "openissue", uid);
                 } else if (req.getShortForm() != null && Boolean.TRUE.equals(req.getShortForm())) {
                     CreditData cd = new CreditData();
                     cd.setIssueId(creditData.getIssueId());
                     res.setCreditData(creditData);
                 } else {
                     if (creditData.getRequestSumma() == null)
                         creditData.setRequestSumma(new BigDecimal("100000.00"));
                     res.setCreditData(creditData);
                     res.setPassportData(passportData);
                     if (Boolean.FALSE.equals(employmentData.isEmpty()))
                         res.setEmploymentData(employmentData);
                     res.setClientData(clientData);
                     res.setParamData(paramData);
                 }
            } catch (IOException | ParseException | InterruptedException e) {
                log.error("{} Error in open issue {}", uid, e);
                res.createError(501, "Сервис временно недоступен",400, null, e.getMessage(), "openissue", uid);
                e.printStackTrace();
            }
        }
        log.info("{} End openissue service {}", uid, res.toString());
        return res;
    }

    private CustSearchInqRs getCustSearchInqRs(Long ownerId, String uid) throws IOException {
        String rsXml = esbGate.sendSalesMessageWithAnswer(
                xmlUnmarshaler.createXml(
                        custSearchInqRqBuilder.createCustSearchInqRq(ownerId.toString(), uid)));
        return xmlUnmarshaler.parse(CustSearchInqRs.class, rsXml);
    }

    private void setAnswer(CreditData creditData
                          ,PassportData passportData
                          ,EmploymentData employmentData
                          ,ClientData clientData
                          ,Long ownerId
                          ,Long oldIssueId
                          ,Boolean shortFlag
                          ,String uid)
            throws ParseException, InterruptedException, IOException {
        Issues issue = null;
        Long issueId;

        if (oldIssueId != null)
            issue = issuesRepository.findByIssueIdAndStatusSysName(oldIssueId, LoanStates.PRE_INPUT.getStatusSysName());


        boolean issueNotExists = issue == null;
        boolean noAttributes = false;
        if (!issueNotExists){
            noAttributes = CollectionUtils.isEmpty(issue.getIssueAttributesList());
        }
        Boolean changeInfo = false;
        if (!issueNotExists && !noAttributes){
            changeInfo = getChangeInfoFromBd(issue.getIssueAttributesList());
        }
        CustSearchInqRs rs = getCustSearchInqRs(ownerId, uid);
        if (rs != null
                && rs.getBankSvcRs() != null
                && rs.getBankSvcRs().getCustInfo() != null
                && rs.getBankSvcRs().getCustInfo().getPersonInfo() != null)
        {
            CustInfoType custInfo = rs.getBankSvcRs().getCustInfo();
            PersonInfoTypeCustSearchInqRs personInfo = custInfo.getPersonInfo();
            List<IdentityCardType> identityCard = personInfo.getIdentityCard();
            String seral = null;
            String number = null;
            String issueOrgCode = null;
            String issueOrgName = null;
            Date issueDate = null;
            boolean canContinue;
            for (IdentityCardType card : identityCard) {
                if (card.isPrimary() && card.getIdType().equals("21")) {
                    seral = card.getIdSeries();
                    number = card.getIdNum();
                    issueOrgCode = card.getIssuedByCode();
                    issueOrgName = card.getIssuedBy();
                    if (card.getIssueDt() != null)
                        issueDate = getDate(card.getIssueDt().getYear(), card.getIssueDt().getMonth(), card.getIssueDt().getDay());
                    break;
                }
            }
            if (issueNotExists || noAttributes) {
                if (issueNotExists) {
                    issue = createIssue(ownerId, uid);
                    issueId = issue.getIssueId();
                    log.info("{} Create issue in db {}", uid, issueId);
                } else {
                    issueId = issue.getIssueId();
                    log.info("{} Use old issue in db {}", uid, issueId);
                }
                IssueCardM issueCardM = issueCardMBuilder.issueCardMBuild(seral, number, issueId);
                String cardXml = xmlUnmarshaler.createXml(issueCardM);
                esbGate.sendSalesMessage(cardXml);

                canContinue = checkStatus(issueId, uid);

            } else {
                canContinue = true;
                issueId = issue.getIssueId();
                log.info("{} Find issue in db {}", uid, issueId);
            }
            if (canContinue) {
                log.info("{} Prepare data for issueId {}", uid, issueId);
                clientData.setClientName(formatString(personInfo.getFullName()));
                log.info("{} Prepare pasport data for issueId {}", uid, issueId);
                passportData.setClientDoc(seral + " " + number);
                passportData.setSerial(seral);
                passportData.setNumber(number);
                passportData.setIssueOrgCode(issueOrgCode);
                passportData.setIssueOrgName(issueOrgName);
                passportData.setIssueDate(issueDate);
                passportData.setSex("Male".equals(personInfo.getGender()) ? 0 : 1);
                log.info("{} Prepare client data for issueId {}", uid, issueId);
                clientData.setFamily(formatString(personInfo.getPersonName().getLastName()));
                clientData.setName(formatString(personInfo.getPersonName().getFirstName()));
                clientData.setFatherName(formatString(personInfo.getPersonName().getMiddleName()));
                passportData.setBirthPlace(nvl(personInfo.getBirthPlace(),""));
                if (personInfo.getBirthday() != null) {
                    Date bdate = getDate(personInfo.getBirthday().getYear(), personInfo.getBirthday().getMonth(), personInfo.getBirthday().getDay());
                    log.info("{} Prepare birth data for issueId {} {}", uid, issueId, bdate);
                    passportData.setBirthDate(bdate);
                }

                clientData.setEmail(personInfo.getContactInfo().getEmailAddr());
                List<FDXPhoneNum> phoneNums = personInfo.getContactInfo().getPhoneNum();
                for (FDXPhoneNum phoneNum : phoneNums) {
                    log.info("{} Prepare phone data for issueId {}", uid, issueId);
                    if (phoneNum.isPrimary() && phoneNum.getPhoneType().equals("Mobile")) {
                        log.info("{} Set phone data for issueId {}", uid, issueId);
                        clientData.setMobilePhone(phoneNum.getPhone());
                        break;
                    }
                }

                List<AddrType> postAddr = personInfo.getContactInfo().getPostAddr();
                for (AddrType addr : postAddr) {
                    log.info("{} Set address data for issueId {}", uid, issueId);
                    Address conAddr = new Address();
                    String type = addr.getAddrType();
                    if (type.equalsIgnoreCase("REGISTRATION")) {
                        log.info("{} Set REGISTRATION address data for issueId {}", uid, issueId);
                        prepareAddress(conAddr, addr);
                        passportData.setRegAddress(conAddr);
                    } else if (type.equalsIgnoreCase("REAL_LIVE")) {
                        log.info("{} Set REAL_LIVE address data for issueId {}", uid, issueId);
                        prepareAddress(conAddr, addr);
                        passportData.setFactAddress(conAddr);
                    }
                }
                log.info("{} next step for issueid {}", uid, issueId);
                if (!issueNotExists && !noAttributes) {
                    List<IssueAttribute> attrList = issue.getIssueAttributesList();
                    log.info("{} Attrs in db exists: {}", uid, attrList.size());
                    getAttrsFromDb(creditData, employmentData, clientData, passportData, attrList, changeInfo, uid);
                }
                log.info("{} Set issueid {}", uid, issueId);
                creditData.setIssueId(issueId);

                if (Boolean.TRUE.equals(shortFlag)){
                    CreateIssueReq req = new CreateIssueReq();
                    req.setClientData(clientData);
                    req.setPassportData(passportData);
                    issueAttributeRepository.saveAll(saveIssueAttributeBuilder.build(req,issueId));
                }
            } else {
                clientData.setFamily("WRONG_STATUS");
            }
            log.info("{} for issueId {} ClientData {}", uid, issueId, clientData.toString());
        }
        log.info("{} CreditData {}", uid, creditData);
    }

    private boolean checkStatus(Long issueId, String uid) throws InterruptedException {
        boolean canContinue = false;
        int ncpkTimeOut = 150;
        for(int i = 0; i < ncpkTimeOut; i++) {
            log.info("{} Wait STATUS_REPLY in iter {} issueId {}", uid, i, issueId);
            Thread.sleep(150);
            if (Boolean.TRUE.equals(issueOperations.findStatusCardReply(issueId))) {
                log.info("{} Get STATUS_REPLY for {}", uid, issueId);
                canContinue = true;
                log.info("{} Continue working with issueId {}", uid, issueId);
                break;
            }
        }
        return canContinue;
    }

    private Boolean getChangeInfoFromBd(List<IssueAttribute> issueAttributesList) {
        boolean retVal = true;
        for(IssueAttribute attr : issueAttributesList){
            if (attr.getAttrName().equals("changeInfo")) {
                retVal = getBoolFromStr(attr.getAttrValue());
                break;
            }
        }
        return retVal;
    }

    private Issues createIssue(Long ownerId, String uid){
        log.info("{} Delete old issue for rboid {}", uid, ownerId);
        issueOperations.deleteIssue(ownerId);
        return issuesRepository.save(new Issues(ownerId
                , LoanStates.PRE_INPUT.getStatus()
                , LoanStates.PRE_INPUT.getStatusSysName()
                , new Date()));
    }

    private void getAttrsFromDb(CreditData creditData
                               ,EmploymentData employmentData
                               ,ClientData clientData
                               ,PassportData passportData
                               ,List<IssueAttribute> attrList
                               ,Boolean flag
                               ,String uid)
    throws ParseException
    {
        Address employAddress = new Address();
        Address regAddress = new Address();
        Address factAddress = new Address();
        RefData issueCountry = new RefData();
        RefData martialStatus = new RefData();
        RefData educationLevel = new RefData();
        RefData ipdlStatusCode = new RefData();
        RefData loanPurpose = new RefData();
        RefData workActivity = new RefData();
        RefData positionLevel = new RefData();
        for(int i = 0; i < attrList.size(); i++){
            IssueAttribute attr = attrList.get(i);
            String attrName = attr.getAttrName();
            String attrValue = attr.getAttrValue();
            log.info("{} AttrIndex is {} ArrtName is {} AttrValue is {}", uid, i, attrName, attrValue);
            switch (attrName) {
                case "creditOtherGoal":
                    creditData.setCreditOtherGoal(attrValue);
                    break;
                case "employmentPhone":
                    employmentData.setEmploymentPhone(attrValue);
                    break;
                case "workStartDate":
                    employmentData.setWorkStartDate(attrValue);
                    break;
                case "employmentFullName":
                    employmentData.setEmploymentFullName(attrValue);
                    break;
                case "issueCountryINN":
                    clientData.setIssueCountryINN(attrValue);
                    break;
                case "codeWord":
                    creditData.setCodeWord(attrValue);
                    break;
                case "prevFatherName":
                    clientData.setPrevFatherName(attrValue);
                    break;
                case "prevFamily":
                    clientData.setPrevFamily(attrValue);
                    break;
                case "prevName":
                    clientData.setPrevName(attrValue);
                    break;
                case "channel":
                    creditData.setChannel(attrValue);
                    break;
                case "extraPhone":
                    clientData.setExtraPhone(attrValue);
                    break;
                case "dependents":
                    clientData.setDependents(nvl(getIntFromStr(attrValue),clientData.getDependents()));
                    break;
                case "creditPeriod":
                    creditData.setCreditPeriod(getBigIntFromStr(attrValue));
                    break;
                case "totalIncome":
                    clientData.setTotalIncome(getBigDecimalFromStr(attrValue));
                    break;
                case "requestSumma":
                    creditData.setRequestSumma(getBigDecimalFromStr(attrValue));
                    break;
                case "interestRateValue":
                    creditData.setInterestRateValue(getFloatFromStr(attrValue));
                    break;
                case "flagChangeFio":
                    clientData.setFlagChangeFio(getBoolFromStr(attrValue));
                    break;
                case "gatkaFlg":
                    clientData.setGatkaFlg(getBoolFromStr(attrValue));
                    break;
                case "smsAgreeFlag":
                    clientData.setSmsAgreeFlag(getBoolFromStr(attrValue));
                    break;
                case "persInfoFlag":
                    clientData.setPersInfoFlag(getBoolFromStr(attrValue));
                    break;
                case "bkiFlag":
                    clientData.setBkiFlag(getBoolFromStr(attrValue));
                    break;
                case "taxUSAFlag":
                    clientData.setTaxUSAFlag(getBoolFromStr(attrValue));
                    break;
                case "publicFlag":
                    clientData.setPublicFlag(getBoolFromStr(attrValue));
                    break;
                case "equalAddressFlag":
                    clientData.setEqualAddressFlag(getBoolFromStr(attrValue));
                    break;
                case "isSalaryClient":
                    clientData.setIsSalaryClient(getBoolFromStr(attrValue));
                    break;
                case "monthlyPayment":
                    creditData.setMonthlyPayment(getBigDecimalFromStr(attrValue));
                    break;
                case "employmentInn":
                    employmentData.setEmploymentInn(attrValue);
                    break;
                case "workStartYear":
                    employmentData.setWorkStartYear(attrValue);
                    break;
                case "position":
                    employmentData.setPosition(attrValue);
                    break;
                case "step":
                    creditData.setStep(getIntFromStr(attrValue));
                    break;
                case "bornUsa":
                    clientData.setBornUsa(getBoolFromStr(attrValue));
                    break;
                case "citizenUsaAndRf":
                    clientData.setCitizenUsaAndRf(getBoolFromStr(attrValue));
                    break;
                case "greenCard":
                    clientData.setGreenCard(getBoolFromStr(attrValue));
                    break;
                case "usaRegAddress":
                    clientData.setUsaRegAddress(attrValue);
                    break;
                case "usaFactAddress":
                    clientData.setUsaFactAddress(attrValue);
                    break;
                case "usaPhoneNumber":
                    clientData.setUsaPhoneNumber(attrValue);
                    break;
                case "changeInfo":
                    clientData.setChangeInfo(getBoolFromStr(attrValue));
                    break;
                case "email":
                    clientData.setEmail(attrValue);
                    break;
                case "sex":
                    passportData.setSex(getIntFromStr(attrValue));
                    break;
                case "birthPlace":
                    passportData.setBirthPlace(attrValue);
                    break;
            }

            if (passportData.getBirthDate() == null){
                if ("birthDate".equals(attrName)) {
                    passportData.setBirthDate(getDateFromStr(attrValue));
                }
            }

            if (passportData.getIssueDate() == null){
                if ("issueDate".equals(attrName)){
                    passportData.setIssueDate(getDateFromStr(attrValue));
                }
            }

            if (Boolean.TRUE.equals(flag)){
                switch (attrName) {
                    case "number":
                        passportData.setNumber(attrValue);
                        break;
                    case "serial":
                        passportData.setSerial(attrValue);
                        break;
                    case "issueOrgCode":
                        passportData.setIssueOrgCode(attrValue);
                        break;
                    case "issueOrgName":
                        passportData.setIssueOrgName(attrValue);
                        break;
                    case "clientName":
                        clientData.setClientName(attrValue);
                        break;
                    case "family":
                        clientData.setFamily(attrValue);
                        break;
                    case "name":
                        clientData.setName(attrValue);
                        break;
                    case "fatherName":
                        clientData.setFatherName(attrValue);
                        break;
                }
            }

            if (attrName.contains("employmentAddress"))
                prepareAddressFromDb(employAddress, attrName, attrValue);
            if (attrName.contains("regAddress"))
                prepareAddressFromDb(regAddress, attrName, attrValue);
            if (attrName.contains("factAddress"))
                prepareAddressFromDb(factAddress, attrName, attrValue);
            if (attrName.contains("issueCountry"))
                prepareRefData(issueCountry, attrName, attrValue);
            if (attrName.contains("educationLevel"))
                prepareRefData(educationLevel, attrName, attrValue);
            if (attrName.contains("ipdlStatusCode"))
                prepareRefData(ipdlStatusCode, attrName, attrValue);
            if (attrName.contains("loanPurpose"))
                prepareRefData(loanPurpose, attrName, attrValue);
            if (attrName.contains("workActivity"))
                prepareRefData(workActivity, attrName, attrValue);
            if (attrName.contains("positionLevel"))
                prepareRefData(positionLevel, attrName, attrValue);
            if (attrName.contains("martialStatus"))
                prepareRefData(martialStatus, attrName, attrValue);
        }
        if (Boolean.FALSE.equals(employAddress.isEmpty()))
            employmentData.setEmploymentAddress(employAddress);
        if (Boolean.FALSE.equals(issueCountry.isEmpty()))
            clientData.setIssueCountry(issueCountry);
        if (Boolean.FALSE.equals(educationLevel.isEmpty()))
            clientData.setEducationLevel(educationLevel);
        if (Boolean.FALSE.equals(ipdlStatusCode.isEmpty()))
            clientData.setIpdlStatusCode(ipdlStatusCode);
        if (Boolean.FALSE.equals(martialStatus.isEmpty()))
            clientData.setMartialStatus(martialStatus);
        if (Boolean.FALSE.equals(loanPurpose.isEmpty()))
            creditData.setLoanPurpose(loanPurpose);
        if (Boolean.FALSE.equals(workActivity.isEmpty()))
            employmentData.setWorkActivity(workActivity);
        if (Boolean.FALSE.equals(positionLevel.isEmpty()))
            employmentData.setPositionLevel(positionLevel);

        if (Boolean.FALSE.equals(regAddress.isEmpty()))
            passportData.setRegAddress(regAddress);
        if (Boolean.FALSE.equals(factAddress.isEmpty()))
            passportData.setFactAddress(factAddress);
    }

    private void prepareRefData(RefData ref, String attrName, String attrValue) {
        if (attrName.contains("/value"))
            ref.setValue(attrValue);
        else if (attrName.contains("/name"))
            ref.setName(attrValue);
    }

    private void setCreditParams(ParamData paramData){
        Iterable<CreditParams> creditParams = creditParamsRepository.findAll();
        for(CreditParams param : creditParams){
            String paramType = param.getParamType();
            if (paramType.equalsIgnoreCase("CreditAmt")) {
                paramData.setCreditAmt(new CreditParam() {{
                    setMax(param.getMaxValue());
                    setMin(param.getMinValue());
                }});
            } else if (paramType.equalsIgnoreCase("CreditTerm")) {
                paramData.setCreditTerm(new CreditParam() {{
                    setMax(param.getMaxValue());
                    setMin(param.getMinValue());
                }});
            } else if (paramType.equalsIgnoreCase("CreditSalaryAmt")) {
                paramData.setCreditSalaryAmt(new CreditParam() {{
                    setMax(param.getMaxValue());
                    setMin(param.getMinValue());
                }});
            }
        }
    }

    private void setInterestRates(ParamData paramData){
        Iterable<InterestRates> rates = interestRatesRepository.findAll();
        List<InterestRate> interestRates = new ArrayList<>();
        for(InterestRates rate : rates){
            InterestRate interestRate = new InterestRate();
            interestRate.setRate(rate.getInterestValue());
            interestRate.setSalaryRate(rate.getSalaryInterestValue());
            interestRate.setTerm(rate.getId());
            interestRates.add(interestRate);
        }
        paramData.setInterestRateList(interestRates);
    }

    private void prepareAddress(Address conAddr, AddrType addr) {
        conAddr.setCountryName(addr.getCountry());
        conAddr.setCountryCode(addr.getCountryCode());
        conAddr.setRegionName(addr.getRegion());
        conAddr.setRegionCode(addr.getRegionCode());
        conAddr.setRegionSocr(addr.getRegionCode());
        conAddr.setDistrictName(addr.getDistrict());
        conAddr.setCityName(addr.getCity());
        conAddr.setStreetName(addr.getStreet());
        if (addr.getHouseNum() != null)
            conAddr.setHouse(addr.getHouseNum().toString());
        conAddr.setBuilding(addr.getHouseExt());
        conAddr.setBlock(addr.getHouseBlock());
        if (addr.getUnitNum() != null)
            conAddr.setFlat(addr.getUnitNum().toString());
        conAddr.setZipCode(addr.getPostalCode());
        if (!StringUtils.isEmpty(addr.getAddr()))
            conAddr.setAddr(formatAddress(addr.getAddr()));
    }

    private String formatString(String value){
        StringBuilder sb = new StringBuilder();
        if (!StringUtils.isEmpty(value)) {
            String[] vals = value.split(" ");
            for (String val : vals) {
                sb.append(val.substring(0, 1).toUpperCase()).append(val.substring(1).toLowerCase()).append(" ");
            }
        }
        return sb.toString().trim();
    }

    private String formatAddress(String addr) {
        String val = addr;
        boolean useHf = false;
        try {
            Map<String, Object> adressMap = humanFactorGate.execute(val);
            Map<String, Object> address;
            if (!adressMap.isEmpty() && adressMap.get("suggestions") != null && isCollection(adressMap.get("suggestions"))) {
                List<Map<String, Object>> addrs = new ArrayList<>((Collection<Map<String, Object>>) adressMap.get("suggestions"));
                if (addrs.size() > 0) {
                    address = addrs.get(0);
                    val = (String) address.get("value");
                    if (!StringUtils.isEmpty(val))
                        useHf = true;
                }
            }
        } catch (Exception e){
            log.error("No answer from hf "+e);
            return getAddrVal(addr, val, useHf);
        }
        return getAddrVal(addr, val, useHf);
    }

    private String getAddrVal(String addr, String val, boolean useHf){
        if (Boolean.FALSE.equals(useHf)) {
            if (addr.contains("Российская Федерация,"))
                val = addr.substring(addr.indexOf("Российская Федерация,") + 21);
            else if (addr.contains("РФ,"))
                val = addr.substring(addr.indexOf("РФ,") + 3);
            else if (addr.contains("Россия,"))
                val = addr.substring(addr.indexOf("Россия,") + 7);
            else if (addr.contains("РОССИЯ,"))
                val = addr.substring(addr.indexOf("РОССИЯ,") + 7);
            else if (addr.contains("РОССИЙСКАЯ ФЕДЕРАЦИЯ,"))
                val = addr.substring(addr.indexOf("РОССИЙСКАЯ ФЕДЕРАЦИЯ,") + 7);
        }
        return val.trim();
    }

    public boolean isCollection(Object obj) {
        return obj.getClass().isArray() || obj instanceof Collection;
    }

}