package ru.mtsbank.integration.dbo.loan.issue.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.DocRec;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.BankSvcRs;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.DocList;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.DocListAddRs;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.FDXStatus;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.RequestInfo;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class DocListAddRsBuilder {

    @Autowired
    private DocumentsRepository documentsRepository;

    public DocListAddRs docListAddRs(Long requestId){

        DocListAddRs docListAddRs = new DocListAddRs();

        String rUid = UUID.randomUUID().toString();
        ru.mtsbank.integration.mts.xsd.DocListAddRs.ServerInfo serverInfo = new ru.mtsbank.integration.mts.xsd.DocListAddRs.ServerInfo();
        serverInfo.setMsgUID(rUid);
        serverInfo.setRqUID(rUid);
        serverInfo.setSPName("MTS_EIP_UMP");
        serverInfo.setMsgReceiver("SIEBEL");
        serverInfo.setServerDt(Utils.getXmlGregorianCalendar(new Date()));
        serverInfo.setMsgType("DocListAddRs");
        docListAddRs.setServerInfo(serverInfo);

        BankSvcRs bankSvcRs = new BankSvcRs();
        RequestInfo requestInfo = new RequestInfo();

        requestInfo.setRequestId(requestId.toString());
        requestInfo.setURL("https://www.DBO.ru");
        bankSvcRs.setRequestInfo(requestInfo);

        FDXStatus status = new FDXStatus();
        status.setStatusCode("0");
        bankSvcRs.setStatus(status);

        List<Documents> docList = documentsRepository.findByRequestId(requestId);

        if (!CollectionUtils.isEmpty(docList)) {
            bankSvcRs.setDocList(new DocList());
            for (Documents dr : docList) {
                DocRec d = new DocRec();
                d.setOrigName(dr.getDocName());
                d.setDocTypeName(dr.getDocTypeSysName());
                d.setHashDoc(Utils.updateStringInSHA(dr.getDocData().getBytes()));
                bankSvcRs.getDocList().getDocRec().add(d);
            }
        }
        docListAddRs.setBankSvcRs(bankSvcRs);
        return docListAddRs;
    }

}
