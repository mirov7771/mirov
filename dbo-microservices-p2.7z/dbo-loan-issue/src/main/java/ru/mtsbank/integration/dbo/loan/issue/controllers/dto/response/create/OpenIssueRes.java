package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@ToString
public class OpenIssueRes extends BaseResponse {

    @JsonProperty("passportData")
    private PassportData passportData;
    @JsonProperty("clientData")
    private ClientData clientData;
    @JsonProperty("creditData")
    private CreditData creditData;
    @JsonProperty("employmentData")
    private EmploymentData employmentData;
    @JsonProperty("paramData")
    private ParamData paramData;

}
