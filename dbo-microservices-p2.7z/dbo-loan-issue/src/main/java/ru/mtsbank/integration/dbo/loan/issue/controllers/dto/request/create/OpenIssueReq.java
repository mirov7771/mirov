package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;

@Getter
@ToString
public class OpenIssueReq extends BaseRequest {

    @JsonProperty("issueId")
    private Long issueId;
    @JsonProperty("shortForm")
    private Boolean shortForm;

}
