package ru.mtsbank.integration.dbo.loan.issue.service.general.utils;

import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Address;

public class LoanUtils {

    public static void prepareAddressFromDb(Address address, String attrName, String attrValue) {
        if (attrName.contains("/countryName"))
            address.setCountryName(attrValue);
        else if (attrName.contains("/countryCode"))
            address.setCountryCode(attrValue);
        else if (attrName.contains("/regionName"))
            address.setRegionName(attrValue);
        else if (attrName.contains("/regionCode"))
            address.setRegionCode(attrValue);
        else if (attrName.contains("/regionSocr"))
            address.setRegionSocr(attrValue);
        else if (attrName.contains("/districtName"))
            address.setDistrictName(attrValue);
        else if (attrName.contains("/localityName"))
            address.setLocalityName(attrValue);
        else if (attrName.contains("/cityName"))
            address.setCityName(attrValue);
        else if (attrName.contains("/streetName"))
            address.setStreetName(attrValue);
        else if (attrName.contains("/house"))
            address.setHouse(attrValue);
        else if (attrName.contains("/building"))
            address.setBuilding(attrValue);
        else if (attrName.contains("/block"))
            address.setBlock(attrValue);
        else if (attrName.contains("/flat"))
            address.setFlat(attrValue);
        else if (attrName.contains("/zipCode"))
            address.setZipCode(attrValue);
        else if (attrName.contains("/addr"))
            address.setAddr(attrValue);
    }

}
