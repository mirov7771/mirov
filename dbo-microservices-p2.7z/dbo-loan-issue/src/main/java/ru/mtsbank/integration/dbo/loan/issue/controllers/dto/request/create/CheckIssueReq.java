package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create;

import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

@Getter
public class CheckIssueReq extends BaseRequest {

}
