package ru.mtsbank.integration.dbo.loan.issue.service;

import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CheckIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.OpenIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueDocListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferSelectReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.*;

public interface Service {

    default BaseResponse checkIssue(CheckIssueReq req){return null;}
    default BaseResponse createIssue(CreateIssueReq req){return null;}
    default BaseResponse openIssue(OpenIssueReq req){return null;}
    default BaseResponse loanIssueList(LoanIssueListReq  req){return null;}
    default BaseResponse loanIssueDocList(LoanIssueDocListReq req){return null;}
    default BaseResponse offerList(OfferListReq req){return null;}
    default BaseResponse offerSelect(OfferSelectReq req){return null;}
    default BaseResponse cancelIssue(CancelIssueReq req){return null;}
    default BaseResponse openDoc(OpenDocReq req){return null;}
    default BaseResponse preSignIssue(PreSignIssueReq req){return null;}
    default BaseResponse sendDocs(SendDocsReq req){return null;}
    default BaseResponse signIssue(SignIssueReq req){return null;}
    default BaseResponse createShortIssue(CreateIssueReq req){return null;}

}
