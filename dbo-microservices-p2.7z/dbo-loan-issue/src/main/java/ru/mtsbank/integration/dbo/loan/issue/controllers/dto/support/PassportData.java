package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static ru.mts.dbo.utils.Utils.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@ToString
@Slf4j
public class PassportData {

    @JsonProperty("clientDoc")
    private String clientDoc;
    @JsonProperty("regAddress")
    private Address regAddress;
    @JsonProperty("factAddress")
    private Address factAddress;
    @JsonProperty("sex")
    private Integer sex;
    @JsonProperty("birthDate")
    private Date birthDate;
    @JsonProperty("birthPlace")
    private String birthPlace;
    @JsonProperty("serial")
    private String serial;
    @JsonProperty("number")
    private String number;
    @JsonProperty("issueOrgCode")
    private String issueOrgCode;
    @JsonProperty("issueOrgName")
    private String issueOrgName;
    @JsonProperty("issueDate")
    private Date issueDate;

    public Map<String, String> toMap(){
        Map<String, String> map = new HashMap<>();
        map.put("clientDoc",clientDoc);
        if (sex != null)
            map.put("sex",sex.toString());
        map.put("birthDate", getStrFromDateGmt(birthDate, "GMT+4"));
        map.put("birthPlace",birthPlace);
        map.put("serial",serial);
        map.put("number",number);
        map.put("issueOrgCode",issueOrgCode);
        map.put("issueOrgName",issueOrgName);
        map.put("issueDate",getStrFromDateGmt(issueDate, "GMT+4"));
        if (regAddress != null)
            setAddrMap(map, regAddress.toMap(),"regAddress");
        if (factAddress != null)
            setAddrMap(map, factAddress.toMap(), "factAddress");
        map.values().removeAll(Collections.singleton(null));
        return map;
    }

}
