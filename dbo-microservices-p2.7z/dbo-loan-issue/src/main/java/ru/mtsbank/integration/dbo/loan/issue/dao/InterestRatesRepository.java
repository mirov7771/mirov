package ru.mtsbank.integration.dbo.loan.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.InterestRates;

@Repository
public interface InterestRatesRepository extends CrudRepository<InterestRates, String> {

}
