package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

@Getter
public class LoanIssueDocListReq extends BaseRequest {

    @JsonProperty("agreeNum")
    private String agreeNum;

}
