package ru.mtsbank.integration.dbo.loan.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.CheckIssue;

@Repository
public interface CheckIssueRepository extends CrudRepository<CheckIssue, String> {

    CheckIssue findByIssueId(Long issueId);

}