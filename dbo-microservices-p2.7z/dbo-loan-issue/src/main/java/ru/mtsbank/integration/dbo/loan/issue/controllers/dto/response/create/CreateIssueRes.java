package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create;

import ru.mts.dbo.dto.BaseResponse;

public class CreateIssueRes extends BaseResponse {
}
