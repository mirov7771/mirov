package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.signing;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.diasoft.integration.mts.xsd.CustNotifAddNf.*;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.SendDocsReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.SendDocsRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@Component("senddocs")
@Slf4j
public class SendDocsMethod {

    @Autowired
    private DocumentsRepository documentsRepository;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    public SendDocsRes call(SendDocsReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start senddocs service", uid);
        List<Documents> documentsList = documentsRepository.findByRequestId(req.getRequestId());
        SendDocsRes res = new SendDocsRes();
        try {
            if (!CollectionUtils.isEmpty(documentsList)) {
                CustNotifAddNf custNotifAddNf = new CustNotifAddNf();
                ServerInfo serverInfo = new ServerInfo();
                serverInfo.setMsgUID(uid);
                serverInfo.setRqUID(uid);
                serverInfo.setMsgReceiver("ESB");
                serverInfo.setSPName("MTS_EIP_UMP");
                serverInfo.setMsgType("CustNotifAddNf");
                serverInfo.setServerDt(getXmlGregorianCalendar(new Date()));
                custNotifAddNf.setServerInfo(serverInfo);

                NotifInfo notifInfo = new NotifInfo();
                EmailInfo emailInfo = new EmailInfo();
                String smtpMessage = "Документы по кредиту";
                String smtpSender = "crm@mtsbank.ru";
                String charSet = "Windows-1251";
                emailInfo.setTo(req.getEmail());
                emailInfo.setSubject(smtpMessage);
                emailInfo.setFrom(smtpSender);

                Body body = new Body();
                Data data = new Data();
                data.setData(smtpMessage.getBytes(charSet));
                data.setCharset(charSet);
                body.setData(data);

                AttachInfo attachInfo = new AttachInfo();
                for (Documents item : documentsList) {
                    Attachment attachment = new Attachment();
                    File file = new File();
                    file.setName(item.getDocName() + ".PDF");
                    file.setCharset(charSet);
                    Data2 itemData = new Data2();
                    itemData.setData(item.getDocData().getBytes());
                    file.setData(itemData);
                    attachment.setFile(file);
                    attachInfo.getAttachment().add(attachment);
                }
                emailInfo.setAttachInfo(attachInfo);
                emailInfo.setBody(body);
                notifInfo.setEmailInfo(emailInfo);
                custNotifAddNf.setNotifInfo(notifInfo);
                String xml = xmlUnmarshaler.createXml(custNotifAddNf);
                esbGate.sendInfoMessage(xml);
                res.setRequestId(uid);
            } else {
                res.createError(1002, String.format("Не найдены документы по заявке с ID %s",req.getRequestId()),406, null, null, "senddocs", uid);
            }
        } catch (IOException e) {
            log.error("{} Error in send docs {}", uid, Utils.getStackError(e));
            res.createError(500, "Сервис временно недоступен",406, null, null, "senddocs", uid);
        }
        log.info("{} End senddocs service", uid);
        return res;
    }

}
