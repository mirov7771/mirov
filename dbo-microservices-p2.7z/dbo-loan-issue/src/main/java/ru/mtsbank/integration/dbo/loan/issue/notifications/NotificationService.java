package ru.mtsbank.integration.dbo.loan.issue.notifications;

public interface NotificationService {

    void handleRequest(String xmlRequest) throws Exception;

}
