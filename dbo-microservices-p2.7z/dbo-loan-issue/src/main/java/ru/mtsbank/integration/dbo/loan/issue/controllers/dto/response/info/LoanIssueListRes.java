package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.info;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Issue;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class LoanIssueListRes extends BaseResponse {

    @JsonProperty("issueList")
    private List<Issue> issueList;

}
