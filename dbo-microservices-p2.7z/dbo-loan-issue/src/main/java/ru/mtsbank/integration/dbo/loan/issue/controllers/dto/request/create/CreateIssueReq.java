package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.ClientData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.CreditData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.EmploymentData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.PassportData;

@Getter @Setter
@ToString
public class CreateIssueReq extends BaseRequest {

    @JsonProperty("isFinal")
    private Boolean isFinal;
    @JsonProperty("passportData")
    private PassportData passportData;
    @JsonProperty("clientData")
    private ClientData clientData;
    @JsonProperty("creditData")
    private CreditData creditData;
    @JsonProperty("employmentData")
    private EmploymentData employmentData;

}
