package ru.mtsbank.integration.dbo.loan.issue.service.general;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.PreSignIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.PreSignIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Doc;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.operations.IssueOperations;

import ru.mts.dbo.enums.LoanStates;

import java.util.*;

@Slf4j
public abstract class PreSignIssueMethod {

    @Autowired
    public IssuesRepository issuesRepository;

    @Autowired
    public DocumentsRepository documentsRepository;

    @Autowired
    public KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    public IssueOperations issueOperations;

    public PreSignIssueRes preSignCall(PreSignIssueReq req){
        log.info("Start presignissue service with params "+req.toString());
        PreSignIssueRes res = new PreSignIssueRes();
        Issues issues = issuesRepository.findByRequestId(req.getRequestId());
        Boolean secondCall = req.getSecondCall();
        String rqUid = UUID.randomUUID().toString();
        if (issues == null){
            res.createError(1002, String.format("Не найдена заявка с ID %s",req.getRequestId()),406, null, null, "presignissue", rqUid);
        } else if (issues.getSendForSign() != null && issues.getSendForSign().equals(1)){
            res.createError(1028, "Ваши документы уже формируются. Дождитесь завершения",406, null, null, "presignissue", rqUid);
        } else {
            String state = issues.getStatusSysName();
            if (state.equalsIgnoreCase(LoanStates.SIGNING.getStatusSysName())) {
                signing(issues, res);
            } else if (state.equalsIgnoreCase(LoanStates.WAITING_CLIENT_InDBO.getStatusSysName()) || Boolean.TRUE.equals(req.getSecondCall())) {
                preSignCall(issues, res, secondCall, rqUid);
            } else if (state.equalsIgnoreCase(LoanStates.APPROVED.getStatusSysName()) || state.equalsIgnoreCase(LoanStates.SCORING.getStatusSysName())) {
                res.createError(1004, "Заявка на рассмотрении. Документы придут в течение нескольких минут", 406, null, null, "presignissue", rqUid);
            } else if (state.equalsIgnoreCase(LoanStates.WAITING_CLIENT_InDO.getStatusSysName())){
                res.createError(1032, "Для оформления заявки необходимо обратиться в ДО", 409, null, null, "presignissue", rqUid);
            } else if (state.equalsIgnoreCase(LoanStates.BANK_REFUSE.getStatusSysName())){
                res.createError(1031, "Заявка отклонена", 409, null, null, "presignissue", rqUid);
            }
        }
        log.info("End presignissue service with result "+res.toString());
        return res;
    }

    private void signing(Issues issue, PreSignIssueRes res){
        res.setLoanLimit(issue.getLoanLimit());
        res.setLoanTerm(issue.getLoanTerm());
        res.setInterestRate(issue.getInterestRate());
        res.setMonthlyPayment(issue.getMonthlyPayment());
        res.setIssueDate(issue.getIssueDate());
        List<Documents> documents = documentsRepository.findByRequestId(issue.getRequestId());
        if (!CollectionUtils.isEmpty(documents)) {
            List<Doc> docs = new ArrayList<>();
            for(Documents dbItem : documents){
                Doc doc = new Doc();
                doc.setDocId(dbItem.getDocumentId());
                doc.setDocName(dbItem.getDocName());
                doc.setDocTypeSysName(dbItem.getDocTypeSysName());
                docs.add(doc);
            }
            res.setDocList(docs);
        }
    }

    public void signing(Issues issue, String loanLimit, String loanTerm, String interestRate, String monthlyPayment, PreSignIssueRes res, String rqUid){
        res.setLoanLimit(loanLimit);
        res.setLoanTerm(loanTerm);
        res.setInterestRate(interestRate);
        res.setMonthlyPayment(monthlyPayment);
        res.setIssueDate(issue.getIssueDate());
        List<Documents> documents = documentsRepository.findByRequestId(issue.getRequestId());
        if (!CollectionUtils.isEmpty(documents)) {
            List<Doc> docs = new ArrayList<>();
            for(Documents dbItem : documents){
                Doc doc = new Doc();
                doc.setDocId(dbItem.getDocumentId());
                doc.setDocName(dbItem.getDocName());
                doc.setDocTypeSysName(dbItem.getDocTypeSysName());
                docs.add(doc);
            }
            res.setDocList(docs);
        }
        res.setRequestId(rqUid);
    }

    public abstract void preSignCall(Issues issue, PreSignIssueRes res, Boolean secondCall, String rqUid);
}
