package ru.mtsbank.integration.dbo.loan.issue.builders;

import org.springframework.stereotype.Component;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.mts.xsd.IssueCardM.DocumentFullDataType;
import ru.mtsbank.integration.mts.xsd.IssueCardM.IssueCardM;
import ru.mtsbank.integration.mts.xsd.IssueCardM.SystemType;

import java.util.Date;
import java.util.UUID;

@Component
public class IssueCardMBuilder {

    public IssueCardM issueCardMBuild(String serial, String number, Long issueId){
        IssueCardM issueCardM = new IssueCardM();
        IssueCardM.ServerInfo serverInfo = new IssueCardM.ServerInfo();
        serverInfo.setMsgType("ISSUE_CARD_M");
        issueCardM.setServerInfo(serverInfo);
        issueCardM.setMessageType("ISSUE_CARD_M");
        issueCardM.setMtsRequestId(issueId);
        issueCardM.setMessageId(UUID.randomUUID().toString());
        issueCardM.setMessageDateTime(Utils.getXmlGregorianCalendar(new Date()));
        issueCardM.setSPName("MTS_EIP_UMP");
        issueCardM.setMsgReceiver("SIEBEL");

        IssueCardM.Request request = new IssueCardM.Request();
        IssueCardM.Request.ServiceData serviceData = new IssueCardM.Request.ServiceData();
        serviceData.setInitiatorCode(SystemType.MTS_EIP_UMP);
        serviceData.setSourceCode(SystemType.SIEBEL);
        request.setServiceData(serviceData);

        IssueCardM.Request.ClientComplexData clientComplexData = new IssueCardM.Request.ClientComplexData();
        IssueCardM.Request.ClientComplexData.Client client = new IssueCardM.Request.ClientComplexData.Client();
        IssueCardM.Request.ClientComplexData.Client.ClientListDocument clientListDocument = new IssueCardM.Request.ClientComplexData.Client.ClientListDocument();
        DocumentFullDataType documentFullDataType = new DocumentFullDataType();
        documentFullDataType.setSerial(serial);
        documentFullDataType.setNumber(number);
        documentFullDataType.setDocumentType("DOCTYPE.FIRST.1");
        documentFullDataType.setIsActive(true);
        documentFullDataType.setIsPrimary(true);
        clientListDocument.setClientDocument(documentFullDataType);
        client.setClientListDocument(clientListDocument);
        clientComplexData.setClient(client);

        IssueCardM.Request.ClientComplexData.ClientRequest clientRequest = new IssueCardM.Request.ClientComplexData.ClientRequest();
        IssueCardM.Request.ClientComplexData.ClientRequest.ClientRequestCommonData clientRequestCommonData = new IssueCardM.Request.ClientComplexData.ClientRequest.ClientRequestCommonData();
        IssueCardM.Request.ClientComplexData.ClientRequest.ClientRequestCommonData.Product product = new IssueCardM.Request.ClientComplexData.ClientRequest.ClientRequestCommonData.Product();
        product.setProductCode("MTS.NCPK");
        clientRequestCommonData.setProduct(product);
        clientRequest.setClientRequestCommonData(clientRequestCommonData);
        clientComplexData.setClientRequest(clientRequest);
        request.setClientComplexData(clientComplexData);
        issueCardM.setRequest(request);
        return issueCardM;
    }

}
