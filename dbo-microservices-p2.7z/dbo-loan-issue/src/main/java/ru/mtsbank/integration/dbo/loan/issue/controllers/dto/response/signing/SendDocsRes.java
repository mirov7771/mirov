package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class SendDocsRes extends BaseResponse {
}
