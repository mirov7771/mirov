package ru.mtsbank.integration.dbo.loan.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Offers;

import java.util.List;

@Repository
public interface OffersRepository extends CrudRepository<Offers, String> {

    List<Offers> findByRequestId(Long requestId);
    Offers findByRequestIdAndDecisionId(Long requestId, String decisionId);

}
