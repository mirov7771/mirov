package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@ToString
public class Address {

    @JsonProperty("countryName")
    private String countryName;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("regionName")
    private String regionName;
    @JsonProperty("regionCode")
    private String regionCode;
    @JsonProperty("regionSocr")
    private String regionSocr;
    @JsonProperty("districtName")
    private String districtName;
    @JsonProperty("localityName")
    private String localityName;
    @JsonProperty("cityName")
    private String cityName;
    @JsonProperty("streetName")
    private String streetName;
    @JsonProperty("house")
    private String house;
    @JsonProperty("building")
    private String building;
    @JsonProperty("block")
    private String block;
    @JsonProperty("flat")
    private String flat;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("addr")
    private String addr;

    public Map<String,String> toMap(){
        Map<String, String> map = new HashMap<>();
        map.put("countryName",countryName);
        map.put("countryCode",countryCode);
        map.put("regionName",regionName);
        map.put("regionCode",regionCode);
        map.put("regionSocr",regionSocr);
        map.put("districtName",districtName);
        map.put("localityName",localityName);
        map.put("cityName",cityName);
        map.put("streetName",streetName);
        map.put("house",house);
        map.put("building",building);
        map.put("block",block);
        map.put("flat",flat);
        map.put("zipCode",zipCode);
        map.put("addr",createAddr());
        return map;
    }

    @JsonIgnore
    public boolean isEmpty(){
        return countryName == null;
    }

    @JsonIgnore
    private String createAddr(){
        if (addr != null)
            return addr;
        String fullAddr = cityName;
        if (streetName != null)
            fullAddr += ", ул "+streetName;
        if (house != null)
            fullAddr += ", д "+house;
        if (building != null)
            fullAddr += ", к "+building;
        if (block != null)
            fullAddr += ", с"+block;
        if (flat != null)
            fullAddr += ", кв "+flat;
        return fullAddr;
    }

}
