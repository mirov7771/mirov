package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "CREDITPARAMS")
@Getter @Setter
public class CreditParams implements Serializable {

    private static final long serialVersionUID = 3427045983572099025L;

    @Id
    @Column(name = "PARAMTYPE")
    private String paramType;
    @Column(name = "MINVALUE")
    private Long minValue;
    @Column(name = "MAXVALUE")
    private Long maxValue;
    @Column(name = "STEPVALUE")
    private Long stepValue;

}
