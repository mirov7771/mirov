package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "INSURANCES")
@Getter @Setter
public class Insurances implements Serializable {

    private static final long serialVersionUID = -7557172446481635954L;

    @Id
    @Column(name = "INSURANCEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long insuranceId;
    @Column(name = "REQUESTID")
    private Long requestId;
    @Column(name = "PROGRAMCODE")
    private String programCode;
    @Column(name = "PREMIUMAMOUNT")
    private BigDecimal premiumAmount;
    @Column(name = "INSURANCETYPE")
    private String insuranceType;
    @Column(name = "INSURANCEPERCENT")
    private BigDecimal insurancePercent;
    @Column(name = "DECISIONID")
    private String decisionId;

}
