package ru.mtsbank.integration.dbo.loan.issue.builders;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.mts.xsd.Agreement.AgreementRs;
import ru.mtsbank.integration.mts.xsd.Agreement.MessageType;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;
import static ru.mtsbank.integration.mts.xsd.Agreement.SystemType.*;

@Component
public class AgreementRsBuilder {

    public AgreementRs agreementRsBuild(BigInteger requestId, String id, BigDecimal amount, Integer payDay, String rqUid){
        AgreementRs rs = new AgreementRs();
        rs.setRequestId(requestId);
        rs.setMessageId(rqUid);
        rs.setMessageIdRq(rqUid);
        rs.setMessageType(MessageType.AGREEMENT_RS);
        rs.setMessageDateTime(getXmlGregorianCalendar(new Date()));
        rs.setInitiatorCode(MTS_EIP_UMP);
        rs.setSourceCode(SIEBEL);
        rs.setCreditDecision(new AgreementRs.CreditDecision(){{
            setDecisionId(id);
            setCreditSum(amount);
        }});
        rs.setPayDay(payDay);
        return rs;
    }

}
