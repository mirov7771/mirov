package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

@Getter
public class OpenDocReq extends BaseRequest {

    @JsonProperty("docId")
    private Long docId;
    @JsonProperty("agreeNum")
    private String agreeNum;
    @JsonProperty("docTypeSysName")
    private String docTypeSysName;

}
