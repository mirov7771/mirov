package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class InterestRate {

    @JsonProperty("term")
    private Long term;
    @JsonProperty("rate")
    private Float rate;
    @JsonProperty("salaryRate")
    private Float salaryRate;

}
