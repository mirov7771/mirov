package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.selection;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@Setter
public class OfferSelectRes extends BaseResponse {

    @JsonProperty("readyToSign")
    private Boolean readyToSign;

}
