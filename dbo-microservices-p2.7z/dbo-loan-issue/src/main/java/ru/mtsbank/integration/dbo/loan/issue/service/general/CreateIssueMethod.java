package ru.mtsbank.integration.dbo.loan.issue.service.general;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestClientException;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.builders.AddressBuilder;
import ru.mtsbank.integration.dbo.loan.issue.builders.RegisterRegSiteBuilder;
import ru.mtsbank.integration.dbo.loan.issue.builders.SaveIssueAttributeBuilder;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.CreateIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Address;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.ClientData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.PassportData;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssueAttributeRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.IssueAttribute;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.operations.IssueOperations;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import static ru.mts.dbo.utils.Utils.*;
import static ru.mtsbank.integration.dbo.loan.issue.service.general.utils.LoanUtils.prepareAddressFromDb;

@Slf4j
public abstract class CreateIssueMethod {

    @Autowired
    private RegisterRegSiteBuilder registerRegSiteBuilder;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private SaveIssueAttributeBuilder saveIssueAttributeBuilder;

    @Autowired
    private IssueAttributeRepository issueAttributeRepository;

    @Autowired
    public IssuesRepository issuesRepository;

    @Autowired
    public IssueOperations issueOperations;

    @Autowired
    private AddressBuilder addressBuilder;

    public abstract CreateIssueRes call(CreateIssueReq req);

    public void setClientAndPassportData(List<IssueAttribute> attrList, CreateIssueReq req) throws ParseException {
        PassportData passportData = new PassportData();
        ClientData clientData = new ClientData();
        if (req.getClientData() != null)
            clientData = req.getClientData();
        Address regAddress = new Address();
        Address factAddress = new Address();
        for(int i = 0; i < attrList.size(); i++) {
            IssueAttribute attr = attrList.get(i);
            String attrName = attr.getAttrName();
            String attrValue = attr.getAttrValue();
            log.info("AttrIndex is " + i + " ArrtName is " + attrName + " AttrValue is " + attrValue);
            log.info("AttrIndex is " + i + " ArrtName is " + attrName + " AttrValue is " + attrValue);
            switch (attrName) {
                case "issueCountryINN":
                    clientData.setIssueCountryINN(attrValue);
                    break;
                case "prevFatherName":
                    clientData.setPrevFatherName(attrValue);
                    break;
                case "prevFamily":
                    clientData.setPrevFamily(attrValue);
                    break;
                case "prevName":
                    clientData.setPrevName(attrValue);
                    break;
                case "extraPhone":
                    clientData.setExtraPhone(attrValue);
                    break;
                case "mobilePhone":
                    clientData.setMobilePhone(attrValue);
                    break;
                case "dependents":
                    clientData.setDependents(nvl(getIntFromStr(attrValue), clientData.getDependents()));
                    break;
                case "totalIncome":
                    clientData.setTotalIncome(getBigDecimalFromStr(attrValue));
                    break;
                case "flagChangeFio":
                    clientData.setFlagChangeFio(getBoolFromStr(attrValue));
                    break;
                case "gatkaFlg":
                    clientData.setGatkaFlg(getBoolFromStr(attrValue));
                    break;
                case "smsAgreeFlag":
                    clientData.setSmsAgreeFlag(getBoolFromStr(attrValue));
                    break;
                case "persInfoFlag":
                    clientData.setPersInfoFlag(getBoolFromStr(attrValue));
                    break;
                case "bkiFlag":
                    clientData.setBkiFlag(getBoolFromStr(attrValue));
                    break;
                case "taxUSAFlag":
                    clientData.setTaxUSAFlag(getBoolFromStr(attrValue));
                    break;
                case "publicFlag":
                    clientData.setPublicFlag(getBoolFromStr(attrValue));
                    break;
                case "equalAddressFlag":
                    clientData.setEqualAddressFlag(getBoolFromStr(attrValue));
                    break;
                case "isSalaryClient":
                    clientData.setIsSalaryClient(getBoolFromStr(attrValue));
                    break;
                case "bornUsa":
                    clientData.setBornUsa(getBoolFromStr(attrValue));
                    break;
                case "citizenUsaAndRf":
                    clientData.setCitizenUsaAndRf(getBoolFromStr(attrValue));
                    break;
                case "greenCard":
                    clientData.setGreenCard(getBoolFromStr(attrValue));
                    break;
                case "usaRegAddress":
                    clientData.setUsaRegAddress(attrValue);
                    break;
                case "usaFactAddress":
                    clientData.setUsaFactAddress(attrValue);
                    break;
                case "usaPhoneNumber":
                    clientData.setUsaPhoneNumber(attrValue);
                    break;
                case "changeInfo":
                    clientData.setChangeInfo(getBoolFromStr(attrValue));
                    break;
                case "email":
                    clientData.setEmail(attrValue);
                    break;
                case "number":
                    passportData.setNumber(attrValue);
                    break;
                case "serial":
                    passportData.setSerial(attrValue);
                    break;
                case "issueOrgCode":
                    passportData.setIssueOrgCode(attrValue);
                    break;
                case "issueOrgName":
                    passportData.setIssueOrgName(attrValue);
                    break;
                case "issueDate":
                    passportData.setIssueDate(getDateFromStr(attrValue));
                    break;
                case "clientName":
                    clientData.setClientName(attrValue);
                    break;
                case "family":
                    clientData.setFamily(attrValue);
                    break;
                case "name":
                    clientData.setName(attrValue);
                    break;
                case "fatherName":
                    clientData.setFatherName(attrValue);
                    break;
                case "sex":
                    passportData.setSex(getIntFromStr(attrValue));
                    break;
                case "birthDate":
                    passportData.setBirthDate(getDateFromStr(attrValue));
                    break;
                case "birthPlace":
                    passportData.setBirthPlace(attrValue);
                    break;
            }

            if (attrName.contains("regAddress"))
                prepareAddressFromDb(regAddress, attrName, attrValue);
            if (attrName.contains("factAddress"))
                prepareAddressFromDb(factAddress, attrName, attrValue);
        }
        if (Boolean.FALSE.equals(regAddress.isEmpty()))
            passportData.setRegAddress(regAddress);
        if (Boolean.FALSE.equals(factAddress.isEmpty()))
            passportData.setFactAddress(factAddress);
        req.setPassportData(passportData);
        clientData.setBkiFlag(true);
        clientData.setShortForm(true);
        req.setClientData(clientData);
    }

    protected void process(Issues issue, CreateIssueReq req, Long issueId, String uid, Boolean isShort) throws IOException, ParseException {
        if (req.getEmploymentData() != null
                && req.getEmploymentData().getEmploymentAddress() != null
                && !isEmpty(req.getEmploymentData().getEmploymentAddress().getAddr())
                && isEmpty(req.getEmploymentData().getEmploymentAddress().getCityName())
                && isEmpty(req.getEmploymentData().getEmploymentAddress().getLocalityName()))
        {
            req.getEmploymentData().setEmploymentAddress(setEmplAddr(req, uid));
        }
        if (Boolean.TRUE.equals(isShort)) {
            setClientAndPassportData(issue.getIssueAttributesList(), req);
        }
        String reqId = req.getCreditData().getChannel() + "-" + issueId;

        issueOperations.deleteAttributes(issueId);
        issueAttributeRepository.saveAll(saveIssueAttributeBuilder.build(req,issueId));
        if ((req.getIsFinal() != null
                && Boolean.TRUE.equals(req.getIsFinal()))
                || Boolean.TRUE.equals(isShort))
        {
            esbGate.sendSalesMessage(xmlUnmarshaler.createXml(registerRegSiteBuilder.build(req, reqId, uid)));
            issue.setStatusSysName(LoanStates.INPUT.getStatusSysName());
            issue.setStatus(LoanStates.INPUT.getStatus());
            issuesRepository.save(issue);
        }
    }

    private Address setEmplAddr(CreateIssueReq req, String uid){
        try {
            return addressBuilder.call(req.getEmploymentData().getEmploymentAddress().getAddr());
        } catch (RestClientException e){
            log.error("{} error in getting hf {}", uid, Utils.getStackError(e));
            return req.getEmploymentData().getEmploymentAddress();
        }
    }

}
