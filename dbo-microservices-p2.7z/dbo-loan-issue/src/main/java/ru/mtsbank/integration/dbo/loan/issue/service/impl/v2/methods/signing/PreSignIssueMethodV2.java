package ru.mtsbank.integration.dbo.loan.issue.service.impl.v2.methods.signing;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.PreSignIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.PreSignIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.service.general.PreSignIssueMethod;
import ru.mtsbank.integration.mts.xsd.RequestMod.*;

import java.util.Date;
import java.util.Map;

@Component
@Slf4j
public class PreSignIssueMethodV2 extends PreSignIssueMethod {

    public PreSignIssueRes call(PreSignIssueReq req){
        return preSignCall(req);
    }

    public void preSignCall(Issues issue, PreSignIssueRes res, Boolean secondCall, String rqUid) {
        try{
            Long requestId = issue.getRequestId();
            int ncpkTimeOut = 150*3;
            long milis = 35;
            if (!Boolean.TRUE.equals(secondCall)) {
                issueOperations.updateSendForSign(1, issue.getIssueId());
                RequestModNf requestModNf = new RequestModNf();
                ServerInfoType serverInfoType = new ServerInfoType();
                serverInfoType.setMsgUID(rqUid);
                serverInfoType.setRqUID(rqUid);
                serverInfoType.setSPName("MTS_EIP_UMP");
                serverInfoType.setMsgReceiver("SIEBEL");
                serverInfoType.setServerDt(Utils.getXmlGregorianCalendar(new Date()));
                serverInfoType.setMsgType("RequestModNf");
                requestModNf.setServerInfo(serverInfoType);

                BankSvcRq bankSvcRq = new BankSvcRq();
                CustInfo custInfo = new CustInfo();
                custInfo.setCustId(issue.getOwnerId().toString());
                bankSvcRq.setCustInfo(custInfo);

                RequestInfo requestInfo = new RequestInfo();
                requestInfo.setRequestId(requestId.toString());
                RequestStatus requestStatus = new RequestStatus();
                requestStatus.setStatusCode("CLIENT_CONTINUE");
                requestInfo.setRequestStatus(requestStatus);
                bankSvcRq.setRequestInfo(requestInfo);
                requestModNf.setBankSvcRq(bankSvcRq);
                requestModNf.setServerInfo(serverInfoType);
                String xml = xmlUnmarshaler.createXml(requestModNf);
                log.info("start send xml "+xml+"to kafka topic dbo.loanissuestatus.continue");
                kafkaTemplate.send("dbo.loanissuestatus.continue", xml);
                log.info("end send xml "+xml+"to kafka topic dbo.loanissuestatus.continue");
            }
            String newStatus = null;
            String loanLimit = null;
            String loanTerm = null;
            String interestRate = null;
            String monthlyPayment = null;
            boolean signing = false;
            for(int i=0;i<ncpkTimeOut;i++){
                Thread.sleep(milis);
                log.info("Start signing " + requestId + " , iteration " + i);
                Map<String, Object> dbIssue = issueOperations.getStatusInfo(requestId);
                if (!dbIssue.isEmpty()) {
                    newStatus = (String) dbIssue.get("STATUSSYSNAME");
                    loanLimit = (String) dbIssue.get("LOANLIMIT");
                    loanTerm = (String) dbIssue.get("LOANTERM");
                    interestRate = (String) dbIssue.get("INTERESTRATE");
                    monthlyPayment = (String) dbIssue.get("MONTHLYPAYMENT");
                    log.info("Start signing " + requestId + " , iteration " + i+" , statusSysName "+newStatus);
                    if (!StringUtils.isEmpty(newStatus) && newStatus.equalsIgnoreCase(LoanStates.SIGNING.getStatusSysName())) {
                        signing = true;
                        break;
                    }
                }
            }
            if (newStatus != null) {
                if (Boolean.TRUE.equals(signing)) {
                    signing(issue, loanLimit, loanTerm, interestRate, monthlyPayment, res, rqUid);
                } else if (newStatus.equalsIgnoreCase(LoanStates.WAITING_CLIENT_InDBO.getStatusSysName())) {
                    res.createError(1004, "Документы придут в течение нескольких минут", 406, null, null, "presignissue", rqUid);
                } else if (newStatus.equalsIgnoreCase(LoanStates.APPROVED.getStatusSysName()) || newStatus.equalsIgnoreCase(LoanStates.SCORING.getStatusSysName())) {
                    res.createError(1004, "Заявка на рассмотрении. Документы придут в течение нескольких минут", 406, null, null, "presignissue", rqUid);
                } else if (newStatus.equalsIgnoreCase(LoanStates.WAITING_CLIENT_InDO.getStatusSysName())){
                    res.createError(1032, "Для оформления заявки необходимо обратиться в ДО", 409, null, null, "presignissue", rqUid);
                } else if (newStatus.equalsIgnoreCase(LoanStates.BANK_REFUSE.getStatusSysName())){
                    res.createError(1031, "Заявка отклонена", 409, null, null, "presignissue", rqUid);
                } else {
                    res.createError(1002, "Заявка отменена", 409, null, null, "presignissue", rqUid);
                }
            } else {
                res.createError(501, "Сервис временно недоступен",400, null, null, "presignissue", rqUid);
            }
        } catch (InterruptedException e) {
            log.error("Error in presign issue v2 {}", Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен",400, null, null, "presignissue", rqUid);
            Thread.currentThread().interrupt();
            e.printStackTrace();
        } finally {
            issueOperations.updateSendForSign(0, issue.getIssueId());
        }
    }

}
