package ru.mtsbank.integration.dbo.loan.issue.builders;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.ClientData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.CreditData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.EmploymentData;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.PassportData;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.IssueAttribute;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class SaveIssueAttributeBuilder {

    public List<IssueAttribute> build(CreateIssueReq req, Long issueId){
        List<IssueAttribute> attrs = new ArrayList<>();
        PassportData passportData = req.getPassportData();
        if (passportData != null) {
            Map<String, String> passportMap = passportData.toMap();
            setAttrs(attrs, passportMap, issueId);
        }
        EmploymentData employmentData = req.getEmploymentData();
        if (employmentData != null) {
            Map<String, String> employmentMap = employmentData.toMap();
            setAttrs(attrs, employmentMap, issueId);
        }
        CreditData creditData = req.getCreditData();
        if (creditData != null) {
            Map<String, String> crediMap = creditData.toMap();
            setAttrs(attrs, crediMap, issueId);
        }
        ClientData clientData = req.getClientData();
        if (clientData != null) {
            Map<String, String> clientMap = clientData.toMap();
            setAttrs(attrs, clientMap, issueId);
        }
        return attrs;
    }

    private void setAttrs(List<IssueAttribute> attrs, Map<String, String> map, Long issueId){
        if (!map.isEmpty()){
            for(Map.Entry<String,String> entry : map.entrySet()){
                attrs.add(new IssueAttribute(issueId, entry.getKey(), entry.getValue()));
            }
        }
    }

}
