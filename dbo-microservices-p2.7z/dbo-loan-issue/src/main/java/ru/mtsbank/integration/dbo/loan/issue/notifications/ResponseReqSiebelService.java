package ru.mtsbank.integration.dbo.loan.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.mts.xsd.SITE.res.MtsSingleResponse;
import ru.mts.dbo.utils.Utils;

@Component("dbo.issue.response")
@Slf4j
public class ResponseReqSiebelService implements NotificationService {

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start consuming RESPONSE_REQ_SIEBEL with [{}]", xmlRequest);
        MtsSingleResponse req = xmlUnmarshaler.parse(MtsSingleResponse.class, xmlRequest);
        if (req != null
                && !Utils.isEmpty(req.getMtsRequestId())
                && !Utils.isEmpty(req.getRequestId())
                && Utils.isDigits(req.getRequestId()))
        {
            Long issueId = getIssueId(req.getMtsRequestId());
            if (issueId != null) {
                Issues issue = issuesRepository.findByIssueId(issueId);
                if (issue != null){
                    issue.setRequestId(Long.valueOf(req.getRequestId()));
                    issuesRepository.save(issue);
                }
            }
        }
        log.info("End consuming RESPONSE_REQ_SIEBEL");
    }

    private Long getIssueId(String val){
        val = val.toUpperCase();
        val = val.replaceAll("IOS-", "").replaceAll("ANDROID-","").replaceAll("ANDR-","");
        if (Utils.isDigits(val))
            return Long.valueOf(val);
        return null;
    }

}
