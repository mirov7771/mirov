package ru.mtsbank.integration.dbo.loan.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.OffersRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Insurances;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Offers;
import ru.mtsbank.integration.mts.xsd.Agreement.AgreementRq;
import ru.mtsbank.integration.mts.xsd.Agreement.CreditDecision;
import ru.mtsbank.integration.mts.xsd.Agreement.InsuranceInfoType;

import java.util.ArrayList;
import java.util.List;

@Component("dbo.loanissueagreements")
@Slf4j
public class AgreementRqService implements NotificationService {

    @Autowired
    private OffersRepository offersRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private IssuesRepository issuesRepository;

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start consuming AGREEMENT_RQ");
        AgreementRq rq = xmlUnmarshaler.parse(AgreementRq.class, xmlRequest);
        if (rq != null
                && rq.getRequestId() != null
                && rq.getCreditDecisions() != null
                && !CollectionUtils.isEmpty(rq.getCreditDecisions().getCreditDecision()))
        {
            Long requestId = rq.getRequestId().longValue();
            Issues issue = issuesRepository.findByRequestId(requestId);
            if (issue != null) {
                List<CreditDecision> creditDecisionList = rq.getCreditDecisions().getCreditDecision();

                for(CreditDecision item : creditDecisionList) {
                    Offers offer = new Offers();
                    String decisionId = item.getDecisionId();
                    offer.setDecisionId(decisionId);
                    offer.setRequestId(requestId);
                    offer.setCreditSum(item.getCreditSum());
                    offer.setCreditMinSum(item.getCreditMinSum());
                    offer.setRate(item.getRate());
                    offer.setCreditPeriod(item.getCreditPeriod());
                    offer.setMonthlyPayment(item.getMonthlyPayment());
                    offer.setDecisionMode(item.getTimeIntervalDecision());
                    offer.setProductCode(item.getProductCode());
                    offer.setProductName(item.getProductName());
                    offer.setPossIssueDbo(item.isPossIssueDBO() ? 1 : 0);

                    if (item.getInsuranceInfo() != null && !CollectionUtils.isEmpty(item.getInsuranceInfo().getInsuranceInfoItem())) {
                        List<Insurances> insurancesList = new ArrayList<>();
                        for (InsuranceInfoType.InsuranceInfoItem inItem : item.getInsuranceInfo().getInsuranceInfoItem()) {
                            Insurances insurance = new Insurances();
                            insurance.setDecisionId(decisionId);
                            insurance.setRequestId(requestId);
                            insurance.setProgramCode(inItem.getInsuranceProgrammCode().toString());
                            insurance.setPremiumAmount(inItem.getPremiumAmount());
                            insurance.setInsurancePercent(inItem.getInsurancePercent());
                            insurance.setInsuranceType(inItem.getInsuranceType());
                            insurancesList.add(insurance);
                        }
                        offer.setInsurancesList(insurancesList);
                    }
                    offersRepository.save(offer);
                }
                issue.setStatus(LoanStates.SELECTION.getStatus());
                issue.setStatusSysName(LoanStates.SELECTION.getStatusSysName());
                issuesRepository.save(issue);
            }
        }
        log.info("End consuming AGREEMENT_RQ");
    }
}
