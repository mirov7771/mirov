package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

@Getter
public class LoanIssueListReq extends BaseRequest {

    @JsonProperty("phoneNumber")
    private String phoneNumber;

}
