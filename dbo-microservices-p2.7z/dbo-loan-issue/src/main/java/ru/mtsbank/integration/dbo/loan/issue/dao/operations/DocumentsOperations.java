package ru.mtsbank.integration.dbo.loan.issue.dao.operations;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DocumentsOperations {

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public DocumentsOperations(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    public void delete(Long requestId){
        String delOper = "DELETE FROM DOCUMENTS WHERE REQUESTID = ?";
        try{
            jdbcTemplate.update(delOper, requestId);
        } catch (DataAccessException e){
            log.error("Error: "+e);
            e.printStackTrace();
        }
    }

}
