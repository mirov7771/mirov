package ru.mtsbank.integration.dbo.loan.issue.dao.operations;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.IssueAttribute;

import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class IssueOperations {

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public IssueOperations(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    public Map<String, Object> getStatusInfo(Long requestId){
        String select = "SELECT STATUSCODE,STATUSCODECOMMENT,STATUSDATE,STATUSSYSNAME,LOANLIMIT,LOANTERM,INTERESTRATE,MONTHLYPAYMENT FROM ISSUES WHERE REQUESTID = ?";
        return jdbcTemplate.queryForMap(select, requestId);
    }

    public void deleteAttributes(Long requestId){
        String delete = "DELETE FROM ISSUEATTRIBUTE WHERE ISSUEID = ?";
        jdbcTemplate.update(delete, requestId);
    }

    public void updateSendForSign(int type, Long issueId){
        String update = "UPDATE ISSUES SET SENDFORSIGN = ? WHERE ISSUEID = ?";
        jdbcTemplate.update(update, type, issueId);
    }

    public void deleteIssue(Long requestId){
        String deleteIssue = "SELECT DELETECLIENTISSUE("+requestId+")";
        jdbcTemplate.queryForObject(deleteIssue,Integer.class);
    }

    public List<IssueAttribute> findByIssueId(Long issueId){
        String select = "SELECT ATTRIBUTEID,ISSUEID,ATTRNAME,ATTRVALUE FROM ISSUEATTRIBUTE WHERE ISSUEID = "+issueId;
        return jdbcTemplate.query(select, new BeanPropertyRowMapper(IssueAttribute.class));
    }

    public Boolean findStatusCardReply(Long issueId){
        String select = "SELECT DETAILSTATE FROM CHECKISSUE WHERE ISSUEID = ?";

        String detail = jdbcTemplate.query(select
                , new Object[] {issueId}
                , rs -> rs.next() ? rs.getString("DETAILSTATE") : "NULL");

        log.info("GET DETAILS FOR ISSUEID "+issueId+" VALUE "+detail);
        return "REQUEST_NOT_FOUND".equalsIgnoreCase(detail);
    }

    public Boolean isWaitingClientInDbo(Long issueId){
        String select = "SELECT STATUSSYSNAME FROM ISSUES WHERE ISSUEID = ?";

        String state = jdbcTemplate.query(select
                , new Object[] {issueId}
                , rs -> rs.next() ? rs.getString("STATUSSYSNAME") : "NULL");

        log.info("GET STATE FOR ISSUEID "+issueId+" VALUE "+state);
        return "WAITING_CLIENT.InDBO".equalsIgnoreCase(state);
    }

    public Long getRequestIdByIssueId(Long issueId){
        String select = "SELECT REQUESTID FROM ISSUES WHERE ISSUEID = ?";
        return jdbcTemplate.query(select
                , new Object[] {issueId}
                , rs -> rs.next() ? rs.getLong("REQUESTID") : null);
    }

}
