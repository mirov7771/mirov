package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "CHECKISSUE")
@Getter @Setter
public class CheckIssue implements Serializable {

    private static final long serialVersionUID = 7071228906950664946L;

    @Id
    @Column(name = "ISSUEID")
    private Long issueId;
    @Column(name = "DETAILSTATE")
    private String detailState;

    public CheckIssue(){

    }

    public CheckIssue(Long issueId, String detailState){
        this.issueId = issueId;
        this.detailState = detailState;
    }

}