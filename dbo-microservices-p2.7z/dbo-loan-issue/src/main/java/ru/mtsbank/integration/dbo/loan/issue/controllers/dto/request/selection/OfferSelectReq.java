package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
public class OfferSelectReq extends BaseRequest {

    @JsonProperty("decisionId")
    @NotNull
    private String decisionId;
    @JsonProperty("payDay")
    @NotNull
    private Integer payDay;
    @JsonProperty("amount")
    @NotNull
    private BigDecimal amount;
    @JsonProperty("requestId")
    @NotNull
    private Long requestId;

}
