package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseRequest;

@Getter @Setter
public class OfferListReq extends BaseRequest {

    @JsonProperty("requestId")
    private Long requestId;

}
