package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.info;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueDocListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.info.LoanIssueDocListRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Doc;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Component("loanissuedoclist")
@Slf4j
public class LoanIssueDocListMethod {

    @Autowired
    public DocumentsRepository documentsRepository;

    public LoanIssueDocListRes call(LoanIssueDocListReq req) {
        log.info("Start loanissuedoclist service");
        LoanIssueDocListRes res = new LoanIssueDocListRes();
        List<Documents> documentsList;
        if (!Utils.isEmpty(req.getAgreeNum())){
            documentsList = documentsRepository.findByOwnerIdAndAgreeNum(req.getRboID(), req.getAgreeNum());
        } else {
            documentsList = documentsRepository.findByOwnerId(req.getRboID());
        }
        if (!CollectionUtils.isEmpty(documentsList)){
            List<Doc> docs = new ArrayList<>();
            for(Documents dbItem : documentsList){
                Doc doc = new Doc();
                doc.setDocId(dbItem.getDocumentId());
                doc.setDocName(dbItem.getDocName());
                doc.setDocTypeSysName(dbItem.getDocTypeSysName());
                doc.setAgreeNum(dbItem.getAgreeNum());
                doc.setDocSize(getFileSize(dbItem.getDocData()));
                docs.add(doc);
            }
            res.setDocList(docs);
        } else {
            res.createError(1002, String.format("Не найдены документы по клиенту с ID %s",req.getRboID()),406, null, null, "loanissuedoclist", null);
        }
        log.info("End loanissuedoclist service");
        return res;
    }

    private Float getFileSize(String value){
        if (!Utils.isEmpty(value)) {
            byte[] decode = Base64.getDecoder().decode(value);
            return (float) ((double) decode.length / (1024 * 1024));
        }
        return 0F;
    }

}
