package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import lombok.ToString;

@Setter
@ToString
public class CreditParam {

    @JsonProperty("min")
    private Long min;
    @JsonProperty("max")
    private Long max;

}
