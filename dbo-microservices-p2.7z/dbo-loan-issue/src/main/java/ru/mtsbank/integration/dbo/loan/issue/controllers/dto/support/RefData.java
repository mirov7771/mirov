package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@Getter @Setter
@ToString
public class RefData {

    @JsonProperty("value")
    private String value;
    @JsonProperty("name")
    private String name;

    public Map<String, String> toMap(){
        Map<String, String> map = new HashMap<>();
        map.put("value",value);
        map.put("name",name);
        return map;
    }

    @JsonIgnore
    public boolean isEmpty(){
        return value == null;
    }

}
