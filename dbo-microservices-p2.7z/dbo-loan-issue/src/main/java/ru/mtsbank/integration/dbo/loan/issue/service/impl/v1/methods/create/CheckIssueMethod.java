package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CheckIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.CheckIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;

import java.util.List;

@Component("checkissue")
@Slf4j
public class CheckIssueMethod {

    @Autowired
    private IssuesRepository issuesRepository;

    public CheckIssueRes call(CheckIssueReq req) {
        log.info("Start checkissue service with params [rboId: {}]",req.getRboID());
        CheckIssueRes res = new CheckIssueRes();
        Long rboId = req.getRboID();
        if (rboId == null){
            res.createError(1060, "Не передан индентификатор клиента", 400, null, "Не передан обязательный параметр rboId", "checkissue", null);
        } else {
            List<Issues> inputIssues = issuesRepository.findByOwnerIdAndStatusSysName(rboId, LoanStates.INPUT.getStatusSysName());
            if (!CollectionUtils.isEmpty(inputIssues)) {
                res.createError(1018, "У вас есть активная заявка на кредит. Дождитесь решения и завершите оформление", 409, null, null, "checkissue", null);
            } else {
                List<Issues> issues = issuesRepository.findByOwnerIdAndStatusSysName(req.getRboID(), LoanStates.PRE_INPUT.getStatusSysName());
                if (!CollectionUtils.isEmpty(issues)) {
                    res.setIssueId(issues.get(0).getIssueId());
                }
            }
        }
        log.info("End checkissue service");
        return res;
    }

}
