package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.signing;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.SignIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.loan.issue.builders.DocListAddRsBuilder;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.SignIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.operations.IssueOperations;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.CustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.DocListAddRs.DocListAddRs;
import ru.mtsbank.integration.mts.xsd.RequestStatusModRq.*;

import java.io.IOException;
import java.util.*;

import static ru.mts.dbo.utils.Utils.*;

@Component("signissue")
@Slf4j
public class SignIssueMethod {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private DocumentsRepository documentsRepository;

    @Autowired
    private DocListAddRsBuilder docListAddRsBuilder;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private IssueOperations issueOperations;

    public SignIssueRes call(SignIssueReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start signissue service with params {}", uid, req.toString());
        SignIssueRes res = new SignIssueRes();
        Long requestId = req.getRequestId();
        Issues issue = issuesRepository.findByRequestId(requestId);
        Integer isDocSend = 0;
        if (issue == null){
            res.createError(1002, String.format("Не найдена заявка с ID %s",requestId),406, null, null, "signissue", uid);
        } else {
            isDocSend = nvl(issue.getIsDocSend(),0);
            String currentStatusCode = issue.getStatusCode();
            if (!StringUtils.isEmpty(currentStatusCode) && currentStatusCode.equals("0")) {
                prepareAnswer(res, currentStatusCode, uid);
            } else if (req.getCode() == null && isDocSend.equals(0)) {
                DocListAddRs docListAddRs = docListAddRsBuilder.docListAddRs(requestId);
                String xml = xmlUnmarshaler.createXml(docListAddRs);
                log.info("{} start send xml {} to kafka topic dbo.loanissuedocs.result", uid, xml);
                kafkaTemplate.send("dbo.loanissuedocs.result", xml);
                log.info("{} end send xml {} to kafka topic dbo.loanissuedocs.result", uid, xml);
                issue.setIsDocSend(1);
                issuesRepository.save(issue);
                res.setRequestId(requestId.toString());
            } else {
                signIssue(res, issue, requestId, req, issue.getStatusDate(), uid);
            }
        }
        log.info("{} End signissue service", uid);
        if (res.getErrorResponse() == null
                && res.getInDO() == null
                && res.getResult() == null
                && req.getCode() != null
                && !isDocSend.equals(0))
        {
            res.createError(1072, "Не получен ответ по СМС", 408, null, null, "signissue", uid);
        }
        return res;
    }

    private void prepareAnswer(SignIssueRes res, String sc, String uid){
        res.setResult(true);
        switch (sc) {
            case "1":
            case "7":
                res.createError(1000, "Введенный пользователем код неверный", 406, null, null, "signissue", uid);
                break;
            case "2":
            case "5":
            case "6":
            case "8":
            case "9":
                res.setResult(false);
                break;
            case "3":
            case "4":
            case "10":
                res.setResult(true);
                res.setInDO(true);
                break;
            case "12":
                res.createError(1073, "Подписываемая документация не совпадает с отправленной", 406, null, null, "signissue", uid);
                break;
        }
    }

    private void signIssue(SignIssueRes res, Issues issue, Long requestId, SignIssueReq req, Date statusDate, String uid){
        try {
            String code = req.getCode();
            String statusCode = "ASP_REQUEST_NEW_CODE";

            List<Documents> documentsList = documentsRepository.findByRequestId(requestId);

            RequestStatusModRq rq = new RequestStatusModRq();

            ServerInfoType serverInfoType = new ServerInfoType();
            serverInfoType.setMsgUID(UUID.randomUUID().toString());
            serverInfoType.setRqUID(requestId.toString());
            serverInfoType.setSPName("MTS_EIP_UMP");
            serverInfoType.setMsgReceiver("SIEBEL");
            serverInfoType.setServerDt(getXmlGregorianCalendar(new Date()));
            serverInfoType.setMsgType("RequestStatusModRq");
            rq.setServerInfo(serverInfoType);

            BankSvcRq bankSvcRq = new BankSvcRq();
            RequestInfo requestInfo = new RequestInfo();
            requestInfo.setRequestId(requestId.toString());
            if (!StringUtils.isEmpty(code)) {
                requestInfo.setEDSCode(req.getCode());
                statusCode = "ASP_SIGNED_BY_CLIENT";
            }
            RequestStatus requestStatus = new RequestStatus();
            requestStatus.setStatusCode(statusCode);
            DateTime dateTime = new DateTime();
            Date currentDate = new Date();
            GregorianCalendar gc = new GregorianCalendar();
            gc.setTime(currentDate);
            dateTime.setDay(gc.get(Calendar.DAY_OF_MONTH));
            dateTime.setMonth(gc.get(Calendar.MONTH) == Calendar.JANUARY ? 12 : gc.get(Calendar.MONTH));
            dateTime.setYear(gc.get(Calendar.YEAR));
            dateTime.setHour(gc.get(Calendar.HOUR_OF_DAY));
            dateTime.setMinute(gc.get(Calendar.MINUTE));
            dateTime.setSecond(gc.get(Calendar.SECOND));
            requestStatus.setEffDt(dateTime);
            requestInfo.setRequestStatus(requestStatus);
            requestInfo.setPhone(getPhoneNumber(issue.getOwnerId().toString(), uid));
            bankSvcRq.setRequestInfo(requestInfo);

            DocList docList = new DocList();
            if (!CollectionUtils.isEmpty(documentsList)) {
                for (Documents dbItem : documentsList) {
                    DocRec docRec = new DocRec();
                    docRec.setDocTypeName(dbItem.getDocTypeSysName());
                    docRec.setOrigName(dbItem.getDocName());
                    docRec.setHashDoc(updateStringInSHA(dbItem.getDocData().getBytes()));
                    docList.getDocRec().add(docRec);
                }
            }
            bankSvcRq.setDocList(docList);
            rq.setBankSvcRq(bankSvcRq);
            String requestStatusModRq = xmlUnmarshaler.createXml(rq);
            log.info("{} start send xml {} to kafka topic dbo.loanissuestatus.change", uid, requestStatusModRq);
            kafkaTemplate.send("dbo.loanissuestatus.change", requestStatusModRq);
            log.info("{} end send xml {} to kafka topic dbo.loanissuestatus.change", uid, requestStatusModRq);

            int ncpkTimeOut = 150*2;
            for (int i = 0; i < ncpkTimeOut; i++) {
                Thread.sleep(250);
                Map<String, Object> dbIssue = issueOperations.getStatusInfo(requestId);
                if (!dbIssue.isEmpty()) {
                    String dbSc = (String) dbIssue.get("STATUSCODE");
                    Date dbStatuDate = (Date) dbIssue.get("STATUSDATE");
                    if (!StringUtils.isEmpty(dbSc) && dbStatuDate != null && !dbStatuDate.equals(statusDate)) {
                        prepareAnswer(res, dbSc, requestId.toString());
                        break;
                    }
                }
                log.info("{} ISSUE APPLICATION IN DB IS {}", uid, dbIssue.toString());
            }
        } catch (InterruptedException | IOException e) {
            log.error("{} Error in sign issue {}", uid, Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен", 400, null, null, "signissue", requestId.toString());
            Thread.currentThread().interrupt();
        }
    }

    private String getPhoneNumber(String custId, String uid) throws IOException {
        String phoneNumber = null;
        String custSearchXml = xmlUnmarshaler.createXml(custSearchInqRqBuilder.createCustSearchInqRq(custId, uid));
        String custSearchAnswerXml = esbGate.sendSalesMessageWithAnswer(custSearchXml);
        CustSearchInqRs custSearchInqRs = xmlUnmarshaler.parse(CustSearchInqRs.class, custSearchAnswerXml);
        if (custSearchInqRs != null
                && custSearchInqRs.getBankSvcRs() != null
                && custSearchInqRs.getBankSvcRs().getCustInfo() != null
                && custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo() != null)
        {
            List<ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FDXPhoneNum> phoneNumsList = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getContactInfo().getPhoneNum();
            if (phoneNumsList != null && phoneNumsList.size() > 0) {
                for (ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FDXPhoneNum fdxPhoneNum : phoneNumsList) {
                    if (fdxPhoneNum.isPrimary()
                            && fdxPhoneNum.getPhoneType().equals("Mobile")){
                        phoneNumber = fdxPhoneNum.getPhone();
                        break;
                    }
                }
            }
        }
        if (phoneNumber == null || phoneNumber.equalsIgnoreCase(""))
            return "";
        return phoneNumber.replace("+7", "");
    }
}
