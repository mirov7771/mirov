package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ISSUEATTRIBUTE")
@Getter @Setter
public class IssueAttribute implements Serializable {

    private static final long serialVersionUID = 1137599918466355394L;

    @Id
    @Column(name = "ATTRIBUTEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attributeId;
    @Column(name = "ISSUEID")
    private Long issueId;
    @Column(name = "ATTRNAME")
    private String attrName;
    @Column(name = "ATTRVALUE")
    private String attrValue;

    public IssueAttribute(){

    }

    public IssueAttribute(Long issueId, String attrName, String attrValue){
        this.issueId = issueId;
        this.attrName = attrName;
        this.attrValue = attrValue;
    }

}
