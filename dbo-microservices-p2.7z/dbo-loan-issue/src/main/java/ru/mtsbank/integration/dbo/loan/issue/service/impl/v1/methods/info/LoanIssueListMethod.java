package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.info;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.info.LoanIssueListRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Issue;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;

import java.util.*;

import static ru.mts.dbo.utils.Utils.nvl;

@Component("loanissuelist")
@Slf4j
public class LoanIssueListMethod {

    private static final Set<String> STATES = new HashSet<>();
    static {
        STATES.add("WAITING_CLIENT.InDO");
        STATES.add("WAITING_CLIENT.InDBO");
        STATES.add("NEW");
        STATES.add("PREAPPROVED");
        STATES.add("APPROVED");
        STATES.add("SCORING");
        STATES.add("SELECTION");
        STATES.add("SIGNING");
    }

    @Autowired
    private IssuesRepository issuesRepository;

    public LoanIssueListRes call(LoanIssueListReq req) {
        log.info("Start loanissuelist service with params [rboId: {}, phone: {}]",req.getRboID(), req.getPhoneNumber());
        LoanIssueListRes res = new LoanIssueListRes();
        List<Issues> issuesList = new ArrayList<>();
        if (req.getRboID() != null)
            issuesList = issuesRepository.findByOwnerId(req.getRboID());
        else if (req.getPhoneNumber() != null)
            issuesList = issuesRepository.findByOwnerPhone(req.getPhoneNumber());
        List<Issue> issues = new ArrayList<>();
        Date currentDate = new Date();
        if (!CollectionUtils.isEmpty(issuesList)){
            for(Issues dbItem : issuesList){
                String statusSysName = dbItem.getStatusSysName();
                Date updateDate = nvl(dbItem.getUpdateDate(), new Date());
                if (STATES.contains(statusSysName) && dateDiff(currentDate,updateDate) < 30) {
                    Issue issue = new Issue();
                    issue.setIssueId(dbItem.getIssueId());
                    issue.setAmount(dbItem.getAmount());
                    issue.setIssueDate(dbItem.getIssueDate());
                    issue.setRboId(dbItem.getOwnerId());
                    issue.setRequestId(dbItem.getRequestId());
                    issue.setStatus(dbItem.getStatus());
                    issue.setStatusSysName(dbItem.getStatusSysName());
                    if (statusSysName.equalsIgnoreCase("WAITING_CLIENT.InDBO"))
                        issue.setShowPromo(checkPromo(dbItem,currentDate));
                    issues.add(issue);
                } /*else if ("BANK_REFUSE".equalsIgnoreCase(statusSysName) && dateDiff(dbItem.getIssueDate(),currentDate) == 0){
                    Issue issue = new Issue();
                    issue.setIssueId(dbItem.getIssueId());
                    issue.setAmount(dbItem.getAmount());
                    issue.setIssueDate(dbItem.getIssueDate());
                    issue.setRboId(dbItem.getOwnerId());
                    issue.setRequestId(dbItem.getRequestId());
                    issue.setStatus(dbItem.getStatus());
                    issue.setStatusSysName(dbItem.getStatusSysName());
                    issues.add(issue);
                }*/
            }
        } else {
            res.createError(1002, String.format("Не найдены заявки по клиенту с ID %s",req.getRboID()),406, null, null, "loanissuelist", null);
        }
        if (!CollectionUtils.isEmpty(issues)) {
            res.setIssueList(issues);
        } else {
            res.createError(1002, String.format("Не найдены заявки по клиенту с ID %s в нужных статусах",req.getRboID()),406, null, null, "loanissuelist", null);
        }
        log.info("End loanissuelist service");
        return res;
    }

    private Boolean checkPromo(Issues dbItem,Date currentDate) {
        Date issueDate = dbItem.getIssueDate();
        int isShow = nvl(dbItem.getIsShow(),0);
        long dayDiff = (issueDate.getTime() - currentDate.getTime())/(24 * 60 * 60 * 1000);
        if (dayDiff == 0 || dayDiff == 4 || dayDiff == 9){
            if (isShow == 0) {
                dbItem.setIsShow(1);
                issuesRepository.save(dbItem);
                return true;
            } else {
                return false;
            }
        } else {
            if (isShow == 1) {
                dbItem.setIsShow(0);
                issuesRepository.save(dbItem);
            }
            return false;
        }
    }

    private long dateDiff(Date checkDate, Date currentDate){
        return (checkDate.getTime() - currentDate.getTime())/(24 * 60 * 60 * 1000);
    }

}
