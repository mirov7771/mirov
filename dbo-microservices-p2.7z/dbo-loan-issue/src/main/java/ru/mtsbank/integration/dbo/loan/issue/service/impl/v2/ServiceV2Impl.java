package ru.mtsbank.integration.dbo.loan.issue.service.impl.v2;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.*;
import ru.mtsbank.integration.dbo.loan.issue.service.Service;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v2.methods.create.CreateShortIssueMethodV2;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v2.methods.signing.PreSignIssueMethodV2;

@RequiredArgsConstructor
@Component("v2")
public class ServiceV2Impl implements Service {

    private final PreSignIssueMethodV2 preSignIssueMethod;
    private final CreateShortIssueMethodV2 createShortIssueMethod;

    @Override
    public BaseResponse preSignIssue(PreSignIssueReq req) {
        return preSignIssueMethod.call(req);
    }

    @Override
    public BaseResponse createShortIssue(CreateIssueReq req) {
        return createShortIssueMethod.call(req);
    }

}
