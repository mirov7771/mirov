package ru.mtsbank.integration.dbo.loan.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.loan.issue.dao.CheckIssueRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.CheckIssue;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.mts.xsd.StatusReqReply.StatusReqReplyM;

@Component("dbo.status.reply")
@Slf4j
public class StatusReqReplyMService implements NotificationService {

    @Autowired
    private CheckIssueRepository checkIssueRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private IssuesRepository issuesRepository;

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start consuming STATUS_REQ_REPLY_M");
        StatusReqReplyM rq = xmlUnmarshaler.parse(StatusReqReplyM.class, xmlRequest);
        if (rq != null && rq.getMtsRequestId() != 0 && rq.getDetailState() != null){
            String state = rq.getDetailState();
            Long issueId = rq.getMtsRequestId();
            checkIssueRepository.save(new CheckIssue(issueId, state));
            if (!"REQUEST_NOT_FOUND".equalsIgnoreCase(state)){
                Issues issue = issuesRepository.findByIssueId(issueId);
                issue.setStatus(LoanStates.BANK_REFUSE.getStatus());
                issue.setStatusSysName(LoanStates.BANK_REFUSE.getStatusSysName());
            }
        }
        log.info("End consuming STATUS_REQ_REPLY_M");
    }
}