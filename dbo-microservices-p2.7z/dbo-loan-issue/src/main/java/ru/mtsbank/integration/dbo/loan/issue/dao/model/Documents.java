package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "DOCUMENTS")
@Getter @Setter
public class Documents implements Serializable {

    private static final long serialVersionUID = -7842713082670468730L;

    @Id
    @Column(name = "DOCUMENTID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;
    @Column(name = "ISSUEID")
    private Long issueId;
    @Column(name = "REQUESTID")
    private Long requestId;
    @Column(name = "OWNERID")
    private Long ownerId;
    @Column(name = "DOCNAME")
    private String docName;
    @Column(name = "DOCTYPESYSNAME")
    private String docTypeSysName;
    @Column(name = "DOCDATA")
    private String docData;
    @Column(name = "AGREENUM")
    private String agreeNum;

}
