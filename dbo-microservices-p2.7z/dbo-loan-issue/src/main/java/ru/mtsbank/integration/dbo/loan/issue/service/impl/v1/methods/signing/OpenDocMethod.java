package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.signing;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.OpenDocReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.OpenDocRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;

@Component("opendoc")
@Slf4j
public class OpenDocMethod {

    @Autowired
    private DocumentsRepository documentsRepository;

    public OpenDocRes call(OpenDocReq req) {
        log.info("Start opendoc service");
        OpenDocRes res = new OpenDocRes();
        Long docId = req.getDocId();
        Documents doc = null;
        if (docId != null) {
            log.info("Search doc by docid "+docId);
            doc = documentsRepository.findByDocumentId(docId);
        } else if (!StringUtils.isEmpty(!StringUtils.isEmpty(req.getAgreeNum()) && !StringUtils.isEmpty(req.getDocTypeSysName()))){
            log.info("Search doc by agreenum "+req.getAgreeNum()+" and type "+req.getDocTypeSysName());
            doc = documentsRepository.findByAgreeNumAndDocTypeSysName(req.getAgreeNum(), req.getDocTypeSysName());
        }
        if (doc != null){
            String pdf = doc.getDocData();
            if (!StringUtils.isEmpty(pdf)) {
                res.setDocData(pdf);
            }
        } else {
            res.createError(100, String.format("Документ с ID %s не существует",docId), 406, null, null, "opendoc", null);
        }
        log.info("End opendoc service");
        return res;
    }

}
