package ru.mtsbank.integration.dbo.loan.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;

import java.util.List;

@Repository
public interface IssuesRepository extends CrudRepository<Issues, String> {

    List<Issues> findByOwnerId(Long ownerId);
    List<Issues> findByOwnerIdAndStatusSysName(Long ownerId, String statusSysName);
    Issues findByRequestId(Long requestId);
    Issues findByRequestIdAndStatusSysName(Long requestId, String statusSysName);
    Issues findByIssueId(Long issueId);
    Issues findByIssueIdAndStatusSysName(Long issueId, String statusSysName);
    List<Issues> findByOwnerPhone(String ownerPhone);

}
