package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.signing;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.CancelIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.CancelIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.mts.xsd.RequestMod.*;

import java.util.Date;
import java.util.UUID;

@Component("cancelissue")
@Slf4j
public class CancelIssueMethod {

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public CancelIssueRes call(CancelIssueReq req) {
        log.info("Start cancelissue service");
        CancelIssueRes res = new CancelIssueRes();
        Long requestId = req.getRequestId();
        Issues issue = issuesRepository.findByRequestId(requestId);
        String rqUid = UUID.randomUUID().toString();
        if (issue == null) {
            res.createError(1002, String.format("Не найдена заявка с ID %s",requestId),409, null, null, "cancelissue", rqUid);
        } else if (issue.getStatusSysName().equalsIgnoreCase(LoanStates.CLIENT_REFUSE.getStatusSysName())
                || issue.getStatusSysName().equalsIgnoreCase(LoanStates.BANK_REFUSE.getStatusSysName())){
            res.createError(1002, String.format("Заявка с ID %s уже отменена",requestId),409, null, null, "cancelissue", rqUid);
        } else if (issue.getStatusSysName().equalsIgnoreCase(LoanStates.DONE.getStatusSysName())){
            res.createError(1002, String.format("Заявка с ID %s исполнена, отмена не доступна",requestId),409, null, null, "cancelissue", rqUid);
        } else {
            RequestModNf requestModNf = new RequestModNf();
            ServerInfoType serverInfoType = new ServerInfoType();
            serverInfoType.setMsgUID(rqUid);
            serverInfoType.setRqUID(rqUid);
            serverInfoType.setSPName("MTS_EIP_UMP");
            serverInfoType.setMsgReceiver("SIEBEL");
            serverInfoType.setServerDt(Utils.getXmlGregorianCalendar(new Date()));
            serverInfoType.setMsgType("RequestModNf");
            requestModNf.setServerInfo(serverInfoType);

            BankSvcRq bankSvcRq = new BankSvcRq();
            CustInfo custInfo = new CustInfo();
            custInfo.setCustId(issue.getOwnerId().toString());
            bankSvcRq.setCustInfo(custInfo);

            RequestInfo requestInfo = new RequestInfo();
            requestInfo.setRequestId(requestId.toString());
            RequestStatus requestStatus = new RequestStatus();
            requestStatus.setStatusCode("CLIENT_REFUSE");
            requestInfo.setRequestStatus(requestStatus);
            bankSvcRq.setRequestInfo(requestInfo);
            requestModNf.setBankSvcRq(bankSvcRq);
            requestModNf.setServerInfo(serverInfoType);

            String xml = xmlUnmarshaler.createXml(requestModNf);

            issue.setStatus(LoanStates.CLIENT_REFUSE.getStatus());
            issue.setStatusSysName(LoanStates.CLIENT_REFUSE.getStatusSysName());
            issuesRepository.save(issue);

            log.info("start send xml "+xml+"to kafka topic dbo.loanissuestatus.continue");
            kafkaTemplate.send("dbo.loanissuestatus.continue", xml);
            log.info("end send xml "+xml+"to kafka topic dbo.loanissuestatus.continue");
            res.setRequestId(rqUid);
        }
        log.info("End cancelissue service");
        return res;
    }



}
