package ru.mtsbank.integration.dbo.loan.issue.builders;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.enums.ActivityTypes;
import ru.mts.dbo.enums.OkvedItems;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.*;
import ru.mtsbank.integration.mts.xsd.SITE.req.*;
import ru.mtsbank.integration.mts.xsd.SITE.req.ClientData;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.isEmpty;
import static ru.mts.dbo.utils.Utils.nvl;

@Component
public class RegisterRegSiteBuilder {

    public MtsSingleRequest build(CreateIssueReq req, String requestId, String uid){
        XMLGregorianCalendar curDate = Utils.getXmlGregorianCalendar(new Date());
        MtsSingleRequest mtsRequest = new MtsSingleRequest();
        mtsRequest.setMtsRequestId(requestId);
        mtsRequest.setMessageId(uid);
        mtsRequest.setMessageType(MessageType.REGISTER_REQ_SITE);
        mtsRequest.setMessageDateTime(curDate);
        mtsRequest.setSPName(SystemType.MTS_EIP_UMP);
        mtsRequest.setMsgReceiver(SystemType.SIEBEL);
        String issueType = "FULL";

        mtsRequest.setRequestContinType("CC");

        MtsSingleRequest.Request request = new MtsSingleRequest.Request();
        ClientData client = new ClientData();
        ClientRequestData clientRequest = new ClientRequestData();

        ClientCommonDataType clientCommonDataType = new ClientCommonDataType();
        ClientData.ClientListDocument clientListDocument = new ClientData.ClientListDocument();
        ClientData.ClientListAddress clientListAddress = new ClientData.ClientListAddress();
        ClientData.ClientListContact clientListContact = new ClientData.ClientListContact();

        ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.ClientData reqClientData = req.getClientData();
        EmploymentData employmentData = req.getEmploymentData();
        if (reqClientData.getShortForm() != null
                && Boolean.TRUE.equals(reqClientData.getShortForm()))
        {
            issueType =  employmentData == null ? "ULTRA_SHORT" : "NEW_SHORT";
        }
        mtsRequest.setQuestionnaireType(issueType);

        CreditData reqCreditData = req.getCreditData();

        clientCommonDataType.setFamily(reqClientData.getFamily());
        clientCommonDataType.setName(reqClientData.getName());
        clientCommonDataType.setFatherName(reqClientData.getFatherName());

        if (employmentData != null) {
            String startYear = employmentData.getWorkStartYear();
            if (!StringUtils.isEmpty(startYear)) {
                int totalExp;
                GregorianCalendar gc = new GregorianCalendar();
                gc.set(Integer.parseInt(startYear), Calendar.JANUARY, 1);
                double diff = (new Date().getTime()-gc.getTime().getTime())/(60 * 60 * 1000 * 24 * 30.41666666);
                totalExp = (int) diff;
                clientCommonDataType.setTotalExperiance(totalExp);
            }
        }

        PassportData pasportData = req.getPassportData();
        clientCommonDataType.setClientSex(pasportData.getSex().equals(0) ? "Sx1" : "Sx2");
        clientCommonDataType.setBirthPlace(pasportData.getBirthPlace());
        RefData ipdlStatusCode = reqClientData.getIpdlStatusCode();
        if (ipdlStatusCode != null)
            clientCommonDataType.setStatusIPDL(ipdlStatusCode.getValue());
        else
            clientCommonDataType.setStatusIPDL((reqClientData.getPublicFlag() != null && Boolean.TRUE.equals(reqClientData.getPublicFlag())) ? "IPDL.5" : "IPDL.4");

        if (Boolean.TRUE.equals(reqClientData.getBkiFlag())) {
            clientCommonDataType.setFlagAllowPassBKI(true);
            clientCommonDataType.setFlagAllowPassBKIDate(curDate);
        } else {
            clientCommonDataType.setFlagAllowPassBKI(false);
        }
        clientCommonDataType.setFlagAllowReceiveInfoFromBank(Boolean.TRUE.equals(reqClientData.getSmsAgreeFlag()));
        if (Boolean.TRUE.equals(reqClientData.getPersInfoFlag())){
            clientCommonDataType.setFlagAllowPassOthersOrg(true);
            ClientData clientHf = new ClientData();
            clientHf.setClientCommonData(new ClientCommonDataType(){{
                setFlagAllowPassOthersOrg(true);
            }});
            request.setClientHF(clientHf);
        } else {
            clientCommonDataType.setFlagAllowPassOthersOrg(false);
        }
        clientCommonDataType.setCodeWord(reqCreditData.getCodeWord());
        if (Boolean.TRUE.equals(reqClientData.getGatkaFlg()))
            clientCommonDataType.setGatkaFlg(reqClientData.getGatkaFlg());

        if (Boolean.TRUE.equals(reqClientData.getFlagChangeFio())){
            clientCommonDataType.setFlagChangeFIO(true);
            clientCommonDataType.setPrevFamily(reqClientData.getPrevFamily());
            clientCommonDataType.setPrevName(reqClientData.getPrevName());
            clientCommonDataType.setPrevFatherName(reqClientData.getPrevFatherName());
        } else {
            clientCommonDataType.setFlagChangeFIO(false);
        }

        clientCommonDataType.setFlagAllowPassOthersOrg(true);
        if (reqClientData.getTotalIncome() != null){
            Amount totalIncome = new Amount();
            totalIncome.setCurrency("RUB");
            totalIncome.setSumma(reqClientData.getTotalIncome());
            clientCommonDataType.setTotalIncome(totalIncome);
        }

        CountryInfo countryInfo = new CountryInfo();
        countryInfo.setCountryCode("643");
        countryInfo.setCountryName("Россия");
        clientCommonDataType.setCitizenship(countryInfo);

        RefData martialStatus = reqClientData.getMartialStatus();
        if (martialStatus != null)
            clientCommonDataType.setMartialStatus(martialStatus.getValue());
        RefData educationLevel = reqClientData.getEducationLevel();
        if (educationLevel != null)
            clientCommonDataType.setEducationStatus(educationLevel.getValue());

        clientCommonDataType.setBirthDate(Utils.getXmlGregorianCalendar(pasportData.getBirthDate()));
        clientCommonDataType.setDependents(reqClientData.getDependents());
        client.setClientCommonData(clientCommonDataType);

        DocumentFullDataType doc = new DocumentFullDataType();
        doc.setIsPrimary(true);
        doc.setIsActive(true);
        doc.setDocumentType("DOCTYPE.FIRST.1");
        doc.setSerial(pasportData.getSerial());
        doc.setNumber(pasportData.getNumber());
        doc.setIssueOrgCode(pasportData.getIssueOrgCode());
        doc.setIssueOrgName(pasportData.getIssueOrgName());
        doc.setIssueDate(Utils.getXmlGregorianCalendar(pasportData.getIssueDate()));
        clientListDocument.getClientDocument().add(doc);

        if (reqClientData.getIssueCountry() != null && !StringUtils.isEmpty(reqClientData.getIssueCountry().getValue())) {
            DocumentFullDataType externalDoc = new DocumentFullDataType();
            externalDoc.setIssueCountry(reqClientData.getIssueCountry().getValue());
            externalDoc.setDocumentType("FOREIGN.INN");
            externalDoc.setNumber(reqClientData.getIssueCountryINN());
            externalDoc.setIsActive(true);
            clientListDocument.getClientDocument().add(externalDoc);
        }

        client.setClientListDocument(clientListDocument);

        Address factAddr = pasportData.getFactAddress();
        Address reqAddr = pasportData.getRegAddress();
        if (reqAddr != null)
            clientListAddress.getClientAddress().add(getKladrAddress(reqAddr,"req"));
        if (factAddr != null || reqAddr != null)
            clientListAddress.getClientAddress().add(getKladrAddress(Utils.nvl(factAddr,reqAddr), "fact"));
        client.setClientListAddress(clientListAddress);

        if (!isEmpty(reqClientData.getMobilePhone())) {
            Contact phone = new Contact();
            phone.setIsPrimary(true);
            phone.setContactType("CONTACT.TYPE.1");
            phone.setValue(reqClientData.getMobilePhone());
            clientListContact.getClientContact().add(phone);
        }
        if (!isEmpty(reqClientData.getEmail())) {
            Contact email = new Contact();
            email.setIsPrimary(false);
            email.setContactType("CONTACT.TYPE.4");
            email.setValue(reqClientData.getEmail());
            clientListContact.getClientContact().add(email);
        }
        if (!isEmpty(reqClientData.getExtraPhone())) {
            Contact extraPhone = new Contact();
            extraPhone.setIsPrimary(false);
            extraPhone.setContactType("CONTACT.TYPE.8");
            extraPhone.setValue(reqClientData.getExtraPhone());
            clientListContact.getClientContact().add(extraPhone);
        }
        client.setClientListContact(clientListContact);


        if (employmentData != null) {
            RefData workActivity = employmentData.getWorkActivity();
            ClientData.ClientListWork clientListWork = new ClientData.ClientListWork();
            PerWorkType perWorkType = new PerWorkType();
            perWorkType.setWorkType(true);
            perWorkType.setFullName(employmentData.getEmploymentFullName());
            perWorkType.setINNCompany(employmentData.getEmploymentInn());
            if (workActivity != null)
                perWorkType.setEmploymentType(ActivityTypes.getEsbValue(workActivity.getValue()));
            perWorkType.setAccountingPhone(new Contact() {{
                setContactType("CONTACT.TYPE.7");
                setValue(employmentData.getEmploymentPhone());
            }});
            Address employmentAddress = employmentData.getEmploymentAddress();
            if (employmentAddress != null) {
                ClientWorkAddressList clientWorkAddressList = new ClientWorkAddressList();
                clientWorkAddressList.getAddress().add(getKladrAddress(employmentAddress, "employ"));
                clientWorkAddressList.getAddress().add(getKladrAddress(employmentAddress, "legal"));
                perWorkType.setAddresses(clientWorkAddressList);
            }
            RefData positionLevel = employmentData.getPositionLevel();
            String positionLevelValue = null;
            if (positionLevel != null)
                positionLevelValue = positionLevel.getValue();
            if (!StringUtils.isEmpty(positionLevelValue)){
                AddForEmploymentType addForEmploymentType = new AddForEmploymentType();
                WorkerType workerType = new WorkerType();
                workerType.setPositionLevel(positionLevelValue);
                workerType.setPosition(employmentData.getPosition());
                workerType.setStartDate(employmentData.getWorkStartDate());
                addForEmploymentType.setWorker(workerType);
                perWorkType.setAddForEmployment(addForEmploymentType);
            } else if (employmentData.getWorkStartDate() != null){
                AddForEmploymentType addForEmploymentType = new AddForEmploymentType();
                WorkerType workerType = new WorkerType();
                workerType.setStartDate(employmentData.getWorkStartDate());
                addForEmploymentType.setWorker(workerType);
                perWorkType.setAddForEmployment(addForEmploymentType);
            }
            String activityTypeDetail = employmentData.getOkved();
            if (!StringUtils.isEmpty(activityTypeDetail)) {
                perWorkType.setActivityType(OkvedItems.getNameByCode(getOkved(activityTypeDetail)));
            }
            clientListWork.getClientWork().add(perWorkType);
            client.setClientListWork(clientListWork);
        }

        request.setClient(client);

        RefData loanPurpose = reqCreditData.getLoanPurpose();
        String type = loanPurpose.getValue();
        ClientRequestCommonDataType requestCommonDataType = new ClientRequestCommonDataType();
        ClientRequestProductDataType product = new ClientRequestProductDataType();
        product.setProductType(type.equals("Refinance") ? "NCPK.REFINANCE" : "NCPK.STANDARD");
        product.setProductCode(type.equals("Refinance") ? "НЦПК_Refin" : "НЦПК_Стандарт");
        product.setCurrency("RUR");
        product.setRequestSumma(reqCreditData.getRequestSumma() == null ? BigDecimal.ZERO : reqCreditData.getRequestSumma());
        if (reqCreditData.getCreditPeriod() != null)
            product.setCreditPeriod(reqCreditData.getCreditPeriod().multiply(new BigInteger("12")));
        requestCommonDataType.setProduct(product);

        String callingTime = "CALLING.TIME.3";

        requestCommonDataType.setCallback(new ClientRequestCommonDataType.Callback(){{
            setCallTime(callingTime);
            setTimeZone("CLIENT.TIME.ZONE.2");
        }});

        requestCommonDataType.setBankInfoSource(new ClientRequestCommonDataType.BankInfoSource(){{
            setSourceOfInformation("SOURCE.OF.INFORMATION.17");
        }});

        if ("AnyPurpose".equalsIgnoreCase(loanPurpose.getValue())){
            requestCommonDataType.setCreditGoal("OtherTarget");
            requestCommonDataType.setCreditOtherGoal("иная цель");
        } else {
            requestCommonDataType.setCreditGoal(loanPurpose.getValue());
            requestCommonDataType.setCreditOtherGoal(StringUtils.isEmpty(reqCreditData.getCreditOtherGoal()) ? "Кредит" : reqCreditData.getCreditOtherGoal());
        }

        if (!isEmpty(reqCreditData.getOfferId())){
            requestCommonDataType.setOfferID(reqCreditData.getOfferId());
        }

        clientRequest.setClientRequestCommonData(requestCommonDataType);
        request.setClientRequest(clientRequest);

        mtsRequest.setRequest(request);
        return mtsRequest;
    }

    private AddressKLADRFull getKladrAddress(Address reqAddr, String type){
        AddressKLADRFull address = new AddressKLADRFull();
        switch (type) {
            case "fact":
                address.setAddressType("ADDRESS.TYPE.2");
                break;
            case "req":
                address.setAddressType("ADDRESS.TYPE.1");
                break;
            case "legal":
                address.setAddressType("ADDRESS.WRK.LEGAL");
                break;
            default:
                address.setAddressType("ADDRESS.WRK.CHIEF");
                break;
        }
        address.setCountryName(reqAddr.getCountryName());
        address.setCountryCode(reqAddr.getCountryCode());
        address.setRegionName(reqAddr.getRegionName());
        address.setRegionCode(reqAddr.getRegionCode());
        address.setRegionSocr(reqAddr.getRegionSocr());
        address.setDistrictName(reqAddr.getDistrictName());
        address.setLocalityName(reqAddr.getLocalityName());
        address.setCityName(reqAddr.getCityName());
        address.setStreetName(reqAddr.getStreetName());
        address.setHouse(reqAddr.getHouse());
        address.setBuilding(reqAddr.getBuilding());
        address.setBlock(reqAddr.getBlock());
        address.setFlat(reqAddr.getFlat());
        address.setZipCode(reqAddr.getZipCode());
        address.setIsKladr(false);
        address.setIsMailAddress(true);
        if (isEmpty(address.getCityName()) && isEmpty(address.getLocalityName()))
            address.setLocalityName(nvl(reqAddr.getRegionName(), "Москва"));
        return address;
    }

    private String getOkved(String value){
        if (value.contains("."))
            return value.substring(0,value.indexOf("."));
        return value;
    }

}
