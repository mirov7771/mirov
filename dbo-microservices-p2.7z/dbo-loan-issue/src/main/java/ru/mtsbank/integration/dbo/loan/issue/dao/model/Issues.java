package ru.mtsbank.integration.dbo.loan.issue.dao.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.context.annotation.Scope;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "ISSUES")
@Getter @Setter
public class Issues implements Serializable {

    private static final long serialVersionUID = -1697791863333601766L;

    @Id
    @Column(name = "ISSUEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long issueId;
    @Column(name = "REQUESTID")
    private Long requestId;
    @Column(name = "OWNERID")
    private Long ownerId;
    @Column(name = "STATUSSYSNAME")
    private String statusSysName;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "AMOUNT")
    private BigDecimal amount;
    @Column(name = "CREATIONDATE")
    private Date creationDate;
    @Column(name = "ISSUEDATE")
    private Date issueDate;
    @Column(name = "AGREENUM")
    private String agreeNum;
    @Column(name = "LOANLIMIT")
    private String loanLimit;
    @Column(name = "MONTHLYPAYMENT")
    private String monthlyPayment;
    @Column(name = "LOANTERM")
    private String loanTerm;
    @Column(name = "INTERESTRATE")
    private String interestRate;
    @Column(name = "STATUSCODE")
    private String statusCode;
    @Column(name = "STATUSCODECOMMENT")
    private String statusCodeComment;
    @Column(name = "StATUSDATE")
    private Date statusDate;
    @Column(name = "OWNERPHONE")
    private String ownerPhone;
    @Column(name = "ISSHOW")
    private Integer isShow;
    @Column(name = "SENDFORSIGN")
    private Integer sendForSign;
    @Column(name = "ISDOCSEND")
    private Integer isDocSend;
    @Column(name = "UPDATEDATE")
    private Date updateDate;
    @OneToMany(mappedBy = "issueId", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<IssueAttribute> issueAttributesList;

    @Override
    public String toString(){
        return "issueId "+issueId
                +" requestId"+requestId
                +" ownerId"+ownerId
                +" statusSysName"+statusSysName
                +" status"+status
                +" creationDate"+creationDate
                +" agreeNum"+agreeNum
                +" statusCode"+statusCode
                +" statusCodeComment"+statusCodeComment;
    }

    public Issues(){

    }

    public Issues(Long ownerId, String status, String statusSysName, Date creationDate){
        this.ownerId = ownerId;
        this.status = status;
        this.statusSysName = statusSysName;
        this.creationDate = creationDate;
    }


}
