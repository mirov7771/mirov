package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static ru.mts.dbo.utils.Utils.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@ToString
public class ClientData {

    @JsonProperty("clientName")
    private String clientName;
    @JsonProperty("family")
    private String family;
    @JsonProperty("name")
    private String name;
    @JsonProperty("fatherName")
    private String fatherName;
    @JsonProperty("mobilePhone")
    private String mobilePhone;
    @JsonProperty("email")
    private String email;
    @JsonProperty("extraPhone")
    private String extraPhone;
    @JsonProperty("totalIncome")
    private BigDecimal totalIncome;
    @JsonProperty("flagChangeFio")
    private Boolean flagChangeFio;
    @JsonProperty("prevName")
    private String prevName;
    @JsonProperty("prevFamily")
    private String prevFamily;
    @JsonProperty("prevFatherName")
    private String prevFatherName;
    @JsonProperty("gatkaFlg")
    private Boolean gatkaFlg;
    @JsonProperty("issueCountryINN")
    private String issueCountryINN;
    @JsonProperty("smsAgreeFlag")
    private Boolean smsAgreeFlag;
    @JsonProperty("persInfoFlag")
    private Boolean persInfoFlag;
    @JsonProperty("bkiFlag")
    private Boolean bkiFlag;
    @JsonProperty("taxUSAFlag")
    private Boolean taxUSAFlag;
    @JsonProperty("publicFlag")
    private Boolean publicFlag;
    @JsonProperty("dependents")
    private Integer dependents;
    @JsonProperty("equalAddressFlag")
    private Boolean equalAddressFlag;
    @JsonProperty("isSalaryClient")
    private Boolean isSalaryClient;
    @JsonProperty("issueCountry")
    private RefData issueCountry;
    @JsonProperty("martialStatus")
    private RefData martialStatus;
    @JsonProperty("educationLevel")
    private RefData educationLevel;
    @JsonProperty("ipdlStatusCode")
    private RefData ipdlStatusCode;
    @JsonProperty("changeInfo")
    private Boolean changeInfo;
    @JsonProperty("bornUsa")
    private Boolean bornUsa;
    @JsonProperty("citizenUsaAndRf")
    private Boolean citizenUsaAndRf;
    @JsonProperty("greenCard")
    private Boolean greenCard;
    @JsonProperty("usaRegAddress")
    private String usaRegAddress;
    @JsonProperty("usaFactAddress")
    private String usaFactAddress;
    @JsonProperty("usaPhoneNumber")
    private String usaPhoneNumber;
    @JsonProperty("shortForm")
    private Boolean shortForm;

    public Map<String, String> toMap(){
        Map<String, String> map = new HashMap<>();
        map.put("clientName",clientName);
        map.put("family",family);
        map.put("name",name);
        map.put("fatherName",fatherName);
        map.put("mobilePhone",mobilePhone);
        map.put("email",email);
        map.put("extraPhone",extraPhone);
        if (totalIncome != null)
            map.put("totalIncome",totalIncome.toString());
        if (flagChangeFio != null)
            map.put("flagChangeFio",flagChangeFio.toString());
        map.put("prevName",prevName);
        map.put("prevFamily",prevFamily);
        map.put("prevFatherName",prevFatherName);
        if (gatkaFlg != null)
            map.put("gatkaFlg",gatkaFlg.toString());
        map.put("issueCountryINN",issueCountryINN);
        if (smsAgreeFlag != null)
            map.put("smsAgreeFlag",smsAgreeFlag.toString());
        if (persInfoFlag != null)
            map.put("persInfoFlag",persInfoFlag.toString());
        if (bkiFlag != null)
            map.put("bkiFlag",bkiFlag.toString());
        if (taxUSAFlag != null)
            map.put("taxUSAFlag", taxUSAFlag.toString());
        if (publicFlag != null)
            map.put("publicFlag", publicFlag.toString());
        if (dependents != null)
            map.put("dependents",dependents.toString());
        if (equalAddressFlag != null)
            map.put("equalAddressFlag",equalAddressFlag.toString());
        if (isSalaryClient != null)
            map.put("isSalaryClient",isSalaryClient.toString());
        if (changeInfo != null)
            map.put("changeInfo", changeInfo.toString());
        if (bornUsa != null)
            map.put("bornUsa", bornUsa.toString());
        if (citizenUsaAndRf != null)
            map.put("citizenUsaAndRf", citizenUsaAndRf.toString());
        if (greenCard != null)
            map.put("greenCard", greenCard.toString());
        if (shortForm != null)
            map.put("shortForm", shortForm.toString());
        map.values().removeAll(Collections.singleton(null));

        if (issueCountry != null)
            setRefMap(map, issueCountry.toMap(), "issueCountry");
        if (martialStatus != null)
            setRefMap(map, martialStatus.toMap(), "martialStatus");
        if (educationLevel != null)
            setRefMap(map, educationLevel.toMap(), "educationLevel");
        if (ipdlStatusCode != null)
            setRefMap(map, ipdlStatusCode.toMap(), "ipdlStatusCode");

        map.put("usaRegAddress", usaRegAddress);
        map.put("usaFactAddress", usaFactAddress);
        map.put("usaPhoneNumber", usaPhoneNumber);

        return map;
    }

    @JsonIgnore
    public boolean isEmpty(){
        return StringUtils.isEmpty(family);
    }
}
