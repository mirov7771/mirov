package ru.mtsbank.integration.dbo.loan.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.springframework.util.CollectionUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.mts.xsd.RequestStatusMod.BankSvcRq;
import ru.mtsbank.integration.mts.xsd.RequestStatusMod.CustInfo;
import ru.mtsbank.integration.mts.xsd.RequestStatusMod.RequestInfo;
import ru.mtsbank.integration.mts.xsd.RequestStatusMod.RequestStatusModNf;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import static ru.mts.dbo.utils.Utils.*;

@Component("dbo.loanissuestatus")
@Slf4j
public class RequestStatusModNfService implements NotificationService {

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start consuming RequestStatusModNf with ["+xmlRequest+"]");
        RequestStatusModNf nf = xmlUnmarshaler.parse(RequestStatusModNf.class, xmlRequest);
        if (nf != null
                && nf.getBankSvcRq() != null
                && nf.getBankSvcRq().getCustInfo() != null
                && nf.getBankSvcRq().getRequestInfo() != null
                && nf.getBankSvcRq().getRequestInfo().getRequestStatus() != null)
        {
            BankSvcRq bankSvcRq = nf.getBankSvcRq();
            RequestInfo requestInfo = bankSvcRq.getRequestInfo();
            String requestId = requestInfo.getRequestId();
            CustInfo custInfo = bankSvcRq.getCustInfo();
            String custId = custInfo.getCustId();
            if (!isEmpty(requestId)
                    && isDigits(requestId))
            {
                Long rqId = Long.parseLong(requestId);
                Issues issue = issuesRepository.findByRequestId(rqId);
                if (issue == null){
                    insertIssue(requestInfo, custId);
                } else {
                    updateIssue(issue, requestInfo);
                }
            }
        }
        log.info("End consuming RequestStatusModNf");
    }

    private void updateIssue(Issues issue, RequestInfo requestInfo){
        prepareIssue(issue, requestInfo, null);
    }

    private void insertIssue(RequestInfo requestInfo, String custId){

        List<Issues> issues = issuesRepository.findByOwnerIdAndStatusSysName(Long.parseLong(custId)
                , LoanStates.INPUT.getStatusSysName());
        if (!CollectionUtils.isEmpty(issues)){
            prepareIssue(issues.get(0), requestInfo, custId);
        } else {
            Issues issue = new Issues();
            prepareIssue(issue, requestInfo, custId);
        }

    }

    @Transactional
    void prepareIssue(Issues issue, RequestInfo requestInfo, String custId){
        LoanStates state = LoanStates.getStatusBySysName(requestInfo.getRequestStatus().getStatusCode());
        if (custId != null)
            issue.setOwnerId(Long.parseLong(custId));
        if (issue.getCreationDate() == null)
            issue.setCreationDate(new Date());
        if (requestInfo.getCurAmt() != null) {
            BigDecimal amount = requestInfo.getCurAmt().getAmt();
            issue.setAmount(amount);
        }
        issue.setStatus(state.getStatus());
        issue.setStatusSysName(state.getStatusSysName());
        if (requestInfo.getOrigDt() != null) {
            issue.setIssueDate(getDate(requestInfo.getOrigDt().getYear(), requestInfo.getOrigDt().getMonth(), requestInfo.getOrigDt().getDay()));
        }
        if (issue.getRequestId() == null){
            issue.setRequestId(Long.parseLong(requestInfo.getRequestId()));
        }
        if (requestInfo.getPhoneNum() != null && requestInfo.getPhoneNum().isPrimary()){
            issue.setOwnerPhone(requestInfo.getPhoneNum().getPhone());
        }
        issue.setUpdateDate(new Date());
        issuesRepository.save(issue);
    }
}
