package ru.mtsbank.integration.dbo.loan.issue.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CheckIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.OpenIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueDocListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferSelectReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.*;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.CheckIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.CreateIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.OpenIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.info.LoanIssueDocListRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.info.LoanIssueListRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.selection.OfferListRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.selection.OfferSelectRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing.*;
import ru.mtsbank.integration.dbo.loan.issue.service.Service;

import javax.validation.Valid;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Tag(name = "LoanIssueController")
@RestController
@RequestMapping("dbo-loan-issue")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/create/checkIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "проверка наличия предзаполненной заявки на кредит у клиента"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CheckIssueRes.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> checkIssue(@PathVariable final String version
                                                  , @RequestHeader(value = "rbo_id", required = false) String rboId
                                                  , @RequestHeader(value = "authorization", required = false) String authorization
                                                  , @RequestBody(required = false) CheckIssueReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).checkIssue(req));
    }

    @PostMapping(value = "{version}/create/createIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "оформление заявки на кредит"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CreateIssueRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> createIssue(@PathVariable final String version
                                                   ,@Valid @RequestBody CreateIssueReq req)
    {
        return ResponseBuilder.build(services.get(version).createIssue(req));
    }

    @PostMapping(value = "{version}/create/openIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "открытие формы заявки на кредит"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = OpenIssueRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> openIssue(@PathVariable final String version
                                                 ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                 ,@RequestHeader(value = "authorization", required = false) String authorization
                                                 ,@Valid @RequestBody OpenIssueReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).openIssue(req));
    }

    @PostMapping(value = "{version}/info/loanIssueList", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "список заявок"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = LoanIssueListRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> loanIssueList(@PathVariable final String version
                                                     ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                     ,@RequestHeader(value = "authorization", required = false) String authorization
                                                     ,@RequestBody(required = false) LoanIssueListReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).loanIssueList(req));
    }

    @PostMapping(value = "{version}/info/loanIssueDocList", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "список документов"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = LoanIssueDocListRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> loanIssueDocList(@PathVariable final String version
                                                        ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                        ,@RequestHeader(value = "authorization", required = false) String authorization
                                                        ,@RequestBody(required = false) LoanIssueDocListReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).loanIssueDocList(req));
    }

    @GetMapping(value = "{version}/selection/offerList", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "список предложений"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = OfferListRes.class))
            }),
            @ApiResponse(responseCode = "410", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> offerList(@PathVariable final String version
                                                 ,@RequestParam("requestId") Long requestId)
    {
        OfferListReq req = new OfferListReq();
        req.setRequestId(requestId);
        return ResponseBuilder.build(services.get(version).offerList(req));
    }

    @PostMapping(value = "{version}/selection/offerSelect", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "выбор предложения"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = OfferSelectRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> offerSelect(@PathVariable final String version
                                                   ,@Valid @RequestBody OfferSelectReq req)
    {
        return ResponseBuilder.build(services.get(version).offerSelect(req));
    }

    @PostMapping(value = "{version}/signing/cancelIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "отмена заявки на кредит"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CancelIssueRes.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> cancelIssue(@PathVariable final String version
                                                   ,@Valid @RequestBody CancelIssueReq req)
    {
        return ResponseBuilder.build(services.get(version).cancelIssue(req));
    }

    @PostMapping(value = "{version}/signing/openDoc", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "получение документа"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = OpenDocRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> openDoc(@PathVariable final String version
                                               ,@Valid @RequestBody OpenDocReq req)
    {
        return ResponseBuilder.build(services.get(version).openDoc(req));
    }

    @PostMapping(value = "{version}/signing/preSignIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "получение окончательных условий и печатных форм по кредитному договору"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = PreSignIssueRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1","v2"}))
    public ResponseEntity<BaseResponse> preSignIssue(@PathVariable final String version
                                                    ,@Valid @RequestBody PreSignIssueReq req)
    {
        return ResponseBuilder.build(services.get(version).preSignIssue(req));
    }

    @PostMapping(value = "{version}/signing/sendDocs", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "отправка документов на почту"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = SendDocsRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> sendDocs(@PathVariable final String version
                                                ,@Valid @RequestBody SendDocsReq req)
    {
        return ResponseBuilder.build(services.get(version).sendDocs(req));
    }

    @PostMapping(value = "{version}/signing/signIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "подписание условий по договору"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = SignIssueRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> signIssue(@PathVariable final String version
                                                 ,@Valid @RequestBody SignIssueReq req)
    {
        return ResponseBuilder.build(services.get(version).signIssue(req));
    }

    @PostMapping(value = "{version}/create/createShortIssue", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "Сохранение и отправка анкеты на обработку"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CreateIssueRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1","v2"}))
    public ResponseEntity<BaseResponse> createShortIssue(@PathVariable final String version
                                                        ,@Valid @RequestBody CreateIssueReq req)
    {
        return ResponseBuilder.build(services.get(version).createShortIssue(req));
    }

}
