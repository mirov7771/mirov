package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class Issue {

    @JsonProperty("issueId")
    private Long issueId;
    @JsonProperty("requestId")
    private Long requestId;
    @JsonProperty("rboId")
    private Long rboId;
    @JsonProperty("statusSysName")
    private String statusSysName;
    @JsonProperty("status")
    private String status;
    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("issueDate")
    private Date issueDate;
    @JsonProperty("docId")
    private Long docId;
    @JsonProperty("docName")
    private String docName;
    @JsonProperty("docTypeSysName")
    private String docTypeSysName;
    @JsonProperty("showPromo")
    private Boolean showPromo;

}
