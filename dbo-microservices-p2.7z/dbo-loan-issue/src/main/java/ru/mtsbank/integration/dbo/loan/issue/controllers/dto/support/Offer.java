package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class Offer {

    @JsonProperty("requestId")
    private Long requestId;
    @JsonProperty("decisionId")
    private String decisionId;
    @JsonProperty("creditSum")
    private BigDecimal creditSum;
    @JsonProperty("creditMinSum")
    private BigDecimal creditMinSum;
    @JsonProperty("rate")
    private BigDecimal rate;
    @JsonProperty("creditPeriod")
    private BigInteger creditPeriod;
    @JsonProperty("monthlyPayment")
    private BigDecimal monthlyPayment;
    @JsonProperty("decisionMode")
    private String decisionMode;
    @JsonProperty("insuranceList")
    private List<Insurance> insuranceList;

}
