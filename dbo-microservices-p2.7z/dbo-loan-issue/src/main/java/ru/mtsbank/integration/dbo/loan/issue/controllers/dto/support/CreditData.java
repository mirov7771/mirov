package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static ru.mts.dbo.utils.Utils.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
@ToString
public class CreditData {

    @JsonProperty("issueId")
    private Long issueId;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("requestSumma")
    private BigDecimal requestSumma;
    @JsonProperty("codeWord")
    private String codeWord;
    @JsonProperty("creditOtherGoal")
    private String creditOtherGoal;
    @JsonProperty("creditPeriod")
    private BigInteger creditPeriod;
    @JsonProperty("interestRateValue")
    private Float interestRateValue;
    @JsonProperty("monthlyPayment")
    private BigDecimal monthlyPayment;
    @JsonProperty("step")
    private Integer step;
    @JsonProperty("offerId")
    private String offerId;

    @JsonProperty("loanPurpose")
    private RefData loanPurpose;

    public Map<String, String> toMap(){
        Map<String, String> map = new HashMap<>();
        map.put("channel",channel);
        if (requestSumma != null)
            map.put("requestSumma",requestSumma.toString());
        map.put("codeWord",codeWord);
        map.put("creditOtherGoal",creditOtherGoal);
        if (creditPeriod != null)
            map.put("creditPeriod",creditPeriod.toString());
        if (interestRateValue != null)
            map.put("interestRateValue",interestRateValue.toString());
        if (monthlyPayment != null)
            map.put("monthlyPayment", monthlyPayment.toString());
        map.values().removeAll(Collections.singleton(null));
        if (step != null)
            map.put("step", step.toString());
        if (loanPurpose != null)
            setRefMap(map, loanPurpose.toMap(), "loanPurpose");
        if (offerId != null)
            map.put("offerId", offerId);
        return map;
    }

}
