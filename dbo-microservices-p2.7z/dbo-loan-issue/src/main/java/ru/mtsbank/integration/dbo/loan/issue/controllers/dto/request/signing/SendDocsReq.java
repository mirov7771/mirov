package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;

@Getter
public class SendDocsReq extends BaseRequest {

    @JsonProperty("email")
    @NotNull
    private String email;
    @JsonProperty("requestId")
    @NotNull
    private Long requestId;

}
