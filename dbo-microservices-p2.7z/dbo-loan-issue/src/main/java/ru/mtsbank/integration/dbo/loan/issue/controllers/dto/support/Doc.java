package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@ToString
public class Doc {

    @JsonProperty("docId")
    private Long docId;
    @JsonProperty("docName")
    private String docName;
    @JsonProperty("docTypeSysName")
    private String docTypeSysName;
    @JsonProperty("agreeNum")
    private String agreeNum;
    @JsonProperty("docSize")
    private Float docSize;

}
