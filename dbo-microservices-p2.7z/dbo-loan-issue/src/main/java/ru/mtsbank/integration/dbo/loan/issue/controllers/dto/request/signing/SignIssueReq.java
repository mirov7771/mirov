package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;

@Getter
@ToString
public class SignIssueReq extends BaseRequest {

    @JsonProperty("code")
    private String code;
    @JsonProperty("requestId")
    @NotNull
    private Long requestId;

}
