package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.create.CreateIssueRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.service.general.CreateIssueMethod;

import java.io.IOException;
import java.text.ParseException;
import java.util.UUID;

@Component
@Slf4j
public class CreateFullIssueMethod extends CreateIssueMethod {

    @Override
    public CreateIssueRes call(CreateIssueReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start create service with params {}", uid, req.toString());
        CreateIssueRes res = new CreateIssueRes();
        try {
            Long issueId = req.getCreditData().getIssueId();
            Issues issue = issuesRepository.findByIssueId(issueId);
            if (issue != null) {
                String requestId = req.getCreditData().getChannel() + "-" + issueId;
                process(issue, req, issueId, uid, false);
                res.setRequestId(requestId);
            } else {
                res.createError(1002, "У вас есть активная заявка на кредит. Дождитесь решения и завершите оформление", 409, null, null, "createissue", uid);
            }
        } catch (IOException | ParseException e){
            log.error("{} Error in create full issue {}", uid, Utils.getStackError(e));
            res.createError(501,"Сервис временно недоступен", 406, null, null, "createissue", uid);
        }
        log.info("{} End create service", uid);
        return res;
    }

}
