package ru.mtsbank.integration.dbo.loan.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.mts.xsd.RequestStatusModRs.FDXStatus;
import ru.mtsbank.integration.mts.xsd.RequestStatusModRs.RequestStatusModRs;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Component("dbo.loanissuestatus.change.result")
@Slf4j
public class RequestStatusModRsService implements NotificationService {

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    private static Set<String> REFUSE_STATUS = new HashSet<>();

    static {
        REFUSE_STATUS.add("2");
        REFUSE_STATUS.add("5");
        REFUSE_STATUS.add("6");
        REFUSE_STATUS.add("8");
        REFUSE_STATUS.add("9");
        REFUSE_STATUS.add("1");
    }

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start consuming RequestStatusModRs with [{}]", xmlRequest);
        RequestStatusModRs rs = xmlUnmarshaler.parse(RequestStatusModRs.class, xmlRequest);
        preValidate(rs);
        String rqId = rs.getServerInfo().getRqUID();
        log.info("get rqid "+rqId);
        if (!StringUtils.isEmpty(rqId) && Utils.isDigits(rqId)) {
            log.info("search app "+rqId);
            FDXStatus status = rs.getBankSvcRs().getStatus();
            String sc = status.getStatusCode();
            Issues issue = issuesRepository.findByRequestId(Long.parseLong(rqId));
            if (issue != null){
                log.info("start proccessing app "+rqId);
                String state = null;
                String stateSysName = null;
                if (!StringUtils.isEmpty(sc)) {
                    if (sc.equals("0")){
                        state = LoanStates.DONE.getStatus();
                        stateSysName = LoanStates.DONE.getStatusSysName();
                    } else if (REFUSE_STATUS.contains(sc)) {
                        state = LoanStates.BANK_REFUSE.getStatus();
                        stateSysName = LoanStates.BANK_REFUSE.getStatusSysName();
                    } else if (sc.equals("1") || sc.equals("11") || sc.equals("7")) {
                        state = issue.getStatus();
                        stateSysName = issue.getStatusSysName();
                    } else if (sc.equals("10") || sc.equals("4") || sc.equals("3")){
                        state = LoanStates.WAITING_CLIENT_InDO.getStatus();
                        stateSysName = LoanStates.WAITING_CLIENT_InDO.getStatusSysName();
                    } else if (sc.equals("12")){
                        state = issue.getStatus();
                        stateSysName = issue.getStatusSysName();
                    }
                    issue.setStatusCode(sc);
                    String message = null;
                    switch (sc){
                        case "0":
                            message = "Заявка подписана успешно. Мы благодарим Вас за обращение в МТС Банк!";
                            break;
                        case "1":
                            message = "Введен неверный код";
                            break;
                        case "2":
                        case "5":
                        case "6":
                        case "8":
                        case "9":
                            message = "Выдача через ДБО невозможна";
                            break;
                        case "3":
                            message = "Выдача через ДБО невозможна. Обратитесь в дополнительный офис МТС-банка.";
                            break;
                        case "4":
                            message = "Превышено количество попыток перегенерации кода. Обратитесь в офис продаж для подписания документации.";
                            break;
                        case "10":
                            message = "Техническая ошибка. Обратитесь в офис продаж для подписания документации.";
                            break;
                        case "7":
                            message = "Уникальный код устарел";
                            break;
                        case "11":
                            message = "Вам отправлен новый код.";
                            break;
                        case "12":
                            message = "Подписываемая документация не совпадает с отправленной";
                            break;
                    }
                    issue.setStatusCodeComment(message);
                    if (state != null && stateSysName != null) {
                        log.info("App "+rqId+" new state is "+state+" sysName "+stateSysName+" message "+message);
                        issue.setStatus(state);
                        issue.setStatusSysName(stateSysName);
                        issue.setStatusDate(new Date());
                    }
                    issuesRepository.save(issue);
                }
            }
        }
        log.info("End consuming RequestStatusModRs");
    }

    private void preValidate(RequestStatusModRs rs) throws Exception {
        boolean error = false;
        if (rs == null){
            error = true;
            log.error("RequestStatusModRs is null");
        } else if (rs.getBankSvcRs() == null){
            error = true;
            log.error("RequestStatusModRs/BankSvcRs is null");
        } else if (rs.getBankSvcRs().getStatus() == null){
            error = true;
            log.error("RequestStatusModRs/BankSvcRs/Status is null");
        } else if (rs.getServerInfo() == null){
            error = true;
            log.error("RequestStatusModRs/ServerInfo is null");
        }
        if (Boolean.TRUE.equals(error)){
            throw new Exception("Сервис временно недоступен");
        }
    }

}
