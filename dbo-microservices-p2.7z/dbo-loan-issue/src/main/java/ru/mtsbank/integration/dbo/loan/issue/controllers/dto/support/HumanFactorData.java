package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class HumanFactorData {

    @JsonProperty("suggestions")
    private List<Suggestions> suggestions;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Suggestions{

        @JsonProperty("data")
        private HfData data;
        @JsonProperty("value")
        private String value;
        @JsonIgnoreProperties(ignoreUnknown = true)
        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        public static class HfData{
            @JsonProperty("country")
            private String countryName;
            @JsonProperty("country_iso_code")
            private String countryCode;
            @JsonProperty("region")
            private String regionName;
            @JsonProperty("region_type")
            private String regionCode;
            @JsonProperty("city_district")
            private String districtName;
            @JsonProperty("area")
            private String localityName;
            @JsonProperty("city")
            private String cityName;
            @JsonProperty("street")
            private String streetName;
            @JsonProperty("house")
            private String house;
            @JsonProperty("building")
            private String building;
            @JsonProperty("block")
            private String block;
            @JsonProperty("flat")
            private String flat;
            @JsonProperty("postal_code")
            private String zipCode;
        }
    }

}
