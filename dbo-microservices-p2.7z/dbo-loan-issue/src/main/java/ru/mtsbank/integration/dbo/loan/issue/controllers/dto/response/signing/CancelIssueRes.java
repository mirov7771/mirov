package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.signing;

import ru.mts.dbo.dto.BaseResponse;

public class CancelIssueRes extends BaseResponse {
}
