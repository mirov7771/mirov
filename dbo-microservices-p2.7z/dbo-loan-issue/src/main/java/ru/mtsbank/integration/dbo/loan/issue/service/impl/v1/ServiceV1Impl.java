package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CheckIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.CreateIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.create.OpenIssueReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueDocListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.info.LoanIssueListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferSelectReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.signing.*;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create.CheckIssueMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create.CreateFullIssueMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create.CreateShortIssueMethodV1;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.create.OpenIssueMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.info.LoanIssueDocListMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.info.LoanIssueListMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.selection.OfferListMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.selection.OfferSelectMethod;
import ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.signing.*;
import ru.mtsbank.integration.dbo.loan.issue.service.Service;

@RequiredArgsConstructor
@Component("v1")
public class ServiceV1Impl implements Service {

    private final CheckIssueMethod checkIssueMethod;
    private final CreateFullIssueMethod createFullIssueMethod;
    private final OpenIssueMethod openIssueMethod;
    private final LoanIssueListMethod loanIssueListMethod;
    private final LoanIssueDocListMethod loanIssueDocListMethod;
    private final OfferListMethod offerListMethod;
    private final OfferSelectMethod offerSelectMethod;
    private final CancelIssueMethod cancelIssueMethod;
    private final OpenDocMethod openDocMethod;
    private final PreSignIssueMethodV1 preSignIssueMethod;
    private final SendDocsMethod sendDocsMethod;
    private final SignIssueMethod signIssueMethod;
    private final CreateShortIssueMethodV1 createShortIssueMethod;

    @Override
    public BaseResponse checkIssue(CheckIssueReq req) {
        return checkIssueMethod.call(req);
    }

    @Override
    public BaseResponse createIssue(CreateIssueReq req) {
        return createFullIssueMethod.call(req);
    }

    @Override
    public BaseResponse openIssue(OpenIssueReq req) {
        return openIssueMethod.call(req);
    }

    @Override
    public BaseResponse loanIssueList(LoanIssueListReq req) {
        return loanIssueListMethod.call(req);
    }

    @Override
    public BaseResponse loanIssueDocList(LoanIssueDocListReq req) {
        return loanIssueDocListMethod.call(req);
    }

    @Override
    public BaseResponse offerList(OfferListReq req) {
        return offerListMethod.call(req);
    }

    @Override
    public BaseResponse offerSelect(OfferSelectReq req) {
        return offerSelectMethod.call(req);
    }

    @Override
    public BaseResponse cancelIssue(CancelIssueReq req) {
        return cancelIssueMethod.call(req);
    }

    @Override
    public BaseResponse openDoc(OpenDocReq req) {
        return openDocMethod.call(req);
    }

    @Override
    public BaseResponse preSignIssue(PreSignIssueReq req) {
        return preSignIssueMethod.preSignCall(req);
    }

    @Override
    public BaseResponse sendDocs(SendDocsReq req) {
        return sendDocsMethod.call(req);
    }

    @Override
    public BaseResponse signIssue(SignIssueReq req) {
        return signIssueMethod.call(req);
    }

    @Override
    public BaseResponse createShortIssue(CreateIssueReq req) {
        return createShortIssueMethod.call(req);
    }

}
