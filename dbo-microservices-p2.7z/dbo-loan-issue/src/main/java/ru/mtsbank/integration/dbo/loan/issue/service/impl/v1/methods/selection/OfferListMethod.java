package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.selection;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferListReq;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.selection.OfferListRes;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Insurance;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Offer;
import ru.mtsbank.integration.dbo.loan.issue.dao.OffersRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Insurances;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Offers;

import java.util.ArrayList;
import java.util.List;

@Component("offerlist")
@Slf4j
public class OfferListMethod {

    @Autowired
    private OffersRepository offersRepository;

    public OfferListRes call(OfferListReq req) {
        log.info("Start offerlist service");
        OfferListRes res = new OfferListRes();
        List<Offers> offersList = offersRepository.findByRequestId(req.getRequestId());
        if (!CollectionUtils.isEmpty(offersList)){
            List<Offer> offers = new ArrayList<>();
            for(Offers item : offersList){
                Offer offer = new Offer();
                offer.setRequestId(item.getRequestId());
                offer.setDecisionId(item.getDecisionId());
                offer.setRate(item.getRate());
                offer.setCreditMinSum(item.getCreditMinSum());
                offer.setCreditPeriod(item.getCreditPeriod());
                offer.setCreditSum(item.getCreditSum());
                offer.setMonthlyPayment(item.getMonthlyPayment());
                if (item.getDecisionMode() != null)
                    offer.setDecisionMode(item.getDecisionMode().equalsIgnoreCase("ONLINE") ? "Получение кредита онлайн, принятие решения в течение нескольких минут" : "Получение кредита в офисе, рассмотрение до трех рабочих дней");
                if (!CollectionUtils.isEmpty(item.getInsurancesList())){
                    List<Insurance> insuranceList = new ArrayList<>();
                    for(Insurances insItem : item.getInsurancesList()){
                        Insurance insurance = new Insurance();
                        insurance.setDecisionId(insItem.getDecisionId());
                        insurance.setRequestId(insItem.getRequestId());
                        insurance.setInsuranceId(insItem.getInsuranceId());
                        insurance.setInsurancePercent(insItem.getInsurancePercent());
                        insurance.setInsuranceProgrammCode(insItem.getProgramCode());
                        insurance.setInsuranceType(insItem.getInsuranceType());
                        insurance.setPremiumAmount(insItem.getPremiumAmount());
                        insuranceList.add(insurance);
                    }
                    offer.setInsuranceList(insuranceList);
                }
                offers.add(offer);
            }
            res.setOffers(offers);
        } else {
            res.createError(1028, "Предложения не найдены", 410, null, null, "offerlist", null);
        }
        log.info("End offerlist service");
        return res;
    }

}
