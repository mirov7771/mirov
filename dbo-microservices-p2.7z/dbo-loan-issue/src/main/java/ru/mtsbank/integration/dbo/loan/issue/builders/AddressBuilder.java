package ru.mtsbank.integration.dbo.loan.issue.builders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.gates.HumanFactorGate;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.Address;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support.HumanFactorData;

@Component
public class AddressBuilder {

    @Autowired
    private HumanFactorGate humanFactorGate;

    public Address call(String addr){
        HumanFactorData hf = humanFactorGate.call(HumanFactorData.class, addr);
        if (hf != null && !CollectionUtils.isEmpty(hf.getSuggestions())){
            Address address = new Address();
            HumanFactorData.Suggestions suggestion = hf.getSuggestions().get(0);
            address.setAddr(suggestion.getValue());
            if (suggestion.getData() != null){
                HumanFactorData.Suggestions.HfData data = suggestion.getData();
                address.setCountryName("Российская Федерация");
                address.setCountryCode("643");
                address.setRegionName(data.getRegionName());
                address.setRegionCode(data.getRegionCode());
                address.setRegionSocr(data.getRegionCode());
                address.setDistrictName(data.getDistrictName());
                address.setCityName(data.getCityName());
                address.setLocalityName(data.getLocalityName());
                address.setStreetName(data.getStreetName());
                address.setHouse(data.getHouse());
                address.setBlock(data.getBlock());
                address.setBuilding(data.getBuilding());
                address.setZipCode(data.getZipCode());
                address.setFlat(data.getFlat());
            }
            return address;
        }
        return null;
    }

}
