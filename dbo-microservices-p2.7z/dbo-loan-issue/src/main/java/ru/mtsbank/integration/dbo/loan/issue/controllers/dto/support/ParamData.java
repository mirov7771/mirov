package ru.mtsbank.integration.dbo.loan.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter @Setter
@ToString
public class ParamData {

    @JsonProperty("creditAmt")
    private CreditParam creditAmt;
    @JsonProperty("creditSalaryAmt")
    private CreditParam creditSalaryAmt;
    @JsonProperty("creditTerm")
    private CreditParam creditTerm;
    @JsonProperty("interestRateList")
    private List<InterestRate> interestRateList;

}
