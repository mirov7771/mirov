package ru.mtsbank.integration.dbo.loan.issue.service.impl.v1.methods.selection;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.request.selection.OfferSelectReq;
import ru.mtsbank.integration.dbo.loan.issue.builders.AgreementRsBuilder;
import ru.mtsbank.integration.dbo.loan.issue.controllers.dto.response.selection.OfferSelectRes;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.OffersRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Offers;
import ru.mtsbank.integration.dbo.loan.issue.dao.operations.IssueOperations;

import java.math.BigInteger;
import java.util.UUID;

@Component("offerselect")
@Slf4j
public class OfferSelectMethod {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private AgreementRsBuilder agreementRsBuilder;

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private OffersRepository offersRepository;

    @Autowired
    private IssueOperations issueOperations;

    public OfferSelectRes call(OfferSelectReq req) {
        String uid = UUID.randomUUID().toString();
        log.info("{} Start offerselect service", uid);
        OfferSelectRes res = new OfferSelectRes();
        try {
            Long requestId = req.getRequestId();
            Issues issue = issuesRepository.findByRequestIdAndStatusSysName(requestId, LoanStates.SELECTION.getStatusSysName());
            if (issue != null) {
                String xml = xmlUnmarshaler.createXml(
                        agreementRsBuilder.agreementRsBuild(BigInteger.valueOf(requestId)
                                , req.getDecisionId()
                                , req.getAmount()
                                , req.getPayDay()
                                , uid)
                );
                if (!StringUtils.isEmpty(xml)) {
                    log.info("{} start send xml {} to kafka topic dbo.loanissueagreements.result", uid, xml);
                    kafkaTemplate.send("dbo.loanissueagreements.result", xml);
                    log.info("{} end send xml {} to kafka topic dbo.loanissueagreements.result", uid, xml);
                    issue.setStatusSysName(LoanStates.SCORING.getStatusSysName());
                    issue.setStatus(LoanStates.SCORING.getStatus());
                    issuesRepository.save(issue);
                    res.setRequestId(uid);
                    Offers offer = offersRepository.findByRequestIdAndDecisionId(requestId, req.getDecisionId());
                    if (offer == null || "OFFLINE".equalsIgnoreCase(offer.getDecisionMode())) {
                        log.info("OFFLINE decision");
                        res.setReadyToSign(false);
                    } else {
                        log.info("ONLINE decision");
                        res.setReadyToSign(checkStatus(issue.getIssueId(), uid));
                    }
                } else {
                    res.createError(501, "Сервис временно недоступен", 406, null, null, "offerselect", uid);
                }
            } else {
                res.createError(1029, "Не найдена заявка в статусе для выбора предложения", 406, null, null, "offerselect", uid);
            }
        } catch (InterruptedException e){
            log.error("{} Error in offer select {}", uid, Utils.getStackError(e));
            res.createError(501, "Сервис временно недоступен", 406, null, null, "offerselect", uid);
        }
        log.info("{} End offerselect service", uid);
        return res;
    }

    private boolean checkStatus(Long issueId, String uid) throws InterruptedException {
        boolean canContinue = false;
        int ncpkTimeOut = 150;
        for(int i = 0; i < ncpkTimeOut; i++) {
            log.info("{} Wait WAITING_CLIENT.inDBO in iter {} issueId {}", uid, i, issueId);
            Thread.sleep(150);
            if (Boolean.TRUE.equals(issueOperations.isWaitingClientInDbo(issueId))) {
                log.info("{} Get WAITING_CLIENT.inDBO for {}", uid, issueId);
                canContinue = true;
                log.info("{} Send flag for issueId {}", uid, issueId);
                break;
            }
        }
        return canContinue;
    }

}
