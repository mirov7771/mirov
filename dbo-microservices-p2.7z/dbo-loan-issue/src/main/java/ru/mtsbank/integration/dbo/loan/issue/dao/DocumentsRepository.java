package ru.mtsbank.integration.dbo.loan.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;

import java.util.List;

@Repository
public interface DocumentsRepository extends CrudRepository<Documents, String> {

    List<Documents> findByOwnerId(Long ownerId);
    List<Documents> findByOwnerIdAndAgreeNum(Long ownerId, String agreeNum);
    Documents findByDocumentId(Long documentId);
    List<Documents> findByRequestId(Long requestId);
    Documents findByAgreeNumAndDocTypeSysName(String agreeNum, String docTypeSysName);

}
