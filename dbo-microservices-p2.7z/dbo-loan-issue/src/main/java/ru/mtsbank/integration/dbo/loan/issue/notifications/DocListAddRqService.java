package ru.mtsbank.integration.dbo.loan.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.enums.LoanStates;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Documents;
import ru.mtsbank.integration.dbo.loan.issue.dao.DocumentsRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.loan.issue.dao.IssuesRepository;
import ru.mtsbank.integration.dbo.loan.issue.dao.operations.DocumentsOperations;
import ru.mtsbank.integration.mts.xsd.DocListAddRq.*;

import java.util.*;

@Component("dbo.loanissuedocs")
@Slf4j
public class DocListAddRqService implements NotificationService {

    @Autowired
    private IssuesRepository issuesRepository;

    @Autowired
    private DocumentsRepository documentsRepository;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private DocumentsOperations documentsOperations;

    private static final Base64.Encoder encoder = Base64.getEncoder();

    @Override
    public void handleRequest(String xmlRequest) throws Exception {
        log.info("Start consuming DocListAddRq");
        DocListAddRq rq = xmlUnmarshaler.parse(DocListAddRq.class, xmlRequest);
        preValidate(rq);
        BankSvcRq bankSvcRq = rq.getBankSvcRq();
        RequestInfo requestInfo = bankSvcRq.getRequestInfo();
        String rqId = requestInfo.getRequestId();
        if (!StringUtils.isEmpty(rqId) && Utils.isDigits(rqId)){
            Long requestId = Long.parseLong(rqId);
            Issues issue = issuesRepository.findByRequestId(requestId);
            if (issue != null){
                Long ownerId = issue.getOwnerId();
                String agreeNum = requestInfo.getAgreemtNum();
                issue.setAgreeNum(agreeNum);
                if (bankSvcRq.getParms() != null){
                    List<Parm> parms = bankSvcRq.getParms().getParm();
                    if (!CollectionUtils.isEmpty(parms)){
                        for(Parm parm : parms){
                            String parmName = parm.getParmName();
                            String parmValue = prepareValue(parm.getParmValue());
                            if (parmName.equalsIgnoreCase("Одобренный лимит")){
                                issue.setLoanLimit(parmValue);
                            } else if (parmName.equalsIgnoreCase("Ежемесячный платеж")){
                                issue.setMonthlyPayment(parmValue);
                            } else if (parmName.equalsIgnoreCase("Срок кредита")){
                                issue.setLoanTerm(parmValue);
                            } else if (parmName.equalsIgnoreCase("Процентная ставка")){
                                issue.setInterestRate(parmValue);
                            }
                        }
                    }
                }
                issue.setStatus(LoanStates.SIGNING.getStatus());
                issue.setStatusSysName(LoanStates.SIGNING.getStatusSysName());
                issue.setIsDocSend(0);
                Long issueId = issue.getIssueId();
                if (bankSvcRq.getDocList() != null) {
                    List<DocRec> docList = bankSvcRq.getDocList().getDocRec();
                    if (!CollectionUtils.isEmpty(docList)){
                        documentsOperations.delete(requestId);
                        for(DocRec docRec : docList){
                            Documents documents = new Documents();
                            documents.setOwnerId(ownerId);
                            documents.setRequestId(requestId);
                            documents.setDocData(new String(encoder.encode(docRec.getData())));
                            documents.setDocName(docRec.getOrigName());
                            documents.setDocTypeSysName(docRec.getDocTypeName());
                            documents.setIssueId(issueId);
                            documents.setAgreeNum(agreeNum);
                            documentsRepository.save(documents);
                        }
                    }
                }
                Thread.sleep(250);
                issuesRepository.save(issue);
            }
        }
        log.info("End consuming DocListAddRq");
    }

    private void preValidate(DocListAddRq req) throws Exception {
        boolean error = false;
        if (req == null){
            error = true;
            log.error("DocListAddRq is null");
        } else if (req.getBankSvcRq() == null){
            error = true;
            log.error("DocListAddRq/BankSvcRq is null");
        } else if (req.getBankSvcRq().getRequestInfo() == null){
            error = true;
            log.error("DocListAddRq/BankSvcRq/Status is null");
        }
        if (Boolean.TRUE.equals(error)){
            throw new Exception("Сервис временно недоступен");
        }
    }

    private String prepareValue(String paramValue){
        if (paramValue != null)
            return paramValue.replace(" руб","").replace(" %","").replace(" мес.","");
        return null;
    }

}
