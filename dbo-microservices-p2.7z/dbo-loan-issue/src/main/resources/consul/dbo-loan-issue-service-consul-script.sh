#!/bin/sh

root="ump/dbo"
url=http://consul-ump-dev.mbrd.ru:8081/v1/kv/${root}
token=230d1066-0d37-e450-df10-d33ae8fa25e9
applicationName=dbo-loan-issue

setGlobalProperty () {
    echo "${1} -> ${2}"
    echo "${2}" | curl -X PUT ${url}/${1}?token=${token} -d @- > /dev/null
}

setProperty () {
    echo "${1} -> ${2}"
    echo "${2}" | curl -X PUT ${url}/${applicationName}/${1}?token=${token} -d @-  > /dev/null
}

#application properties

setProperty "spring/datasource/driver-class-name" "org.postgresql.Driver"
setProperty "spring/datasource/url" "jdbc:postgresql://pg-dbo-dev-1.mbrd.ru:54326/dbo_loan-issue"
setProperty "spring/datasource/username" "postgres"
setProperty "spring/datasource/password" "=VnC5rCOEs"
setProperty "application/validateCharset" "UTF-8"
setProperty "application/adtws" "http://172.16.16.99:9100/mtsadtws/mtsadtws"
setProperty "application/techUser" "tech"
setProperty "application/techPwd" "123456Qq"
setProperty "application/smsws" "http://services-ump2-dev.mbrd.ru:8090/dbo-sms-informer/v1/"
setProperty "application/token" "NOd1zB3Bbl0HWMsupJoEy5awdzhs4Tvg"
setProperty "server/port" "8080"
setProperty "server/servlet-path" "/*"
setProperty "management/endpoints/web/exposure/include" "loggers, health, metrics"
setProperty "management/security/enabled" "false"