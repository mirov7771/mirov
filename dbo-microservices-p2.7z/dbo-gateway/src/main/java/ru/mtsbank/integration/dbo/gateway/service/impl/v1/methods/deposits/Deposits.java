package ru.mtsbank.integration.dbo.gateway.service.impl.v1.methods.deposits;

import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.request.DepositsReq;

public interface Deposits {

    BaseResponse call(DepositsReq request);

}
