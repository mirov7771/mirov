package ru.mtsbank.integration.dbo.gateway.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.Balance;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.Operations;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.deposits.Deposit;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.deposits.TermInfo;

import java.util.List;

@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DepositsRes extends BaseResponse {

    private List<Deposit> deposits;

    private String name;
    private Balance initialAmount;
    private String agreementId;
    private String delinqInfo;
    private Float actualRate;
    private String depositTerm;
    private TermInfo termInfo;
    private Balance maxPartialAmt;
    private String refundAccountNumber;

    private String clientName;
    private String accountNumber;
    private String currency;
    private String bankName;
    private String bankTIN;
    private String bankRRC;
    private String bankBIC;
    private String bankCorrAccount;

    private Operations operations;

}
