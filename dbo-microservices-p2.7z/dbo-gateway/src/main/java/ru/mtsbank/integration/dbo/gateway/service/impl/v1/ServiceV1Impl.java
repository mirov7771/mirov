package ru.mtsbank.integration.dbo.gateway.service.impl.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.request.DepositsReq;
import ru.mtsbank.integration.dbo.gateway.service.Service;
import ru.mtsbank.integration.dbo.gateway.service.impl.v1.methods.deposits.Deposits;

import java.util.Map;

@Component("v1")
public class ServiceV1Impl implements Service {

    @Autowired
    private Map<String, Deposits> deposits;

    public BaseResponse deposits(DepositsReq request){
        return deposits.get(request.getType()).call(request);
    }

}
