package ru.mtsbank.integration.dbo.gateway.controllers.dto.request;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseRequest;

@Getter @Setter
@Builder
public class DepositsReq extends BaseRequest {

    private String dateFrom;
    private String dateTo;
    private String account;

}
