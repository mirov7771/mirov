package ru.mtsbank.integration.dbo.gateway.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ApplicationConfig {

    @JsonProperty("springdoc")
    private Springdoc springdoc;

    @Data
    public static class Springdoc {
        @JsonProperty("author")
        private String author;
        @JsonProperty("title")
        private String title;
        @JsonProperty("version")
        private String version;
    }

}
