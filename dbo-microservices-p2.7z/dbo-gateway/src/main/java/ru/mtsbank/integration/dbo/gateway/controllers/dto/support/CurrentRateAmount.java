package ru.mtsbank.integration.dbo.gateway.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CurrentRateAmount {

    private BigDecimal amount;
    private String currency;
    private Date payDate;

}
