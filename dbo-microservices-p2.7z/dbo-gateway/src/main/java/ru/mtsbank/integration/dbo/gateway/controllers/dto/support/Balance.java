package ru.mtsbank.integration.dbo.gateway.controllers.dto.support;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Balance {

    private BigDecimal amount;
    private String currency;

}
