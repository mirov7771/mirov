package ru.mtsbank.integration.dbo.gateway.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.history.OperationDetails;

import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Operations {

    private String operationId;
    private Date operationDateTime;
    private Balance operationAmount;
    private OperationDetails operationDetails;

}
