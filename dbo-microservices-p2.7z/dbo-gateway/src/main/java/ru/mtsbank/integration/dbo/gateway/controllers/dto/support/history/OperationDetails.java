package ru.mtsbank.integration.dbo.gateway.controllers.dto.support.history;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OperationDetails {

    private String docId;
    private String category;
    private String direction;

}
