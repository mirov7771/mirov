package ru.mtsbank.integration.dbo.gateway.service.impl.v1.methods.deposits;

import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.request.DepositsReq;

@Component("history")
public class DepositsHistory implements Deposits {

    @Override
    public BaseResponse call(DepositsReq request) {
        return null;
    }

}
