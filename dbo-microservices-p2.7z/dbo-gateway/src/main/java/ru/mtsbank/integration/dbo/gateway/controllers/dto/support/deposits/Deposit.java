package ru.mtsbank.integration.dbo.gateway.controllers.dto.support.deposits;

import lombok.Data;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.Balance;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.support.CurrentRateAmount;

@Data
public class Deposit {

    private String name;
    private String accountNumber;
    private Boolean enableAddCash;
    private Boolean enableGetCash;
    private Balance balance;
    private CurrentRateAmount currentRateAmount;

}
