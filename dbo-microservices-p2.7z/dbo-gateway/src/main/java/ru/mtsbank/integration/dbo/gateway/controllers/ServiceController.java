package ru.mtsbank.integration.dbo.gateway.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.request.DepositsReq;
import ru.mtsbank.integration.dbo.gateway.controllers.dto.response.DepositsRes;
import ru.mtsbank.integration.dbo.gateway.service.Service;

import java.util.Map;

@Tag(name = "DboGateWay")
@RestController
@RequestMapping("dbo-gateway")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @GetMapping(value = "{version}/deposits/{account}/{type}", produces = "application/json")
    @Operation(summary = "Интерфейс для работы со вкладами"
            ,responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = DepositsRes.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    @Parameter(name = "type", schema = @Schema(type = "string", allowableValues = {"","info","details","history"}))
    public ResponseEntity<BaseResponse> deposits(@PathVariable final String version
                                                , @PathVariable(required = false) final String account
                                                , @PathVariable(required = false) final String type
                                                , @RequestParam(name = "dateFrom", required = false) final String dateFrom
                                                , @RequestParam(name = "dateTo", required = false) final String dateTo
                                                , @RequestHeader(value = "rbo_id", required = false) String rboId
                                                , @RequestHeader(value = "authorization", required = false) String authorization)
    {
        DepositsReq req = DepositsReq.builder().account(account).dateFrom(dateFrom).dateTo(dateTo).build();
        req.setType(type);
        req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).deposits(req));
    }

}