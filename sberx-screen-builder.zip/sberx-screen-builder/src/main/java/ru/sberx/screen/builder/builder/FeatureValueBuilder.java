package ru.sberx.screen.builder.builder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.dto.questionary.count.CountRes;
import ru.sberx.dto.questionary.scouting.res.ScoutingListRes;
import ru.sberx.screen.builder.dao.model.PageValuesCache;
import ru.sberx.screen.builder.dao.repository.PageValuesCacheRepository;
import ru.sberx.unity.gate.questionary.QuestionaryService;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class FeatureValueBuilder {

    private final PageValuesCacheRepository pageValuesCacheRepository;
    private final QuestionaryService questionaryService;
    private static final ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
    }

    public List<Map<String, Object>> buildValues(List<Map<String, Object>> features, String locale, String role, Long userId, String tariff){
        try {
            String jsonString = mapper.writeValueAsString(features);
            List<String> pageWords = Arrays.asList(jsonString.split(" "));
            log.info("pageWords {}", pageWords);
            if (!CollectionUtils.isEmpty(pageWords)
                    && pageWords.stream().anyMatch(i -> i.trim().startsWith("%") && i.trim().endsWith("%"))){
                List<PageValuesCache> values =
                        pageValuesCacheRepository.findByNameIn(pageWords.stream()
                                .filter(i -> i.trim().startsWith("%") && i.trim().endsWith("%"))
                                .map(String::trim)
                                .collect(Collectors.toList()));
                if (CollectionUtils.isEmpty(values))
                    return features;
                for(PageValuesCache p : values){
                    if (StringUtils.hasText(p.getValue())) {
                        String value = p.getValue();
                        switch (p.getName()) {
                            case "%startups_size%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "startups" : "стартапов", value, 0, locale);
                                break;
                            case "%startups_size_list%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "startups" : "стартапам", value, 0, locale);
                                break;
                            case "%corporations_size%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "corporates" : "корпораций", value, 1, locale);
                                break;
                            case "%investors_size%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "investors" : "инвесторов", value, 2, locale);
                                break;
                            case "%pilot_size%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "pilots" : "пилотов", value, 4, locale);
                                break;
                            case "%import_size%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "solutions" : "решениям", value, 6, locale);
                                break;
                            case "%import_size_main%":
                                value += " " + getValueName(!"ru".equalsIgnoreCase(locale) ? "solutions" : "решения", value, 7, locale);
                                break;
                            case "%available_scouting%":
                                value = getScoutingButtonValue(locale, role, userId);
                                break;
                            case "%isCorpLightText%":
                                value = getTariffValue(tariff, "CorpLight", locale);
                                break;
                            case "%isCorpLight%":
                                value = getTariffValueDisabled(tariff, "CorpLight");
                                break;
                            case "%isCorpProText%":
                                value = getTariffValue(tariff, "CorpPro", locale);
                                break;
                            case "%isCorpPro%":
                                value = getTariffValueDisabled(tariff, "CorpPro");
                                break;
                            case "%isCorpProPlusText%":
                                value = getTariffValue(tariff, "CorpProPlus", locale);
                                break;
                            case "%isCorpProPlus%":
                                value = getTariffValueDisabled(tariff, "CorpProPlus");
                                break;
                            case "%isCorpLightButton%":
                                value = getTariffValueButton(tariff, "CorpLight");
                                break;
                            case "%isCorpProButton%":
                                value = getTariffValueButton(tariff, "CorpPro");
                                break;
                            case "%isCorpProPlusButton%":
                                value = getTariffValueButton(tariff, "CorpProPlus");
                                break;
                            case "%isInvestLightText%":
                                value = getTariffValue(tariff, "InvestLight", locale);
                                break;
                            case "%isInvestLight%":
                                value = getTariffValueDisabled(tariff, "InvestLight");
                                break;
                            case "%isInvestAngelText%":
                                value = getTariffValue(tariff, "InvestAngel", locale);
                                break;
                            case "%isInvestAngel%":
                                value = getTariffValueDisabled(tariff, "InvestAngel");
                                break;
                            case "%isInvestProText%":
                                value = getTariffValue(tariff, "InvestPro", locale);
                                break;
                            case "%isInvestPro%":
                                value = getTariffValueDisabled(tariff, "InvestPro");
                                break;
                            case "%isInvestLightButton%":
                                value = getTariffValueButton(tariff, "InvestLight");
                                break;
                            case "%isInvestAngelButton%":
                                value = getTariffValueButton(tariff, "InvestAngel");
                                break;
                            case "%isInvestProButton%":
                                value = getTariffValueButton(tariff, "InvestPro");
                                break;
                        }
                        if (p.getName().startsWith("%is")) {
                            jsonString = jsonString.replace(" " + p.getName() + " ", p.getName());
                        }
                        jsonString = jsonString.replace(p.getName(), value);
                    }
                }
                CompletableFuture.runAsync(() -> updateCache(values));
                if (jsonString.contains("\"disabled\":\"false\""))
                    jsonString = jsonString.replace("\"disabled\":\"false\"", "\"disabled\": false");
                if (jsonString.contains("\"disabled\":\"true\""))
                    jsonString = jsonString.replace("\"disabled\":\"true\"", "\"disabled\": true");
                return mapper.readValue(jsonString, new TypeReference<List<Map<String, Object>>>() {});
            } else {
                return features;
            }
        } catch (Exception e){
            log.error("Exception: ", e);
        }
        return features;
    }

    private String getTariffValueDisabled(String role, String tariff) {
        if (StringUtils.hasText(role) && role.equalsIgnoreCase(tariff))
            return "true";
        return "false";
    }

    private String getTariffValueButton(String role, String tariff) {
        if (StringUtils.hasText(role) && role.equalsIgnoreCase(tariff))
            return "buttonNinja";
        return "buttonPopup";
    }

    private String getTariffValue(String role, String tariff, String locale) {
        if (StringUtils.hasText(role) && role.equalsIgnoreCase(tariff))
            return "ru".equalsIgnoreCase(locale) ? "Текущий тариф" : "Current tariff";
        return "ru".equalsIgnoreCase(locale) ? "Выбрать тариф" : "Choose a tariff";
    }

    private String getScoutingButtonValue(String locale, String role, Long userId) {
        if (StringUtils.hasText(role)){
            if (!"CorpProPlus".equalsIgnoreCase(role))
                return "";
            String value = "ru".equalsIgnoreCase(locale) ? "Вам доступен скаутинг size бесплатно" : "Scouting available to you size  requests for free";
            try {
                ScoutingListRes scoutingList = questionaryService.getScoutingList(List.of(20002L, 20012L, 20015L), userId);
                if (scoutingList != null) {
                    if (CollectionUtils.isEmpty(scoutingList.getList()))
                        return "";
                    if (scoutingList.getList().size() > 3)
                        return "";
                    String size = scoutingList.getList().size() + "";
                    if ("ru".equalsIgnoreCase(locale)){
                        if (size.equals("1"))
                            size = "1-й потребности";
                        else
                            size = size + "-х потребностей";
                    }
                    return value.replace("size", size);
                }
            } catch (Exception e) {
                log.error("Error getting scouting size: ", e);
                return "";
            }
            return value;
        }
        return "";
    }

    private void updateCache(List<PageValuesCache> values){
        log.info("start async {}", values);
        for(PageValuesCache p : values){
            if (StringUtils.hasText(p.getValue())) {
                String value;
                if (p.getCacheTime() == null || p.getCacheTime().before(new Date())) {
                    p.setCacheTime(getDaysDiff(p.getCachePeriod()));
                    CountRes res;
                    switch (p.getMethod()) {
                        case "/reply":
                            res = questionaryService.count(5);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                        case "/list/round":
                            res = questionaryService.count(4);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                        case "/list/questionnaire?type=0":
                            res = questionaryService.count(0);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                        case "/list/questionnaire?type=1":
                            res = questionaryService.count(1);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                        case "/list/questionnaire?type=2":
                            res = questionaryService.count(2);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                        case "/list/pilots":
                            res = questionaryService.count(3);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                        case "/list/questionnaire?type=0&isImport=true":
                            res = questionaryService.count(6);
                            value = String.valueOf(res != null && res.getCount() != null ? res.getCount() : 0);
                            p.setValue(value);
                            break;
                    }
                    log.info("save {}", p);
                    pageValuesCacheRepository.save(p);
                }
            }
        }
    }

    private Date getDaysDiff(Integer amount){
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.add(Calendar.MINUTE, amount);
        return dateCalendar.getTime();
    }

    private String getValueName(String defaultValue, String value, Integer type, String locale){
        if (!"ru".equalsIgnoreCase(locale))
            return defaultValue;
        boolean first_declension = value.endsWith("1");
        boolean second_declension = value.endsWith("11") || value.endsWith("13") || value.endsWith("14");
        boolean second_declension_extra = value.endsWith("0") || value.endsWith("11")
                || value.endsWith("12")
                || value.endsWith("13")
                || value.endsWith("14")
                || value.endsWith("15")
                || value.endsWith("16")
                || value.endsWith("17")
                || value.endsWith("18")
                || value.endsWith("19")
                || value.endsWith("20");
        boolean third_declension = value.endsWith("2") || value.endsWith("3") || value.endsWith("4");
        if (type.equals(0)){
            if (Boolean.TRUE.equals(second_declension))
                return defaultValue;
            if (Boolean.TRUE.equals(first_declension))
                return "стартап";
            if (Boolean.TRUE.equals(third_declension))
                return "стартапа";
        } else if (type.equals(1)) {
            if (Boolean.TRUE.equals(second_declension))
                return defaultValue;
            if (Boolean.TRUE.equals(first_declension))
                return "корпорация";
            if (Boolean.TRUE.equals(third_declension))
                return "корпорации";
        } else if (type.equals(2)) {
            if (Boolean.TRUE.equals(second_declension))
                return defaultValue;
            if (Boolean.TRUE.equals(first_declension))
                return "инвестор";
            if (Boolean.TRUE.equals(third_declension))
                return "инвестора";
        } else if (type.equals(4)) {
            if (Boolean.TRUE.equals(second_declension))
                return defaultValue;
            if (Boolean.TRUE.equals(first_declension))
                return "пилот";
            if (Boolean.TRUE.equals(third_declension))
                return "пилота";
        } else if (type.equals(6)) {
            if (Boolean.TRUE.equals(second_declension))
                return defaultValue;
            if (Boolean.TRUE.equals(first_declension))
                return "решению";
            if (Boolean.TRUE.equals(third_declension))
                return defaultValue;
        } else if (type.equals(7)) {
            if (Boolean.TRUE.equals(first_declension))
                return "решение";
            if (Boolean.TRUE.equals(second_declension))
                return "решений";
            if (Boolean.TRUE.equals(second_declension_extra))
                return "решений";
            if (Boolean.TRUE.equals(third_declension))
                return defaultValue;

        }
        return defaultValue;
    }

}
