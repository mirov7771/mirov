package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.WidgetDao;

@Repository
public interface FeatureDaoRepository extends CrudRepository<WidgetDao, Long> {
}
