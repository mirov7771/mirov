package ru.sberx.screen.builder.dao.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.util.StringUtils;
import ru.sberx.dto.screen.builder.widget.support.WidgetDto;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Map;

@Entity
@Table(name = "FEATURE")
@Getter
@Setter
@NoArgsConstructor
public class WidgetDao implements Serializable {

    private static final long serialVersionUID = -769442127568499925L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "FORM_NAME")
    private String formName;
    @Column(name = "VISIBLE")
    private Boolean visible;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "CONFIG")
    private String config;

    public WidgetDao(WidgetDto req) {
        if (req.getId() != null)
            this.id = req.getId();
        this.formName = req.getFormName();
        this.visible = req.getVisible();
        this.type = req.getType();
        this.config = req.getLink();
    }

    public WidgetDto convertToDto() {
        WidgetDto f = new WidgetDto();
        f.setId(this.id);
        f.setFormName(this.formName);
        f.setVisible(this.visible);
        f.setType(this.type);
        if (StringUtils.hasText(this.config))
            f.setConfig(Map.of("link", this.config));
        return f;
    }

}
