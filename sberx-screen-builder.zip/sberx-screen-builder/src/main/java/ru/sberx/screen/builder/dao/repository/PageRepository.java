package ru.sberx.screen.builder.dao.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.custom.CustomRepository;
import ru.sberx.screen.builder.dao.model.PageDao;

@Repository
public interface PageRepository extends CrudRepository<PageDao, Long>, CustomRepository {
    @Query("from PageDao where uri = :uri and type = :pageType and langId = :langId")
    List<PageDao> findByUriAndPageTypeAndLangId(String uri, String pageType, Long langId);
}
