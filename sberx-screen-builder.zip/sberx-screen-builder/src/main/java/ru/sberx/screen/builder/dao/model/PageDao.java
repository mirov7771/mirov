package ru.sberx.screen.builder.dao.model;

import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import ru.sberx.dto.screen.builder.structure.page.support.PageDto;
import ru.sberx.screen.builder.dao.model.jsonb.Feature;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "pages")
@Entity
@Getter
@Setter
@NoArgsConstructor
@TypeDef(name = "json", typeClass = JsonStringType.class)
public class PageDao implements Serializable {

    private static final long serialVersionUID = 4808194501822914399L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "CODE")
    private String code;
    @Column(name = "NAME")
    private String name;
    @Column(name = "URI", nullable = false)
    private String uri;
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "PAGE_TYPE")
    private String type;
    @Type(type = "json")
    @Column(name = "PAGE", columnDefinition = "json")
    private Feature page;
    @Column(name = "LANG_ID")
    private Long langId;

}