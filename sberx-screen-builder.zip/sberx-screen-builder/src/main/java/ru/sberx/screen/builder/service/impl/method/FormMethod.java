package ru.sberx.screen.builder.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.screen.builder.form.req.FormReq;
import ru.sberx.dto.screen.builder.form.res.FormRes;
import ru.sberx.dto.screen.builder.form.support.ModuleDto;
import ru.sberx.screen.builder.dao.model.LangDao;
import ru.sberx.screen.builder.dao.model.Screen;
import ru.sberx.screen.builder.dao.repository.LangRepository;
import ru.sberx.screen.builder.dao.repository.ScreenRepository;

import java.util.List;
import java.util.OptionalInt;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class FormMethod {

    private final ScreenRepository screenRepository;
    private final LangRepository langRepository;

    public List<FormRes> execute(FormReq req) {
        Pageable sz = PageRequest.of(0, 1);
        LangDao locale = langRepository.findByLocale(req.getLocale());
        List<Screen> screens = screenRepository.findByTypeAndFormNameAndLangId(req.getType(), req.getName(), locale.getId(), sz);
        return screens.stream().map(screen -> {
            FormRes form = new FormRes();
            form.setFormName(screen.getFormName());
            form.setType(screen.getType());
            form.setDescription(screen.getDescription());
            form.setPages(screen.getPages());
            form.setName(screen.getName());
            form.setLogoFile(screen.getLogoFile());
            form.setSecondOfferDescription(screen.getSecondOfferDescription());
            form.setOfferDescription(screen.getOfferDescription());
            form.setInfo(screen.getInfo());
            if (Integer.valueOf(1).equals(req.getAction())) {
                if (screen.getFormView() != null) {
                    form.setForm(screen.getFormView().getForm());
                    if (screen.getFormView().getVerify() != null)
                        form.setVerify(screen.getFormView().getVerify());
                    form.setPages(getPagesCount(screen.getFormView().getForm(), screen.getPages()));
                }
            } else if (Integer.valueOf(2).equals(req.getAction())) {
                if (screen.getFormEdit() != null) {
                    form.setForm(screen.getFormEdit().getForm());
                    if (screen.getFormEdit().getVerify() != null)
                        form.setVerify(screen.getFormEdit().getVerify());
                    form.setPages(getPagesCount(screen.getFormEdit().getForm(), screen.getPages()));
                }
            }
            if (screen.getButton() != null
                    && screen.getButton().getButtons() != null
                    && screen.getButton().getButtons().size() > 0) {
                form.setButtons(screen.getButton().getButtons());
            }
            return form;
        }).collect(Collectors.toList());
    }

    private Integer getPagesCount(List<ModuleDto> form, Integer pages) {
        if (!CollectionUtils.isEmpty(form)){
            List<ModuleDto> list = form.stream().filter(i -> i.getPage() != null).collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(list)) {
                OptionalInt max = list.stream().mapToInt(ModuleDto::getPage).max();
                if (max.isPresent())
                    return max.getAsInt();
            }
        }
        return pages;
    }

}