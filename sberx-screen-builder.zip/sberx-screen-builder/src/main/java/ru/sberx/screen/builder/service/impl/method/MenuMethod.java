package ru.sberx.screen.builder.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.screen.builder.menu.req.MenuReq;
import ru.sberx.dto.screen.builder.menu.res.MenuRes;
import ru.sberx.screen.builder.dao.model.ClientMenu;
import ru.sberx.screen.builder.dao.repository.ClientMenuRepository;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Component
@RequiredArgsConstructor
public class MenuMethod {

    private final ClientMenuRepository clientMenuRepository;

    public List<MenuRes> execute(MenuReq req) {
        List<ClientMenu> menu = getClientMenuFromRepository(req);
        List<MenuRes> res = fillResponse(menu, req.getId());
        modifyResponseForMenuTypes(req, res);
        return res;
    }

    private List<ClientMenu> getClientMenuFromRepository(MenuReq req) {
        //use ELSE IF instead of CASE here
        if (req.getName() != null && req.getName().equals("sidebar")) {
            if (!StringUtils.hasText(req.getRole())) {
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
            }
            return clientMenuRepository.findAllByTypeAndMenuTypeAndUserRoleOrderById(
                    req.getType(),
                    req.getName(),
                    req.getRole());
        } else {
            return clientMenuRepository.findAllByTypeAndMenuTypeOrderById(
                    req.getType(),
                    req.getName());
        }
    }

    private List<MenuRes> fillResponse(List<ClientMenu> cl, Long id) {
        List<MenuRes> res = new ArrayList<>();
        boolean withPriority = true;
        if (cl != null && !cl.isEmpty()) {
            for(ClientMenu clientMenu : cl) {
                MenuRes r = new MenuRes();
                r.setId(clientMenu.getId());
                r.setName(clientMenu.getName());
                r.setSysname(clientMenu.getSysname());
                String action = clientMenu.getAction();
                if (id != null && action.endsWith("&id="))
                    action += id;
                r.setAction(action);
                r.setMethod(clientMenu.getMethod());
                r.setLogoFile(clientMenu.getLogoFile());
                r.setUi(clientMenu.getUi());
                r.setIsDefault(clientMenu.getIsDefault());
                r.setPriority(clientMenu.getPriority());
                if (clientMenu.getPriority() == null)
                    withPriority = false;
                r.setLock(clientMenu.getLock());
                res.add(r);
            }
        }
        if (withPriority)
            res.sort(Comparator.comparing(MenuRes::getPriority));
        return res;
    }

    private void modifyResponseForMenuTypes(MenuReq req, List<MenuRes> res) {
        //use ELSE IF instead of CASE here
        if (req.getName() != null && req.getName().equals("sidebar")) {
            modifyResponseForSidebars(res);
        }
    }

    private void modifyResponseForSidebars(List<MenuRes> res) {
        long count = 1L;
        for (MenuRes r: res) {
            r.setId(count++);
        }
    }

}
