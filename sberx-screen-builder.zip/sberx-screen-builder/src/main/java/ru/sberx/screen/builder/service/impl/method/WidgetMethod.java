package ru.sberx.screen.builder.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.IterableUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.dto.questionary.questionary.questionary.req.DraftReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetListRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetRes;
import ru.sberx.dto.screen.builder.widget.support.WidgetDto;
import ru.sberx.screen.builder.dao.model.WidgetDao;
import ru.sberx.screen.builder.dao.repository.FeatureDaoRepository;
import ru.sberx.unity.gate.questionary.QuestionaryService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class WidgetMethod {

    private final FeatureDaoRepository featureDaoRepository;
    private final QuestionaryService questionaryService;

    public WidgetListRes features(Long userId, String location) {
        WidgetListRes res = new WidgetListRes();
        List<WidgetDao> features = IterableUtils.toList(featureDaoRepository.findAll());
        if (features.size() > 0)
            res.setFeatures(features.stream().map(WidgetDao::convertToDto).collect(Collectors.toList()));

        if (userId != null && StringUtils.hasText(location) &&
                (location.contains("import-substitution") || location.contains("pilots"))){
            List<TypeRes> type = questionaryService.getTypeByUserId(userId);
            if (!CollectionUtils.isEmpty(type)
                    && type.stream().allMatch(i -> i.getType().equals(0))){
                List<TypeRes> approveList = type.stream().filter(i -> i.getState().equals(20004L)).collect(Collectors.toList());
                Long id = CollectionUtils.isEmpty(approveList) ? type.get(0).getQuestionnaireId() : approveList.get(0).getQuestionnaireId();
                WidgetDto dto = new WidgetDto();
                dto.setId(777L);
                dto.setFormName("importSubstitution");
                dto.setVisible(true);
                dto.setType("banner");
                dto.setConfig(Map.of("link", "/view?type=0&action=2&name=import_create&id=" + id, "closed", location.contains("pilots")));
                if (type.stream().allMatch(i -> i.getIsImport() == null)){
                    if (CollectionUtils.isEmpty(res.getFeatures()))
                        res.setFeatures(new ArrayList<>());
                    res.getFeatures().add(dto);
                } else if (type.stream().anyMatch(i -> Boolean.FALSE.equals(i.getIsImport())) && !location.contains("pilots")){
                    if (CollectionUtils.isEmpty(res.getFeatures()))
                        res.setFeatures(new ArrayList<>());
                    res.getFeatures().add(dto);
                }
            }
        }
        return res;

    }

    public WidgetRes featureSave(WidgetDto req) {
        WidgetDao save = featureDaoRepository.save(new WidgetDao(req));
        WidgetRes res = new WidgetRes();
        res.setId(save.getId());
        return res;
    }

    public void featureDelete(Long id) {
        featureDaoRepository.deleteById(id);
    }

    public void featureUpdate(WidgetDto req) {
        featureDaoRepository.save(new WidgetDao(req));
    }
}
