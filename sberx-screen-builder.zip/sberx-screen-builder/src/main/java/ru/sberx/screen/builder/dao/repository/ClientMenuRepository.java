package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.ClientMenu;

import java.util.List;

@Repository
public interface ClientMenuRepository extends CrudRepository<ClientMenu, Long> {
    List<ClientMenu> findAllByTypeAndMenuTypeOrderById(Integer type, String menuType);
    List<ClientMenu> findAllByTypeAndMenuTypeAndUserRoleOrderById(Integer type, String menuType, String role);
}
