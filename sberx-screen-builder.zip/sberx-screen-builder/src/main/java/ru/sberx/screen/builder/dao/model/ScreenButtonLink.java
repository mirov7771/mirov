package ru.sberx.screen.builder.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SCREEN_BUTTONS_LINK")
@Getter
@Setter
public class ScreenButtonLink implements Serializable {

    private static final long serialVersionUID = 2020046539967276483L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "SCREEN_ID")
    private Long screenId;
    @Column(name = "BUTTON_ID")
    private Long buttonId;

}
