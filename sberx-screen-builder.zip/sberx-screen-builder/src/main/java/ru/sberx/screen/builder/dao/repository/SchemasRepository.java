package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.Schemas;

@Repository
public interface SchemasRepository extends CrudRepository<Schemas, String> {
    Schemas findByName(String name);
}
