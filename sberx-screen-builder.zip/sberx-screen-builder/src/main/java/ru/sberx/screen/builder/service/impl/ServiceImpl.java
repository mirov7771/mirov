package ru.sberx.screen.builder.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.screen.builder.button.res.ButtonRes;
import ru.sberx.dto.screen.builder.form.req.FormReq;
import ru.sberx.dto.screen.builder.form.res.FormRes;
import ru.sberx.dto.screen.builder.menu.req.MenuReq;
import ru.sberx.dto.screen.builder.menu.res.MenuRes;
import ru.sberx.dto.screen.builder.structure.page.req.GetFullPageReq;
import ru.sberx.dto.screen.builder.structure.page.res.GetFullPageRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetListRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetRes;
import ru.sberx.dto.screen.builder.widget.support.WidgetDto;
import ru.sberx.screen.builder.service.Service;
import ru.sberx.screen.builder.service.impl.method.*;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ServiceImpl implements Service {

    private final MenuMethod menuMethod;
    private final FormMethod formMethod;
    private final ButtonMethod buttonMethod;
    private final PageMethod pageMethod;
    private final WidgetMethod widgetMethod;

    @Override
    public List<MenuRes> menu(MenuReq req) {
        if (req.getType() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "type");
        return menuMethod.execute(req);
    }

    @Override
    public List<FormRes> form(FormReq req) {
        if (req.getType() == null || req.getAction() == null || req.getName() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "type || action || name");
        return formMethod.execute(req);
    }

    @Override
    public ButtonRes getButtons(String name, Integer type, Long userId, String role, String sessionId, Long id, String uid, String locale) {
        return buttonMethod.execute(name, type, userId, role, sessionId, id, uid, locale);
    }

    @Override
    public GetFullPageRes getFullPage(GetFullPageReq req) {
        return pageMethod.getFullPage(req);
    }

    @Override
    public WidgetListRes widgets(Long userId, String location) {
        return widgetMethod.features(userId, location);
    }

    @Override
    public WidgetRes widgetSave(WidgetDto req) {
        return widgetMethod.featureSave(req);
    }

    @Override
    public void widgetDelete(Long id) {
        widgetMethod.featureDelete(id);
    }

    @Override
    public void widgetUpdate(WidgetDto req) {
        widgetMethod.featureUpdate(req);
    }

}
