package ru.sberx.screen.builder.dao.model.jsonb;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class Feature {
    private List<Map<String, Object>> features;
}
