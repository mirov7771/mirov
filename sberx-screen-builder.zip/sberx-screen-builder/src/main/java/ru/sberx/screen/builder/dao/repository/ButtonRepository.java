package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.ButtonDao;

import java.util.List;

@Repository
public interface ButtonRepository extends CrudRepository<ButtonDao, Long> {
    List<ButtonDao> findByIdInAndLangId(List<Long> ids, Long langId);
}
