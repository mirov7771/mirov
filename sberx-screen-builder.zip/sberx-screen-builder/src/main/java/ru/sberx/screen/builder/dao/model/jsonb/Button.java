package ru.sberx.screen.builder.dao.model.jsonb;

import java.util.List;
import java.util.Map;
import lombok.Data;

@Data
public class Button {
    private List<Map<String, Object>> buttons;
}
