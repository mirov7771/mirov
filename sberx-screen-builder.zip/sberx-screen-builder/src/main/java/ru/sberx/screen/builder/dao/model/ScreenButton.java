package ru.sberx.screen.builder.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SCREEN_BUTTON")
@Getter
@Setter
public class ScreenButton implements  Serializable{

    private static final long serialVersionUID = 2020046539967276483L;

    @Id
    @Column(name = "SCREEN_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "NAME")
    private String name;
    @Column(name = "ADMIN_CHECK")
    private Boolean adminCheck;
    @Column(name = "MAIN_CHECK")
    private Boolean mainCheck;
    @Column(name = "PARENT_CHECK")
    private Boolean parentCheck;
    @Column(name = "SUCCESS_PILOT_CHECK")
    private Boolean successPilotCheck;
    @Column(name = "OWNER_CHECK")
    private Boolean ownerCheck;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "FAVORITE")
    private Boolean favorite;
    @Column(name = "investor_check")
    private Boolean investorCheck;
    @Column(name = "active_round_check")
    private Boolean activeRoundCheck;
    @Column(name = "future_round_check")
    private Boolean futureRoundCheck;
}
