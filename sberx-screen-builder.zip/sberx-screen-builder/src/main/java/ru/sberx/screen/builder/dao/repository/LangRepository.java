package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.LangDao;

@Repository
public interface LangRepository extends CrudRepository<LangDao, Long> {
    LangDao findByLocale(String locale);
}
