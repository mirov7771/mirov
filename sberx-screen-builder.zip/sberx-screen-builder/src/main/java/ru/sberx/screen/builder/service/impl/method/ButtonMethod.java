package ru.sberx.screen.builder.service.impl.method;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.questionary.pilot.req.PilotListReq;
import ru.sberx.dto.questionary.questionary.pilot.res.PilotListRes;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.questionary.questionary.round.req.RoundListReq;
import ru.sberx.dto.questionary.questionary.round.res.RoundListRes;
import ru.sberx.dto.questionary.questionary.round.support.RoundDto;
import ru.sberx.dto.screen.builder.button.res.ButtonRes;
import ru.sberx.dto.screen.builder.button.support.ButtonDto;
import ru.sberx.dto.screen.builder.custom.QuestionnaireDtoCustom;
import ru.sberx.screen.builder.dao.model.ButtonDao;
import ru.sberx.screen.builder.dao.model.LangDao;
import ru.sberx.screen.builder.dao.model.ScreenButton;
import ru.sberx.screen.builder.dao.model.ScreenButtonLink;
import ru.sberx.screen.builder.dao.repository.ButtonRepository;
import ru.sberx.screen.builder.dao.repository.LangRepository;
import ru.sberx.screen.builder.dao.repository.ScreenButtonLinkRepository;
import ru.sberx.screen.builder.dao.repository.ScreenButtonRepository;
import ru.sberx.unity.gate.questionary.QuestionaryService;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class ButtonMethod {

    private final ScreenButtonLinkRepository screenButtonLinkRepository;
    private final ButtonRepository buttonRepository;
    private final ScreenButtonRepository screenButtonRepository;
    private final LangRepository langRepository;
    private static final Map<Integer, List<Map<Integer, Map<String, String>>>> CUSTOM_BUTTONS = new HashMap<>();
    private final QuestionaryService questionaryService;

    private final List<RoundDto> roundList = new ArrayList<>();

    private static final Set<String> ADMIN_ROLE = new HashSet<>();

    static {
        ADMIN_ROLE.add("SberbankEmployee");
        ADMIN_ROLE.add("Administrator");

        CUSTOM_BUTTONS.put(7, List.of
                (
                        Map.of(20002, Map.of("ru", "В работу", "en", "To work")),
                        Map.of(20003, Map.of("ru", "Пауза", "en", "Pause")),
                        Map.of(20004, Map.of("ru", "Пилотировать", "en", "Pilot")),
                        Map.of(20009, Map.of("ru", "Отказ", "en", "Decline")),
                        Map.of(20011, Map.of("ru", "Новый", "en", "New"))
                )
        );
    }

    public ButtonRes execute(String name, Integer type, Long userId, String role, String sessionId, Long id, String uid, String locale) {
        if (name == null && type == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "name , type");
        QuestionnaireDtoCustom object = type.equals(10) ? questionaryService.getMainObject(id, userId, sessionId, "/round") : null;
        String formName = getFormName(name, type, role, object != null && Boolean.TRUE.equals(object.getInvestment()));
        ButtonRes res = new ButtonRes();
        if (formName == null)
            return res;
        LangDao localeDao = langRepository.findByLocale(locale);
        List<TypeRes> extTypes = null;
        if (localeDao != null
                && localeDao.getId() != null)
        {
            try {
                if (Boolean.TRUE.equals(findObject(type)) && id != null) {
                    if (formName.endsWith("_app_Administrator")) {
                        object = questionaryService.getMainObject(id, null, null, "/application");
                    } else if (formName.startsWith("round")) {
                        if (object == null)
                            object = questionaryService.getMainObject(id, null, sessionId, "/round");
                    } else if (formName.startsWith("reply") || formName.startsWith("offer")) {
                        object = questionaryService.getMainObject(null, null, null, "/reply/" + id);
                        log.info("Object {}", object);
                        if (object != null
                                && object.getUserId() != null
                                && !(object.getUserId() instanceof List)) {
                            if (object.getState() == null)
                                object.setState(20011L);
                            if (object.getQuestionnaire() != null)
                                object.getQuestionnaire().setState(object.getState());
                            extTypes = questionaryService.getTypeByUserId(castToLong(object.getUserId()));
                        }
                    } else if (formName.contains("pilot")){
                        object = questionaryService.getMainObject(null, userId, null, "/pilot/" + id);
                        if (object != null && object.getState() != null && object.getQuestionnaire() != null)
                            object.getQuestionnaire().setState(object.getState());
                    } else if (formName.contains("community")){
                        object = questionaryService.getMainObject(id, null, null, "/community");
                    } else if (formName.contains("syndicate")){
                        object = questionaryService.getMainObject(id, null, null, "/syndicate");
                    } else {
                        object = questionaryService.getMainObject(id, userId, null, "/questionary");
                        if (object != null && object.getQuestionnaire() != null && object.getQuestionnaire().getFavorite() != null)
                            object.setFavorite(Boolean.TRUE.equals(object.getQuestionnaire().getFavorite()));
                    }
                }
            } catch (Exception e){
                e.printStackTrace();
            }

            Long state = object != null ?
                    (object.getQuestionnaire() != null
                            ? (object.getQuestionnaire().getState() == null
                            ? object.getState()
                            : object.getQuestionnaire().getState())
                            : object.getState())
                    : null;
            log.info("State {}", state);
            log.info("Object {}", object);
            List<TypeRes> types = null;
            Boolean isOwnerFlag = false;
            Integer qType = 0;
            log.info("state {}", state);
            log.info("formName {}", formName);
            List<Screen> s = getList(formName.equalsIgnoreCase("offer_SuperClient") ? "reply_SuperClient" : formName, state, localeDao.getId());

            if (object != null && userId != null && s.stream().anyMatch(i -> Boolean.TRUE.equals(i.getOwnerCheck()) || Boolean.TRUE.equals(i.getFavorite()))) {
                types = questionaryService.getTypeByUserId(userId);
                isOwnerFlag = isOwner(types, object.getQuestionnaireId() != null ? object.getQuestionnaireId() : id);
                if (!CollectionUtils.isEmpty(types)
                        && formName.contains("corporate")
                        && !Boolean.TRUE.equals(isOwnerFlag))
                    qType = types.get(0).getType();
            }

            List<ButtonDto> buttons = new ArrayList<>();
            Long oId = !CollectionUtils.isEmpty(extTypes) ? extTypes.get(0).getQuestionnaireId() : null;
            String oUid = !CollectionUtils.isEmpty(extTypes) ? extTypes.get(0).getUid() : null;
            Long objectId = object != null ? (object.getQuestionnaire() != null
                    ? object.getQuestionnaire().getQuestionnaireId()
                    : object.getQuestionnaireId()) : null;
            String uuid = object != null ? (object.getQuestionnaire() != null
                    ? object.getQuestionnaire().getUuid()
                    : object.getUuid()) : null;

            if (s.size() > 0) {
                for(Screen b : s) {
                    if (b.getButtons() == null || b.getButtons().size() == 0)
                        continue;
                    if (!isAdminCheck(b.getAdminCheck(), userId, role))
                        continue;
                    if (!isMainCheck(b.getMainCheck(), object))
                        continue;
                    if (!isOwnerCheck(b.getOwnerCheck(), isOwnerFlag))
                        continue;
                    if (!isParentCheck(b.getParentCheck(), object))
                        continue;
                    if (!isSuccessPilotCheck(b.getSuccessPilotCheck(), id))
                        continue;
                    if (object != null && !isFavorite(types, b.getFavorite(), Boolean.TRUE.equals(object.getFavorite()), formName))
                        continue;
                    log.info("start check investor {}", b);
                    if (!isInvestorCheck(b.getInvestorCheck(), userId))
                        continue;
                    log.info("start check active round {}", b);
                    if (!isRoundCheck(b.getActiveRoundCheck(), false, id))
                        continue;
                    log.info("start check plan round {}", b);
                    if (!isRoundCheck(b.getFutureRoundCheck(), true, id))
                        continue;
                    buttons.addAll(b.getButtons().stream().map(i -> i.convertToDto(
                            i.getCode().equals(100000) ? oUid : uid,
                            i.getCode().equals(100000) ? oId : id,
                            state,
                            formName, objectId, uuid)).collect(Collectors.toList()));
                }
            }
            if (buttons.size() > 0) {
                List<TypeRes> userTypes = userId != null ? questionaryService.getTypeByUserId(userId) : null;
                if (qType.equals(1))
                    res.setButtons(buttons.stream().filter(i -> !i.getCode().equals(100001)).distinct().collect(Collectors.toList()));
                else
                    res.setButtons(buttons.stream().distinct().collect(Collectors.toList()));

                if (!CollectionUtils.isEmpty(userTypes)) {
                    if (res.getButtons().stream().anyMatch(i -> i.getCode().equals(100003))
                            && (type.equals(0) || type.equals(1) || type.equals(2))
                            && !userTypes.get(0).getQuestionnaireId().equals(id)) {
                        res.setButtons(res.getButtons().stream().filter(i -> !i.getCode().equals(100003)).collect(Collectors.toList()));
                    }

                    if (type.equals(7) && !Integer.valueOf(1).equals(userTypes.get(0).getType()))
                        return new ButtonRes();
                }
                renameButtons(type, res.getButtons(), StringUtils.hasText(locale) ? locale : "ru");
                if (type.equals(10))
                    res.getButtons().sort(Comparator.comparing(ButtonDto::getCode));
                if (type.equals(7))
                    swapList(res.getButtons(), state);

                res.getButtons().forEach(i -> {
                    if (!CollectionUtils.isEmpty(this.roundList) && (i.getCode().equals(30001)
                            || i.getCode().equals(30002))){
                        Optional<RoundDto> round = Optional.empty();
                        if (i.getCode().equals(30001)) {
                            round = this.roundList.stream().filter(r -> Boolean.TRUE.equals(r.getInvestment())).findFirst();
                        } else {
                            round = this.roundList.stream().filter(r -> !Boolean.TRUE.equals(r.getInvestment())).findFirst();
                        }
                        round.ifPresent(roundDto -> {
                            i.setId(roundDto.getRoundId());
                            i.setClickMethod("GET");
                            i.setClickAction("/main/investment/" + roundDto.getRoundId());
                            i.setUid(null);
                        });
                    }
                });
            } else {
                res.setButtons(new ArrayList<>());
            }
        } else {
            res.setButtons(new ArrayList<>());
        }
        return res;
    }

    private void swapList(List<ButtonDto> buttons, Long state) {
        if (state != null && buttons.stream().anyMatch(i -> i.getCode().equals(state.intValue()))){
            ButtonDto item = null;
            for(ButtonDto i : buttons) {
                if (i.getCode() != null && i.getCode().equals(state.intValue())) {
                    item = i;
                    break;
                }
            }
            if (item != null){
                buttons.remove(item);
                buttons.add(1, item);
            }
        }
    }

    private void renameButtons(Integer type, List<ButtonDto> buttons, String locale) {
        if (CUSTOM_BUTTONS.get(type) != null) {
            for(ButtonDto dto : buttons){
                CUSTOM_BUTTONS.get(type).forEach(i -> {
                    if (i.get(dto.getCode()) != null && StringUtils.hasText(i.get(dto.getCode()).get(locale))) {
                        dto.setText(i.get(dto.getCode()).get(locale));
                    }
                });
            }
        }
    }

    private Boolean isAdminCheck(Boolean adminCheck, Long userId, String role) {
        if (adminCheck == null)
            return true;
        if (Boolean.TRUE.equals(adminCheck) && userId == null && !StringUtils.hasText(role))
            return false;
        if (Boolean.TRUE.equals(adminCheck) && ADMIN_ROLE.contains(role))
            return true;
        if (Boolean.TRUE.equals(adminCheck) && !ADMIN_ROLE.contains(role))
            return false;
        if (Boolean.FALSE.equals(adminCheck) && userId == null && !StringUtils.hasText(role))
            return true;
        return !Boolean.FALSE.equals(adminCheck) || !ADMIN_ROLE.contains(role);
    }

    private Boolean isMainCheck(Boolean isMain, QuestionnaireDtoCustom object) {
        if (isMain == null)
            return true;
        if (object == null || object.getQuestionnaire() == null)
            return false;
        if (Boolean.TRUE.equals(isMain) && (object.getQuestionnaire().getParentId() == null || object.getQuestionnaire().getParentId().equals(0L)))
            return true;
        if (Boolean.FALSE.equals(isMain) && (object.getQuestionnaire().getParentId() == null || object.getQuestionnaire().getParentId().equals(0L)))
            return false;
        return !Boolean.TRUE.equals(isMain) || object.getQuestionnaire().getParentId() == null || object.getQuestionnaire().getParentId().equals(0L);
    }

    private Boolean isOwnerCheck(Boolean isOwnerFlag, Boolean isOwnerFlagMain){
        if (isOwnerFlag == null)
            return true;
        return isOwnerFlag.equals(isOwnerFlagMain);
    }

    private Boolean isParentCheck(Boolean isParent, QuestionnaireDtoCustom object) {
        if (isParent == null)
            return true;
        if (object == null)
            return false;
        if (Boolean.TRUE.equals(isParent) && Boolean.TRUE.equals(object.getIsChild()))
            return true;
        if (Boolean.TRUE.equals(isParent) && !Boolean.TRUE.equals(object.getIsChild()))
            return false;
        return !Boolean.FALSE.equals(isParent) || !Boolean.TRUE.equals(object.getIsChild());
    }

    private Boolean isSuccessPilotCheck(Boolean isSuccessPilot, Long id){
        if (isSuccessPilot == null)
            return true;
        if (id == null)
            return false;
        if (Boolean.TRUE.equals(isSuccessPilot)){
            PilotListReq req = new PilotListReq();
            req.setId(String.valueOf(id));
            PilotListRes pilotsList = questionaryService.getPilotsList(req);
            return pilotsList != null && pilotsList.getList() != null && pilotsList.getList().size() > 0;
        }
        return true;
    }

    private Boolean isInvestorCheck(Boolean isInvestor, Long userId){
        if (isInvestor == null)
            return true;
        if (userId == null)
            return false;
        List<TypeRes> types = questionaryService.getTypeByUserId(userId);
        if (CollectionUtils.isEmpty(types))
            return false;
        return types.stream().anyMatch(i -> i.getType().equals(2));
    }

    private Boolean isRoundCheck(Boolean flag, Boolean plan, Long id){
        if (flag == null)
            return true;
        if (id == null)
            return false;
        RoundListReq req = new RoundListReq();
        req.setQuestionnaireId(id);
        req.setState(List.of(20004L));
        RoundListRes roundList = questionaryService.getRoundList(req);
        if (roundList == null || CollectionUtils.isEmpty(roundList.getList()))
            return false;
        this.roundList.addAll(roundList.getList());
        if (Boolean.TRUE.equals(plan))
            return this.roundList.stream().anyMatch(i -> !Boolean.TRUE.equals(i.getInvestment()));
        else
            return this.roundList.stream().anyMatch(i -> Boolean.TRUE.equals(i.getInvestment()));
    }

    private String getRole(String role) {
        if (!StringUtils.hasText(role))
            return "Client";
        return role.contains("Client") ? "SuperClient" : role;
    }

    private Boolean isOwner(List<TypeRes> type, Long id) {
        if (!CollectionUtils.isEmpty(type)) {
            for (TypeRes t : type) {
                if (id.equals(t.getQuestionnaireId()))
                    return true;
            }
        }
        return false;
    }

    private String getFormName(String name, Integer type, String role, Boolean investment) {
        String formName = name;
        if (formName == null) {
            switch (type) {
                case 0:
                    formName = "startup_" + getRole(role);
                    break;
                case 1:
                    formName = "corporate_" + getRole(role);
                    break;
                case 2:
                    formName = "investor_" + getRole(role);
                    break;
                case 4:
                    formName = "pilot_" + getRole(role);
                    break;
                case 7:
                    formName = "reply_" + (!StringUtils.hasText(role) ? "Client" : role);
                    break;
                case 10:
                    formName = "round_" + (!Boolean.TRUE.equals(investment) ? "short_" : "") + "Administrator";
                    break;
            }
        } else if (formName.equalsIgnoreCase("pilot_Client"))
            formName = "pilot_SuperClient";

        if ("startup_SuperStartup".equalsIgnoreCase(formName))
            formName = "startup_SuperClient";
        return formName;
    }

    private boolean findObject(Integer type){
        return type.equals(0)
                || type.equals(1)
                || type.equals(2)
                || type.equals(4)
                || type.equals(7)
                || type.equals(9)
                || type.equals(10)
                || type.equals(11)
                || type.equals(12)
                || type.equals(13);
    }

    private Boolean isFavorite(List<TypeRes> type, Boolean formFavorite, Boolean roundFavorite, String formName) {
        if (formFavorite == null)
            return true;
        if (formName.contains("round")) {
            if (type == null || type.size() == 0)
                return false;
            if (type.stream().noneMatch(i -> i.getType() != null && i.getType().equals(2)))
                return false;
        }
        return formFavorite.equals(roundFavorite);
    }

    private List<Screen> getList(String name, Long state, Long langId){
        List<Screen> screens = new ArrayList<>();
        List<ScreenButton> screenButtons;
        if (state == null)
            screenButtons = screenButtonRepository.findByName(name);
        else
            screenButtons = screenButtonRepository.findByNameAndState(name, state);
        if (screenButtons.size() > 0) {
            List<ScreenButtonLink> links = screenButtonLinkRepository
                    .findByScreenIdIn(screenButtons
                            .stream()
                            .map(ScreenButton::getId)
                            .collect(Collectors.toList()));
            if (links != null && links.size() > 0) {
                List<ButtonDao> buttons = buttonRepository
                        .findByIdInAndLangId(links
                                .stream()
                                .map(ScreenButtonLink::getButtonId)
                                .collect(Collectors.toList()),
                                langId);
                if (buttons != null && buttons.size() > 0){
                    screenButtons.forEach(sb -> {
                        Screen screen = new Screen(sb);
                        for(ScreenButtonLink l : links){
                            if (sb.getId().equals(l.getScreenId())){
                                if (CollectionUtils.isEmpty(screen.getButtons()))
                                    screen.setButtons(new ArrayList<>());
                                for(ButtonDao b : buttons){
                                    if (l.getButtonId().equals(b.getId()))
                                        screen.getButtons().add(new Screen.Button(b));
                                }
                            }
                        }
                        if (screen.getButtons() != null && screen.getButtons().size() > 0)
                            screens.add(screen);
                    });
                }
            }
        }
        return screens;
    }

    @Data
    static class Screen {
        private Long id;
        private String name;
        private Boolean adminCheck;
        private Boolean mainCheck;
        private Boolean parentCheck;
        private Boolean successPilotCheck;
        private Boolean ownerCheck;
        private Boolean favorite;
        private Long state;
        private List<Button> buttons;
        private Boolean investorCheck;
        private Boolean activeRoundCheck;
        private Boolean futureRoundCheck;

        Screen(ScreenButton s){
            this.id = s.getId();
            this.name = s.getName();
            this.adminCheck = s.getAdminCheck();
            this.mainCheck = s.getMainCheck();
            this.parentCheck = s.getParentCheck();
            this.successPilotCheck = s.getSuccessPilotCheck();
            this.ownerCheck = s.getOwnerCheck();
            this.favorite = s.getFavorite();
            this.state = s.getState();
            this.investorCheck = s.getInvestorCheck();
            this.activeRoundCheck = s.getActiveRoundCheck();
            this.futureRoundCheck = s.getFutureRoundCheck();
        }

        @Data
        static class Button {
            private Long id;
            private Integer code;
            private String text;
            private String clickAction;
            private String clickMethod;

            Button(ButtonDao b) {
                this.id = b.getId();
                this.code = b.getCode();
                this.text = b.getText();
                this.clickAction = b.getClickAction();
                this.clickMethod = b.getClickMethod();
            }

            ButtonDto convertToDto(String uuid, Long id, Long state, String formName, Long objectId, String objectUuid){
                ButtonDto dto = new ButtonDto();
                dto.setCode(this.code);
                dto.setText(this.text);
                //TODO переделать с доработкой фронта
                if (state != null
                        && this.code != null
                        && state.equals(20004L)
                        && this.code.equals(20004))
                    dto.setText("Отправить ссылку для входа");
                if ("pilot_SuperClient".equals(formName)
                        && this.code != null
                        && this.code.equals(20009))
                    dto.setText("Отправить заявку");
                if (this.clickAction != null && id != null)
                    dto.setClickAction(this.clickAction.replace("{id}", StringUtils.hasText(uuid) ? uuid : id.toString()));
                if (("reply_SuperClient".equals(formName) || "offer_SuperClient".equals(formName))
                        && this.code != null
                        && !this.code.equals(100000))
                    dto.setGroup(1);

                dto.setId(objectId);
                dto.setUid(objectUuid);
                dto.setClickMethod(this.clickMethod);
                return dto;
            }
        }
    }

    public static Long castToLong(Object val){
        if (val == null)
            return null;
        if (val instanceof Long)
            return (Long) val;
        if (val instanceof Integer)
            return ((Integer) val).longValue();
        if (val instanceof String)
            return Long.valueOf((String) val);
        return null;
    }

}
