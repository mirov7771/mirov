package ru.sberx.screen.builder.dao.model;

import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import ru.sberx.dto.screen.builder.schema.support.SchemaValueDto;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SCHEMAS")
@TypeDef(name = "json", typeClass = JsonStringType.class)
@Getter
@Setter
public class Schemas implements Serializable {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "NAME")
    private String name;
    @Type(type = "json")
    @Column(name = "VALUE", columnDefinition = "json")
    private SchemaValueDto value;

}
