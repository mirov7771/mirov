package ru.sberx.screen.builder.service.impl.method;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.Constants.PageCode;
import ru.sberx.constants.Constants.PageType;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.questionary.tariff.support.TariffDto;
import ru.sberx.dto.screen.builder.custom.QuestionnaireDtoCustom;
import ru.sberx.dto.screen.builder.structure.page.req.GetFullPageReq;
import ru.sberx.dto.screen.builder.structure.page.res.GetFullPageRes;
import ru.sberx.screen.builder.builder.FeatureValueBuilder;
import ru.sberx.screen.builder.dao.custom.dto.MetaDAO;
import ru.sberx.screen.builder.dao.model.LangDao;
import ru.sberx.screen.builder.dao.model.PageDao;
import ru.sberx.screen.builder.dao.model.jsonb.Feature;
import ru.sberx.screen.builder.dao.repository.LangRepository;
import ru.sberx.screen.builder.dao.repository.PageRepository;
import ru.sberx.unity.gate.questionary.QuestionaryService;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.constants.Constants.Header.*;
import static ru.sberx.constants.Constants.InvestorType.*;
import static ru.sberx.constants.Constants.PageCode.ROOT;
import static ru.sberx.utils.util.ObjectUtils.nvl;

@Component
@RequiredArgsConstructor
@Slf4j
public class PageMethod {

    private final PageRepository pageRepository;
    private final LangRepository langRepository;
    private final FeatureValueBuilder featureValueBuilder;
    private final QuestionaryService questionaryService;

    public GetFullPageRes getFullPage(GetFullPageReq req) {
        GetFullPageRes res = new GetFullPageRes();
        List<Map<String, Object>> features = new ArrayList<>();
        String name;
        String description;
        String loc = ThreadContext.get(LOCALE);
        if (!StringUtils.hasText(loc))
            loc = "ru";
        String usrId = ThreadContext.get(USER_ID);
        Long userId = null;
        res.setLangs(loc);
        LangDao locale = langRepository.findByLocale(loc);
        boolean isAuth = false;
        if (StringUtils.hasText(usrId)){
            isAuth = true;
            userId = Long.valueOf(usrId);
        }
        String pageType = isAuth ? PageType.AUTH : PageType.UNAUTH;
        String uri = ThreadContext.get(HttpHeaders.LOCATION);
        if (!StringUtils.hasText(uri))
            uri = ROOT;
        req.setPageUri(uri);
        req.setLocale(loc);
        req.setRole(ThreadContext.get(ROLE));
        String role = req.getRole();
        req.setUserId(userId);

        log.info("request pages {}", req);

        String tariff = null;
        if (userId != null) {
            try {
                TariffDto tf = questionaryService.getTariff(userId, role, null, null, true);
                tariff = tf != null ? tf.getSysname() : null;
            } catch (Exception e) {
                log.error("Error getting tariff: ", e);
            }
        }

        if (StringUtils.hasText(tariff) && uri.equalsIgnoreCase("/select-tariff")){
            if (tariff.toLowerCase().contains("corp"))
                uri = "/select-tariff-corp";
            else
                uri = "/select-tariff-inv";
        }
        List<PageDao> pageDaos = pageRepository.findByUriAndPageTypeAndLangId(uri, pageType, locale.getId());
        MetaDAO metaDAO = null;
        Long pageId = null;
        if (CollectionUtils.isEmpty(pageDaos)) {
            throw new SberxException(SberxErrors.NOT_FOUND,
                    "Элемента с uri " + uri
                            + " для типа " + pageType
                            + " не существует в системе");
        }
        if (!isAuth) {
            PageDao pageDao = pageDaos.get(0);
            pageId = pageDao.getId();
            metaDAO = pageRepository.findPageName(pageId);
            name = getPageName(metaDAO, "getName");
            description = getPageName(metaDAO, "getDescription");
            final Feature feature = pageDao.getPage();
            if (feature != null)
                features = feature.getFeatures();
        } else if (uri.contains("/community")){
            QuestionnaireDtoCustom c = questionaryService.getMainObject(null, userId, null, "/community");
            String pageCode = PageCode.COMMUNITY_AZ;
            TypeRes typeInfoDto = questionaryService.getOneTypeByUserId(userId);
            int type = typeInfoDto != null && typeInfoDto.getType() != null ? typeInfoDto.getType() : 0;
            if (c == null || c.getState() == null || Objects.equals(c.getState(), 20001L)) {
                switch (type) {
                    case 0:
                        pageCode = PageCode.COMMUNITY_AZ_STARTUP;
                        break;
                    case 1:
                        pageCode = PageCode.COMMUNITY_AZ_CORPORATE;
                        break;
                    case 2:
                        if (typeInfoDto.getInvestorType() != null) {
                            switch (typeInfoDto.getInvestorType()) {
                                case FAMILY_OFFICE:
                                    pageCode = PageCode.COMMUNITY_AZ_FAMILYOFFICE;
                                    break;
                                case BUSINESS_ANGEL:
                                    pageCode = PageCode.COMMUNITY_AZ_BUSINESSANGEL;
                                    break;
                                case VENTURE_FOND:
                                    pageCode = PageCode.COMMUNITY_AZ_VENTUREFOND;
                            }
                        }
                }
            } else if (Objects.equals(c.getState(), 20004L)) {
                switch (type) {
                    case 0:
                        pageCode = PageCode.COMMUNITY_AZ_CONFIRMED_APP_STARTUP;
                        break;
                    case 2:
                        pageCode = PageCode.COMMUNITY_AZ_CONFIRMED_APP_INVESTOR;
                        break;
                    default:
                        pageCode = PageCode.COMMUNITY_AZ_CONFIRMED_APP;
                }
            } else {
                switch (type) {
                    case 0:
                        pageCode = PageCode.COMMUNITY_AZ_NOT_CONFIRMED_APP_STARTUP;
                        break;
                    case 2:
                        pageCode = PageCode.COMMUNITY_AZ_NOT_CONFIRMED_APP_INVESTOR;
                        break;
                    default:
                        pageCode = PageCode.COMMUNITY_AZ_NOT_CONFIRMED_APP;
                }
            }
            String finalPageCode = pageCode;
            PageDao page = pageDaos
                    .stream()
                    .filter(i -> i.getCode().equals(finalPageCode))
                    .findFirst().orElseThrow(() -> new SberxException(SberxErrors.NOT_FOUND,
                            "Элемента с code " + finalPageCode
                                    + " не существует в системе"));
            pageId = page.getId();
            metaDAO = pageRepository.findPageName(pageId);
            name = getPageName(metaDAO, "getName");
            description = getPageName(metaDAO, "getDescription");
            if (page.getPage() != null)
                features = page.getPage().getFeatures();
        } else if (uri.contains("/pilots")) {
            String pageCode = PageCode.PILOTS_STARTUP + loc;
            List<TypeRes> type = questionaryService.getTypeByUserId(userId);
            if (!CollectionUtils.isEmpty(type)){
                if (type.get(0).getType().equals(1)){
                    pageCode = PageCode.PILOTS_CORPORATE + loc;
                } else if (type.get(0).getType().equals(2)) {
                    pageCode = PageCode.PILOTS_INVESTOR + loc;
                } else {
                    pageCode = PageCode.PILOTS_STARTUP + loc;
                }
            }
            String finalPageCode = pageCode;
            PageDao page = pageDaos
                    .stream()
                    .filter(i -> i.getCode().equals(finalPageCode))
                    .findFirst().orElseThrow(() -> new SberxException(SberxErrors.NOT_FOUND,
                            "Элемента с code " + finalPageCode
                                    + " не существует в системе"));
            pageId = page.getId();
            metaDAO = pageRepository.findPageName(pageId);
            name = getPageName(metaDAO, "getName");
            description = getPageName(metaDAO, "getDescription");
            if (page.getPage() != null)
                features = page.getPage().getFeatures();
        } else {
            PageDao page = pageDaos.stream()
                    .findFirst().orElseThrow(() -> new SberxException(SberxErrors.NOT_FOUND,
                            "Элемента не существует в системе"));
            pageId = page.getId();
            metaDAO = pageRepository.findPageName(pageId);
            name = getPageName(metaDAO, "getName");
            description = getPageName(metaDAO, "getDescription");
            if (page.getPage() != null)
                features = page.getPage().getFeatures();
        };
        res.setFeatures(featureValueBuilder.buildValues(features, loc, role, userId, tariff));

        if (userId != null
                && !CollectionUtils.isEmpty(res.getFeatures())
                && (uri.contains("import-substitution") || uri.contains("pilot"))
                && !uri.equals("/pilot-view")){
            List<TypeRes> type = questionaryService.getTypeByUserId(userId);
            if (!CollectionUtils.isEmpty(type)
                    && type.stream().allMatch(i -> i.getType().equals(0))){
                List<TypeRes> approveList = type.stream().filter(i -> i.getState().equals(20004L)).collect(Collectors.toList());
                Long id = CollectionUtils.isEmpty(approveList) ? type.get(0).getQuestionnaireId() : approveList.get(0).getQuestionnaireId();
                Map<String, Object> banner = new HashMap<>();
                banner.put("type", "banner");
                banner.put("closed", !uri.contains("pilots"));
                banner.put("link", "/view?type=0&action=2&name=import_create&id=" + id);
                banner.put("visible", true);
                banner.put("title", "ru".equalsIgnoreCase(loc) ? "Какие сервисы заменяет ваш продукт?" : "What services does your product replace?");
                banner.put("subtitle", "ru".equalsIgnoreCase(loc) ? "Добавьте информацию, чтобы стать заметнее для корпораций" : "Add information to become more visible to corporations");
                banner.put("button", Map.of("text", "ru".equalsIgnoreCase(loc) ? "Добавить информацию" : "Add Information"));
                if (type.stream().allMatch(i -> i.getIsImport() == null)){
                    res.getFeatures().add(0, banner);
                } else if (type.stream().anyMatch(i -> Boolean.FALSE.equals(i.getIsImport())) && !uri.contains("pilots")){
                    res.getFeatures().add(0, banner);
                }
            }
        }
        //Обходим САСТ
        String metaName = name;
        String metaDescription = description;
        final GetFullPageRes.Meta meta = new GetFullPageRes.Meta(metaName, metaDescription);
        res.setMeta(meta);
        return res;
    }

    //Обходим САСТ
    private String getPageName(MetaDAO page, String key) {
        try {
            Method declaredMethod = page.getClass().getDeclaredMethod(key);
            final Object ret = declaredMethod.invoke(page);
            return (String) ret;
        } catch (Exception e) {
            log.error("Error getting name: ", e);
            return "SberUnity";
        }
    }

}
