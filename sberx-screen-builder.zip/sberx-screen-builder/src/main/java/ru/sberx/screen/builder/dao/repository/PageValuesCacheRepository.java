package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.PageValuesCache;

import java.util.List;

@Repository
public interface PageValuesCacheRepository extends CrudRepository<PageValuesCache, String> {
    List<PageValuesCache> findByNameIn(List<String> names);
}
