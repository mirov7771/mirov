package ru.sberx.screen.builder.dao.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "BUTTONS")
@Data
public class ButtonDao implements Serializable {

    @Id
    @Column(name = "BUTTON_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "CODE")
    private Integer code;
    @Column(name = "TEXT")
    private String text;
    @Column(name = "CLICK_ACTION")
    private String clickAction;
    @Column(name = "CLICK_METHOD")
    private String clickMethod;
    @Column(name = "LANG_ID")
    private Long langId;

}
