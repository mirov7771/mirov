package ru.sberx.screen.builder.dao.model;

import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.Getter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import ru.sberx.dto.screen.builder.form.support.FormDto;
import ru.sberx.screen.builder.dao.model.jsonb.Button;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SCREEN")
@TypeDef(name = "json", typeClass = JsonStringType.class)
@Getter
public class Screen implements Serializable {

    private static final long serialVersionUID = -5531515181448119279L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "TYPE")
    private Integer type;
    @Column(name = "FORMNAME")
    private String formName;
    @Type(type = "json")
    @Column(name = "formedit", columnDefinition = "json")
    private FormDto formEdit;
    @Type(type = "json")
    @Column(name = "formview", columnDefinition = "json")
    private FormDto formView;
    @Column(name = "NAME")
    private String name;
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "PAGES")
    private Integer pages;
    @Type(type = "json")
    @Column(name = "buttons", columnDefinition = "json")
    private Button button;
    @Column(name = "LOGOFILE")
    private String logoFile;
    @Column(name = "OFFERDESCRIPTION")
    private String offerDescription;
    @Column(name = "SECONDOFFERDESCRIPTION")
    private String secondOfferDescription;
    @Column(name = "LANG_ID")
    private Long langId;
    @Column(name = "INFO")
    private String info;

}
