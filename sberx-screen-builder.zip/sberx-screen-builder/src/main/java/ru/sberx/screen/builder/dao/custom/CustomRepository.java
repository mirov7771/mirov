package ru.sberx.screen.builder.dao.custom;

import ru.sberx.screen.builder.dao.custom.dto.MetaDAO;

public interface CustomRepository {
    MetaDAO findPageName(Long id);
}
