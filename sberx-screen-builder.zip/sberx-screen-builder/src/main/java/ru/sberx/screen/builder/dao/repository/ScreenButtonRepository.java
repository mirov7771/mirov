package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.repository.CrudRepository;
import ru.sberx.screen.builder.dao.model.ScreenButton;

import java.util.List;

public interface ScreenButtonRepository extends CrudRepository<ScreenButton, Long> {
    List<ScreenButton> findByNameAndState(String name, Long state);
    List<ScreenButton> findByName(String name);
}
