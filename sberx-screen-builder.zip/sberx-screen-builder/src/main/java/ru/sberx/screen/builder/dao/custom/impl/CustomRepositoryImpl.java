package ru.sberx.screen.builder.dao.custom.impl;

import org.hibernate.query.Query;
import ru.sberx.screen.builder.dao.custom.CustomRepository;
import ru.sberx.screen.builder.dao.custom.ListResultTransformer;
import ru.sberx.screen.builder.dao.custom.dto.MetaDAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class CustomRepositoryImpl implements CustomRepository {
    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Override
    public MetaDAO findPageName(Long id) {
        String sql = "select name, description\n" +
                "  from pages p \n" +
                " where id = :id";
        Query<MetaDAO> query = entityManager.createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new MetaDAO(
                                tuple[0] != null ? ((String) tuple[0]) : null,
                                tuple[1] != null ? ((String) tuple[1]) : null
                        ));
        query.setParameter("id", id);
        query.setMaxResults(1);
        return query.getSingleResult();
    }
}
