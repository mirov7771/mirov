package ru.sberx.screen.builder.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import ru.sberx.constants.Constants;
import ru.sberx.dto.screen.builder.button.res.ButtonRes;
import ru.sberx.dto.screen.builder.form.req.FormReq;
import ru.sberx.dto.screen.builder.form.res.FormRes;
import ru.sberx.dto.screen.builder.menu.req.MenuReq;
import ru.sberx.dto.screen.builder.menu.res.MenuRes;
import ru.sberx.dto.screen.builder.structure.page.req.GetFullPageReq;
import ru.sberx.dto.screen.builder.structure.page.res.GetFullPageRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetListRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetRes;
import ru.sberx.dto.screen.builder.widget.support.WidgetDto;
import ru.sberx.screen.builder.service.Service;
import ru.sberx.utils.builder.ResponseBuilder;

import java.util.List;

import static ru.sberx.constants.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.constants.Constants.Header.*;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class ServiceController {

    private final Service service;

    @GetMapping(value = "form", produces = APPLICATION_JSON_VALUE)
    private ResponseEntity<List<FormRes>> form(@RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                               FormReq req) {
        req.setLocale(locale);
        return ResponseBuilder.ok(service.form(req));
    }

    @GetMapping(value = "menu", produces = APPLICATION_JSON_VALUE)
    private ResponseEntity<List<MenuRes>> menu(@RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                               @RequestHeader(value = ROLE, required = false) String role,
                                               MenuReq req) {
        if (StringUtils.hasText(role)) {
            req.setRole(role);
        } else {
            req.setRole(null);
        }
        req.setLocale(locale);
        return ResponseBuilder.ok(service.menu(req));
    }


    @GetMapping(value = "buttons", produces = APPLICATION_JSON_VALUE)
    private ResponseEntity<ButtonRes> buttons(@RequestParam(value = "name", required = false) String name,
                                              @RequestParam(value = "type", required = false) Integer type,
                                              @RequestParam(value = "id", required = false) Long questionnaireId,
                                              @RequestParam(value = "uid", required = false) String uid,
                                              @RequestHeader(value = LOCALE, defaultValue = "ru") String locale,
                                              @RequestHeader(value = USER_ID, required = false) Long userId,
                                              @RequestHeader(value = ROLE, required = false) String role,
                                              @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId) {
        return ResponseBuilder.ok(service.getButtons(name, type, userId, role, sessionId, questionnaireId, uid, locale));
    }

    @GetMapping(value = "structure/pages", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<GetFullPageRes> getFullPage(GetFullPageReq req) {
        return ResponseBuilder.ok(service.getFullPage(req));
    }

    @GetMapping(value = "features", produces = APPLICATION_JSON_VALUE)
    private ResponseEntity<WidgetListRes> features(@RequestHeader(value = Constants.Header.USER_ID, required = false) Long userId,
                                                   @RequestHeader(value = HttpHeaders.LOCATION, required = false) String location) {
        return ResponseBuilder.ok(service.widgets(userId, location));
    }

    @PostMapping(value = "feature", produces = APPLICATION_JSON_VALUE)
    private ResponseEntity<WidgetRes> featureSave(@RequestBody WidgetDto req) {
        return ResponseBuilder.ok(service.widgetSave(req));
    }

    @DeleteMapping(value = "feature/{id}", produces = APPLICATION_JSON_VALUE)
    private void featureDelete(@PathVariable("id") Long id) {
        service.widgetDelete(id);
    }

    @PutMapping(value = "feature/{id}", produces = APPLICATION_JSON_VALUE)
    private void featureUpdate(@PathVariable("id") Long id,
                               @RequestBody WidgetDto req) {
        req.setId(id);
        service.widgetUpdate(req);
    }

}
