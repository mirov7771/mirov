package ru.sberx.screen.builder.dao.custom.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter @Setter
public class MetaDAO {
    private String name;
    private String description;
}
