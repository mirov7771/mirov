package ru.sberx.screen.builder.dao.repository;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.screen.builder.dao.model.Screen;

import java.util.List;

@Repository
public interface ScreenRepository extends CrudRepository<Screen, String> {
    List<Screen> findByTypeAndFormNameAndLangId(Integer type, String formName, Long langId, Pageable pageable);
}
