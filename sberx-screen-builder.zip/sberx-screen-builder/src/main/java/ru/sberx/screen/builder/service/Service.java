package ru.sberx.screen.builder.service;

import ru.sberx.dto.screen.builder.button.res.ButtonRes;
import ru.sberx.dto.screen.builder.form.req.FormReq;
import ru.sberx.dto.screen.builder.form.res.FormRes;
import ru.sberx.dto.screen.builder.menu.req.MenuReq;
import ru.sberx.dto.screen.builder.menu.res.MenuRes;
import ru.sberx.dto.screen.builder.structure.page.req.GetFullPageReq;
import ru.sberx.dto.screen.builder.structure.page.res.GetFullPageRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetListRes;
import ru.sberx.dto.screen.builder.widget.res.WidgetRes;
import ru.sberx.dto.screen.builder.widget.support.WidgetDto;

import java.util.List;

public interface Service {
    List<MenuRes> menu(MenuReq req);
    List<FormRes> form(FormReq req);
    ButtonRes getButtons(String name, Integer type, Long userId, String role, String sessionId, Long id, String uid, String locale);
    GetFullPageRes getFullPage(GetFullPageReq req);
    WidgetListRes widgets(Long userId, String location);
    WidgetRes widgetSave(WidgetDto req);
    void widgetDelete(Long id);
    void widgetUpdate(WidgetDto req);
}
