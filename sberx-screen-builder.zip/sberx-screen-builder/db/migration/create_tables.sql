create table client_menu
(
    ID       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY ,
    TYPE     SMALLINT,
    MENUTYPE VARCHAR(50),
    NAME     VARCHAR(150),
    SYSNAME  VARCHAR(50),
    ACTION   VARCHAR(50) NULL,
    METHOD   VARCHAR(20) NULL,
    clientid VARCHAR(50) NOT NULL,
    logofile varchar(150) null
);

create index x1_client_menu on client_menu (type, menutype, clientid);

create table screen
(
    ID                      BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    clientid                varchar(150),
    type                    smallint,
    formName                varchar(150),
    formEdit                json null,
    formView                json null,
    name                    varchar(255) null,
    description             varchar(655) null,
    pages                   smallint,
    buttons                 json null,
    logoFile                varchar(255) null,
    offerdescription        text null,
    secondofferdescription  text null
);

create index x1_screen on screen (clientid, type);

create table schemas
(
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        varchar(150),
    clientid    VARCHAR(50) NOT NULL,
    value       json null
);

create index x1_schemas on schemas(clientid,name);