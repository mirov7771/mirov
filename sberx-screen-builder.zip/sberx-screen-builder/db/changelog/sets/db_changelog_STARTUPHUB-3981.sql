--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3981
update public.screen
set formview = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "fio",
                    "required": false,
                    "localName": "Имя, Фамилия"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "name",
                    "required": false,
                    "localName": "В каком сообществе вы уже состоите?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "position",
                    "required": false,
                    "localName": "Должность"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "site",
                    "required": false,
                    "localName": "Сайт проекта"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "В какие направления инвестируете?"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Интересующая география инвестиций"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "round",
                    "activity": [
                        7000
                    ],
                    "required": false,
                    "localName": "Интересующие стадии инвестиций"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "expectation",
                    "required": false,
                    "localName": "Что вы ожидаете получить от сообщества?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "useful",
                    "required": false,
                    "localName": "Что вы можете дать сообществу?"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "ventureProjectsCount",
                    "required": false,
                    "localName": "Количество венчурных проектов в портфеле"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "email",
                    "required": false,
                    "localName": "Электронная почта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "phoneNumber",
                    "required": false,
                    "localName": "Номер телефона для связи"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "facebook",
                    "required": false,
                    "localName": "Ваш аккаунт в Facebook"
                }
            ],
            "module": "Основная информация",
            "pageName": ""
        }
    ]
}'
where formname = 'community_Administrator';