--liquibase formatted sql
--changeset Mirov AA:main_reply
delete from pages where code = 'reply_auth_ru';
insert into pages (code, name, uri, description, page_type, page, lang_id)
values('reply_auth_ru', 'Отклики | SberUnity', '/reply', 'SberUnity', 'auth', '{
   "features":[
      {
         "type":"replies",
         "sysName":"replies",
         "visible":true,
         "position":1,
         "filterTextField":{
            "id":"search-field",
            "placeholder":"Поиск по наименованию стартапа"
         },
         "toggleButtons":[
            {
               "value":"reply_search",
               "label":"Все отклики"
            },
            {
               "value":"offer_search",
               "label":"Предложения стартапов"
            }
         ],
         "fastFilters":[
            {
               "label":"Новые",
               "status":20011
            },
            {
               "label":"В работе",
               "status":20002
            },
            {
               "label":"Пауза",
               "status":20003
            },
            {
               "label":"Пилотируются",
               "status":20004
            },
            {
               "label":"Завершено",
               "status":20007
            },
            {
               "label":"Отказ",
               "status":20009
            },
            {
               "label":"Отозван",
               "status":20013
            }
         ],
         "showMoreBtn":"Показать ещё",
         "emptyText":{
            "reply_search":"Откликов нет",
            "offer_search":"Предложений на пилот от стартапов нет"
         }
      }
   ]
}', 1);
