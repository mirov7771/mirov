--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5297_3
update pages set name = 'Восстановление пароля | SberUnity' where uri = '/recovery' and lang_id = 1;
update pages set name = 'Выберите роль для регистрации | SberUnity' where uri = '/participant-registration' and lang_id = 1;
update pages set name = 'Регистрация корпорации | SberUnity' where uri = '/participant-registration/corporate' and lang_id = 1;
update pages set name = 'Регистрация инвестора | SberUnity' where uri = '/participant-registration/investor' and lang_id = 1;
update pages set name = 'Настройки профиля | SberUnity' where uri = '/settings' and lang_id = 1;
update pages set name = 'Просмотр анкеты | SberUnity' where uri = '/questionnaire-view' and lang_id = 1;
update pages set name = 'Technology requests | SberUnity' where uri = '/pilots' and lang_id = 2;
update pages set name = 'Choose a role to register | SberUnity' where uri = '/participant-registration' and lang_id = 2;
update pages set name = 'Sign up as a corporation | SberUnity' where uri = '/participant-registration/corporate' and lang_id = 2;
update pages set name = 'Sign up as an investor | SberUnity' where uri = '/participant-registration/investor' and lang_id = 2;
