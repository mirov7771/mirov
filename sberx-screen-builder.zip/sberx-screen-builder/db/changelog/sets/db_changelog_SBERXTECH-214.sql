--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-214
alter table client_menu add priority smallint null;
