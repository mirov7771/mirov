--liquibase formatted sql
--changeset Mirov AA:page_values_cache
drop table if exists page_values_cache;
create table page_values_cache(
                                  name varchar,
                                  value varchar null,
                                  cache_period smallint,
                                  cache_time timestamp,
                                  action varchar,
                                  method varchar
);

insert into page_values_cache
values('%pilots_size%', '0', 7, null, 'GET', '/reply');