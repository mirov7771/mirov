--liquibase formatted sql
--changeset Mirov A:SBERXTECH-1907
update public.screen
set formview = '{
  "form": [
    {
      "fields": [

        {
          "sysName": "service_category"
        ,"localName": ""
        ,"type": "array"
        ,"format": "chip"
        ,"edited": false
        ,"required": false
        ,"activity": [10000]
        },{
          "sysName": "serviceCompany_note",
          "localName": "",
          "type": "string",
          "edited": false,
          "required": false
        },{
          "sysName": "serviceCompany_resourceURI",
          "localName": "",
          "type": "hyperlink",
          "format":"",
          "edited": false,
          "required": false
        }

      ]
    },{
      "module": "",
      "moduleNote": "",
      "moduleFormat" : "card",
      "fields": [
        {
          "sysName": "service_smallNote",
          "localName": "",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false
        },
        {
          "sysName": "service_note",
          "localName": "",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false
        },
        {
          "sysName": "service_discount",
          "localName": "",
          "type": "string",
          "format": "bodyhide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "service_offer",
          "localName": "",
          "type": "string",
          "format": "bodybold",
          "edited": false,
          "required": false
        },
        {
          "sysName": "service_offerUri",
          "localName": "Получить предложение",
          "type": "info",
          "format": "button",
          "logo": "",
          "clickActon": "",
          "edited": false,
          "required": false
        }

      ]
    }
  ]
}'
where formname like 'vas_%'