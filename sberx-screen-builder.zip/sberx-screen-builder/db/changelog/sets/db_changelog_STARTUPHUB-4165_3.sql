--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4165_3
delete
from public.pages
where uri = '/questionnaire';

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('questionnaire_az_ru', 'SberUnity', '/questionnaire', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "questionnaire",
            "sysName": "questionnaire",
            "visible": true,
            "position": 1,
            "config": {
                "nowrap": true
            },
            "commentOfAdministrator": {
                "title": "Комментарий от администратора:",
                "description": "Ваши последние изменения в анкету не видны другим пользователям. Для публикации актуальной анкеты просим внести правки:"
            },
            "buttonLabels": {
                "success": "Сохранить и выйти",
                "back": "Назад",
                "next": "Далее",
                "send": "Отправить"
            },
            "modalLabels": {
                "title": "Спасибо за вашу заявку!",
                "description": "В течение нескольких дней мы проверим вашу анкету и откроем полный доступ к платформе, либо свяжемся для уточнения деталей. Пока вы можете просмотреть спецпредложения сервисов. Если проверка анкеты затянулась, напишите нам на ",
                "cancelButton": "Редактировать анкету",
                "confirmButton": "Начать работу"
            }
        }
    ]
}',1)