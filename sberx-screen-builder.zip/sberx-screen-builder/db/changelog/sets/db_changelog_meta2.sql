--liquibase formatted sql
--changeset Mirov AA:meta2
update pages set name = 'SberUnity', description = 'Стартапы, инвесторы и корпорации находят друг друга на нашей платформе' where lang_id = 1 and uri = '/root';
update pages set name = 'SberUnity Запросы корпораций', description = 'Потребности корпораций собраны на этой странице. Узнайте, какие технологии интересны бизнесу сейчас' where lang_id = 1 and uri = '/pilot';
update pages set name = 'СберСтартап Сообщество', description = 'Стартап-коммьнити Сбера — возможность общаться с другими фаундерами и экспертами венчурного рынка, найти решения для своих бизнес-задач' where lang_id = 1 and uri = '/community';
update pages set name = 'SberUnity Спецпредложения', description = 'Акции на сервисы для бизнеса, которые помогут вам прокачать свой стартап' where lang_id = 1 and uri = '/vas';
update pages set name = 'SberUnity Стартапы', description = 'Интересные стартапы для вложения ваших инвестиций собраны здесь. Стадия проектов не ниже MVP' where lang_id = 1 and uri = '/startup';
update pages set name = 'SberUnity Корпорации', description = 'Топовые корпорации, которые открыты к сотрудничеству, собраны здесь' where lang_id = 1 and uri = '/corporates';
update pages set name = 'SberUnity Инвесторы', description = 'Найти инвестора для своего проекта и получить финансирование для стартапа можно здесь' where lang_id = 1 and uri = '/investors';
update pages set name = 'SberUnity Регистрация', description = 'Объединяем стартапы, инвесторов и корпорации. Заполните анкету, чтобы присоединиться' where lang_id = 1 and uri = '/participant-registration';
update pages set name = 'SberUnity Регистрация', description = 'Объединяем стартапы, инвесторов и корпорации. Заполните анкету, чтобы присоединиться' where lang_id = 1 and uri = '/registration';
update pages set name = 'Регистрация SberUnity', description = 'Объединяем стартапы, инвесторов и корпорации. Заполните анкету, чтобы присоединиться' where lang_id = 1 and uri = '/pre-questionnaire?type=1';
update pages set name = 'SberUnity Регистрация', description = 'Объединяем стартапы, инвесторов и корпорации. Заполните анкету, чтобы присоединиться' where lang_id = 1 and uri = '/pre-questionnaire?type=2';
update pages set name = 'SberUnity Личный кабинет или SberUnity Вход', description = 'Введите логин и пароль, чтобы войти в свой аккаунт на платформе' where lang_id = 1 and uri = '/auth';
update pages set name = 'SberUnity Сброс пароля', description = 'Восстановить пароль на платформе можно просто и быстро' where lang_id = 1 and uri = '/recovery';