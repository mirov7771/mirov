--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5034
update public.pages
set page = '{
    "features": [
        {
            "type": "mainHeader",
            "sysName": "cMainHeader_1",
            "visible": true,
            "position": 1,
            "config": {},
            "features": [
                {
                    "type": "button",
                    "sysName": "cMainHeader_1_button_1",
                    "config": {},
                    "iconUrl": null,
                    "theme": "purple-gradient",
                    "category": "simple",
                    "visible": true,
                    "default": "active",
                    "text": "Стать частью сообщества",
                    "url": null,
                    "action": "popup"
                },
                {
                    "type": "bigNSmallGallery",
                    "sysName": "cMainHeader_1_bigNSmallGallery_1",
                    "config": {},
                    "images": [
                        {
                            "url": "/file/welcome_headerImg_1.png",
                            "isMain": true
                        },
                        {
                            "url": "/file/welcome_headerImg_2.png",
                            "isMain": false
                        }
                    ],
                    "visible": true
                }
            ],
            "title": "**СберСтартап**  \\nсообщество",
            "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
            "backgroundUrl": "/file/bg-main.png"
        },
        {
            "type": "mainTabs",
            "sysName": "cMainTabs_1",
            "items": [
                {
                    "config": {},
                    "features": [
                        {
                            "type": "squareList",
                            "sysName": "сSquareList_startup_1",
                            "items": [
                                {
                                    "iconUrl": "/file/ic_96_bubbles.svg",
                                    "title": "Нетворкинг",
                                    "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач"
                                },
                                {
                                    "title": "Экспертиза",
                                    "description": "Консультации от профессиональных трекеров и опытных менторов",
                                    "iconUrl": "/file/ic_96_person_document.svg"
                                },
                                {
                                    "title": "Контент",
                                    "description": "Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
                                    "iconUrl": "/file/ic_96_media.svg"
                                },
                                {
                                    "title": "Мероприятия",
                                    "description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
                                    "iconUrl": "/file/ic_96_calendar_mic.svg"
                                },
                                {
                                    "title": "Закрытый стартап-клуб",
                                    "description": "Эксклюзивные мероприятия с инвесторами",
                                    "iconUrl": "/file/ic_96_invite_letter.svg"
                                },
                                {
                                    "title": "Поддержка",
                                    "description": "Обмен опытом и помощь в решении бизнес-кейсов",
                                    "iconUrl": "/file/ic_96_question_notebook.svg"
                                }
                            ],
                            "position": 1,
                            "config": {},
                            "title": "Что вам **будет доступно**"
                        },
                        {
                            "type": "flatTabs",
                            "sysName": "cFlatTabs_startup_1",
                            "header": "**Как попасть** в сообщество СберСтартап",
                            "visible": true,
                            "position": 2,
                            "items": [
                                {
                                    "title": "Новым участникам",
                                    "isDefault": true,
                                    "position": 1,
                                    "features": [
                                        {
                                            "type": "roadMap",
                                            "sysName": "сRoadMap_startup_1",
                                            "visible": true,
                                            "position": 1,
                                            "config": {},
                                            "items": [
                                                {
                                                    "title": "[Зарегистрируйтесь](/participant-registration) на платформе",
                                                    "description": "Станьте резидентом SberUnity, чтобы присоединиться к сообществу",
                                                    "iconUrl": null,
                                                    "stepNumber": "1"
                                                },
                                                {
                                                    "title": "Заполните анкету сообщества",
                                                    "description": "Она находится в личном кабинете в разделе «Сообщество»",
                                                    "iconUrl": null,
                                                    "stepNumber": "2"
                                                },
                                                {
                                                    "title": "Дождитесь результата",
                                                    "description": "В течение 3-х дней мы рассмотрим вашу заявку и вернёмся с обратной связью",
                                                    "iconUrl": null,
                                                    "stepNumber": "3"
                                                },
                                                {
                                                    "title": "Присоединитесь к нам",
                                                    "description": "После прохождения отбора вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                                                    "iconUrl": null,
                                                    "stepNumber": "4"
                                                }
                                            ]
                                        }
                                    ]
                                },
                                {
                                    "title": "Участникам SberUnity",
                                    "isDefault": false,
                                    "position": 2,
                                    "features": [
                                        {
                                            "type": "roadMap",
                                            "sysName": "сRoadMap_startup_2",
                                            "visible": true,
                                            "position": 1,
                                            "config": {},
                                            "items": [
                                                {
                                                    "title": "Заполните анкету сообщества",
                                                    "description": "Она находится в личном кабинете в разделе «Сообщество»",
                                                    "iconUrl": null,
                                                    "stepNumber": "1"
                                                },
                                                {
                                                    "title": "Дождитесь результата",
                                                    "description": "В течение 3-х дней мы рассмотрим вашу заявку и вернёмся с обратной связью",
                                                    "iconUrl": null,
                                                    "stepNumber": "2"
                                                },
                                                {
                                                    "title": "Присоединитесь к нам",
                                                    "description": "После прохождения отбора вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                                                    "iconUrl": null,
                                                    "stepNumber": "3"
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ],
                            "config": {},
                            "backgroundColor": "#EBECF1"
                        },
                        {
                            "type": "nearby",
                            "sysName": "cNearby_startup_1",
                            "header": "Мы **рядом** с вами",
                            "visible": true,
                            "features": [
                                {
                                    "type": "banner",
                                    "sysName": "cNearbyBanner_startup_1",
                                    "title": "Онлайн",
                                    "visible": true,
                                    "description": "На платформе Telegram и онлайн-событиях",
                                    "iconUrl": "/file/community_banner_il_online.png",
                                    "tablePosition": {
                                        "row": 1,
                                        "column": 1
                                    },
                                    "config": {},
                                    "theme": "default"
                                },
                                {
                                    "type": "banner",
                                    "sysName": "cNearbyBanner_startup_2",
                                    "title": "Оффлайн",
                                    "visible": true,
                                    "description": "В собственном коворкинге и на закрытых встречах",
                                    "iconUrl": "/file/community_banner_il_offline.png",
                                    "tablePosition": {
                                        "row": 2,
                                        "column": 1
                                    },
                                    "config": {},
                                    "theme": "default"
                                },
                                {
                                    "type": "banner",
                                    "sysName": "cNearbyBanner_startup_3",
                                    "title": "Сообщество СберСтартап",
                                    "visible": true,
                                    "description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
                                    "backgroundUrl": "/file/community-banner.png",
                                    "tablePosition": {
                                        "row": 1,
                                        "column": 2
                                    },
                                    "config": {},
                                    "features": [
                                        {
                                            "type": "button",
                                            "sysName": "cNearbyBanner_startup_3_button_1",
                                            "category": "simple",
                                            "default": "active",
                                            "text": "Стать частью сообщества",
                                            "iconUrl": null,
                                            "url": null,
                                            "config": {},
                                            "action": "popup",
                                            "theme": "default"
                                        }
                                    ],
                                    "theme": "purple-gradient"
                                }
                            ],
                            "config": {
                                "tableConfiguration": [
                                    {
                                        "columnNumber": 1,
                                        "rows": 2
                                    },
                                    {
                                        "columnNumber": 2,
                                        "rows": 1
                                    }
                                ]
                            },
                            "position": 3
                        }
                    ],
                    "badgeText": null,
                    "title": "Стартапам",
                    "visible": true,
                    "isDefault": true,
                    "isActive": true,
                    "iconUrl": "/file/participants_ic-startups.svg",
                    "position": 1
                },
                {
                    "visible": true,
                    "isDefault": false,
                    "isActive": true,
                    "iconUrl": "/file/participants_ic-investors.svg",
                    "position": 2,
                    "title": "Инвесторам",
                    "features": [
                        {
                            "type": "squareRow",
                            "sysName": "cSquareRow_investor_1",
                            "visible": true,
                            "header": "Большая **воронка стартапов** на российском рынке",
                            "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
                            "position": 3,
                            "items": [
                                {
                                    "title": "Знакомим",
                                    "description": "с основателями стартапов",
                                    "iconUrl": "/file/squareRow_1.svg"
                                },
                                {
                                    "title": "Проводим",
                                    "description": "предварительный скоринг",
                                    "iconUrl": "/file/squareRow_2.svg"
                                },
                                {
                                    "title": "Рекомендуем",
                                    "description": "только отобранные проекты",
                                    "iconUrl": "/file/squareRow_3.svg"
                                },
                                {
                                    "title": "Объединяем",
                                    "description": "инвесторов и стартапы",
                                    "iconUrl": "/file/squareRow_4.svg"
                                }
                            ],
                            "config": {}
                        },
                        {
                            "type": "rectangTiles",
                            "sysName": "cRectangTiles_investor_2",
                            "visible": true,
                            "header": "Наши акселераторы",
                            "position": 4,
                            "config": {},
                            "description": null,
                            "items": [
                                {
                                    "imageUrl": "/file/logo_2_accelerator.png",
                                    "url": "https://sberstudent.sberclass.ru/"
                                },
                                {
                                    "imageUrl": "/file/logo_3_accelerator.png",
                                    "url": "https://sber-up.ru/"
                                },
                                {
                                    "imageUrl": "/file/logo_4_accelerator.png",
                                    "url": "https://sber-z.sberclass.ru/"
                                }
                            ]
                        },
                        {
                            "type": "bulletBanner",
                            "sysName": "cBulletBanner_investor_2",
                            "visible": true,
                            "header": "**Всё, что нужно —** уже под рукой",
                            "description": "Мы организовали сообщество в Slack-каналах",
                            "backgroundColor": "#F4F5F9",
                            "imageUrl": "/file/bullet-banner-opportunities.png",
                            "position": 5,
                            "config": {
                                "direction": "left"
                            },
                            "bullets": [
                                "Разделите деловые и личный мессенджеры",
                                "Структурируйте информацию в тематических каналах",
                                "Только релевантные сообщения, без спама и рекламы",
                                "Полная информация о любой сделке всегда в паре кликов"
                            ]
                        },
                        {
                            "type": "bulletBanner",
                            "sysName": "cBulletBanner_investor_1",
                            "visible": true,
                            "header": "**Соинвестируйте** с профессионалами",
                            "bullets": [
                                "Снижайте риски, соинвестируя с лучшими венчурными фондами",
                                "Обеспечьте себе поток лучших сделок",
                                "Расширьте портфель за счёт низкого входного чека",
                                "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
                            ],
                            "position": 1,
                            "config": {
                                "direction": "left"
                            },
                            "description": null,
                            "backgroundColor": "#FFFFFF",
                            "imageUrl": "/file/bullet-banner-invest.png"
                        },
                        {
                            "type": "rectangTiles",
                            "sysName": "cRectangTiles_investor_1",
                            "visible": true,
                            "header": "Уже в сообществе",
                            "position": 2,
                            "config": {},
                            "description": null,
                            "items": [
                                {
                                    "imageUrl": "/file/rectang_tiles_logo1.png"
                                },
                                {
                                    "imageUrl": "/file/rectang_tiles_logo2.png"
                                },
                                {
                                    "imageUrl": "/file/rectang_tiles_logo3.png"
                                },
                                {
                                    "imageUrl": "/file/rectang_tiles_logo4.png"
                                }
                            ]
                        }
                    ],
                    "config": {},
                    "badgeText": null
                }
            ],
            "config": {},
            "theme": "purple-gradient",
            "visible": true,
            "position": 2
        },
        {
            "type": "carousel",
            "sysName": "cCarousel_1",
            "visible": true,
            "position": 3,
            "header": "**Направления** сообщества",
            "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
            "items": [
                "/file/carousel_slide_1.jpeg",
                "/file/carousel_slide_2.jpeg",
                "/file/carousel_slide_3.jpeg"
            ],
            "config": {
                "autorotation": false,
                "delay": 3,
                "speed": 1000,
                "direction": "left"
            }
        },
        {
            "type": "events",
            "sysName": "cEvents_1",
            "visible": true,
            "header": "Событийная кухня",
            "title": "Закрывайте бизнес-потребности через нетворкинг",
            "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
            "position": 4,
            "config": {},
            "features": [
                {
                    "type": "offsetSquares",
                    "sysName": "cOffsetSquares_1",
                    "visible": true,
                    "items": [
                        {
                            "title": "Партнерские мероприятия",
                            "imageUrl": "/file/meetings.png",
                            "tablePosition": {
                                "row": 1,
                                "column": 1
                            }
                        },
                        {
                            "title": "Хакатоны и интенсивы",
                            "imageUrl": "/file/hakatons.png",
                            "tablePosition": {
                                "row": 1,
                                "column": 2
                            }
                        },
                        {
                            "title": "Мероприятия с другими фондами и сообществами",
                            "imageUrl": "/file/another_funds.png",
                            "tablePosition": {
                                "row": 2,
                                "column": 1
                            }
                        },
                        {
                            "title": "Выезды и вечеринки",
                            "imageUrl": "/file/party.png",
                            "tablePosition": {
                                "row": 2,
                                "column": 2
                            }
                        },
                        {
                            "title": "Закрытые очные встречи",
                            "imageUrl": "/file/close-meeting.png",
                            "tablePosition": {
                                "row": 3,
                                "column": 1
                            }
                        },
                        {
                            "title": "Онлайн-митапы",
                            "imageUrl": "/file/onlline-meetings.png",
                            "tablePosition": {
                                "row": 3,
                                "column": 2
                            }
                        }
                    ],
                    "config": {}
                },
                {
                    "type": "button",
                    "sysName": "cEvents_1_button_1",
                    "category": "simple",
                    "visible": true,
                    "default": "active",
                    "text": "Календарь событий",
                    "iconUrl": "/file/calendar.svg",
                    "url": "http://sber.me/?p=k3w6h",
                    "action": "redirect",
                    "config": {},
                    "theme": "purple-gradient"
                }
            ]
        },
        {
            "type": "socialTiles",
            "sysName": "cSocialTiles_1",
            "header": "Контент-студия",
            "visible": true,
            "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
            "position": 5,
            "items": [
                {
                    "title": "Сберстартап",
                    "category": "Telegram-канал",
                    "imageUrl": "/file/content_studio_tg_chanel.jpeg",
                    "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
                    "features": [
                        {
                            "type": "button",
                            "sysName": "cSocialTiles_1_button_1",
                            "category": "simple",
                            "default": "active",
                            "text": "Подписаться",
                            "iconUrl": null,
                            "url": "http://sber.me/?p=m6f1b",
                            "action": "redirect",
                            "config": {},
                            "visible": true,
                            "theme": "default"
                        }
                    ]
                },
                {
                    "title": "Три запятые",
                    "category": "Подкаст",
                    "imageUrl": "/file/content_studio_podcast.jpeg",
                    "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
                    "features": [
                        {
                            "type": "button",
                            "sysName": "cSocialTiles_1_button_2",
                            "category": "simple",
                            "default": "active",
                            "text": "Подписаться",
                            "url": "http://sber.me/?p=NZrMd",
                            "action": "redirect",
                            "visible": true,
                            "iconUrl": null,
                            "config": {},
                            "theme": "default"
                        }
                    ]
                },
                {
                    "title": "VC.RU",
                    "category": "Блог",
                    "imageUrl": "/file/content_studio_blog.jpeg",
                    "description": "Успешные и не очень кейсы участников сообщества",
                    "features": [
                        {
                            "type": "button",
                            "sysName": "cSocialTiles_1_button_3",
                            "category": "simple",
                            "default": "active",
                            "text": "Подписаться",
                            "url": "http://sber.me/?p=9FxbQ",
                            "action": "redirect",
                            "visible": true,
                            "iconUrl": null,
                            "config": {},
                            "theme": "default"
                        }
                    ]
                },
                {
                    "title": "Для стартапов",
                    "category": "YouTube-шоу",
                    "imageUrl": "/file/content_studio_yb_show.jpeg",
                    "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
                    "features": [
                        {
                            "type": "button",
                            "sysName": "cSocialTiles_1_button_4",
                            "category": "simple",
                            "default": "inactive",
                            "text": "Скоро",
                            "iconUrl": "/file/content_studio_clock.svg",
                            "action": "redirect",
                            "visible": true,
                            "url": null,
                            "config": {},
                            "theme": "default"
                        }
                    ]
                }
            ],
            "config": {}
        },
        {
            "type": "banner",
            "sysName": "cFooterBanner_1",
            "visible": true,
            "title": "Подайте заявку и станьте частью сообщества СберСтартап",
            "backgroundUrl": "/file/banner_banner.png",
            "position": 6,
            "description": null,
            "config": {},
            "features": [
                {
                    "type": "button",
                    "sysName": "cFooterBanner_1_button_1",
                    "category": "simple",
                    "default": "active",
                    "text": "Стать частью сообщества",
                    "url": null,
                    "action": "popup",
                    "visible": true,
                    "config": {},
                    "theme": "default"
                }
            ]
        }
    ]
}'
where uri = '/community'
  and code = 'community_nz';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_VENTUREFOND_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_VENTUREFOND_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_VENTUREFOND_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "carousel",
      "sysName": "AZ_VENTUREFOND_cCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      },
      "position": 8
    },
    {
      "type": "events",
      "sysName": "AZ_VENTUREFOND_cEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_VENTUREFOND_cOffsetSquares_1",
          "config": {},
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "tablePosition": {
                "row": 2,
                "column": 1
              },
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png"
            },
            {
              "tablePosition": {
                "row": 2,
                "column": 2
              },
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png"
            },
            {
              "tablePosition": {
                "row": 3,
                "column": 1
              },
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png"
            },
            {
              "tablePosition": {
                "row": 3,
                "column": 2
              },
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png"
            }
          ]
        },
        {
          "type": "button",
          "sysName": "AZ_VENTUREFOND_cEvents_1_button_1",
          "config": {},
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "theme": "purple-gradient"
        }
      ],
      "position": 9
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_VENTUREFOND_cSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_VENTUREFOND_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_VENTUREFOND_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_VENTUREFOND_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_VENTUREFOND_cSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {},
      "position": 10
    },
    {
      "type": "banner",
      "sysName": "AZ_VENTUREFOND_cFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_VENTUREFOND_cFooterBanner_1_button_1",
          "category": "simple",
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ],
      "position": 11
    },
    {
      "type": "bulletBanner",
      "sysName": "AZ_VENTUREFOND_cBulletBanner_investor_1",
      "visible": true,
      "header": "**Соинвестируйте** с профессионалами",
      "bullets": [
        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
        "Обеспечьте себе поток лучших сделок",
        "Расширьте портфель за счёт низкого входного чека",
        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
      ],
      "config": {
        "direction": "left"
      },
      "description": null,
      "backgroundColor": "#FFFFFF",
      "imageUrl": "/file/bullet-banner-invest.png",
      "position": 2
    },
    {
      "type": "rectangTiles",
      "sysName": "AZ_VENTUREFOND_cRectangTiles_investor_1",
      "visible": true,
      "header": "Уже в сообществе",
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/rectang_tiles_logo1.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo2.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo3.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo4.png"
        }
      ],
      "position": 3
    },
    {
      "type": "squareRow",
      "sysName": "AZ_VENTUREFOND_cSquareRow_investor_1",
      "visible": true,
      "header": "Большая **воронка стартапов** на российском рынке",
      "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
      "items": [
        {
          "title": "Знакомим",
          "description": "с основателями стартапов",
          "iconUrl": "/file/squareRow_1.svg"
        },
        {
          "title": "Проводим",
          "description": "предварительный скоринг",
          "iconUrl": "/file/squareRow_2.svg"
        },
        {
          "title": "Рекомендуем",
          "description": "только отобранные проекты",
          "iconUrl": "/file/squareRow_3.svg"
        },
        {
          "title": "Объединяем",
          "description": "инвесторов и стартапы",
          "iconUrl": "/file/squareRow_4.svg"
        }
      ],
      "config": {},
      "position": 4
    },
    {
      "type": "rectangTiles",
      "sysName": "AZ_VENTUREFOND_cRectangTiles_investor_2",
      "visible": true,
      "header": "Наши акселераторы",
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/logo_2_accelerator.png",
          "url": "https://sberstudent.sberclass.ru/"
        },
        {
          "imageUrl": "/file/logo_3_accelerator.png",
          "url": "https://sber-up.ru/"
        },
        {
          "imageUrl": "/file/logo_4_accelerator.png",
          "url": "https://sber-z.sberclass.ru/"
        }
      ],
      "position": 5
    },
    {
      "type": "bulletBanner",
      "sysName": "AZ_VENTUREFOND_cBulletBanner_investor_2",
      "visible": true,
      "header": "**Всё, что нужно —** уже под рукой",
      "description": "Мы организовали сообщество в Slack-каналах",
      "config": {
        "direction": "left"
      },
      "backgroundColor": "#F4F5F9",
      "imageUrl": "/file/bullet-banner-opportunities.png",
      "position": 6,
      "bullets": [
        "Разделите деловые и личный мессенджеры",
        "Структурируйте информацию в тематических каналах",
        "Только релевантные сообщения, без спама и рекламы",
        "Полная информация о любой сделке всегда в паре кликов"
      ]
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_venturefond';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APP_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "title": "**СберСтартап**  \\nсообщество",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "inactive",
          "text": "Заявка уже отправлена",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "bulletBanner",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcBulletBanner_investor_1",
      "visible": true,
      "header": "**Соинвестируйте** с профессионалами",
      "bullets": [
        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
        "Обеспечьте себе поток лучших сделок",
        "Расширьте портфель за счёт низкого входного чека",
        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
      ],
      "position": 2,
      "config": {
        "direction": "left"
      },
      "description": null,
      "backgroundColor": "#FFFFFF",
      "imageUrl": "/file/bullet-banner-invest.png"
    },
    {
      "type": "rectangTiles",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcRectangTiles_investor_1",
      "visible": true,
      "header": "Уже в сообществе",
      "position": 3,
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/rectang_tiles_logo1.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo2.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo3.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo4.png"
        }
      ]
    },
    {
      "type": "squareRow",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSquareRow_investor_1",
      "visible": true,
      "header": "Большая **воронка стартапов** на российском рынке",
      "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
      "position": 4,
      "items": [
        {
          "title": "Знакомим",
          "description": "с основателями стартапов",
          "iconUrl": "/file/squareRow_1.svg"
        },
        {
          "title": "Проводим",
          "description": "предварительный скоринг",
          "iconUrl": "/file/squareRow_2.svg"
        },
        {
          "title": "Рекомендуем",
          "description": "только отобранные проекты",
          "iconUrl": "/file/squareRow_3.svg"
        },
        {
          "title": "Объединяем",
          "description": "инвесторов и стартапы",
          "iconUrl": "/file/squareRow_4.svg"
        }
      ],
      "config": {}
    },
    {
      "type": "rectangTiles",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcRectangTiles_investor_2",
      "visible": true,
      "header": "Наши акселераторы",
      "position": 5,
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/logo_2_accelerator.png",
          "url": "https://sberstudent.sberclass.ru/"
        },
        {
          "imageUrl": "/file/logo_3_accelerator.png",
          "url": "https://sber-up.ru/"
        },
        {
          "imageUrl": "/file/logo_4_accelerator.png",
          "url": "https://sber-z.sberclass.ru/"
        }
      ]
    },
    {
      "type": "bulletBanner",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcBulletBanner_investor_2",
      "visible": true,
      "header": "**Всё, что нужно —** уже под рукой",
      "description": "Мы организовали сообщество в Slack-каналах",
      "position": 6,
      "config": {
        "direction": "left"
      },
      "backgroundColor": "#F4F5F9",
      "imageUrl": "/file/bullet-banner-opportunities.png",
      "bullets": [
        "Разделите деловые и личный мессенджеры",
        "Структурируйте информацию в тематических каналах",
        "Только релевантные сообщения, без спама и рекламы",
        "Полная информация о любой сделке всегда в паре кликов"
      ]
    },
    {
      "type": "carousel",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcCarousel_1",
      "visible": true,
      "position": 7,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      }
    },
    {
      "type": "events",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "position": 8,
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ]
    },
    {
      "type": "socialTiles",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "position": 9,
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {}
    },
    {
      "type": "banner",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "position": 10,
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcFooterBanner_1_button_1",
          "category": "simple",
          "default": "inactive",
          "text": "Заявка уже отправлена",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ]
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_not_confrimed_app_investor';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_FAMILYOFFICE_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_FAMILYOFFICE_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_FAMILYOFFICE_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "carousel",
      "sysName": "AZ_FAMILYOFFICE_cCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      },
      "position": 8
    },
    {
      "type": "events",
      "sysName": "AZ_FAMILYOFFICE_cEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_FAMILYOFFICE_cOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "column": 1,
                "row": 3
              }
            },
            {
              "imageUrl": "/file/onlline-meetings.png",
              "title": "Онлайн-митапы",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "AZ_FAMILYOFFICE_cEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ],
      "position": 9
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_FAMILYOFFICE_cSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_FAMILYOFFICE_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_FAMILYOFFICE_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_FAMILYOFFICE_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_FAMILYOFFICE_cSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {},
      "position": 10
    },
    {
      "type": "banner",
      "sysName": "AZ_FAMILYOFFICE_cFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_FAMILYOFFICE_cFooterBanner_1_button_1",
          "category": "simple",
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ],
      "position": 11
    },
    {
      "type": "bulletBanner",
      "sysName": "AZ_FAMILYOFFICE_cBulletBanner_investor_1",
      "visible": true,
      "header": "**Соинвестируйте** с профессионалами",
      "bullets": [
        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
        "Обеспечьте себе поток лучших сделок",
        "Расширьте портфель за счёт низкого входного чека",
        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
      ],
      "config": {
        "direction": "left"
      },
      "description": null,
      "backgroundColor": "#FFFFFF",
      "imageUrl": "/file/bullet-banner-invest.png",
      "position": 2
    },
    {
      "type": "rectangTiles",
      "sysName": "AZ_FAMILYOFFICE_cRectangTiles_investor_1",
      "visible": true,
      "header": "Уже в сообществе",
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/rectang_tiles_logo1.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo2.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo3.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo4.png"
        }
      ],
      "position": 3
    },
    {
      "type": "squareRow",
      "sysName": "AZ_FAMILYOFFICE_cSquareRow_investor_1",
      "visible": true,
      "header": "Большая **воронка стартапов** на российском рынке",
      "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
      "items": [
        {
          "title": "Знакомим",
          "description": "с основателями стартапов",
          "iconUrl": "/file/squareRow_1.svg"
        },
        {
          "title": "Проводим",
          "description": "предварительный скоринг",
          "iconUrl": "/file/squareRow_2.svg"
        },
        {
          "title": "Рекомендуем",
          "description": "только отобранные проекты",
          "iconUrl": "/file/squareRow_3.svg"
        },
        {
          "title": "Объединяем",
          "description": "инвесторов и стартапы",
          "iconUrl": "/file/squareRow_4.svg"
        }
      ],
      "config": {},
      "position": 4
    },
    {
      "type": "rectangTiles",
      "sysName": "AZ_FAMILYOFFICE_cRectangTiles_investor_2",
      "visible": true,
      "header": "Наши акселераторы",
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/logo_2_accelerator.png",
          "url": "https://sberstudent.sberclass.ru/"
        },
        {
          "imageUrl": "/file/logo_3_accelerator.png",
          "url": "https://sber-up.ru/"
        },
        {
          "imageUrl": "/file/logo_4_accelerator.png",
          "url": "https://sber-z.sberclass.ru/"
        }
      ],
      "position": 5
    },
    {
      "type": "bulletBanner",
      "sysName": "AZ_FAMILYOFFICE_cBulletBanner_investor_2",
      "visible": true,
      "header": "**Всё, что нужно —** уже под рукой",
      "description": "Мы организовали сообщество в Slack-каналах",
      "config": {
        "direction": "left"
      },
      "backgroundColor": "#F4F5F9",
      "imageUrl": "/file/bullet-banner-opportunities.png",
      "bullets": [
        "Разделите деловые и личный мессенджеры",
        "Структурируйте информацию в тематических каналах",
        "Только релевантные сообщения, без спама и рекламы",
        "Полная информация о любой сделке всегда в паре кликов"
      ],
      "position": 6
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_familyoffice';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_CORPORATE_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_CORPORATE_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_CORPORATE_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "mainTabs",
      "sysName": "AZ_CORPORATE_cMainTabs_1",
      "visible": true,
      "position": 2,
      "items": [
        {
          "title": "Стартапам",
          "visible": true,
          "isDefault": true,
          "isActive": true,
          "iconUrl": "/file/participants_ic-startups.svg",
          "position": 1,
          "config": {},
          "features": [
            {
              "type": "roadMap",
              "sysName": "AZ_CORPORATE_сRoadMap_startup_2",
              "visible": true,
              "position": 1,
              "config": {},
              "items": [
                {
                  "title": "[Заполните анкету сообщества]()",
                  "description": "Она находится в личном кабинете в разделе «Сообщество»",
                  "iconUrl": null,
                  "stepNumber": "1"
                },
                {
                  "title": "Дождитесь результата",
                  "description": "В течение 3-х дней мы рассмотрим вашу заявку и вернёмся с обратной связью",
                  "iconUrl": null,
                  "stepNumber": "2"
                },
                {
                  "title": "Присоединитесь к нам",
                  "description": "После прохождения отбора вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                  "iconUrl": null,
                  "stepNumber": "3"
                }
              ],
              "backgroundColor": "#EBECF1",
              "header": "**Как попасть** в сообщество СберСтартап"
            },
            {
              "type": "nearby",
              "sysName": "AZ_CORPORATE_cNearby_startup_1",
              "header": "Мы **рядом** с вами",
              "visible": true,
              "features": [
                {
                  "type": "banner",
                  "sysName": "AZ_CORPORATE_cNearbyBanner_startup_1",
                  "title": "Онлайн",
                  "visible": true,
                  "description": "На платформе Telegram и онлайн-событиях",
                  "iconUrl": "/file/community_banner_il_online.png",
                  "tablePosition": {
                    "row": 1,
                    "column": 1
                  },
                  "config": {},
                  "theme": "default"
                },
                {
                  "type": "banner",
                  "sysName": "AZ_CORPORATE_cNearbyBanner_startup_2",
                  "title": "Оффлайн",
                  "visible": true,
                  "description": "В собственном коворкинге и на закрытых встречах",
                  "iconUrl": "/file/community_banner_il_offline.png",
                  "tablePosition": {
                    "row": 2,
                    "column": 1
                  },
                  "config": {},
                  "theme": "default"
                },
                {
                  "type": "banner",
                  "sysName": "AZ_CORPORATE_cNearbyBanner_startup_3",
                  "title": "Сообщество СберСтартап",
                  "visible": true,
                  "description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
                  "backgroundUrl": "/file/community-banner.png",
                  "tablePosition": {
                    "row": 1,
                    "column": 2
                  },
                  "config": {},
                  "features": [
                    {
                      "type": "button",
                      "sysName": "AZ_CORPORATE_cNearbyBanner_startup_3_button_1",
                      "category": "simple",
                      "default": "active",
                      "text": "Стать частью сообщества",
                      "iconUrl": null,
                      "url": null,
                      "config": {},
                      "action": "popup",
                      "theme": "default"
                    }
                  ],
                  "theme": "purple-gradient"
                }
              ],
              "config": {
                "tableConfiguration": [
                  {
                    "columnNumber": 1,
                    "rows": 2
                  },
                  {
                    "columnNumber": 2,
                    "rows": 1
                  }
                ]
              },
              "position": 3
            },
            {
              "type": "squareList",
              "sysName": "AZ_CORPORATE_сSquareList_startup_1",
              "title": "Что вам **будет доступно**",
              "items": [
                {
                  "title": "Нетворкинг",
                  "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
                  "iconUrl": "/file/ic_96_bubbles.svg"
                },
                {
                  "title": "Экспертиза",
                  "description": "Консультации от профессиональных трекеров и опытных менторов",
                  "iconUrl": "/file/ic_96_person_document.svg"
                },
                {
                  "title": "Контент",
                  "description": "Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
                  "iconUrl": "/file/ic_96_media.svg"
                },
                {
                  "title": "Мероприятия",
                  "description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
                  "iconUrl": "/file/ic_96_calendar_mic.svg"
                },
                {
                  "title": "Закрытый стартап-клуб",
                  "description": "Эксклюзивные мероприятия с инвесторами",
                  "iconUrl": "/file/ic_96_invite_letter.svg"
                },
                {
                  "title": "Поддержка",
                  "description": "Обмен опытом и помощь в решении бизнес-кейсов",
                  "iconUrl": "/file/ic_96_question_notebook.svg"
                }
              ],
              "position": 1,
              "config": {}
            }
          ],
          "badgeText": null
        },
        {
          "visible": true,
          "isDefault": false,
          "isActive": true,
          "iconUrl": "/file/participants_ic-investors.svg",
          "position": 2,
          "title": "Инвесторам",
          "features": [
            {
              "type": "bulletBanner",
              "sysName": "AZ_CORPORATE_cBulletBanner_investor_1",
              "visible": true,
              "header": "**Соинвестируйте** с профессионалами",
              "bullets": [
                "Снижайте риски, соинвестируя с лучшими венчурными фондами",
                "Обеспечьте себе поток лучших сделок",
                "Расширьте портфель за счёт низкого входного чека",
                "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
              ],
              "position": 1,
              "config": {
                "direction": "left"
              },
              "description": null,
              "backgroundColor": "#FFFFFF",
              "imageUrl": "/file/bullet-banner-invest.png"
            },
            {
              "type": "rectangTiles",
              "sysName": "AZ_CORPORATE_cRectangTiles_investor_1",
              "visible": true,
              "header": "Уже в сообществе",
              "items": [
                "/file/rectang_tiles_logo5.png",
                "/file/rectang_tiles_logo2.png",
                "/file/rectang_tiles_logo3.png",
                "/file/rectang_tiles_logo4.png"
              ],
              "position": 2,
              "config": {},
              "description": null
            },
            {
              "type": "squareRow",
              "sysName": "AZ_CORPORATE_cSquareRow_investor_1",
              "visible": true,
              "header": "Большая **воронка стартапов** на российском рынке",
              "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
              "items": [
                {
                  "title": "Знакомим",
                  "description": "с основателями стартапов",
                  "iconUrl": "/file/squareRow_1.svg"
                },
                {
                  "title": "Проводим",
                  "description": "предварительный скоринг",
                  "iconUrl": "/file/squareRow_2.svg"
                },
                {
                  "title": "Рекомендуем",
                  "description": "только отобранные проекты",
                  "iconUrl": "/file/squareRow_3.svg"
                },
                {
                  "title": "Объединяем",
                  "description": "инвесторов и стартапы",
                  "iconUrl": "/file/squareRow_4.svg"
                }
              ],
              "config": {},
              "position": 3
            },
            {
              "type": "rectangTiles",
              "sysName": "AZ_CORPORATE_cRectangTiles_investor_2",
              "visible": true,
              "header": "Наши акселераторы",
              "items": [
                "/file/logo_1_accelerator.png",
                "/file/logo_2_accelerator.png",
                "/file/logo_3_accelerator.png",
                "/file/logo_4_accelerator.png"
              ],
              "position": 4,
              "config": {},
              "description": null
            },
            {
              "type": "bulletBanner",
              "sysName": "AZ_CORPORATE_cBulletBanner_investor_2",
              "visible": true,
              "header": "**Всё, что нужно —** уже под рукой",
              "description": "Мы организовали сообщество в Slack-каналах",
              "position": 3,
              "config": {
                "direction": "left"
              },
              "backgroundColor": "#F4F5F9",
              "imageUrl": "/file/bullet-banner-opportunities.png",
              "bullets": [
                "Разделите деловые и личный мессенджеры",
                "Структурируйте информацию в тематических каналах",
                "Только релевантные сообщения, без спама и рекламы",
                "Полная информация о любой сделке всегда в паре кликов"
              ]
            }
          ],
          "config": {},
          "badgeText": null
        }
      ],
      "config": {},
      "theme": "purple-gradient"
    },
    {
      "type": "carousel",
      "sysName": "AZ_CORPORATE_cCarousel_1",
      "visible": true,
      "position": 3,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      }
    },
    {
      "type": "events",
      "sysName": "AZ_CORPORATE_cEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "position": 4,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_CORPORATE_cEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        },
        {
          "type": "offsetSquares",
          "sysName": "AZ_CORPORATE_cOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        }
      ]
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_CORPORATE_cSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "position": 5,
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CORPORATE_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CORPORATE_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CORPORATE_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CORPORATE_cSocialTiles_1_button_4",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default",
              "category": "simple"
            }
          ]
        }
      ],
      "config": {}
    },
    {
      "type": "banner",
      "sysName": "AZ_CORPORATE_cFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "position": 6,
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_CORPORATE_cFooterBanner_1_button_1",
          "category": "simple",
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ]
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_corporate';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_BUSINESSANGEL_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_BUSINESSANGEL_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_BUSINESSANGEL_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "carousel",
      "sysName": "AZ_BUSINESSANGEL_cCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      },
      "position": 7
    },
    {
      "type": "events",
      "sysName": "AZ_BUSINESSANGEL_cEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_BUSINESSANGEL_cOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "AZ_BUSINESSANGEL_cEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ],
      "position": 8
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_BUSINESSANGEL_cSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_BUSINESSANGEL_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_BUSINESSANGEL_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_BUSINESSANGEL_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_BUSINESSANGEL_cSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {},
      "position": 9
    },
    {
      "type": "banner",
      "sysName": "AZ_BUSINESSANGEL_cFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "description": null,
      "features": [
        {
          "type": "button",
          "sysName": "AZ_BUSINESSANGEL_cFooterBanner_1_button_1",
          "category": "simple",
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ],
      "config": {},
      "position": 10
    },
    {
      "type": "bulletBanner",
      "sysName": "AZ_BUSINESSANGEL_cBulletBanner_investor_1",
      "visible": true,
      "header": "**Соинвестируйте** с профессионалами",
      "bullets": [
        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
        "Обеспечьте себе поток лучших сделок",
        "Расширьте портфель за счёт низкого входного чека",
        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
      ],
      "position": 2,
      "config": {
        "direction": "left"
      },
      "description": null,
      "backgroundColor": "#FFFFFF",
      "imageUrl": "/file/bullet-banner-invest.png"
    },
    {
      "type": "rectangTiles",
      "sysName": "AZ_BUSINESSANGEL_cRectangTiles_investor_1",
      "visible": true,
      "header": "Уже в сообществе",
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/rectang_tiles_logo1.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo2.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo3.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo4.png"
        }
      ],
      "position": 3
    },
    {
      "type": "squareRow",
      "sysName": "AZ_BUSINESSANGEL_cSquareRow_investor_1",
      "visible": true,
      "header": "Большая **воронка стартапов** на российском рынке",
      "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
      "items": [
        {
          "title": "Знакомим",
          "description": "с основателями стартапов",
          "iconUrl": "/file/squareRow_1.svg"
        },
        {
          "title": "Проводим",
          "description": "предварительный скоринг",
          "iconUrl": "/file/squareRow_2.svg"
        },
        {
          "title": "Рекомендуем",
          "description": "только отобранные проекты",
          "iconUrl": "/file/squareRow_3.svg"
        },
        {
          "title": "Объединяем",
          "description": "инвесторов и стартапы",
          "iconUrl": "/file/squareRow_4.svg"
        }
      ],
      "config": {},
      "position": 4
    },
    {
      "type": "rectangTiles",
      "sysName": "AZ_BUSINESSANGEL_cRectangTiles_investor_2",
      "visible": true,
      "header": "Наши акселераторы",
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/logo_2_accelerator.png",
          "url": "https://sberstudent.sberclass.ru/"
        },
        {
          "imageUrl": "/file/logo_3_accelerator.png",
          "url": "https://sber-up.ru/"
        },
        {
          "imageUrl": "/file/logo_4_accelerator.png",
          "url": "https://sber-z.sberclass.ru/"
        }
      ],
      "position": 5
    },
    {
      "type": "bulletBanner",
      "sysName": "AZ_BUSINESSANGEL_cBulletBanner_investor_2",
      "visible": true,
      "header": "**Всё, что нужно —** уже под рукой",
      "description": "Мы организовали сообщество в Slack-каналах",
      "config": {
        "direction": "left"
      },
      "backgroundColor": "#F4F5F9",
      "imageUrl": "/file/bullet-banner-opportunities.png",
      "position": 6,
      "bullets": [
        "Разделите деловые и личный мессенджеры",
        "Структурируйте информацию в тематических каналах",
        "Только релевантные сообщения, без спама и рекламы",
        "Полная информация о любой сделке всегда в паре кликов"
      ]
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_businessangel';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_NOT_CONFIRMED_APP_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_NOT_CONFIRMED_APPcMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "inactive",
          "text": "Заявка уже направлена",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_NOT_CONFIRMED_APPcMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "carousel",
      "sysName": "AZ_NOT_CONFIRMED_APPcCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "position": 5,
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      }
    },
    {
      "type": "events",
      "sysName": "AZ_NOT_CONFIRMED_APPcEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_NOT_CONFIRMED_APPcOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "AZ_NOT_CONFIRMED_APPcEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ],
      "position": 6
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "config": {},
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_2",
              "iconUrl": null,
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "theme": "default",
              "config": {}
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "position": 7
    },
    {
      "type": "banner",
      "sysName": "AZ_NOT_CONFIRMED_APPcFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_NOT_CONFIRMED_APPcFooterBanner_1_button_1",
          "category": "simple",
          "default": "inactive",
          "text": "Заявка уже отправлена",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ],
      "position": 8
    },
    {
      "type": "squareList",
      "sysName": "AZ_NOT_CONFIRMED_APPсSquareList_startup_1",
      "title": "Что вам **будет доступно**",
      "items": [
        {
          "title": "Нетворкинг",
          "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
          "iconUrl": "/file/ic_96_bubbles.svg"
        },
        {
          "title": "Экспертиза",
          "description": "Консультации от профессиональных трекеров и опытных менторов",
          "iconUrl": "/file/ic_96_person_document.svg"
        },
        {
          "title": "Контент",
          "description": "Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
          "iconUrl": "/file/ic_96_media.svg"
        },
        {
          "title": "Мероприятия",
          "description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
          "iconUrl": "/file/ic_96_calendar_mic.svg"
        },
        {
          "title": "Закрытый стартап-клуб",
          "description": "Эксклюзивные мероприятия с инвесторами",
          "iconUrl": "/file/ic_96_invite_letter.svg"
        },
        {
          "title": "Поддержка",
          "description": "Обмен опытом и помощь в решении бизнес-кейсов",
          "iconUrl": "/file/ic_96_question_notebook.svg"
        }
      ],
      "config": {},
      "visible": true,
      "position": 2
    },
    {
      "type": "roadMap",
      "sysName": "AZ_NOT_CONFIRMED_APPсRoadMap_startup_2",
      "visible": true,
      "config": {},
      "items": [
        {
          "title": "Вы уже заполнили анкету",
          "description": "В ближайшее время наш комьюнити-менеджер свяжется с вами",
          "iconUrl": "/file/roadmap_done.svg",
          "stepNumber": null
        },
        {
          "title": "Дождитесь результата",
          "description": "В течение 3-х дней мы рассмотрим вашу заявку и вернёмся с обратной связью",
          "iconUrl": null,
          "stepNumber": "2"
        },
        {
          "title": "Присоединитесь к нам",
          "description": "После прохождения отбора вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
          "iconUrl": null,
          "stepNumber": "3"
        }
      ],
      "backgroundColor": "#EBECF1",
      "header": "**Как попасть** в сообщество СберСтартап",
      "position": 3
    },
    {
      "type": "nearby",
      "sysName": "AZ_NOT_CONFIRMED_APPcNearby_startup_1",
      "header": "Мы **рядом** с вами",
      "visible": true,
      "features": [
        {
          "type": "banner",
          "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_1",
          "title": "Онлайн",
          "visible": true,
          "description": "На платформе Telegram и онлайн-событиях",
          "iconUrl": "/file/community_banner_il_online.png",
          "tablePosition": {
            "row": 1,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_2",
          "title": "Оффлайн",
          "visible": true,
          "description": "В собственном коворкинге и на закрытых встречах",
          "iconUrl": "/file/community_banner_il_offline.png",
          "tablePosition": {
            "row": 2,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_3",
          "title": "Сообщество СберСтартап",
          "visible": true,
          "description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
          "backgroundUrl": "/file/community-banner.png",
          "tablePosition": {
            "row": 1,
            "column": 2
          },
          "config": {},
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_3_button_1",
              "category": "simple",
              "default": "inactive",
              "text": "Заявка уже отправлена",
              "iconUrl": null,
              "url": null,
              "config": {},
              "action": "popup",
              "theme": "default"
            }
          ],
          "theme": "purple-gradient"
        }
      ],
      "config": {
        "tableConfiguration": [
          {
            "columnNumber": 1,
            "rows": 2
          },
          {
            "columnNumber": 2,
            "rows": 1
          }
        ]
      },
      "position": 4
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_not_confrimed_app_startup';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_CONFIRMED_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "title": "**СберСтартап**  \\nсообщество",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_CONFIRMED_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "inactive",
          "text": "Вы уже в сообществе",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_CONFIRMED_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "carousel",
      "sysName": "AZ_CONFIRMED_cCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      },
      "position": 9
    },
    {
      "type": "events",
      "sysName": "AZ_CONFIRMED_cEvents_1",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_CONFIRMED_cOffsetSquares_1",
          "items": [
            {
              "tablePosition": {
                "row": 1,
                "column": 1
              },
              "imageUrl": "/file/meetings.png",
              "title": "Партнерские мероприятия"
            },
            {
              "tablePosition": {
                "row": 1,
                "column": 2
              },
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png"
            },
            {
              "tablePosition": {
                "row": 2,
                "column": 1
              },
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png"
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "visible": true,
          "config": {}
        },
        {
          "type": "button",
          "sysName": "AZ_CONFIRMED_cEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ],
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "position": 10
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_CONFIRMED_cSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CONFIRMED_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CONFIRMED_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CONFIRMED_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CONFIRMED_cSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {},
      "position": 11
    },
    {
      "type": "squareList",
      "sysName": "AZ_CONFIRMED_сSquareList_startup_1",
      "items": [
        {
          "title": "Нетворкинг",
          "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
          "iconUrl": "/file/ic_96_bubbles.svg"
        },
        {
          "title": "Экспертиза",
          "description": "Консультации от профессиональных трекеров и опытных менторов",
          "iconUrl": "/file/ic_96_person_document.svg"
        },
        {
          "title": "Контент",
          "description": "Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
          "iconUrl": "/file/ic_96_media.svg"
        },
        {
          "title": "Мероприятия",
          "description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
          "iconUrl": "/file/ic_96_calendar_mic.svg"
        },
        {
          "title": "Закрытый стартап-клуб",
          "description": "Эксклюзивные мероприятия с инвесторами",
          "iconUrl": "/file/ic_96_invite_letter.svg"
        },
        {
          "title": "Поддержка",
          "description": "Обмен опытом и помощь в решении бизнес-кейсов",
          "iconUrl": "/file/ic_96_question_notebook.svg"
        }
      ],
      "config": {},
      "visible": true,
      "title": "Что вам **доступно**",
      "position": 2
    },
    {
      "type": "nearby",
      "sysName": "AZ_CONFIRMED_cNearby_startup_1",
      "header": "Мы **рядом** с вами",
      "visible": true,
      "features": [
        {
          "type": "banner",
          "sysName": "AZ_CONFIRMED_cNearbyBanner_startup_1",
          "title": "Онлайн",
          "visible": true,
          "description": "На платформе Telegram и онлайн-событиях",
          "iconUrl": "/file/community_banner_il_online.png",
          "tablePosition": {
            "row": 1,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_CONFIRMED_cNearbyBanner_startup_2",
          "title": "Оффлайн",
          "visible": true,
          "description": "В собственном коворкинге и на закрытых встречах",
          "iconUrl": "/file/community_banner_il_offline.png",
          "tablePosition": {
            "row": 2,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_CONFIRMED_cNearbyBanner_startup_3",
          "title": "Сообщество СберСтартап",
          "visible": true,
          "description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
          "backgroundUrl": "/file/community-banner.png",
          "tablePosition": {
            "row": 1,
            "column": 2
          },
          "config": {},
          "features": [
            {
              "type": "button",
              "sysName": "AZ_CONFIRMED_cNearbyBanner_startup_3_button_1",
              "category": "simple",
              "default": "inactive",
              "text": "Вы уже в сообществе",
              "iconUrl": null,
              "url": null,
              "config": {},
              "action": "popup",
              "theme": "default"
            }
          ],
          "theme": "purple-gradient"
        }
      ],
      "config": {
        "tableConfiguration": [
          {
            "columnNumber": 1,
            "rows": 2
          },
          {
            "columnNumber": 2,
            "rows": 1
          }
        ]
      },
      "position": 8
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_confrimed_app_startup';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_STARTUP_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_STARTUP_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        },
        {
          "type": "button",
          "sysName": "AZ_STARTUP_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "squareList",
      "sysName": "AZ_STARTUP_сSquareList_startup_1",
      "title": "Что вам **будет доступно**",
      "items": [
        {
          "title": "Нетворкинг",
          "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
          "iconUrl": "/file/ic_96_bubbles.svg"
        },
        {
          "title": "Экспертиза",
          "description": "Консультации от профессиональных трекеров и опытных менторов",
          "iconUrl": "/file/ic_96_person_document.svg"
        },
        {
          "description": "Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
          "iconUrl": "/file/ic_96_media.svg",
          "title": "Контент"
        },
        {
          "title": "Мероприятия",
          "description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
          "iconUrl": "/file/ic_96_calendar_mic.svg"
        },
        {
          "title": "Закрытый стартап-клуб",
          "description": "Эксклюзивные мероприятия с инвесторами",
          "iconUrl": "/file/ic_96_invite_letter.svg"
        },
        {
          "title": "Поддержка",
          "description": "Обмен опытом и помощь в решении бизнес-кейсов",
          "iconUrl": "/file/ic_96_question_notebook.svg"
        }
      ],
      "config": {},
      "visible": true,
      "position": 2
    },
    {
      "type": "carousel",
      "sysName": "AZ_STARTUP_cCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      },
      "position": 5
    },
    {
      "type": "events",
      "sysName": "AZ_STARTUP_cEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_STARTUP_cOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "AZ_STARTUP_cEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ],
      "position": 6
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_STARTUP_cSocialTiles_1",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "header": "Контент-студия",
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_STARTUP_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_STARTUP_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_STARTUP_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_STARTUP_cSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {},
      "position": 7
    },
    {
      "type": "banner",
      "sysName": "AZ_STARTUP_cFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_STARTUP_cFooterBanner_1_button_1",
          "category": "simple",
          "default": "active",
          "text": "Стать частью сообщества",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ],
      "position": 8
    },
    {
      "type": "roadMap",
      "sysName": "AZ_STARTUP_сRoadMap_startup_2",
      "visible": true,
      "config": {},
      "items": [
        {
          "title": "[Заполните анкету сообщества]()",
          "description": "Она находится в личном кабинете в разделе «Сообщество»",
          "iconUrl": null,
          "stepNumber": "1"
        },
        {
          "title": "Дождитесь результата",
          "description": "В течение 3-х дней мы рассмотрим вашу заявку и вернёмся с обратной связью",
          "iconUrl": null,
          "stepNumber": "2"
        },
        {
          "title": "Присоединитесь к нам",
          "description": "После прохождения отбора вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
          "iconUrl": null,
          "stepNumber": "3"
        }
      ],
      "backgroundColor": "#EBECF1",
      "header": "**Как попасть** в сообщество СберСтартап",
      "position": 3
    },
    {
      "type": "nearby",
      "sysName": "AZ_STARTUP_cNearby_startup_1",
      "header": "Мы **рядом** с вами",
      "visible": true,
      "features": [
        {
          "type": "banner",
          "sysName": "AZ_STARTUP_cNearbyBanner_startup_1",
          "title": "Онлайн",
          "visible": true,
          "description": "На платформе Telegram и онлайн-событиях",
          "iconUrl": "/file/community_banner_il_online.png",
          "tablePosition": {
            "row": 1,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_STARTUP_cNearbyBanner_startup_2",
          "title": "Оффлайн",
          "visible": true,
          "description": "В собственном коворкинге и на закрытых встречах",
          "iconUrl": "/file/community_banner_il_offline.png",
          "tablePosition": {
            "row": 2,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_STARTUP_cNearbyBanner_startup_3",
          "title": "Сообщество СберСтартап",
          "visible": true,
          "description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
          "backgroundUrl": "/file/community-banner.png",
          "tablePosition": {
            "row": 1,
            "column": 2
          },
          "config": {},
          "features": [
            {
              "type": "button",
              "sysName": "AZ_STARTUP_cNearbyBanner_startup_3_button_1",
              "category": "simple",
              "default": "active",
              "text": "Стать частью сообщества",
              "iconUrl": null,
              "url": null,
              "config": {},
              "action": "popup",
              "theme": "default"
            }
          ],
          "theme": "purple-gradient"
        }
      ],
      "config": {
        "tableConfiguration": [
          {
            "columnNumber": 1,
            "rows": 2
          },
          {
            "columnNumber": 2,
            "rows": 1
          }
        ]
      },
      "position": 4
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_startup';

update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "INVESTOR_AZ_CONFIRMED_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_CONFIRMED_cMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "inactive",
          "text": "Вы уже в сообществе",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "INVESTOR_AZ_CONFIRMED_cMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "bulletBanner",
      "sysName": "INVESTOR_AZ_CONFIRMED_cBulletBanner_investor_1",
      "visible": true,
      "header": "**Соинвестируйте** с профессионалами",
      "bullets": [
        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
        "Обеспечьте себе поток лучших сделок",
        "Расширьте портфель за счёт низкого входного чека",
        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
      ],
      "position": 2,
      "config": {
        "direction": "left"
      },
      "description": null,
      "backgroundColor": "#FFFFFF",
      "imageUrl": "/file/bullet-banner-invest.png"
    },
    {
      "type": "rectangTiles",
      "sysName": "INVESTOR_AZ_CONFIRMED_cRectangTiles_investor_1",
      "visible": true,
      "header": "Уже в сообществе",
      "position": 3,
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/rectang_tiles_logo1.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo2.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo3.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo4.png"
        }
      ]
    },
    {
      "type": "squareRow",
      "sysName": "INVESTOR_AZ_CONFIRMED_cSquareRow_investor_1",
      "visible": true,
      "header": "Большая **воронка стартапов** на российском рынке",
      "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
      "position": 4,
      "items": [
        {
          "title": "Знакомим",
          "description": "с основателями стартапов",
          "iconUrl": "/file/squareRow_1.svg"
        },
        {
          "title": "Проводим",
          "description": "предварительный скоринг",
          "iconUrl": "/file/squareRow_2.svg"
        },
        {
          "title": "Рекомендуем",
          "description": "только отобранные проекты",
          "iconUrl": "/file/squareRow_3.svg"
        },
        {
          "title": "Объединяем",
          "description": "инвесторов и стартапы",
          "iconUrl": "/file/squareRow_4.svg"
        }
      ],
      "config": {}
    },
    {
      "type": "rectangTiles",
      "sysName": "INVESTOR_AZ_CONFIRMED_cRectangTiles_investor_2",
      "visible": true,
      "header": "Наши акселераторы",
      "position": 5,
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/logo_2_accelerator.png",
          "url": "https://sberstudent.sberclass.ru/"
        },
        {
          "imageUrl": "/file/logo_3_accelerator.png",
          "url": "https://sber-up.ru/"
        },
        {
          "imageUrl": "/file/logo_4_accelerator.png",
          "url": "https://sber-z.sberclass.ru/"
        }
      ]
    },
    {
      "type": "bulletBanner",
      "sysName": "INVESTOR_AZ_CONFIRMED_cBulletBanner_investor_2",
      "visible": true,
      "header": "**Всё, что нужно —** уже под рукой",
      "description": "Мы организовали сообщество в Slack-каналах",
      "position": 6,
      "config": {
        "direction": "left"
      },
      "backgroundColor": "#F4F5F9",
      "imageUrl": "/file/bullet-banner-opportunities.png",
      "bullets": [
        "Разделите деловые и личный мессенджеры",
        "Структурируйте информацию в тематических каналах",
        "Только релевантные сообщения, без спама и рекламы",
        "Полная информация о любой сделке всегда в паре кликов"
      ]
    },
    {
      "type": "carousel",
      "sysName": "INVESTOR_AZ_CONFIRMED_cCarousel_1",
      "visible": true,
      "position": 7,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      }
    },
    {
      "type": "events",
      "sysName": "INVESTOR_AZ_CONFIRMED_cEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "position": 8,
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "INVESTOR_AZ_CONFIRMED_cOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_CONFIRMED_cEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ]
    },
    {
      "type": "socialTiles",
      "sysName": "INVESTOR_AZ_CONFIRMED_cSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "position": 9,
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=NZrMd",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=9FxbQ",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстремальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {}
    }
  ]
}'
where uri = '/community'
  and code = 'community_az_confrimed_app_investor';