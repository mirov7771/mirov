--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5379
update screen
set formname = replace(formname, 'CorpDemo','CorpLight')
where formname like '%CorpDemo%';

update screen
set formname = replace(formname, 'InvestDemo','InvestLight')
where formname like '%InvestDemo%';