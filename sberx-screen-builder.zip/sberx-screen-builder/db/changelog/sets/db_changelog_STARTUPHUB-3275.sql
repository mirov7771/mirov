--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3275
delete from screen_buttons_link where screen_id not in (select screen_id from screen_button);
delete from screen_button where name like '%Community%';
insert into screen_button (name) values('New_PreAuth_Community_StartUp');
insert into screen_button (name) values('New_PreAuth_Community_VentureFond');
insert into screen_button (name) values('New_PreAuth_Community_BusinessAngel');
insert into screen_button (name) values('New_PreAuth_Community_FamilyOffice');
insert into screen_button (name) values('New_PreAuth_Community_Corporate');
insert into screen_button (name) values('New_Community_StartUp');
insert into screen_button (name) values('New_Community_VentureFond');
insert into screen_button (name) values('New_Community_BusinessAngel');
insert into screen_button (name) values('New_Community_FamilyOffice');
insert into screen_button (name) values('New_Community_Corporate');


delete from buttons where code in (200001, 200002, 200003, 200004);
insert into buttons (code, "text", click_action, lang_id) values (200001, 'Войти', '/auth', 1);
insert into buttons (code, "text", click_action, lang_id) values (200002, 'Зарегистрироваться', '/registration', 1);
insert into buttons (code, "text", click_action, click_method, lang_id) values (200003, 'Отправить заявку', '/community', 'POST', 1);
insert into buttons (code, "text", click_action, lang_id) values (200004, 'Отменить', '$close_popup', 1);

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_StartUp'), (select button_id from buttons where code = 200001));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_StartUp'), (select button_id from buttons where code = 200002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_VentureFond'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_VentureFond'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_BusinessAngel'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_BusinessAngel'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_FamilyOffice'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_FamilyOffice'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_Corporate'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_PreAuth_Community_Corporate'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_StartUp'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_StartUp'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_VentureFond'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_VentureFond'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_BusinessAngel'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_BusinessAngel'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_FamilyOffice'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_FamilyOffice'), (select button_id from buttons where code = 200004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_Corporate'), (select button_id from buttons where code = 200003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where "name" = 'New_Community_Corporate'), (select button_id from buttons where code = 200004));