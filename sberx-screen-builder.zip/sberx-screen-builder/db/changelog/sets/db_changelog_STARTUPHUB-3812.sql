--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3812
delete from public.screen_button where name in ('pilot_SuperClient','corporate_SuperClient','investor_SuperClient','startup_SuperClient') and favorite = true and state = 20004;
delete from public.screen_button where name in ('pilot_SuperClient','corporate_SuperClient','investor_SuperClient','startup_SuperClient') and favorite = false and state = 20004;

insert into public.screen_button (name, favorite, state) values('pilot_SuperClient', true, 20004);
insert into public.screen_button (name, favorite, state) values('pilot_SuperClient', false, 20004);

insert into public.screen_button (name, favorite, state) values('corporate_SuperClient', true, 20004);
insert into public.screen_button (name, favorite, state) values('corporate_SuperClient', false, 20004);

insert into public.screen_button (name, favorite, state) values('investor_SuperClient', true, 20004);
insert into public.screen_button (name, favorite, state) values('investor_SuperClient', false, 20004);

insert into public.screen_button (name, favorite, state) values('startup_SuperClient', true, 20004);
insert into public.screen_button (name, favorite, state) values('startup_SuperClient', false, 20004);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'pilot_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'pilot_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100006));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'pilot_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'pilot_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100005));



insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'corporate_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'corporate_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100001));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'corporate_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100006));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'corporate_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'corporate_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100001));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'corporate_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100005));


insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'startup_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'startup_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100006));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'startup_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'startup_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100005));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'investor_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'investor_SuperClient' and state = 20004 and favorite = true limit 1),
       (select button_id from buttons where code = 100006));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'investor_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'investor_SuperClient' and state = 20004 and favorite = false limit 1),
       (select button_id from buttons where code = 100005));
