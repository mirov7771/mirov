--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-2884

CREATE TABLE public.widget_types (
                                     id bigserial primary key,
                                     code varchar NOT NULL,
                                     name varchar

);

CREATE TABLE public.page_types (
                                   id bigserial primary key,
                                   code varchar NOT NULL,
                                   name varchar

);

CREATE TABLE public.locale (
                               id bigserial primary key,
                               code varchar NOT NULL,
                               name varchar

);


CREATE TABLE public.widgets (
                                id bigserial primary key,
                                code varchar NOT NULL,
                                name varchar,
                                parent_id bigint,
                                id_widget_types bigint references public.widget_types (id),
                                description varchar

);

CREATE TABLE public.attribute_types (
                                        id bigserial primary key,
                                        code varchar NOT NULL,
                                        name varchar

);


CREATE TABLE public.attributes (
                                   id bigserial primary key,
                                   name varchar NOT NULL,
                                   code varchar NOT NULL,
                                   parent_id bigint references public.attributes (id),
                                   id_attribute_types bigint references public.attribute_types (id)

);
CREATE TABLE public.values (
                               id bigserial primary key,
                               value varchar NOT NULL,
                               id_locale bigint references public.locale (id)

);

CREATE TABLE public.attribute_values (
                                         id bigserial primary key,
                                         id_attributes bigint references public.attributes (id),
                                         id_values bigint references public.values (id)

);

CREATE TABLE public.widget_attributes_values (
                                                 id bigserial primary key,
                                                 id_attribute_values bigint references public.attribute_values (id),
                                                 id_widgets bigint references public.widgets (id)

);
CREATE TABLE public.pages (
                              id bigserial primary key,
                              code varchar NOT NULL,
                              name varchar,
                              URI varchar NOT NULL,
                              description varchar,
                              id_page_types bigint references public.page_types (id),
                              parent_id bigint references public.pages (id)

);
CREATE TABLE public.pages_widgets (
                                      id bigserial primary key,
                                      id_widgets bigint references public.widgets (id),
                                      id_pages bigint references public.pages (id)
);