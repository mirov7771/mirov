--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.screen
set description = '<br/>Filling out the questionnaire will take about 15 minutes.  <br/>
<br/>The data is saved automatically when you go to the next step of the questionnaire. <br/>
<br/>The "*" symbol indicates the infornation that will be available only to the administrators of SberUnity for review. <br/>
<br/>The data from the remaining fields will be available to other users. <br/>'
where formname = 'startup_edit'
  and lang_id = 2;