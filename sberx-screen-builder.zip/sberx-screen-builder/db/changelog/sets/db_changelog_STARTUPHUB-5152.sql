--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-5152

update public.pages set name = 'Startups' where code = 'startups_nz_auth_en';
update public.pages set name = 'Startups' where code = 'startups_nz_unauth_en';

update public.pages set name = 'Corporates' where code = 'corporates_nz_auth_en';
update public.pages set name = 'Corporates' where code = 'corporates_nz_unauth_en';

update public.pages set name = 'Investors' where code = 'investors_nz_auth_en';
update public.pages set name = 'Investors' where code = 'investors_nz_unauth_en';

update public.pages set name = 'Pilots' where code = 'pilot_nz_unauth_en';

update public.pages set name = 'Vas' where code = 'vas_az_auth_en';
update public.pages set name = 'Vas' where code = 'vas_nz_unauth_en';