--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-4755 Заведение JSON по CSI

delete from public.screen where formname in ('success_csi','add_csi');

INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES
                                                                                                                                                                 (0,'success_csi',NULL,NULL,'Спасибо за ваш ответ!',NULL,0,NULL,NULL,NULL,NULL,1,NULL),
                                                                                                                                                                 (0,'add_csi','{
                                                                                                                                                                   "form": [
                                                                                                                                                                     {
                                                                                                                                                                       "page": 1,
                                                                                                                                                                       "fields": [
                                                                                                                                                                         {
                                                                                                                                                                           "localName": "Насколько вы удовлетворены сайтом SberUnity?",
                                                                                                                                                                           "type": "array",
                                                                                                                                                                           "required": true,
                                                                                                                                                                           "edited": true,
                                                                                                                                                                           "format": "chip",
                                                                                                                                                                           "sysName": "csi",
                                                                                                                                                                           "multySelect": false,
                                                                                                                                                                           "values": [
                                                                                                                                                                             {
                                                                                                                                                                               "code": "1",
                                                                                                                                                                               "name": "1",
                                                                                                                                                                               "description": "Очень плохо"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "code": "2",
                                                                                                                                                                               "name": "2"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "code": "3",
                                                                                                                                                                               "name": "3"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "code": "4",
                                                                                                                                                                               "name": "4"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "code": "5",
                                                                                                                                                                               "name": "5",
                                                                                                                                                                               "description": "Очень хорошо"
                                                                                                                                                                             }
                                                                                                                                                                           ]
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }
                                                                                                                                                                   ]
                                                                                                                                                                 }
                                                                                                                                                                 ',NULL,'CSI',NULL,1,NULL,NULL,NULL,NULL,1,NULL);