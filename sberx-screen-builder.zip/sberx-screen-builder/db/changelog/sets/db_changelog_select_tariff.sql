--liquibase formatted sql
--changeset Mirov AA:select_tariff
delete from pages where code in ('tariff_auth_ru','corporations_tariff_auth_ru','investors_tariff_auth_ru');
delete from pages where code in ('tariff_auth_ru','corporations_tariff_auth_ru','investors_tariff_auth_ru');
insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('tariff_auth_ru', 'Выбор тарифа | SberUnity', '/select-tariff', 'Выбор тарифа', 'auth',
        '{
           "features":[
              {
                 "type":"spacer",
                 "visible":true,
                 "position":1,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"backButton",
                 "label":"Назад",
                 "sysName":"back",
                 "visible":true,
                 "position":2
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":2,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Выберите тариф",
                 "sysName":"title",
                 "visible":true,
                 "position":3,
                 "config":{
                    "styles":{
                       "padding":{
                          "xs":{
                             "top":16,
                             "bottom":8
                          },
                          "s":{
                             "top":16,
                             "bottom":8
                          },
                          "md":{
                             "top":24,
                             "bottom":16
                          },
                          "lg":{
                             "top":24,
                             "bottom":16
                          }
                       }
                    }
                 }
              },
              {
                 "type":"baseText",
                 "size":{
                    "mobile":"m",
                    "desktop":"l"
                 },
                 "text":"В зависимости от выбранного тарифа, вам будут доступны разные возможности SberUnity",
                 "visible":true,
                 "position":4,
                 "sysName":"baseText"
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":5,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":32,
                    "desktop":40
                 }
              },
              {
                 "type":"tariffs",
                 "visible":true,
                 "position":6,
                 "sysName":"tariffs",
                 "tariffs":[
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpLight",
                       "nameTariff":"Light",
                       "priceTariff":"12 000 ₽ в год",
                       "descriptionTariff":[
                          "Краткая информация о&nbsp;стартапе",
                          "5 запросов на&nbsp;технологии",
                          "Ограниченные уведомления",
                          "1 пользователь"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpLight",
                          "text": " %isCorpLightText% ",
                          "disabled": " %isCorpLight% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpPro",
                       "nameTariff":"Pro",
                       "priceTariff":"1 200 000 ₽ в год",
                       "descriptionTariff":[
                          "Полная информация о стартапе",
                          "Запросы на технологии без&nbsp;ограничений",
                          "Все уведомления доступны",
                          "До 3 пользователей"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpPro",
                          "text": " %isCorpProText% ",
                          "disabled": " %isCorpPro% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":true
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpProPlus",
                       "nameTariff":"Pro Plus",
                       "priceTariff":"2 000 000 ₽ в год",
                       "descriptionTariff":[
                          "Все преимущества тарифа Pro",
                          "PR-продвижение на&nbsp;платформе",
                          "Услуга скаутинга включена",
                          "До 5 пользователей"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpProPlus",
                          "text": " %isCorpProPlusText% ",
                          "disabled": " %isCorpProPlus% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    }
                 ]
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":6,
                 "sysName":"spacer2",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":48,
                    "desktop":64
                 }
              },
              {
                 "type":"tariffsTable",
                 "position":7,
                 "sysName":"tariffsTable",
                 "visible":true,
                 "header":{
                    "highlightHeader":"Базы участников",
                    "tariffs":[
                       "Light",
                       "Pro",
                       "Pro Plus"
                    ]
                 },
                 "content":[
                    {
                       "type":"subAdvantagesName",
                       "text":"База стартапов"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Краткая информация о&nbsp;стартапе"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Полная информация о&nbsp;стартапе"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Полная информация о&nbsp;стартапе"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"База инвесторов"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Фильтрация"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только по индустриям"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все фильтры"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все фильтры"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Функции платформы"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Рекомендованные стартапы"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только 3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без ограничений"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без ограничений"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Избранные"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Сохранение на 30 дней"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Просмотренные"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Сохранение на 30 дней"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Доступность"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Количество пользователей"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"5"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Уведомления на почту"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только отклики на&nbsp;запросы"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все уведомления"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все уведомления"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Дополнительно"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Скаутинг (3 потребности)"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"PR-продвижение"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Приоритетный показ в списке корпораций"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без приоритета"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"7 дней в год"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"30 дней в год"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Email-рассылка по&nbsp;базе SberUnity"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 раз в дайджесте"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 рассылка, 1&nbsp;новость в&nbsp;дайджесте"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Пост в телеграм-канале SberUnity"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 раз в дайджесте"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 пост, 1&nbsp;новость в&nbsp;дайджесте"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Пост в телеграм-канале СберСтартап"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 пост, 1&nbsp;новость в&nbsp;дайджесте"
                    }
                 ],
                 "buttons":[
                    {
                       "type": " %isCorpLightButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"CorpLight"
                    },
                    {
                       "type": " %isCorpProButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"CorpPro"
                    },
                    {
                       "type": " %isCorpProPlusButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"CorpProPlus"
                    },
                    {
                       "type":"buttonMobile",
                       "text":"Выбрать тариф"
                    }
                 ],
                 "popup":{
                    "icon":"icIllustrationsSuccess",
                    "title":"Отправить заявку на&nbsp;смену тарифа?",
                    "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                    "buttons":[
                       {
                          "type":"submit",
                          "text":"Отправить",
                          "variant":"contained",
                          "colorScheme":"orange-gradient"
                       },
                       {
                          "type":"cancel",
                          "text":"Отменить",
                          "variant":"text",
                          "colorScheme":"link"
                       }
                    ]
                 },
                 "config":{
                    "nowrap":false,
                    "styles":{
                       "backgroundColor":"#fff",
                       "padding":{
                          "xs":{
                             "top":4,
                             "bottom":32
                          },
                          "s":{
                             "top":4,
                             "bottom":32
                          },
                          "md":{
                             "top":12,
                             "bottom":32
                          },
                          "lg":{
                             "top":12,
                             "bottom":32
                          }
                       }
                    }
                 }
              }
           ]
        }', 1);

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('corporations_tariff_auth_ru', 'Выбор тарифа | SberUnity', '/select-tariff-corp', 'Выбор тарифа', 'auth',
        '{
           "features":[
              {
                 "type":"spacer",
                 "visible":true,
                 "position":1,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"backButton",
                 "label":"Назад",
                 "sysName":"back",
                 "visible":true,
                 "position":2
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":2,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Выберите тариф",
                 "sysName":"title",
                 "visible":true,
                 "position":3,
                 "config":{
                    "styles":{
                       "padding":{
                          "xs":{
                             "top":16,
                             "bottom":8
                          },
                          "s":{
                             "top":16,
                             "bottom":8
                          },
                          "md":{
                             "top":24,
                             "bottom":16
                          },
                          "lg":{
                             "top":24,
                             "bottom":16
                          }
                       }
                    }
                 }
              },
              {
                 "type":"baseText",
                 "size":{
                    "mobile":"m",
                    "desktop":"l"
                 },
                 "text":"В зависимости от выбранного тарифа, вам будут доступны разные возможности SberUnity",
                 "visible":true,
                 "position":4,
                 "sysName":"baseText"
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":5,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":32,
                    "desktop":40
                 }
              },
              {
                 "type":"tariffs",
                 "visible":true,
                 "position":6,
                 "sysName":"tariffs",
                 "tariffs":[
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpLight",
                       "nameTariff":"Light",
                       "priceTariff":"12 000 ₽ в год",
                       "descriptionTariff":[
                          "Краткая информация о&nbsp;стартапе",
                          "5 запросов на&nbsp;технологии",
                          "Ограниченные уведомления",
                          "1 пользователь"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpLight",
                          "text": " %isCorpLightText% ",
                          "disabled": " %isCorpLight% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpPro",
                       "nameTariff":"Pro",
                       "priceTariff":"1 200 000 ₽ в год",
                       "descriptionTariff":[
                          "Полная информация о стартапе",
                          "Запросы на технологии без&nbsp;ограничений",
                          "Все уведомления доступны",
                          "До 3 пользователей"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpPro",
                          "text": " %isCorpProText% ",
                          "disabled": " %isCorpPro% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":true
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpProPlus",
                       "nameTariff":"Pro Plus",
                       "priceTariff":"2 000 000 ₽ в год",
                       "descriptionTariff":[
                          "Все преимущества тарифа Pro",
                          "PR-продвижение на&nbsp;платформе",
                          "Услуга скаутинга включена",
                          "До 5 пользователей"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpProPlus",
                          "text": " %isCorpProPlusText% ",
                          "disabled": " %isCorpProPlus% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    }
                 ]
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":6,
                 "sysName":"spacer2",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":48,
                    "desktop":64
                 }
              },
              {
                 "type":"tariffsTable",
                 "position":7,
                 "sysName":"tariffsTable",
                 "visible":true,
                 "header":{
                    "highlightHeader":"Базы участников",
                    "tariffs":[
                       "Light",
                       "Pro",
                       "Pro Plus"
                    ]
                 },
                 "content":[
                    {
                       "type":"subAdvantagesName",
                       "text":"База стартапов"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Краткая информация о&nbsp;стартапе"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Полная информация о&nbsp;стартапе"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Полная информация о&nbsp;стартапе"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"База инвесторов"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Фильтрация"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только по индустриям"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все фильтры"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все фильтры"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Функции платформы"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Рекомендованные стартапы"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только 3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без ограничений"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без ограничений"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Избранные"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Сохранение на 30 дней"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Просмотренные"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Сохранение на 30 дней"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Доступность"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Количество пользователей"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"5"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Уведомления на почту"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только отклики на&nbsp;запросы"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все уведомления"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все уведомления"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Дополнительно"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Скаутинг (3 потребности)"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"PR-продвижение"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Приоритетный показ в списке корпораций"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без приоритета"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"7 дней в год"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"30 дней в год"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Email-рассылка по&nbsp;базе SberUnity"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 раз в дайджесте"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 рассылка, 1&nbsp;новость в&nbsp;дайджесте"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Пост в телеграм-канале SberUnity"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 раз в дайджесте"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 пост, 1&nbsp;новость в&nbsp;дайджесте"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Пост в телеграм-канале СберСтартап"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 пост, 1&nbsp;новость в&nbsp;дайджесте"
                    }
                 ],
                 "buttons":[
                    {
                       "type": " %isCorpLightButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"CorpLight"
                    },
                    {
                       "type": " %isCorpProButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"CorpPro"
                    },
                    {
                       "type": " %isCorpProPlusButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"CorpProPlus"
                    },
                    {
                       "type":"buttonMobile",
                       "text":"Выбрать тариф"
                    }
                 ],
                 "popup":{
                    "icon":"icIllustrationsSuccess",
                    "title":"Отправить заявку на&nbsp;смену тарифа?",
                    "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                    "buttons":[
                       {
                          "type":"submit",
                          "text":"Отправить",
                          "variant":"contained",
                          "colorScheme":"orange-gradient"
                       },
                       {
                          "type":"cancel",
                          "text":"Отменить",
                          "variant":"text",
                          "colorScheme":"link"
                       }
                    ]
                 },
                 "config":{
                    "nowrap":false,
                    "styles":{
                       "backgroundColor":"#fff",
                       "padding":{
                          "xs":{
                             "top":4,
                             "bottom":32
                          },
                          "s":{
                             "top":4,
                             "bottom":32
                          },
                          "md":{
                             "top":12,
                             "bottom":32
                          },
                          "lg":{
                             "top":12,
                             "bottom":32
                          }
                       }
                    }
                 }
              }
           ]
        }', 1);

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('investors_tariff_auth_ru', 'Выбор тарифа | SberUnity', '/select-tariff-inv', 'Выбор тарифа', 'auth',
        '{
           "features":[
              {
                 "type":"spacer",
                 "visible":true,
                 "position":1,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"backButton",
                 "label":"Назад",
                 "sysName":"back",
                 "visible":true,
                 "position":2
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":2,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Выберите тариф",
                 "sysName":"title",
                 "visible":true,
                 "position":3,
                 "config":{
                    "styles":{
                       "padding":{
                          "xs":{
                             "top":16,
                             "bottom":8
                          },
                          "s":{
                             "top":16,
                             "bottom":8
                          },
                          "md":{
                             "top":24,
                             "bottom":16
                          },
                          "lg":{
                             "top":24,
                             "bottom":16
                          }
                       }
                    }
                 }
              },
              {
                 "type":"baseText",
                 "size":{
                    "mobile":"m",
                    "desktop":"l"
                 },
                 "text":"В зависимости от выбранного тарифа, вам будут доступны разные возможности SberUnity",
                 "visible":true,
                 "position":4,
                 "sysName":"baseText"
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":5,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":32,
                    "desktop":40
                 }
              },
              {
                 "type":"tariffs",
                 "visible":true,
                 "position":6,
                 "sysName":"tariffs",
                 "tariffs":[
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"InvestLight",
                       "nameTariff":"Light",
                       "priceTariff":"12 000 ₽ в год",
                       "descriptionTariff":[
                          "Краткая информация о&nbsp;стартапе",
                          "Доступно 9 запросов на&nbsp;инвестиции",
                          "1 пользователь"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=2&tariff=InvestLight",
                          "text": " %isInvestLightText% ",
                          "disabled": " %isInvestLight% "
                       },
                       "isBestTariff":false,
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       }
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"InvestAngel",
                       "nameTariff":"Pro Бизнес-ангел",
                       "priceTariff":"60 000 ₽ в год",
                       "descriptionTariff":[
                          "Размещение от&nbsp;физлица",
                          "Полная информация о&nbsp;стартапе",
                          "Все запросы на&nbsp;инвестиции",
                          "Все уведомления",
                          "1 пользователь"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=2&tariff=InvestAngel",
                          "text": " %isInvestAngelText% ",
                          "disabled": " %isInvestAngel% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":true
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"InvestPro",
                       "nameTariff":"Pro Фонд",
                       "priceTariff":"120 000 ₽ в год",
                       "descriptionTariff":[
                          "Для венчурных фондов и&nbsp;family&nbsp;office",
                          "Полная информация о&nbsp;стартапе",
                          "Все запросы на&nbsp;инвестиции",
                          "Все уведомления",
                          "До 3 пользователя"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=2&tariff=InvestPro",
                          "text": " %isInvestProText% ",
                          "disabled": " %isInvestPro% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Отправить заявку на&nbsp;смену тарифа?",
                          "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Отправить",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Отменить",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    }
                 ]
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":6,
                 "sysName":"spacer2",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":48,
                    "desktop":64
                 }
              },
              {
                 "type":"tariffsTable",
                 "position":7,
                 "sysName":"tariffsTable",
                 "visible":true,
                 "header":{
                    "highlightHeader":"Базы участников",
                    "tariffs":[
                       "Light",
                       "Pro Бизнес-ангел",
                       "Pro Фонд"
                    ]
                 },
                 "content":[
                    {
                       "type":"subAdvantagesName",
                       "text":"База стартапов"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Краткая информация о&nbsp;стартапе"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Полная информация о&nbsp;стартапе"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Полная информация о&nbsp;стартапе"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Запросы на инвестиции"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"9 последних запросов"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все запросы стартапов"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все запросы стартапов"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Фильтрация"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только по индустриям"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все фильтры"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все фильтры"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Функции платформы"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Рекомендованные стартапы"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только 3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без ограничений"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Без ограничений"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Избранные"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Сохранение на 30 дней"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Просмотренные"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Сохранение на 30 дней"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Доступность"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Количество пользователей"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"3"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Уведомления на почту"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Только напоминания"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все уведомления"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Все уведомления"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"PR-продвижение"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Приоритетный показ в списке инвесторов"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"7 дней в год"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Email-рассылка по базе SberUnity"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 рассылка, 1&nbsp;новость в&nbsp;дайджесте"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Пост в телеграм-канале SberUnity"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 новость в&nbsp;дайджесте"
                    }
                 ],
                 "buttons":[
                    {
                       "type": " %isInvestLightButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"InvestLight"
                    },
                    {
                       "type": " %isInvestAngelButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"InvestAngel"
                    },
                    {
                       "type": " %isInvestProButton% ",
                       "text":"Выбрать тариф",
                       "sysNameTariff":"InvestPro"
                    },
                    {
                       "type":"buttonMobile",
                       "text":"Выбрать тариф"
                    }
                 ],
                 "popup":{
                    "icon":"icIllustrationsSuccess",
                    "title":"Отправить заявку на&nbsp;смену тарифа?",
                    "text":"Менеджер свяжется с&nbsp;вами в&nbsp;ближайшее время.",
                    "buttons":[
                       {
                          "type":"submit",
                          "text":"Отправить",
                          "variant":"contained",
                          "colorScheme":"orange-gradient"
                       },
                       {
                          "type":"cancel",
                          "text":"Отменить",
                          "variant":"text",
                          "colorScheme":"link"
                       }
                    ]
                 },
                 "config":{
                    "nowrap":false,
                    "styles":{
                       "backgroundColor":"#fff",
                       "padding":{
                          "xs":{
                             "top":4,
                             "bottom":32
                          },
                          "s":{
                             "top":4,
                             "bottom":32
                          },
                          "md":{
                             "top":12,
                             "bottom":32
                          },
                          "lg":{
                             "top":12,
                             "bottom":32
                          }
                       }
                    }
                 }
              }
           ]
        }', 1);

delete from page_values_cache where name in ('%isInvestProButton%', '%isInvestAngelButton%',
                                             '%isInvestLightButton%', '%isInvestPro%', '%isInvestProText%', '%isInvestAngel%', '%isInvestAngelText%', '%isInvestLight%', '%isInvestLightText%',
                                             '%isCorpProPlusButton%', '%isCorpProButton%', '%isCorpLightButton%','%isCorpProPlus%', '%isCorpProPlusText%', '%isCorpPro%','%isCorpProText%', '%isCorpLight%', '%isCorpLightText%');

insert into page_values_cache (name, value, cache_period, cache_time, action, method)
values ('%isInvestProButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestAngelButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestLightButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestPro%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestProButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestProText%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestAngel%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestAngelText%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestLight%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isInvestLightText%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpProPlusButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpProButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpLightButton%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpProPlus%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpProPlusText%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpPro%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpProText%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpLight%', 0, 0, current_date, 'GET', '/select-tariff'),
       ('%isCorpLightText%', 0, 0, current_date, 'GET', '/select-tariff');
