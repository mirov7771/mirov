--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4379
delete from screen where formname = 'offer_Client';
INSERT INTO screen
(id, "type", formname, formedit, "name", lang_id)
VALUES((select max(id) +1 from screen), 7, 'offer_Client', '{
  "form": [
    {
      "page": 1,
      "module": "Основная информация",
      "moduleNote": "",
      "fields": [
        {
          "rows": "1",
          "type": "string",
          "edited": true,
          "example": "Название предлагаемого пилота",
          "sysName": "reply_offerName",
          "required": true,
          "localName": "Название пилота",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Расскажите о предлагаемой технологии",
          "sysName": "reply_offerDescription",
          "required": true,
          "localName": "Краткое описание пилота",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Описание",
          "sysName": "reply_note",
          "required": true,
          "localName": "Какую потребность корпорации вы решите?",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "mask": "$",
          "note": "Сумма, в которую вы оцениваете ваш пилотный запуск",
          "type": "string",
          "edited": true,
          "example": "$",
          "sysName": "reply_cost",
          "required": false,
          "localName": "Какова стоимость вашего решения",
          "maxLength": "30"
        },
        {
          "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Комментарий",
          "sysName": "reply_process",
          "required": true,
          "localName": "Как вы видите процесс пилотирования",
          "minLength": "50",
          "maxLength": "500"
        }
      ]
    },
    {
      "page": 1,
      "module": "Презентация",
      "moduleNote": "",
      "fields": [
        {
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "edited": true,
          "format": "URL",
          "sysName": "reply_fileURL",
          "required": false,
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "maxLength": "5",
          "allowedTypes": [
            ".pdf"
          ]
        }
      ]
    }
  ]
}','Заявка на пилотирование', 1);
select setval('public.screen_id_seq',  (SELECT max(id)+1 FROM public.screen s));

delete from public.screen_button where name = 'offer_Client';

insert into public.screen_button (name, state) values ('offer_Client', 20011);
insert into public.screen_button (name, state) values ('offer_Client', 20003);
insert into public.screen_button (name, state) values ('offer_Client', 20004);
insert into public.screen_button (name, state) values ('offer_Client', 20009);
insert into public.screen_button (name, state) values ('offer_Client', 20007);
insert into public.screen_button (name, state) values ('offer_Client', 20002);
insert into public.screen_button (name, state) values ('offer_Client', 20013);

insert into screen_buttons_link (screen_id, button_id)
select screen_id ,
       (select button_id
        from public.buttons b
        where code = 200003 limit 1)
from screen_button
where name = 'offer_Client';