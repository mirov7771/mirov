--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-1127
update public.screen set name = 'Создать пилот' where clientid = '111260' and type = 4 and formname = 'New_Pilot';