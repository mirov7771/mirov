--liquibase formatted sql
--changeset Mirov A:locale_buttons
ALTER TABLE buttons ADD lang_id bigint NULL;

update public.buttons
set lang_id = (select id from lang where locale = 'ru');