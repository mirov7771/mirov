--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-4791 Добавление карточки компаний

delete from public.screen where formname = 'company_SuperClient' and lang_id = 1;


INSERT INTO public.screen ("type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)

VALUES(3, 'company_SuperClient', '{}'::json::json, '{ "form":[
    {
      "page":1,
      "fields":[
        {
          "type":"string",
          "edited":false,
          "sysName":"company_note",
          "required":false,
          "localName":"Описание проекта"
        },
        {
          "type":"hyperlink",
          "edited":false,
          "format":"",
          "sysName":"company_resourceURI",
          "required":false,
          "localName":"Сайт"
        }
      ],
      "module":"Основная информация"
    },
    {
      "page":1,
      "module":"Импортозамещение",
      "fields":[
        {
          "type":"array",
          "edited":false,
          "format":"tags",
          "sysName":"importReplace_name",
          "required":false,
          "localName":"Названия сервисов, которые заменяет продукт стартапа"
        },
        {
          "type":"string",
          "edited":false,
          "sysName":"importReplace_note",
          "required":false,
          "localName":"Как именно вы заменяете перечисленные сервисы/компании?",
          "maxLength":"1000",
          "rows":"3"
        },
        {
          "type":"string",
          "edited":false,
          "sysName":"importReplace_benefits",
          "required":false,
          "rows":"3",
          "localName":"Преимущества перед перечисленными сервисами/компаниями",
          "maxLength":"500"
        }
      ]
    },
    {
      "page":1,
      "module":"Текущие предложения",
      "isArray":"true",
      "moduleFormat":"card",
      "fields":[
        {
          "type":"string",
          "edited":false,
          "format":"heading",
          "sysName":"services[]_smallNote",
          "required":false,
          "localName":""
        },
        {
          "type":"string",
          "edited":false,
          "format":"body",
          "sysName":"services[]_note",
          "required":false,
          "localName":""
        },
        {
          "type":"string",
          "edited":false,
          "format":"bodyhide",
          "sysName":"services[]_discount",
          "required":false,
          "localName":""
        },
        {
          "type":"string",
          "edited":false,
          "format":"bodybold",
          "sysName":"services[]_offer",
          "required":false,
          "localName":""
        },
        {
          "logo":"",
          "type":"info",
          "edited":false,
          "format":"button",
          "sysName":"services[]_offerUri",
          "required":false,
          "localName":"Получить предложение",
          "clickAction":""
        }
      ]

    }
  ]
}'::json::json, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL);
