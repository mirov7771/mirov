--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-4945 Правка экранов для метрик

delete from screen_buttons_link  where button_id in (select u.button_id from buttons u where u.code in (30010, 30011));
delete from buttons where code in (30010, 30011);
delete from screen_button where name = 'delete_metric';

INSERT INTO public.buttons (code,"text",click_action,click_method,lang_id) VALUES (30010,'Назад',NULL,NULL,1);
INSERT INTO public.buttons (code,"text",click_action,click_method,lang_id) VALUES (30011,'Удалить',NULL,NULL,1);

INSERT INTO public.screen_button ("name",admin_check,main_check,parent_check,success_pilot_check,owner_check,state,favorite,investor_check,active_round_check,future_round_check) VALUES ('delete_metric',false,NULL,NULL,NULL,NULL,20004,NULL,NULL,NULL,NULL);

insert into screen_buttons_link (screen_id,button_id)
values ((select screen_id from screen_button where name = 'delete_metric' limit 1), (select button_id from buttons where code = 30010 limit 1));
insert into screen_buttons_link (screen_id,button_id)
values ((select screen_id from screen_button where name = 'delete_metric' limit 1), (select button_id from buttons where code = 30011 limit 1));

delete from public.screen where formname in ('edit_metric','add_metric_values','delete_metric','add_metric');
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (14,'edit_metric','{
  "form":
  [
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные значения метрики в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "sysName": "items_date"
        }
      ]
    }
  ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (14,'add_metric_values','{
  "form":
  [
    {
      "page": 1,
      "module": "Добавление значений",
      "moduleNote": "Укажите известные значения метрики %metricName% в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "sysName": "items_date"
        }
      ]
    }
  ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (14,'delete_metric','{"form": []}','{"form": []}','Удалить метрику?','После удаления все значения метрики Annual Recurring Revenue будут удалены без возможности восстановления.',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (14,'add_metric','{
    "form":
    [
        {
            "page": 1,
            "fields":
            [
                {
                    "localName": "Тип метрики",
                    "example": "Выберите тип",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "type",
                    "multySelect": false
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "1"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "2"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "3"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "4"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "5"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "6"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "7"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "9"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "10"
                }
            ]
        },
        {
            "page": 1,
            "module": "Значения метрики",
            "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
            "isArray": "true",
            "actionText": "Добавить значение",
            "fields":
            [
                {
                    "localName": "Значение",
                    "example": "Введите число",
                    "type": "int",
                    "required": true,
                    "edited": true,
                    "sysName": "items_value",
                    "triggerField": "currency",
                    "triggerValue": ""
                },
                {
                    "localName": "Значение",
                    "example": "Введите сумму",
                    "type": "int",
                    "required": true,
                    "edited": true,
                    "sysName": "items_value",
                    "triggerField": "currency",
                    "triggerValue": "41001",
                    "mask": "$"
                },
                {
                    "localName": "Значение",
                    "example": "Введите сумму",
                    "type": "int",
                    "required": true,
                    "edited": true,
                    "sysName": "items_value",
                    "triggerField": "currency",
                    "triggerValue": "41002",
                    "mask": "rub"
                },
                {
                    "localName": "Дата",
                    "example": "Укажите дату",
                    "type": "date",
                    "required": true,
                    "edited": true,
                    "sysName": "items_date"
                }
            ]
        }
    ]
}',NULL,'Добавление метрики',NULL,1,NULL,NULL,NULL,NULL,1,NULL);