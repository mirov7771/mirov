--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4355_2


update public.pages
set page = '{
   "features":[
      {
         "type":"breadcrumbs",
         "sysName":"vas_en_breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Main",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Services"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"vas_en_pageTitle",
         "title":"Exclusive offers for startups",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_en",
         "visible":true,
         "position":2,
         "placeholder":"Enter a name",
         "loginDescription": "Join the platform <br/>to take advantage of the service offer",
         "joinButtonName": "Join",
         "loginButtonName": "Log in"
      }
   ]
}'
where uri = '/vas'
  and page_type  = 'unauth'
  and lang_id = 2;