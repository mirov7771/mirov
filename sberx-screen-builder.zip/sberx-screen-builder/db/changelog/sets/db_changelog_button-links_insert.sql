--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-2548_insert
delete from public.buttons where code = 20002;

insert into public.buttons(code, text)
values(20002, 'На рассмотрении');

UPDATE screen_button
SET state = 20001
WHERE name = 'New_Pilot';

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = false and state = 20004),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = false and state = 20004),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = false and state = 20004),
        (select button_id from buttons where code = 100003));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20004),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20004),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20004),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20009),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20009),
        (select button_id from buttons where code = 100002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = true and state = 20004),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = true and state = 20004),
        (select button_id from buttons where code = 100002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = false and state = 20002),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_Administrator' and admin_check = true and main_check = false and state = 20002),
        (select button_id from buttons where code = 20004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20003));
---

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20009),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20009));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = true and state = 20004),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = true and state = 20004),
        (select button_id from buttons where code = 100002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = false and state = 20002),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_Administrator' and admin_check = true and main_check = false and state = 20002),
        (select button_id from buttons where code = 20004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20002),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20004),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20004),
        (select button_id from buttons where code = 100002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20004),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20009),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20009),
        (select button_id from buttons where code = 100002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = true and state = 20004),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = true and state = 20004),
        (select button_id from buttons where code = 100002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = false and state = 20002),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_Administrator' and admin_check = true and main_check = false and state = 20002),
        (select button_id from buttons where code = 20004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20002 limit 1),
        (select button_id from buttons where code = 20012));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20012 limit 1),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20012 limit 1),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20012 limit 1),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20003  limit 1),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20004  limit 1),
        (select button_id from buttons where code = 20003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_Administrator' and admin_check = true and state = 20012  limit 1),
        (select button_id from buttons where code = 20003));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'New_Pilot' and owner_check = true and state = 20001),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_edit' and owner_check = true and state = 20002),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_edit' and owner_check = true and state = 20003),
        (select button_id from buttons where code = 20002));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_edit' and owner_check = true and state = 20004),
        (select button_id from buttons where code = 20002));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_SuperClient' and state = 20004),
        (select button_id from buttons where code = 100000));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'pilot_SuperClient' and state = 20004),
        (select button_id from buttons where code = 100000));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_SuperClient' and success_pilot_check = false and owner_check = true and state = 20004),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_SuperClient' and success_pilot_check = true and owner_check = true and state = 20004),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_SuperClient' and owner_check = true and state = 20004),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_SuperClient'  and owner_check = true and state = 20004),
        (select button_id from buttons where code = 100003));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_SuperClient' and state = 20004 limit 1),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corporate_SuperClient' and state = 20004 limit 1),
        (select button_id from buttons where code = 100001));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'investor_SuperClient' and state = 20004 limit 1),
        (select button_id from buttons where code = 100003));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'startup_SuperClient' and state = 20004 limit 1),
        (select button_id from buttons where code = 100003));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'reply_SuperClient' and state = 20001),
        (select button_id from buttons where code = 100000));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corp_app_Administrator' and state = 20011 limit 1),
        (select button_id from buttons where code = 20012));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corp_app_Administrator' and state = 20012 limit 1),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corp_app_Administrator' and state = 20012 limit 1),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corp_app_Administrator' and state = 20009 limit 1),
        (select button_id from buttons where code = 20012));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'corp_app_Administrator' and state = 20004 limit 1),
        (select button_id from buttons where code = 20004));

insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'invest_app_Administrator' and state = 20011 limit 1),
        (select button_id from buttons where code = 20012));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'invest_app_Administrator' and state = 20012 limit 1),
        (select button_id from buttons where code = 20004));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'invest_app_Administrator' and state = 20012 limit 1),
        (select button_id from buttons where code = 20009));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'invest_app_Administrator' and state = 20009 limit 1),
        (select button_id from buttons where code = 20012));
insert into screen_buttons_link (screen_id, button_id)
values ((select screen_id from screen_button where name = 'invest_app_Administrator' and state = 20004 limit 1),
        (select button_id from buttons where code = 20004));

