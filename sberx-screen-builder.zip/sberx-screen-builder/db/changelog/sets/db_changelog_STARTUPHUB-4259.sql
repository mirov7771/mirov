--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4259
select setval('public.schemas_id_seq', (SELECT max(id) + 1 FROM public.schemas));
delete from schemas where name = 'pilots_reply';
insert into schemas (name, value)
values ('pilots_reply', '{
  "clickable": true,
  "columns": [
    {
      "sysName": "startup",
      "type": "string",
      "title": "Стартап",
      "key": "questionnaireName"
    },
    {
      "sysName": "view_date",
      "type": "date",
      "title": "Дата и время отклика",
      "key": "date"
    },
    {
      "sysName": "status",
      "type": "nameplate",
      "title": "Статус",
      "key": "state",
      "refs": {
        "map": {
          "20002": "В работе",
          "20003": "Пауза",
          "20004": "Пилотируется",
          "20007": "Завершен",
          "20009": "Отказ",
          "20011": "Новый",
          "20013": "Отозван"
        }
      }
    }
  ]
}');