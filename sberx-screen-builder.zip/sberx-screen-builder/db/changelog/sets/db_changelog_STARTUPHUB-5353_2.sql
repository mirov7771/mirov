--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5353_2
update screen
set formview = cast(replace(cast(formview as text), 'Дополнительные контакты','Дополнительные ссылки') as json)
where (cast(formview as text)) like '%Дополнительные контакты%';

