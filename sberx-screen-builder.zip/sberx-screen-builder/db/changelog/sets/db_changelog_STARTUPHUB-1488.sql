--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1488

UPDATE public.screen SET   buttons='{
  "buttons": [
    {
      "icon": "",
      "type": "active",
      "text": "Посмотреть запросы",
      "action": "/v2/list?type=4&questionnaireId={questionnaireId}",
      "variant": "primary",
      "description": ""
    }
  ]
  }' WHERE formname='corporate_Client';

 UPDATE public.screen SET   buttons='{
  "buttons": [
    {
      "icon": "",
      "type": "active",
      "text": "Посмотреть запросы",
      "action": "/v2/list?type=4&questionnaireId={questionnaireId}",
      "variant": "primary",
      "description": ""
    }
  ]
  }' WHERE formname='corporate_SuperClient';
