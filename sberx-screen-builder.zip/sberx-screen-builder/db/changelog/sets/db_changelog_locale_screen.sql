--liquibase formatted sql
--changeset Mirov A:locale_screen
update public.screen
set lang_id = (select id from lang where locale = 'ru');