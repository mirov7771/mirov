--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-4733_5
delete
from pages
where uri = '/import-substitution';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_ru', 'SberUnity Ипортозамещение', '/import-substitution', 'Импортозамещение', 'auth',
        '{
           "features":[
              {
                 "config":{

                 },
                 "type":"participantSearch",
                 "foundsTitle":"Найдено: {0}",
                 "header":"Импортозамещающие решения",
                 "participant":"startupsRecommend",
                 "placeholder":"Поиск стартапа",
                 "position":1,
                 "shownFromTitle":"Показано {0} из {1}",
                 "sortLabels":{
                    "alphabetically":"По алфавиту",
                    "byUpdateDate":"По дате обновления"
                 },
                 "sysName":"startupsRecommend_ru_participantSearch",
                 "title":"Импортозамещающие решения",
                 "isImport":true,
                 "noContent":{
                    "Startup":{
                       "title":"Добавьте информацию в анкету об импортозамещении",
                       "subtitle":"Чтобы стать заметнее для корпораций на SberUnity, укажите сервисы или компании, которые заменяет ваш продукт. Анкета появится в данном разделе после модерации.",
                       "button":{
                          "text":"Добавить информацию"
                       }
                    },
                    "Corporates":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Скоро здесь будут анкеты стартапов, которые добавили информацию про импортозамещение"
                    },
                    "Investor":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Скоро здесь будут анкеты стартапов, которые добавили информацию про импортозамещение"
                    }
                 },
                 "visible":true
              }
           ]
        }', 1);

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_en', 'SberUnity Import substitution', '/import-substitution', 'Import substitution', 'auth',
        '{
           "features":[
              {
                 "config":{

                 },
                 "type":"participantSearch",
                 "foundsTitle":"Find: {0}",
                 "header":"Import substitution solution",
                 "participant":"startupsRecommend",
                 "placeholder":"Find a startup",
                 "position":1,
                 "shownFromTitle":"Shown {0} from {1}",
                 "sortLabels":{
                    "alphabetically":"Alphabetically",
                    "byUpdateDate":"By update date"
                 },
                 "sysName":"startupsRecommend_ru_participantSearch",
                 "title":"Import substitution solution",
                 "isImport":true,
                 "noContent":{
                    "Startup":{
                       "title":"Add information to the import substitution questionnaire",
                       "subtitle":"To become more visible to corporations on SberUnity, specify the services or companies that your product replaces. The questionnaire will appear in this section after moderation.",
                       "button":{
                          "text":"Add Information"
                       }
                    },
                    "Corporates":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Soon there will be questionnaires of startups that have added information about import substitution"
                    },
                    "Investor":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Soon there will be questionnaires of startups that have added information about import substitution"
                    }
                 },
                 "visible":true
              }
           ]
        }', 2);