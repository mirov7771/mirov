--liquibase formatted sql
--changeset Mirov A:pilots_az
delete from public.pages where code = 'pilot_az_auth_ru';
insert into public.pages (code,name, uri, description , page_type, page, lang_id)
values ('pilot_az_auth_ru', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "pilotSearch",
            "menuItems": {
                "all": {
                    "action": "/v2/list?type=4",
                    "id": 1,
                    "name": "Все пилоты",
                    "sysname": "all"
                },
                "corporates": {
                    "action": "/v2/list?type=4&filters=user&schema=pilots_user",
                    "id": 2,
                    "name": "Мои отклики",
                    "sysname": "corporates"
                }
            },
            "corporationBlock": {
                "menuTitle": "Корпорации",
                "buttonChooseCorporation": "Выбрать корпорацию"
            },
            "fastFilters": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное"
            },
            "infoBanner": {
                "typeBanner": "successStory",
                "title": "Расскажите как вам помог SberUnity и получите новые возможности!",
                "mainButtonText": "Рассказать",
                "popupData": {
                    "title": "SberUnity ищет истории успеха!",
                    "description": "Если вы подались на пилот через SberUnity и запустили его с корпорацией, привлекли инвестора и получили от него инвестиционный транш или нашли бизнес-партнера, расскажите нам об этом.",
                    "benefits": {
                        "title": "За историю успеха SberUnity подарит вам:",
                        "list": [
                            {
                                "text": "Публикацию о вашем успехе в телеграм-канале ",
                                "link": {
                                    "name": "SberStartup",
                                    "url": "https://t.me/sberstartup"
                                }
                            },
                            {
                                "text": "Приоритетная выдача вашего стартапа в поиске"
                            },
                            {
                                "text": "Тёплое интро любому инвестору или корпорации на выбор"
                            },
                            {
                                "text": "Предложим рассказать о вашем успехе деловым СМИ"
                            }
                        ]
                    },
                    "radioBoxInfo": {
                        "title": "Выберите вашу историю успеха:",
                        "list": [
                            {
                                "name": "Успешно проведённый пилот",
                                "code": "Успешно проведённый пилот"
                            },
                            {
                                "name": "Привлечённая инвестиция",
                                "code": "Привлечённая инвестиция"
                            },
                            {
                                "name": "Найденный партнёр",
                                "code": "Найденный партнёр"
                            }
                        ],
                        "input": {
                            "placeholder": "Расскажите кратко про ваш успешный кейс",
                            "errorMessages": {
                                "storyType": "Выберите тип истории успеха",
                                "text": "Заполните поле"
                            }
                        }
                    },
                    "caption": "Сообщите нам о своей истории успеха, и администратор SberUnity свяжется с вами для обсуждения деталей",
                    "button": {
                        "title": "Поделиться историей"
                    },
                    "toastInfo": {
                        "success": "История успеха отправлена",
                        "error": "Не удалось отправить историю успеха"
                    }
                }
            }
        }
    ]
}', 1);

update public.pages
set page = '{
    "features": [
        {
            "type": "participantSearch",
			"title": "Все корпорации",
			"header": "Корпорации",
            "sysName": "corporates_ru_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Введите название",
            "participant": "corporation",
            "shownFromTitle": "Показано {0} из {1}",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "sortLabels": {
                "alphabetically": "По алфавиту",
                "byUpdateDate": "По дате обновления",
                "byCreationDate": "По дате создания"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            }
        }
    ]
}'
where page_type = 'auth'
  and uri = '/corporates'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "corporates_en_participantSearch",
			"title": "All corporates",
			"header": "Corporates",
            "visible": true,
            "position": 3,
            "placeholder": "Enter name",
            "participant": "corporation",
            "shownFromTitle": "Shown {0} of {1}",
            "foundsTitle": "Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
            "sortLabels": {
                "alphabetically": "Alphabetically",
                "byUpdateDate": "By creation date",
                "byCreationDate": "By date modified"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Favorite",
                "viewedLabel": "Viewed",
                "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
            }
        }
    ]
}'
where page_type = 'auth'
  and uri = '/corporates'
  and lang_id = 2;

update public.pages
set page = '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "investor_ru_participantSearch",
            "visible": true,
			"title": "Все инвесторы",
			"header": "Инвесторы",
            "position": 3,
            "placeholder": "Введите название или воспользуйтесь фильтром",
            "participant": "investor",
            "shownFromTitle": "Показано {0} из {1}",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "sortLabels": {
                "alphabetically": "По алфавиту",
                "byUpdateDate": "По дате обновления",
                "byCreationDate": "По дате создания"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            }
        }
    ]
}'
where page_type = 'auth'
  and uri = '/investors'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "investor_en_participantSearch",
            "visible": true,
			"title": "All investors",
			"header": "Investors",
            "position": 3,
            "placeholder": "Enter name or use the filter",
            "participant": "investor",
            "shownFromTitle": "Shown {0} of {1}",
            "foundsTitle": "Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
            "sortLabels": {
                "alphabetically": "Alphabetically",
                "byUpdateDate": "By creation date",
                "byCreationDate": "By date modified"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Favorite",
                "viewedLabel": "Viewed",
                "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
            }
        }
    ]
}'
where page_type = 'auth'
  and uri = '/investors'
  and lang_id = 2;


update public.pages
set page = '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "startups_ru_participantSearch",
            "visible": true,
			"title": "Все стартапы",
			"header": "Стартапы",
            "position": 3,
            "placeholder": "Поиск стартапа",
            "participant": "startup",
            "shownFromTitle": "Показано {0} из {1}",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "sortLabels": {
                "alphabetically": "По алфавиту",
                "byUpdateDate": "По дате обновления",
                "byCreationDate": "По дате создания"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            }
        }
    ]
}'
where page_type = 'auth'
  and uri = '/startup'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "startups_en_participantSearch",
            "visible": true,
			"title": "All startups",
			"header": "Startups",
            "position": 3,
            "placeholder": "Search startups",
            "participant": "startup",
            "shownFromTitle": "Shown {0} of {1}",
            "foundsTitle": "Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
            "sortLabels": {
                "alphabetically": "Alphabetically",
                "byUpdateDate": "By creation date",
                "byCreationDate": "By date modified"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Favorite",
                "viewedLabel": "Viewed",
                "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
            }
        }
    ]
}'
where page_type = 'auth'
  and uri = '/startup'
  and lang_id = 2;

update public.pages
set page = '{
    "features": [
        {
            "type": "changePasswordForm",
            "sysName": "participant-registration_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 8 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"
                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "participant-registration_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_ru_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "title": "Мы обновили пользовательское соглашение",
            "description": "Примите его условия, чтобы продолжить работу на платформе SberUnity",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Продолжить",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/participant-registration'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "changePasswordForm",
            "sysName": "participant-registration_en_changePasswordForm",
            "titleForm": "Creating a new password",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Latin characters only ",
                "Minimum of 8 characters",
                "At least 6 different characters",
                "At least 1 uppercase and 1 lowercase letters",
                "At least 1 special symbol, for example \"! _ : ;\""
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "New password"
                },
                {
                    "type": "confirmPassword",
                    "label": "Repeat password",
                    "confirmPasswordLabel": "Repeat password"
                }
            ],
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "participant-registration_en_userAgreementForm_button",
                "text": "Create a password",
                "theme": "purple-gradient",
                "url": "/",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_en_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "title": "We have updated the user agreement",
            "description": "Accept terms to continue using the SberUnity platform",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Continue",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/participant-registration'
  and lang_id = 2;