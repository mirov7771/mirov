--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4508_2
update public.pages
set page = '{
    "features": [
        {
            "type": "questionnaireView",
            "sysName": "",
            "visible": true,
            "position": 1,
            "backButtonTitle": "назад",
            "adminCommentTitles": {
                "title": "Необходима дополнительная информация",
                "additionalInfo": "Комментарий администратора:"
            },
          "config": {
              "nowrap": true
          }
        }
    ]
}'
where code = 'questionnaire_view_az_ru';