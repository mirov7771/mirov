--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-171
insert into schemas(id, clientid, "name", value)
select (select max(id) from schemas)+id,
       '8385' ,
       "name" ,
       value
from schemas s
where s.clientid = '111260'
  and not exists (select 1
                    from schemas s1
                  where s.name      = s1.name
                    and s1.clientid = '8385');


insert into client_menu (id, type, menutype, "name", sysname, action, "method", clientid, logofile, isdefault, ui)
select (select max(id) from client_menu)+id, type, menutype, name, sysname, action, method, '8385', logofile, isdefault, ui
from client_menu s
where s.clientid = '111260'
  and not exists (select 1
                    from client_menu s1
                   where s.name      = s1.name
                     and s.menutype  = s1.menutype
                     and s.type      = s1."type"
                     and s.sysname   = s1.sysname
                     and s1.clientid = '8385');


insert into screen (id, clientid , "type" , formname , formedit , formview , name, description , buttons , logofile , offerdescription , secondofferdescription)
select (select max(id) from screen)+id, '8385' , "type" , formname , formedit , formview , name, description , buttons , logofile , offerdescription , secondofferdescription
from screen s
where s.clientid = '111260'
  and not exists (select 1
                    from screen s1
                   where s."type"   = s1."type"
                     and s.formname = s1.formname
                     and s1.clientid = '8385');

insert into public.client_menu
values ((select max(id)+1 from public.client_menu), 1, 'pilots_corporate_client', 'Активные', 'all', '/v2/list?type=4&schema=pilots_active&id=', 'GET', '111260', null, true, null);
insert into public.client_menu
values ((select max(id)+1 from public.client_menu), 1, 'pilots_corporate_client', 'Архив', 'archive', '/v2/list?type=4&schema=pilots_archive&state=20005&id=', 'GET', '111260', null, false, null);

insert into public.client_menu
values ((select max(id)+1 from public.client_menu), 1, 'pilots_corporate_client', 'Активные', 'all', '/v2/list?type=4&schema=pilots_active&id=', 'GET', '8385', null, true, null);
insert into public.client_menu
values ((select max(id)+1 from public.client_menu), 1, 'pilots_corporate_client', 'Архив', 'archive', '/v2/list?type=4&schema=pilots_archive&state=20005&id=', 'GET', '8385', null, false, null);



