--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3793
update public.screen set
    formview = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "firstName",
                    "required": false,
                    "localName": "Имя"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "lastName",
                    "required": false,
                    "localName": "Фамилия"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "phone",
                    "required": false,
                    "localName": "Номер телефона"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "email",
                    "required": false,
                    "localName": "Email"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "telegramLink",
                    "required": false,
                    "localName": "Никнейм в Telegram"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "site",
                    "required": false,
                    "localName": "Сайт проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "orgFullName",
                    "required": false,
                    "localName": "Название компании"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "ventureExperience",
                    "required": false,
                    "localName": "Венчурный опыт"
                },
                {
                    "type": "array",
                    "edited": false,
                    "activity": [
                        39000
                    ],
                    "format": "search_dropdown",
                    "sysName": "sumInvestment",
                    "required": false,
                    "localName": "Какую сумму вы готовы инвестировать?"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "sysName": "isUnity",
                    "required": false,
                    "localName": "Хотели бы опубликоваться на SberUnity"
                }
            ],
            "module": "Основная информация",
            "pageName": ""
        }
    ]
}'
where formname = 'syndicate_Administrator';