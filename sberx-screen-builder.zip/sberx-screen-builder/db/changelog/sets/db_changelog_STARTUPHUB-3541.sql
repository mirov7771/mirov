--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3541
select setval('public.screen_id_seq',  (SELECT max(id)+1 FROM public.screen s));
delete from public.screen where formname = 'syndicate_Administrator';
insert into public.screen (clientid, "type", formname, formview, name, pages, lang_id)
values('111260', 12, 'syndicate_Administrator', '{
    "form": [
        {
            "module": "Основная информация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "firstName",
                    "localName": "Имя",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "lastName",
                    "localName": "Фамилия",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "phone",
                    "localName": "Номер телефона",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Email",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "telegramLink",
                    "localName": "Никнейм в Telegram",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "site",
                    "localName": "Сайт проекта",
                    "type": "hyperlink",
                    "format": "button",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "orgFullName",
                    "localName": "Название компании",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ventureExperience",
                    "localName": "Венчурный опыт",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "sumInvestment",
                    "localName": "Какую сумму вы готовы инвестировать?",
                    "type": "string",
                    "edited": false,
                    "required": false,
                    "mask": "$"
                },
                {
                    "sysName": "isUnity",
                    "localName": "Хотели бы опубликоваться на SberUnity",
                    "type": "boolean",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}', 'Просмотр анкеты синдиката', 1, 1);

insert into public.screen (clientid, "type", formname, formview, name, pages, lang_id)
values('8385', 12, 'syndicate_Administrator', '{
    "form": [
        {
            "module": "Основная информация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "firstName",
                    "localName": "Имя",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "lastName",
                    "localName": "Фамилия",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "phone",
                    "localName": "Номер телефона",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Email",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "telegramLink",
                    "localName": "Никнейм в Telegram",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "site",
                    "localName": "Сайт проекта",
                    "type": "hyperlink",
                    "format": "button",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "orgFullName",
                    "localName": "Название компании",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ventureExperience",
                    "localName": "Венчурный опыт",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "sumInvestment",
                    "localName": "Какую сумму вы готовы инвестировать?",
                    "type": "string",
                    "edited": false,
                    "required": false,
                    "mask": "$"
                },
                {
                    "sysName": "isUnity",
                    "localName": "Хотели бы опубликоваться на SberUnity",
                    "type": "boolean",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}', 'Просмотр анкеты синдиката', 1, 1);