--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3346
delete from public.screen where formname = 'community_Administrator';

insert into screen (id, clientid, "type", formname, formview, pages, lang_id)
values ((select max(id)+1 from screen), '111260', 11, 'community_Administrator', '{
    "form": [
        {
            "module": "Основная информация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "В каком сообществе Вы уже состоите?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "position",
                    "localName": "Должность",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "site",
                    "localName": "Сайт проекта",
                    "type": "hyperlink",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        3000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "round",
                    "localName": "Интересующие стадии инвестиций",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        6000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле",
                    "type": "int",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "type": "hyperlink",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}', 1, 1);

insert into screen (id, clientid, "type", formname, formview, pages, lang_id)
values ((select max(id)+1 from screen), '8385', 11, 'community_Administrator', '{
    "form": [
        {
            "module": "Основная информация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "В каком сообществе Вы уже состоите?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "position",
                    "localName": "Должность",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "site",
                    "localName": "Сайт проекта",
                    "type": "hyperlink",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        3000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "round",
                    "localName": "Интересующие стадии инвестиций",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        6000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле",
                    "type": "int",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "type": "hyperlink",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}', 1, 1);

delete from public.screen_button where "name"  = 'community_Administrator';
insert into public.screen_button (name, admin_check, state) values ('community_Administrator', true, 20001);
insert into public.screen_button (name, admin_check, state) values ('community_Administrator', true, 20002);
insert into public.screen_button (name, admin_check, state) values ('community_Administrator', true, 20012);
insert into public.screen_button (name, admin_check, state) values ('community_Administrator', true, 20004);
insert into public.screen_button (name, admin_check, state) values ('community_Administrator', true, 20009);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20001), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20002), (select button_id from public.buttons where code = 20012));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20012), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20012), (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20012), (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20004), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20004), (select button_id from public.buttons where code = 20012));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20009), (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20009), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'community_Administrator' and state = 20009), (select button_id from public.buttons where code = 20012));
