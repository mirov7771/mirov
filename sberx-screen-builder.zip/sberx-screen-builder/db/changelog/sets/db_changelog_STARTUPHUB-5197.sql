--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5197
update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Пройденные акселераторы"
             }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_type",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"С кем был успешный кейс"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Описание и результаты кейса"
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      },
        {
            "page": 1,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Названия сервисов, которые заменяет продукт стартапа"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "rows": "3",
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500"
                }
            ]
        }
   ]
}'
where formname = 'startup_SuperClient'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Accelerators alumni"
             }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_type",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who was the successful case with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      },{
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      }
   ]
}'
where formname = 'startup_SuperClient'
  and lang_id = 2;