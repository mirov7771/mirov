--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3522
delete from public.screen_button where "name"  = 'syndicate_Administrator';
insert into public.screen_button (name, admin_check, state) values ('syndicate_Administrator', true, 20001);
insert into public.screen_button (name, admin_check, state) values ('syndicate_Administrator', true, 20002);
insert into public.screen_button (name, admin_check, state) values ('syndicate_Administrator', true, 20012);
insert into public.screen_button (name, admin_check, state) values ('syndicate_Administrator', true, 20004);
insert into public.screen_button (name, admin_check, state) values ('syndicate_Administrator', true, 20009);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20001), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20002), (select button_id from public.buttons where code = 20012));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20012), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20012), (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20012), (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20004), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20004), (select button_id from public.buttons where code = 20012));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20009), (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20009), (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_Administrator' and state = 20009), (select button_id from public.buttons where code = 20012));
