--liquibase formatted sql
--changeset Mirov A:pilots_az3
--liquibase formatted sql
--changeset Mirov A:pilots_az2
delete from public.pages where code in ('pilot_corporate_az_auth_ru', 'pilot_investors_az_auth_ru');
insert into public.pages (code, name, uri, description, page_type , page , lang_id )
values ('pilot_corporate_az_auth_ru', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
  "features": [
    {
      "type": "pilotSearch",
      "menuItems": {
        "all": {
          "action": "/v2/list?type=4&schema=pilots_active",
          "id": 1,
          "name": "Активные",
          "sysname": "all"
        },
        "archive": {
          "action": "/v2/list?type=4&schema=pilots_archive&state=20005",
          "id": 2,
          "name": "Архивные",
          "sysname": "archive"
        }
      },
      "pilotCreation": {
        "createPilotButton": {
          "label": "Создать пилот",
          "action": "view?action=2&type=4&name=New_Pilot"
        },
        "cancelPilotButton": {
          "label": "Отменить"
        },
        "toast": {
          "successMessage": "Пилот создан",
          "errorMessage": "Не удалось создать пилот"
        }
      },
      "infoBanner": {
        "typeBanner": "successStory",
        "title": "Расскажите как вам помог SberUnity и получите новые возможности!",
        "mainButtonText": "Рассказать",
        "popupData": {
          "title": "SberUnity ищет истории успеха!",
          "description": "Если вы подались на пилот через SberUnity и запустили его с корпорацией, привлекли инвестора и получили от него инвестиционный транш или нашли бизнес-партнера, расскажите нам об этом.",
          "benefits": {
            "title": "За историю успеха SberUnity подарит вам:",
            "list": [
                "Публикацию о вашем успехе в телеграм-канале [SberStartup](https://t.me/sberstartup)",
                "Приоритетная выдача вашего стартапа в поиске",
                "Тёплое интро любому инвестору или корпорации на выбор",
                "Предложим рассказать о вашем успехе деловым СМИ"
            ]
          },
          "radioBoxInfo": {
            "title": "Выберите вашу историю успеха:",
            "list": [
              {
                "name": "Успешно проведённый пилот",
                "code": "Успешно проведённый пилот"
              },
              {
                "name": "Привлечённая инвестиция",
                "code": "Привлечённая инвестиция"
              },
              {
                "name": "Найденный партнёр",
                "code": "Найденный партнёр"
              }
            ],
            "input": {
              "placeholder": "Расскажите кратко про ваш успешный кейс",
              "errorMessages": {
                "storyType": "Выберите тип истории успеха",
                "text": "Заполните поле"
              }
            }
          },
          "caption": "Сообщите нам о своей истории успеха, и администратор SberUnity свяжется с вами для обсуждения деталей",
          "button": {
            "title": "Поделиться историей"
          },
          "toastInfo": {
            "success": "История успеха отправлена",
            "error": "Не удалось отправить историю успеха"
          }
        }
      }
    }
  ]
}', 1);

insert into public.pages (code, name, uri, description, page_type , page , lang_id )
values ('pilot_investors_az_auth_ru', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
  "features": [
    {
      "type": "pilotSearch",
      "menuItems": {
        "all": {
          "action": "/v2/list?type=4",
          "id": 1,
          "name": "Все пилоты",
          "sysname": "all"
        }
      },
      "corporationBlock": {
        "menuTitle": "Корпорации",
        "buttonChooseCorporation": "Выбрать корпорацию"
      },
      "fastFilters": {
        "favoriteLabel": "Избранные",
        "viewedLabel": "Просмотренное"
      },
      "infoBanner": {
        "typeBanner": "successStory",
        "title": "Расскажите как вам помог SberUnity и получите новые возможности!",
        "mainButtonText": "Рассказать",
        "popupData": {
          "title": "SberUnity ищет истории успеха!",
          "description": "Если вы подались на пилот через SberUnity и запустили его с корпорацией, привлекли инвестора и получили от него инвестиционный транш или нашли бизнес-партнера, расскажите нам об этом.",
          "benefits": {
            "title": "За историю успеха SberUnity подарит вам:",
            "list": [
                "Публикацию о вашем успехе в телеграм-канале [SberStartup](https://t.me/sberstartup)",
                "Приоритетная выдача вашего стартапа в поиске",
                "Тёплое интро любому инвестору или корпорации на выбор",
                "Предложим рассказать о вашем успехе деловым СМИ"
            ]
          },
          "radioBoxInfo": {
            "title": "Выберите вашу историю успеха:",
            "list": [
              {
                "name": "Успешно проведённый пилот",
                "code": "Успешно проведённый пилот"
              },
              {
                "name": "Привлечённая инвестиция",
                "code": "Привлечённая инвестиция"
              },
              {
                "name": "Найденный партнёр",
                "code": "Найденный партнёр"
              }
            ],
            "input": {
              "placeholder": "Расскажите кратко про ваш успешный кейс",
              "errorMessages": {
                "storyType": "Выберите тип истории успеха",
                "text": "Заполните поле"
              }
            }
          },
          "caption": "Сообщите нам о своей истории успеха, и администратор SberUnity свяжется с вами для обсуждения деталей",
          "button": {
            "title": "Поделиться историей"
          },
          "toastInfo": {
            "success": "История успеха отправлена",
            "error": "Не удалось отправить историю успеха"
          }
        }
      }
    }
  ]
}', 1);

delete from public.pages where code = 'pilot_az_auth_ru';
insert into public.pages (code,name, uri, description , page_type, page, lang_id)
values ('pilot_az_auth_ru', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "pilotSearch",
            "menuItems": {
                "all": {
                    "action": "/v2/list?type=4",
                    "id": 1,
                    "name": "Все пилоты",
                    "sysname": "all"
                },
                "corporates": {
                    "action": "/v2/list?type=4&filters=user&schema=pilots_user",
                    "id": 2,
                    "name": "Мои отклики",
                    "sysname": "corporates"
                }
            },
            "corporationBlock": {
                "menuTitle": "Корпорации",
                "buttonChooseCorporation": "Выбрать корпорацию"
            },
            "fastFilters": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное"
            },
            "infoBanner": {
                "typeBanner": "successStory",
                "title": "Расскажите как вам помог SberUnity и получите новые возможности!",
                "mainButtonText": "Рассказать",
                "popupData": {
                    "title": "SberUnity ищет истории успеха!",
                    "description": "Если вы подались на пилот через SberUnity и запустили его с корпорацией, привлекли инвестора и получили от него инвестиционный транш или нашли бизнес-партнера, расскажите нам об этом.",
                    "benefits": {
                        "title": "За историю успеха SberUnity подарит вам:",
                        "list": [
                "Публикацию о вашем успехе в телеграм-канале [SberStartup](https://t.me/sberstartup)",
                "Приоритетная выдача вашего стартапа в поиске",
                "Тёплое интро любому инвестору или корпорации на выбор",
                "Предложим рассказать о вашем успехе деловым СМИ"
            ]
                    },
                    "radioBoxInfo": {
                        "title": "Выберите вашу историю успеха:",
                        "list": [
                            {
                                "name": "Успешно проведённый пилот",
                                "code": "Успешно проведённый пилот"
                            },
                            {
                                "name": "Привлечённая инвестиция",
                                "code": "Привлечённая инвестиция"
                            },
                            {
                                "name": "Найденный партнёр",
                                "code": "Найденный партнёр"
                            }
                        ],
                        "input": {
                            "placeholder": "Расскажите кратко про ваш успешный кейс",
                            "errorMessages": {
                                "storyType": "Выберите тип истории успеха",
                                "text": "Заполните поле"
                            }
                        }
                    },
                    "caption": "Сообщите нам о своей истории успеха, и администратор SberUnity свяжется с вами для обсуждения деталей",
                    "button": {
                        "title": "Поделиться историей"
                    },
                    "toastInfo": {
                        "success": "История успеха отправлена",
                        "error": "Не удалось отправить историю успеха"
                    }
                }
            }
        }
    ]
}', 1);