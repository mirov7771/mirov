--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4908
update public.pages
set page = '{
           "features":[
              {
                 "config":{

                 },
                 "type":"participantSearch",
                 "foundsTitle":"Найдено: {0}",
                 "header":"Импортозамещение",
                 "participant":"startup",
                 "placeholder":"Поиск сервисов-аналогов",
                 "position":1,
                 "shownFromTitle":"Показано {0} из {1}", "helperText": "Введите название сервиса, аналог которого хотите найти, или название стартапа",
                 "sortLabels":{
                    "alphabetically":"По алфавиту",
                    "byUpdateDate":"По дате обновления"
                 },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            },
                 "sysName":"startup_ru_participantSearch",
                 "title":"Импортозамещающие решения",
                 "isImport":true,
                 "noContent":{
                    "Startup":{
                       "title":"Добавьте информацию в анкету об импортозамещении",
                       "subtitle":"Чтобы стать заметнее для корпораций на SberUnity, укажите сервисы или компании, которые заменяет ваш продукт. Анкета появится в данном разделе после модерации.",
                       "button":{
                          "text":"Добавить информацию"
                       }
                    },
                    "Corporates":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Скоро здесь будут анкеты стартапов, которые добавили информацию про импортозамещение"
                    },
                    "Investor":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Скоро здесь будут анкеты стартапов, которые добавили информацию про импортозамещение"
                    }
                 },
                 "visible":true
              }
           ]
        }'
where code = 'import_auth_ru';