--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-1506
INSERT INTO public.screen (id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription) VALUES((select max(id)+1 from public.screen), '111260', 4, 'New_Company', ' {
  "form": [
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "name",
          "localName": "Название компании",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "140",
          "showLength": false
        },
        {
          "sysName": "note",
          "localName": "Описание компании",
          "type": "string",
          "note": "Какую потребность стартапы будут решать в рамках пилота?",
          "edited": true,
          "required": true,
          "maxLength": "300"
        },
        {
          "sysName": "resourceUri",
          "localName": "Сайт компании",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "200",
          "showLength": false
        },        {
          "sysName": "email",
          "localName": "Контактный email",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        }, {
          "sysName": "logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
  ]
}
]}', NULL, 'Добавление компании', '', 1, NULL, NULL, NULL, NULL);

INSERT INTO public.screen (id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription) VALUES((select max(id)+1 from public.screen), '111260', 4, 'сompany_edit', ' {
  "form": [
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "name",
          "localName": "Название компании",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "50",
          "showLength": false
        },
        {
          "sysName": "note",
          "localName": "Описание компании",
          "type": "string",
          "note": "Какую потребность стартапы будут решать в рамках пилота?",
          "edited": true,
          "required": true,
          "maxLength": "1000"
        },
        {
          "sysName": "resourceUri",
          "localName": "Сайт компании",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "200",
          "showLength": false
        },        {
          "sysName": "email",
          "localName": "Контактный email",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        }, {
          "sysName": "logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [".png"]
        }
  ]
}
]}', NULL, 'Изменение компании', '', 1, NULL, NULL, NULL, NULL);


INSERT INTO public.screen (id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription) VALUES((select max(id)+1 from public.screen), '111260', 4, 'New_vas', ' {
  "form": [
    {
      "module": "Создание предложения",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "discount",
          "localName": "Краткое предложение",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "250",
          "showLength": false
        },
        {
          "sysName": "offer",
          "localName": "Полное предложение",
          "type": "string",
          "note": "Какую потребность стартапы будут решать в рамках пилота?",
          "edited": true,
          "required": true,
          "maxLength": "1000"
        },
        {
          "sysName": "smallNote",
          "localName": "Краткое описание продукта",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "150",
          "showLength": false
        },        {
          "sysName": "note",
          "localName": "Полное описание продукта",
          "note": "Доступно при подробном просмотре карточки",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "1000"
        },{
          "sysName": "category",
          "localName": "Категория предложения",
          "note": "",
          "type": "array",
          "format": "dropdown",
          "activity": [
            10000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        }, {
          "sysName": "priority",
          "localName": "Приоритет",
          "note": "Чем больше, тем выше в списке",
          "type": "int",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "edited": true,
          "required": true
        },{
          "sysName": "dateFrom",
          "localName": "Дата начала",
          "type": "date",
          "edited": true,
          "required": true
        },{
          "sysName": "dateTo",
          "localName": "Дата окончания",
          "type": "date",
          "edited": true,
          "required": true
        }, {
          "sysName": "offerUri",
          "localName": "Ссылка на старницу приложения",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
        }
  ]
}
]}', NULL, 'Создание предложения', '', 1, NULL, NULL, NULL, NULL);

INSERT INTO public.screen (id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription) VALUES((select max(id)+1 from public.screen), '111260', 4, 'vas_edit', ' {
  "form": [
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "discount",
          "localName": "Краткое предложение",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "250",
          "showLength": false
        },
        {
          "sysName": "offer",
          "localName": "Полное предложение",
          "type": "string",
          "note": "Какую потребность стартапы будут решать в рамках пилота?",
          "edited": true,
          "required": true,
          "maxLength": "1000"
        },
        {
          "sysName": "smallNote",
          "localName": "Краткое описание продукта",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "150",
          "showLength": false
        },        {
          "sysName": "note",
          "localName": "Полное описание продукта",
          "note": "Доступно при подробном просмотре карточки",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "1000"
        },{
          "sysName": "category",
          "localName": "Категория предложения",
          "note": "",
          "type": "array",
          "format": "dropdown",
          "activity": [
            10000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        }, {
          "sysName": "priority",
          "localName": "Приоритет",
          "note": "Чем больше, тем выше в списке",
          "type": "int",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "edited": true,
          "required": true
        },{
          "sysName": "dateFrom",
          "localName": "Дата начала",
          "type": "date",
          "edited": true,
          "required": true
        },{
          "sysName": "dateTo",
          "localName": "Дата окончания",
          "type": "date",
          "edited": true,
          "required": true
        }, {
          "sysName": "offerUri",
          "localName": "Ссылка на старницу приложения",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
        }
  ]
}
]}', NULL, '', '', 1, NULL, NULL, NULL, NULL);

