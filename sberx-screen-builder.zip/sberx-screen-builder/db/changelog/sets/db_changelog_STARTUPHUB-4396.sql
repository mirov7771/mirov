--liquibase formatted sql
--changeset Filatov EA:STARTUPHUB-4396
delete from screen where formname = 'offer_SuperClient';
INSERT INTO screen
("type", formname, formview, "name", lang_id)
VALUES(7, 'offer_SuperClient', '{
  "form": [
    {
      "page": 1,
      "module": "Основная информация",
      "moduleNote": "",
      "fields": [
        {
          "rows": "1",
          "type": "string",
          "edited": true,
          "example": "Название предлагаемого пилота",
          "sysName": "reply_offerName",
          "required": true,
          "localName": "Название пилота",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Расскажите о предлагаемой технологии",
          "sysName": "reply_offerDescription",
          "required": true,
          "localName": "Краткое описание пилота",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Описание",
          "sysName": "reply_note",
          "required": true,
          "localName": "Какую потребность корпорации вы решите?",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "mask": "$",
          "note": "Сумма, в которую вы оцениваете ваш пилотный запуск",
          "type": "string",
          "edited": true,
          "example": "$",
          "sysName": "reply_cost",
          "required": false,
          "localName": "Какова стоимость вашего решения",
          "maxLength": "30"
        },
        {
          "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Комментарий",
          "sysName": "reply_process",
          "required": true,
          "localName": "Как вы видите процесс пилотирования",
          "minLength": "50",
          "maxLength": "500"
        }
      ]
    },
    {
      "page": 1,
      "module": "Презентация",
      "moduleNote": "",
      "fields": [
        {
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "edited": true,
          "format": "URL",
          "sysName": "reply_fileURL",
          "required": false,
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "maxLength": "5",
          "allowedTypes": [
            ".pdf"
          ]
        }
      ]
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2bPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "format": "heading",
          "sysName": "b2bPilots[]_reference",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "format": "body",
          "sysName": "b2bPilots[]_suggestCase",
          "required": false,
          "localName": ""
        }
      ],
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "isArray": "true",
      "pageName": "",
      "moduleNote": "",
      "moduleFormat": "card"
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "string",
          "edited": false,
          "format": "heading",
          "sysName": "response[]_question",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "format": "body",
          "sysName": "response[]_responseNote",
          "required": false,
          "localName": ""
        }
      ],
      "module": "Дополнительные вопросы",
      "isArray": "true",
      "moduleFormat": "card"
    }
  ]
}','Просмотр предложения Корпорацией', 1);
