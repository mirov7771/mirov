--liquibase formatted sql
--changeset Mirov AA:community_forms_nz_3
update public.screen set
    formedit = '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "investorType",
                    "localName": "Выберите подроль инвестора*",
                    "type": "array",
                    "format": "chip_selected",
                    "multySelect": false,
                    "edited": true,
                    "required": true,
                    "items": [
                        {
                            "content": "Венчурный фонд",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                            "clickMethod": "GET"
                        },
                        {
                            "content": "Бизнес-ангел",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
                            "clickMethod": "GET"
                        },
                        {
                            "content": "Фэмили офис",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
                            "clickMethod": "GET",
                            "default": true
                        }
                    ]
                },
                {
                    "sysName": "name",
                    "localName": "Название family office*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 3
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                }
            ]
        }
    ]
}'
where formname  = 'New_PreAuth_Community_FamilyOffice'