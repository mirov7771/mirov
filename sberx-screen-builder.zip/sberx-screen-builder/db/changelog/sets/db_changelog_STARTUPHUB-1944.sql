--liquibase formatted sql
--changeset Molotkov D:SBERXTECH-1944 бновление анкет

UPDATE public.screen set formedit='{}'::json::json, formview='{ "form": [{
  "module": "Основная информация",
  "page": 1,
  "fields": [{
    "sysName": "questionnaire_fullName",
    "localName": "Название",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_acceleratorCode",
    "localName": "Является выпускником:",
    "type": "array",
    "format": "text",
    "activity": [26000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_birthYear",
    "localName": "Год основания",
    "type": "int",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_interactionType",
    "localName": "Тип взаимодействия с пользователем",
    "type": "array",
    "format": "text",
    "activity": [8000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_businessModel",
    "localName": "Бизнес-модели",
    "type": "array",
    "format": "search_dropdown",
    "activity": [
      24000
    ],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_industry",
    "localName": "Индустрия проекта",
    "type": "array",
    "format": "text",
    "activity": [3000],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_note",
    "localName": "Краткое описание проекта",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_problem",
    "localName": "Проблема, которую решает проект",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_auditory",
    "localName": "Целевая аудитория",
    "type": "string",
    "edited": false,
    "required": false,
    "isBlur" : true
  }
  ]
}, {
  "module": "Дополнительные контакты (Доступно по подписке)",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "fields": [
    {
      "sysName": "contacts[]_name",
      "localName": "Ссылка",
      "type": "hyperlink",
      "edited": false,
      "required": false,
      "isBlur" : true
    }
  ]
},{
  "module": "О проекте (Доступно по подписке)",
  "page": 1,
  "fields": [{
    "sysName": "project_mvpCode",
    "localName": "Стадия развития продукта",
    "type": "array",
    "format": "text",
    "activity": [27000],
    "edited": false,
    "required": false
  },{
    "sysName": "project_demoSite",
    "localName": "Ссылка на демо",
    "type": "hyperlink",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false,
    "isBlur" : true
  },{
    "sysName": "project_demoVideo",
    "localName": "Видео о продукте",
    "type": "hyperlink",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false,
    "isBlur" : true
  },
    {
      "sysName": "investment_businessPlan",
      "localName": "Презентация (Доступно по подписке)",
      "type": "hyperlink",
      "edited": false,
      "required": false,
      "isBlur" : true
    },{
      "sysName": "project_pitchVideo",
      "localName": "Видео питча",
      "type": "hyperlink",
      "edited": false,
      "required": false,
      "isBlur" : true

    },  {
      "sysName": "project_geography",
      "localName": "Рынки, на которых работает стартап",
      "type": "array",
      "format": "text",
      "activity": [2000],
      "edited": false,
      "required": false,
      "isBlur" : true
    },{
      "sysName": "project_expansion",
      "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false,
      "isBlur" : true
    }, {
      "sysName": "project_sales",
      "localName": "Продажи",
      "type": "array",
      "format": "text",
      "activity": [5000],
      "edited": false,
      "required": false,
      "isBlur" : true
    }, {
      "sysName": "investment_turnover",
      "localName": "Оборот",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur" : true
    }
  ]
}, {
  "module": "Конкуренты (Доступно по подписке)",
  "page": 1,
  "fields": [{
    "sysName": "project_competitor",
    "localName": "Прямые конкуренты",
    "type": "string",
    "edited": false,
    "required": false,
    "isBlur" : true
  },{
    "sysName": "project_indirectCompetitor",
    "localName": "Косвенные конкуренты",
    "type": "string",
    "edited": false,
    "required": false,
    "isBlur" : true
  },{
    "sysName": "project_upSide",
    "localName": "Преимущества перед конкурентами",
    "type": "string",
    "edited": false,
    "required": false,
    "isBlur" : true
  }, {
    "sysName": "project_downSide",
    "localName": "Недостатки перед конкурентами ",
    "type": "string",
    "edited": false,
    "required": false,
    "isBlur" : true
  }
  ]
}, {
  "module": "Команда (Доступно по подписке)",
  "page": 1,
  "fields": [


    {
      "sysName": "questionnaire_locationCountry",
      "localName": "Страна, где находится команда",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false,
      "isBlur" : true
    },
    {
      "sysName": "questionnaire_location",
      "localName": "Город, где находится команда",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur" : true
    },
    {
      "sysName": "project_staff",
      "localName": "Количество сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "isBlur" : true
    }, {
      "sysName": "project_hiringStaff",
      "localName": "Из них наемных сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "isBlur" : true
    }
  ]
},  {
  "module": "",
  "page": 1,
  "isArray": "true",
  "fields": [{
    "sysName": "worker_parentId",
    "localName": "",
    "type": "long",
    "format": "hide",
    "edited": false,
    "required": false
  }, {
    "sysName": "worker_isFounder",
    "localName": "",
    "type": "boolean",
    "format": "hide",
    "value": false,
    "edited": false,
    "required": false
  }, {
    "sysName": "worker_role",
    "localName": "Ключевые члены команды",
    "type": "string",
    "edited": false,
    "required": false,
    "direction": "concatenation",
    "isBlur" : true
  },{
    "sysName": "workers[]_note",
    "localName": "Опыт",
    "type": "string",
    "maxLength": "150",
    "edited": false,
    "required": false,
    "isBlur" : true
  }
  ]
}, {
  "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы (Доступно по подписке)",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "fields": [
    {
      "sysName": "b2bPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false,
      "isBlur" : true
    },
    {
      "sysName": "b2bPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur" : true
    },
    {
      "sysName": "b2bPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur" : true
    }
  ]
}, {
  "module": "Успешные B2C-, C2C- кейсы (Доступно по подписке)",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "fields": [
    {
      "sysName": "b2cPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false,
      "isBlur" : true
    },
    {
      "sysName": "b2cPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur" : true
    },
    {
      "sysName": "b2cPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur" : true
    }
  ]
},{
  "module": "Инвестиции (Доступно по подписке)",
  "page": 1,
  "fields": [{
    "sysName": "investment_investment",
    "localName": "Привлекаете ли вы инвестиции?",
    "type": "boolean",
    "format": "switch",
    "edited": false,
    "required": false,
    "isBlur" : true
  }, {
    "sysName": "investment_round",
    "localName": "Раунд",
    "type": "array",
    "format": "chip",
    "activity": [6000],
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false,
    "isBlur" : true
  }, {
    "sysName": "investment_sumInvestment",
    "localName": "Требуемая сумма",
    "type": "int",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false,
    "isBlur" : true
  },{
    "sysName": "investment_lastInvestment",
    "localName": "Объем ранее привлеченных инвестиций, всего",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false,
    "isBlur" : true
  },{
    "sysName": "investment_coInvestment",
    "localName": "Имя/ имена инвестора/ инвесторов",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false,
    "isBlur" : true
  }
  ]
},{
  "module": "Дополнительная информация (Доступно по подписке)",
  "page": 1,
  "fields": [
    {
      "sysName": "project_addNote",
      "localName": "Что еще важно знать о проекте?",
      "type": "string",
      "maxLength": "500",
      "edited": false,
      "required": false,
      "isBlur" : true
    }
  ]
}
]
}
'::json::json WHERE formname='startup_Client';



UPDATE public.screen SET  formview= '{
  "form": [
    {
      "module": "Организация",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "Questionnaire_Modified",
          "localName": "Время обновления",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "type": "string",
          "edited": false,
          "required": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "text",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "chip",
          "activity": [
            24000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_industry",
          "localName": "Направления",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Прототип",
      "page": 1,
      "pageName": "",
      "fields": [
       {
    "sysName": "project_mvpCode",
    "localName": "Стадия развития продукта",
    "type": "array",
    "format": "text",
    "activity": [27000],
    "edited": false,
    "required": false
  },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }

      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "string",
          "edited": false,
          "required": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "text",
          "activity": [
            5000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в месяц и оборот в год",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные B2C-, C2C- кейсы",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "type": "string",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "edited": false,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "edited": false,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Заинтересованы ли вы сейчас в привлечении инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций",
          "type": "int",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 1,
      "pageName": "",
      "fields": [
        {
    "sysName": "questionnaire_accelerator",
    "localName": "Является выпускником:",
    "type": "array",
    "format": "text",
    "activity": [26000],
    "edited": false,
    "required": false
  }
      ]
    },
    {
      "module": "Сообщества",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществах СберСтартап",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'::json::json where formname='startup_Administrator';



UPDATE public.screen SET formedit='{
  "form": [

    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": true,
          "required": false,
          "direction": "row",
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "format": "year",
          "mask": "year:[2000]",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "direction": "row",
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Фирменное наименование (Товарный знак)",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО|ПАО|ЗАО|ООО|ИП|АО).)*$",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },{
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "note": "Название на другом языке (англ/рус)",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },{
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
           "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
       },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо*",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Опционально. Укажите ссылки на внешние ресурсы",
      "isArray": "true",
      "actionText": "Добавить ресурс",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },{
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "title": "Где базируется ваш проект?",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true

        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": true,
          "required": true,

          "maxLength": 30,
          "showLength": false
        },
        {
          "sysName": "project_industry",
          "localName": "Направления",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "maxLength": "200",
          "note": "Опишите проект в 1-2 предложениях",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
     {
      "module": "Стадия развития продукта",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27004,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "100",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "title": "Презентация",
          "description": "Не обязательно загружать, но повышает шансы заинтересовать инвесторов и корпорации",
          "type": "hyperlink",
          "format": "URL",
          "note": "Принимаем файлы до 50 Мб. Формат — PDF",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },{
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "string",
          "maxLength": "70",
          "edited": true,
          "required": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в месяц и оборот в год",
          "type": "string",
          "maxLength": "300",
          "note": "Опционально. Если у вас пока нет оборота, то напишите, сколько есть первых клиентов, было ли проведено исследование Customer Development и с каким количеством пользователей",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 4,
      "pageName": "Конкуренты",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },{
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Команда",
      "page": 5,
      "pageName": "Команда",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "edited": true,
          "required": true,
          "direction": "row"
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "minValue": 0,
          "maxValue": 1000,
          "format": "[0;1000]",
          "edited": true,
          "required": true,
          "direction": "row"
        }
      ]
    },
    {
      "module": "",
      "page": 5,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые роли / должности в стартапе закрыты",
      "actionText": "Добавить роль",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "Если вы В2В-, В2G-, B2B2C-, В2О- стартап: у вас есть успешные пилоты / внедрения?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "moduleNote": "Опционально. Укажите, с кем у вас были успешные пилоты / внедрения, и опишите их суть и результаты, но только если раскрытие этой информации не противоречит договоренностям с корпорацией и пр. Эту информацию увидят другие пользователи SberUnity",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilotsB2C",
          "localName": "Если вы B2C-, C2C- стартап: у вас есть первые продажи на реальных клиентах (не FFF)?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование",
      "triggerField": "questionnaire_successPilotsB2C",
      "triggerValue": "true",
      "moduleNote": "",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 6,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "note": "Опишите в двух-трех предложениях, как именно корпорация должна использовать ваш стартап и что это ей даст",
          "type": "string",
          "maxLength": "300",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "maxLength": "120",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 7,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Заинтересованы ли вы сейчас в привлечении инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций(USD)",
          "type": "int",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите объем ранее привлеченных инвестиций",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Укажите, выпускником каких акселераторов Сбера вы являетесь",
          "type": "array",
          "format": "dropdown",
          "activity": [
            26000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщества",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществе СберСтартап?*",
          "note": "и получать советы экспертов, разбирать кейсы фаундеров стартапов, узнавать первым новости венчурного рынка и иметь доступ к стартап-вакансиям?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 8,
      "pageName": "Дополнительная информация",
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'::json::json WHERE formname='startup_edit';


UPDATE public.screen SET   formview='{ "form": [{
  "module": "Основная информация",
  "page": 1,
  "fields": [{
    "sysName": "questionnaire_fullName",
    "localName": "Название",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_accelerator",
    "localName": "Является выпускником:",
    "type": "array",
    "format": "text",
    "activity": [26000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_birthYear",
    "localName": "Год основания",
    "type": "int",
    "edited": false,
    "required": false
  },{
    "sysName": "project_interactionType",
    "localName": "Тип взаимодействия с пользователем",
    "type": "array",
    "format": "text",
    "activity": [8000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_businessModel",
    "localName": "Бизнес-модели",
    "type": "array",
    "format": "search_dropdown",
    "activity": [
      24000
    ],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_industry",
    "localName": "Индустрия проекта",
    "type": "array",
    "format": "text",
    "activity": [3000],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_note",
    "localName": "Краткое описание проекта",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_problem",
    "localName": "Проблема, которую решает проект",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_auditory",
    "localName": "Целевая аудитория",
    "type": "string",
    "edited": false,
    "required": false
  }
  ]
}, {
  "module": "Дополнительные контакты",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "fields": [
    {
      "sysName": "contacts[]_name",
      "localName": "Ссылка",
      "type": "hyperlink",
      "edited": false,
      "required": false
    }
  ]
},{
  "module": "О проекте",
  "page": 1,
  "fields": [{
    "sysName": "project_mvpCode",
    "localName": "Стадия развития продукта",
    "type": "array",
    "format": "text",
    "activity": [27000],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_demoSite",
    "localName": "Ссылка на демо",
    "type": "hyperlink",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "project_demoVideo",
    "localName": "Видео о продукте",
    "type": "hyperlink",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },
    {
      "sysName": "investment_businessPlan",
      "localName": "Презентация",
      "type": "hyperlink",
      "edited": false,
      "required": false
    },{
      "sysName": "project_pitchVideo",
      "localName": "Видео питча",
      "type": "hyperlink",
      "edited": false,
      "required": false

    },  {
      "sysName": "project_geography",
      "localName": "Рынки, на которых работает стартап",
      "type": "array",
      "format": "text",
      "activity": [2000],
      "edited": false,
      "required": false
    },{
      "sysName": "project_expansion",
      "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }, {
      "sysName": "project_sales",
      "localName": "Продажи",
      "type": "array",
      "format": "text",
      "activity": [5000],
      "edited": false,
      "required": false
    }, {
      "sysName": "investment_turnover",
      "localName": "Оборот",
      "type": "string",
      "edited": false,
      "required": false
    }
  ]
}, {
  "module": "Конкуренты",
  "page": 1,
  "fields": [{
    "sysName": "project_competitor",
    "localName": "Прямые конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_indirectCompetitor",
    "localName": "Косвенные конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_upSide",
    "localName": "Преимущества перед конкурентами",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_downSide",
    "localName": "Недостатки перед конкурентами ",
    "type": "string",
    "edited": false,
    "required": false
  }
  ]
}, {
  "module": "Команда",
  "page": 1,
  "fields": [


    {
      "sysName": "questionnaire_locationCountry",
      "localName": "Страна, где находится команда",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },
    {
      "sysName": "questionnaire_location",
      "localName": "Город, где находится команда",
      "type": "string",
      "edited": false,
      "required": false
    },
    {
      "sysName": "project_staff",
      "localName": "Количество сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }, {
      "sysName": "project_hiringStaff",
      "localName": "Из них наемных сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }
  ]
},  {
  "module": "",
  "page": 1,
  "isArray": "true",
  "fields": [{
    "sysName": "worker_parentId",
    "localName": "",
    "type": "long",
    "format": "hide",
    "edited": false,
    "required": false
  }, {
    "sysName": "worker_isFounder",
    "localName": "",
    "type": "boolean",
    "format": "hide",
    "value": false,
    "edited": false,
    "required": false
  }, {
    "sysName": "worker_role",
    "localName": "Ключевые члены команды",
    "type": "string",
    "edited": false,
    "required": false,
    "direction": "concatenation"
  },{
    "sysName": "workers[]_note",
    "localName": "Опыт",
    "type": "string",
    "maxLength": "150",
    "edited": false,
    "required": false
  }
  ]
}, {
  "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "fields": [
    {
      "sysName": "b2bPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2bPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2bPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "edited": false,
      "required": false
    }
  ]
}, {
  "module": "Успешные B2C-, C2C- кейсы",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "fields": [
    {
      "sysName": "b2cPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "edited": false,
      "required": false
    }
  ]
},{
  "module": "Инвестиции",
  "page": 1,
  "fields": [{
    "sysName": "investment_investment",
    "localName": "Привлекаете ли вы инвестиции?",
    "type": "boolean",
    "format": "switch",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_round",
    "localName": "Раунд",
    "type": "array",
    "format": "chip",
    "activity": [6000],
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_sumInvestment",
    "localName": "Требуемая сумма",
    "type": "int",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_lastInvestment",
    "localName": "Объем ранее привлеченных инвестиций, всего",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_coInvestment",
    "localName": "Имя/ имена инвестора/ инвесторов",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }
  ]
},{
  "module": "Дополнительная информация",
  "page": 1,
  "fields": [
    {
      "sysName": "project_addNote",
      "localName": "Что еще важно знать о проекте?",
      "type": "string",
      "maxLength": "500",
      "edited": false,
      "required": false
    }
  ]
}
]
}
'::json::json WHERE formname='startup_SuperClient';




UPDATE public.screen SET formedit='{
  "form": [
    {
      "module": "Условия соглашения",
      "page": 1,
      "pageName": "Юридическая информация",
      "fields": [
        {
          "sysName": "userConsent_consent",
          "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": true,
          "required": true,
          "direction": "row",
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "mask": "2000;getyear",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "direction": "row",
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Фирменное наименование (Товарный знак)",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО|ПАО|ЗАО|ООО|ИП|АО).)*$",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },{
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "note": "Название на другом языке (англ/рус)",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },{
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
           "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
       },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо*",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Опционально. Укажите ссылки на внешние ресурсы",
      "isArray": "true",
      "actionText": "Добавить ресурс",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "mask": "URL",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },{
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "title": "Где базируется ваш проект?",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true

        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": true,
          "required": true,

          "maxLength": 30,
          "showLength": false
        },
        {
          "sysName": "project_industry",
          "localName": "Направления",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "maxLength": "200",
          "note": "Опишите проект в 1-2 предложениях",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Стадия развития продукта",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27002,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27002,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27003,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27003,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "title": "Презентация",
          "description": "Не обязательно загружать, но повышает шансы заинтересовать инвесторов и корпорации",
          "type": "hyperlink",
          "format": "URL",
          "note": "Принимаем файлы до 50 Мб. Формат — PDF",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },{
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "string",
          "maxLength": "70",
          "edited": true,
          "required": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в месяц и оборот в год",
          "type": "string",
          "maxLength": "300",
          "note": "Опционально. Если у вас пока нет оборота, то напишите, сколько есть первых клиентов, было ли проведено исследование Customer Development и с каким количеством пользователей",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 4,
      "pageName": "Конкуренты",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },{
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Команда",
      "page": 5,
      "pageName": "Команда",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "format": "[1;1000]",
          "minValue": 1,
          "maxValue": 1000,
          "edited": true,
          "required": true,
          "direction": "row"
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "format": "[0;1000]",
          "minValue": 0,
          "maxValue": 1000,
          "edited": true,
          "required": true,
          "direction": "row"
        }
      ]
    },
    {
      "module": "",
      "page": 5,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые роли / должности в стартапе закрыты",
      "actionText": "Добавить роль",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "Если вы В2В-, В2G-, B2B2C-, В2О- стартап: у вас есть успешные пилоты / внедрения?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "moduleNote": "Опционально. Укажите, с кем у вас были успешные пилоты / внедрения, и опишите их суть и результаты, но только если раскрытие этой информации не противоречит договоренностям с корпорацией и пр. Эту информацию увидят другие пользователи SberUnity",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilotsB2C",
          "localName": "Если вы B2C-, C2C- стартап: у вас есть первые продажи на реальных клиентах (не FFF)?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование",
      "triggerField": "questionnaire_successPilotsB2C",
      "triggerValue": "true",
      "moduleNote": "",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 6,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "note": "Опишите в двух-трех предложениях, как именно корпорация должна использовать ваш стартап и что это ей даст",
          "type": "string",
          "maxLength": "300",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "maxLength": "120",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 7,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Заинтересованы ли вы сейчас в привлечении инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций(USD)",
          "type": "int",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите объем ранее привлеченных инвестиций",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Укажите, выпускником каких акселераторов Сбера вы являетесь",
          "type": "array",
          "format": "dropdown",
          "activity": [
            26000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщества",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществе СберСтартап?*",
          "note": "и получать советы экспертов, разбирать кейсы фаундеров стартапов, узнавать первым новости венчурного рынка и иметь доступ к стартап-вакансиям?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 8,
      "pageName": "Дополнительная информация",
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'::json::json, formview=NULL, "name"='Анкета стартапа', description='<br/>Заполнение анкеты займет примерно 20 минут.<br/>
<br/>Пожалуйста, заполняйте поля максимально полно – это сделает профиль вашего стартапа на SberUnity более интересным и заметным для других участников.<br/>
<br/>Внесенная в анкету информация сохраняется автоматически.<br/>
Вы можете завершить заполнение в любое время.<br/>
<br/>Знаком «*» обозначаются поля, информация из которых будет доступна только администраторам SberUnity для работы. Данные из остальных полей будут доступны для всех пользователей.<br/>' WHERE formname='New_StartUp';





UPDATE public.screen SET  formedit='{
          "form": [
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_questionnaireid",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "edited": true,
                  "required": true
                },{
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "type": "string",
                  "edited": false,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации",
                  "type": "int",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": false,
                  "required": true,
                  "multySelect": false
                },
                {
                  "sysName": "representative_facebook",
                  "localName": "Профиль в Facebook*",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "format": "hide"
                }
              ]
            },
            {
              "module": "Данные профиля",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_investorType",
                  "localName": "Выберите тип инвестора",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    11000
                  ],
                  "multySelect": false,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего фонда",
                  "note": "Например, \"Фонд и акселератор\"",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                  "note":"Например, \"Рассматриваю любые проекты\"",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего Family-Office",
                  "note": "Например, \"Фонд семьи Безосов\"",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },{
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите полно описание Вашего фонда",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите свою полную характеристику как бизнес-ангела",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите полное описание Вашего Family-Office",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Ваши данные",
              "page": 2,
              "pageName": "Ваши данные",
              "fields": [
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Добавьте фото",
                  "localName": "Загрузить фото",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "note": "Например, \"Управляющий партнёр\"",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_facebook",
                  "localName": "Профиль в Facebook*",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "investment_industry",
                  "localName": "Направления",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_geography",
                  "title": "География стартапов",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Стадии инвестирования",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Данные о стартапах портфеля",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "questionnaire_activeDealsNumber",
                  "localName": "Количество стартапов в портфеле",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_allDealsNumber",
                  "localName": "Количество сделок, всего",
                  "note": "Количество стартапов, в которые Вы инвестировали",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_exitDealsNumber",
                  "localName": "Количество выходов",
                  "note": "Количество стартапов, в которые Вы инвестировали и вышли",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                }
              ]
            },
            {
              "module": "",
              "page": 3,
              "pageName": "Инвестиции",
              "subTitle": "Стартап №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить стартап",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_company",
                  "localName": "Название стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "questionnairePilots[]_site",
                  "localName": "Ссылка на сайт стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Инвестиционные клубы",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "fields": [
                {
                  "sysName": "questionnaire_club",
                  "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "subTitle": "Клуб / сообщество №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить клуб",
              "triggerField": "questionnaire_club",
              "triggerValue": true,
              "fields": [
                {
                  "sysName": "investorClubs[]_name",
                  "localName": "Название клуба / сообщества*",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "investorClubs[]_role",
                  "localName": "Ваша роль в клубе / сообществе*",
                  "note": "Например, \"Основатель клуба\"",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            }
          ]
        }'::json::json, description='<br>Знаком «*» обозначаются поля, информация из которых будет доступна только администраторам SberUnity для работы.<br/>Данные из остальных полей будут доступны для всех пользователей.<br/>', pages=4, buttons=NULL, logofile=NULL, offerdescription=NULL, secondofferdescription=NULL WHERE formname='investor_edit';




       UPDATE public.screen SET  formview='{
      "form": [
        {
          "module": "Юридическая информация об организации",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Наименование организации",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год регистрации",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_name",
              "localName": "Публичное название / название бренда",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_registrationCountry",
              "localName": "Страна юрисдикции*",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Данные профиля",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_investorType",
              "localName": "Выберите тип инвестора",
              "type": "array",
              "format": "chip",
              "activity": [
                11000
              ],
              "edited": false,
              "required": false
            },{
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего фонда",
                  "note": "Например: Фонд и акселератор",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                  "note":"Например, Рассматриваю любые проекты",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего family-office",
                  "note": "Например: Фонд семьи Безосов",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },{
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите полно описание Вашего фонда",
                  "note": "Например: Фонд и акселератор",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите свою полную характеристику как бизнес-ангела",
                  "note":"Например, Рассматриваю любые проекты",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите полное описание Вашего family-office",
                  "note": "Например: Фонд семьи Безосов",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11003",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11002",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11003",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11003",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Ваши данные",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить фото",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11002",
              "edited": false,
              "required": false
            },{
              "sysName": "questionnaire_portfolioNote",
              "localName": "Краткое описание портфельного стартапа",
              "type": "string",
              "maxLength": "300",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_fio",
              "localName": "Фамилия Имя",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_role",
              "localName": "Должность*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_phone",
              "localName": "Мобильный телефон*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_facebook",
              "localName": "Профиль в Facebook*",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиции",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "investment_industry",
              "localName": "Направления",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "investment_geography",
              "title": "География стартапов",
              "localName": "География стартапов",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "investment_round",
              "localName": "Стадии инвестирования",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Данные о стартапах портфеля",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_activeDealsNumber",
              "localName": "Количество стартапов в портфеле",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_allDealsNumber",
              "localName": "Количество сделок, всего",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_exitDealsNumber",
              "localName": "Количество выходов",
              "type": "int",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "",
          "page": 1,
          "pageName": "",
          "withIndex": true,
          "isArray": "true",
          "fields": [
            {
              "sysName": "questionnairePilots[]_pilotid",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_site",
              "localName": "Ссылка на сайт стартапа",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиционные клубы",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_club",
              "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
          "page": 1,
          "pageName": "",
          "withIndex": true,
          "isArray": "true",
          "fields": [
            {
              "sysName": "investorClubs[]_name",
              "localName": "Название клуба / сообщества*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "investorClubs[]_role",
              "localName": "Ваша роль в клубе / сообществе*",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        }
      ]
    }'::json::json, "name"=NULL, description=NULL, pages=NULL, buttons='{
    "buttons": [{
        "type": "archive",
        "code": 20005,
        "action": "/verify",
        "variant": "danger",
        "text": "В архив"
    },
    {
        "type": "active",
        "code": 20004,
        "action": "/verify",
        "variant": "primary",
        "text": "Согласовать анкету"
    },
    {
        "type": "processing",
        "code": 20003,
        "action": "/verify",
        "variant": "default",
        "text": "На доработку"
    }]
    }'::json::json WHERE formname='investor_Administrator';




   UPDATE public.screen SET   formview='{
          "form": [{
            "module": "Основная информация",
            "page": 1,
            "fields": [{
              "sysName": "questionnaire_investorType",
              "localName": "Тип инвестора",
              "type": "array",
              "format": "text",
              "activity": [
                11000
              ],
              "edited": false,
              "required": false
            },{
              "sysName": "questionnaire_fullName",
              "localName": "Название/имя",
              "type": "string",
              "edited": false,
              "required": false
            },{
                  "sysName": "questionnaire_fullNote",
                  "localName": "Описание",
                  "type": "string",
                  "edited": false,
                  "required": false
            },{
              "sysName": "questionnaire_site",
              "localName": "Сайт (Доступно по подписке)",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_email",
              "localName": "Email (Доступно по подписке)",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
            ]
          }, {
            "module": "Инвестиции (Доступно по подписке)",
            "page": 1,
            "fields": [{
              "sysName": "investment_industry",
              "localName": "Направление инвестиций",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "project_geography",
              "localName": "География стартапов",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "investment_round",
              "localName": "Стадии инвестиций",
              "type": "array",
              "format": "text",
              "activity": [
                6000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "investment_note",
              "localName": "Особые условия инвестирования",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_portfolioNote",
              "localName": "Краткое описание портфельного стартапа",
              "type": "string",
              "maxLength": "300",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_allDealsNumber",
              "localName": "Количество стартапов, в которые инвестировал фонд",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_exitDealsNumber",
              "localName": "Количество выходов",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            }
            ]
          },{
            "module": "Портфель",
            "page": 1,
            "isArray": true,
            "fields": [{
              "sysName": "pilots[]_pilotid",
              "localName": "",
              "type": "int",
              "format": "hide",
              "edited": false,
              "required": false
            }, {
              "sysName": "pilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "edited": false,
              "required": false
            }
            ]
          }
          ]
        }'::json::json WHERE formname='investor_Client';


 UPDATE public.screen SET  formview='{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_investorType",
      "localName": "Тип инвестора",
      "type": "array",
      "format": "text",
      "activity": [
        11000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_fullName",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },{
                  "sysName": "questionnaire_fullnote",
                  "localName": "Описание",
                  "type": "string",
                  "edited": false,
                  "required": false
            },
      {
        "sysName": "questionnaire_portfolioNote",
        "localName": "Краткое описание портфельного стартапа",
        "type": "string",
        "maxLength": "300",
        "edited": false,
        "required": false
      },{
        "sysName": "questionnaire_site",
        "localName": "Сайт",
        "type": "hyperlink",
        "edited": false,
        "required": false
      },{
        "sysName": "questionnaire_email",
        "localName": "Email",
        "type": "string",
        "edited": false,
        "required": false
      }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Направление инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География стартапов",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_round",
      "localName": "Стадии инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_note",
      "localName": "Особые условия инвестирования",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_allDealsNumber",
      "localName": "Количество стартапов, в которые инвестировал фонд",
      "type": "int",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_exitDealsNumber",
      "localName": "Количество выходов",
      "type": "int",
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "Портфель",
    "page": 1,
    "isArray": true,
    "fields": [{
      "sysName": "questionnairePilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_company",
      "localName": "Название стартапа",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}
'::json::json WHERE formname='investor_SuperClient';

update public.screen set formedit='{
          "form": [
            {
              "module": "Условия соглашения",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "userConsent_consent",
                  "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
                  "type": "boolean",
                  "format": "checkbox",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "userConsent_contract",
                  "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
                  "type": "boolean",
                  "format": "checkbox",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации",
                  "type": "int",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": false,
                  "required": true,
                  "multySelect": false
                }
              ]
            },
            {
              "module": "Данные профиля",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_investorType",
                  "localName": "Выберите тип инвестора",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    11000
                  ],
                  "multySelect": false,
                  "edited": true,
                  "required": true
                }, {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего фонда",
                  "note": "Например, \"Фонд и акселератор\"",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                  "note":"Например, \"Рассматриваю любые проекты\"",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего Family-Office",
                  "note": "Например: \"Фонд семьи Безосов\"",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },{
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите полно описание Вашего фонда",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите свою полную характеристику как бизнес-ангела",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_fullNote",
                  "localName": "Укажите полное описание Вашего Family-Office",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 1000,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Ваши данные",
              "page": 2,
              "pageName": "Ваши данные",
              "fields": [
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Добавьте фото",
                  "localName": "Загрузить фото",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "note": "Например, \"Управляющий партнёр\"",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_facebook",
                  "localName": "Профиль в Facebook*",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "investment_industry",
                  "localName": "Направления",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_geography",
                  "title": "География стартапов",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Стадии инвестирования",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Данные о стартапах портфеля",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "questionnaire_activeDealsNumber",
                  "localName": "Количество стартапов в портфеле",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_allDealsNumber",
                  "localName": "Количество сделок, всего",
                  "note": "Количество стартапов, в которые Вы инвестировали",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_exitDealsNumber",
                  "localName": "Количество выходов",
                  "note": "Количество стартапов, в которые Вы инвестировали и вышли",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                }
              ]
            },
            {
              "module": "",
              "page": 3,
              "pageName": "Инвестиции",
              "subTitle": "Стартап №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить стартап",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_company",
                  "localName": "Название стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "questionnairePilots[]_site",
                  "localName": "Ссылка на сайт стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Инвестиционные клубы",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "fields": [
                {
                  "sysName": "questionnaire_club",
                  "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "subTitle": "Клуб / сообщество №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить клуб",
              "triggerField": "questionnaire_club",
              "triggerValue": true,
              "fields": [
                {
                  "sysName": "investorClubs[]_name",
                  "localName": "Название клуба / сообщества*",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "investorClubs[]_role",
                  "localName": "Ваша роль в клубе / сообществе*",
                  "note": "Например, \"Основатель клуба\"",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            }
          ]
        }'::json::json   where formname='New_Investor';




        update public.screen set formedit='{
          "form": [
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация об организации",
              "moduleNote": "",
              "fields": [
                {
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации*",
                  "type": "int",
                  "format": "[1991;2021]",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": true,
                  "required": true,
                  "multySelect": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт корпорации",
                  "type": "string",
                  "maxLength": "100",
                  "edited": true,
                  "required": true,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Представитель",
              "page": 2,
              "pageName": "Информация о представителе",
              "moduleNote": "",
              "fields": [
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя представителя*",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_email",
                  "localName": "Электронная почта*",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Корпорация",
              "page": 3,
              "pageName": "Информация о корпорации",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "questionnaire_industry",
                  "localName": "Направление деятельности",
                  "note": "Выберите направления работы Вашей корпорации",
                  "description": "Выберите направления работы Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    22000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_innovationMethod",
                  "title": "Методы работы с инновациями",
                  "localName": "Укажите методы",
                  "note": "Выберите методы внедрения инноваций в Вашей корпорации ",
                  "description": "Выберите методы внедрения инноваций в Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    4000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "title": "Годовой оборот",
                  "sysName": "questionnaire_turnover",
                  "localName": "Годовой оборот",
                  "note": "Опционально",
                  "type": "array",
                  "format": "search_dropdown",
                  "edited": true,
                  "required": true,
                  "values": [
                    {
                      "name": "Микропредприятия — до 120 млн",
                      "code": "Микропредприятия — до 120 млн"
                    },
                    {
                      "name": "Малые предприятия — до 800 млн",
                      "code": "Малые предприятия — до 800 млн"
                    },
                    {
                      "name": "Средние предприятия — до 2 млрд рублей",
                      "code": "Средние предприятия — до 2 млрд рублей"
                    },
                    {
                      "name": "Крупный бизнес — до 30 млрд рублей",
                      "code": "Крупный бизнес — до 30 млрд рублей"
                    },
                    {
                      "name": "Крупнейший бизнес — свыше 30 млрд рублей",
                      "code": "Крупнейший бизнес — свыше 30 млрд рублей"
                    }
                  ]
                },
                {
              "sysName": "questionnaire_note",
              "localName": "Краткое описание",
              "type": "string",
              "maxLength": "150",
              "edited": true,
              "required": true
            },{
              "sysName": "questionnaire_fullNote",
              "localName": "Полное описание",
              "note": "Опишите корпорацию в нескольких предложениях",
              "type": "string",
              "maxLength": "480",
              "edited": true,
              "required": true
            },
                {
                  "sysName": "questionnaire_logoFile",
                  "localName": "Загрузить логотип",
                  "title": "Логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Работа со стартапами",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "fields": [
                {
                  "sysName": "project_industry",
                  "title": "Направления",
                  "description": "Выберите направления, по которым Вы ищете стартапы",
                  "localName": "Направления",
                  "note": "Выберите направления, по которым Вы ищете стартапы",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_stady",
                  "title": "Стадии развития стартапов",
                  "description": "Выберите интересующие стадии развития стартапов",
                  "localName": "Стадия развития",
                  "note": "Выберите интересующие стадии развития стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    7000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "title": "Потребности корпорации",
              "subTitle": "Потребность №",
              "withIndex": true,
              "actionText": "Добавить потребность",
              "isArray": "true",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotId",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_suggestCase",
                  "localName": "Описание потребности",
                  "note": "Кратко опишите суть Вашего запроса на пилотирование стартапа",
                  "type": "string",
                  "maxLength": "520",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 5,
              "pageName": "Пилотирование",
              "fields": [
                {
                  "sysName": "questionnaire_successPilots",
                  "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_startupInvestmentYears",
                  "title": "Информация о сотрудничестве со стартапами",
                  "localName": "Сколько лет Ваша корпорация работает со стартапами",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_overallPilots",
                  "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_lastYearInvestmentsCount",
                  "localName": "Количество пилотов со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },

                {
                  "sysName": "questionnaire_overallContracts",
                  "localName": "Количество контрактов (внедрений) со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 6,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "investment_investment",
                  "localName": "Инвестирует ли Ваша корпорация в стартапы?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_industry",
                  "title": "Направления",
                  "description": "Выберите интересные для Вас направления инвестирования",
                  "localName": "Направления",
                  "note": "Выберите интересные для Вас направления инвестирования",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Раунд инвестиций",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "project_geography",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 6,
              "pageName": "Инвестиции",
              "triggerField": "investment_investment",
              "triggerValue": true,
              "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
              "isArray": true,
              "subTitle": "Стартап №",
              "withIndex": true,
              "actionText": "Добавить кейс",
              "fields": [
                {
                  "sysName": "successPilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "successPilots[]_company",
                  "localName": "Название стартапа",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "successPilots[]_suggestCase",
                  "localName": "Описание кейса",
                  "type": "string",
                  "maxLength": "300",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Скаутинг",
              "page": 7,
              "pageName": "Скаутинг",
              "moduleNote": "Подбор технологических решений стартапов под запрос заказчика",
              "fields": [
                {
                  "sysName": "questionnaire_scouting",
                  "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            }
          ]
        }'::json::json   where formname='corporate_edit';


 update public.screen set formedit ='{
      "form": [
        {
          "module": "Условия соглашения",
          "page": 1,
          "pageName": "Юридическая информация об организации",
          "fields": [
            {
              "sysName": "userConsent_consent",
              "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
              "type": "boolean",
              "format": "checkbox",
              "edited": true,
              "required": true
            },
            {
              "sysName": "userConsent_contract",
              "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
              "type": "boolean",
              "format": "checkbox",
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Юридическая информация об организации",
          "page": 1,
          "pageName": "Юридическая информация об организации",
          "moduleNote": "",
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Наименование организации",
              "type": "string",
              "edited": true,
              "required": false,
              "direction": "row",
              "maxLength": 70,
              "showLength": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год регистрации*",
              "type": "int",
              "format": "[1991;2021]",
              "maxLength": 4,
              "edited": true,
              "required": true,
              "direction": "row",
              "showLength": false
            },
            {
              "sysName": "questionnaire_name",
              "localName": "Публичное название / название бренда",
              "type": "string",
              "maxLength": 100,
              "edited": true,
              "required": true,
              "showLength": false
            },
            {
              "sysName": "questionnaire_registrationCountry",
              "localName": "Страна юрисдикции*",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": true,
              "required": true,
              "multySelect": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "format": "e-mail",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт корпорации",
              "type": "string",
              "maxLength": "100",
              "edited": true,
              "required": true,
              "showLength": false
            }
          ]
        },
        {
          "module": "Представитель",
          "page": 2,
          "pageName": "Информация о представителе",
          "moduleNote": "",
          "fields": [
            {
              "sysName": "representative_fio",
              "localName": "Фамилия Имя представителя*",
              "type": "string",
              "edited": true,
              "required": true
            },
            {
              "sysName": "representative_role",
              "localName": "Должность*",
              "type": "string",
              "edited": true,
              "required": true
            },
            {
              "sysName": "representative_phone",
              "localName": "Мобильный телефон*",
              "type": "string",
              "format": "phone",
              "edited": true,
              "required": true,
              "mask": "phone"
            },
            {
              "sysName": "representative_email",
              "localName": "Электронная почта*",
              "type": "string",
              "format": "e-mail",
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Корпорация",
          "page": 3,
          "pageName": "Информация о корпорации",
          "fields": [
            {
              "title": "Направления",
              "sysName": "questionnaire_industry",
              "localName": "Направление деятельности",
              "note": "Выберите направления работы Вашей корпорации",
              "description": "Выберите направления работы Вашей корпорации",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                22000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_innovationMethod",
              "title": "Методы работы с инновациями",
              "localName": "Укажите методы",
              "note": "Выберите методы внедрения инноваций в Вашей корпорации ",
              "description": "Выберите методы внедрения инноваций в Вашей корпорации",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                4000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "title": "Годовой оборот",
              "sysName": "questionnaire_turnover",
              "localName": "Годовой оборот",
              "note": "Опционально",
              "type": "array",
              "format": "search_dropdown",
              "edited": true,
              "required": true,
              "values": [
                {
                  "name": "Микропредприятия — до 120 млн",
                  "code": "Микропредприятия — до 120 млн"
                },
                {
                  "name": "Малые предприятия — до 800 млн",
                  "code": "Малые предприятия — до 800 млн"
                },
                {
                  "name": "Средние предприятия — до 2 млрд рублей",
                  "code": "Средние предприятия — до 2 млрд рублей"
                },
                {
                  "name": "Крупный бизнес — до 30 млрд рублей",
                  "code": "Крупный бизнес — до 30 млрд рублей"
                },
                {
                  "name": "Крупнейший бизнес — свыше 30 млрд рублей",
                  "code": "Крупнейший бизнес — свыше 30 млрд рублей"
                }
              ]
            },
            {
              "sysName": "questionnaire_note",
              "localName": "Краткое описание",
              "type": "string",
              "maxLength": "150",
              "edited": true,
              "required": true
            },{
              "sysName": "questionnaire_fullNote",
              "localName": "Полное описание",
              "note": "Опишите корпорацию в нескольких предложениях",
              "type": "string",
              "maxLength": "480",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "title": "Логотип",
              "type": "logo",
              "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
              "edited": true,
              "required": false,
              "allowedTypes": [
                ".png"
              ]
            }
          ]
        },
        {
          "module": "Работа со стартапами",
          "page": 4,
          "pageName": "Условия работы со стартапами",
          "fields": [
            {
              "sysName": "project_industry",
              "title": "Направления",
              "description": "Выберите направления, по которым Вы ищете стартапы",
              "localName": "Направления",
              "note": "Выберите направления, по которым Вы ищете стартапы",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                3000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_stady",
              "title": "Стадии развития стартапов",
              "description": "Выберите интересующие стадии развития стартапов",
              "localName": "Стадия развития",
              "note": "Выберите интересующие стадии развития стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                7000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "",
          "page": 4,
          "pageName": "Условия работы со стартапами",
          "title": "Потребности корпорации",
          "subTitle": "Потребность №",
          "withIndex": true,
          "actionText": "Добавить потребность",
          "isArray": "true",
          "fields": [
            {
              "sysName": "questionnairePilots[]_pilotId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_suggestCase",
              "localName": "Описание потребности",
              "note": "Кратко опишите суть Вашего запроса на пилотирование стартапа",
              "type": "string",
              "maxLength": "520",
              "edited": true,
              "required": false
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 5,
          "pageName": "Пилотирование",
          "fields": [
            {
              "sysName": "questionnaire_successPilots",
              "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_startupInvestmentYears",
              "title": "Информация о сотрудничестве со стартапами",
              "localName": "Сколько лет Ваша корпорация работает со стартапами",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_overallPilots",
              "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_lastYearInvestmentsCount",
              "localName": "Количество пилотов со стартапами за последний год",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_overallContracts",
              "localName": "Количество контрактов (внедрений) со стартапами за последний год",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиции",
          "page": 6,
          "pageName": "Инвестиции",
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Инвестирует ли Ваша корпорация в стартапы?",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            },
            {
              "sysName": "investment_industry",
              "title": "Направления",
              "description": "Выберите интересные для Вас направления инвестирования",
              "localName": "Направления",
              "note": "Выберите интересные для Вас направления инвестирования",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                3000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд инвестиций",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "project_geography",
              "localName": "География стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                2000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 6,
          "pageName": "Инвестиции",
          "triggerField": "investment_investment",
          "triggerValue": true,
          "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
          "isArray": true,
          "subTitle": "Стартап №",
          "withIndex": true,
          "actionText": "Добавить кейс",
          "fields": [
            {
              "sysName": "successPilots[]_pilotid",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "successPilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "maxLength": "140",
              "edited": true,
              "required": false,
              "showLength": false
            },
            {
              "sysName": "successPilots[]_suggestCase",
              "localName": "Описание кейса",
              "type": "string",
              "maxLength": "300",
              "edited": true,
              "required": false,
              "showLength": false
            }
          ]
        },
        {
          "module": "Скаутинг",
          "page": 7,
          "pageName": "Скаутинг",
          "moduleNote": "Подбор технологических решений стартапов под запрос заказчика",
          "fields": [
            {
              "sysName": "questionnaire_scouting",
              "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            }
          ]
        }
      ]
    }'::json::json where formname='New_Corporate';



