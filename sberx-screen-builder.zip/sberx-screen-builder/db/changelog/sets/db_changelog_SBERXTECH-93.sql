--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-93
update screen set formview = '{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_investorType",
      "localName": "Тип инвестора",
      "type": "array",
      "format": "text",
      "activity": [
        11000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_fullName",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_site",
      "localName": "Сайт (Доступно по подписке)",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur": true
    },{
        "sysName": "questionnaire_email",
        "localName": "Email (Доступно по подписке)",
        "type": "string",
        "edited": false,
        "required": false,
        "isBlur": true
      }
    ]
  }, {
    "module": "Инвестиции (Доступно по подписке)",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Направление инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false,
      "isBlur": true
    },{
      "sysName": "project_geography",
      "localName": "География стартапов",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false,
      "isBlur": true
    },{
      "sysName": "investment_round",
      "localName": "Стадии инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false,
      "isBlur": true
    },{
      "sysName": "investment_note",
      "localName": "Особые условия инвестирования",
      "type": "string",
      "edited": false,
      "required": false,
      "isBlur": true
    },{
      "sysName": "questionnaire_allDealsNumber",
      "localName": "Количество стартапов, в которые инвестировал фонд",
      "type": "int",
      "edited": false,
      "required": false,
      "isBlur": true
    },{
      "sysName": "questionnaire_exitDealsNumber",
      "localName": "Количество выходов",
      "type": "int",
      "edited": false,
      "required": false,
      "isBlur": true
    }
    ]
  },{
    "module": "Портфель",
    "page": 1,
    "isArray": true,
    "fields": [{
      "sysName": "pilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "pilots[]_company",
      "localName": "Название стартапа",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}' where formname = 'investor_Client';

update screen set formview = '{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_investorType",
      "localName": "Тип инвестора",
      "type": "array",
      "format": "text",
      "activity": [
        11000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_fullName",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_site",
      "localName": "Сайт",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_email",
      "localName": "Email",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Направление инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География стартапов",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_round",
      "localName": "Стадии инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_note",
      "localName": "Особые условия инвестирования",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_allDealsNumber",
      "localName": "Количество стартапов, в которые инвестировал фонд",
      "type": "int",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_exitDealsNumber",
      "localName": "Количество выходов",
      "type": "int",
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "Портфель",
    "page": 1,
    "isArray": true,
    "fields": [{
      "sysName": "questionnairePilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_company",
      "localName": "Название стартапа",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}
' where formname = 'investor_SuperClient';