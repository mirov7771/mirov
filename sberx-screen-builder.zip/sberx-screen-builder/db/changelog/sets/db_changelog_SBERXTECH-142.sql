--liquibase formatted sql
--changeset Rakhimova NV:SBERXTECH-142
UPDATE screen
SET formedit='{
          "form": [
            {
              "module": "Основная информация",
              "moduleNote": "",
              "page": 1,
              "fields": [
                {
                  "sysName": "name",
                  "localName": "Заголовок",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "140",
                  "showLength": false
                },
                {
                  "sysName": "businessUnit",
                  "localName": "Подразделение",
                  "note": "Потребность какого подразделения компании вы хотите закрыть?",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "200",
                  "showLength": false
                },
                {
                  "sysName": "suggestCase",
                  "localName": "Краткое описание запроса",
                  "type": "string",
                  "note": "Какую потребность стартапы будут решать в рамках пилота?",
                  "edited": true,
                  "required": true,
                  "maxLength": "300"
                },
                {
                  "sysName": "conditions",
                  "localName": "Условия пилотирования",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "300"
                },
                {
                  "sysName": "industry",
                  "localName": "Добавьте тематику или направление",
                  "note": "Например «Страхование» или «Usability Testing»",
                  "type": "array",
                  "format": "serch_dropdown",
                  "activity": [
                    3000
                  ],
                  "edited": true,
                  "required": false,
                  "multySelect": true
                },
                {
                  "sysName": "file",
                  "localName": "Разрешить загрузку файлов",
                  "note": "Стартапы смогут загружать презентации под вашу бизнес-потребность",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "isHub",
                  "localName": "Разрешить загрузку файлов",
                  "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                  "type": "boolean",
                  "format": "hide",
                  "edited": true,
                  "value": "true",
                  "required": false
                },
                {
                  "sysName": "state",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "value": "20002",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Разрешить загрузку файлов",
                  "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                  "type": "string",
                  "format": "hide",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "",
              "moduleNote": "",
              "isArray": true,
              "actionText": "Добавить вопрос",
              "page": 1,
              "fields": [
                {
                  "sysName": "response[]_responseId",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "edited": "true",
                  "required": "false"
                },
                {
                  "sysName": "response[]_pilotId",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "response[]_question",
                  "localName": "Текст вопроса",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "maxLength": "100"
                },
                {
                  "sysName": "response[]_questionDescription",
                  "localName": "Описание",
                  "note": "Дополнительная информация, уточнение вопроса",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "maxLength": "100"
                }
              ]
            }
          ]
        }'
WHERE "type" = 4 AND formname='New_Pilot';