--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4733
delete from pages where uri = '/import-substitution';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_ru', 'SberUnity Ипортозамещение', '/import-substitution', 'Импортозамещение',  'auth',
        '{
            "features": [
                {
                    "type": "participantSearch",
                    "sysName": "startups_ru_participantSearch",
                    "visible": true,
                    "title": "Импортозамещающие решения",
                    "header": "Импортозамещение",
                    "position": 3,
                    "placeholder": "Поиск сервисов-аналогов",
                    "participant": "startup",
                    "shownFromTitle": "Показано {0} из {1}",
                    "foundsTitle": "Найдено: {0}",
                    "sortLabels": {
                        "alphabetically": "По алфавиту",
                        "byUpdateDate": "По дате обновления",
                        "byCreationDate": "По дате создания"
                    },
                    "fastFilterLabels": {
                        "favoriteLabel": "Избранные",
                        "viewedLabel": "Просмотренное",
                        "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
                    }
                }
            ]
        }', 1);

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_en', 'SberUnity Import substitution', '/import-substitution', 'Import substitution', 'auth',
        '{
            "features": [
                {
                    "type": "participantSearch",
                    "sysName": "startups_ru_participantSearch",
                    "visible": true,
                    "title": "Import-substituting solutions",
                    "header": "Import substitution",
                    "position": 3,
                    "placeholder": "Search for analog services",
                    "participant": "startup",
                    "shownFromTitle": "Shown {0} из {1}",
                    "foundsTitle": "Find: {0}",
                    "sortLabels": {
                        "alphabetically": "Alphabetically",
                        "byUpdateDate": "By creation date",
                        "byCreationDate": "By date modified"
                    },
                    "fastFilterLabels": {
                        "favoriteLabel": "Favorite",
                        "viewedLabel": "Viewed",
                        "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
                    }
                }
            ]
        }', 2);