--liquibase formatted sql
--changeset MirovAA:remove_clientid
delete from public.schemas where clientid != '8385';
delete from public.screen where clientid != '8385';
delete from public.client_menu where clientid != '8385';

alter table public.schemas drop column if exists clientid;
alter table public.screen drop column if exists clientid;
alter table public.client_menu drop column if exists clientid;