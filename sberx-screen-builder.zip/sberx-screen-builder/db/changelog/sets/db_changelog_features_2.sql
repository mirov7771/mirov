--liquibase formatted sql
--changeset Mirov AA:features_table_2
ALTER TABLE public.feature ALTER COLUMN config TYPE text USING config::text;
