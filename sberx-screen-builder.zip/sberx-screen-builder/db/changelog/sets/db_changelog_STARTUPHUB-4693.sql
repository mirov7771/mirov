--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-4693

delete from public.pages p where code = 'settings_ru';

insert into public.pages (code, name, uri, description, page_type, page, lang_id) values
    ('settings_ru',
     'SberUnity Настройки',
     '/settings',
     'Страница настроек профиля',
     'unauth',
     '{
        "data":{
           "features":[
              {
                 "type":"backButton",
                 "label":"Назад",
                 "config":{
                    "nowrap":true,
                    "styles":{
                       "padding":{
                          "md":{
                             "top":32,
                             "bottom":24
                          },
                          "lg":{
                             "top":32,
                             "bottom":24
                          }
                       }
                    }
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Настройки",
                 "config":{
                    "nowrap":true,
                    "styles":{
                       "padding":{
                          "md":{
                             "bottom":24
                          },
                          "lg":{
                             "bottom":24
                          }
                       }
                    }
                 }
              },
              {
                 "type":"tabs",
                 "items":[
                    {
                       "label":"Пользователи",
                       "url":"/main/settings/users",
                       "default":true
                    }
                 ],
                 "config":{
                    "nowrap":true
                 }
              },
              {
                 "type":"settings",
                 "header":"Пользователи",
                 "subheader":"Вы можете добавить дополнительно двух пользователей к профилю вашей компании",
                 "mainUserLabel":"Основной пользователь",
                 "acceptedInvitationLabel":"Принял приглашение",
                 "validityLabel":"Приглашение действительно до",
                 "addUserLabel":"Добавить пользователя",
                 "addLabel":"Добавить",
                 "config":{
                    "nowrap":true
                 }
              }
           ],
           "mock":[

           ],
           "meta":[

           ]
        }
     }',
     1);