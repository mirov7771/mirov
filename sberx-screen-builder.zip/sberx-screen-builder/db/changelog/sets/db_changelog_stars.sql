--liquibase formatted sql
--changeset Mirov AA:stars
update public.screen
set formedit = cast(replace(cast(formedit as text), '*"', '"') as json)
where cast(formedit as text) like '%*"%';