--liquibase formatted sql
--changeset Mirov AA:sidebar_logo
update client_menu cm set logofile = 'icSidebarCorp' where menutype = 'sidebar' and name = 'Корпорации';
update client_menu cm set logofile = 'icSidebarPilot' where menutype = 'sidebar' and name = 'Запросы корпораций';
update client_menu cm set logofile = 'icSidebarPilot' where menutype = 'sidebar' and name = 'Мои запросы';
update client_menu cm set logofile = 'icSidebarInvestment' where menutype = 'sidebar' and name = 'Инвестиции';
update client_menu cm set logofile = 'icSidebarInvestor' where menutype = 'sidebar' and name = 'Инвесторы';
