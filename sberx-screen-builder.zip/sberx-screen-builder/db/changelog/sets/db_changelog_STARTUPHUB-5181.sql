--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-5181

update public.screen set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "mask": "$",
                    "note": "Сумма, в которую вы оцениваете ваш пилотный запуск",
                    "type": "string",
                    "edited": true,
                    "example": "$",
                    "sysName": "reply_cost",
                    "required": false,
                    "localName": "Какова стоимость вашего решения",
                    "maxLength": "30"
                },
                {
                    "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Комментарий",
                    "sysName": "reply_process",
                    "required": true,
                    "localName": "Как вы видите процесс пилотирования",
                    "maxLength": "500"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите подробно ваш оффер по данному пилоту",
                    "sysName": "reply_note",
                    "required": true,
                    "localName": "Сопроводительное письмо",
                    "maxLength": "500"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "hide",
                    "sysName": "pilotId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": "Pilot",
                    "edited": true,
                    "format": "hide",
                    "sysName": "reply_tableName",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": "0",
                    "edited": true,
                    "format": "hide",
                    "sysName": "reply_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": "Вес файла — не более 5 МБ, формата PDF",
                    "type": "hyperlink",
                    "edited": true,
                    "format": "URL",
                    "sysName": "reply_fileURL",
                    "required": false,
                    "localName": "Презентация",
					"title": "Презентация",
                    "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
                    "maxLength": "5",
                    "allowedTypes": [
                        ".pdf"
                    ]
                }
            ],
            "module": "Заявка на пилотирование",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "format": "question",
                    "example": "Ваш вопрос",
                    "sysName": "response",
                    "required": false
                }
            ],
            "module": "Вопросы корпорации",
            "isArray": "true",
            "moduleType": "question"
        }
    ]
}' where formname = 'pilot_Client_Extra' and type = 4 and lang_id = 1;

update public.screen set formedit = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "note":"The amount you value your pilot run",
               "type":"string",
               "edited":true,
               "example":"$",
               "sysName":"reply_cost",
               "required":false,
               "localName":"What is the cost of your solution",
               "maxLength":"30"
            },
            {
               "note":"Deadlines, steps, special conditions, restrictions, etc.",
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Comments",
               "sysName":"reply_process",
               "required":true,
               "localName":"How do you see the piloting process",
               "maxLength":"500"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Describe in detail your offer for this pilot",
               "sysName":"reply_note",
               "required":true,
               "localName":"Transmittal letter",
               "maxLength":"500"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"hide",
               "sysName":"pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":"Pilot",
               "edited":true,
               "format":"hide",
               "sysName":"reply_tableName",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":"0",
               "edited":true,
               "format":"hide",
               "sysName":"reply_state",
               "required":false,
               "localName":""
            },
            {
               "note":"File weight - no more than 5 MB, PDF format",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
			   "title":"Presentation",
               "description":"Increases the chances of attracting investors and corporations, but not required",
               "maxLength":"5",
               "allowedTypes":[
                  ".pdf"
               ]
            }
         ],
         "module":"Application for piloting",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"question",
               "example":"Your question",
               "sysName":"response",
               "required":false
            }
         ],
         "module":"Corporation questions",
         "isArray":"true",
         "moduleType":"question"
      }
   ]
}' where formname = 'pilot_Client_Extra' and type = 4 and lang_id = 2;