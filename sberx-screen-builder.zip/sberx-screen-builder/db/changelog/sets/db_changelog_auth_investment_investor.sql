--liquibase formatted sql
--changeset Mirov AA:auth_investment_investor
delete from pages where code = 'auth-investment-investor-ru';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values('auth-investment-investor-ru', 'Инвестии | SberUnity', '/auth-investment-investor', 'SberUnity', 'auth', '{
   "features":[
      {
         "position": 1,
         "type":"investorInvestment",
         "sysName":"investorInvestment",
         "visible":true,
         "fastFilterLabel":"Избранные",
         "noDataBannerTitle":"Пока нет раундов для инвестиций",
         "foundsTitle":"Найдено: {0}",
         "roundCardAmountLabel":"Требуемая сумма",
         "placeholderTextField":"Поиск по наименованию стартапа",
         "buttons":[
            {
               "label":"Уже в раунде",
               "value":0
            },
            {
               "label":"Планируются",
               "value":1
            }
         ]
      }
   ]
}', 1);
