--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4394
select setval('public.schemas_id_seq', (SELECT max(id) + 1 FROM public.schemas));
insert into schemas (name, value)
values ('offer_search_corp', '{
  "value": {
    "clickable": true,
    "columns": [
      {
        "sysName": "pilot",
        "type": "string",
        "title": "Название запроса",
        "key": "offerName"
      },
      {
        "sysName": "startup",
        "type": "string",
        "title": "Стартап",
        "key": "questionnaireName"
      },
      {
        "sysName": "view_date",
        "type": "date",
        "title": "Дата и время предложения",
        "key": "date"
      },
      {
        "sysName": "status",
        "type": "nameplate",
        "title": "Статус",
        "key": "state",
        "refs": {
          "map": {
            "20002": "В работе",
            "20003": "Пауза",
            "20004": "Пилотируется",
            "20007": "Завершен",
            "20009": "Отказ",
            "20011": "Новый",
            "20013": "Отозван"
          }
        }
      }
    ]
  }
}');