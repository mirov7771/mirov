--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-85

update client_menu set
    action = '/menu?type=1&name=pilots_corporate&id='
where menutype = 'sidebar'
  and type = 1
  and sysname = 'pilots';