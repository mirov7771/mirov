--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2573
update public.screen set
    formview = '{
      "form": [
        {
          "module": "Основная информация",
          "page": 1,
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Название",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_acceleratorCode",
              "localName": "Является выпускником:",
              "type": "array",
              "format": "text",
              "activity": [
                26000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год основания",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_interactionType",
              "localName": "Тип взаимодействия с пользователем",
              "type": "array",
              "format": "text",
              "activity": [
                8000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_businessModel",
              "localName": "Бизнес-модели",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                24000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_industry",
              "localName": "Индустрия проекта",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_note",
              "localName": "Краткое описание проекта",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_problem",
              "localName": "Проблема, которую решает проект",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_auditory",
              "localName": "Целевая аудитория",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Дополнительные контакты (Доступно по подписке)",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "contacts[]_name",
              "localName": "Ссылка",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "О проекте (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_mvpCode",
              "localName": "Стадия развития продукта",
              "type": "array",
              "format": "text",
              "activity": [
                27000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_demoSite",
              "localName": "Ссылка на демо",
              "type": "hyperlink",
              "triggerField": "project_haveMVP",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_demoVideo",
              "localName": "Видео о продукте",
              "type": "hyperlink",
              "triggerField": "project_haveMVP",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_businessPlan",
              "localName": "Презентация (Доступно по подписке)",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_pitchVideo",
              "localName": "Видео питча",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_geography",
              "localName": "Рынки, на которых работает стартап",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_expansion",
              "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_sales",
              "localName": "Продажи",
              "type": "array",
              "format": "text",
              "activity": [
                5000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_turnover",
              "localName": "Оборот",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Конкуренты (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_competitor",
              "localName": "Прямые конкуренты",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_indirectCompetitor",
              "localName": "Косвенные конкуренты",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_upSide",
              "localName": "Преимущества перед конкурентами",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_downSide",
              "localName": "Недостатки перед конкурентами ",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Команда (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "questionnaire_locationCountry",
              "localName": "Страна, где находится команда",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "questionnaire_location",
              "localName": "Город, где находится команда",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_staff",
              "localName": "Количество сотрудников",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_hiringStaff",
              "localName": "Из них наемных сотрудников",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "",
          "page": 1,
          "isArray": "true",
          "fields": [
            {
              "sysName": "worker_parentId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "worker_isFounder",
              "localName": "",
              "type": "boolean",
              "format": "hide",
              "value": false,
              "edited": false,
              "required": false
            },
            {
              "sysName": "worker_role",
              "localName": "Ключевые члены команды",
              "type": "string",
              "edited": false,
              "required": false,
              "direction": "concatenation",
              "isBlur": true
            },
            {
              "sysName": "workers[]_note",
              "localName": "Опыт",
              "type": "string",
              "maxLength": "150",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы (Доступно по подписке)",
          "moduleNote": "",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "b2bPilots[]_state",
              "localName": "",
              "type": "array",
              "format": "hide",
              "value": "20007",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2bPilots[]_reference",
              "localName": "С кем был успешный кейс",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2bPilots[]_suggestCase",
              "localName": "Описание и результаты кейса",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Успешные B2C-, C2C- кейсы (Доступно по подписке)",
          "moduleNote": "",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "b2cPilots[]_state",
              "localName": "",
              "type": "array",
              "format": "hide",
              "value": "20007",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2cPilots[]_reference",
              "localName": "С кем был успешный кейс",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2cPilots[]_suggestCase",
              "localName": "Описание и результаты кейса",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Инвестиции (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Привлекаете ли вы инвестиции?",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_sumInvestment",
              "localName": "Требуемая сумма",
              "type": "int",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_lastInvestment",
              "localName": "Объем ранее привлеченных инвестиций, всего",
              "type": "string",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_coInvestment",
              "localName": "Имя/ имена инвестора/ инвесторов",
              "type": "string",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Дополнительная информация (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_addNote",
              "localName": "Что еще важно знать о проекте?",
              "type": "string",
              "maxLength": "500",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        }
      ]
    }'
where formname in ('startup_Client');