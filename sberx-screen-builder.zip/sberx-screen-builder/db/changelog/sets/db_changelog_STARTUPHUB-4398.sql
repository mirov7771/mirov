--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4398
select setval('public.schemas_id_seq', (SELECT max(id) + 1 FROM public.schemas));
insert into schemas (name, value)
values ('offer_search_startup', '{
  "value": {
    "clickable": true,
    "columns": [
      {
        "sysName": "company",
        "type": "img",
        "title": "Корпорация",
        "key": "questionnaire.logoFile",
        "refs": {
          "labelKey": "questionnaire.name"
        }
      },
      {
        "sysName": "pilot",
        "type": "string",
        "title": "Название запроса",
        "key": "offerName"
      },
      {
        "sysName": "view_date",
        "type": "date",
        "title": "Дата и время предложения",
        "key": "date"
      },
      {
        "sysName": "status",
        "type": "nameplate",
        "title": "Статус",
        "key": "state",
        "refs": {
          "map": {
            "20002": "В работе",
            "20003": "Пауза",
            "20004": "Пилотируется",
            "20007": "Завершен",
            "20009": "Отказ",
            "20011": "Новый",
            "20013": "Отозван"
          }
        }
      }
    ]
  }
}');