--liquibase formatted sql
--changeset Timofeev V:SBERXTECH-68 Создать пилот. Изменить названия кнопок "Убрать", "Добавить" SBERXTECH-66 Редактировать пилот. При редактировании пилота нет полей "Текст вопроса" и "Описание"

update screen set
    formedit =
        '{
          "form": [
            {
              "module": "Основная информация",
              "moduleNote": "",
              "page": 1,
              "fields": [
                {
                  "sysName": "name",
                  "localName": "Заголовок",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "140",
                  "showLength": false
                },
                {
                  "sysName": "businessUnit",
                  "localName": "Подразделение",
                  "note": "Потребность какого подразделения компании вы хотите закрыть?",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "200",
                  "showLength": false
                },
                {
                  "sysName": "suggestCase",
                  "localName": "Краткое описание запроса",
                  "type": "string",
                  "note": "Какую потребность стартапы будут решать в рамках пилота?",
                  "edited": true,
                  "required": true,
                  "maxLength": "300"
                },
                {
                  "sysName": "conditions",
                  "localName": "Условия пилотирования",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "300"
                },
                {
                  "sysName": "industry",
                  "localName": "Добавьте тематику или направление",
                  "note": "Например «Страхование» или «Usability Testing»",
                  "type": "array",
                  "format": "serch_dropdown",
                  "activity": [
                    3000
                  ],
                  "edited": true,
                  "required": false,
                  "multySelect": true
                },
                {
                  "sysName": "file",
                  "localName": "Разрешить загрузку файлов",
                  "note": "Стартапы смогут загружать презентации под вашу бизнес-потребность",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "isHub",
                  "localName": "Разрешить загрузку файлов",
                  "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                  "type": "boolean",
                  "format": "hide",
                  "edited": true,
                  "value": "true",
                  "required": false
                },
                {
                  "sysName": "state",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "value": "20002",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Разрешить загрузку файлов",
                  "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                  "type": "string",
                  "format": "hide",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "",
              "moduleNote": "",
              "isArray": true,
              "actionText": "Добавить вопрос",
              "page": 1,
              "fields": [
                {
                  "sysName": "response[]_responseId",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "edited": "true",
                  "required": "false"
                },
                {
                  "sysName": "response[]_pilotId",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "response[]_question",
                  "localName": "Текст вопроса",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "100"
                },
                {
                  "sysName": "response[]_questionDescription",
                  "localName": "Описание",
                  "note": "Дополнительная информация, уточнение вопроса",
                  "type": "string",
                  "edited": true,
                  "required": true,
                  "maxLength": "100"
                }
              ]
            }
          ]
        }'
where "type" = 4 and formname = 'New_Pilot';

update screen set
    formedit =
        ' {"form": [
          {
            "module": "Основная информация",
            "moduleNote": "",
            "page": 1,
            "fields": [
              {
                "sysName": "pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": true
              },{
                "sysName": "name",
                "localName": "Заголовок",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "140",
                "showLength": false
              },
              {
                "sysName": "businessUnit",
                "localName": "Подразделение",
                "note": "Потребность какого подразделения компании вы хотите закрыть?",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "200",
                "showLength": false
              },
              {
                "sysName": "suggestCase",
                "localName": "Краткое описание запроса",
                "type": "string",
                "note": "Какую потребность стартапы будут решать в рамках пилота?",
                "edited": true,
                "required": true,
                "maxLength": "300"
              },
              {
                "sysName": "conditions",
                "localName": "Условия пилотирования",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "300"
              },
              {
                "sysName": "industry",
                "localName": "Добавьте тематику или направление",
                "type": "array",
                "format": "serch_dropdown",
                "activity": [
                  3000
                ],
                "edited": true,
                "required": false,
                "multySelect": true
              },
              {
                "sysName": "file",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "switch",
                "edited": true,
                "required": true
              },
              {
                "sysName": "isHub",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "edited": true,
                "value": "true",
                "required": false
              },
              {
                "sysName": "state",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "string",
                "format": "hide",
                "edited": true,
                "value": "20004",
                "required": false
              }
            ]
          },
          {
            "module": "",
            "moduleNote": "",
            "actionText": "Добавить вопрос",
            "isArray": true,
            "page": 1,
            "fields": [
              {
                "sysName": "response[]_responseId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": "true",
                "required": "false"
              },
              {
                "sysName": "response[]_pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": false
              },
              {
                "sysName": "response[]_question",
                "localName": "Текст вопроса",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "100"
              },
              {
                "sysName": "response[]_questionDescription",
                "localName": "Описание",
                "note": "Дополнительная информация, уточнение вопроса",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "100"
              }
            ]
          }
        ]
        }'
where "type" = 4 and formname = 'pilot_edit';