--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-3127 Добавляю FT для онбординга

INSERT INTO public.feature (form_name,name,visible,"type",config) VALUES
  ('onboarding',NULL,true,'toggle','');
