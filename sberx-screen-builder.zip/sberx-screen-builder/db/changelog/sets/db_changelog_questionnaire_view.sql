--liquibase formatted sql
--changeset Mirov AA:questionnaire-view
delete from public.pages where code = 'questionnaire_view_az_ru';
insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('questionnaire_view_az_ru', 'SberUnity', '/questionnaire-view', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "questionnaireView",
            "sysName": "",
            "visible": true,
            "position": 1,
            "backButtonTitle": "назад",
            "adminCommentTitles": {
                "title": "Необходима дополнительная информация",
                "additionalInfo": "Комментарий администратора:"
            }
        }
    ]
}', 1);