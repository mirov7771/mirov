--liquibase formatted sql
--changeset Mirov AA:app_short_new
update public.screen
set formview  = '{
  "form": [
    {
      "module": "Информация по заявке",
      "page": 1,
      "pageName": "orgFullName",
      "fields": [
        {
          "sysName": "firstName",
          "localName": "Имя",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "phone",
          "localName": "Телефон",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "position",
          "localName": "Должность",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "email",
          "localName": "Корпоративный email",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'
where formname = 'corp_app_Administrator';

update public.screen
set formview  = '{
  "form": [
    {
      "module": "Информация по заявке",
      "page": 1,
      "pageName": "investorType+orgFullName",
      "fields": [
        {
          "sysName": "firstName",
          "localName": "Имя",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "phone",
          "localName": "Телефон",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "position",
          "localName": "Должность",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "email",
          "localName": "Корпоративный email",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'
where formname = 'invest_app_Administrator'