--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4360_3

update public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_ru_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Регистрация",
            "titleInfoForm": "Отправили пароль вам на почту",
            "textDescription": "Мы отправили на вашу электронную почту {email} временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_infoForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_ru_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Есть аккаунт? ",
                    "linkText": "Войти",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Регистрация",
            "emailField": {
                "label": "Корпоративный email",
                "errorCorporationEmail": "Введите почту на корпоративном домене",
                "helperText": "Он не будет доступен в публичной анкете. Контактный email вы сможете указать на следующем шаге"
            },
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_lregistrationForm_button",
                "text": "Получить пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/registration'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_en_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Registration",
            "titleInfoForm": "A temporary password was send to your email",
            "textDescription": "We have sent a new temporary password to your email **{email}**. After using it to login, you''ll have to set your own one.",
            "text": "If the email has not arrived, look for it in the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_en_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_en_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Already have an account? ",
                    "linkText": "Log in",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Registration",
            "emailField": {
                "label": "Email",
                "errorCorporationEmail": "Enter corporate e-mail",
                "helperText": "It will not be available in the public profile. You can specify the contact email address in the next step"
            },
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_en_lregistrationForm_button",
                "text": "Get a password",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/registration'
  and lang_id = 2;


update public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_ru_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Регистрация",
            "titleInfoForm": "Отправили пароль вам на почту",
            "textDescription": "Мы отправили на вашу электронную почту {email} временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_infoForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_ru_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Есть аккаунт? ",
                    "linkText": "Войти",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Регистрация",
            "emailField": {
                "label": "Корпоративный email",
                "errorCorporationEmail": "Введите почту на корпоративном домене",
                "helperText": "Он не будет доступен в публичной анкете. Контактный email вы сможете указать на следующем шаге"
            },
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_lregistrationForm_button",
                "text": "Получить пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/registration'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_ru_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Регистрация",
            "titleInfoForm": "Отправили пароль вам на почту",
            "textDescription": "Мы отправили на вашу электронную почту **{email}** временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_infoForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_ru_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Есть аккаунт? ",
                    "linkText": "Войти",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Регистрация",
            "emailField": {
                "label": "Корпоративный email",
                "errorCorporationEmail": "Введите почту на корпоративном домене",
                "helperText": "Он не будет доступен в публичной анкете. Контактный email вы сможете указать на следующем шаге"
            },
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_lregistrationForm_button",
                "text": "Получить пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/registration'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "recovery_en_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Password Recovery",
            "titleInfoForm": "We have sent a password to your email",
            "textDescription": "We have sent a new temporary password to your email **{email}**. After using it to login, you''ll have to set your own one.",
            "text": "If the email has not arrived, look for it in the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "rrecovery_en_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "recoveryForm",
            "sysName": "recovery_en_recoveryForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Password Recovery",
            "descriptionForm": "To recover your password, enter the email address you provided during registration",
            "subText": "SberUnity Support:",
            "subTextLink": "sberunity@sberbank.ru",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_en_recoveryForm_button",
                "text": "Get a password",
                "theme": "purple-gradient",
                "url": "/restore-password",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/recovery'
  and lang_id = 2;

update public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "recovery_ru_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Восстановление пароля",
            "titleInfoForm": "Отправили пароль Вам на почту",
            "textDescription": "Мы отправили на Вашу электронную почту **{email}** временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_ru_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "recoveryForm",
            "sysName": "recovery_ru_recoveryForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Восстановление пароля",
            "descriptionForm": "Чтобы восстановить пароль, введите адрес электронной почты, указанный при регистрации",
            "subText": "Поддержка SberUnity:",
            "subTextLink": "sberunity@sberbank.ru",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_ru_recoveryForm_button",
                "text": "Получить пароль",
                "theme": "purple-gradient",
                "url": "/restore-password",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/recovery'
  and lang_id = 1;