--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-5096 Новые JSON для заявок в неавторизованной зоне

delete from public.screen where formname in ('New_Corporate_Short','New_Investor_Short','New_Investor_Short_Angel');

INSERT INTO public.screen ("type",formname,formedit,formview,name,description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (1,'New_Corporate_Short','{
    "form": [
        {
            "module": "Личная информация",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "representative_firstName",
                    "localName": "Имя",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "representative_lastName",
                    "localName": "Фамилия",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                },
                {
                    "sysName": "representative_phone",
                    "localName": "Номер телефона",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "representative_position",
                    "localName": "Должность",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Информация о компании",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Название",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Адрес сайта",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Корпоративный email",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "note": "В случае использования личного email может потребоваться подтверждение у администратора платформы",
                    "required": true
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "hide",
                    "sysName": "tariff",
                    "required": true
                }
            ]
        }
    ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,name,description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (1,'New_Investor_Short','{
    "form": [
        {
            "module": "Investor Type",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_investorType",
                    "localName": "",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        11000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Personal information",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "representative_firstName",
                    "localName": "First Name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "representative_lastName",
                    "localName": "Last Name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                },
                {
                    "sysName": "representative_phone",
                    "localName": "Phone number",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "representative_position",
                    "localName": "Job title",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Company Information",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Company name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Website",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Enter corporate e-mail",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "note": "If you use a personal email, you may need confirmation from the platform administrator",
                    "required": true
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "I confirm that I have read the <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms without restrictions.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "hide",
                    "sysName": "tariff",
                    "required": true
                }
            ]
        }
    ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,2,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,name,description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (1,'New_Investor_Short_Angel','{
    "form": [
        {
            "module": "Investor Type",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_investorType",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "activity": [
                        11000
                    ],
                    "value": "11002",
                    "multySelect": false,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Personal information",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "representative_firstName",
                    "localName": "First Name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "representative_lastName",
                    "localName": "Last Name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                },
                {
                    "sysName": "representative_phone",
                    "localName": "Phone number",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "representative_position",
                    "localName": "Job title",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Company Information",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Company name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Website",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Enter corporate e-mail",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "note": "If you use a personal email, you may need confirmation from the platform administrator",
                    "required": true
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "I confirm that I have read the <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms without restrictions.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "hide",
                    "sysName": "tariff",
                    "required": true
                }
            ]
        }
    ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,2,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,name,description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (1,'New_Investor_Short','{
    "form": [
        {
            "module": "Тип инвестора",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_investorType",
                    "localName": "",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        11000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Личная информация",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "representative_firstName",
                    "localName": "Имя",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "representative_lastName",
                    "localName": "Фамилия",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                },
                {
                    "sysName": "representative_phone",
                    "localName": "Номер телефона",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "representative_position",
                    "localName": "Должность",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Информация о компании",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Название",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Адрес сайта",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Корпоративный email",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "note": "В случае использования личного email может потребоваться подтверждение у администратора платформы",
                    "required": true
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "hide",
                    "sysName": "tariff",
                    "required": true
                }
            ]
        }
    ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,name,description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (1,'New_Investor_Short_Angel','{
    "form": [
        {
            "module": "Тип инвестора",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_investorType",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "activity": [
                        11000
                    ],
                    "value": "11002",
                    "multySelect": false,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Личная информация",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "representative_firstName",
                    "localName": "Имя",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "representative_lastName",
                    "localName": "Фамилия",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                },
                {
                    "sysName": "representative_phone",
                    "localName": "Номер телефона",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "representative_position",
                    "localName": "Должность",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Информация о компании",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Название",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Адрес сайта",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Корпоративный email",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "note": "В случае использования личного email может потребоваться подтверждение у администратора платформы",
                    "required": true
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "hide",
                    "sysName": "tariff",
                    "required": true
                }
            ]
        }
    ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,name,description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (1,'New_Corporate_Short','{
    "form": [
        {
            "module": "Personal information",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "representative_firstName",
                    "localName": "First Name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "representative_lastName",
                    "localName": "Last Name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                },
                {
                    "sysName": "representative_phone",
                    "localName": "Phone number",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "representative_position",
                    "localName": "Job title",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Company Information",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Company name",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Website",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Enter corporate e-mail",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "note": "If you use a personal email, you may need confirmation from the platform administrator",
                    "required": true
                },
                {
                    "sysName": "userConsent_contract",
                    "localName": "I confirm that I have read the <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms without restrictions.",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": true
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "hide",
                    "sysName": "tariff",
                    "required": true
                }
            ]
        }
    ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,2,NULL);