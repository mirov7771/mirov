--liquibase formatted sql
--changeset Mirov AA:import_filter
update public.pages
set page = '{
           "features":[
              {
                 "config":{

                 },
                 "type":"participantSearch",
                 "foundsTitle":"Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
                 "header":"Импортозамещение",
                 "participant":"startup",
                 "placeholder":"Поиск сервисов-аналогов",
                 "position":1,
                 "shownFromTitle":"Показано {0} из {1}", "helperText": "Введите название сервиса, аналог которого хотите найти, или название стартапа",
                 "sortLabels":{
                    "alphabetically":"По алфавиту",
                    "byUpdateDate":"По дате обновления"
                 },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            },
                 "sysName":"startup_ru_participantSearch",
                 "title":"Импортозамещающие решения",
                 "isImport":true,
                 "noContent":{
                    "Startup":{
                       "title":"Добавьте информацию в анкету об импортозамещении",
                       "subtitle":"Чтобы стать заметнее для корпораций на SberUnity, укажите сервисы или компании, которые заменяет ваш продукт. Анкета появится в данном разделе после модерации.",
                       "button":{
                          "text":"Добавить информацию"
                       }
                    },
                    "Corporates":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Скоро здесь будут анкеты стартапов, которые добавили информацию про импортозамещение"
                    },
                    "Investor":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Скоро здесь будут анкеты стартапов, которые добавили информацию про импортозамещение"
                    }
                 },
                 "visible":true
              }
           ]
        }'
where uri = '/import-substitution'
  and lang_id = 1;

update pages
set page = '{
           "features":[
              {
                 "config":{

                 },
                 "type":"participantSearch",
                 "foundsTitle":"Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
                 "header":"Import substitution solution",
                 "participant":"startup",
                 "placeholder":"Find a startup",
                 "position":1,
                 "shownFromTitle":"Shown {0} from {1}",
                 "sortLabels":{
                    "alphabetically":"Alphabetically",
                    "byUpdateDate":"By update date"
                 },
                 "sysName":"startup_ru_participantSearch",
                 "title":"Import substitution solution",
                 "isImport":true,
                 "noContent":{
                    "Startup":{
                       "title":"Add information to the import substitution questionnaire",
                       "subtitle":"To become more visible to corporations on SberUnity, specify the services or companies that your product replaces. The questionnaire will appear in this section after moderation.",
                       "button":{
                          "text":"Add Information"
                       }
                    },
                    "Corporates":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Soon there will be questionnaires of startup that have added information about import substitution"
                    },
                    "Investor":{
                       "img":"/sberx-gateway/file/il_waiting.png",
                       "subtitle":"Soon there will be questionnaires of startup that have added information about import substitution"
                    }
                 },
                 "visible":true
              }
           ]
        }'
where uri = '/import-substitution'
  and lang_id = 2;