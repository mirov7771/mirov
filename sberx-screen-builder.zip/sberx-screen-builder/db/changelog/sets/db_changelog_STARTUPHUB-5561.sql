--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5561
update pages
set page = '{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "startups_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Найти стартап",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "startups_ru_pageTitle",
      "title": "Стартапы, которые уже с нами",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "startups_ru_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Поиск стартапа",
      "participant": "startup",
      "shownFromTitle": " Всего {1} стартапов",
      "foundsTitle": "Найдено: {0} стартапов",
          "filterBar": {
              "title": "Фильтры",
              "acceptButtonText": "Применить фильтры",
              "resetButtonText": "Сбросить фильтры",
              "acceptButtonShortText": "Применить",
              "resetButtonShortText": "Сбросить",
              "placeholder": "поиск"
          },
          "popupFooter": {
              "title": "Зарегистрируйтесь, чтобы получить доступ к полной анкете",
              "caption": "После регистрации будут доступны: полное описание компании, информация о продукте, направления, ключевые сотрудники, успешные пилоты, инвестиции и трекшн стартапа.",
              "mainButtonText": "Зарегистрироваться",
              "secondButtonText": "Войти"
          },
      "features": [
        {
          "type": "authBanner",
          "sysName": "authBanner",
          "visible": true,
          "position": 4,
          "typeBanner": "participantSearch",
          "title": "Больше стартапов",
          "caption": "Доступно после регистрации на платформе SberUnity",
          "mainButtonText": "Присоединиться",
          "secondButtonText": "Войти",
          "config": {
            "nowrap": true
          }
        },
        {
          "type": "authBanner",
          "sysName": "authBanner",
          "visible": true,
          "position": 1,
          "title": "Зарегистрируйтесь и получите доступ к %startups_size_list% на SberUnity",
          "mainButtonText": "Зарегистрироваться",
          "secondButtonText": "Войти",
          "placement": "bottom",
          "config": {
            "nowrap": true
          }
        }
      ]
    }
  ]
}'
where uri = '/startup'
  and code = 'startups_nz_unauth_ru'
  and lang_id = 1
  and page_type = 'unauth';

delete from page_values_cache where name = '%startups_size_list%';
insert into page_values_cache
values('%startups_size_list%', 0, 50, null, 'GET', '/list/questionnaire?type=0')
