--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3096
alter table screen_button add favorite boolean null ;

delete from buttons where code in (100005, 100006);
insert into buttons(code, text)
values(100005, 'Добавить в избранное');
insert into buttons(code, text)
values(100006, 'Удалить из избранного');

insert into screen_button(name,owner_check,favorite,state)
values ('round_Administrator', false, true, 20004);
insert into screen_button(name,owner_check,favorite,state)
values ('round_short_Administrator', false, true, 20004);
insert into screen_button(name,owner_check,favorite,state)
values ('round_Administrator', false, false, 20004);
insert into screen_button(name,owner_check,favorite,state)
values ('round_short_Administrator', false, false, 20004);

insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'round_Administrator' and owner_check = false and favorite = true and state = 20004),
        (select button_id from public.buttons where code = 100006));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'round_Administrator' and owner_check = false and favorite = false and state = 20004),
        (select button_id from public.buttons where code = 100005));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'round_short_Administrator' and owner_check = false and favorite = true and state = 20004),
        (select button_id from public.buttons where code = 100006));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'round_short_Administrator' and owner_check = false and favorite = false and state = 20004),
        (select button_id from public.buttons where code = 100005));