--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4475
update public.pages
set page = cast(replace(cast(page as text), 'инофрмацию', 'информацию') as json)
where cast(page as text) like '% инофрмацию %';

update public.pages
set page = '{
	"features": [
		{
			"type": "welcomeScreen",
			"sysName": "main_en_welcomeScreen",
			"visible": true,
			"position": 1,
			"title": "We unite \nstartups, corporations \nand investors",
			"subtitle": "Venture online hub",
			"imageUrl": "/file/mainImg_ae1aaa00.png",
			"buttons": [
				{
					"url": "/participant-registration",
					"text": "Join",
					"theme": "orange-gradient"
				}
			],
			"cards": [
				{
					"iconUrl": "/file/startup_6df4f39b.svg",
					"title": " %startups_size% ",
					"description": "at growth stage"
				},
				{
					"iconUrl": "/file/corporation_26fda955.svg",
					"title": " %corporations_size% ",
					"description": "in search of technologies"
				},
				{
					"iconUrl": "/file/pilots_d2f8627d.svg",
					"title": " %pilot_size% ",
					"description": "available for startups"
				},
				{
					"iconUrl": "/file/investor_fc1ede14.svg",
					"title": " %investors_size% ",
					"description": "looking for a deal"
				}
			],
			"config": {
				"styles": {
					"backgroundColor": "#F4F7F9",
					"padding": {
						"xs": {
							"top": 24,
							"bottom": 64
						},
						"s": {
							"top": 24,
							"bottom": 64
						},
						"md": {
							"top": 40,
							"bottom": 118
						},
						"lg": {
							"top": 64,
							"bottom": 136
						}
					}
				}
			}
		},
		{
			"type": "participantsTab",
			"sysName": "main_en_participantsTab",
			"visible": true,
			"position": 2,
			"items": [
				{
					"isActive": true,
					"isDefault": true,
					"position": 1,
					"title": "Startups",
					"visible": true,
					"features": [
						{
							"type": "tabContent",
							"sysName": "main_en_startups_tabContent",
							"visible": true,
							"position": 1,
							"title": "Become visible \nin the market",
							"subtitle": {
								"text": "Startups",
								"backgroundColor": "#F4F7F9"
							},
							"description": "Find customers, investments, pilot projects and discounts on business services",
							"caption": "For startups, it''s always free",
							"iconUrl": "/file/opportunity_startup_b705bf2a_eng.png",
							"config": {
								"styles": {
									"padding": {
										"xs": {
											"top": 40,
											"bottom": 64
										},
										"s": {
											"top": 40,
											"bottom": 64
										},
										"md": {
											"top": 48,
											"bottom": 64
										},
										"lg": {
											"top": 64,
											"bottom": 70
										}
									}
								}
							}
						},
						{
							"type": "mainPageCarousel",
							"sysName": "main_en_startups_mainPageCarousel",
							"visible": true,
							"position": 2,
							"title": "**Startup Opportunities**",
							"subtitle": "What is available",
							"items": [
								{
									"title": "Apply for a pilot in 1 click",
									"description": "Get acquainted with the requests of companies for technologies and immediately respond to them",
									"imageUrl": "/file/step1_startup_f9db8e2a.png",
									"position": 1
								},
								{
									"title": "Find an investor",
									"description": "Contact investors and raise venture capital",
									"imageUrl": "/file/step2_startup_4641e0a6.png",
									"position": 2
								},
								{
									"title": "Exclusive offers for business growth",
									"description": "Choose the tools to improve business efficiency from Sber and partners",
									"imageUrl": "/file/step3_startup_f6f24306.png",
									"position": 3
								},
								{
									"title": "All startups on the same platform",
									"description": "Stay up-to-date with market trends and new opportunities",
									"imageUrl": "/file/step4_startup_3c172047.png",
									"position": 4
								},
								{
									"title": "Become part of the Community",
									"description": "Participate in events, subscribe to media projects and get useful content",
									"imageUrl": "/file/step5_startup_62be6884.png",
									"position": 5
								}
							],
							"config": {
								"styles": {
									"backgroundColor": "#F4F7F9",
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 64
										},
										"s": {
											"top": 64,
											"bottom": 64
										},
										"md": {
											"top": 64,
											"bottom": 64
										},
										"lg": {
											"top": 80,
											"bottom": 80
										}
									}
								}
							}
						},
						{
							"type": "startupSteps",
							"sysName": "main_en_startupSteps",
							"visible": true,
							"position": 3,
							"subtitle": {
								"text": "Startup requirements",
								"backgroundColor": "#F4F7F9"
							},
							"title": "Three conditions for registration on the SberUnity platform",
							"items": [
								{
									"id": "1",
									"step": {
										"text": "01",
										"backgroundColor": "#F4F7F9"
									},
									"title": "Technological bias",
									"caption": "Innovative technology is required"
								},
								{
									"id": "2",
									"step": {
										"text": "02",
										"backgroundColor": "#F4F7F9"
									},
									"title": "Registered legal entity or sole proprietor",
									"caption": "Business must be registered legally"
								},
								{
									"id": "3",
									"step": {
										"text": "03",
										"backgroundColor": "#F4F7F9"
									},
									"title": "MVP or later stages of development",
									"caption": "Temporarily we do not add projects on prototype and idea stages"
								}
							],
							"config": {
								"styles": {
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 64
										},
										"s": {
											"top": 64,
											"bottom": 64
										},
										"md": {
											"top": 64,
											"bottom": 64
										},
										"lg": {
											"top": 80,
											"bottom": 80
										}
									}
								}
							}
						},
						{
							"type": "partners",
							"sysName": "main_en_startups_partners",
							"visible": true,
							"position": 6,
							"subtitle": {
								"text": "SberUnity members"
							},
							"title": "Corporations and investors  \nwho already work with us",
							"items": [
								{
									"imageUrl": "/file/sber_0001.png",
									"url": "/view?type=1&name=corporate_preauth&id=1&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/66772b8f-019a-4004-a09e-8908b9a2a47c_Logo blue transparent RGB (2).png",
									"url": "/view?type=1&name=corporate_preauth&id=84&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/30e23502-5257-46d9-b9c8-cf13c0cc65f9_IBM_blue.png",
									"url": "/view?type=1&name=corporate_preauth&id=156&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/60be939e-6c03-487c-959f-5e7b4a92140f_NVLogo_2D_H.png",
									"url": "/view?type=1&name=corporate_preauth&id=87&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/99f3e70e-bf19-4f74-8934-17ff10cf43be_Corp-Logo_BG_Bayer-Cross_Basic_72dpi_on-screen_RGB.png",
									"url": "/view?type=1&name=corporate_preauth&id=93&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/FRV.png",
									"url": "/view?type=2&name=investor_preauth&id=111&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/74d8fcf1-d3ff-4ab0-9c27-883b446acf5e_logo_rgb3 (4).png",
									"url": "/view?type=2&name=investor_preauth&id=91&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/c55e0459-6afb-4ca8-b376-1b30ff115dfa_logo-yrvc.png",
									"url": "/view?type=2&name=investor_preauth&id=77&preauthorize=true&action=1"
								}
							],
							"config": {
								"styles": {
									"backgroundColor": "#F4F7F9",
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 24
										},
										"s": {
											"top": 64,
											"bottom": 24
										},
										"md": {
											"top": 64,
											"bottom": 24
										},
										"lg": {
											"top": 80,
											"bottom": 32
										}
									}
								}
							}
						}
					],
					"description": "Upgrade the project"
				},
				{
					"isActive": true,
					"isDefault": false,
					"position": 2,
					"title": "Corporations",
					"visible": true,
					"features": [
						{
							"type": "tabContent",
							"sysName": "main_en_corporates_tabContent",
							"visible": true,
							"position": 1,
							"title": "Find technologies",
							"subtitle": {
								"text": "Corporations",
								"backgroundColor": "#F4F7F9"
							},
							"description": "Strengthen your business with the help of technological\nsolutions of startups",
							"caption": " %pilots_size% applications for startup pilots collected ",
							"iconUrl": "/file/opportunity_corporation_c0fb87da.png",
							"config": {
								"styles": {
									"padding": {
										"xs": {
											"top": 40,
											"bottom": 64
										},
										"s": {
											"top": 40,
											"bottom": 64
										},
										"md": {
											"top": 48,
											"bottom": 64
										},
										"lg": {
											"top": 64,
											"bottom": 70
										}
									}
								}
							}
						},
						{
							"type": "mainPageCarousel",
							"sysName": "main_en_corporates_mainPageCarousel",
							"visible": true,
							"position": 2,
							"title": "**Opportunities for corporations**",
							"subtitle": "What is available",
							"items": [
								{
									"title": "Get direct access to startups",
									"description": "Regularly updated database and verified questionnaires of all participants",
									"imageUrl": "/file/step1_corporation_daf51708.png",
									"position": 1
								},
								{
									"title": "Formulate your needs",
									"description": "Specify which technology projects you are looking for and collect offers from verified startups",
									"imageUrl": "/file/step2_corporation_1b4a3f1d.png",
									"position": 2
								},
								{
									"title": "Personalized Custom Scouting",
									"description": "A team of professional scouts will form an exclusive startup funnel for your personal request",
									"imageUrl": "/file/step3_corporation_fadf963a.png",
									"position": 3
								},
								{
									"title": "Offer your services to startups",
									"description": "Place your own services and products for startups on preferential terms and get access to fast-growing customers",
									"imageUrl": "/file/step4_corporation_c195c9b0.png",
									"position": 4
								},
								{
									"title": "Organize the selection in your own accelerator",
									"description": "Use SberUnity residents to find relevant solutions for your own acceleration programs",
									"imageUrl": "/file/step5_corporation_d2acde8a.png",
									"position": 5
								},
								{
									"title": "Get access to the Startup and Investor Community",
									"description": "Participate in our events and become part of a dynamically developing Community",
									"imageUrl": "/file/step6_corporation_c7b19fce.png",
									"position": 6
								}
							],
							"config": {
								"styles": {
									"backgroundColor": "#F4F7F9",
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 0
										},
										"s": {
											"top": 64,
											"bottom": 0
										},
										"md": {
											"top": 64,
											"bottom": 0
										},
										"lg": {
											"top": 80,
											"bottom": 0
										}
									}
								}
							}
						},
						{
							"type": "partners",
							"sysName": "main_en_corporates_partners",
							"visible": true,
							"position": 3,
							"subtitle": {
								"text": "SberUnity members"
							},
							"title": "Corporations and investors  \nwho already work with us",
							"items": [
								{
									"imageUrl": "/file/sber_0001.png",
									"url": "/view?type=1&name=corporate_preauth&id=1&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/66772b8f-019a-4004-a09e-8908b9a2a47c_Logo blue transparent RGB (2).png",
									"url": "/view?type=1&name=corporate_preauth&id=84&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/30e23502-5257-46d9-b9c8-cf13c0cc65f9_IBM_blue.png",
									"url": "/view?type=1&name=corporate_preauth&id=156&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/60be939e-6c03-487c-959f-5e7b4a92140f_NVLogo_2D_H.png",
									"url": "/view?type=1&name=corporate_preauth&id=87&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/99f3e70e-bf19-4f74-8934-17ff10cf43be_Corp-Logo_BG_Bayer-Cross_Basic_72dpi_on-screen_RGB.png",
									"url": "/view?type=1&name=corporate_preauth&id=93&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/72a49df2-695a-4c02-85cf-943e0baa945d_VW_logo.png",
									"url": "/view?type=1&name=corporate_preauth&id=158&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/d76005a6-52ad-4002-82c9-dba48230200c_логомагнит.png",
									"url": "/view?type=1&name=corporate_preauth&id=95&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/44491df8-a526-4829-b82b-ff25c3e51f1b_2560px-Kirovsky_Zavod_Logo.png",
									"url": "/view?type=1&name=corporate_preauth&id=160&preauthorize=true&action=1"
								}
							],
							"config": {
								"styles": {
									"backgroundColor": "#F4F7F9",
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 24
										},
										"s": {
											"top": 64,
											"bottom": 24
										},
										"md": {
											"top": 64,
											"bottom": 24
										},
										"lg": {
											"top": 80,
											"bottom": 32
										}
									}
								}
							}
						}
					],
					"description": "Find technologies"
				},
				{
					"isActive": true,
					"isDefault": false,
					"position": 3,
					"title": "Investors",
					"visible": true,
					"features": [
						{
							"type": "tabContent",
							"sysName": "main_en_investors_tabContent",
							"visible": true,
							"position": 1,
							"title": "Find the best deals",
							"subtitle": {
								"text": "Investors",
								"backgroundColor": "#F4F7F9"
							},
							"description": "Be the first to learn about startups that raise investments",
							"caption": " %round_size% investment funding requests have already been placed",
							"iconUrl": "/file/opportunity_investor_34b2207b.png",
							"config": {
								"styles": {
									"padding": {
										"xs": {
											"top": 40,
											"bottom": 64
										},
										"s": {
											"top": 40,
											"bottom": 64
										},
										"md": {
											"top": 48,
											"bottom": 64
										},
										"lg": {
											"top": 64,
											"bottom": 70
										}
									}
								}
							}
						},
						{
							"type": "mainPageCarousel",
							"sysName": "main_en_investors_mainPageCarousel",
							"visible": true,
							"position": 2,
							"title": "**Opportunities for investors**",
							"subtitle": "What is available",
							"items": [
								{
									"title": "Startup database",
									"description": "We publish only verified companies, regularly update data and offer filter search",
									"imageUrl": "/file/step1_investor_f912a124.png",
									"position": 1
								},
								{
									"title": "Open Venture Deals",
									"description": "Find investment rounds, in which you can participate now or in the near future",
									"imageUrl": "/file/step2_investor_37c534dc.png",
									"position": 2
								},
								{
									"title": "Upon your personal request",
									"description": "A team of professional scouts will create an exclusive startup funnel for your personal request",
									"imageUrl": "/file/step3_investor_07c307af.png",
									"position": 3
								},
								{
									"title": "Community of startups and investors",
									"description": "Make joint venture deals, address requests to the community and communicate with professional investors",
									"imageUrl": "/file/step4_investor_5a92f274.png",
									"position": 4
								}
							],
							"config": {
								"styles": {
									"backgroundColor": "#F4F7F9",
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 0
										},
										"s": {
											"top": 64,
											"bottom": 0
										},
										"md": {
											"top": 64,
											"bottom": 0
										},
										"lg": {
											"top": 80,
											"bottom": 0
										}
									}
								}
							}
						},
						{
							"type": "partners",
							"sysName": "main_en_investors_partners",
							"visible": true,
							"position": 3,
							"subtitle": {
								"text": "SberUnity members"
							},
							"title": "Corporations and investors  \nwho already work with us",
							"items": [
								{
									"imageUrl": "/file/FRV.png",
									"url": "/view?type=2&name=investor_preauth&id=111&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/74d8fcf1-d3ff-4ab0-9c27-883b446acf5e_logo_rgb3 (4).png",
									"url": "/view?type=2&name=investor_preauth&id=91&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/c55e0459-6afb-4ca8-b376-1b30ff115dfa_logo-yrvc.png",
									"url": "/view?type=2&name=investor_preauth&id=77&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/3b66990a-9f88-4a29-89f9-876838fb08f3_startech.vc black.png",
									"url": "/view?type=2&name=investor_preauth&id=85&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/9bd511d9-8ab4-4ba1-99f1-14b5b870f05c_Снимок.png",
									"url": "/view?type=2&name=investor_preauth&id=234&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/a73414be-10cc-49e6-86c2-1a051b5ff48a_Рисунок4.png",
									"url": "/view?type=2&name=investor_preauth&id=1598&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/6a845d71-7030-4127-b58f-40cd4f5c57d7_newindustry_logo_rus_standa.png",
									"url": "/view?type=2&name=investor_preauth&id=90&preauthorize=true&action=1"
								},
								{
									"imageUrl": "/file/58e06111-d67a-4265-b8d8-4a37cdd673e1_imgonline-com-ua-Resize-ogK0NMxUTH.png",
									"url": "/view?type=2&name=investor_preauth&id=75&preauthorize=true&action=1"
								}
							],
							"config": {
								"styles": {
									"backgroundColor": "#F4F7F9",
									"padding": {
										"xs": {
											"top": 64,
											"bottom": 24
										},
										"s": {
											"top": 64,
											"bottom": 24
										},
										"md": {
											"top": 64,
											"bottom": 24
										},
										"lg": {
											"top": 80,
											"bottom": 32
										}
									}
								}
							}
						}
					],
					"description": "Find the best deals"
				}
			]
		},
		{
			"type": "authBanner",
			"sysName": "main_en_authBanner",
			"visible": true,
			"position": 7,
			"title": "More corporations and investors",
			"caption": "are available after registration on the SberUnity platform",
			"mainButtonText": "Join",
			"secondButtonText": "Sign in",
			"config": {
				"styles": {
					"backgroundColor": "#F4F7F9",
					"padding": {
						"xs": {
							"top": 0,
							"bottom": 64
						},
						"s": {
							"top": 0,
							"bottom": 64
						},
						"md": {
							"top": 0,
							"bottom": 64
						},
						"lg": {
							"top": 0,
							"bottom": 80
						}
					}
				}
			}
		}
	]
}'
where uri = '/root'
  and lang_id = 2