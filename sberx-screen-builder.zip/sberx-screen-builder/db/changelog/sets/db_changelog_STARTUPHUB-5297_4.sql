--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5297_4
update pages set name = 'Инвестиции | SberUnity' where uri = '/investment ' and lang_id = 1;
update pages set name = 'Investments | SberUnity' where uri = '/investment ' and lang_id = 2;
update pages set name = 'Отклики | SberUnity' where uri = '/reply' and lang_id = 1;
update pages set name = 'Replies | SberUnity' where uri = '/reply' and lang_id = 2;
update pages set name = 'Просмотр предложения от стартапа | SberUnity' where uri = '/reply-view' and lang_id = 1;
update pages set name = 'Viewing an offer from a startup | SberUnity' where uri = '/reply-view' and lang_id = 2;
