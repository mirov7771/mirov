--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4165_2
update public.screen set
    formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "mask": "$",
                    "note": "Сумма, в которую вы оцениваете ваш пилотный запуск",
                    "type": "string",
                    "edited": true,
                    "example": "$",
                    "sysName": "reply_cost",
                    "required": false,
                    "localName": "Какова стоимость вашего решения",
                    "maxLength": "30"
                },
                {
                    "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Комментарий",
                    "sysName": "reply_process",
                    "required": true,
                    "localName": "Как вы видите процесс пилотирования",
                    "maxLength": "500"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите подробно ваш оффер по данному пилоту",
                    "sysName": "reply_note",
                    "required": true,
                    "localName": "Сопроводительное письмо",
                    "maxLength": "500"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "hide",
                    "sysName": "pilotId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": "Pilot",
                    "edited": true,
                    "format": "hide",
                    "sysName": "reply_tableName",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": "0",
                    "edited": true,
                    "format": "hide",
                    "sysName": "reply_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": "Вес файла — не более 5 МБ, формата PDF",
                    "type": "hyperlink",
                    "edited": true,
                    "format": "URL",
                    "sysName": "reply_fileURL",
                    "required": false,
                    "localName": "Презентация",
                    "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
                    "maxLength": "5",
                    "allowedTypes": [
                        ".pdf"
                    ]
                }
            ],
            "module": "Заявка на пилотирование",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "format": "question",
                    "example": "Ваш вопрос",
                    "sysName": "response",
                    "required": false
                }
            ],
            "module": "Вопросы корпорации",
            "isArray": "true",
            "moduleType": "question"
        }
    ]
}'
where formname = 'pilot_Client_Extra';

update public.screen set
    formedit = '{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "mask": "$",
          "note": "Сумма, в которую вы оцениваете ваш пилотный запуск",
          "type": "string",
          "edited": true,
          "example": "$",
          "sysName": "reply_cost",
          "required": false,
          "localName": "Какова стоимость вашего решения",
          "maxLength": "30"
        },
        {
          "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Комментарий",
          "sysName": "reply_process",
          "required": true,
          "localName": "Как вы видите процесс пилотирования",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Опишите подробно ваш оффер по данному пилоту",
          "sysName": "reply_note",
          "required": true,
          "localName": "Сопроводительное письмо",
          "minLength": "50",
          "maxLength": "500"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "hide",
          "sysName": "pilotId",
          "required": false,
          "localName": ""
        },
        {
          "type": "boolean",
          "value": "Pilot",
          "edited": true,
          "format": "hide",
          "sysName": "reply_tableName",
          "required": false,
          "localName": ""
        },
        {
          "type": "boolean",
          "value": "0",
          "edited": true,
          "format": "hide",
          "sysName": "reply_state",
          "required": false,
          "localName": ""
        },
        {
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "edited": true,
          "format": "URL",
          "sysName": "reply_fileURL",
          "required": false,
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "maxLength": "5",
          "allowedTypes": [
            ".pdf"
          ]
        }
      ],
      "module": "Заявка на пилотирование",
      "moduleNote": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "string",
          "edited": false,
          "format": "question",
          "example": "Ваш вопрос",
          "sysName": "response",
          "required": false
        }
      ],
      "module": "Вопросы корпорации",
      "isArray": "true",
      "moduleType": "question"
    }
  ]
}'
where formname = 'pilot_SuperClient_Extra';