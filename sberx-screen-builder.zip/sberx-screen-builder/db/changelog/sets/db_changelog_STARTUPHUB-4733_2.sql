--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4733_2
delete from pages where uri like '/import-substitution%';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_ru', 'SberUnity Ипортозамещение', '/import-substitution', 'Импортозамещение',  'auth',
        '{
   "features":[
      {
         "config":{

         },
         "type":"participantSearch",
         "foundsTitle":"Найдено: {0}",
         "header":"Импортозамещающие решения",
         "participant":"startupsRecommend",
         "placeholder":"Поиск стартапа",
         "position":1,
         "shownFromTitle":"Показано {0} из {1}",
         "sortLabels":{
            "alphabetically":"По алфавиту",
            "byUpdateDate":"По дате обновления"
         },
         "sysName":"startupsRecommend_ru_participantSearch",
         "title":"Импортозамещающие решения",
         "isImport":true,
         "visible":true
      }
   ]
}', 1);

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_rec_ru', 'SberUnity Ипортозамещение', '/import-substitution/recommended', 'Импортозамещение',  'auth',
        '{
   "features":[
      {
         "config":{

         },
         "type":"participantSearch",
         "foundsTitle":"Найдено: {0}",
         "header":"Рекомендованные",
         "participant":"startupsRecommend",
         "placeholder":"Поиск стартапа",
         "position":1,
         "shownFromTitle":"Показано {0} из {1}",
         "sortLabels":{
            "alphabetically":"По алфавиту",
            "byUpdateDate":"По дате обновления"
         },
         "sysName":"startupsRecommend_ru_participantSearch",
         "title":"Рекомендованные",
         "goBackLink":{
            "to":"/main/import-substitution"
         },
         "isImport":true,
         "visible":true
      }
   ]
}', 1);