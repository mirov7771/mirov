--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3938
select setval('public.client_menu_id_seq', (SELECT max(id) + 1 FROM public.client_menu));

delete
from public.client_menu
where menutype = 'topbar'
  and sysname = 'delete';

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", clientid, logofile, isdefault)

values (0, 'topbar', 'Удалить профиль', 'delete', '/user/{questionnaireId}?isClient=true', 'DELETE', '111260',
        '/file/delete.svg', false);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", clientid, logofile, isdefault)

values (0, 'topbar', 'Удалить профиль', 'delete', '/user/{questionnaireId}?isClient=true', 'DELETE', '8385',
        '/file/delete.svg', false);



insert into public.client_menu ("type", menutype, name, sysname, "action", "method", clientid, logofile, isdefault)

values (1, 'topbar', 'Удалить профиль', 'delete', '/user/{questionnaireId}?isClient=true', 'DELETE', '111260',
        '/file/delete.svg', false);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", clientid, logofile, isdefault)

values (1, 'topbar', 'Удалить профиль', 'delete', '/user/{questionnaireId}?isClient=true', 'DELETE', '8385',
        '/file/delete.svg', false);



insert into public.client_menu ("type", menutype, name, sysname, "action", "method", clientid, logofile, isdefault)

values (2, 'topbar', 'Удалить профиль', 'delete', '/user/{questionnaireId}?isClient=true', 'DELETE', '111260',
        '/file/delete.svg', false);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", clientid, logofile, isdefault)

values (2, 'topbar', 'Удалить профиль', 'delete', '/user/{questionnaireId}?isClient=true', 'DELETE', '8385',
        '/file/delete.svg', false);