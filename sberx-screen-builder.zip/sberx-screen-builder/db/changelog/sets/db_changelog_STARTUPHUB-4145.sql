--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4145
update public.screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "note": "Укажите полное юридическое название вашей компании",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "note": "Укажите год создания вашей компании",
                    "type": "int",
                    "edited": true,
                    "format": "[1991;2021]",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 100,
                    "showLength": false
                },
                {
                    "note": "Выберите страну, в которой зарегистрирована ваша компания",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты"
                },
                {
                    "note": "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт корпорации",
                    "maxLength": "100",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Юридическая информация об организации",
            "pageName": "Юридическая информация об организации",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_fio",
                    "required": true,
                    "localName": "Имя, фамилия представителя"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_role",
                    "required": true,
                    "localName": "Должность"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "representative_phone",
                    "required": true,
                    "localName": "Мобильный телефон"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "representative_email",
                    "required": true,
                    "localName": "Электронная почта"
                }
            ],
            "module": "Контакт представителя",
            "pageName": "Информация о представителе",
            "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
        },
        {
            "page": 2,
            "title": "",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_fio",
                    "required": false,
                    "localName": "Имя, фамилия представителя",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "note": "Укажите должность ответственного лица из предыдущего вопроса",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "workers[]_facebook",
                    "required": false,
                    "localName": "Электронная почта",
                    "maxLength": "150",
                    "showLength": false
                }
            ],
            "module": "Публичный контакт",
            "isArray": "true",
            "pageName": "Информация о представителе",
            "actionText": "Добавить контактное лицо"
        },
        {
            "page": 3,
            "fields": [
                {
                    "note": "Опишите вашу компанию одним предложением",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": true,
                    "localName": "Краткое описание",
                    "maxLength": "150"
                },
                {
                    "note": "Опишите вашу компанию более подробно",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": true,
                    "localName": "Полное описание",
                    "maxLength": "480"
                },
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_industry",
                    "activity": [
                        22000
                    ],
                    "required": true,
                    "localName": "Направление деятельности",
                    "description": "Укажите все релевантные вашей компании отрасли",
                    "multySelect": true
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ]
                }
            ],
            "module": "Корпорация",
            "pageName": "Информация о корпорации"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "title": "Методы работы с инновациями",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_innovationMethod",
                    "activity": [
                        4000
                    ],
                    "required": true,
                    "localName": "Укажите методы",
                    "description": "Выберите методы внедрения инноваций в вашей корпорации",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "title": "Стадии развития стартапов",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_stady",
                    "activity": [
                        7000
                    ],
                    "required": true,
                    "localName": "Стадия развития",
                    "description": "Выберите интересующие стадии развития стартапов",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Укажите все релевантные вашей компании направления",
                    "multySelect": true
                }
            ],
            "module": "Работа со стартапами",
            "pageName": "Условия работы со стартапами"
        },
        {
            "page": 5,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true,
                    "localName": "У вашей компании есть опыт сотрудничества со стартапами?"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "title": "Информация о сотрудничестве со стартапами",
                    "edited": true,
                    "sysName": "questionnaire_startupInvestmentYears",
                    "required": false,
                    "localName": "Сколько лет ваша корпорация работает со стартапами",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_overallPilots",
                    "required": false,
                    "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_lastYearInvestmentsCount",
                    "required": false,
                    "localName": "Количество пилотов со стартапами за последний год",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_overallContracts",
                    "required": false,
                    "localName": "Количество контрактов (внедрений) со стартапами за последний год",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "Успешные кейсы",
            "pageName": "Пилотирование"
        },
        {
            "page": 6,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true,
                    "localName": "Инвестирует ли ваша корпорация в стартапы?"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "chip",
                    "sysName": "investment_round",
                    "activity": [
                        6000
                    ],
                    "required": true,
                    "localName": "Раунд инвестиций",
                    "multySelect": true,
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                },
                {
                    "note": "В стартапы из каких регионов вы готовы инвестировать",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "География стартапов",
                    "multySelect": true,
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции"
        },
        {
            "page": 6,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "successPilots[]_pilotid",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "successPilots[]_company",
                    "required": false,
                    "localName": "Название стартапа",
                    "maxLength": "140",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "successPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание кейса",
                    "maxLength": "300",
                    "showLength": false
                }
            ],
            "module": "Успешные кейсы",
            "isArray": true,
            "pageName": "Инвестиции",
            "subTitle": "Стартап №",
            "withIndex": true,
            "actionText": "Добавить кейс",
            "moduleNote": "Опционально. Укажите названия стартапов, с которыми у вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
            "triggerField": "investment_investment",
            "triggerValue": true
        },
        {
            "page": 7,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_scouting",
                    "required": true,
                    "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?"
                }
            ],
            "module": "Скаутинг",
            "pageName": "Скаутинг"
        }
    ]
}'
where formname = 'New_Corporate';

update public.screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "chip",
                    "sysName": "questionnaire_investorType",
                    "activity": [
                        11000
                    ],
                    "required": true,
                    "localName": "Выберите тип инвестора",
                    "multySelect": false
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название / название бренда",
                    "maxLength": 100,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Ваши имя и фамилия",
                    "maxLength": 100,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название / название бренда",
                    "maxLength": 100,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "hide",
                    "sysName": "questionnaire_questionnaireid",
                    "required": true,
                    "localName": ""
                },
                {
                    "note": "Укажите полное юридическое название вашей компании",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Укажите год создания вашей компании",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Выберите страну, в которой зарегистрирована ваша компания",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Укажите полное юридическое название вашей компании",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Укажите год создания вашей компании",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Выберите страну, в которой зарегистрирована ваша компания",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "hide",
                    "sysName": "representative_facebook",
                    "required": false,
                    "localName": "Профиль в Facebook"
                }
            ],
            "module": "Общая информация",
            "pageName": "Данные профиля и общая информация"
        },
        {
            "page": 1,
            "fields": [
                {
                    "note": "Например, \"Фонд и акселератор\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Укажите краткое описание вашего фонда",
                    "maxLength": 150,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Например, \"Рассматриваю любые проекты\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                    "maxLength": 150,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Укажите страну, в которой вы совершаете основной объем венчурных сделок",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Например, \"Фонд семьи Безосов\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Укажите краткое описание вашего Family Office",
                    "maxLength": 150,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Укажите полное описание вашего фонда",
                    "maxLength": 1000,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Укажите свою полную характеристику как бизнес-ангела",
                    "maxLength": 1000,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Укажите полное описание вашего Family Office",
                    "maxLength": 1000,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11003"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11003"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11003"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Добавьте фото",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить фото",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                }
            ],
            "module": "Данные профиля",
            "pageName": "Данные профиля и общая информация"
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_fio",
                    "required": true,
                    "localName": "Фамилия Имя"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_role",
                    "required": true,
                    "localName": "Должность"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "representative_phone",
                    "required": true,
                    "localName": "Мобильный телефон"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "representative_facebook",
                    "required": false,
                    "localName": "Профиль в Facebook",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Контакт представителя",
            "pageName": "Ваши данные",
            "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
        },
        {
            "page": 2,
            "title": "",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_fio",
                    "required": false,
                    "localName": "Фамилия Имя",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "note": "Укажите должность лица из предыдущего вопроса",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "workers[]_facebook",
                    "required": false,
                    "localName": "Электронная почта",
                    "maxLength": "150",
                    "showLength": false
                }
            ],
            "module": "Публичный контакт",
            "isArray": "true",
            "pageName": "Ваши данные",
            "actionText": "Добавить контактное лицо",
            "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в вашей анкете в качестве контактного лица"
        },
        {
            "page": 3,
            "fields": [
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "investment_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "investment_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "title": "География стартапов",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "investment_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "География стартапов",
                    "description": "В стартапы из каких регионов вы готовы инвестировать",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "chip",
                    "sysName": "investment_round",
                    "activity": [
                        6000
                    ],
                    "required": true,
                    "localName": "Стадии инвестирования",
                    "multySelect": true
                },
                {
                    "note": "Например, impact startups, female founders и т.д.",
                    "type": "string",
                    "edited": true,
                    "sysName": "investment_note",
                    "required": false,
                    "localName": "Особые условия инвестирования",
                    "maxLength": "300",
                    "showLength": false
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые вами для инвестиций"
        },
        {
            "page": 3,
            "fields": [
                {
                    "note": "Число портфельных проектов на текущий момент",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_activeDealsNumber",
                    "required": true,
                    "localName": "Количество стартапов в портфеле",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых вы уже вышли",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_allDealsNumber",
                    "required": true,
                    "localName": "Количество сделок, всего",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Количество стартапов, в которые вы инвестировали и вышли",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_exitDealsNumber",
                    "required": true,
                    "localName": "Количество выходов",
                    "maxLength": 4,
                    "showLength": false
                }
            ],
            "module": "Данные о стартапах портфеля",
            "pageName": "Инвестиции"
        },
        {
            "page": 3,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "questionnairePilots[]_pilotid",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": "Опционально",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnairePilots[]_company",
                    "required": false,
                    "localName": "Название стартапа",
                    "maxLength": "140",
                    "showLength": false
                },
                {
                    "note": "Опционально",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnairePilots[]_site",
                    "required": false,
                    "localName": "Ссылка на сайт стартапа",
                    "maxLength": "140",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Примеры стартапов",
            "isArray": "true",
            "pageName": "Инвестиции",
            "withIndex": true,
            "actionText": "Добавить стартап",
            "moduleNote": "Здесь вы можете перечислить все или наиболее интересные стартапы из вашего портфеля"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_club",
                    "required": true,
                    "localName": "Состоите ли вы в каком-либо инвестиционном клубе / сообществе?"
                }
            ],
            "module": "Инвестиционные клубы",
            "pageName": "Участие в инвестиционных клубах"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "investorClubs[]_name",
                    "required": false,
                    "localName": "Название клуба / сообщества"
                },
                {
                    "note": "Например, \"Основатель клуба\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "investorClubs[]_role",
                    "required": false,
                    "localName": "Ваша роль в клубе / сообществе"
                }
            ],
            "module": "Сообщества",
            "isArray": "true",
            "pageName": "Участие в инвестиционных клубах",
            "subTitle": "Клуб / сообщество №",
            "withIndex": true,
            "actionText": "Добавить клуб",
            "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
            "triggerField": "questionnaire_club",
            "triggerValue": true
        }
    ]
}'
where formname = 'New_Investor';

update public.screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "chip",
                    "sysName": "questionnaire_investorType",
                    "activity": [
                        11000
                    ],
                    "required": true,
                    "localName": "Выберите тип инвестора",
                    "multySelect": false
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название / название бренда",
                    "maxLength": 100,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Ваши имя и фамилия",
                    "maxLength": 100,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название / название бренда",
                    "maxLength": 100,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "hide",
                    "sysName": "questionnaire_questionnaireid",
                    "required": true,
                    "localName": ""
                },
                {
                    "note": "Укажите полное юридическое название вашей компании",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Укажите год создания вашей компании",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Выберите страну, в которой зарегистрирована ваша компания",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Укажите полное юридическое название вашей компании",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Укажите год создания вашей компании",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Выберите страну, в которой зарегистрирована ваша компания",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "hide",
                    "sysName": "representative_facebook",
                    "required": false,
                    "localName": "Профиль в Facebook"
                }
            ],
            "module": "Общая информация",
            "pageName": "Данные профиля и общая информация"
        },
        {
            "page": 1,
            "fields": [
                {
                    "note": "Например, \"Фонд и акселератор\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Укажите краткое описание вашего фонда",
                    "maxLength": 150,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Например, \"Рассматриваю любые проекты\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                    "maxLength": 150,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Укажите страну, в которой вы совершаете основной объем венчурных сделок",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Например, \"Фонд семьи Безосов\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Укажите краткое описание вашего Family Office",
                    "maxLength": 150,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Укажите полное описание вашего фонда",
                    "maxLength": 1000,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Укажите свою полную характеристику как бизнес-ангела",
                    "maxLength": 1000,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Укажите полное описание вашего Family Office",
                    "maxLength": 1000,
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11003"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11003"
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты",
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11001"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11003"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11004"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Добавьте фото",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить фото",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ],
                    "triggerField": "questionnaire_investorType",
                    "triggerValue": "11002"
                }
            ],
            "module": "Данные профиля",
            "pageName": "Данные профиля и общая информация"
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_fio",
                    "required": true,
                    "localName": "Фамилия Имя"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_role",
                    "required": true,
                    "localName": "Должность"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "representative_phone",
                    "required": true,
                    "localName": "Мобильный телефон"
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "representative_facebook",
                    "required": false,
                    "localName": "Профиль в Facebook",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Контакт представителя",
            "pageName": "Ваши данные",
            "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
        },
        {
            "page": 2,
            "title": "",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_fio",
                    "required": false,
                    "localName": "Фамилия Имя",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "note": "Укажите должность лица из предыдущего вопроса",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "workers[]_facebook",
                    "required": false,
                    "localName": "Электронная почта",
                    "maxLength": "150",
                    "showLength": false
                }
            ],
            "module": "Публичный контакт",
            "isArray": "true",
            "pageName": "Ваши данные",
            "actionText": "Добавить контактное лицо",
            "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в вашей анкете в качестве контактного лица"
        },
        {
            "page": 3,
            "fields": [
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "investment_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "investment_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "title": "География стартапов",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "investment_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "География стартапов",
                    "description": "В стартапы из каких регионов вы готовы инвестировать",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "chip",
                    "sysName": "investment_round",
                    "activity": [
                        6000
                    ],
                    "required": true,
                    "localName": "Стадии инвестирования",
                    "multySelect": true
                },
                {
                    "note": "Например, impact startups, female founders и т.д.",
                    "type": "string",
                    "edited": true,
                    "sysName": "investment_note",
                    "required": false,
                    "localName": "Особые условия инвестирования",
                    "maxLength": "300",
                    "showLength": false
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые вами для инвестиций"
        },
        {
            "page": 3,
            "fields": [
                {
                    "note": "Число портфельных проектов на текущий момент",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_activeDealsNumber",
                    "required": true,
                    "localName": "Количество стартапов в портфеле",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых вы уже вышли",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_allDealsNumber",
                    "required": true,
                    "localName": "Количество сделок, всего",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Количество стартапов, в которые вы инвестировали и вышли",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_exitDealsNumber",
                    "required": true,
                    "localName": "Количество выходов",
                    "maxLength": 4,
                    "showLength": false
                }
            ],
            "module": "Данные о стартапах портфеля",
            "pageName": "Инвестиции"
        },
        {
            "page": 3,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "questionnairePilots[]_pilotid",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": "Опционально",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnairePilots[]_company",
                    "required": false,
                    "localName": "Название стартапа",
                    "maxLength": "140",
                    "showLength": false
                },
                {
                    "note": "Опционально",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnairePilots[]_site",
                    "required": false,
                    "localName": "Ссылка на сайт стартапа",
                    "maxLength": "140",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Примеры стартапов",
            "isArray": "true",
            "pageName": "Инвестиции",
            "withIndex": true,
            "actionText": "Добавить стартап",
            "moduleNote": "Здесь вы можете перечислить все или наиболее интересные стартапы из вашего портфеля"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_club",
                    "required": true,
                    "localName": "Состоите ли вы в каком-либо инвестиционном клубе / сообществе?"
                }
            ],
            "module": "Инвестиционные клубы",
            "pageName": "Участие в инвестиционных клубах"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "investorClubs[]_name",
                    "required": false,
                    "localName": "Название клуба / сообщества"
                },
                {
                    "note": "Например, \"Основатель клуба\"",
                    "type": "string",
                    "edited": true,
                    "sysName": "investorClubs[]_role",
                    "required": false,
                    "localName": "Ваша роль в клубе / сообществе"
                }
            ],
            "module": "Сообщества",
            "isArray": "true",
            "pageName": "Участие в инвестиционных клубах",
            "subTitle": "Клуб / сообщество №",
            "withIndex": true,
            "actionText": "Добавить клуб",
            "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
            "triggerField": "questionnaire_club",
            "triggerValue": true
        }
    ]
}'
where formname = 'investor_edit';

update public.screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "note": "Укажите полное юридическое название вашей компании",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "note": "Укажите год создания вашей компании",
                    "type": "int",
                    "edited": true,
                    "format": "[1991;2021]",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 100,
                    "showLength": false
                },
                {
                    "note": "Выберите страну, в которой зарегистрирована ваша компания",
                    "type": "array",
                    "edited": true,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна юрисдикции",
                    "multySelect": false
                },
                {
                    "note": "Эта почта будет видна другим участниками платформы",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Публичный адрес электронной почты"
                },
                {
                    "note": "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт корпорации",
                    "maxLength": "100",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Юридическая информация об организации",
            "pageName": "Юридическая информация об организации",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_fio",
                    "required": true,
                    "localName": "Имя, фамилия представителя"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "representative_role",
                    "required": true,
                    "localName": "Должность"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "representative_phone",
                    "required": true,
                    "localName": "Мобильный телефон"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "representative_email",
                    "required": true,
                    "localName": "Электронная почта"
                }
            ],
            "module": "Контакт представителя",
            "pageName": "Информация о представителе",
            "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
        },
        {
            "page": 2,
            "title": "",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_fio",
                    "required": false,
                    "localName": "Имя, фамилия представителя",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "note": "Укажите должность ответственного лица из предыдущего вопроса",
                    "type": "string",
                    "edited": true,
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "workers[]_facebook",
                    "required": false,
                    "localName": "Электронная почта",
                    "maxLength": "150",
                    "showLength": false
                }
            ],
            "module": "Публичный контакт",
            "isArray": "true",
            "pageName": "Информация о представителе",
            "actionText": "Добавить контактное лицо"
        },
        {
            "page": 3,
            "fields": [
                {
                    "note": "Опишите вашу компанию одним предложением",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_note",
                    "required": true,
                    "localName": "Краткое описание",
                    "maxLength": "150"
                },
                {
                    "note": "Опишите вашу компанию более подробно",
                    "type": "string",
                    "edited": true,
                    "sysName": "questionnaire_fullNote",
                    "required": true,
                    "localName": "Полное описание",
                    "maxLength": "480"
                },
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_industry",
                    "activity": [
                        22000
                    ],
                    "required": true,
                    "localName": "Направление деятельности",
                    "description": "Укажите все релевантные вашей компании отрасли",
                    "multySelect": true
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип",
                    "maxLength": "5",
                    "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                    "allowedTypes": [
                        ".png", ".jpg"
                    ]
                }
            ],
            "module": "Корпорация",
            "pageName": "Информация о корпорации"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "title": "Методы работы с инновациями",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_innovationMethod",
                    "activity": [
                        4000
                    ],
                    "required": true,
                    "localName": "Укажите методы",
                    "description": "Выберите методы внедрения инноваций в вашей корпорации",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "title": "Стадии развития стартапов",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_stady",
                    "activity": [
                        7000
                    ],
                    "required": true,
                    "localName": "Стадия развития",
                    "description": "Выберите интересующие стадии развития стартапов",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Укажите все релевантные вашей компании направления",
                    "multySelect": true
                }
            ],
            "module": "Работа со стартапами",
            "pageName": "Условия работы со стартапами"
        },
        {
            "page": 5,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true,
                    "localName": "У вашей компании есть опыт сотрудничества со стартапами?"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "title": "Информация о сотрудничестве со стартапами",
                    "edited": true,
                    "sysName": "questionnaire_startupInvestmentYears",
                    "required": false,
                    "localName": "Сколько лет ваша корпорация работает со стартапами",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_overallPilots",
                    "required": false,
                    "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_lastYearInvestmentsCount",
                    "required": false,
                    "localName": "Количество пилотов со стартапами за последний год",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "note": "Опционально",
                    "type": "int",
                    "edited": true,
                    "sysName": "questionnaire_overallContracts",
                    "required": false,
                    "localName": "Количество контрактов (внедрений) со стартапами за последний год",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "Успешные кейсы",
            "pageName": "Пилотирование"
        },
        {
            "page": 6,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true,
                    "localName": "Инвестирует ли ваша корпорация в стартапы?"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "chip",
                    "sysName": "investment_round",
                    "activity": [
                        6000
                    ],
                    "required": true,
                    "localName": "Раунд инвестиций",
                    "multySelect": true,
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                },
                {
                    "note": "В стартапы из каких регионов вы готовы инвестировать",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "География стартапов",
                    "multySelect": true,
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции"
        },
        {
            "page": 6,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "successPilots[]_pilotid",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "successPilots[]_company",
                    "required": false,
                    "localName": "Название стартапа",
                    "maxLength": "140",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "successPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание кейса",
                    "maxLength": "300",
                    "showLength": false
                }
            ],
            "module": "Успешные кейсы",
            "isArray": true,
            "pageName": "Инвестиции",
            "subTitle": "Стартап №",
            "withIndex": true,
            "actionText": "Добавить кейс",
            "moduleNote": "Опционально. Укажите названия стартапов, с которыми у вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
            "triggerField": "investment_investment",
            "triggerValue": true
        },
        {
            "page": 7,
            "fields": [
                {
                    "type": "boolean",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_scouting",
                    "required": true,
                    "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?"
                }
            ],
            "module": "Скаутинг",
            "pageName": "Скаутинг"
        }
    ]
}'
where formname = 'corporate_edit';