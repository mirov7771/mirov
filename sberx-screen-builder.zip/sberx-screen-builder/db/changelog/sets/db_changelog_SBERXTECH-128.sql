--liquibase formatted sql
--changeset Mirov A:SBERXTECH-128
update screen
set formview = '{
  "form": [
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Компания",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "hyperlink",
          "format": "hyperlink",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_note",
          "localName": "Сопроводительное письмо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_fileURL",
          "localName": "Презентация",
          "type": "hyperlink",
          "format": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_staff",
          "localName": "Число сотрудников",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}', buttons = '
{
  "buttons": [
    {
      "icon": "",
      "type": "active",
      "text": "Перейти в анкету",
      "action": "/view?name=corporate_SuperClient&type=1&action=1&id=",
      "variant": "primary",
      "description": ""
    }
  ]
}'
where formname like 'reply%Client';
