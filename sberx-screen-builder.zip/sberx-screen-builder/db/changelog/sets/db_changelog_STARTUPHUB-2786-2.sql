--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-2786-2

UPDATE public.screen SET formedit='{
  "form": [
    {
      "module": "Юридическая информация об организации",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "questionnaire_questionnaireid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "note": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook*",
          "type": "string",
          "edited": true,
          "required": false,
          "format": "hide"
        }
      ]
    },
    {
      "module": "Данные профиля",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Выберите тип инвестора",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего фонда",
          "note": "Например, \"Фонд и акселератор\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите свою краткую характеристику как бизнес-ангела",
          "note": "Например, \"Рассматриваю любые проекты\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего Family Office",
          "note": "Например, \"Фонд семьи Безосов\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего фонда",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите свою полную характеристику как бизнес-ангела",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего Family Office",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Добавьте фото",
          "localName": "Загрузить фото",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Контакт представителя",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения Вашей анкеты",
      "page": 2,
      "pageName": "Ваши данные",
      "fields": [
        {
          "sysName": "representative_fio",
          "localName": "Фамилия Имя",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_role",
          "localName": "Должность*",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_phone",
          "localName": "Мобильный телефон*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook*",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Публичный контакт",
      "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в Вашей анкете в качестве контактного лица",
      "page": 2,
      "pageName": "Ваши данные",
      "isArray": "true",
      "title": "",
      "actionText": "Добавить контактное лицо",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_fio",
          "localName": "Фамилия Имя",
          "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "note": "Укажите должность лица из предыдущего вопроса",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_facebook",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "maxLength": "150",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые Вами для инвестиций",
      "fields": [
        {
          "title": "Направления",
          "sysName": "investment_industry",
          "localName": "Индустии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_geography",
          "title": "География стартапов",
          "localName": "География стартапов",
          "description": "В стартапы из каких регионов Вы готовы инвестировать",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестирования",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_note",
          "localName": "Особые условия инвестирования",
          "note": "Например, impact startups, female founders и т.д.",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Данные о стартапах портфеля",
      "page": 3,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_activeDealsNumber",
          "localName": "Количество стартапов в портфеле",
          "note": "Число портфельных проектов на текущий момент",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество сделок, всего",
          "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых Вы уже вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "note": "Количество стартапов, в которые Вы инвестировали и вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        }
      ]
    },
    {
      "module": "Примеры стартапов",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Здесь Вы можете перечислить все или наиболее интересные стартапы из Вашего портфеля",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить стартап",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "note": "Опционально",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "questionnairePilots[]_site",
          "localName": "Ссылка на сайт стартапа",
          "note": "Опционально",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиционные клубы",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "fields": [
        {
          "sysName": "questionnaire_club",
          "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Сообщества",
      "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "subTitle": "Клуб / сообщество №",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить клуб",
      "triggerField": "questionnaire_club",
      "triggerValue": true,
      "fields": [
        {
          "sysName": "investorClubs[]_name",
          "localName": "Название клуба / сообщества*",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investorClubs[]_role",
          "localName": "Ваша роль в клубе / сообществе*",
          "note": "Например, \"Основатель клуба\"",
          "type": "string",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}' where formname='investor_edit' ;

UPDATE public.screen SET  formedit='{
  "form": [
    {
      "module": "Условия соглашения",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Юридическая информация об организации",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "questionnaire_questionnaireid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": true
        },{
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "note": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook*",
          "type": "string",
          "edited": true,
          "required": false,
          "format": "hide"
        }
      ]
    },
    {
      "module": "Данные профиля",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Выберите тип инвестора",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего фонда",
          "note": "Например, \"Фонд и акселератор\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите свою краткую характеристику как бизнес-ангела",
          "note":"Например, \"Рассматриваю любые проекты\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего Family Office",
          "note": "Например, \"Фонд семьи Безосов\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },{
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего фонда",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите свою полную характеристику как бизнес-ангела",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего Family Office",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Опционально",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",


          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",

          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Опционально",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Опционально",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "200*200",
          "maxLength" : "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "200*200",
          "maxLength" : "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "200*200",
          "maxLength" : "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },{
          "sysName": "questionnaire_logoFile",
          "title": "Добавьте фото",
          "localName": "Загрузить фото",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "200*200",
          "maxLength" : "5",
          "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Контакт представителя",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения Вашей анкеты",
      "page": 2,
      "pageName": "Ваши данные",
      "fields": [
        {
          "sysName": "representative_fio",
          "localName": "Фамилия Имя",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_role",
          "localName": "Должность*",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_phone",
          "localName": "Мобильный телефон*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook*",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "edited": true,
          "required": false
        }
      ]
    },{
      "module": "Публичный контакт",
      "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в Вашей анкете в качестве контактного лица",
      "page": 2,
      "pageName": "Ваши данные",
      "isArray": "true",
      "title": "",
      "actionText": "Добавить контактное лицо",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_fio",
          "localName": "Фамилия Имя",
          "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "note": "Укажите должность лица из предыдущего вопроса",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "workers[]_facebook",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "maxLength": "150",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые Вами для инвестиций",
      "fields": [
        {
          "title": "Направления",
          "sysName": "investment_industry",
          "localName": "Индустии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "investment_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_geography",
          "title": "География стартапов",
          "localName": "География стартапов",
          "description": "В стартапы из каких регионов Вы готовы инвестировать",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестирования",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "investment_note",
          "localName": "Особые условия инвестирования",
          "note": "Например, impact startups, female founders и т.д.",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Данные о стартапах портфеля",
      "page": 3,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_activeDealsNumber",
          "localName": "Количество стартапов в портфеле",
          "note": "Число портфельных проектов на текущий момент",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество сделок, всего",
          "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых Вы уже вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "note": "Количество стартапов, в которые Вы инвестировали и вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        }
      ]
    },
    {
      "module": "Примеры стартапов",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Здесь Вы можете перечислить все или наиболее интересные стартапы из Вашего портфеля",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить стартап",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "note": "Опционально",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "questionnairePilots[]_site",
          "localName": "Ссылка на сайт стартапа",
          "note": "Опционально",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиционные клубы",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "fields": [
        {
          "sysName": "questionnaire_club",
          "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Сообщества",
      "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "subTitle": "Клуб / сообщество №",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить клуб",
      "triggerField": "questionnaire_club",
      "triggerValue": true,
      "fields": [
        {
          "sysName": "investorClubs[]_name",
          "localName": "Название клуба / сообщества*",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investorClubs[]_role",
          "localName": "Ваша роль в клубе / сообществе*",
          "note": "Например, \"Основатель клуба\"",
          "type": "string",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}' where formname='New_Investor';

UPDATE public.screen SET  formedit='{
  "form": [

    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "description": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },{
          "sysName": "questionnaire_inn",
          "localName": "Идентификационный номер компании*",
          "note": "например, ИНН",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 40,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "description": "Укажите год создания Вашей компании",
          "type": "int",
          "format": "year",
          "mask": "2000;getyear",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название",
          "description": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "note": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "note": "Почта сотрудника, с которым можно связаться",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона*",
          "note": "Телефон контактного лица",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Опционально. Укажите ссылки на внешние ресурсы",
      "isArray": "true",
      "actionText": "Добавить ресурс",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "maxLength": "200",
          "note": "Опишите Ваш проект одним предложением",
          "edited": true,
          "required": true
        },
        {
          "title": "Модели продаж",
          "description": "Укажите все модели взаимодействия с пользователями в Вашем бизнесе",
          "sysName": "project_interactionType",
          "localName": "",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "title": "Где базируется Ваш проект?",
          "description": "Укажите, где фактически базируется штаб-квартира Вашей компании",
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 30,
          "showLength": false
        },
        {
          "title": "Направления",
          "description": "Индустрии и технологические вертикали, в которых функционирует ваш бизнес",
          "sysName": "project_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Стадия развития продукта",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
         "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27004,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1-2 предложениях, какую задачу или проблему решает Ваш продукт",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "note": "Опишите Вашу ЦА: возраст, род деятельности, интересы и т.д.",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "title": "Презентация",
          "description": "Не обязательно загружать, но повышает шансы заинтересовать инвесторов и корпорации",
          "type": "hyperlink",
          "maxLength": "50",
          "format": "URL",
          "note": "Принимаем файлы до 50 Мб. Формат — PDF",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },
        {
          "title": "Видео питча",
          "description": "Укажите ссылку на видеозапись Вашей презентации проекта на внешнем ресурсе",
          "sysName": "project_pitchVideo",
          "localName": "Ссылка на видео",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "type": "string",
          "maxLength": "255",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Рынок",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых Вы работаете",
          "note": "Регионы, на которых уже представлен Ваш продукт",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "note": "Регионы, в которые планируете выходить в ближайшем будущем",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "note": "Наличие продаж у Вашей компании",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в год",
          "type": "string",
          "maxLength": "300",
          "note": "Валовый оборот компании за последний год в USD",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 4,
      "pageName": "Конкуренты",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите компании, решающие ту же проблему, но иным типом продукта",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "note": "Перечислите предметно, чем вы лучше конкурентов",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "note": "Перечислите возможные слабые стороны Вашей компании относительно конкурентов",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 5,
      "pageName": "Команда",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Общее число сотрудников",
          "note": "Общее число сотрудников, включая основателей",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 5,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые должности в стартапе закрыты",
      "actionText": "Добавить сотрудника",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность сотрудника в команде",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "Если вы В2В-, В2G-, B2B2C-, В2О- стартап: у вас есть успешные пилоты / внедрения?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "moduleNote": "Опционально. Укажите, с кем у вас были успешные пилоты / внедрения, и опишите их суть и результаты, но только если раскрытие этой информации не противоречит договоренностям с корпорацией и пр. Эту информацию увидят другие пользователи SberUnity",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 6,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "note": "Если у Вас уже есть идеи, как можно пилотировать Ваш продукт, опишите их в 1-2 предложениях",
          "type": "string",
          "maxLength": "300",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "title": "Есть ли у Вас опыт взаимодействия с экосистемой Сбера?*",
          "description": "Были ли у Вас пилоты, контракты и другие виды сотрудничества со Сбером или компаниями экосистемы Сбера?",
          "sysName": "ecoPilot_experience",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": false
        },
        {
          "description": "С какими подразделениями или компаниями Сбера Вы взаимодействовали?",
          "sysName": "ecoPilot_businessUnit",
          "localName": "Перечислите компании или подразделения",
          "type": "string",
          "maxLength": "120",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 7,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "title": "Находитесь ли Вы в активном поиске инвестиций?",
          "description": "Собираете ли вы в раунд прямо сейчас?",
          "sysName": "investment_investment",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций (USD)",
          "type": "int",
           "mask": "splitter",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Укажите, выпускником каких акселераторов вы являетесь (если применимо)",
          "type": "array",
          "format": "chip",
          "activity": [
            26000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщество",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "title": "Хотите вступить в стартап-сообщество Сбера?*",
          "sysName": "questionnaire_community",
          "localName": "",
          "description": "Вы получите эксклюзивные митапы с экспертами венчурного рынка, приглашения на закрытые мероприятия, медиа-поддержку проектов, полезный нетворк и приоритетный доступ к ресурсам экосистемы Сбера. Ответ увидят только администраторы SberUnity.",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },{
  "module": "",
  "page": 7,
  "pageName": "",
  "isArray": "true",
  "moduleFormat" : "editbutton",
  "triggerField": "questionnaire_community",
  "triggerValue": "true",
  "fields": [
    {
          "sysName": "",
          "localName": "",
          "type": "array",
          "format": "heading",
          "value": "SberStartup",
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "",
          "localName": "",
          "type": "array",
          "format": "body",
          "value": "Подпишитесь на канал стартап-сообщества Сбера! Полезные советы от лучших венчурных экспертов, прикладные кейсы фаундеров, актуальные новости инвестиций.",
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "",
          "title": "Подписаться",
          "type": "info",
          "format": "Telegram_button",
          "value": "https://t.me/sberstartup",
          "edited": false,
          "required": false
    }
  ]
}
  ]
}'  WHERE formname='New_StartUp';

UPDATE public.screen SET   formview='{
  "form": [
    {
      "module": "Организация",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "Questionnaire_Modified",
          "localName": "Время обновления",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": false,
          "required": false
        },{
          "sysName": "questionnaire_inn",
          "localName": "ИНН организации",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "type": "string",
          "edited": false,
          "required": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "text",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "chip",
          "activity": [
            24000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        },{
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false

        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "type": "logo",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Прототип",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "text",
          "activity": [27000],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "hyperlink",
          "format": "URL",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }

      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "text",
          "activity": [
            5000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в год(USD)",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Общее количество сотрудников",
          "type": "int",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные B2C-, C2C- кейсы",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "type": "string",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "edited": false,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "edited": false,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Проект привлекает инвестиции",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций",
          "type": "int",
          "mask": "splitter",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Является выпускником:",
          "type": "array",
          "format": "text",
          "activity": [26000],
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщества",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществах СберСтартап",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'  WHERE formname='startup_Administrator';

UPDATE public.screen SET   formview='{
      "form": [
        {
          "module": "Основная информация",
          "page": 1,
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Название",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_acceleratorCode",
              "localName": "Является выпускником:",
              "type": "array",
              "format": "text",
              "activity": [
                26000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год основания",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_interactionType",
              "localName": "Тип взаимодействия с пользователем",
              "type": "array",
              "format": "text",
              "activity": [
                8000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_businessModel",
              "localName": "Бизнес-модели",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                24000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_industry",
              "localName": "Индустрия проекта",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_note",
              "localName": "Краткое описание проекта",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_problem",
              "localName": "Проблема, которую решает проект",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_auditory",
              "localName": "Целевая аудитория",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Дополнительные контакты (Доступно по подписке)",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "contacts[]_name",
              "localName": "Ссылка",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "О проекте (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_mvpCode",
              "localName": "Стадия развития продукта",
              "type": "array",
              "format": "text",
              "activity": [
                27000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_demoSite",
              "localName": "Ссылка на демо",
              "type": "hyperlink",
              "triggerField": "project_haveMVP",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_demoVideo",
              "localName": "Видео о продукте",
              "type": "hyperlink",
              "triggerField": "project_haveMVP",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_businessPlan",
              "localName": "Презентация (Доступно по подписке)",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_pitchVideo",
              "localName": "Видео питча",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_geography",
              "localName": "Рынки, на которых работает стартап",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_expansion",
              "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_sales",
              "localName": "Продажи",
              "type": "array",
              "format": "text",
              "activity": [
                5000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_turnover",
              "localName": "Оборот",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Конкуренты (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_competitor",
              "localName": "Прямые конкуренты",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_indirectCompetitor",
              "localName": "Косвенные конкуренты",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_upSide",
              "localName": "Преимущества перед конкурентами",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_downSide",
              "localName": "Недостатки перед конкурентами ",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Команда (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "questionnaire_locationCountry",
              "localName": "Страна, где находится команда",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "questionnaire_location",
              "localName": "Город, где находится команда",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_staff",
              "localName": "Общее количество сотрудников",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "",
          "page": 1,
          "isArray": "true",
          "fields": [
            {
              "sysName": "worker_parentId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "worker_isFounder",
              "localName": "",
              "type": "boolean",
              "format": "hide",
              "value": false,
              "edited": false,
              "required": false
            },
            {
              "sysName": "worker_role",
              "localName": "Ключевые члены команды",
              "type": "string",
              "edited": false,
              "required": false,
              "direction": "concatenation",
              "isBlur": true
            },
            {
              "sysName": "workers[]_note",
              "localName": "Опыт",
              "type": "string",
              "maxLength": "150",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы (Доступно по подписке)",
          "moduleNote": "",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "b2bPilots[]_state",
              "localName": "",
              "type": "array",
              "format": "hide",
              "value": "20007",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2bPilots[]_reference",
              "localName": "С кем был успешный кейс",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2bPilots[]_suggestCase",
              "localName": "Описание и результаты кейса",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Успешные B2C-, C2C- кейсы (Доступно по подписке)",
          "moduleNote": "",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "b2cPilots[]_state",
              "localName": "",
              "type": "array",
              "format": "hide",
              "value": "20007",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2cPilots[]_reference",
              "localName": "С кем был успешный кейс",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2cPilots[]_suggestCase",
              "localName": "Описание и результаты кейса",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Инвестиции (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Проект привлекает инвестиции",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_sumInvestment",
              "localName": "Требуемая сумма",
              "type": "int",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_lastInvestment",
              "localName": "Объем ранее привлеченных инвестиций, всего",
              "type": "string",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_coInvestment",
              "localName": "Имя/ имена инвестора/ инвесторов",
              "type": "string",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        }
      ]
    }'  WHERE formname='startup_Client';

   UPDATE public.screen SET  formedit='{
  "form": [
    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "description": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },{
          "sysName": "questionnaire_inn",
          "localName": "Идентификационный номер компании*",
          "note": "например, ИНН",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 40,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "description": "Укажите год создания Вашей компании",
          "type": "int",
          "format": "year",
          "mask": "2000;getyear",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название",
          "description": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
          "example": "https://sber-unity.ru",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "note": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "note": "Почта сотрудника, с которым можно связаться",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона*",
          "note": "Телефон контактного лица",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Опционально. Укажите ссылки на внешние ресурсы",
      "isArray": "true",
      "actionText": "Добавить ресурс",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "maxLength": "200",
          "note": "Опишите Ваш проект одним предложением",
          "edited": true,
          "required": true
        },
        {
          "title": "Модели продаж",
          "description": "Укажите все модели взаимодействия с пользователями в Вашем бизнесе",
          "sysName": "project_interactionType",
          "localName": "",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "title": "Где базируется Ваш проект?",
          "description": "Укажите, где фактически базируется штаб-квартира Вашей компании",
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 30,
          "showLength": false
        },
        {
          "title": "Направления",
          "description": "Индустрии и технологические вертикали, в которых функционирует ваш бизнес",
          "sysName": "project_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "200*200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Стадия развития продукта",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
         "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27004,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "note": "Это необязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1-2 предложениях, какую задачу или проблему решает Ваш продукт",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "note": "Опишите Вашу ЦА: возраст, род деятельности, интересы и т.д.",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "title": "Презентация",
          "description": "Не обязательно загружать, но повышает шансы заинтересовать инвесторов и корпорации",
          "type": "hyperlink",
          "maxLength": "50",
          "format": "URL",
          "note": "Принимаем файлы до 50 Мб. Формат — PDF",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },
        {
          "title": "Видео питча",
          "description": "Укажите ссылку на видеозапись Вашей презентации проекта на внешнем ресурсе",
          "sysName": "project_pitchVideo",
          "localName": "Ссылка на видео",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "type": "string",
          "maxLength": "255",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Рынок",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых Вы работаете",
          "note": "Регионы, на которых уже представлен Ваш продукт",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "note": "Регионы, в которые планируете выходить в ближайшем будущем",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "note": "Наличие продаж у Вашей компании",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в год",
          "type": "string",
          "maxLength": "300",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "note": "Валовый оборот компании за последний год в USD",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 4,
      "pageName": "Конкуренты",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите компании, решающие ту же проблему, но иным типом продукта",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "note": "Перечислите предметно, чем вы лучше конкурентов",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "note": "Перечислите возможные слабые стороны Вашей компании относительно конкурентов",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 5,
      "pageName": "Команда",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Общее число сотрудников",
          "note": "Общее число сотрудников, включая основателей",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 5,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые должности в стартапе закрыты",
      "actionText": "Добавить сотрудника",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность сотрудника в команде",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "Если вы В2В-, В2G-, B2B2C-, В2О- стартап: у вас есть успешные пилоты / внедрения?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "moduleNote": "Опционально. Укажите, с кем у вас были успешные пилоты / внедрения, и опишите их суть и результаты, но только если раскрытие этой информации не противоречит договоренностям с корпорацией и пр. Эту информацию увидят другие пользователи SberUnity",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 6,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "note": "Если у Вас уже есть идеи, как можно пилотировать Ваш продукт, опишите их в 1-2 предложениях",
          "type": "string",
          "maxLength": "300",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "title": "Есть ли у Вас опыт взаимодействия с экосистемой Сбера?*",
          "description": "Были ли у Вас пилоты, контракты и другие виды сотрудничества со Сбером или компаниями экосистемы Сбера?",
          "sysName": "ecoPilot_experience",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": false
        },
        {
          "description": "С какими подразделениями или компаниями Сбера Вы взаимодействовали?",
          "sysName": "ecoPilot_businessUnit",
          "localName": "Перечислите компании или подразделения",
          "type": "string",
          "maxLength": "120",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 7,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "title": "Находитесь ли Вы в активном поиске инвестиций?",
          "description": "Собираете ли вы в раунд прямо сейчас?",
          "sysName": "investment_investment",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций (USD)",
          "type": "int",
           "mask": "splitter",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Укажите, выпускником каких акселераторов вы являетесь (если применимо)",
          "type": "array",
          "format": "chip",
          "activity": [
            26000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщество",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "title": "Хотите вступить в стартап-сообщество Сбера?*",
          "sysName": "questionnaire_community",
          "localName": "",
          "description": "Вы получите эксклюзивные митапы с экспертами венчурного рынка, приглашения на закрытые мероприятия, медиа-поддержку проектов, полезный нетворк и приоритетный доступ к ресурсам экосистемы Сбера. Ответ увидят только администраторы SberUnity.",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },{
  "module": "",
  "page": 7,
  "pageName": "",
  "isArray": "true",
  "moduleFormat" : "editbutton",
  "triggerField": "questionnaire_community",
  "triggerValue": "true",
  "fields": [
    {
          "sysName": "",
          "localName": "",
          "type": "array",
          "format": "heading",
          "value": "SberStartup",
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "",
          "localName": "",
          "type": "array",
          "format": "body",
          "value": "Подпишитесь на канал стартап-сообщества Сбера! Полезные советы от лучших венчурных экспертов, прикладные кейсы фаундеров, актуальные новости инвестиций.",
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "",
          "title": "Подписаться",
          "type": "info",
          "format": "Telegram_button",
          "value": "https://t.me/sberstartup",
          "edited": false,
          "required": false
    }
  ]
}
  ]
}' WHERE formname='startup_edit';
UPDATE public.screen SET   formview='{ "form": [{
  "module": "Основная информация",
  "page": 1,
  "fields": [{
    "sysName": "project_note",
    "localName": "Краткое описание проекта",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_problem",
    "localName": "Проблема, которую решает проект",
    "type": "string",
    "edited": false,
    "required": false
  },  {
    "sysName": "project_auditory",
    "localName": "Целевая аудитория",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "title": "Перейти",
    "type": "hyperlink",
    "format": "button",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_acceleratorCode",
    "localName": "Является выпускником:",
    "type": "array",
    "format": "text",
    "activity": [26000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_birthYear",
    "localName": "Год основания",
    "type": "int",
    "edited": false,
    "required": false
  },{
    "sysName": "project_interactionType",
    "localName": "Модель продаж",
    "type": "array",
    "format": "text",
    "activity": [8000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_businessModel",
    "localName": "Бизнес-модели",
    "type": "array",
    "format": "search_dropdown",
    "activity": [
      24000
    ],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_industry",
    "localName": "Индустрии проекта",
    "type": "array",
    "format": "text",
    "activity": [3000],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_technology",
    "localName": "Технологии проекта",
    "type": "array",
    "format": "text",
    "activity": [13000],
    "edited": false,
    "required": false
  },{
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false
        }
  ]
}, {
  "module": "Дополнительные ссылки",
  "page": 1,
  "pageName": "",
  "isArray": "true",
   "moduleFormat" : "button",
  "fields": [
    {
          "sysName": "contacts[]_type",
          "localName": "",
          "type": "array",
          "format": "heading",
          "activity": [
            21000
          ],
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "contacts[]_name",
          "title": "Перейти",
          "type": "info",
          "format": "button",
          "edited": false,
          "required": false
    }
  ]
},{
  "module": "О проекте",
  "page": 1,
  "fields": [{
    "sysName": "project_mvpCode",
    "localName": "Стадия развития продукта",
    "type": "array",
    "format": "text",
    "activity": [27000],
    "edited": false,
    "required": false
  }, {
      "sysName": "project_sales",
      "localName": "Продажи",
      "type": "array",
      "format": "text",
      "activity": [5000],
      "edited": false,
      "required": false
    }, {
      "sysName": "investment_turnover",
      "localName": "Оборот в год(USD)",
      "type": "string",
      "edited": false,
      "required": false
    }, {
    "sysName": "project_demoSite",
    "localName": "Ссылка на демо",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "project_demoVideo",
    "localName": "Видео о продукте",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },
    {
      "sysName": "investment_businessPlan",
      "localName": "Презентация",
      "type": "hyperlink",
      "title": "Смотреть",
      "format": "filebutton",
      "edited": false,
      "required": false
    },{
      "sysName": "project_pitchVideo",
      "localName": "Видео питча",
      "type": "hyperlink",
      "title": "Смотреть",
      "format": "button",
      "edited": false,
      "required": false

    },  {
      "sysName": "project_geography",
      "localName": "Рынки, на которых работает стартап",
      "type": "array",
      "format": "text",
      "activity": [2000],
      "edited": false,
      "required": false
    },{
      "sysName": "project_expansion",
      "localName": "Рынки, на которые стартап планирует выйти в будущем",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }
  ]
}, {
  "module": "Конкуренты",
  "page": 1,
  "fields": [{
    "sysName": "project_competitor",
    "localName": "Прямые конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_indirectCompetitor",
    "localName": "Косвенные конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_upSide",
    "localName": "Преимущества перед конкурентами",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_downSide",
    "localName": "Недостатки перед конкурентами ",
    "type": "string",
    "edited": false,
    "required": false
  }
  ]
}, {
  "module": "Команда",
  "page": 1,
  "fields": [


    {
      "sysName": "questionnaire_locationCountry",
      "localName": "Страна, где находится команда",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },
    {
      "sysName": "questionnaire_location",
      "localName": "Город, где находится команда",
      "type": "string",
      "edited": false,
      "required": false
    },
    {
      "sysName": "project_staff",
      "localName": "Общее количество сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }
  ]
},  {
  "module": "",
  "page": 1,
  "isArray": "true",
  "moduleFormat" : "card",
  "fields": [{
    "sysName": "workers[]_parentId",
    "localName": "",
    "type": "long",
    "format": "hide",
    "edited": false,
    "required": false
  },{
    "sysName": "workers[]_role",
    "localName": "Ключевые члены команды",
    "type": "string",
    "format": "heading",
    "edited": false,
    "required": false
  },{
    "sysName": "workers[]_note",
    "localName": "Опыт",
    "type": "string",
    "format": "body",
    "edited": false,
    "required": false
  }
  ]
}, {
"module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
"moduleNote": "",
"page": 1,
"pageName": "",
"isArray": "true",
"moduleFormat" : "card",
"fields": [
{
"sysName": "b2bPilots[]_state",
"localName": "",
"type": "array",
"format": "hide",
"value": "20007",
"edited": false,
"required": false
},
{
"sysName": "b2bPilots[]_reference",
"localName": "",
"type": "string",
"format": "heading",
"edited": false,
"required": false
},
{
"sysName": "b2bPilots[]_suggestCase",
"localName": "",
"type": "string",
"format": "body",
"edited": false,
"required": false
}
]
}, {
  "module": "Успешные B2C-, C2C- кейсы",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "moduleFormat" : "card",
  "fields": [
    {
      "sysName": "b2cPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "format": "heading",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "format": "body",
      "edited": false,
      "required": false
    }
  ]
},{
  "module": "Инвестиции",
  "page": 1,
  "fields": [{
    "sysName": "investment_investment",
    "localName": "Проект привлекает инвестиции",
    "type": "boolean",
    "format": "switch",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_round",
    "localName": "Раунд",
    "type": "array",
    "format": "chip",
    "activity": [6000],
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_sumInvestment",
    "localName": "Требуемая сумма (USD)",
    "type": "int",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "mask": "splitter",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_lastInvestment",
    "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_coInvestment",
    "localName": "Имя/ имена инвестора/ инвесторов",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }
  ]
}
]
}' WHERE formname='startup_SuperClient';
