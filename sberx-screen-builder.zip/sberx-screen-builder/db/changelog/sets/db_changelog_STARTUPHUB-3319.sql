--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3319
insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('startup_Administrator', true, true, false, 20012);
insert into public.screen_button (name, admin_check, main_check, state) values ('startup_Administrator', true, false, 20012);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('corporate_Administrator', true, true, false, 20012);
insert into public.screen_button (name, admin_check, main_check, state) values ('corporate_Administrator', true, false, 20012);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('investor_Administrator', true, true, false, 20012);
insert into public.screen_button (name, admin_check, main_check, state) values ('investor_Administrator', true, false, 20012);


insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20003' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20004' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20009' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '100002' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20003' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20004' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20009' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '100002' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20003' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20004' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20009' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20012 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '100002' limit 1));


insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20012 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20003' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20012 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20004' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20012 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20003' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20012 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20004' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20012 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20003' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20012 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20004' limit 1));


delete
from public.screen_button sb
where sb."name" in ('startup_Administrator','corporate_Administrator','investor_Administrator')
  and state = 20002;

delete from public.screen_buttons_link where screen_id not in (select screen_id from screen_button);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('startup_Administrator', true, true, false, 20002);
insert into public.screen_button (name, admin_check, main_check, state) values ('startup_Administrator', true, false, 20002);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('corporate_Administrator', true, true, false, 20002);
insert into public.screen_button (name, admin_check, main_check, state) values ('corporate_Administrator', true, false, 20002);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('investor_Administrator', true, true, false, 20002);
insert into public.screen_button (name, admin_check, main_check, state) values ('investor_Administrator', true, false, 20002);

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20002 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20012' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20002 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '100002' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20002 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20012' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20002 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '100002' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20002 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '20012' limit 1));
insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20002 and main_check = true limit 1),
                                                           (select button_id from public.buttons where code = '100002' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'startup_Administrator' and state = 20002 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20012' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'corporate_Administrator' and state = 20002 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20012' limit 1));

insert into screen_buttons_link (screen_id, button_id) values
                                                           ((select screen_id from public.screen_button sb where name = 'investor_Administrator' and state = 20002 and main_check != true limit 1),
                                                           (select button_id from public.buttons where code = '20012' limit 1));