--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.pages
set page = '{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "startups_en_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Main",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Find a startup",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "startups_en_pageTitle",
      "title": "Startups on the platform",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "startups_en_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Enter your request or use the filter",
      "participant": "startup",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}",
          "filterBar": {
              "title": "Filters",
              "acceptButtonText": "Apply filter",
              "resetButtonText": "Clear filter",
              "acceptButtonShortText": "Apply",
              "resetButtonShortText": "Clear",
              "placeholder": "search"
          },
          "popupFooter": {
              "caption": "To view the full startup profile, register or login in to the platform",
              "mainButtonText": "Join",
              "secondButtonText": "Enter"
          },
      "features": [
        {
          "type": "authBanner",
          "sysName": "startups_en_authBanner",
          "visible": true,
          "position": 1,
          "typeBanner": "participantSearch",
          "title": "More startups",
          "caption": "are available after registration on the SberUnity platform",
          "mainButtonText": "Join",
          "secondButtonText": "Log in",
          "config": {
            "nowrap": true
          }
        }
      ]
    }
  ]
}'
where uri = '/startup'
  and code = 'startups_nz_unauth_en';