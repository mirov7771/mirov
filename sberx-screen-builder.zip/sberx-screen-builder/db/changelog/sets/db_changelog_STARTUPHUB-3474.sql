--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-3474
update public.values
set  value='**Соинвестируйте**  \nс профессионалами'
where value ='**Соинвестируйте** с профессионалами';

update public.values
set  value='Присоединитесь  \nк сообществу'
where value ='Присоединитесь к нам';

update public.values
set  value='Дождитесь проверки анкеты'
where value ='Дождитесь результата';

update public.values
set  value='В течение 3-х дней мы рассмотрим Вашу анкету и вернёмся с обратной связью'
where value ='В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью';