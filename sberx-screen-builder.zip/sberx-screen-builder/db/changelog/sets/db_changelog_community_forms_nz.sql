--liquibase formatted sql
--changeset Mirov AA:community_forms_nz
delete from public.screen where formname like 'New_PreAuth_Community%';
insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_PreAuth_Community', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "role",
                    "localName": "Выберите роль*",
                    "type": "array",
                    "format": "choice_blocks",
                    "edited": true,
                    "required": true,
                    "items": [
                        {
                            "title": "Стартап",
                            "content": "Сообщество доступно участникам SberUnity",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_StartUp&action=1&preauthorize=true",
                            "clickMethod": "GET"
                        },
                        {
                            "title": "Инвестор",
                            "content": "Доступно фондам, бизнес-ангелам и фэмили офисам",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                            "clickMethod": "GET"
                        },
                        {
                            "title": "Корпорация",
                            "content": "Сообщество корпораций в разработке",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_Corporate&action=2&preauthorize=true",
                            "clickMethod": "GET"
                        }
                    ]
                }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_PreAuth_Community_Corporate', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "fio",
                    "localName": "ФИО*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Иванов Иван Иванович"
                },
                {
                    "sysName": "name",
                    "localName": "Название компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Сайт компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в стартапе*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 4
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);


insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_PreAuth_Community_VentureFond', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
{
    "sysName": "investorType",
    "localName": "Выберите подроль инвестора*",
    "type": "array",
    "format": "chip_selected",
    "multySelect": false,
    "edited": true,
    "required": true,
    "items": [
        {
            "content": "Венчурный фонд",
            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
            "default": true,
            "clickMethod": "GET"
        },
        {
            "content": "Бизнес-ангел",
            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Фэмили офис",
            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
            "clickMethod": "GET"
        }
    ]
},
                {
                    "sysName": "name",
                    "localName": "Название фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в фонде*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 2
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_PreAuth_Community_BusinessAngel', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
{
    "sysName": "investorType",
    "localName": "Выберите подроль инвестора*",
    "type": "array",
    "format": "chip_selected",
    "multySelect": false,
    "edited": true,
    "required": true,
    "items": [
        {
            "content": "Венчурный фонд",
            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2",
            "clickMethod": "GET"
        },
        {
            "content": "Бизнес-ангел",
            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2",
            "default": true,
            "clickMethod": "GET"
        },
        {
            "content": "Фэмили офис",
            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2",
            "clickMethod": "GET"
        }
    ]
},
                {
                    "sysName": "name",
                    "localName": "В каком сообществе бизнес-ангелов Вы уже состоите?",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 1
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_PreAuth_Community_FamilyOffice', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
{
    "sysName": "investorType",
    "localName": "Выберите подроль инвестора*",
    "type": "array",
    "format": "chip_selected",
    "multySelect": false,
    "edited": true,
    "required": true,
    "items": [
        {
            "content": "Венчурный фонд",
            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Бизнес-ангел",
            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Фэмили офис",
            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
            "clickMethod": "GET"
        }
    ]
},
                {
                    "sysName": "name",
                    "localName": "Название family office*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 3
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_PreAuth_Community', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "role",
                    "localName": "Выберите роль*",
                    "type": "array",
                    "format": "choice_blocks",
                    "edited": true,
                    "required": true,
                    "items": [
                        {
                            "title": "Стартап",
                            "content": "Сообщество доступно участникам SberUnity",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_StartUp&action=1&preauthorize=true",
                            "clickMethod": "GET"
                        },
                        {
                            "title": "Инвестор",
                            "content": "Доступно фондам, бизнес-ангелам и фэмили офисам",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                            "clickMethod": "GET"
                        },
                        {
                            "title": "Корпорация",
                            "content": "Сообщество корпораций в разработке",
                            "clickAction": "view?type=11&name=New_PreAuth_Community_Corporate&action=2&preauthorize=true",
                            "clickMethod": "GET"
                        }
                    ]
                }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_PreAuth_Community_Corporate', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "fio",
                    "localName": "ФИО*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Иванов Иван Иванович"
                },
                {
                    "sysName": "name",
                    "localName": "Название компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Сайт компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в стартапе*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 4
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);


insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_PreAuth_Community_VentureFond', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
{
    "sysName": "investorType",
    "localName": "Выберите подроль инвестора*",
    "type": "array",
    "format": "chip_selected",
    "multySelect": false,
    "edited": true,
    "required": true,
    "items": [
        {
            "content": "Венчурный фонд",
            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
            "default": true,
            "clickMethod": "GET"
        },
        {
            "content": "Бизнес-ангел",
            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Фэмили офис",
            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
            "clickMethod": "GET"
        }
    ]
},
                {
                    "sysName": "name",
                    "localName": "Название фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в фонде*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "investorType",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": false,
                    "required": false,
                    "value": 2
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_PreAuth_Community_BusinessAngel', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
{
    "sysName": "investorType",
    "localName": "Выберите подроль инвестора*",
    "type": "array",
    "format": "chip_selected",
    "multySelect": false,
    "edited": true,
    "required": true,
    "items": [
        {
            "content": "Венчурный фонд",
            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Бизнес-ангел",
            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
            "default": true,
            "clickMethod": "GET"
        },
        {
            "content": "Фэмили офис",
            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
            "clickMethod": "GET"
        }
    ]
},
                {
                    "sysName": "name",
                    "localName": "В каком сообществе бизнес-ангелов Вы уже состоите?",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 1
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_PreAuth_Community_FamilyOffice', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
{
    "sysName": "investorType",
    "localName": "Выберите подроль инвестора*",
    "type": "array",
    "format": "chip_selected",
    "multySelect": false,
    "edited": true,
    "required": true,
    "items": [
        {
            "content": "Венчурный фонд",
            "clickAction": "view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Бизнес-ангел",
            "clickAction": "view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
            "clickMethod": "GET"
        },
        {
            "content": "Фэмили офис",
            "clickAction": "view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
            "default": true,
            "clickMethod": "GET"
        }
    ]
},
                {
                    "sysName": "name",
                    "localName": "Название family office*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 3
                },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
            ]
        }
    ]
}', 'Заявка на вступление в сообщество СберСтартап', 1, 1);

insert into public.screen (id, clientid, type, formname, formview, buttons, logofile, lang_id)
values ((select max(id)+1 from screen ), '111260',  11, 'New_PreAuth_Community_StartUp', '{
    "form": [
        {
            "module": "Вступление в сообщество доступно  участникам SberUnity",
            "page": 1,
            "fields": [
                {
                    "sysName": "",
                    "localName": "Войдите или зарегистрируйтесь, чтобы заполнить анкету на вступление в сообщество СберСтартап. Она находится в личном кабинете в разделе «Сообщество».",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}', '{
    "buttons": [
        {
            "type": "active",
            "action": "/auth",
            "variant": "primary",
            "text": "Присоединиться"
        },
        {
            "type": "active",
            "action": "/auth",
            "variant": "primary",
            "text": "Войти"
        }
    ]
}', '/file/il_sign_up.png', 1);

insert into public.screen (id, clientid, type, formname, formview, buttons, logofile, lang_id)
values ((select max(id)+1 from screen ), '8385',  11, 'New_PreAuth_Community_StartUp', '{
    "form": [
        {
            "module": "Вступление в сообщество доступно участникам SberUnity",
            "page": 1,
            "fields": [
                {
                    "sysName": "",
                    "localName": "Войдите или зарегистрируйтесь, чтобы заполнить анкету на вступление в сообщество СберСтартап. Она находится в личном кабинете в разделе «Сообщество».",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}', '{
    "buttons": [
        {
            "type": "active",
            "action": "/auth",
            "variant": "primary",
            "text": "Присоединиться"
        },
        {
            "type": "active",
            "action": "/auth",
            "variant": "primary",
            "text": "Войти"
        }
    ]
}', '/file/il_sign_up.png', 1);