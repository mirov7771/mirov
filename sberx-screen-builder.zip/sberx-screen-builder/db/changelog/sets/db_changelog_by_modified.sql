--liquibase formatted sql
--changeset Mirov AA:By_modified
update public.pages
set page = cast(replace(cast(page as text), 'By update date', 'By date modified') as json)
where cast(page as text) like '%By update date%';