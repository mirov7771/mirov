--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.pages
set page = '{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_en_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "links": [
                {
                    "text": "Forgot your password? ",
                    "linkText": "Recover",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "Don`t have an account? ",
                    "linkText": "Register",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Login",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Password",
                    "placeholder": "Enter password"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_loginForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_en_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "title": "We have updated the user agreement",
            "description": "Accept terms to continue using the SberUnity platform",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Continue",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_en_changePasswordForm",
            "titleForm": "Creating a new password",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Latin characters only ",
                "Minimum of 8 characters",
                "At least 6 different characters",
                "At least 1 uppercase and 1 lowercase letters",
                "At least 1 special symbol, for example \"! _ : ;\""
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "New password"

                },
                {
                    "type": "confirmPassword",
                    "label": "Confirm password",
                    "confirmPasswordLabel": "Confirm password"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Create a password",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_en_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "titleInfoForm": "The temporary password is no longer valid",
            "textDescription": "We have sent a new temporary password to your email **{email}**. After using it to login, you''ll have to set your own one.",
            "text": " If you don`t see an email, check the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_infoPasswordIsExpiredForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}'
where uri = '/auth'
  and code = 'auth_en';