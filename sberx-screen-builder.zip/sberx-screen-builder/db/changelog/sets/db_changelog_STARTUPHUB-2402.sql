--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2402
delete from public.screen where formname in ('corp_app_Administrator', 'invest_app_Administrator');
INSERT INTO screen
    (id, clientid, "type", formname, formview, buttons)
VALUES ((select max(id) + 1 from screen), '111260', 9, 'corp_app_Administrator', '{
  "form": [
    {
      "module": "Информация по заявке",
      "page": 1,
      "pageName": "application_orgFullName",
      "fields": [
        {
          "sysName": "application_firstName",
          "localName": "Имя",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_phone",
          "localName": "Телефон",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_position",
          "localName": "Должность",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_email",
          "localName": "Корпоративный email",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}', '{
  "buttons": [
    {
      "code": 20004,
      "text": "Согласовать"
    },
    {
      "code": 20009,
      "text": "Отклонить"
    },
    {
      "code": 20012,
      "text": "В работу"
    }
  ]
}');

INSERT INTO screen
    (id, clientid, "type", formname, formview, buttons)
VALUES ((select max(id) + 1 from screen), '8385', 9, 'corp_app_Administrator', '{
  "form": [
    {
      "module": "Информация по заявке",
      "page": 1,
      "pageName": "application_orgFullName",
      "fields": [
        {
          "sysName": "application_firstName",
          "localName": "Имя",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_phone",
          "localName": "Телефон",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_position",
          "localName": "Должность",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_email",
          "localName": "Корпоративный email",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}', '{
  "buttons": [
    {
      "code": 20004,
      "text": "Согласовать"
    },
    {
      "code": 20009,
      "text": "Отклонить"
    },
    {
      "code": 20012,
      "text": "В работу"
    }
  ]
}');


INSERT INTO screen
    (id, clientid, "type", formname, formview, buttons)
VALUES ((select max(id) + 1 from screen), '111260', 9, 'invest_app_Administrator', '{
  "form": [
    {
      "module": "Информация по заявке",
      "page": 1,
      "pageName": "application_investorType+application_orgFullName",
      "fields": [
        {
          "sysName": "application_firstName",
          "localName": "Имя",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_phone",
          "localName": "Телефон",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_position",
          "localName": "Должность",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_email",
          "localName": "Корпоративный email",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}', '{
  "buttons": [
    {
      "code": 20004,
      "text": "Согласовать"
    },
    {
      "code": 20009,
      "text": "Отклонить"
    },
    {
      "code": 20012,
      "text": "В работу"
    }
  ]
}');

INSERT INTO screen
    (id, clientid, "type", formname, formview, buttons)
VALUES ((select max(id) + 1 from screen), '8385', 9, 'invest_app_Administrator', '{
  "form": [
    {
      "module": "Информация по заявке",
      "page": 1,
      "pageName": "application_investorType+application_orgFullName",
      "fields": [
        {
          "sysName": "application_firstName",
          "localName": "Имя",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_phone",
          "localName": "Телефон",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_position",
          "localName": "Должность",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_email",
          "localName": "Корпоративный email",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "application_site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}', '{
  "buttons": [
    {
      "code": 20004,
      "text": "Согласовать"
    },
    {
      "code": 20009,
      "text": "Отклонить"
    },
    {
      "code": 20012,
      "text": "В работу"
    }
  ]
}');

update screen
set buttons = '{
  "buttons": [
    {
      "code": 20003,
      "text": "На доработку"
    },
    {
      "code": 20004,
      "text": "Согласовать"
    },
    {
      "code": 20009,
      "text": "Отклонить"
    }
  ]
}'
where formname in ('corporate_Administrator', 'investor_Administrator', 'startup_Administrator');



