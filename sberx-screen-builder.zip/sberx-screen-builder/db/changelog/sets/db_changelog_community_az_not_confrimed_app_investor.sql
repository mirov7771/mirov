--liquibase formatted sql
--changeset Mirov AA:community_az_not_confrimed_app_investor
update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APP_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "title": "**СберСтартап**  \\nсообщество",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "inactive",
          "text": "Заявка уже отправлена",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "bulletBanner",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcBulletBanner_investor_1",
      "visible": true,
      "header": "**Соинвестируйте** с профессионалами",
      "bullets": [
        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
        "Обеспечьте себе поток лучших сделок",
        "Расширьте портфель за счёт низкого входного чека",
        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
      ],
      "position": 2,
      "config": {
        "direction": "left"
      },
      "description": null,
      "backgroundColor": "#FFFFFF",
      "imageUrl": "/file/bullet-banner-invest.png"
    },
    {
      "type": "rectangTiles",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcRectangTiles_investor_1",
      "visible": true,
      "header": "Уже в сообществе",
      "position": 3,
      "config": {},
      "description": null,
      "items": [
        {
          "imageUrl": "/file/rectang_tiles_logo1.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo2.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo3.png"
        },
        {
          "imageUrl": "/file/rectang_tiles_logo4.png"
        }
      ]
    },
    {
      "type": "squareRow",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSquareRow_investor_1",
      "visible": true,
      "header": "Большая **воронка стартапов** на российском рынке",
      "description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
      "position": 4,
      "items": [
        {
          "title": "Знакомим",
          "description": "с основателями стартапов",
          "iconUrl": "/file/squareRow_1.svg"
        },
        {
          "title": "Проводим",
          "description": "предварительный скоринг",
          "iconUrl": "/file/squareRow_2.svg"
        },
        {
          "title": "Рекомендуем",
          "description": "только отобранные проекты",
          "iconUrl": "/file/squareRow_3.svg"
        },
        {
          "title": "Объединяем",
          "description": "инвесторов и стартапы",
          "iconUrl": "/file/squareRow_4.svg"
        }
      ],
      "config": {}
    },
    {
      "type": "rectangTiles",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcRectangTiles_investor_2",
      "visible": true,
      "header": "Наши акселераторы",
      "position": 5,
      "config": {},
      "description": null,
      "items": [
        {
          "url": "https://sberbank-500.ru/",
          "imageUrl": "//file/logo_1_accelerator.png"
        },
        {
          "imageUrl": "//file/logo_2_accelerator.png",
          "url": "https://sberstudent.sberclass.ru/"
        },
        {
          "imageUrl": "//file/logo_3_accelerator.png",
          "url": "https://sber-up.ru/"
        },
        {
          "imageUrl": "//file/logo_4_accelerator.png",
          "url": "https://sber-z.sberclass.ru/"
        }
      ]
    },
    {
      "type": "bulletBanner",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcBulletBanner_investor_2",
      "visible": true,
      "header": "**Всё, что нужно —** уже под рукой",
      "description": "Мы организовали сообщество в Slack-каналах",
      "position": 6,
      "config": {
        "direction": "left"
      },
      "backgroundColor": "#F4F5F9",
      "imageUrl": "/file/bullet-banner-opportunities.png",
      "bullets": [
        "Разделите деловые и личный мессенджеры",
        "Структурируйте инофрмацию в тематических каналах",
        "Только релевантные сообщения, без спама и рекламы",
        "Полная информация о любой сделке всегда в паре кликов"
      ]
    },
    {
      "type": "carousel",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcCarousel_1",
      "visible": true,
      "position": 7,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      }
    },
    {
      "type": "events",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "position": 8,
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ]
    },
    {
      "type": "socialTiles",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "position": 9,
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_2",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=1V5r1",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=ZpLRc",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "config": {}
    },
    {
      "type": "banner",
      "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "position": 10,
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "INVESTOR_AZ_NOT_CONFIRMED_APPcFooterBanner_1_button_1",
          "category": "simple",
          "default": "inactive",
          "text": "Заявка уже отправлена",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ]
    }
  ]
}'
where code = 'community_az_not_confrimed_app_investor';
