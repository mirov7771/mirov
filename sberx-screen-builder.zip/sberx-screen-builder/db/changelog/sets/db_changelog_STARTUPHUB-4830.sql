--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-4830 Правка JSON для просмотра собственной анкеты

update screen set description = 'Full information about your startup is visible only to corporations and investors' where formname = 'startup_Administrator' and lang_id = 2;
update screen set description = 'Полная информация о вашем стартапе видна только корпорациям и инвесторам' where formname = 'startup_Administrator' and lang_id = 1;