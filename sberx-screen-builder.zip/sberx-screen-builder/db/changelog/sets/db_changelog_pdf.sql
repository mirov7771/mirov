--liquibase formatted sql
--changeset Mirov AA:PDF
update screen set
    formedit = cast(replace(cast(formedit as text),'20 Мб','50 Мб') as json)
where cast(formedit as text) like '%20 Мб%';