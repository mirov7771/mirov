--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-4555
delete
from public.screen s
where s.formname in
      ('syndicate_Administrator', 'offer_Client', 'startup_AdministratorBran', 'vas', 'round_short_Administrator',
       'round_short_Administrator', 'community_Administrator', 'reply_SuperClient', 'pilot_BusinessUnit',
       'offer_SuperClient', 'corporate_SuperClient', 'startup_Administrator', 'syndicate_SyndicateUser',
       'New_Corporate', 'corporate_edit', 'New_Investor', 'investor_edit', 'investor_SuperClient', 'New_scouting',
       'corporate_blur', 'startup_blur', 'investor_blur', 'pilot_SuperClient_Extra', 'pilot_Client_Extra',
       'investor_BusinessUnit', 'scouting_edit', 'New_vas', 'investor_Administrator', 'New_scouting', 'scouting_edit',
       'startup_SuperStartup', 'New_Community_FamilyOffice', 'investor_Client', 'pilot_AdministratorBran',
       'pilot_Administrator', 'round_Administrator', 'reply_Client', 'corp_app_Administrator',
       'invest_app_Administrator', 'pilot', 'New_vas', 'startup_SuperClient', 'New_Company', 'сompany_edit',
       'vas_SuperClient', 'vas_edit', 'New_Company', 'сompany_edit', 'vas_edit', 'New_Pilot', 'corporate_Administrator',
       'pilot_Client', 'New_Community_Corporate', 'New_Community_Mentor', 'New_Community_StartUp',
       'New_Community_BusinessAngel', 'New_PreAuth_Community', 'New_PreAuth_Community_Corporate',
       'New_PreAuth_Community_VentureFond', 'New_PreAuth_Community_FamilyOffice', 'vas_Client', 'corporate_Client',
       'New_Community_VentureFond', 'New_PreAuth_Community_BusinessAngel', 'investor_AdministratorBran',
       'corporate_Administrator', 'corporate_BusinessUnit', 'startup_BusinessUnit', 'Dossier',
       'corporate_AdministratorBran', 'pilot_SuperClient', 'startup_Client', 'New_PreAuth_Community_StartUp',
       'pilot_edit')
  and s.lang_id = 2;
INSERT INTO public.screen (type, formname, formedit, formview, "name", lang_id)
VALUES (12, 'syndicate_Administrator', NULL,
        '{
           "form":[
              {
                 "page":1,
                 "fields":[
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"firstName",
                       "required":false,
                       "localName":"Name"
                    },
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"lastName",
                       "required":false,
                       "localName":"Surname"
                    },
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"phone",
                       "required":false,
                       "localName":"Phone number"
                    },
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"email",
                       "required":false,
                       "localName":"Email"
                    },
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"telegramLink",
                       "required":false,
                       "localName":"Nickname in Telegram"
                    },
                    {
                       "type":"hyperlink",
                       "edited":false,
                       "format":"button",
                       "sysName":"site",
                       "required":false,
                       "localName":"Project website"
                    },
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"orgFullName",
                       "required":false,
                       "localName":"Company name"
                    },
                    {
                       "type":"string",
                       "edited":false,
                       "sysName":"ventureExperience",
                       "required":false,
                       "localName":"Venture experience"
                    },
                    {
                       "type":"array",
                       "edited":false,
                       "format":"search_dropdown",
                       "sysName":"sumInvestment",
                       "activity":[
                          39000
                       ],
                       "required":false,
                       "localName":"How much are you ready to invest?"
                    },
                    {
                       "type":"boolean",
                       "edited":false,
                       "sysName":"isUnity",
                       "required":false,
                       "localName":"Would you like to publish on SberUnity"
                    }
                 ],
                 "module":"Main information",
                 "pageName":""
              }
           ]
        }', 'View the profile of the syndicate',
        2),
       (7, 'offer_Client', '{
   "form":[
      {
         "page":1,
         "module":"Basic information",
         "moduleNote":"",
         "fields":[
            {
               "rows":"1",
               "type":"string",
               "edited":true,
               "example":"Name of proposed pilot",
               "sysName":"reply_offerName",
               "required":true,
               "localName":"Pilot name",
               "maxLength":"140"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Tell us about the proposed technologyи",
               "sysName":"reply_offerDescription",
               "required":true,
               "localName":"Brief description of the pilot",
               "maxLength":"500"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Description",
               "sysName":"reply_note",
               "required":true,
               "localName":"What corporate need will you solve?",
               "maxLength":"300"
            },
            {
               "mask":"$",
               "note":"The amount you value your pilot run",
               "type":"string",
               "edited":true,
               "example":"$",
               "sysName":"reply_cost",
               "required":false,
               "localName":"What is the cost of your solution",
               "maxLength":"30"
            },
            {
               "note":"Terms, steps, special conditions, restrictions and such like",
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Comment",
               "sysName":"reply_process",
               "required":true,
               "localName":"How do you see the piloting process",
               "minLength":"50",
               "maxLength":"500"
            }
         ]
      },
      {
         "page":1,
         "module":"Presentation",
         "moduleNote":"",
         "fields":[
            {
               "note":"File weight - no more than 5 MB, PDF format",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
               "description":"Increases the chances of attracting investors and corporations, but not required",
               "maxLength":"5",
               "allowedTypes":[
                  ".pdf"
               ]
            }
         ]
      }
   ]
}', NULL, 'Application for piloting', 2),
       (0, 'startup_AdministratorBran', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Te",
               "edited":true,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Company name"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":true,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"resourse"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":true,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logo"
            }
         ],
         "module":"About project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or technology ready for implementation"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL demo link"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"Problem that the project solves"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before??"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investorр"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":false,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of the organization"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":false,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of the registration"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone nuber"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Resourse"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":false,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL demo link"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors"
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (3, 'vas', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"empty_field",
               "required":false,
               "localName":"To take advantage of the service offer, join the platform"
            }
         ],
         "module":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"",
               "required":false,
               "localName":"To take advantage of the service offer, join the platform"
            }
         ],
         "module":""
      }
   ]
}', NULL, 2),
       (4, 'round_short_Administrator', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Short name of the requested technology in the nominative case",
               "type":"string",
               "edited":true,
               "example":"Requested technology name",
               "sysName":"name",
               "required":true,
               "localName":"Pilot name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"What business need will startups solve as part of the pilot?",
               "type":"string",
               "edited":true,
               "example":"Tell us about the requested technology",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":true,
               "example":"Subdivision name",
               "sysName":"businessUnit",
               "required":false,
               "localName":"Subdivision",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "example":"Specify industry",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"industry",
               "multySelect":true
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"pilotId",
               "required":false,
               "localName":""
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Pdf file up to 5 MB",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"demoFile",
               "required":false,
               "localName":"Requirements",
               "maxLength":"5",
               "description":"You can attach more detailed technical task for the pilot or a description of the case in a PDF file. The field is optional.",
               "allowedTypes":[
                  ".pdf"
               ]
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":true,
               "edited":true,
               "format":"hide",
               "sysName":"file",
               "required":true,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":true,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Technical task",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"true",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "example":"Question text",
               "sysName":"response[]_question",
               "required":false,
               "localName":"",
               "maxLength":"100"
            }
         ],
         "module":"Questions for a startup",
         "isArray":true,
         "subTitle":"Question №",
         "actionText":"Add a question",
         "moduleNote":"Here you can ask additional questions to the startup, which кmust be answered when applying for a pilot"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"pilotId",
               "required":true,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Title",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":true,
               "sysName":"businessUnit",
               "required":true,
               "localName":"Department",
               "maxLength":"200",
               "showLength":false
            },
            {
               "note":"What need will startups solve as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"suggestCase",
               "required":true,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"conditions",
               "required":true,
               "localName":"Conditions of piloting",
               "maxLength":"300"
            },
            {
               "type":"array",
               "edited":true,
               "format":"serch_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Add theme or direction",
               "multySelect":true
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"file",
               "required":true,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":true,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"string",
               "value":"20004",
               "edited":true,
               "format":"hide",
               "sysName":"state",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"true",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"response[]_question",
               "required":false,
               "localName":"Question text",
               "maxLength":"100"
            },
            {
               "note":"Additional information, clarification of the question",
               "type":"string",
               "edited":true,
               "sysName":"response[]_questionDescription",
               "required":false,
               "localName":"Description",
               "maxLength":"100"
            }
         ],
         "module":"",
         "isArray":true,
         "actionText":"Add a question",
         "moduleNote":""
      }
   ]
}', 'Pilot editing', 2),
       (10, 'round_short_Administrator', NULL, '{
   "form":[
      {
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"roundType",
               "activity":[
                  6000
               ],
               "required":true,
               "localName":"Round stage"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"otherDescription",
               "required":false,
               "localName":"The purpose of attracting investments"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Planned jurisdiction of the deal"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"transactionType",
               "activity":[
                  14000
               ],
               "required":true,
               "localName":"Planned type of deal"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"planDate",
               "required":true,
               "localName":"Planned start date for the round collection"
            }
         ],
         "module":"Main information"
      },
      {
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"sumInvestment",
               "required":true,
               "localName":"How much investment do you plan to attract?"
            },
            {
               "mask":"%",
               "type":"string",
               "edited":false,
               "sysName":"percent",
               "required":true,
               "localName":"For what percentage of the company?"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"preMoney",
               "required":true,
               "localName":"Pre-money"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"postMoney",
               "required":true,
               "localName":"Post-money"
            }
         ],
         "module":"Planned startup evaluation in the round"
      },
      {
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"inviteFio",
               "required":true,
               "localName":"Name of person to contact"
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Employee Email"
            },
            {
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"phone",
               "required":true,
               "localName":"Employee phone"
            }
         ],
         "module":"Contacts"
      }
   ]
}', NULL, 2),
       (11, 'community_Administrator', NULL, '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "fio",
                    "required": false,
                    "localName": "First Name, Last Name"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "name",
                    "required": false,
                    "localName": "Name"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "position",
                    "required": false,
                    "localName": "Position"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "site",
                    "required": false,
                    "localName": "Project website"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "What areas are you investing in?"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Interested geography of investments"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "round",
                    "activity": [
                        7000
                    ],
                    "required": false,
                    "localName": "Investment stages of interest"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "expectation",
                    "required": false,
                    "localName": "What do you expect to recieve from the community?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "useful",
                    "required": false,
                    "localName": "What can you give to the community?"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "ventureProjectsCount",
                    "required": false,
                    "localName": "Number of venture projects in the portfolio"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "email",
                    "required": false,
                    "localName": "Email"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "phoneNumber",
                    "required": false,
                    "localName": "Contact phone number"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "facebook",
                    "required": false,
                    "localName": "Your Facebook account"
                }
            ],
            "module": "Main information",
            "pageName": ""
        }
    ]
}', NULL, 2),
       (7, 'reply_SuperClient', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"hyperlink",
               "edited":false,
               "format":"hyperlink",
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_phoneNumber",
               "required":false,
               "localName":"Phone number"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"reply_cost",
               "required":true,
               "localName":"What is the cost of your solution"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"reply_process",
               "required":true,
               "localName":"How do you see the piloting process"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"reply_note",
               "required":false,
               "localName":"Transmittal letter"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Startup industry"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Startup technologies"
            }
         ],
         "module":"",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":""
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О- cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"response[]_question",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"response[]_responseNote",
               "required":false,
               "localName":""
            }
         ],
         "module":"Additional questions",
         "isArray":"true",
         "moduleFormat":"card"
      }
   ]
}', 'Response', 2),
       (4, 'pilot_BusinessUnit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"name",
               "required":true,
               "localName":"Title"
            },
            {
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "values":[
                  {
                     "code":"15001",
                     "name":"Optimization of current processes, costs"
                  },
                  {
                     "code":"15002",
                     "name":"Introduction of new functions, new revenue channels"
                  },
                  {
                     "code":"15003",
                     "name":"Other"
                  }
               ],
               "sysName":"target",
               "required":true,
               "localName":"Goal"
            },
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"targetOption",
               "required":false,
               "localName":"Your choice of goal",
               "triggerfield":"target",
               "triggervalue":"15003"
            },
            {
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Describe the problem"
            },
            {
               "note":"1 — the problem is optional, 10 — need to solve in a quarter",
               "type":"star",
               "edited":true,
               "values":[
                  {
                     "code":"1",
                     "name":"1"
                  },
                  {
                     "code":"2",
                     "name":"2"
                  },
                  {
                     "code":"3",
                     "name":"3"
                  },
                  {
                     "code":"4",
                     "name":"4"
                  },
                  {
                     "code":"5",
                     "name":"5"
                  },
                  {
                     "code":"6",
                     "name":"6"
                  },
                  {
                     "code":"7",
                     "name":"7"
                  },
                  {
                     "code":"8",
                     "name":"8"
                  },
                  {
                     "code":"9",
                     "name":"9"
                  },
                  {
                     "code":"10",
                     "name":"10"
                  }
               ],
               "sysName":"relevance",
               "required":true,
               "localName":"Importance and urgency of the problem"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"17001",
                     "name":"Yes"
                  },
                  {
                     "code":"17002",
                     "name":"No"
                  },
                  {
                     "code":"17003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"effect",
               "required":true,
               "localName":"Is it possible to measure the economic effect of solving a problem?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"18001",
                     "name":"Yes"
                  },
                  {
                     "code":"18002",
                     "name":"No"
                  },
                  {
                     "code":"18003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"resources",
               "required":true,
               "localName":"Are there free resources to conduct the pilot before the end of this year?"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"search",
               "required":true,
               "localName":"Have you searched for a solution in the database yourself?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"16001",
                     "name":"No"
                  },
                  {
                     "code":"16002",
                     "name":"Yes, through internal development"
                  },
                  {
                     "code":"16003",
                     "name":"Yes, by working with an external company"
                  }
               ],
               "sysName":"exp",
               "required":true,
               "localName":"Have you tried to solve the problem yourself?"
            },
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"company",
               "required":false,
               "localName":"Companies",
               "triggerfield":"exp",
               "triggervalue":"16003"
            },
            {
               "type":"date",
               "edited":true,
               "format":"DD.MM.YYYY",
               "sysName":"deadline",
               "required":true,
               "localName":"Decision term"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"A product or technology that will fill your need",
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"decision",
               "required":false,
               "localName":"Describe the solution"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"isForeign",
               "required":false,
               "localName":"Ready to work with foreign companies?"
            },
            {
               "note":"Examples of companies that can solve your need",
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"decisionCompany",
               "required":false,
               "localName":"Companies"
            },
            {
               "note":"The demand will become public and companies registered in SberUnity will be able to respond to the request",
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"isHub",
               "required":false,
               "localName":"Publish on SberUnity showcase"
            }
         ],
         "module":"Additionally",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"name",
               "required":true,
               "localName":"Title"
            },
            {
               "type":"array",
               "edited":false,
               "format":"dropdown",
               "values":[
                  {
                     "code":"15001",
                     "name":"Optimization of current processes, costs"
                  },
                  {
                     "code":"15002",
                     "name":"Introduction of new functions, new revenue channels"
                  },
                  {
                     "code":"15003",
                     "name":"Other"
                  }
               ],
               "sysName":"target",
               "required":true,
               "localName":"Goal"
            },
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"targetOption",
               "required":false,
               "localName":"Your choice of goal",
               "triggerfield":"target",
               "triggervalue":"15003"
            },
            {
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Describe the problem"
            },
            {
               "note":"1 — the problem is optional, 10 — need to solve in a quarter",
               "type":"star",
               "edited":false,
               "sysName":"relevance",
               "required":true,
               "localName":"Importance and urgency of the problem"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"17001",
                     "name":"Yes"
                  },
                  {
                     "code":"17002",
                     "name":"No"
                  },
                  {
                     "code":"17003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"effect",
               "required":true,
               "localName":"Is it possible to measure the economic effect of solving a problem?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"18001",
                     "name":"Yes"
                  },
                  {
                     "code":"18002",
                     "name":"No"
                  },
                  {
                     "code":"18003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"resources",
               "required":true,
               "localName":"Are there free resources to conduct the pilot before the end of this year?"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"search",
               "required":true,
               "localName":"Have you searched for a solution in the database yourself?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"16001",
                     "name":"No"
                  },
                  {
                     "code":"16002",
                     "name":"Yes, through internal development"
                  },
                  {
                     "code":"16003",
                     "name":"Yes, by working with an external company"
                  }
               ],
               "sysName":"exp",
               "required":true,
               "localName":"Have you tried to solve the problem yourself?"
            },
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"company",
               "required":false,
               "localName":"Companies",
               "triggerfield":"exp",
               "triggervalue":"16003"
            },
            {
               "type":"date",
               "edited":false,
               "format":"calendar",
               "sysName":"deadline",
               "required":true,
               "localName":"Decision term"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"A product or technology that will fill your need",
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"decision",
               "required":false,
               "localName":"Describe the solution"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"isForeign",
               "required":false,
               "localName":"Ready to work with foreign companies?"
            },
            {
               "note":"Examples of companies that can solve your need",
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"decisionCompany",
               "required":false,
               "localName":"Companies"
            },
            {
               "note":"The demand will become public and companies registered in SberUnity will be able to respond to the request",
               "type":"boolean",
               "edited":false,
               "format":"checkbox",
               "sysName":"isHub",
               "required":false,
               "localName":"Publish on SberUnity showcase"
            }
         ],
         "module":"Additionaly",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (7, 'offer_SuperClient', NULL, '{
   "form":[
      {
         "page":1,
         "module":"Main information",
         "moduleNote":"",
         "fields":[
            {
               "rows":"1",
               "type":"string",
               "edited":false,
               "example":"Name of proposed pilot",
               "sysName":"reply_offerName",
               "required":false,
               "localName":"Pilot name",
               "minLength":"50",
               "maxLength":"500"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":false,
               "example":"Tell us about the proposed technology",
               "sysName":"reply_offerDescription",
               "required":false,
               "localName":"Brief description of the pilot",
               "minLength":"50",
               "maxLength":"500"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":false,
               "example":"Description",
               "sysName":"reply_note",
               "required":false,
               "localName":"What corporate need will you solve?",
               "minLength":"50",
               "maxLength":"500"
            },
            {
               "mask":"$",
               "note":"The amount you value your pilot run",
               "type":"string",
               "edited":false,
               "example":"$",
               "sysName":"reply_cost",
               "required":false,
               "localName":"What is the cost of your solution",
               "maxLength":"30"
            },
            {
               "note":"Deadlines, steps, special conditions, restrictions, etc.",
               "rows":"3",
               "type":"string",
               "edited":false,
               "example":"Comments",
               "sysName":"reply_process",
               "required":false,
               "localName":"How do you see the piloting process",
               "minLength":"50",
               "maxLength":"500"
            }
         ]
      },
      {
         "page":1,
         "module":"Presentation",
         "moduleNote":"",
         "fields":[
            {
               "note":"File weight - no more than 5 MB, PDF format",
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
               "description":"Increases the chances of attracting investors and corporations, but not required",
               "maxLength":"5",
               "allowedTypes":[
                  ".pdf"
               ]
            }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":""
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О- cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"response[]_question",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"response[]_responseNote",
               "required":false,
               "localName":""
            }
         ],
         "module":"Additional questions",
         "isArray":"true",
         "moduleFormat":"card"
      }
   ]
}', 'Review of the proposal by the Corporation', 2),
       (1, 'corporate_SuperClient', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Description"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":false,
               "localName":"Direction of activity"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Corporation website"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":false,
               "localName":"Methods of working with innovations"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":false,
               "localName":"Product development stages"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"technologies"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Industries"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_startupInvestmentYears",
               "required":false,
               "localName":"Years the corporation has been working with startups"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year"
            }
         ],
         "module":"Working with startups"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Demand description"
            }
         ],
         "module":"",
         "isArray":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography"
            }
         ],
         "module":"Investments"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Startup name"
            }
         ],
         "module":"Successful piloting cases",
         "isArray":true,
         "moduleFormat":"card",
         "triggerField":"investment_investment",
         "triggerValue":"true"
      }
   ]
}', 'Viewing the corporation profile', 2),
       (0, 'startup_Administrator', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"session_date",
               "required":false,
               "localName":"Visit time"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inn",
               "required":false,
               "localName":"TIN of the organization"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of registration",
               "maxLength":4
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":false,
               "localName":"Public name / brand name"
            },
            {
               "type":"hyperlink",
               "format":"URL",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_transcription",
               "required":false,
               "localName":"Transcription"
            },
            {
               "type":"text",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country of jurisdiction*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_phoneNumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "title":"Resourse",
               "edited":false,
               "format":"chip",
               "sysName":"contacts[]_type",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":""
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Additional contacts",
         "isArray":"true",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"User interaction business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"logo",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo"
            }
         ],
         "module":"About the project",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_demoSite",
               "required":false,
               "localName":"URL link to demo"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project"
            }
         ],
         "module":"Prototype",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Describe in 1-2 sentences",
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Download presentation"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"project_pitchVideo",
               "required":false,
               "localName":"Videos pitch"
            }
         ],
         "module":"About the project",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets you operate in"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets you plan to enter in the near future"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (in USD)"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_indirectCompetitor",
               "required":false,
               "localName":"Indirect competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_downSide",
               "required":false,
               "localName":"Disadvantages over competitors"
            }
         ],
         "module":"Competitors",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "localName":"Total number of employees"
            }
         ],
         "module":"Team",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"The role of the employee in the team"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Brief description of the experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":false,
               "localName":"If you are В2В-, В2G-, B2B2C- startup: do you have successful pilots or implementations in corporations?"
            }
         ],
         "module":"Successful pilots",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who had a successful case"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О- cases",
         "isArray":"true",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2cPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"b2cPilots[]_reference",
               "required":false,
               "localName":"Who had a successful case"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"b2cPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful B2C-, C2C- cases",
         "isArray":"true",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or with other corporations?*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"ecoPilot_suggestCase",
               "required":false,
               "localName":"Предлагаемый кейс*"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"ecoPilot_experience",
               "required":false,
               "localName":"Have you interacted with the Sber ecosystem before?*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"ecoPilot_businessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?*"
            }
         ],
         "module":"Sber Ecosystem",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"investment_investment",
               "required":false,
               "localName":"Are you actively looking for investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total"
            },
            {
               "note":"List all investors from whom you received investments, if disclosure of this information does not contradict agreements with them",
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name/ names of investor/ investors"
            }
         ],
         "module":"Investments",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_acceleratorCode",
               "activity":[
                  26000
               ],
               "required":false,
               "localName":"Is a graduate:"
            }
         ],
         "module":"Sber Accelerators",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_sber500",
               "required":false,
               "localName":"Does a startup want to apply for participation in Sber500?",
               "information":"Sber500 is a unique accelerator based on the capabilities of the Sber ecosystem and the expertise and experience of 500 Global"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"sberFiveHundred_firsttime",
               "required":false,
               "localName":"Has the startup been submitted to Sber500 before?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "example":"Specify the need",
               "sysName":"sberFiveHundred_ecorequirement",
               "activity":[
                  38000
               ],
               "required":false,
               "localName":"What need of the Sber Ecosystem does the startup cover?",
               "multySelect":true
            },
            {
               "type":"string",
               "edited":false,
               "regExp":"(^([0-9]{1,7}))",
               "sysName":"sberFiveHundred_monthrevenue",
               "required":false,
               "localName":"Revenue for the last month",
               "maxLength":"300",
               "showLength":false,
               "regExpError":"You must enter a number"
            },
            {
               "type":"string",
               "edited":false,
               "regExp":"(^([0-9]{1,7}))",
               "sysName":"sberFiveHundred_quarterrevenue",
               "required":false,
               "localName":"Revenue for the last 3 months",
               "maxLength":"300",
               "showLength":false,
               "regExpError":"You must enter a number"
            },
            {
               "type":"int",
               "edited":false,
               "format":"[1;1000]",
               "example":"Specify the number of clients",
               "sysName":"sberFiveHundred_clients",
               "maxValue":1000,
               "minValue":1,
               "required":false,
               "localName":"Number of active or paying customers in the last month"
            }
         ],
         "module":"Accelerator Sber500",
         "pageName":"Sber500"
      }
   ]
}', NULL, 2),
       (12, 'syndicate_SyndicateUser', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"firstName",
               "required":false,
               "localName":"First name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"lastName",
               "required":false,
               "localName":"Second name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"phone",
               "required":false,
               "localName":"Phone number"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"telegramLink",
               "required":false,
               "localName":"Telegram nickname"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"button",
               "sysName":"site",
               "required":false,
               "localName":"Project website"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"orgFullName",
               "required":false,
               "localName":"The name of the company"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"ventureExperience",
               "required":false,
               "localName":"Venture experience"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"sumInvestment",
               "activity":[
                  39000
               ],
               "required":false,
               "localName":"How much are you willing to invest?"
            }
         ],
         "module":"Main information",
         "pageName":""
      }
   ]
}', 'View syndicate profile', 2),
       (1, 'New_Corporate', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Enter the full juridical name of your company",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullName",
               "required":true,
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false
            },
            {
               "note":"Enter the year your company was founded",
               "type":"int",
               "edited":true,
               "format":"[1991;2021]",
               "sysName":"questionnaire_birthYear",
               "required":true,
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name",
               "maxLength":100,
               "showLength":false
            },
            {
               "note":"Select the country where your company is registered",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address"
            },
            {
               "note":"We recommend that you provide a link not to the main website of the company, but to a page that is most relevant to startups (for example, an accelerator landing page)",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Corporation website",
               "maxLength":"100",
               "showLength":false,
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"Juridical information about the organization",
         "pageName":"Juridical information about the organization",
         "moduleNote":""
      },
      {
         "page":2,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_fio",
               "required":true,
               "localName":"Name, surname of the representative"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_role",
               "required":true,
               "localName":"Position"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":true,
               "format":"phone",
               "example":"+",
               "sysName":"representative_phone",
               "required":true,
               "localName":"Mobile phone"
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"representative_email",
               "required":true,
               "localName":"Email"
            }
         ],
         "module":"Representative contact",
         "pageName":"Representative information",
         "moduleNote":"Specify an employee whom SberUnity administrators can contact regarding the placement of your profile"
      },
      {
         "page":2,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":true,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":""
            },
            {
               "note":" It is important for startups to see personalities. Specify the responsible person of the corporation, which will be seen by other participants of the platform",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Name, surname of the representative",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Indicate the position of the responsible person from the previous question",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Position",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Representative information",
         "actionText":"Add contact person"
      },
      {
         "page":3,
         "fields":[
            {
               "note":"Describe your company in one sentence",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Brief description",
               "maxLength":"150"
            },
            {
               "note":"Describe your company in more detail",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":true,
               "localName":"Full description",
               "maxLength":"480"
            },
            {
               "type":"array",
               "title":"Directions",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":true,
               "localName":"Direction of activity",
               "description":"List all industries relevant to your company",
               "multySelect":true
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ]
            }
         ],
         "module":"Corporation",
         "pageName":"Corporation information"
      },
      {
         "page":4,
         "fields":[
            {
               "type":"array",
               "title":"Methods of working with innovations",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":true,
               "localName":"Specify methods",
               "description":"Choose methods of innovations implementation in your corporation",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Stages of startup development",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Development stage",
               "description":"Select the stages of startup development you are interested in",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":true,
               "localName":"technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Directions",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Industries",
               "description":"List all relevant directions of your company",
               "multySelect":true
            }
         ],
         "module":"Working with startups",
         "pageName":"Conditions of working with startups"
      },
      {
         "page":5,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":true,
               "localName":"Does your company have experience of cooperation with startups?"
            },
            {
               "note":"Optional",
               "type":"int",
               "title":"Information about cooperation with startups",
               "edited":true,
               "sysName":"questionnaire_startupInvestmentYears",
               "required":false,
               "localName":"How many years has your corporation been working with startups",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            }
         ],
         "module":"Successful cases",
         "pageName":"Piloting"
      },
      {
         "page":6,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"investment_investment",
               "required":true,
               "localName":"Does your corporation invest in startups?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":true,
               "localName":"Investment round",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "note":"In startups from which regions you are ready to invest",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Geography of startups",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments",
         "pageName":"Investments"
      },
      {
         "page":6,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Startup name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"successPilots[]_suggestCase",
               "required":false,
               "localName":"Case description",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Successful cases",
         "isArray":true,
         "pageName":"Investments",
         "subTitle":"Startup №",
         "withIndex":true,
         "actionText":"Add case",
         "moduleNote":"Optional. Indicate the names of startups with which your company had successful implementations, if you want other SberUnity users to see information about them",
         "triggerField":"investment_investment",
         "triggerValue":true
      },
      {
         "page":7,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"questionnaire_scouting",
               "required":true,
               "localName":"Do you consider custom scouting as a tool for finding the right startups?"
            },
            {
               "sysName":"userConsent_mailingConsent",
               "localName":"I <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">argee</a> for the processing of personal data for the purpose of conducting analytical, statistical, marketing research and forming personal offers based on them",
               "type":"boolean",
               "format":"checkbox",
               "edited":true,
               "required":false
            }
         ],
         "module":"Scouting",
         "pageName":"Scouting"
      }
   ]
}', NULL, 'Corporation questionnaire', 2),
       (1, 'corporate_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Enter the full juridical name of your company",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullName",
               "required":true,
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false
            },
            {
               "note":"Enter the year your company was founded",
               "type":"int",
               "edited":true,
               "format":"[1991;2021]",
               "sysName":"questionnaire_birthYear",
               "required":true,
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name",
               "maxLength":100,
               "showLength":false
            },
            {
               "note":"Select the country where your company is registered",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email"
            },
            {
               "note":"We recommend that you provide a link not to the main website of the company, but to a page that is most relevant to startups (for example, an accelerator landing page)",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Corporation website",
               "maxLength":"100",
               "showLength":false,
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"Juridical information about the organization",
         "pageName":"Juridical information about the organization",
         "moduleNote":""
      },
      {
         "page":2,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_fio",
               "required":true,
               "localName":"Name, surname of the representative"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_role",
               "required":true,
               "localName":"Position"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":true,
               "format":"phone",
               "example":"+",
               "sysName":"representative_phone",
               "required":true,
               "localName":"Mobile phone"
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"representative_email",
               "required":true,
               "localName":"Email"
            }
         ],
         "module":"Representative contact",
         "pageName":"Representative information",
         "moduleNote":"Specify an employee whom SberUnity administrators can contact regarding the placement of your profile"
      },
      {
         "page":2,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":true,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":""
            },
            {
               "note":" It is important for startups to see personalities. Specify the responsible person of the corporation, which will be seen by other participants of the platform",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Name, surname of the representative",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Indicate the position of the responsible person from the previous question",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Position",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Representative information",
         "actionText":"Add contact person"
      },
      {
         "page":3,
         "fields":[
            {
               "note":"Describe your company in one sentence",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Краткое описание",
               "maxLength":"150"
            },
            {
               "note":"Describe your company in more detail",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":true,
               "localName":"Full description",
               "maxLength":"480"
            },
            {
               "type":"array",
               "title":"Directions",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":true,
               "localName":"Direction of activity",
               "description":"List all industries relevant to your company",
               "multySelect":true
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ]
            }
         ],
         "module":"Corporation",
         "pageName":"Corporation information"
      },
      {
         "page":4,
         "fields":[
            {
               "type":"array",
               "title":"Methods of working with innovations",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":true,
               "localName":"Specify methods",
               "description":"Choose methods of innovations implementation in your corporation",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Stages of startup development",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Development stage",
               "description":"Select the stages of startup development you are interested in",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":true,
               "localName":"technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Directions",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Industries",
               "description":"Indicate all areas relevant to your company",
               "multySelect":true
            }
         ],
         "module":"Working with startups",
         "pageName":"Conditions for working with startups"
      },
      {
         "page":5,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":true,
               "localName":"Does your company have experience of cooperation with startups?"
            },
            {
               "note":"Optional",
               "type":"int",
               "title":"Information about cooperation with startups",
               "edited":true,
               "sysName":"questionnaire_startupInvestmentYears",
               "required":false,
               "localName":"How many years has your corporation been working with startups",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            }
         ],
         "module":"Successful cases",
         "pageName":"Piloting"
      },
      {
         "page":6,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"investment_investment",
               "required":true,
               "localName":"Does your corporation invest in startups?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":true,
               "localName":"Investment round",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "note":"In startups from which regions you are ready to invest",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Geography of startups",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments",
         "pageName":"Investments"
      },
      {
         "page":6,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Startup name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"successPilots[]_suggestCase",
               "required":false,
               "localName":"Case description",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Successful cases",
         "isArray":true,
         "pageName":"Investments",
         "subTitle":"Startup №",
         "withIndex":true,
         "actionText":"Add case",
         "moduleNote":"Optional. Indicate the names of startups with which your company had successful implementations, if you want other SberUnity users to see information about them",
         "triggerField":"investment_investment",
         "triggerValue":true
      },
      {
         "page":7,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"questionnaire_scouting",
               "required":true,
               "localName":"Do you consider custom scouting as a tool for finding the right startups?"
            }
         ],
         "module":"Scouting",
         "pageName":"Scouting"
      }
   ]
}', NULL, 'Editing a corporation profile', 2),
       (2, 'New_Investor', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"questionnaire_investorType",
               "activity":[
                  11000
               ],
               "required":true,
               "localName":"Choose the type of investor",
               "multySelect":false
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name / brand name",
               "maxLength":100,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Your first and last name",
               "maxLength":100,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name / brand name",
               "maxLength":100,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"questionnaire_questionnaireid",
               "required":true,
               "localName":""
            },
            {
               "note":"Enter the full juridical name of your company",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Enter the year your company was founded",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_birthYear",
               "required":true,
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Select the country where your company is registered",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Enter the full juridical name of your company",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Enter the year your company was founded",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_birthYear",
               "required":true,
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Select the country where your company is registered",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            }
         ],
         "module":"General information",
         "pageName":"Profile data and general information"
      },
      {
         "page":1,
         "fields":[
            {
               "note":"For example, \"Fund and accelerator\"",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Provide a brief description of your fund",
               "maxLength":85,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"For example, \"I consider any projects\"",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Specify your brief description as a business angel",
               "maxLength":85,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"Indicate the country in which you make the main volume of venture deals",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"For example, \"Bezos Family Foundation\"",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Provide a brief description of your Family Office",
               "maxLength":85,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":true,
               "localName":"Provide a full description of your fund",
               "maxLength":1000,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Specify your full description as a business angel",
               "maxLength":1000,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":true,
               "localName":"Provide a full description of your Family Office",
               "maxLength":1000,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Website",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"string",
               "edited":false,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Website",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"ublic email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":true,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"Мы сделали поле обязательным, чтобы повысить качество базы участников",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Add photo",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download photo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            }
         ],
         "module":"Profile data",
         "pageName":"Profile data and general information"
      },
      {
         "page":2,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_fio",
               "required":true,
               "localName":"Last name First name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_role",
               "required":true,
               "localName":"Position"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":true,
               "format":"phone",
               "example":"+",
               "sysName":"representative_phone",
               "required":true,
               "localName":"Mobile phone"
            }
         ],
         "module":"Representative contact",
         "pageName":"Your data",
         "moduleNote":"Specify an employee whom SberUnity administrators can contact regarding the placement of your profile"
      },
      {
         "page":2,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":true,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":""
            },
            {
               "note":"It is important for startups to see personalities. Specify the responsible person of the fund, which will be seen by other platform participants.",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Last name First name",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Specify the position of the person from the previous question",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Position",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Your data",
         "actionText":"Add contact person",
         "modulenote":"Specify the employee that other users of the platform will see in your profile as a contact person"
      },
      {
         "page":3,
         "fields":[
            {
               "type":"array",
               "title":"Directions",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Industries",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"investment_technology",
               "activity":[
                  13000
               ],
               "required":true,
               "localName":"technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Geography of startups",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"investment_geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Geography of startups",
               "description":"In startups from which regions you are ready to invest",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":true,
               "localName":"Investment stages",
               "multySelect":true
            },
            {
               "note":"For example, impact startups, female founders, etc.",
               "type":"string",
               "edited":true,
               "sysName":"investment_note",
               "required":false,
               "localName":"Special investment conditions",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Investments",
         "pageName":"Investments",
         "moduleNote":"Select all technology areas, startup stages and geography you are considering for investment"
      },
      {
         "page":3,
         "fields":[
            {
               "note":"Number of portfolio projects to date",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_activeDealsNumber",
               "required":true,
               "localName":"Number of startups in the portfolio",
               "maxLength":4,
               "showLength":false
            },
            {
               "note":"Total number of investment rounds, including rounds with startups that you have already left",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_allDealsNumber",
               "required":true,
               "localName":"Number of transactions, total",
               "maxLength":4,
               "showLength":false
            },
            {
               "note":"Number of startups you have invested in and exited",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_exitDealsNumber",
               "required":true,
               "localName":"Number of outputs",
               "maxLength":4,
               "showLength":false
            }
         ],
         "module":"Portfolio startup data",
         "pageName":"Investments"
      },
      {
         "page":3,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":true,
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Startup name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnairePilots[]_site",
               "required":false,
               "localName":"Startup website link",
               "maxLength":"140",
               "showLength":false,
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"Startup examples",
         "isArray":"true",
         "pageName":"Investments",
         "withIndex":true,
         "actionText":"Add startup",
         "moduleNote":"Here you can list all or the most interesting startups in your portfolio"
      },
      {
         "page":4,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"questionnaire_club",
               "required":true,
               "localName":"Are you a member of any investment club/community?"
            }
         ],
         "module":"Investment clubs",
         "pageName":"Participation in investment clubs"
      },
      {
         "page":4,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"investorClubs[]_name",
               "required":false,
               "localName":"Club/community name"
            },
            {
               "note":"For example, \"Club founder\"",
               "type":"string",
               "edited":true,
               "sysName":"investorClubs[]_role",
               "required":false,
               "localName":"Your role in the club/community"
            }
         ],
         "module":"Community",
         "isArray":"true",
         "pageName":"Participation in investment clubs",
         "subTitle":"Club / Community №",
         "withIndex":true,
         "actionText":"Add club",
         "moduleNote":"We will be happy to start cooperation with these communities and offer additional benefits to its members",
         "triggerField":"questionnaire_club",
         "triggerValue":true
      },
      {
         "page":4,
         "fields":[
            {
               "sysName":"userConsent_mailingConsent",
               "localName":"I <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">agree</a> for the processing of personal data for the purpose of conducting analytical, statistical, marketing research and forming personal offers based on them",
               "type":"boolean",
               "format":"checkbox",
               "edited":true,
               "required":false
            }
         ],
         "module":"Communities",
         "pageName":"Participation in investment clubs"
      }
   ]
}', NULL, 'Investor questionnaire', 2),
       (2, 'investor_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"questionnaire_investorType",
               "activity":[
                  11000
               ],
               "required":true,
               "localName":"Choose the type of investor",
               "multySelect":false
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name / brand name",
               "maxLength":100,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Your first and last name",
               "maxLength":100,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"Specify under what name to display your profile for other platform participants",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name / brand name",
               "maxLength":100,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"questionnaire_questionnaireid",
               "required":true,
               "localName":""
            },
            {
               "note":"Enter the full legal name of your company",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Enter the year your company was founded",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_birthYear",
               "required":true,
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Select the country where your company is registered",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Enter the full legal name of your company",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Enter the year your company was founded",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_birthYear",
               "required":true,
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Select the country where your company is registered",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            }
         ],
         "module":"General information",
         "pageName":"Profile data and general information"
      },
      {
         "page":1,
         "fields":[
            {
               "note":"For example, \"Fund and accelerator\"",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Provide a brief description of your fund",
               "maxLength":85,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"For example, \"I consider any projects\"",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Specify your brief description as a business angel",
               "maxLength":85,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"Specify the country in which you make the bulk of venture deals",
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"For example, \"Bezos Family Foundation\"",
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Give a brief description of your Family Office",
               "maxLength":85,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":true,
               "localName":"Provide a full description of your fund",
               "maxLength":1000,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Specify your full description as a business angel",
               "maxLength":1000,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"questionnaire_fullNote",
               "required":true,
               "localName":"Provide a full description of your Family Office",
               "maxLength":1000,
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Website",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Website",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "note":"This mail will be visible to other members of the platform",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":true,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Logofile",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
               "type":"logo",
               "title":"Add photo",
               "edited":true,
               "format":"1200*1200",
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download photo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png",
                  ".jpg"
               ],
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            }
         ],
         "module":"Profile data",
         "pageName":"Profile data and general information"
      },
      {
         "page":2,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_fio",
               "required":true,
               "localName":"Last name First name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"representative_role",
               "required":true,
               "localName":"Position"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":true,
               "format":"phone",
               "example":"+",
               "sysName":"representative_phone",
               "required":true,
               "localName":"Mobile phone"
            }
         ],
         "module":"Representative contact",
         "pageName":"Your data",
         "moduleNote":"Specify an employee whom SberUnity administrators can contact regarding the placement of your profile"
      },
      {
         "page":2,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":true,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":""
            },
            {
               "note":"Specify an employee whom SberUnity administrators can contact regarding the placement of your profile",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Last name First name",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Specify the position of the person from the previous question",
               "type":"string",
               "edited":true,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Position",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Your data",
         "actionText":"Add contact person",
         "modulenote":"Specify the employee that other users of the platform will see in your profile as a contact person"
      },
      {
         "page":3,
         "fields":[
            {
               "type":"array",
               "title":"Directions",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Industries",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"investment_technology",
               "activity":[
                  13000
               ],
               "required":true,
               "localName":"technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Geography of startups",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"investment_geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Geography of startups",
               "description":"In startups from which regions you are ready to invest",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":true,
               "localName":"Investment stages",
               "multySelect":true
            },
            {
               "note":"For example, impact startups, female founders, etc.",
               "type":"string",
               "edited":true,
               "sysName":"investment_note",
               "required":false,
               "localName":"Special investment conditions",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Investments",
         "pageName":"Investments",
         "moduleNote":"Select all technology areas, startup stages and geography you are considering for investment"
      },
      {
         "page":3,
         "fields":[
            {
               "note":"Number of portfolio projects to date",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_activeDealsNumber",
               "required":true,
               "localName":"Number of startups in the portfolio",
               "maxLength":4,
               "showLength":false
            },
            {
               "note":"Total number of investment rounds, including rounds with startups that you have already left",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_allDealsNumber",
               "required":true,
               "localName":"Number of transactions, total",
               "maxLength":4,
               "showLength":false
            },
            {
               "note":"Number of startups you have invested in and exited",
               "type":"int",
               "edited":true,
               "sysName":"questionnaire_exitDealsNumber",
               "required":true,
               "localName":"Number of outputs",
               "maxLength":4,
               "showLength":false
            }
         ],
         "module":"Portfolio startup data",
         "pageName":"Investments"
      },
      {
         "page":3,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":true,
               "sysName":"questionnairePilots[]_company",
               "required":false,
               "localName":"Startup name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
               "sysName":"questionnairePilots[]_site",
               "required":false,
               "localName":"Startup website link",
               "maxLength":"140",
               "showLength":false,
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"Startup examples",
         "isArray":"true",
         "pageName":"Investments",
         "withIndex":true,
         "actionText":"Add startup",
         "moduleNote":"Here you can list all or the most interesting startups from your portfolio"
      },
      {
         "page":4,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"questionnaire_club",
               "required":true,
               "localName":"Are you a member of any investment club/community?"
            }
         ],
         "module":"Investment clubs",
         "pageName":"Participation in investment clubs"
      },
      {
         "page":4,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"investorClubs[]_name",
               "required":false,
               "localName":"Club/community name"
            },
            {
               "note":"For example, \"Club founder\"",
               "type":"string",
               "edited":true,
               "sysName":"investorClubs[]_role",
               "required":false,
               "localName":"Your role in the club/community"
            }
         ],
         "module":"Communities",
         "isArray":"true",
         "pageName":"Participation in investment clubs",
         "subTitle":"Club / Community №",
         "withIndex":true,
         "actionText":"Add club",
         "moduleNote":"We will be happy to start cooperation with these communities and offer additional benefits to its members",
         "triggerField":"questionnaire_club",
         "triggerValue":true
      }
   ]
}', NULL, 'Investor questionnaire editing', 2),
       (2, 'investor_SuperClient', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_investorType",
               "activity":[
                  11000
               ],
               "required":false,
               "localName":"Type of investor"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"string",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_note",
               "required":false,
               "localName":"Short description"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullnote",
               "required":false,
               "localName":"Description"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_portfolioNote",
               "required":false,
               "localName":"Brief description of the portfolio startup",
               "maxLength":"300"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Investment industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Investment technologies"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment stages"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_note",
               "required":false,
               "localName":"Special investment conditions"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of investments in startups",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_exitDealsNumber",
               "required":false,
               "localName":"Number of outputs"
            }
         ],
         "module":"Investments"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"questionnairePilots[]_company",
               "required":false,
               "localName":"Startup name"
            },
            {
               "type":"string",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"questionnairePilots[]_site",
               "required":false
            }
         ],
         "module":"Portfolio",
         "isArray":true,
         "moduleFormat":"card"
      }
   ]
}', 'View investor profile', 2),
       (13, 'New_scouting', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "example":"Иван",
               "sysName":"name",
               "required":true,
               "localName":"Name of contact person",
               "maxLength":90,
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "example":"mail@example.u",
               "sysName":"email",
               "required":true,
               "localName":"Contact email"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":true,
               "format":"phone",
               "example":"+",
               "sysName":"phone",
               "required":true,
               "localName":"Phone number"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Describe the need for scouting",
               "sysName":"comment",
               "required":false,
               "localName":"Need description",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"",
         "pageName":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Scouting request', 2),
       (1, 'corporate_blur', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Description"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":false,
               "localName":"Direction of activity"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":false,
               "localName":"Methods of working with innovations"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Corporation website"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":true,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"technologies"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":false,
               "localName":"Product development stages"
            }
         ],
         "module":"Working with startups"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "isBlur":false,
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Need description"
            }
         ],
         "module":"",
         "isArray":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography"
            }
         ],
         "module":"Investments"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "isBlur":false,
               "sysName":"successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "isBlur":false,
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Successful cases"
            }
         ],
         "module":"",
         "isArray":true,
         "moduleFormat":"card",
         "triggerField":"investment_investment",
         "triggerValue":"true"
      }
   ]
}', 'Viewing a corporation profile in an unauthorized area', 2),
       (0, 'startup_blur', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "isBlur":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Project industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":true,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":true,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover"
            },
            {
               "type":"hyperlink",
               "title":"View",
               "edited":false,
               "format":"button",
               "isBlur":false,
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Product video",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"View",
               "edited":false,
               "format":"button",
               "isBlur":false,
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"The number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "isBlur":false,
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "isBlur":false,
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "isBlur":false,
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":""
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О- cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":true,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}', 'Viewing a startup profile in an unauthorized area', 2),
       (2, 'investor_blur', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_investorType",
               "activity":[
                  11000
               ],
               "required":false,
               "localName":"Investor type"
            },
            {
               "type":"string",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_note",
               "required":false,
               "localName":"Brief description"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullnote",
               "required":false,
               "localName":"Description"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_portfolioNote",
               "required":false,
               "localName":"Brief description of the portfolio startup",
               "maxLength":"300"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":true,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Investments industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Investments technologies"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment stages"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_note",
               "required":false,
               "localName":"Special investment conditions"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of investments in startups",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_exitDealsNumber",
               "required":false,
               "localName":"Number of outputs"
            }
         ],
         "module":"Investments"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "isBlur":false,
               "sysName":"questionnairePilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"questionnairePilots[]_company",
               "required":false,
               "localName":"Startup name"
            }
         ],
         "module":"Portfolio",
         "isArray":true,
         "moduleFormat":"card"
      }
   ]
}', 'Viewing the investor profile in an unauthorized area', 2),
       (4, 'pilot_SuperClient_Extra', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "note":"The amount you value your pilot run",
               "type":"string",
               "edited":true,
               "example":"$",
               "sysName":"reply_cost",
               "required":false,
               "localName":"What is the cost of your solution",
               "maxLength":"30"
            },
            {
               "note":"Deadlines, steps, special conditions, restrictions, etc.",
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Comments",
               "sysName":"reply_process",
               "required":true,
               "localName":"How do you see the piloting process",
               "minLength":"50",
               "maxLength":"500"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Describe in detail your offer for this pilot",
               "sysName":"reply_note",
               "required":true,
               "localName":"Transmittal letter",
               "minLength":"50",
               "maxLength":"500"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"hide",
               "sysName":"pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":"Pilot",
               "edited":true,
               "format":"hide",
               "sysName":"reply_tableName",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":"0",
               "edited":true,
               "format":"hide",
               "sysName":"reply_state",
               "required":false,
               "localName":""
            },
            {
               "note":"File weight - no more than 5 MB, PDF format",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
               "description":"Increases the chances of attracting investors and corporations, but not required",
               "maxLength":"5",
               "allowedTypes":[
                  ".pdf"
               ]
            }
         ],
         "module":"Application for piloting",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"question",
               "example":"Your question",
               "sysName":"response",
               "required":false
            }
         ],
         "module":"Corporation Issues",
         "isArray":"true",
         "moduleType":"question"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"reply_note",
               "required":false,
               "localName":"Transmittal letter",
               "maxLength":"512"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"hide",
               "sysName":"pilot_file",
               "required":false,
               "localName":""
            },
            {
               "note":"Download the file",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
               "allowedTypes":[
                  ".pptx",
                  ".ppt",
                  ".pdf"
               ],
               "triggerField":"pilot_file",
               "triggerValue":true
            }
         ],
         "module":"Submit your application",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (4, 'pilot_Client_Extra', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "note":"The amount you value your pilot run",
               "type":"string",
               "edited":true,
               "example":"$",
               "sysName":"reply_cost",
               "required":false,
               "localName":"What is the cost of your solution",
               "maxLength":"30"
            },
            {
               "note":"Deadlines, steps, special conditions, restrictions, etc.",
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Comments",
               "sysName":"reply_process",
               "required":true,
               "localName":"How do you see the piloting process",
               "maxLength":"500"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Describe in detail your offer for this pilot",
               "sysName":"reply_note",
               "required":true,
               "localName":"Transmittal letter",
               "maxLength":"500"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"hide",
               "sysName":"pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":"Pilot",
               "edited":true,
               "format":"hide",
               "sysName":"reply_tableName",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":"0",
               "edited":true,
               "format":"hide",
               "sysName":"reply_state",
               "required":false,
               "localName":""
            },
            {
               "note":"File weight - no more than 5 MB, PDF format",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
               "description":"Increases the chances of attracting investors and corporations, but not required",
               "maxLength":"5",
               "allowedTypes":[
                  ".pdf"
               ]
            }
         ],
         "module":"Application for piloting",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"question",
               "example":"Your question",
               "sysName":"response",
               "required":false
            }
         ],
         "module":"Corporation questions",
         "isArray":"true",
         "moduleType":"question"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"reply_note",
               "required":false,
               "localName":"Transmittal letter",
               "maxLength":"512"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"hide",
               "sysName":"pilot_file",
               "required":false,
               "localName":""
            },
            {
               "note":"Download the file",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation",
               "allowedTypes":[
                  ".pptx",
                  ".ppt",
                  ".pdf"
               ],
               "triggerField":"pilot_file",
               "triggerValue":true
            }
         ],
         "module":"Leave the application",
         "moduleNote":""
      }
   ]
}', 'Application for piloting', 2),
       (2, 'investor_BusinessUnit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":true,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":true,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"resourse"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":true,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":false,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"string",
               "value":"Global technologies",
               "edited":false,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Brief name"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Resourse"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief project description"
            },
            {
               "type":"Logo",
               "edited":false,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL demo link"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (13, 'scouting_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"name",
               "required":false,
               "localName":"Name of contact person",
               "maxLength":90,
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"email",
               "required":false,
               "localName":"Contact email"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"phone",
               "required":false,
               "localName":"Phone number"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":false,
               "example":"Describe the need for scouting",
               "sysName":"comment",
               "required":false,
               "localName":"Need description",
               "maxLength":"300"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "sysName":"adminComment",
               "required":false,
               "localName":"Comment",
               "maxLength":"300",
               "note":"The comment is only available to the administrator"
            }
         ],
         "module":"",
         "pageName":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Scouting request', 2),
       (4, 'New_vas', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"discount",
               "required":true,
               "localName":"Brief offer",
               "maxLength":"250",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"offer",
               "required":true,
               "localName":"Full offer",
               "maxLength":"1000"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"smallNote",
               "required":true,
               "localName":"Brief product description",
               "maxLength":"150",
               "showLength":false
            },
            {
               "note":"Available in detailed card view",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Full product description",
               "maxLength":"1000"
            },
            {
               "note":"",
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "sysName":"category",
               "activity":[
                  10000
               ],
               "required":true,
               "localName":"Offer category",
               "multySelect":false
            },
            {
               "note":"The more, the higher in the list",
               "type":"int",
               "edited":true,
               "format":"[0;10000000000000]",
               "sysName":"priority",
               "maxValue":2000000000,
               "minValue":0,
               "required":true,
               "localName":"Priority"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateFrom",
               "required":true,
               "localName":"Date of the beginnig"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateTo",
               "required":true,
               "localName":"Expiration date"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"offerUri",
               "required":true,
               "localName":"Link to application page",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"Creating an offer",
         "moduleNote":""
      }
   ]
}', NULL, 'Creating an offer', 2),
       (2, 'investor_Administrator', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "direction":"row",
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "direction":"row",
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":false,
               "localName":"Public name / brand name",
               "maxLength":70,
               "showLength":false
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country of jurisdiction",
               "multySelect":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"questionnaire_phoneNumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Organization information is automatically transferred from SberBusiness Online. Please fill in the missing data."
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "title":"Resourse",
               "edited":false,
               "format":"chip",
               "sysName":"contacts[]_type",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Link",
               "maxLength":"70"
            }
         ],
         "module":"Additional contacts",
         "isArray":"true",
         "actionText":"Add resource",
         "moduleNote":"Optional. Provide links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[

               ],
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"User interaction business models",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Where is your project based?",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "direction":"row",
               "localName":"Country",
               "multySelect":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "direction":"row",
               "localName":"City",
               "maxLength":30,
               "showLength":false
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions",
               "multySelect":true
            },
            {
               "note":"Describe the project in 1-2 sentences",
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project",
               "maxLength":"200"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Company logo",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"This is an optional field. The demo should show how the product works. Usually this is a video or screen record",
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"project_haveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "note":"This is an optional field. The demo should show how the product works. Usually this is a video or screen record",
               "type":"string",
               "edited":false,
               "sysName":"project_demoSite",
               "required":false,
               "localName":"URL link to demo",
               "maxLength":"100",
               "showLength":false,
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Describe in 1-2 sentences",
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience",
               "maxLength":"300"
            },
            {
               "note":"We accept files up to 50 MB. Format - DOC, XLSX or PDF",
               "type":"hyperlink",
               "title":"Presentation",
               "edited":false,
               "format":"URL",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Download presentation",
               "description":"Not required to download, but increases the chances of attracting investors and corporations",
               "allowedTypes":[
                  ".doc",
                  ".docx",
                  ".pdf",
                  ".xlsx"
               ]
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets you operate in",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales",
               "multySelect":true
            },
            {
               "note":"Optional. If you do not have a turnover yet, then write how many first customers you have, whether a Customer Development study has been conducted and with how many users",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per month and turnover per year",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Name 2-3 main direct and 2-3 indirect competitors",
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Competitors",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_downSide",
               "required":false,
               "localName":"Disadvantages over competitors",
               "maxLength":"300"
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"[1;1000]",
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "format":"[0;1000]",
               "sysName":"project_hiringStaff",
               "required":false,
               "direction":"row",
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "title":"Specify which key roles / positions in the startup are closed",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"The role of the employee in the team",
               "maxLength":"100"
            }
         ],
         "module":"",
         "isArray":"true",
         "actionText":"Add role"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":false,
               "localName":"If you are a B2B-, B2G-, B2B2C-, B2O-startup: do you have successful pilots / implementations?"
            }
         ],
         "module":"Successful pilots",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who had a successful case",
               "maxLength":"140"
            },
            {
               "note":"Describe in 1-2 sentences",
               "type":"string",
               "edited":false,
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case",
               "maxLength":"100",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            }
         ],
         "module":"Successful cases",
         "isArray":"true",
         "actionText":"Add case",
         "moduleNote":"Optional. Specify with whom you had successful pilots / implementations, and describe their essence and results, but only if the disclosure of this information does not contradict agreements with the corporation, etc. Other SberUnity users will see this information",
         "triggerField":"questionnaire_successPilots",
         "triggerValue":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilotsB2C",
               "required":false,
               "localName":"If you are a B2C, C2C startup: do you have first sales to real customers (not FFF)?"
            }
         ],
         "module":"",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2cPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"b2cPilots[]_reference",
               "required":false,
               "localName":"Who had a successful case",
               "maxLength":"140"
            },
            {
               "note":"Describe in 1-2 sentences",
               "type":"string",
               "edited":false,
               "sysName":"b2cPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case",
               "maxLength":"100",
               "triggerField":"questionnaire_successPilotsB2C",
               "triggerValue":"true"
            }
         ],
         "module":"",
         "isArray":"true",
         "actionText":"Add case",
         "moduleNote":"",
         "triggerField":"questionnaire_successPilotsB2C",
         "triggerValue":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in Sber Ecosystem or other corporations?"
            },
            {
               "type":"array",
               "value":"20008",
               "edited":false,
               "format":"hide",
               "sysName":"ecoPilot_state",
               "required":false,
               "localName":"",
               "triggerField":"questionnaire_pilot",
               "triggerValue":"true"
            },
            {
               "note":"Describe in two or three sentences exactly how the corporation should use your startup and what this will give them",
               "type":"string",
               "edited":false,
               "sysName":"ecoPilot_suggestCase",
               "required":false,
               "localName":"Proposed case",
               "maxLength":"300",
               "triggerField":"questionnaire_pilot",
               "triggerValue":"true"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"ecoPilot_experience",
               "required":false,
               "localName":"Have you interacted with the Sber ecosystem before?",
               "triggerField":"questionnaire_pilot",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"ecoPilot_businessUnit",
               "required":false,
               "localName":"What business unit of Sberbank did you interact with?",
               "maxLength":"120",
               "triggerField":"ecoPilot_experience",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "value":true,
               "edited":false,
               "format":"hide",
               "sysName":"ecoPilot_ecoSystem",
               "required":false,
               "localName":"",
               "maxLength":"120",
               "triggerField":"questionnaire_pilot",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "value":true,
               "edited":false,
               "format":"hide",
               "sysName":"ecoPilot_pilot",
               "required":false,
               "localName":"",
               "maxLength":"120",
               "triggerField":"questionnaire_pilot",
               "triggerValue":"true"
            }
         ],
         "module":"Sber Ecosystem"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"investment_investment",
               "required":false,
               "localName":"Are you interested in attracting investments now?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"int",
               "edited":false,
               "format":"[0;10000000000000]",
               "sysName":"investment_sumInvestment",
               "required":false,
               "localName":"Required investment amount",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "note":"Indicate the amount of previously attracted investments",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total",
               "maxLength":"300",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "note":"List all investors from whom you received investments, if disclosure of this information does not contradict agreements with them",
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "maxLength":"300",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_accelerator",
               "required":false,
               "localName":"Is your company a graduate of Sber500, SberUP, SberZ, SberStudent?"
            }
         ],
         "module":"Sber Accelerators"
      },
      {
         "page":1,
         "fields":[
            {
               "note":"and get expert advice, analyze cases of startup founders, be the first to know the news of the venture market and have access to startup vacancies?",
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_community",
               "required":false,
               "localName":"Do you want to participate in SberStartup communities?"
            }
         ],
         "module":"Communities"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"session_date",
               "required":false,
               "localName":"Visit time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":false,
               "localName":"Public name / brand name"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country of jurisdiction*"
            }
         ],
         "module":"Juridical information about the organization",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"questionnaire_investorType",
               "activity":[
                  11000
               ],
               "required":false,
               "localName":"Choose the type of investor"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_acceleratorSite",
               "required":false,
               "localName":"Link to accelerator"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_note",
               "required":false,
               "localName":"Brief description",
               "maxLength":150
            },
            {
               "note":"For example: Fund and accelerator",
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Full description",
               "maxLength":1000
            },
            {
               "type":"hyperlink",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Public email address"
            },
            {
               "type":"logo",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"Profile data",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"logo",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download photo"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_portfolioNote",
               "required":false,
               "localName":"Brief description of the portfolio startup",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_fio",
               "required":false,
               "localName":"Last name First name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_role",
               "required":false,
               "localName":"Position*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_phone",
               "required":false,
               "localName":"Mobile phone*"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "sysName":"representative_facebook",
               "required":false,
               "localName":"Facebook profile*"
            }
         ],
         "module":"Your data",
         "pageName":""
      },
      {
         "page":1,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":""
            },
            {
               "note":"It is important for startups to see personalities. Specify the responsible person of the fund, which will be seen by other platform participants.",
               "type":"string",
               "edited":false,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Last name First name",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Specify the position of the person from the previous question",
               "type":"string",
               "edited":false,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Position",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Your data",
         "actionText":"Add contact person",
         "modulenote":"Specify the employee that other users of the platform will see in your profile as a contact person"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "title":"Geography of startups",
               "edited":false,
               "format":"text",
               "sysName":"investment_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment stages"
            },
            {
               "note":"For example, impact startups, female founders, etc.",
               "type":"string",
               "edited":false,
               "sysName":"investment_note",
               "required":false,
               "localName":"Special investment conditions",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Investments",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_activeDealsNumber",
               "required":false,
               "localName":"Number of startups in the portfolio"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of transactions, total"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_exitDealsNumber",
               "required":false,
               "localName":"Number of outputs"
            }
         ],
         "module":"Portfolio startup data",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnairePilots[]_company",
               "required":false,
               "localName":"Startup name"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "sysName":"questionnairePilots[]_site",
               "required":false,
               "localName":"Startup website link"
            }
         ],
         "module":"",
         "isArray":"true",
         "pageName":"",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_club",
               "required":false,
               "localName":"Are you a member of any investment club/community?*"
            }
         ],
         "module":"Investment clubs",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"investorClubs[]_name",
               "required":false,
               "localName":"Club/community name*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investorClubs[]_role",
               "required":false,
               "localName":"Your role in the club/community*"
            }
         ],
         "module":"Indicate the name of the investment club / community and your role",
         "isArray":"true",
         "pageName":"",
         "withIndex":true
      }
   ]
}', NULL, 2),
       (13, 'New_scouting', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "example":"Иван",
               "sysName":"name",
               "required":true,
               "localName":"Name of contact person",
               "maxLength":90,
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "example":"mail@example.u",
               "sysName":"email",
               "required":true,
               "localName":"Contact email"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":true,
               "format":"phone",
               "example":"+",
               "sysName":"phone",
               "required":true,
               "localName":"Phone number"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "example":"Describe the need for scouting",
               "sysName":"comment",
               "required":false,
               "localName":"Need description",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"",
         "pageName":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Scouting request', 2),
       (13, 'scouting_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"name",
               "required":false,
               "localName":"Name of contact person",
               "maxLength":90,
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"email",
               "required":false,
               "localName":"Contact email"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"phone",
               "required":false,
               "localName":"Phone number"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":false,
               "example":"Describe the need for scouting",
               "sysName":"comment",
               "required":false,
               "localName":"Need description",
               "maxLength":"300"
            },
            {
               "rows":"3",
               "type":"string",
               "edited":true,
               "sysName":"adminComment",
               "required":false,
               "localName":"Comment",
               "maxLength":"300",
               "note":"The comment is only available to the administrator"
            }
         ],
         "module":"",
         "pageName":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Scouting request', 2),
       (0, 'startup_SuperStartup', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Project industries"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Main information"
      }
   ]
}', 'Viewing the startup profile', 2),
       (11, 'New_Community_FamilyOffice', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Family office name",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to the Found website",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"Select destinations",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"What areas are you investing in?",
               "multySelect":true
            },
            {
               "note":"Select geography",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Interested geography of investments",
               "multySelect":true
            },
            {
               "note":"Select stages",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Investment stages of interest",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Number of venture projects in the portfolio"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Link to account",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Your Facebook account"
            },
            {
               "type":"int",
               "value":3,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Family office application', 2),
       (2, 'investor_Client', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_investorType",
               "activity":[
                  11000
               ],
               "required":false,
               "localName":"Investor type"
            },
            {
               "type":"string",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_note",
               "required":false,
               "localName":"Short description"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Title/name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Description"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website (Available by subscription)"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email (Available by subscription)"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Direction of investment"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment stages"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_note",
               "required":false,
               "localName":"Special investment conditions"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_portfolioNote",
               "required":false,
               "localName":"Brief description of the portfolio startup",
               "maxLength":"300"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11001"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of investments in startups",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11002"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11003"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_allDealsNumber",
               "required":false,
               "localName":"Number of startups in which the fund has invested",
               "triggerField":"questionnaire_investorType",
               "triggerValue":"11004"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_exitDealsNumber",
               "required":false,
               "localName":"Number of outputs"
            }
         ],
         "module":"Investments (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"pilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_company",
               "required":false,
               "localName":"Startup name"
            }
         ],
         "module":"Briefcase",
         "isArray":true
      }
   ]
}', 'View investor profile', 2),
       (4, 'pilot_AdministratorBran', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"name",
               "required":true,
               "localName":"Title"
            },
            {
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "values":[
                  {
                     "code":"15001",
                     "name":"Optimization of current processes, costs"
                  },
                  {
                     "code":"15002",
                     "name":"Introduction of new functions, new revenue channels"
                  },
                  {
                     "code":"15003",
                     "name":"Other"
                  }
               ],
               "sysName":"target",
               "required":true,
               "localName":"Goal"
            },
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"targetOption",
               "required":false,
               "localName":"Your choice of goal",
               "triggerfield":"target",
               "triggervalue":"15003"
            },
            {
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Describe the problem"
            },
            {
               "note":"1 - the problem is optional, 10 - needs to be solved in a quarter",
               "type":"star",
               "edited":true,
               "sysName":"relevance",
               "required":true,
               "localName":"Importance and urgency of the problem"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"17001",
                     "name":"Yes"
                  },
                  {
                     "code":"17002",
                     "name":"No"
                  },
                  {
                     "code":"17003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"effect",
               "required":true,
               "localName":"Is it possible to measure the economic effect of solving a problem?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"18001",
                     "name":"Yes"
                  },
                  {
                     "code":"18002",
                     "name":"No"
                  },
                  {
                     "code":"18003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"resources",
               "required":true,
               "localName":"Are there free resources to conduct the pilot before the end of this year?"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"search",
               "required":true,
               "localName":"Have you searched for a solution in the database yourself?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"16001",
                     "name":"No"
                  },
                  {
                     "code":"16002",
                     "name":"Yes, through internal development"
                  },
                  {
                     "code":"16003",
                     "name":"Yes, by working with an external company"
                  }
               ],
               "sysName":"exp",
               "required":true,
               "localName":"Have you tried to solve the problem yourself?"
            },
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"company",
               "required":false,
               "localName":"Companies",
               "triggerfield":"exp",
               "triggervalue":"16003"
            },
            {
               "type":"date",
               "edited":true,
               "format":"DD.MM.YYYY",
               "sysName":"deadline",
               "required":true,
               "localName":"Decision term"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"A product or technology that will fill your need",
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"decision",
               "required":false,
               "localName":"Describe the solution"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"isForeign",
               "required":false,
               "localName":"Ready to work with foreign companies?"
            },
            {
               "note":"Examples of companies that can solve your need",
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"decisionCompany",
               "required":false,
               "localName":"Companies"
            },
            {
               "note":"The demand will become public and companies registered on SberUnity will be able to respond to the request",
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"isHub",
               "required":false,
               "localName":"Publish on SberUnity showcase"
            }
         ],
         "module":"Additionally",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"name",
               "required":true,
               "localName":"Header"
            },
            {
               "type":"array",
               "edited":false,
               "format":"dropdown",
               "values":[
                  {
                     "code":"15001",
                     "name":"Optimization of current processes, costs"
                  },
                  {
                     "code":"15002",
                     "name":"Introduction of new functions, new revenue channels"
                  },
                  {
                     "code":"15003",
                     "name":"Other"
                  }
               ],
               "sysName":"target",
               "required":true,
               "localName":"Goal"
            },
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"targetOption",
               "required":false,
               "localName":"Your choice of goal",
               "triggerfield":"target",
               "triggervalue":"15003"
            },
            {
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Describe the problem"
            },
            {
               "note":"1 - the problem is optional, 10 - needs to be solved in a quarter",
               "type":"star",
               "edited":false,
               "sysName":"relevance",
               "required":true,
               "localName":"Importance and urgency of the problem"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"17001",
                     "name":"Yes"
                  },
                  {
                     "code":"17002",
                     "name":"No"
                  },
                  {
                     "code":"17003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"effect",
               "required":true,
               "localName":"Is it possible to measure the economic effect of solving a problem?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"18001",
                     "name":"Yes"
                  },
                  {
                     "code":"18002",
                     "name":"No"
                  },
                  {
                     "code":"18003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"resources",
               "required":true,
               "localName":"Are there free resources to conduct the pilot before the end of this year?"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"search",
               "required":true,
               "localName":"Have you searched for a solution in the database yourself?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"16001",
                     "name":"No"
                  },
                  {
                     "code":"16002",
                     "name":"Yes, through internal development"
                  },
                  {
                     "code":"16003",
                     "name":"Yes, by working with an external company"
                  }
               ],
               "sysName":"exp",
               "required":true,
               "localName":"Have you tried to solve the problem yourself?"
            },
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"company",
               "required":false,
               "localName":"Companies",
               "triggerfield":"exp",
               "triggervalue":"16003"
            },
            {
               "type":"date",
               "edited":false,
               "format":"calendar",
               "sysName":"deadline",
               "required":true,
               "localName":"Decision term"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"A product or technology that will fill your need",
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"decision",
               "required":false,
               "localName":"Describe the solution"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"isForeign",
               "required":false,
               "localName":"Ready to work with foreign companies?"
            },
            {
               "note":"Examples of companies that can solve your need",
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"decisionCompany",
               "required":false,
               "localName":"Companies"
            },
            {
               "note":"The demand will become public and companies registered in SberUnit will be able to respond to the request",
               "type":"boolean",
               "edited":false,
               "format":"checkbox",
               "sysName":"isHub",
               "required":false,
               "localName":"Publish on SberUnit showcase"
            }
         ],
         "module":"Additional",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (4, 'pilot_Administrator', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"name",
               "required":false,
               "localName":"Header",
               "maxLength":"140"
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":false,
               "sysName":"businessUnit",
               "required":false,
               "localName":"Subdivision",
               "maxLength":"200"
            },
            {
               "note":"What needs will startups address in the pilot?",
               "type":"string",
               "edited":false,
               "sysName":"suggestCase",
               "required":false,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"conditions",
               "required":false,
               "localName":"Piloting conditions",
               "maxLength":"300"
            },
            {
               "type":"array",
               "edited":false,
               "format":"serch_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Add a theme or direction",
               "multySelect":true
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"file",
               "required":false,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":false,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"string",
               "value":"20004",
               "edited":false,
               "format":"hide",
               "sysName":"state",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"true",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"response[]_question",
               "required":false,
               "localName":"Question text",
               "maxLength":"100"
            },
            {
               "note":"Additional information, clarification of the question",
               "type":"string",
               "edited":false,
               "sysName":"response[]_questionDescription",
               "required":false,
               "localName":"Description",
               "maxLength":"100"
            }
         ],
         "module":"",
         "isArray":true,
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"name",
               "required":false,
               "localName":"Header",
               "maxLength":"140"
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":false,
               "sysName":"businessUnit",
               "required":false,
               "localName":"Subdivision",
               "maxLength":"200"
            },
            {
               "note":"What needs will startups address in the pilot?",
               "type":"string",
               "edited":false,
               "sysName":"suggestCase",
               "required":false,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"conditions",
               "required":false,
               "localName":"Piloting conditions",
               "maxLength":"300"
            },
            {
               "type":"array",
               "edited":false,
               "format":"serch_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Add a theme or direction",
               "multySelect":true
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"file",
               "required":false,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":false,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"РAllow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"string",
               "value":"20004",
               "edited":false,
               "format":"hide",
               "sysName":"state",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"false",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"response[]_question",
               "required":false,
               "localName":"Question text",
               "maxLength":"100"
            },
            {
               "note":"Additional information, clarification of the question",
               "type":"string",
               "edited":false,
               "sysName":"response[]_questionDescription",
               "required":false,
               "localName":"Description",
               "maxLength":"100"
            }
         ],
         "module":"",
         "isArray":true,
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (10, 'round_Administrator', NULL, '{
   "form":[
      {
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"roundType",
               "activity":[
                  6000
               ],
               "required":true,
               "localName":"Round stage"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"filebutton",
               "sysName":"presentation",
               "required":true,
               "localName":"Investment presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Deal jurisdiction"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"transactionType",
               "activity":[
                  14000
               ],
               "required":true,
               "localName":"Deal type"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"endDate",
               "required":true,
               "localName":"Deal closing date"
            }
         ],
         "module":"Main information"
      },
      {
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"sumInvestment",
               "required":true,
               "localName":"How much investment are you attracting?"
            },
            {
               "mask":"%",
               "type":"string",
               "edited":false,
               "sysName":"percent",
               "required":true,
               "localName":"For what percentage of the company?"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"preMoney",
               "required":true,
               "localName":"Pre-money"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"postMoney",
               "required":true,
               "localName":"Post-money"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"result",
               "required":true,
               "localName":"What results will be achieved?"
            }
         ],
         "module":"Startup evaluation in the round"
      },
      {
         "fields":[
            {
               "mask":"%",
               "type":"string",
               "edited":false,
               "sysName":"marketingPercent",
               "required":false,
               "localName":"Marketing and sales"
            },
            {
               "mask":"%",
               "type":"string",
               "edited":false,
               "sysName":"softwarePercent",
               "required":false,
               "localName":"Hardware and software"
            },
            {
               "mask":"%",
               "type":"string",
               "edited":false,
               "sysName":"teamPercent",
               "required":false,
               "localName":"Payment for the current team"
            },
            {
               "mask":"%",
               "type":"string",
               "edited":false,
               "sysName":"extensionPercent",
               "required":false,
               "localName":"Team extension"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"otherDescription",
               "required":false
            }
         ],
         "module":"Where will the money go?"
      },
      {
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"leadCheck",
               "required":true,
               "localName":"Is there a lead investor?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"leadName",
               "required":false,
               "localName":"Lead investor"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"lastInvestment",
               "required":true,
               "localName":"How much has already been collected?"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"futureInvestment",
               "required":true,
               "localName":"It remains to collect"
            }
         ],
         "module":"Round status"
      },
      {
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"roundInfo",
               "required":false,
               "localName":"Additional information about the round"
            }
         ],
         "module":"Additional information"
      },
      {
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"inviteFio",
               "required":true,
               "localName":"Employee name to contact with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Employee Email"
            },
            {
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"phone",
               "required":true,
               "localName":"Employee phone number"
            }
         ],
         "module":"Contacts"
      }
   ]
}', NULL, 2),
       (7, 'reply_Client', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Company"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"hyperlink",
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_phoneNumber",
               "required":false,
               "localName":"Phone number"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"reply_note",
               "required":false,
               "localName":"Transmittal letter"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"reply_fileURL",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "localName":"Number of employees"
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', 'Response', 2),
       (9, 'corp_app_Administrator', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"firstName",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"lastName",
               "required":false,
               "localName":"Surname"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"phone",
               "required":false,
               "localName":"Phone number",
               "maxLength":4
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"position",
               "required":false,
               "localName":"Position"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"email",
               "required":false,
               "localName":"Corporate email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"site",
               "required":false,
               "localName":"Website address"
            }
         ],
         "module":"Application information",
         "pageName":"orgFullName"
      }
   ]
}', NULL, 2),
       (9, 'invest_app_Administrator', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"firstName",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"lastName",
               "required":false,
               "localName":"Surname"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"phone",
               "required":false,
               "localName":"Phone number",
               "maxLength":4
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"position",
               "required":false,
               "localName":"Position"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"email",
               "required":false,
               "localName":"Corporate email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"site",
               "required":false,
               "localName":"Website address"
            }
         ],
         "module":"Application information",
         "pageName":"investorType+orgFullName"
      }
   ]
}', NULL, 2),
       (4, 'pilot', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"name",
               "required":true,
               "localName":"Header"
            },
            {
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "values":[
                  {
                     "code":"15001",
                     "name":"Optimization of current processes, costs"
                  },
                  {
                     "code":"15002",
                     "name":"Introduction of new functions, new revenue channels"
                  },
                  {
                     "code":"15003",
                     "name":"Other"
                  }
               ],
               "sysName":"target",
               "required":true,
               "localName":"Goal"
            },
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"targetOption",
               "required":false,
               "localName":"Your choice of goal",
               "triggerfield":"target",
               "triggervalue":"15003"
            },
            {
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Describe the problem"
            },
            {
               "note":"1 - the problem is optional, 10 - needs to be solved in a quarter",
               "type":"star",
               "edited":true,
               "sysName":"relevance",
               "required":true,
               "localName":"Importance and urgency of the problem"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"17001",
                     "name":"Yes"
                  },
                  {
                     "code":"17002",
                     "name":"No"
                  },
                  {
                     "code":"17003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"effect",
               "required":true,
               "localName":"Is it possible to measure the economic effect of solving a problem?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"18001",
                     "name":"Yes"
                  },
                  {
                     "code":"18002",
                     "name":"No"
                  },
                  {
                     "code":"18003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"resources",
               "required":true,
               "localName":"Are there free resources to conduct the pilot before the end of this year?"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"search",
               "required":true,
               "localName":"Have you searched for a solution in the database yourself?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "values":[
                  {
                     "code":"16001",
                     "name":"No"
                  },
                  {
                     "code":"16002",
                     "name":"Yes, through internal development"
                  },
                  {
                     "code":"16003",
                     "name":"Yes, by working with an external company"
                  }
               ],
               "sysName":"exp",
               "required":true,
               "localName":"Have you tried to solve the problem yourself?"
            },
            {
               "type":"string",
               "edited":true,
               "format":"140",
               "sysName":"company",
               "required":false,
               "localName":"Companies",
               "triggerfield":"exp",
               "triggervalue":"16003"
            },
            {
               "type":"date",
               "edited":true,
               "format":"DD.MM.YYYY",
               "sysName":"deadline",
               "required":true,
               "localName":"Decision term"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"A product or technology that will fill your need",
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"decision",
               "required":false,
               "localName":"Describe the solution"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"isForeign",
               "required":false,
               "localName":"Ready to work with foreign companies?"
            },
            {
               "note":"Examples of companies that can solve your need",
               "type":"string",
               "edited":true,
               "format":"1000",
               "sysName":"decisionCompany",
               "required":false,
               "localName":"Companies"
            },
            {
               "note":"The demand will become public and companies registered on SberUnity will be able to respond to the request",
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"isHub",
               "required":false,
               "localName":"Publish on SberUnity showcase"
            }
         ],
         "module":"Additionally",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"name",
               "required":true,
               "localName":"Header"
            },
            {
               "type":"array",
               "edited":false,
               "format":"dropdown",
               "values":[
                  {
                     "code":"15001",
                     "name":"Optimization of current processes, costs"
                  },
                  {
                     "code":"15002",
                     "name":"Introduction of new functions, new revenue channels"
                  },
                  {
                     "code":"15003",
                     "name":"Other"
                  }
               ],
               "sysName":"target",
               "required":true,
               "localName":"Goal"
            },
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"targetOption",
               "required":false,
               "localName":"Your choice of goal",
               "triggerfield":"target",
               "triggervalue":"15003"
            },
            {
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Describe the problem"
            },
            {
               "note":"1 - the problem is optional, 10 - needs to be solved in a quarter",
               "type":"star",
               "edited":false,
               "sysName":"relevance",
               "required":true,
               "localName":"Importance and urgency of the problem"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"17001",
                     "name":"Yes"
                  },
                  {
                     "code":"17002",
                     "name":"No"
                  },
                  {
                     "code":"17003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"effect",
               "required":true,
               "localName":"Is it possible to measure the economic effect of solving a problem?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"18001",
                     "name":"Yes"
                  },
                  {
                     "code":"18002",
                     "name":"No"
                  },
                  {
                     "code":"18003",
                     "name":"Difficult to answer"
                  }
               ],
               "sysName":"resources",
               "required":true,
               "localName":"Are there free resources to conduct the pilot before the end of this year?"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"search",
               "required":true,
               "localName":"Have you searched for a solution in the database yourself?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "values":[
                  {
                     "code":"16001",
                     "name":"No"
                  },
                  {
                     "code":"16002",
                     "name":"Yes, through internal development"
                  },
                  {
                     "code":"16003",
                     "name":"Yes, by working with an external company"
                  }
               ],
               "sysName":"exp",
               "required":true,
               "localName":"Have you tried to solve the problem yourself?"
            },
            {
               "type":"string",
               "edited":false,
               "format":"140",
               "sysName":"company",
               "required":false,
               "localName":"Companies",
               "triggerfield":"exp",
               "triggervalue":"16003"
            },
            {
               "type":"date",
               "edited":false,
               "format":"calendar",
               "sysName":"deadline",
               "required":true,
               "localName":"Decision term"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"A product or technology that will fill your need",
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"decision",
               "required":false,
               "localName":"Describe the solution"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"isForeign",
               "required":false,
               "localName":"Ready to work with foreign companies?"
            },
            {
               "note":"Examples of companies that can solve your need",
               "type":"string",
               "edited":false,
               "format":"1000",
               "sysName":"decisionCompany",
               "required":false,
               "localName":"Companies"
            },
            {
               "note":"The demand will become public and companies registered on SberUnity will be able to respond to the request",
               "type":"boolean",
               "edited":false,
               "format":"checkbox",
               "sysName":"isHub",
               "required":false,
               "localName":"Publish on SberUnity showcase"
            }
         ],
         "module":"Additionally",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (4, 'New_vas', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"discount",
               "required":true,
               "localName":"Brief offer",
               "maxLength":"250",
               "showLength":false
            },
            {
               "note":"Какую потребность стартапы будут решать в рамках пилота?",
               "type":"string",
               "edited":true,
               "sysName":"offer",
               "required":true,
               "localName":"Full offer",
               "maxLength":"1000"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"smallNote",
               "required":true,
               "localName":"Brief description of the product",
               "maxLength":"150",
               "showLength":false
            },
            {
               "note":"Available in detailed card view",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Full product description",
               "maxLength":"1000"
            },
            {
               "note":"",
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "sysName":"category",
               "activity":[
                  10000
               ],
               "required":true,
               "localName":"Offer category",
               "multySelect":false
            },
            {
               "note":"The more, the higher in the list",
               "type":"int",
               "edited":true,
               "format":"[0;10000000000000]",
               "sysName":"priority",
               "maxValue":2000000000,
               "minValue":0,
               "required":true,
               "localName":"Priority"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateFrom",
               "required":true,
               "localName":"Date of the beginnig"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateTo",
               "required":true,
               "localName":"Expiration date"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"offerUri",
               "required":true,
               "localName":"Link to application page",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"Create an offer",
         "moduleNote":""
      }
   ]
}', NULL, 'Create an offer', 2),
       (0, 'startup_SuperClient', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_type",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":""
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}', 'Viewing the startup profile', 2),
       (4, 'New_Company', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"The name of the company",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Company description",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"resourceUri",
               "required":true,
               "localName":"The site of the company",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Contact email"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Company logo",
               "edited":true,
               "format":"200*200",
               "sysName":"logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Adding a company', 2),
       (4, 'сompany_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"The name of the company",
               "maxLength":"50",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Company description",
               "maxLength":"1000"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"resourceUri",
               "required":true,
               "localName":"The site of the company",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Contact email"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Company logo",
               "edited":true,
               "format":"200*200",
               "sysName":"logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Company change', 2),
       (3, 'vas_SuperClient', NULL, '{
   "form":[
      {
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"service_category",
               "activity":[
                  10000
               ],
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"serviceCompany_note",
               "required":false,
               "localName":""
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"",
               "sysName":"serviceCompany_resourceURI",
               "required":false,
               "localName":""
            }
         ]
      },
      {
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"service_smallNote",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"service_note",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"bodyhide",
               "sysName":"service_discount",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"bodybold",
               "sysName":"service_offer",
               "required":false,
               "localName":""
            },
            {
               "logo":"",
               "type":"info",
               "edited":false,
               "format":"button",
               "sysName":"service_offerUri",
               "required":false,
               "localName":"Get an offer",
               "clickActon":""
            }
         ],
         "module":"",
         "moduleNote":"",
         "moduleFormat":"card"
      }
   ]
}', NULL, 2),
       (4, 'vas_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"discount",
               "required":true,
               "localName":"Brief offer",
               "maxLength":"250",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"offer",
               "required":true,
               "localName":"Full offer",
               "maxLength":"1000"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"smallNote",
               "required":true,
               "localName":"Brief description of the product",
               "maxLength":"150",
               "showLength":false
            },
            {
               "note":"Available in detailed card view",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Full description of the product",
               "maxLength":"1000"
            },
            {
               "note":"",
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "sysName":"category",
               "activity":[
                  10000
               ],
               "required":true,
               "localName":"Offer category",
               "multySelect":false
            },
            {
               "note":"The more, the higher in the list",
               "type":"int",
               "edited":true,
               "format":"[0;10000000000000]",
               "sysName":"priority",
               "maxValue":2000000000,
               "minValue":0,
               "required":true,
               "localName":"Priority"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateFrom",
               "required":true,
               "localName":"Date of the beginnig"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateTo",
               "required":true,
               "localName":"Expiration date"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"offerUri",
               "required":true,
               "localName":"Link to application page",
               "regExpError":"You must specify the site in the format: https://sber-unity.ru"
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', NULL, NULL, 2),
       (4, 'New_Company', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"The name of the company",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Company description",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"resourceUri",
               "required":true,
               "localName":"The site of the company",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Contact email"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Company logo",
               "edited":true,
               "format":"200*200",
               "sysName":"logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Adding a company', 2),
       (4, 'сompany_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Company name",
               "maxLength":"50",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Company description",
               "maxLength":"1000"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"resourceUri",
               "required":true,
               "localName":"The site of the company",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Contact email"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Company logo",
               "edited":true,
               "format":"200*200",
               "sysName":"logoFile",
               "required":false,
               "localName":"Download logo",
               "maxLength":"5",
               "description":"We made the field required to improve the quality of the member base",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', NULL, 'Company change', 2),
       (4, 'vas_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"discount",
               "required":true,
               "localName":"Краткое предложение",
               "maxLength":"250",
               "showLength":false
            },
            {
               "note":"Какую потребность стартапы будут решать в рамках пилота?",
               "type":"string",
               "edited":true,
               "sysName":"offer",
               "required":true,
               "localName":"Полное предложение",
               "maxLength":"1000"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"smallNote",
               "required":true,
               "localName":"Краткое описание продукта",
               "maxLength":"150",
               "showLength":false
            },
            {
               "note":"Доступно при подробном просмотре карточки",
               "type":"string",
               "edited":true,
               "sysName":"note",
               "required":true,
               "localName":"Полное описание продукта",
               "maxLength":"1000"
            },
            {
               "note":"",
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "sysName":"category",
               "activity":[
                  10000
               ],
               "required":true,
               "localName":"Категория предложения",
               "multySelect":false
            },
            {
               "note":"Чем больше, тем выше в списке",
               "type":"int",
               "edited":true,
               "format":"[0;10000000000000]",
               "sysName":"priority",
               "maxValue":2000000000,
               "minValue":0,
               "required":true,
               "localName":"Приоритет"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateFrom",
               "required":true,
               "localName":"Дата начала"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"dateTo",
               "required":true,
               "localName":"Дата окончания"
            },
            {
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"offerUri",
               "required":true,
               "localName":"Ссылка на старницу приложения",
               "regExpError":"Необходимо указать сайт в формате: https://sber-unity.ru"
            }
         ],
         "module":"",
         "moduleNote":""
      }
   ]
}', NULL, NULL, 2),
       (4, 'New_Pilot', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Short name of the requested technology in the nominative case",
               "type":"string",
               "edited":true,
               "example":"Requested technology name",
               "sysName":"name",
               "required":true,
               "localName":"Pilot name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"What business need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "example":"Tell us about the requested technology",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":true,
               "example":"Subdivision name",
               "sysName":"businessUnit",
               "required":false,
               "localName":"Subdivision",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "example":"Specify industry",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Industries",
               "multySelect":true
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Pdf file up to 5 MB",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"demoFile",
               "required":false,
               "localName":"Requirements",
               "maxLength":"5",
               "description":"You can attach a more detailed TOR for the pilot or a description of the case in a pdf file. The field is optional.",
               "allowedTypes":[
                  ".pdf"
               ]
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":true,
               "edited":true,
               "format":"hide",
               "sysName":"file",
               "required":true,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":true,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Technical task",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"true",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "example":"Question text",
               "sysName":"response[]_question",
               "required":false,
               "localName":"",
               "maxLength":"100"
            }
         ],
         "module":"Questions for a startup",
         "isArray":true,
         "subTitle":"Question №",
         "actionText":"Add a question",
         "moduleNote":"Here you can ask additional questions to the startup, which must be answered when applying for a pilot"
      }
   ]
}', NULL, 'Creation of a pilot', 2),
       (2, 'corporate_Administrator', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "direction":"row",
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false
            },
            {
               "type":"int",
               "edited":false,
               "format":"[1991;2021]",
               "sysName":"questionnaire_birthYear",
               "required":true,
               "direction":"row",
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name / brand name",
               "maxLength":100,
               "showLength":false
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Corporation website",
               "maxLength":"100",
               "showLength":false
            }
         ],
         "module":"Legal information about the organization",
         "moduleNote":"Information about the organization is automatically transferred from SberBusiness Online. Please fill in the missing data."
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_fio",
               "required":true,
               "localName":"Surname Name of the representative"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_role",
               "required":true,
               "localName":"Position"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"representative_phone",
               "required":true,
               "localName":"Mobile phone"
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"representative_email",
               "required":true,
               "localName":"Email"
            }
         ],
         "module":"Representative",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Choose the direction of your corporation",
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":true,
               "localName":"Direction of activity",
               "description":"Choose the direction of your corporation",
               "multySelect":true
            },
            {
               "note":"Choose how to innovate in your corporation ",
               "type":"array",
               "title":"Methods of working with innovations",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":true,
               "localName":"Specify methods",
               "description":"Choose how to innovate in your corporation",
               "multySelect":true
            },
            {
               "note":"Optional",
               "type":"array",
               "title":"Annual turnover",
               "edited":false,
               "format":"search_dropdown",
               "values":[
                  {
                     "code":"Micro enterprises — до 120 млн",
                     "name":"Micro enterprises — до 120 млн"
                  },
                  {
                     "code":"Small enterprises — до 800 млн",
                     "name":"Small enterprises — до 800 млн"
                  },
                  {
                     "code":"Meduim enterprises — до 2 млрд рублей",
                     "name":"Meduim enterprises — до 2 млрд рублей"
                  },
                  {
                     "code":"Big business — до 30 млрд рублей",
                     "name":"Big business — до 30 млрд рублей"
                  },
                  {
                     "code":"Biggest business — свыше 30 млрд рублей",
                     "name":"Biggest business — свыше 30 млрд рублей"
                  }
               ],
               "sysName":"questionnaire_turnover",
               "required":true,
               "localName":"Annual turnover"
            },
            {
               "note":"Describe the corporation in a few sentences",
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Description",
               "maxLength":"480"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Logofile",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"Corporation"
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Select the areas in which you are looking for startups",
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Directions",
               "description":"Select the areas in which you are looking for startups",
               "multySelect":true
            },
            {
               "note":"Select the stages of startup development you are interested in",
               "type":"array",
               "title":"Stages of startup development",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Development stage",
               "description":"Select the stages of startup development you are interested in",
               "multySelect":true
            }
         ],
         "module":"Working with startups"
      },
      {
         "page":1,
         "title":"Corporation needs",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "note":"Briefly describe the essence of your request to pilot a startup",
               "type":"string",
               "edited":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Need description",
               "maxLength":"520"
            }
         ],
         "module":"",
         "isArray":"true",
         "subTitle":"Need №",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":true,
               "localName":"Does your company have experience of cooperation with startups?"
            },
            {
               "note":"Optional",
               "type":"string",
               "title":"Information about cooperation with startups",
               "edited":false,
               "sysName":"questinnaire_startupInvestmentYears",
               "required":false,
               "localName":"How many years has your corporation been working with startups",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":false,
               "sysName":"questinnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":false,
               "sysName":"questinnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":false,
               "sysName":"questinnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            }
         ],
         "module":"Successful cases"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"investment_investment",
               "required":true,
               "localName":"Does your corporation invest in startups?"
            },
            {
               "note":"Choose areas of investment that interest you",
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions",
               "description":"Choose areas of investment that interest you",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnaire_successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_successPilots[]_company",
               "required":false,
               "localName":"Startup name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_successPilots[]_suggestCase",
               "required":false,
               "localName":"Case description",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Successful cases",
         "isArray":true,
         "subTitle":"Startup №",
         "withIndex":true,
         "actionText":"Add case",
         "moduleNote":"Optional. Indicate the names of startups with which your company had successful implementations, if you want other SberUnity users to see information about them",
         "triggerField":"investment_investment",
         "triggerValue":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_scouting",
               "required":true,
               "localName":"Do you see scouting as a tool for finding the right startups?"
            }
         ],
         "module":"Scouting",
         "moduleNote":"Selection of technological solutions for startups at the request of the customer"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"session_date",
               "required":false,
               "localName":"Visit time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of organization"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of registration*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":false,
               "localName":"Public name / brand name"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country of jurisdiction*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Public email address"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Corporation website"
            }
         ],
         "module":"Juridical information about the organization",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_fio",
               "required":false,
               "localName":"Surname Name of the representative*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_role",
               "required":false,
               "localName":"Position"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_phone",
               "required":false,
               "localName":"Mobile phone"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_email",
               "required":false,
               "localName":"Email*"
            }
         ],
         "module":"Representative",
         "pageName":"",
         "moduleNote":""
      },
      {
         "page":1,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":"Founder"
            },
            {
               "note":" It is important for startups to see personalities. Specify the responsible person of the corporation, which will be seen by other participants of the platform",
               "type":"string",
               "edited":false,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Name, surname of the representative",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Specify the position of the responsible person from the previous question",
               "type":"string",
               "edited":false,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Position",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Representative information",
         "actionText":"Add contact person"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":false,
               "localName":"Direction of activity"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":false,
               "localName":"Specify methods"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_turnover",
               "required":false,
               "localName":"Annual turnover"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_note",
               "required":false,
               "localName":"Short description"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Full description"
            },
            {
               "type":"logo",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo"
            }
         ],
         "module":"Corporation",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":false,
               "localName":"Development stage"
            }
         ],
         "module":"Working with startups",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Need description"
            }
         ],
         "module":"Corporation needs",
         "isArray":"true",
         "subTitle":"Need №",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":false,
               "localName":"Does your company have experience of cooperation with startups?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_startupInvestmentYears",
               "required":false,
               "localName":"How many years has your corporation been working with startups"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year"
            }
         ],
         "module":"Successful cases",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"investment_investment",
               "required":false,
               "localName":"Does your corporation invest in startups?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investments round"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups",
               "multySelect":true
            }
         ],
         "module":"Investments",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Startup name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"successPilots[]_suggestCase",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful investment cases",
         "isArray":true,
         "pageName":"",
         "subTitle":"Startup №",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_scouting",
               "required":false,
               "localName":"Do you see scouting as a tool for finding the right startups?*"
            }
         ],
         "module":"Scouting",
         "pageName":""
      }
   ]
}', NULL, 2),
       (4, 'pilot_Client', NULL, '{
   "form":[
      {
         "fields":[
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":false,
               "format":"bold",
               "sysName":"businessunit",
               "required":false,
               "localName":"Department"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"suggestCase",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"demoFile",
               "required":false,
               "localName":"Technical task"
            }
         ]
      }
   ]
}', NULL, 2),
       (11, 'New_Community_Corporate', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Name of the company",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Site of the company",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position in the startup",
               "maxLength":200,
               "showLength":false
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Tell us about your expectations from participating in the community",
               "type":"string",
               "edited":true,
               "sysName":"expectation",
               "required":true,
               "localName":"What do you expect from the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "note":"Tell us how you can help the community",
               "type":"string",
               "edited":true,
               "sysName":"useful",
               "required":true,
               "localName":"What can you give to the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "type":"int",
               "value":4,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Corporate application', 2),
       (11, 'New_Community_Mentor', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Link to website or account",
               "type":"string",
               "edited":true,
               "sysName":"facebook",
               "required":true,
               "localName":"Your website or Facebook account",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Marketing",
               "type":"string",
               "edited":true,
               "sysName":"expert",
               "required":true,
               "localName":"What area are you an expert in?",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"site",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Tell us about your expectations from participating in the community",
               "type":"string",
               "edited":true,
               "sysName":"expectation",
               "required":true,
               "localName":"What do you expect from the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "note":"Tell us how you can help the community",
               "type":"string",
               "edited":true,
               "sysName":"useful",
               "required":true,
               "localName":"What can you give to the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "type":"int",
               "value":5,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Application for a mentor/tracker', 2),
       (11, 'New_Community_StartUp', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Startup name",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to project site",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position in the startup",
               "maxLength":200,
               "showLength":false
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Tell us about your expectations from participating in the community",
               "type":"string",
               "edited":true,
               "sysName":"expectation",
               "required":true,
               "localName":"What do you expect from the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "note":"Tell us how you can help the community",
               "type":"string",
               "edited":true,
               "sysName":"useful",
               "required":true,
               "localName":"What can you give to the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "type":"int",
               "value":0,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Startup application', 2),
       (11, 'New_Community_BusinessAngel', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Name of business angel",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to website",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Select directions",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"What areas are you investing in?",
               "multySelect":true
            },
            {
               "note":"Select geography",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Interested geography of investments",
               "multySelect":true
            },
            {
               "note":"Select stages",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Investment stages of interest",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Number of venture projects in the portfolio"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Link to account",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Your Facebook account"
            },
            {
               "type":"int",
               "value":1,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Business angel Application', 2),
       (11, 'New_PreAuth_Community', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "items":[
                  {
                     "title":"Startup",
                     "content":"Community available to SberUnity members",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_StartUp&action=1&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "title":"Investor",
                     "content":"Available to funds, business angels and family offices",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "title":"Corporation",
                     "content":"Community of corporations in development",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_Corporate&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  }
               ],
               "edited":true,
               "format":"choice_blocks",
               "sysName":"role",
               "required":true,
               "localName":"Choose a role"
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Application for joining the SberStartup community', 2),
       (11, 'New_PreAuth_Community_Corporate', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Ivanov Ivan Ivanovich",
               "type":"string",
               "edited":true,
               "sysName":"fio",
               "required":true,
               "localName":"Full name",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Name of the company",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Site of the company",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position in the startup",
               "maxLength":200,
               "showLength":false
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Tell us about your expectations from participating in the community",
               "type":"string",
               "edited":true,
               "sysName":"expectation",
               "required":true,
               "localName":"What do you expect from the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "note":"Tell us how you can help the community",
               "type":"string",
               "edited":true,
               "sysName":"useful",
               "required":true,
               "localName":"What can you give to the community?",
               "maxLength":500,
               "showLength":false
            },
            {
               "type":"int",
               "value":4,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"userConsent_contract",
               "required":true,
               "localName":"I confirm that I have read <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms without reservation or limitation."
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Application for joining the SberStartup community', 2),
       (11, 'New_PreAuth_Community_VentureFond', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "items":[
                  {
                     "content":"Venture fund",
                     "default":true,
                     "clickAction":"view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "content":"Business angel",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "content":"Family office",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  }
               ],
               "edited":true,
               "format":"chip_selected",
               "sysName":"investorType",
               "required":true,
               "localName":"Select investor sub-role",
               "multySelect":false
            },
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Fund name",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to the foundation website",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position in the fund",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"Choose directions",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"What areas are you investing in?",
               "multySelect":true
            },
            {
               "note":"Select geography",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Interested geography of investments",
               "multySelect":true
            },
            {
               "note":"Select stages",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Investment stages of interest",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Number of venture projects in the portfolio"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Link to account",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Your Facebook account"
            },
            {
               "type":"int",
               "value":2,
               "edited":false,
               "format":"hide",
               "sysName":"investorType",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"userConsent_contract",
               "required":true,
               "localName":"I confirm that I have read <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms and conditions without reservations and restrictions."
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Application for joining the SberStartup community', 2),
       (11, 'New_PreAuth_Community_FamilyOffice', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "items":[
                  {
                     "content":"Venture fund",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "content":"Business angel",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "content":"Family office",
                     "default":true,
                     "clickAction":"view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  }
               ],
               "edited":true,
               "format":"chip_selected",
               "sysName":"investorType",
               "required":true,
               "localName":"Select investor sub-role",
               "multySelect":false
            },
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Family office name",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to the foundation website",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"Select directions",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"What areas are you investing in?",
               "multySelect":true
            },
            {
               "note":"Select geography",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Interested geography of investments",
               "multySelect":true
            },
            {
               "note":"Select stages",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Investment stages of interest",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Number of venture projects in the portfolio"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Link to account",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Your Facebook account"
            },
            {
               "type":"int",
               "value":3,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"userConsent_contract",
               "required":true,
               "localName":"I confirm that I have read <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms and conditions without reservations and restrictions."
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Application for joining the SberStartup community', 2),
       (3, 'vas_Client', NULL, '{
   "form":[
      {
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"service_category",
               "activity":[
                  10000
               ],
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"serviceCompany_note",
               "required":false,
               "localName":""
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"",
               "sysName":"serviceCompany_resourceURI",
               "required":false,
               "localName":""
            }
         ]
      },
      {
         "fields":[
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"service_smallNote",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"service_note",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"bodyhide",
               "sysName":"service_discount",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"bodybold",
               "sysName":"service_offer",
               "required":false,
               "localName":""
            },
            {
               "logo":"",
               "type":"info",
               "edited":false,
               "format":"button",
               "sysName":"service_offerUri",
               "required":false,
               "localName":"Get an offer",
               "clickActon":""
            }
         ],
         "module":"",
         "moduleNote":"",
         "moduleFormat":"card"
      }
   ]
}', NULL, 2),
       (1, 'corporate_Client', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Corporation name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":false,
               "localName":"Direction of activity"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Description"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":false,
               "localName":"Methods of working with innovations"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_turnover",
               "required":false,
               "localName":"Turnover"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Corporation website"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Industry"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":false,
               "localName":"Product Development Stages"
            }
         ],
         "module":"Working with startups (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Need description"
            }
         ],
         "module":"",
         "isArray":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Industry"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography"
            }
         ],
         "module":"Investments (Available by subscription)",
         "triggerField":"investment_investment",
         "triggerValue":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "format":"hide",
               "sysName":"successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Successful cases"
            }
         ],
         "module":"",
         "isArray":true,
         "triggerField":"investment_investment",
         "triggerValue":"true"
      }
   ]
}', 'Viewing the corporation profile', 2),
       (11, 'New_Community_VentureFond', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Fund name",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to the foundation website",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Manager",
               "type":"string",
               "edited":true,
               "sysName":"position",
               "required":true,
               "localName":"Your position in the fund",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"Select directions",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"What areas are you investing in?",
               "multySelect":true
            },
            {
               "note":"Select geography",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Interested geography of investments",
               "multySelect":true
            },
            {
               "note":"Select stages",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Investment stages of interest",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Number of venture projects in the portfolio"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Ссылка на аккаунт",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Your Facebook account"
            },
            {
               "type":"int",
               "value":2,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Application for joining the SberStartup communityп",
         "moduleNote":""
      }
   ]
}', NULL, 'Venture fund application', 2),
       (11, 'New_PreAuth_Community_BusinessAngel', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "items":[
                  {
                     "content":"Venture fund",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_VentureFond&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "content":"Business angel",
                     "default":true,
                     "clickAction":"view?type=11&name=New_PreAuth_Community_BusinessAngel&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  },
                  {
                     "content":"Family office",
                     "clickAction":"view?type=11&name=New_PreAuth_Community_FamilyOffice&action=2&preauthorize=true",
                     "clickMethod":"GET"
                  }
               ],
               "edited":true,
               "format":"chip_selected",
               "sysName":"investorType",
               "required":true,
               "localName":"Select investor sub-role",
               "multySelect":false
            },
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"What community of business angels are you already a member of?",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Link to the website",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Select directions",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"What areas are you investing in?",
               "multySelect":true
            },
            {
               "note":"Select geography",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Interested geography of investments",
               "multySelect":true
            },
            {
               "note":"Select stages",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Investment stages of interest",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Number of venture projects in the portfolio"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Email"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Contact phone number"
            },
            {
               "note":"Link to account",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Your Facebook account"
            },
            {
               "type":"int",
               "value":1,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"checkbox",
               "sysName":"userConsent_contract",
               "required":true,
               "localName":"I confirm that I have read <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">User Agreement</a> and accept its terms and conditions without reservations and restrictions."
            }
         ],
         "module":"Application for joining the SberStartup community",
         "moduleNote":""
      }
   ]
}', NULL, 'Application for joining the SberStartup community', 2),
       (2, 'investor_AdministratorBran', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"nformation about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"resourse"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":true,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logo"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the product",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Resourse"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":false,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the product",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (1, 'corporate_Administrator', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "direction":"row",
               "localName":"Name of company",
               "maxLength":70,
               "showLength":false
            },
            {
               "type":"int",
               "edited":false,
               "format":"[1991;2021]",
               "sysName":"questionnaire_birthYear",
               "required":true,
               "direction":"row",
               "localName":"Year of registration",
               "maxLength":4,
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":true,
               "localName":"Public name / brand name",
               "maxLength":100,
               "showLength":false
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Country of jurisdiction",
               "multySelect":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"questionnaire_email",
               "required":true,
               "localName":"Public email address"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":true,
               "localName":"Corporation website",
               "maxLength":"100",
               "showLength":false
            }
         ],
         "module":"Juridical information about the organization",
         "moduleNote":"Organization information is automatically transferred from SberBusiness Online. Please fill in the missing data."
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_fio",
               "required":true,
               "localName":"Surname Name of the representative"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_role",
               "required":true,
               "localName":"Position"
            },
            {
               "mask":"phone",
               "type":"string",
               "edited":false,
               "format":"phone",
               "sysName":"representative_phone",
               "required":true,
               "localName":"Mobile phone"
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"representative_email",
               "required":true,
               "localName":"Email"
            }
         ],
         "module":"Representative",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Choose the direction of your corporation",
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":true,
               "localName":"Direction of activity",
               "description":"Choose the direction of your corporation",
               "multySelect":true
            },
            {
               "note":"Choose how to innovate in your corporation ",
               "type":"array",
               "title":"Methods of working with innovations",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":true,
               "localName":"Specify methods",
               "description":"Choose how to innovate in your corporation",
               "multySelect":true
            },
            {
               "note":"Optional",
               "type":"array",
               "title":"Annual turnover",
               "edited":false,
               "format":"search_dropdown",
               "values":[
                  {
                     "code":"Microenterprises - up to 120 million",
                     "name":"Microenterprises - up to 120 million"
                  },
                  {
                     "code":"Small enterprises - up to 800 million",
                     "name":"Small enterprises - up to 800 million"
                  },
                  {
                     "code":"Medium enterprises — up to 2 billion rubles",
                     "name":"Medium enterprises — up to 2 billion rubles"
                  },
                  {
                     "code":"Large business — up to 30 billion rubles",
                     "name":"Large business — up to 30 billion rubles"
                  },
                  {
                     "code":"The largest business — over 30 billion rubles",
                     "name":"The largest business — over 30 billion rubles"
                  }
               ],
               "sysName":"questionnaire_turnover",
               "required":true,
               "localName":"Annual turnover"
            },
            {
               "note":"Describe the corporation in a few sentences",
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_note",
               "required":true,
               "localName":"Description",
               "maxLength":"480"
            },
            {
               "note":"We recommend uploading a 120x120 square image. PNG format",
               "type":"logo",
               "title":"Logofile",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo",
               "allowedTypes":[
                  ".png"
               ]
            }
         ],
         "module":"Corporation"
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Select the areas in which you are looking for startups",
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Directions",
               "description":"Select the areas in which you are looking for startups",
               "multySelect":true
            },
            {
               "note":"Select the stages of startup development you are interested in",
               "type":"array",
               "title":"Stages of startup development",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Development stage",
               "description":"Select the stages of startup development you are interested in",
               "multySelect":true
            }
         ],
         "module":"Working with startups"
      },
      {
         "page":1,
         "title":"Corporation needs",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "note":"Briefly describe the essence of your request to pilot a startup",
               "type":"string",
               "edited":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Need description",
               "maxLength":"520"
            }
         ],
         "module":"",
         "isArray":"true",
         "subTitle":"Need №",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":true,
               "localName":"Does your company have experience of cooperation with startups?"
            },
            {
               "note":"Optional",
               "type":"string",
               "title":"Information about cooperation with startups",
               "edited":false,
               "sysName":"questinnaire_startupInvestmentYears",
               "required":false,
               "localName":"How many years has your corporation been working with startups",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":false,
               "sysName":"questinnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":false,
               "sysName":"questinnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            },
            {
               "note":"Optional",
               "type":"string",
               "edited":false,
               "sysName":"questinnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year",
               "maxLength":"300",
               "triggerField":"questionnaire_successPilots",
               "triggerValue":"true"
            }
         ],
         "module":"Successful cases"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"investment_investment",
               "required":true,
               "localName":"Does your corporation invest in startups?"
            },
            {
               "note":"Choose areas of investment that interest you",
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions",
               "description":"Choose areas of investment that interest you",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups",
               "multySelect":true,
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnaire_successPilots[]_pilotid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_successPilots[]_company",
               "required":false,
               "localName":"Startup name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_successPilots[]_suggestCase",
               "required":false,
               "localName":"Case description",
               "maxLength":"300",
               "showLength":false
            }
         ],
         "module":"Successful cases",
         "isArray":true,
         "subTitle":"Startup №",
         "withIndex":true,
         "actionText":"Add case",
         "moduleNote":"Optional. Indicate the names of startups with which your company had successful implementations, if you want other SberUnity users to see information about them",
         "triggerField":"investment_investment",
         "triggerValue":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_scouting",
               "required":true,
               "localName":"Do you see scouting as a tool for finding the right startups?"
            }
         ],
         "module":"Scouting",
         "moduleNote":"Selection of technological solutions for startups at the request of the customer"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"session_date",
               "required":false,
               "localName":"Visit time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of registration*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_name",
               "required":false,
               "localName":"Public name / brand name"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_registrationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country of jurisdiction*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Public email address"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Corporation website"
            }
         ],
         "module":"Juridical information about the organization",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_fio",
               "required":false,
               "localName":"Surname Name of the representative*"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_role",
               "required":false,
               "localName":"Position"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_phone",
               "required":false,
               "localName":"Mobile phone"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"representative_email",
               "required":false,
               "localName":"Email*"
            }
         ],
         "module":"Representative",
         "pageName":"",
         "moduleNote":""
      },
      {
         "page":1,
         "title":"",
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_isFounder",
               "required":false,
               "localName":"Founder"
            },
            {
               "note":" It is important for startups to see personalities. Specify the responsible person of the corporation, which will be seen by other participants of the platform",
               "type":"string",
               "edited":false,
               "sysName":"workers[]_fio",
               "required":false,
               "localName":"Name, surname of the representative",
               "maxLength":"100",
               "showLength":false
            },
            {
               "note":"Indicate the position of the responsible person from the previous question",
               "type":"string",
               "edited":false,
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Role",
               "maxLength":"100",
               "showLength":false
            },
            {
               "type":"string",
               "edited":false,
               "format":"e-mail",
               "sysName":"workers[]_facebook",
               "required":false,
               "localName":"Email",
               "maxLength":"150",
               "showLength":false
            }
         ],
         "module":"Public contact",
         "isArray":"true",
         "pageName":"Representative information",
         "actionText":"Add contact person"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "title":"Directions",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_industry",
               "activity":[
                  22000
               ],
               "required":false,
               "localName":"Direction of activity"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_innovationMethod",
               "activity":[
                  4000
               ],
               "required":false,
               "localName":"Specify methods"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_turnover",
               "required":false,
               "localName":"Annual turnover"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_note",
               "required":false,
               "localName":"Brief description"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullNote",
               "required":false,
               "localName":"Full description"
            },
            {
               "type":"logo",
               "edited":false,
               "sysName":"questionnaire_logoFile",
               "required":false,
               "localName":"Download logo"
            }
         ],
         "module":"Corporation",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Technologies",
               "multySelect":true
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_stady",
               "activity":[
                  7000
               ],
               "required":false,
               "localName":"Development stage"
            }
         ],
         "module":"Working with startups",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"questionnairePilots[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnairePilots[]_suggestCase",
               "required":false,
               "localName":"Need description"
            }
         ],
         "module":"Corporation need",
         "isArray":"true",
         "subTitle":"Need №",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_successPilots",
               "required":false,
               "localName":"Does your company have experience of cooperation with startups?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_startupInvestmentYears",
               "required":false,
               "localName":"How many years has your corporation been working with startups"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_overallPilots",
               "required":false,
               "localName":"Total number of pilots/contracts (implementations) with startups for all time"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_lastYearInvestmentsCount",
               "required":false,
               "localName":"Number of pilots with startups in the last year"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_overallContracts",
               "required":false,
               "localName":"Number of contracts (implements) with startups over the past year"
            }
         ],
         "module":"Successful cases",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"investment_investment",
               "required":false,
               "localName":"oes your corporation invest in startups?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Directions"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"investment_round",
               "activity":[
                  6000
               ],
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Geography of startups",
               "multySelect":true
            }
         ],
         "module":"Investments",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"successPilots[]_company",
               "required":false,
               "localName":"Startup name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"successPilots[]_suggestCase",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful investment cases",
         "isArray":true,
         "pageName":"",
         "subTitle":"Startup №",
         "withIndex":true
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"questionnaire_scouting",
               "required":false,
               "localName":"Do you see scouting as a tool for finding the right startups?*"
            }
         ],
         "module":"Scouting",
         "pageName":""
      }
   ]
}', 'Corporation questionnaire', 2),
       (2, 'corporate_BusinessUnit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of organization"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Brief name"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"resourse"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based?"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":true,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sberbank did you interact with?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Ecosystem of Sberbank",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of company"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Resourse"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":false,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"Number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Команда",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sberbank did you interact with?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (0, 'startup_BusinessUnit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Company name"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Brief name"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"resourse"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":true,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of the market"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired workers"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sberbank did you interact with?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amountй"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Organization name"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Brief name"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Resourse"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":false,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired employeesв"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (5, 'Dossier', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "values":[
                  {
                     "code":12001,
                     "name":"Cooperation negotiations"
                  },
                  {
                     "code":12002,
                     "name":"Piloting"
                  },
                  {
                     "code":12003,
                     "name":"Pilot successful"
                  },
                  {
                     "code":12004,
                     "name":"Pilot unsuccessful"
                  },
                  {
                     "code":12005,
                     "name":"Contract signing"
                  },
                  {
                     "code":12006,
                     "name":"Contract"
                  },
                  {
                     "code":12007,
                     "name":"Other"
                  },
                  {
                     "code":12008,
                     "name":"Work completed"
                  }
               ],
               "sysName":"interactionState",
               "activity":[
                  12000
               ],
               "required":true,
               "localName":"Interaction status"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12001"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Date of the pilot",
               "triggerField":"interactionState",
               "triggerValue":"12002"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Piot KPI",
               "triggerField":"interactionState",
               "triggerValue":"12002"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Pilot end date",
               "triggerField":"interactionState",
               "triggerValue":"12003"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12003"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Pilot end date",
               "triggerField":"interactionState",
               "triggerValue":"12004"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12004"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12005"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Date of contact",
               "triggerField":"interactionState",
               "triggerValue":"12006"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12006"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12007"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Work completion date",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"score",
               "required":false,
               "localName":"Grade",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"needscore",
               "required":false,
               "localName":"Need assessment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"needcomment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"casescore",
               "required":false,
               "localName":"Case evaluation",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"casecomment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"kpiscore",
               "required":false,
               "localName":"KPI assessment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"kpicomment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"If not - why not?",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            }
         ],
         "module":"Add a note",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"dropdown",
               "values":[
                  {
                     "code":12001,
                     "name":"Cooperation negotiations"
                  },
                  {
                     "code":12002,
                     "name":"Piloting"
                  },
                  {
                     "code":12003,
                     "name":"Pilot successful"
                  },
                  {
                     "code":12004,
                     "name":"Pilot unsuccessful"
                  },
                  {
                     "code":12005,
                     "name":"Contract signing"
                  },
                  {
                     "code":12006,
                     "name":"Contact"
                  },
                  {
                     "code":12007,
                     "name":"Other"
                  },
                  {
                     "code":12008,
                     "name":"Work completed"
                  }
               ],
               "sysName":"interactionState",
               "activity":[
                  12000
               ],
               "required":true,
               "localName":"Interaction status"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12001"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Date of the pilot",
               "triggerField":"interactionState",
               "triggerValue":"12002"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Piloting KPI",
               "triggerField":"interactionState",
               "triggerValue":"12002"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Pilot end date",
               "triggerField":"interactionState",
               "triggerValue":"12003"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12003"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Pilot end date",
               "triggerField":"interactionState",
               "triggerValue":"12004"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12004"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12005"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Date of contact",
               "triggerField":"interactionState",
               "triggerValue":"12006"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12006"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12007"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"date",
               "required":false,
               "localName":"Work completion date",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"score",
               "required":false,
               "localName":"Grade",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"needscore",
               "required":false,
               "localName":"Need assessment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"needcomment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"casescore",
               "required":false,
               "localName":"Case evaluation",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"casecomment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"star",
               "edited":true,
               "sysName":"kpiscore",
               "required":false,
               "localName":"KPI assessment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"kpicomment",
               "required":false,
               "localName":"Comment",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"comment",
               "required":false,
               "localName":"If not - why not?",
               "triggerField":"interactionState",
               "triggerValue":"12008"
            }
         ],
         "module":"Add a note",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (2, 'corporate_AdministratorBran', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Organization name"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":true,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Brief name"
            },
            {
               "type":"date",
               "edited":true,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"resourse"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":true,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":true,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":true,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":true,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired employees"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":true,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Modified",
               "required":false,
               "localName":"Update time"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Questionnaire_typeName",
               "required":false,
               "localName":"Role"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_FullName",
               "required":false,
               "localName":"Name of the organization"
            },
            {
               "type":"string",
               "value":"Global Techologies",
               "edited":false,
               "sysName":"Questionnaire_name",
               "required":false,
               "localName":"Short title"
            },
            {
               "type":"date",
               "edited":false,
               "sysName":"Questionnaire_Birthday",
               "required":false,
               "localName":"Year of registration"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Questionnaire_RegistrationCountry",
               "required":false,
               "localName":"Country of jurisdiction"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_phonenumber",
               "required":false,
               "localName":"Phone number"
            }
         ],
         "module":"Organization",
         "moduleNote":"Information about the organization was automatically transferred from SberBusiness Online"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Resourse"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Contacts[]_value",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Contacts",
         "isArray":"true",
         "moduleNote":"Links to external resources"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_InteractionType",
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Questionnaire_Location",
               "required":false,
               "localName":"Where is the project based?"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "values":[
                  {
                     "code":1,
                     "name":"Personally"
                  },
                  {
                     "code":2,
                     "name":"Online"
                  }
               ],
               "sysName":"Project_Industry",
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"Logo",
               "edited":false,
               "sysName":"Questionnaire_Logo_File",
               "required":false,
               "localName":"Logofile"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"",
               "sysName":"Project_HaveMVP",
               "required":false,
               "localName":"MVP or ready-to-deploy technology"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoSite",
               "required":false,
               "localName":"URL link to demo"
            }
         ],
         "module":"Prototype",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Auditory",
               "required":false,
               "localName":"Target audience"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Project_DemoFile",
               "required":false,
               "localName":"Pitch-deck"
            }
         ],
         "module":"About the project",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"",
               "sysName":"Project_Geography",
               "required":false,
               "localName":"Geography of markets"
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"Project_Sales",
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "format":"URL",
               "sysName":"Investment_BusinessPlan",
               "required":false,
               "localName":"Business plan"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Turnover",
               "required":false,
               "localName":"What is the turnover per month/year"
            }
         ],
         "module":"Market",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_Competitor",
               "required":false,
               "localName":"Competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_UpSide",
               "required":false,
               "localName":"Advantages over competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Project_DownSide",
               "required":false,
               "localName":"Disadvantages over competitors "
            }
         ],
         "module":"Competitors",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_Staff",
               "required":false,
               "localName":"The number of employees"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"Project_HiringStaff",
               "required":false,
               "localName":"The number of hired employees"
            }
         ],
         "module":"Team",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":false,
               "sysName":"Workers[]_Role",
               "required":false,
               "localName":"Employee "
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Name",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"pilots[]_Note",
               "required":false,
               "localName":"Case description"
            }
         ],
         "module":"Successful pilots",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Pilot",
               "required":false,
               "localName":"Are you interested in piloting your product in the Sber Ecosystem or other corporations?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Case",
               "required":false,
               "localName":"Proposed case"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Pilots[]_Experience",
               "required":false,
               "localName":"Have you interacted with the Sber Ecosystem before?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_BusinessUnit",
               "required":false,
               "localName":"What business unit of Sber did you interact with?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Pilots[]_Reference",
               "required":false,
               "localName":"References"
            }
         ],
         "module":"Sber Ecosystem",
         "isArray":"true",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Investment_Investment",
               "required":false,
               "localName":"Do you attract investments?"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_SumInvestment",
               "required":false,
               "localName":"Required investment amount"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"Investment_Round",
               "required":false,
               "localName":"Investment round"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_LastInvestment",
               "required":false,
               "localName":"Previously raised investments"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"Investment_Co_Investment",
               "required":false,
               "localName":"The project has a co-investor"
            }
         ],
         "module":"Investments",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "sysName":"Questionnaire_Mentoring",
               "required":false,
               "localName":"Does the project need a mentor?"
            }
         ],
         "module":"Mentoring",
         "moduleNote":""
      }
   ]
}', NULL, 2),
       (4, 'pilot_SuperClient', NULL, '{
   "form":[
      {
         "fields":[
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":false,
               "format":"bold",
               "sysName":"businessunit",
               "required":false,
               "localName":"Subdivision"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"suggestCase",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "edited":false,
               "format":"chip",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"demoFile",
               "required":false,
               "localName":"Additional materials"
            }
         ]
      }
   ]
}', NULL, 2),
       (0, 'startup_Client', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"hyperlink",
               "edited":false,
               "isBlur":false,
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Additional contacts (Available by subscription)",
         "isArray":"true",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "isBlur":false,
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Product Video",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation (Available by subscription)"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets you plan to enter in the near future"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover"
            }
         ],
         "module":"About the project (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"project_staff",
               "required":false,
               "localName":"Total number of employees"
            }
         ],
         "module":"Team (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"worker_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":false,
               "format":"hide",
               "sysName":"worker_isFounder",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"worker_role",
               "required":false,
               "direction":"concatenation",
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience",
               "maxLength":"150"
            }
         ],
         "module":"",
         "isArray":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "isBlur":false,
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who had successful cases"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О- cases (Available by subscription)",
         "isArray":"true",
         "pageName":"",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "isBlur":false,
               "sysName":"investment_investment",
               "required":false,
               "localName":"The project attracts investments"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "isBlur":false,
               "sysName":"investment_planInvestment",
               "required":false,
               "localName":"The project plans to attract investments in the next 6 months",
               "triggerField":"investment_investment",
               "triggerValue":"false"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments (Available by subscription)"
      }
   ]
}', 'Viewing the startup profile', 2),
       (11, 'New_PreAuth_Community_StartUp', NULL, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"",
               "required":false,
               "localName":"Log in or register to fill out a form to join the SberStartup community. It is located in your personal account in the section «Сommunity»."
            }
         ],
         "module":"Joining the community is available to SberUnity members"
      }
   ]
}', NULL, 2),
       (4, 'pilot_edit', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"Short name of the requested technology in the nominative case",
               "type":"string",
               "edited":true,
               "example":"Requested technology name",
               "sysName":"name",
               "required":true,
               "localName":"Pilot name",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"What business need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "example":"Tell us about the requested technology",
               "sysName":"suggestCase",
               "required":true,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":true,
               "example":"Subdivision name",
               "sysName":"businessUnit",
               "required":false,
               "localName":"Subdivision",
               "maxLength":"200",
               "showLength":false
            },
            {
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "example":"Specify industry",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"Industries",
               "multySelect":true
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"pilotId",
               "required":false,
               "localName":""
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "note":"Pdf file up to 5 MB",
               "type":"hyperlink",
               "edited":true,
               "format":"URL",
               "sysName":"demoFile",
               "required":false,
               "localName":"Requirements",
               "maxLength":"5",
               "description":"You can attach a more detailed TOR for the pilot or a description of the case in a pdf file. The field is optional.",
               "allowedTypes":[
                  ".pdf"
               ]
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":true,
               "edited":true,
               "format":"hide",
               "sysName":"file",
               "required":true,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":true,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Technical task",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"true",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "example":"Question text",
               "sysName":"response[]_question",
               "required":false,
               "localName":"",
               "maxLength":"100"
            }
         ],
         "module":"Questions for a startup",
         "isArray":true,
         "subTitle":"Question №",
         "actionText":"Add a question",
         "moduleNote":"Here you can ask additional questions to the startup, which must be answered when applying for a pilot"
      }
   ]
}', '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"pilotId",
               "required":true,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Header",
               "maxLength":"140",
               "showLength":false
            },
            {
               "note":"Which department of the company do you want to cover?",
               "type":"string",
               "edited":true,
               "sysName":"businessUnit",
               "required":true,
               "localName":"Subdivision",
               "maxLength":"200",
               "showLength":false
            },
            {
               "note":"What need will startups address as part of the pilot?",
               "type":"string",
               "edited":true,
               "sysName":"suggestCase",
               "required":true,
               "localName":"Brief description of the request",
               "maxLength":"300"
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"conditions",
               "required":true,
               "localName":"Piloting conditions",
               "maxLength":"300"
            },
            {
               "type":"array",
               "edited":true,
               "format":"serch_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Add a theme or direction",
               "multySelect":true
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "edited":true,
               "format":"switch",
               "sysName":"file",
               "required":true,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"boolean",
               "value":"true",
               "edited":true,
               "format":"hide",
               "sysName":"isHub",
               "required":false,
               "localName":"Allow file uploads"
            },
            {
               "note":"Startups will be able to upload presentations tailored to your business need",
               "type":"string",
               "value":"20004",
               "edited":true,
               "format":"hide",
               "sysName":"state",
               "required":false,
               "localName":"Allow file uploads"
            }
         ],
         "module":"Main information",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"int",
               "edited":"true",
               "format":"hide",
               "sysName":"response[]_responseId",
               "required":"false",
               "localName":""
            },
            {
               "type":"int",
               "edited":true,
               "format":"hide",
               "sysName":"response[]_pilotId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":true,
               "sysName":"response[]_question",
               "required":false,
               "localName":"Question text",
               "maxLength":"100"
            },
            {
               "note":"Additional information, clarification of the question",
               "type":"string",
               "edited":true,
               "sysName":"response[]_questionDescription",
               "required":false,
               "localName":"Description",
               "maxLength":"100"
            }
         ],
         "module":"",
         "isArray":true,
         "actionText":"Add a question",
         "moduleNote":""
      }
   ]
}', 'Pilot editing', 2);