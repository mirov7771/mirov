--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-3699

DELETE FROM public.screen_buttons_link where screen_id in (select screen_button.screen_id from public.screen_button where name = 'corporate_Administrator'
                                                                                                                      and state = 20004
                                                                                                                      and main_check = true
                                                                                                                      and parent_check = false);
INSERT INTO public.screen_buttons_link (screen_id, button_id)
select screen_id , b.button_id
from public.screen_button sb
   ,public.buttons b
where name = 'corporate_Administrator'
  and state = 20004
  and main_check = true
  and parent_check = false
  and b.code in (20003, 20009, 100002);