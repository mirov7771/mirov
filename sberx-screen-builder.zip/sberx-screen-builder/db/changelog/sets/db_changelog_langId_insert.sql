--liquibase formatted sql
--changeset Fedorov EO:task_1
ALTER TABLE screen ADD lang_id bigint NULL;