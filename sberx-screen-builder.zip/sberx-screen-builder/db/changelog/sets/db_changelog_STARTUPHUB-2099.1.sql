--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-2099_1 Обновление пилота

UPDATE public.screen SET   formedit=' {
  "form": [
    {
      "module": "Основная информация",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "name",
          "localName": "Название пилота",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "140",
          "showLength": false
        },
        {
          "sysName": "suggestCase",
          "localName": "Краткое описание запроса",
          "type": "string",
          "note": "Какую потребность стартапы будут решать в рамках пилота?",
          "edited": true,
          "required": true,
          "maxLength": "300"
        },
        {
          "sysName": "businessUnit",
          "localName": "Подразделение",
          "note": "Потребность какого подразделения компании вы хотите закрыть?",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "200",
          "showLength": false
        },
        {
          "sysName": "industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "serch_dropdown",
          "activity": [
            3000
          ],
          "edited": true,
          "required": false,
          "multySelect": true
        },
        {
          "sysName": "demoFile",
          "localName": "Дополнительные материалы",
          "description": "Вы можете вложить более подробное ТЗ на пилот или описание кейса pdf-файлом. Поле опциональное.",
          "note": "Pdf файл до 5 МБ",
          "type": "hyperlink",
          "format": "URL",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },
        {
          "sysName": "file",
          "localName": "Разрешить загрузку файлов",
          "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
          "type": "boolean",
          "format": "hide",
          "value": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "isHub",
          "localName": "Разрешить загрузку файлов",
          "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "value": "true",
          "required": false
        }
      ]
    },
    {
      "module": "Вопросы стартапу",
      "moduleNote": "Здесь Вы можете задать дополнительные вопросы стартапу, на которые необходимо ответить при подаче заявки на пилот",
      "actionText": "Добавить вопрос",
      "subTitle": "Вопрос №",
      "isArray": true,
      "page": 1,
      "fields": [
        {
          "sysName": "response[]_responseId",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": "true",
          "required": "false"
        },
        {
          "sysName": "response[]_pilotId",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": false
        },
        {
          "sysName": "response[]_question",
          "localName": "Текст вопроса стартапу",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "100"
        }
      ]
    }
  ]
}' WHERE formname='New_Pilot';
UPDATE public.screen SET formedit=' {"form": [
          {
            "module": "Основная информация",
            "moduleNote": "",
            "page": 1,
            "fields": [
              {
                "sysName": "pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": true
              },{
                "sysName": "name",
                "localName": "Название пилота",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "140",
                "showLength": false
              },{
                "sysName": "suggestCase",
                "localName": "Краткое описание запроса",
                "type": "string",
                "note": "Какую потребность стартапы будут решать в рамках пилота?",
                "edited": true,
                "required": true,
                "maxLength": "300"
              },
              {
                "sysName": "businessUnit",
                "localName": "Подразделение",
                "note": "Потребность какого подразделения компании вы хотите закрыть?",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "200",
                "showLength": false
              },
              {
                "sysName": "industry",
                "localName": "Индустрии",
                "type": "array",
                "format": "serch_dropdown",
                "activity": [
                  3000
                ],
                "edited": true,
                "required": false,
                "multySelect": true
              }, {
        "sysName": "file",
        "localName": "Дополнительные материалы",
        "description": "Вы можете вложить более подробное ТЗ на пилот или описание кейса pdf-файлом. Поле опциональное.",
        "note": "Pdf файл до 5 МБ",
        "type": "hyperlink",
        "format": "URL",
        "allowedTypes": [".pdf"],
        "edited": true,
        "required": false
      },
              {
                "sysName": "file",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "value": true,
                "edited": true,
                "required": true
              },
              {
                "sysName": "isHub",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "edited": true,
                "value": "true",
                "required": false
              }
            ]
          },
          {
            "module": "Вопросы стартапу",
            "moduleNote": "Здесь Вы можете задать дополнительные вопросы стартапу, на которые необходимо ответить при подаче заявки на пилот",
            "actionText": "Добавить вопрос",
            "subTitle": "Вопрос №",
            "isArray": true,
            "page": 1,
            "fields": [
              {
                "sysName": "response[]_responseId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": "true",
                "required": "false"
              },
              {
                "sysName": "response[]_pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": false
              },
              {
                "sysName": "response[]_question",
                "localName": "Текст вопроса стартапу",
                "type": "string",
                "edited": true,
                "required": false,
                "maxLength": "100"
              }
              ]
          }
        ]
        }'::json::json WHERE formname='pilot_edit';
