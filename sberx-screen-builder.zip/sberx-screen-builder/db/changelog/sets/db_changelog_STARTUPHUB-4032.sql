--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4032
delete from public.buttons where code = 100009;

insert into public.buttons (code, text, lang_id) values (100009, 'Просмотреть историю', 1);

delete from public.screen_buttons_link where button_id = (select button_id from buttons where code = 100009);

insert into public.screen_buttons_link (screen_id, button_id)
select screen_id, (select button_id from buttons where code = 100009)
from public.screen_button sb
where "name" in ('startup_Administrator', 'corporate_Administrator', 'investor_Administrator');