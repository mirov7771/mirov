--liquibase formatted sql
--changeset Mirov A:SBERXTECH-195_2
update schemas
set value = '{"value":{
  "itemIdKey": "pilotId",
  "clickable": true,
  "columns": [
    {
      "sysName": "description",
      "type": "string",
      "title": "Название",
      "key": "name",
      "refs": {
        "maxLength": "100"
      }
    },
    {
      "sysName": "status",
      "type": "nameplate",
      "title": "",
      "key": "state",
      "refs": {
        "map": {
          "20001": "Draft",
          "20002": "На рассмотрении",
          "20003": "На доработку",
          "20005": "Архивный",
          "20007": "Удачный пилот",
          "20008": "Предлагаемый кейс",
          "20009": "Отклоненный"
        }
      }
    },
    {
      "sysName": "view",
      "type": "string",
      "title": "Просмотры",
      "key": "pilot_view"
    },
    {
      "sysName": "reply",
      "type": "string",
      "title": "Отклики",
      "key": "pilot_reply"
    },
    {
      "sysName": "newReply",
      "type": "badge",
      "title": "Новые",
      "key": "pilot_newReply"
    }
  ]
}}'
where name = 'pilots_active'