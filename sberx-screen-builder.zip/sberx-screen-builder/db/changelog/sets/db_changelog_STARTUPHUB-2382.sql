--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2382
update public.screen set
    formview = '{
      "form": [
        {
          "module": "Юридическая информация об организации",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Наименование организации",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год регистрации*",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_name",
              "localName": "Публичное название / название бренда",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_registrationCountry",
              "localName": "Страна юрисдикции*",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт корпорации",
              "type": "hyperlink",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Представитель",
          "page": 1,
          "pageName": "",
          "moduleNote": "",
          "fields": [
            {
              "sysName": "representative_fio",
              "localName": "Фамилия Имя представителя*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_role",
              "localName": "Должность",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_phone",
              "localName": "Мобильный телефон",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_email",
              "localName": "Электронная почта*",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Корпорация",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "title": "Направления",
              "sysName": "questionnaire_industry",
              "localName": "Направление деятельности",
              "type": "array",
              "format": "text",
              "activity": [
                22000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_innovationMethod",
              "localName": "Укажите методы",
              "type": "array",
              "format": "text",
              "activity": [
                4000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_turnover",
              "localName": "Годовой оборот",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_note",
              "localName": "Описание",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Работа со стартапами",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "project_industry",
              "localName": "Направления",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_stady",
              "localName": "Стадия развития",
              "type": "array",
              "format": "text",
              "activity": [
                7000
              ],
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Потребности корпорации",
          "page": 1,
          "subTitle": "Потребность №",
          "withIndex": true,
          "isArray": "true",
          "fields": [
            {
              "sysName": "questionnairePilots[]_pilotId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_suggestCase",
              "localName": "Описание потребности",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_successPilots",
              "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_startupInvestmentYears",
              "localName": "Сколько лет Ваша корпорация работает со стартапами",
              "type": "string",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_overallPilots",
              "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
              "type": "string",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_lastYearInvestmentsCount",
              "localName": "Количество пилотов со стартапами за последний год",
              "type": "string",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": false,
              "required": false
            },

            {
              "sysName": "questionnaire_overallContracts",
              "localName": "Количество контрактов (внедрений) со стартапами за последний год",
              "type": "string",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиции",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Инвестирует ли Ваша корпорация в стартапы?",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false
            },
            {
              "sysName": "investment_industry",
              "localName": "Направления",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд инвестиций",
              "type": "array",
              "format": "text",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_geography",
              "localName": "География стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                2000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Успешные кейсы инвестирования",
          "page": 1,
          "pageName": "",
          "isArray": true,
          "subTitle": "Стартап №",
          "withIndex": true,
          "fields": [
            {
              "sysName": "successPilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "successPilots[]_suggestCase",
              "localName": "Описание кейса",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Скаутинг",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_scouting",
              "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false
            }
          ]
        }
      ]
    }'
where formname in ('corporate_Administrator');