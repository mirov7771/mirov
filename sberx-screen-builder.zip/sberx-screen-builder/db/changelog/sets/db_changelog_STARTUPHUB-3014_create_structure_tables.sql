--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-3014

DROP TABLE IF EXISTS public.feature_types CASCADE;
CREATE TABLE public.feature_types
(
    code varchar primary key,
    name varchar
);

DROP TABLE IF EXISTS public.status_types CASCADE;
CREATE TABLE public.status_types
(
    code varchar primary key,
    name varchar
);

DROP TABLE IF EXISTS public.features CASCADE;
CREATE TABLE public.features
(
    id           bigserial primary key,
    code         varchar not null unique,
    name         varchar,
    status       varchar references public.status_types (code) not null,
    feature_type varchar references public.feature_types (code) not null,
    description  varchar
);

DROP TABLE IF EXISTS public.attribute_types CASCADE;
CREATE TABLE public.attribute_types
(
    code varchar primary key,
    name varchar
);


DROP TABLE IF EXISTS public.attributes CASCADE;
CREATE TABLE public.attributes
(
    id             bigserial primary key,
    name           varchar not null,
    code           varchar not null unique,
    is_system      boolean not null,
    attribute_type varchar references public.attribute_types (code) not null,
    description  varchar
);

DROP TABLE IF EXISTS public.locale CASCADE;
CREATE TABLE public.locale
(
    code varchar primary key,
    name varchar
);

DROP TABLE IF EXISTS public.values CASCADE;
CREATE TABLE public.values
(
    id     bigserial primary key,
    value  varchar,
    locale varchar references public.locale (code)
);

DROP TABLE IF EXISTS public.feature_attributes_values CASCADE;
CREATE TABLE public.feature_attributes_values
(
    id            bigserial primary key,
    id_attributes bigint references public.attributes (id),
    id_values     bigint references public.values (id) unique,
    id_features   bigint references public.features (id),
    id_parent     bigint references public.feature_attributes_values (id),
    status        varchar references public.status_types (code) not null,
    group_id      bigint,
    unique (id_attributes, id_features)
);

DROP TABLE IF EXISTS public.page_types CASCADE;
CREATE TABLE public.page_types
(
    code varchar primary key,
    name varchar
);

DROP TABLE IF EXISTS public.pages CASCADE;
CREATE TABLE public.pages
(
    id          bigserial primary key,
    code        varchar not null unique,
    name        varchar,
    URI         varchar not null,
    description varchar,
    page_type   varchar references public.page_types (code) not null,
    parent_id   bigint references public.pages (id),
    client_id   varchar
);

DROP TABLE IF EXISTS public.pages_features CASCADE;
CREATE TABLE public.pages_features
(
    id_pages          bigint references public.pages (id),
    id_features       bigint references public.features (id),
    is_visible        boolean not null,
    id_parent_feature bigint references public.features (id),
    primary key (id_pages, id_features)
);