--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3717
update public.screen
set formedit = '{
    "form": [
        {
            "module": "Organization",
            "page": 1,
            "pageName": "Legal information",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Name of organization",
                    "example": "Full legal name of your company",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_inn",
                    "localName": "Company identification number, for example, EIN",
                    "example": "Company identification number, for example, EIN",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_birthYear",
                    "localName": "Year of registration",
                    "example": "Specify the year your company was founded",
                    "type": "int",
                    "format": "year",
                    "mask": "2000;getyear",
                    "maxLength": 4,
                    "edited": true,
                    "required": true,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_name",
                    "localName": "Public name/Brand name",
                    "example": "For example, SberUnity",
                    "note": "Other users of the platform will see it in your profile",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "regExpError": "Use short name without legal form"
                },
                {
                    "sysName": "questionnaire_registrationCountry",
                    "localName": "Country of jurisdiction",
                    "example": "Select country of jurisdiction",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Website",
                    "example": "Website",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Please use specific format: https://sber-unity.ru",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_inviteFio",
                    "localName": "Contact person",
                    "example": "John Doe",
                    "type": "string",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Email",
                    "example": "Provide contact email",
                    "note": "This email will be visible to other platform users as your contact",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_phoneNumber",
                    "localName": "Phone number",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                }
            ]
        },
        {
            "module": "Additional links",
            "page": 1,
            "pageName": "Legal information",
            "moduleNote": "Specify links to external resources that give information about your product",
            "isArray": "true",
            "actionText": "Add link",
            "fields": [
                {
                    "sysName": "contacts[]_type",
                    "localName": "",
                    "title": "Resource",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        21000
                    ],
                    "edited": true,
                    "required": false,
                    "multySelect": false
                },
                {
                    "sysName": "contacts[]_name",
                    "example": "Link",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Please use specific format: https://sber-unity.ru",
                    "maxLength": "70",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "About the startup",
            "page": 2,
            "pageName": "Startup information 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_note",
                    "localName": "Brief descriprion of your product",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "200",
                    "example": "Describe your startup in one sentence",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Sales models",
                    "description": "What is your business model?",
                    "sysName": "project_interactionType",
                    "localName": "",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        8000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "questionnaire_businessModel",
                    "localName": "What is your revenue model?",
                    "example": "Select your revenue model",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        24000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "project_mvpCode",
                    "localName": "Startup stage",
                    "example": "Select your development stage",
                    "type": "array",
                    "format": "dropdown",
                    "activity": [
                        27000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_logoFile",
                    "title": "Startup logo",
                    "note": "Logo requirements: size should not exceed 200x200, 5mb, png or jpg",
                    "type": "logo",
                    "format": "200*200",
                    "maxLength": "5",
                    "edited": true,
                    "required": true,
                    "allowedTypes": [
                        ".png",
                        "jpg"
                    ]
                },
                {
                    "sysName": "project_demoVideo",
                    "localName": "Video about the product",
                    "example": "Link to the video",
                    "type": "string",
                    "maxLength": "255",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Please use specific link format: https://sber-unity.ru",
                    "edited": true,
                    "required": false,
                    "showLength": false
                },
                {
                    "title": "Where is your startup based?",
                    "description": "Indicate where your startup''''s headquarters are actually based",
                    "sysName": "questionnaire_locationCountry",
                    "localName": "Country",
                    "example": "Select country",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_location",
                    "localName": "City",
                    "example": "Enter city",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 30,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Tech verticals",
            "page": 2,
            "pageName": "Startup information 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "description": "Industries and technological verticals in which your startup operates",
                    "sysName": "project_industry",
                    "localName": "Industries",
                    "example": "Select industries",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_technology",
                    "localName": "Technologies",
                    "example": "Select technologies",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        13000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "About the product",
            "page": 3,
            "pageName": "Startup information 2/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_problem",
                    "localName": "The client problem that your product solves",
                    "example": "What client needs does your product fulfill",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_auditory",
                    "localName": "Target audience",
                    "example": "Describe your target audience",
                    "note": "Age, occupation, interests, etc.",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_businessPlan",
                    "localName": "",
                    "title": "Presentation",
                    "type": "hyperlink",
                    "maxLength": "50",
                    "format": "URL",
                    "note": "File size should not exceed 20mb, pdf",
                    "allowedTypes": [
                        ".pdf"
                    ],
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_geography",
                    "localName": "Countries of presence",
                    "example": "Type or select country",
                    "note": "Regions where your product is already presented",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_expansion",
                    "localName": "Markets that you are going to enter in the nearest future",
                    "example": "Type or select country",
                    "note": "Markets that you plan to access in a year",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "project_sales",
                    "localName": "Sales",
                    "example": "Choose your sales stage",
                    "note": "Indicate if you have sales",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        5000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_turnover",
                    "localName": "Annual turnover",
                    "example": "$",
                    "type": "string",
                    "maxLength": "300",
                    "note": "Gross turnover of the company for the last year",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Specify a number",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "project_competitor",
                    "localName": "Competitors",
                    "example": "Specify your competitors",
                    "type": "string",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_upSide",
                    "localName": "Advantages over competitors",
                    "example": "Tell about your advantages",
                    "note": "Specify in detail why you are better than your competitors",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_staff",
                    "localName": "Number of employees",
                    "example": "Specify total number of employees",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Key employees",
            "page": 3,
            "pageName": "Team",
            "isArray": "true",
            "title": "Tell about key team members",
            "actionText": "Add team member",
            "fields": [
                {
                    "sysName": "workers[]_parentId",
                    "localName": "",
                    "type": "long",
                    "format": "hide",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_isFounder",
                    "localName": "",
                    "type": "boolean",
                    "format": "hide",
                    "value": false,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_role",
                    "localName": "Role",
                    "example": "Team member role/position",
                    "type": "string",
                    "maxLength": "100",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_note",
                    "localName": "Brief role description",
                    "example": "Tell about your team member experience",
                    "type": "string",
                    "maxLength": "150",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Successful pilot projects",
            "page": 4,
            "pageName": "Piloting, First sales and Integrations",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_successPilots",
                    "title": "If you are B2B-, B2G-, B2B2C-startup: do you have successful pilot projects with corporations?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "",
            "page": 4,
            "pageName": "Piloting, first sales and Integrations",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true",
            "isArray": "true",
            "actionText": "Add case",
            "fields": [
                {
                    "sysName": "b2bPilots[]_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "value": "20007",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_reference",
                    "localName": "Company name you had a successful case with",
                    "example": "Specify company name",
                    "type": "string",
                    "maxLength": "140",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_suggestCase",
                    "localName": "Description and results of the pilot project",
                    "example": "Provide detailed information on the results of the above-mentioned case",
                    "type": "string",
                    "maxLength": "200",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "The Sber Ecosystem",
            "information": "Sber Ecosystem includes a wide range of companies. Read more on the [website](https://www.sberbank.com/eco)",
            "page": 4,
            "pageName": "Pilots",
            "fields": [
                {
                    "sysName": "questionnaire_pilot",
                    "title": "Are you interested in piloting your product with Sber or other corporations?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ecoPilot_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "value": "20008",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_suggestCase",
                    "localName": "Suggest a case",
                    "example": "If you have ideas on how to pilot your product, share them here",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "title": "Have you interacted with Sber Ecosystem?",
                    "sysName": "ecoPilot_experience",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Investments",
            "page": 4,
            "pageName": "Investments",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "investment_investment",
                    "title": "Are you looking for investments?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_lastInvestment",
                    "localName": "Amount of previously raised investments, total",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Please specify a number",
                    "maxLength": "300",
                    "edited": true,
                    "required": false,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "investment_coInvestment",
                    "localName": "Investors list",
                    "example": "List the investors from your captable",
                    "note": "Provided that the disclosure of this information does not contradict the agreements with investors",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Sber500 accelerator",
            "page": 5,
            "pageName": "Sber500",
            "fields": [
                {
                    "title": "Do you want to apply to Sber500?",
                    "information": "Sber500 is a unique accelerator based on the capabilities of Sber Ecosystem and experience of 500 Global: [https://sberbank-500.ru/en](https://sberbank-500.ru/en)",
                    "sysName": "questionnaire_sber500",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "value": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Have you previously applied to Sber500?",
                    "sysName": "sberFiveHundred_firsttime",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "sberFiveHundred_ecorequirement",
                    "localName": "What need of the Sber Ecosystem does your startup meet?",
                    "information": "A detailed description of the needs is published on the Sber500 accelerator website [https://sberbank-500.ru/en](https://sberbank-500.ru/en)",
                    "example": "Indicate the need",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        38000
                    ],
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "example": "$",
                    "sysName": "sberFiveHundred_monthrevenue",
                    "localName": "Revenue for the last month",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "You must specify a number",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_quarterrevenue",
                    "localName": "Revenue for the last three months",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "You must specify a number",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_clients",
                    "localName": "The number of active or paying customers in the last month",
                    "example": "Specify a number of clients",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500PrivacyPolicy",
                    "localName": "I agree to the processing of <a href=\"sber500PrivacyPolicyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">personal data for the participation in Sber500 accelerator</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500Consent",
                    "localName": "I agree to the processing <a href=\"sber500ConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">personal data for marketing purposes</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500TermOfUse",
                    "localName": "I agree to <a href=\"sber500TermOfUseURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">the rules of participation in Sber500 accelerator</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                }
            ]
        }
    ]
}'
where formname = 'New_StartUp' and lang_id != 1;

update public.screen
set formedit = '{
  "form": [
    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "example": "Полное юридическое название",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_inn",
          "localName": "Идентификационный номер компании",
          "example": "Укажите Ваш ИНН или иной регистрационный номер",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 40,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "example": "Укажите год регистрации юрлица",
          "type": "int",
          "format": "year",
          "mask": "2000;getyear",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название",
          "example": "Например, SberUnity",
          "note": "Под каким названием отображать анкету другим участникам платформы",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна регистрации юрлица",
          "example": "Выберите страну юрисдикции",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "example": "Адрес сайта",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "example": "Иванов Иван Иванович",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "example": "Укажите почту для связи",
          "note": "Данный email будет виден другим участникам платформы как контактный",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "format": "phone",
          "example": "+",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные ссылки",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах",
      "isArray": "true",
      "actionText": "Добавить ссылку",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "example": "Адрес ссылки",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О стартапе",
      "page": 2,
      "pageName": "Информация о стартапе 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_note",
          "localName": "Краткое описание стартапа",
          "type": "string",
          "rows": "3",
          "maxLength": "200",
          "example": "Опишите Ваш стартап одним предложением",
          "edited": true,
          "required": true
        },
        {
          "title": "Модели продаж",
          "description": "Укажите модели взаимодействия с клиентами в Вашем бизнесе",
          "sysName": "project_interactionType",
          "localName": "",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модель",
          "example": "Укажите бизнес-модель стартапа",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития стартапа",
          "example": "Выберите стадию развития",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип стартапа",
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "edited": true,
          "required": true,
          "allowedTypes": [
            ".png",
            ".jpg"
          ]
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о стартапе",
          "example": "Ссылка на видео",
          "type": "string",
          "maxLength": "255",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "title": "Где базируется Ваш стартап?",
          "description": "Укажите, где фактически находится штаб-квартира Вашего стартапа",
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "example": "Выберите страну",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "example": "Введите город",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 30,
          "showLength": false
        }
      ]
    },
    {
      "module": "Направления",
      "page": 2,
      "pageName": "Информация о стартапе 1/2",
      "moduleNote": "",
      "fields": [
        {
          "description": "Индустрии и технологические вертикали, в которых функционирует Ваш стартап",
          "sysName": "project_industry",
          "localName": "Индустрии",
          "example": "Выберите индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии",
          "example": "Выберите технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "О продукте",
      "page": 3,
      "pageName": "Информация о стартапе 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает Ваш продукт",
          "example": "Расскажите, какую задачу или проблему решает продукт",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "example": "Опишите Вашу целевую аудиторию",
          "note": "Возраст, род деятельности, интересы и т.д.",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "",
          "title": "Презентация",
          "type": "hyperlink",
          "maxLength": "50",
          "format": "URL",
          "note": "Вес файла — не более 20 МБ, формат pdf",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых Вы работаете",
          "example": "Введите или выберите страну",
          "note": "Регионы, на которых уже представлен Ваш продукт",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые планируете выходить",
          "example": "Введите или выберите страну",
          "note": "Регионы, на которые Вы планируете выйти в ближайший год",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "example": "Выберите тип продаж",
          "note": "Укажите стадию продаж Вашего продукта",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в год",
          "example": "$",
          "type": "string",
          "maxLength": "300",
          "note": "Валовый оборот компании за последний год в $",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "edited": true,
          "required": true,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "example": "Перечислите название компаний-конкурентов",
          "note": "Укажите конкурентов, близких к Вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "example": "Опишите преимущества Вашего продукта",
          "note": "Перечислите предметно, чем Вы лучше конкурентов",
          "type": "string",
          "rows": "3",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "example": "Укажите число сотрудников в штате",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Ключевые сотрудники",
      "page": 3,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые должности в стартапе закрыты",
      "actionText": "Добавить должность",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "example": "Название должности",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "example": "Опишите опыт сотрудника",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 4,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "title": "Если Вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "",
      "page": 4,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "example": "Опишите, с какой корпорацией у Вас был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "rows": "3",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "example": "Расскажите про кейс и его результаты",
          "type": "string",
          "maxLength": "200",
          "rows": "3",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)",
      "page": 4,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "title": "Заинтересованы ли Вы в пилотировании Вашего продукта в Экосистеме Сбера или у других корпораций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "title": "Предлагаемый кейс",
          "example": "Если у Вас есть идеи, как можно пилотировать Ваш продукт, опишите их в нескольких предложениях",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "title": "Есть ли у Вас опыт взаимодействия с экосистемой Сбера?",
          "sysName": "ecoPilot_experience",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 4,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "title": "Находитесь ли Вы в активном поиске инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Общий объём ранее привлеченных инвестиций",
          "example": "$",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Список инвесторов",
          "example": "Перечислите инвесторов, от которых получали инвестиции",
          "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселератор Sber500",
      "page": 5,
      "pageName": "Sber500",
      "fields": [
        {
          "title": "Хотите ли Вы подать заявку на участие в Sber500?",
          "information": "Sber500 - уникальный акселератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global: [https://sberbank-500.ru](https://sberbank-500.ru)",
          "sysName": "questionnaire_sber500",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "value": "true",
          "edited": true,
          "required": true
        },
        {
          "title": "Подавались ли Вы ранее в Sber500?",
          "sysName": "sberFiveHundred_firsttime",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "sberFiveHundred_ecorequirement",
          "title": "Какую потребность Экосистемы Сбера закрывает Ваш стартап?",
          "information": "Подробные описания потребностей [опубликованы](https://sberbank-500.ru) на сайте акселератора Sber500",
          "example": "Укажите потребность",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            38000
          ],
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "example": "$",
          "sysName": "sberFiveHundred_monthrevenue",
          "localName": "Выручка за последний месяц",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "sberFiveHundred_quarterrevenue",
          "localName": "Выручка за последние 3 месяца",
          "example": "$",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "sberFiveHundred_clients",
          "localName": "Количество активных или платящих клиентов за последний месяц",
          "example": "Укажите количество клиентов",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_sber500PrivacyPolicy",
          "localName": "Я даю согласие на <a href=\"sber500PrivacyPolicyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">обработку персональных данных</a> с целью участия в акселераторе Sber500",
          "type": "boolean",
          "format": "checkbox",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_sber500Consent",
          "localName": "Я даю согласие на обработку в <a href=\"sber500ConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">маркетинговых целях</a>",
          "type": "boolean",
          "format": "checkbox",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_sber500TermOfUse",
          "localName": "Я ознакомлен с <a href=\"sber500TermOfUseURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Правилами участия в программе Sber500</a>",
          "type": "boolean",
          "format": "checkbox",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}'
where formname = 'New_StartUp' and lang_id = 1;

update public.screen set formedit = '{
  "form": [
    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "example": "Полное юридическое название",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_inn",
          "localName": "Идентификационный номер компании",
          "example": "Укажите Ваш ИНН или иной регистрационный номер",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 40,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "example": "Укажите год регистрации юрлица",
          "type": "int",
          "format": "year",
          "mask": "2000;getyear",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название",
          "example": "Например, SberUnity",
          "note": "Под каким названием отображать анкету другим участникам платформы",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна регистрации юрлица",
          "example": "Выберите страну юрисдикции",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "example": "Адрес сайта",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "example": "Иванов Иван Иванович",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "example": "Укажите почту для связи",
          "note": "Данный email будет виден другим участникам платформы как контактный",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "format": "phone",
          "example": "+",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные ссылки",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах",
      "isArray": "true",
      "actionText": "Добавить ссылку",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "example": "Адрес ссылки",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О стартапе",
      "page": 2,
      "pageName": "Информация о стартапе 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_note",
          "localName": "Краткое описание стартапа",
          "type": "string",
          "rows": "3",
          "maxLength": "200",
          "example": "Опишите Ваш стартап одним предложением",
          "edited": true,
          "required": true
        },
        {
          "title": "Модели продаж",
          "description": "Укажите модели взаимодействия с клиентами в Вашем бизнесе",
          "sysName": "project_interactionType",
          "localName": "",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модель",
          "example": "Укажите бизнес-модель стартапа",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития стартапа",
          "example": "Выберите стадию развития",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип стартапа",
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "edited": true,
          "required": true,
          "allowedTypes": [
            ".png",
            ".jpg"
          ]
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о стартапе",
          "example": "Ссылка на видео",
          "type": "string",
          "maxLength": "255",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "title": "Где базируется Ваш стартап?",
          "description": "Укажите, где фактически находится штаб-квартира Вашего стартапа",
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "example": "Выберите страну",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "example": "Введите город",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 30,
          "showLength": false
        }
      ]
    },
    {
      "module": "Направления",
      "page": 2,
      "pageName": "Информация о стартапе 1/2",
      "moduleNote": "",
      "fields": [
        {
          "description": "Индустрии и технологические вертикали, в которых функционирует Ваш стартап",
          "sysName": "project_industry",
          "localName": "Индустрии",
          "example": "Выберите индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии",
          "example": "Выберите технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "О продукте",
      "page": 3,
      "pageName": "Информация о стартапе 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает Ваш продукт",
          "example": "Расскажите, какую задачу или проблему решает продукт",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "example": "Опишите Вашу целевую аудиторию",
          "note": "Возраст, род деятельности, интересы и т.д.",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "",
          "title": "Презентация",
          "type": "hyperlink",
          "maxLength": "50",
          "format": "URL",
          "note": "Вес файла — не более 20 МБ, формат pdf",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых Вы работаете",
          "example": "Введите или выберите страну",
          "note": "Регионы, на которых уже представлен Ваш продукт",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые планируете выходить",
          "example": "Введите или выберите страну",
          "note": "Регионы, на которые Вы планируете выйти в ближайший год",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "example": "Выберите тип продаж",
          "note": "Укажите стадию продаж Вашего продукта",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в год",
          "example": "$",
          "type": "string",
          "maxLength": "300",
          "note": "Валовый оборот компании за последний год в $",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "edited": true,
          "required": true,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "example": "Перечислите название компаний-конкурентов",
          "note": "Укажите конкурентов, близких к Вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "example": "Опишите преимущества Вашего продукта",
          "note": "Перечислите предметно, чем Вы лучше конкурентов",
          "type": "string",
          "rows": "3",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "example": "Укажите число сотрудников в штате",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Ключевые сотрудники",
      "page": 3,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые должности в стартапе закрыты",
      "actionText": "Добавить должность",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "example": "Название должности",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "example": "Опишите опыт сотрудника",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 4,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "title": "Если Вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "",
      "page": 4,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "example": "Опишите, с какой корпорацией у Вас был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "rows": "3",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "example": "Расскажите про кейс и его результаты",
          "type": "string",
          "maxLength": "200",
          "rows": "3",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)",
      "page": 4,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "title": "Заинтересованы ли Вы в пилотировании Вашего продукта в Экосистеме Сбера или у других корпораций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "title": "Предлагаемый кейс",
          "example": "Если у Вас есть идеи, как можно пилотировать Ваш продукт, опишите их в нескольких предложениях",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "title": "Есть ли у Вас опыт взаимодействия с экосистемой Сбера?",
          "sysName": "ecoPilot_experience",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 4,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "title": "Находитесь ли Вы в активном поиске инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Общий объём ранее привлеченных инвестиций",
          "example": "$",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Список инвесторов",
          "example": "Перечислите инвесторов, от которых получали инвестиции",
          "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
          "type": "string",
          "maxLength": "300",
          "rows": "3",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселератор Sber500",
      "page": 5,
      "pageName": "Sber500",
      "fields": [
        {
          "title": "Хотите ли Вы подать заявку на участие в Sber500?",
          "information": "Sber500 - уникальный акселератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global: [https://sberbank-500.ru](https://sberbank-500.ru)",
          "sysName": "questionnaire_sber500",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "value": "true",
          "edited": true,
          "required": true
        },
        {
          "title": "Подавались ли Вы ранее в Sber500?",
          "sysName": "sberFiveHundred_firsttime",
          "localName": "",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "sberFiveHundred_ecorequirement",
          "title": "Какую потребность Экосистемы Сбера закрывает Ваш стартап?",
          "information": "Подробные описания потребностей [опубликованы](https://sberbank-500.ru) на сайте акселератора Sber500",
          "example": "Укажите потребность",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            38000
          ],
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "example": "$",
          "sysName": "sberFiveHundred_monthrevenue",
          "localName": "Выручка за последний месяц",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "sberFiveHundred_quarterrevenue",
          "localName": "Выручка за последние 3 месяца",
          "example": "$",
          "type": "string",
          "regExp": "(^([0-9]{1,7}))",
          "regExpError": "Необходимо указать число",
          "maxLength": "300",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true,
          "showLength": false,
          "mask": "$"
        },
        {
          "sysName": "sberFiveHundred_clients",
          "localName": "Количество активных или платящих клиентов за последний месяц",
          "example": "Укажите количество клиентов",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_sber500PrivacyPolicy",
          "localName": "Я даю согласие на <a href=\"sber500PrivacyPolicyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">обработку персональных данных</a> с целью участия в акселераторе Sber500",
          "type": "boolean",
          "format": "checkbox",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_sber500Consent",
          "localName": "Я даю согласие на обработку в <a href=\"sber500ConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">маркетинговых целях</a>",
          "type": "boolean",
          "format": "checkbox",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_sber500TermOfUse",
          "localName": "Я ознакомлен с <a href=\"sber500TermOfUseURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Правилами участия в программе Sber500</a>",
          "type": "boolean",
          "format": "checkbox",
          "triggerField": "questionnaire_sber500",
          "triggerValue": "true",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}'
where formname = 'startup_edit' and lang_id = 1;

update public.screen set formedit = '{
    "form": [
        {
            "module": "Organization",
            "page": 1,
            "pageName": "Legal information",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Name of organization",
                    "example": "Full legal name of your company",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_inn",
                    "localName": "Company identification number, for example, EIN",
                    "example": "Company identification number, for example, EIN",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_birthYear",
                    "localName": "Year of registration",
                    "example": "Specify the year your company was founded",
                    "type": "int",
                    "format": "year",
                    "mask": "2000;getyear",
                    "maxLength": 4,
                    "edited": true,
                    "required": true,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_name",
                    "localName": "Public name/Brand name",
                    "example": "For example, SberUnity",
                    "note": "Other users of the platform will see it in your profile",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "regExpError": "Use short name without legal form"
                },
                {
                    "sysName": "questionnaire_registrationCountry",
                    "localName": "Country of jurisdiction",
                    "example": "Select country of jurisdiction",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Website",
                    "example": "Website",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Please use specific format: https://sber-unity.ru",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_inviteFio",
                    "localName": "Contact person",
                    "example": "John Doe",
                    "type": "string",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Email",
                    "example": "Provide contact email",
                    "note": "This email will be visible to other platform users as your contact",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_phoneNumber",
                    "localName": "Phone number",
                    "type": "string",
                    "format": "phone",
                    "example": "+",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                }
            ]
        },
        {
            "module": "Additional links",
            "page": 1,
            "pageName": "Legal information",
            "moduleNote": "Specify links to external resources that give information about your product",
            "isArray": "true",
            "actionText": "Add link",
            "fields": [
                {
                    "sysName": "contacts[]_type",
                    "localName": "",
                    "title": "Resource",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        21000
                    ],
                    "edited": true,
                    "required": false,
                    "multySelect": false
                },
                {
                    "sysName": "contacts[]_name",
                    "example": "Link",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Please use specific format: https://sber-unity.ru",
                    "maxLength": "70",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "About the startup",
            "page": 2,
            "pageName": "Startup information 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_note",
                    "localName": "Brief descriprion of your product",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "200",
                    "example": "Describe your startup in one sentence",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Sales models",
                    "description": "What is your business model?",
                    "sysName": "project_interactionType",
                    "localName": "",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        8000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "questionnaire_businessModel",
                    "localName": "What is your revenue model?",
                    "example": "Select your revenue model",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        24000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "project_mvpCode",
                    "localName": "Startup stage",
                    "example": "Select your development stage",
                    "type": "array",
                    "format": "dropdown",
                    "activity": [
                        27000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_logoFile",
                    "title": "Startup logo",
                    "note": "Logo requirements: size should not exceed 200x200, 5mb, png or jpg",
                    "type": "logo",
                    "format": "200*200",
                    "maxLength": "5",
                    "edited": true,
                    "required": true,
                    "allowedTypes": [
                        ".png",
                        "jpg"
                    ]
                },
                {
                    "sysName": "project_demoVideo",
                    "localName": "Video about the product",
                    "example": "Link to the video",
                    "type": "string",
                    "maxLength": "255",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Please use specific link format: https://sber-unity.ru",
                    "edited": true,
                    "required": false,
                    "showLength": false
                },
                {
                    "title": "Where is your startup based?",
                    "description": "Indicate where your startup''''s headquarters are actually based",
                    "sysName": "questionnaire_locationCountry",
                    "localName": "Country",
                    "example": "Select country",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_location",
                    "localName": "City",
                    "example": "Enter city",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 30,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Tech verticals",
            "page": 2,
            "pageName": "Startup information 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "description": "Industries and technological verticals in which your startup operates",
                    "sysName": "project_industry",
                    "localName": "Industries",
                    "example": "Select industries",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_technology",
                    "localName": "Technologies",
                    "example": "Select technologies",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        13000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "About the product",
            "page": 3,
            "pageName": "Startup information 2/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_problem",
                    "localName": "The client problem that your product solves",
                    "example": "What client needs does your product fulfill",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_auditory",
                    "localName": "Target audience",
                    "example": "Describe your target audience",
                    "note": "Age, occupation, interests, etc.",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_businessPlan",
                    "localName": "",
                    "title": "Presentation",
                    "type": "hyperlink",
                    "maxLength": "50",
                    "format": "URL",
                    "note": "File size should not exceed 20mb, pdf",
                    "allowedTypes": [
                        ".pdf"
                    ],
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_geography",
                    "localName": "Countries of presence",
                    "example": "Type or select country",
                    "note": "Regions where your product is already presented",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_expansion",
                    "localName": "Markets that you are going to enter in the nearest future",
                    "example": "Type or select country",
                    "note": "Markets that you plan to access in a year",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "project_sales",
                    "localName": "Sales",
                    "example": "Choose your sales stage",
                    "note": "Indicate if you have sales",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        5000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_turnover",
                    "localName": "Annual turnover",
                    "example": "$",
                    "type": "string",
                    "maxLength": "300",
                    "note": "Gross turnover of the company for the last year",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Specify a number",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "project_competitor",
                    "localName": "Competitors",
                    "example": "Specify your competitors",
                    "type": "string",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_upSide",
                    "localName": "Advantages over competitors",
                    "example": "Tell about your advantages",
                    "note": "Specify in detail why you are better than your competitors",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_staff",
                    "localName": "Number of employees",
                    "example": "Specify total number of employees",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Key employees",
            "page": 3,
            "pageName": "Team",
            "isArray": "true",
            "title": "Tell about key team members",
            "actionText": "Add team member",
            "fields": [
                {
                    "sysName": "workers[]_parentId",
                    "localName": "",
                    "type": "long",
                    "format": "hide",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_isFounder",
                    "localName": "",
                    "type": "boolean",
                    "format": "hide",
                    "value": false,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_role",
                    "localName": "Role",
                    "example": "Team member role/position",
                    "type": "string",
                    "maxLength": "100",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_note",
                    "localName": "Brief role description",
                    "example": "Tell about your team member experience",
                    "type": "string",
                    "maxLength": "150",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Successful pilot projects",
            "page": 4,
            "pageName": "Piloting, First sales and Integrations",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_successPilots",
                    "title": "If you are B2B-, B2G-, B2B2C-startup: do you have successful pilot projects with corporations?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "",
            "page": 4,
            "pageName": "Piloting, first sales and Integrations",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true",
            "isArray": "true",
            "actionText": "Add case",
            "fields": [
                {
                    "sysName": "b2bPilots[]_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "value": "20007",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_reference",
                    "localName": "Company name you had a successful case with",
                    "example": "Specify company name",
                    "type": "string",
                    "maxLength": "140",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_suggestCase",
                    "localName": "Description and results of the pilot project",
                    "example": "Provide detailed information on the results of the above-mentioned case",
                    "type": "string",
                    "maxLength": "200",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "The Sber Ecosystem",
            "information": "Sber Ecosystem includes a wide range of companies. Read more on the [website](https://www.sberbank.com/eco)",
            "page": 4,
            "pageName": "Pilots",
            "fields": [
                {
                    "sysName": "questionnaire_pilot",
                    "title": "Are you interested in piloting your product with Sber or other corporations?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ecoPilot_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "value": "20008",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_suggestCase",
                    "localName": "Suggest a case",
                    "example": "If you have ideas on how to pilot your product, share them here",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "title": "Have you interacted with Sber Ecosystem?",
                    "sysName": "ecoPilot_experience",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Investments",
            "page": 4,
            "pageName": "Investments",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "investment_investment",
                    "title": "Are you looking for investments?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_lastInvestment",
                    "localName": "Amount of previously raised investments, total",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Please specify a number",
                    "maxLength": "300",
                    "edited": true,
                    "required": false,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "investment_coInvestment",
                    "localName": "Investors list",
                    "example": "List the investors from your captable",
                    "note": "Provided that the disclosure of this information does not contradict the agreements with investors",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Sber500 accelerator",
            "page": 5,
            "pageName": "Sber500",
            "fields": [
                {
                    "title": "Do you want to apply to Sber500?",
                    "information": "Sber500 is a unique accelerator based on the capabilities of Sber Ecosystem and experience of 500 Global: [https://sberbank-500.ru/en](https://sberbank-500.ru/en)",
                    "sysName": "questionnaire_sber500",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "value": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Have you previously applied to Sber500?",
                    "sysName": "sberFiveHundred_firsttime",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "sberFiveHundred_ecorequirement",
                    "localName": "What need of the Sber Ecosystem does your startup meet?",
                    "information": "A detailed description of the needs is published on the Sber500 accelerator website [https://sberbank-500.ru/en](https://sberbank-500.ru/en)",
                    "example": "Indicate the need",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        38000
                    ],
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "example": "$",
                    "sysName": "sberFiveHundred_monthrevenue",
                    "localName": "Revenue for the last month",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "You must specify a number",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_quarterrevenue",
                    "localName": "Revenue for the last three months",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "You must specify a number",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_clients",
                    "localName": "The number of active or paying customers in the last month",
                    "example": "Specify a number of clients",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500PrivacyPolicy",
                    "localName": "I agree to the processing of <a href=\"sber500PrivacyPolicyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">personal data for the participation in Sber500 accelerator</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500Consent",
                    "localName": "I agree to the processing <a href=\"sber500ConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">personal data for marketing purposes</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500TermOfUse",
                    "localName": "I agree to <a href=\"sber500TermOfUseURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">the rules of participation in Sber500 accelerator</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                }
            ]
        }
    ]
}'
where formname = 'startup_edit' and lang_id != 1;