--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3539_3
UPDATE screen
SET  formview='{
  "form": [
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "hyperlink",
          "format": "hyperlink",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_cost",
          "localName": "Какова стоимость вашего решения",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "$"
        },
        {
          "sysName": "reply_process",
          "localName": "Как вы видите процесс пилотирования",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "reply_note",
          "localName": "Сопроводительное письмо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_fileURL",
          "localName": "Презентация",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_industry",
          "localName": "Индустрии стартапа",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии стартапа",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "moduleNote": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Дополнительные вопросы",
      "page": 1,
      "isArray": "true",
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "response[]_question",
          "localName": "",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false
        },
        {
          "sysName": "response[]_responseNote",
          "localName": "",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'
WHERE formname='reply_SuperClient';