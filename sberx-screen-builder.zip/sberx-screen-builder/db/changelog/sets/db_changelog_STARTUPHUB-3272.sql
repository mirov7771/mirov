--liquibase formatted sql
--changeset Kiryushin MG:STARTUPHUB-3272
alter table buttons
    add column click_action varchar null,
    add column click_method varchar null;