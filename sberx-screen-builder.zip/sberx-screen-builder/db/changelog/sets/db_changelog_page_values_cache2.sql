--liquibase formatted sql
--changeset Mirov AA:page_values_cache2
insert into page_values_cache
values('%round_size%', '0', 7, null, 'GET', '/list/round');