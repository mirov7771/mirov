--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3645
UPDATE screen
SET formview='{
  "form": [
    {
      "fields": [
        {
          "sysName": "businessunit",
          "localName": "Подразделение",
          "note": "Потребность какого подразделения компании вы хотите закрыть?",
          "type": "string",
          "format": "bold",
          "edited": false,
          "required": false
        },
        {
          "sysName": "suggestCase",
          "localName": "",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "industry",
          "localName": "",
          "type": "array",
          "format": "chip",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "demoFile",
          "localName": "Техническое задание",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'
WHERE formname='pilot_Client';

UPDATE screen
SET formedit='{
  "form": [
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "reply_cost",
          "localName": "Какова стоимость Вашего решения",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "30",
          "mask": "$",
          "note": "Сумма, в которую Вы оцениваете ваш пилотный запуск",
          "example": "$"
        },
        {
          "sysName": "reply_process",
          "localName": "Как Вы видите процесс пилотирования",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "500",
          "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
          "example": "Комментарий",
          "rows": "3"
        },
        {
          "sysName": "reply_note",
          "localName": "Сопроводительное письмо",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "500",
          "example": "Опишите подробно Ваш оффер по данному пилоту",
          "rows": "3"
        },
        {
          "sysName": "pilotId",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_tableName",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "Pilot"
        },
        {
          "sysName": "reply_state",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "0"
        },
        {
          "sysName": "reply_fileURL",
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "format": "URL",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Вопросы корпорации",
      "page": 1,
      "isArray": "true",
      "moduleType": "question",
      "fields": [
        {
          "sysName": "response",
          "type": "string",
          "format": "question",
          "edited": false,
          "required": false,
          "example": "Ваш вопрос"
        }
      ]
    }
  ]
}', "name"= 'Заявка на пилотирование'
WHERE formname='pilot_Client_Extra';