--liquibase formatted sql
--changeset Timofeev VV:SBERXTECH-73
update public.screen set buttons = '{
  "buttons": [
    {
      "icon": "Lock",
      "text": "Получить",
      "variant": "disabled",
      "description": "Сервис будет доступен после проверки анкеты"
    }
  ]
}'
where formname = 'vas_Client' and type = 3;