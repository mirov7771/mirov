--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3370_3
delete
from public.screen_buttons_link sbl
where button_id = (select button_id from public.buttons b where code = '100000')
  and screen_id not in (select screen_id from public.screen_button sb where name like 'reply%');

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'pilot_SuperClient'
    limit 1), (select button_id from public.buttons where code = 20009 limit 1));
