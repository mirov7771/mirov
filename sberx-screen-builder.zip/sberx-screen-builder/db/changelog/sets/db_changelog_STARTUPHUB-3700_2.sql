--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3700_2
update public.screen
set formview = '{
    "form": [
        {
            "module": "Организация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "Questionnaire_Modified",
                    "localName": "Время обновления",
                    "type": "date",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Наименование организации",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_inn",
                    "localName": "ИНН организации",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_birthYear",
                    "localName": "Год регистрации",
                    "type": "int",
                    "maxLength": 4,
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_name",
                    "localName": "Публичное название / название бренда",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Сайт",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_transcription",
                    "localName": "Транскрипция",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_registrationCountry",
                    "localName": "Страна юрисдикции*",
                    "type": "text",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_inviteFio",
                    "localName": "Контактное лицо",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Электронная почта",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_phoneNumber",
                    "localName": "Номер телефона",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Дополнительные контакты",
            "page": 1,
            "pageName": "",
            "isArray": "true",
            "fields": [
                {
                    "sysName": "contacts[]_type",
                    "localName": "",
                    "title": "Ресурс",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        21000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "contacts[]_name",
                    "localName": "Ссылка",
                    "type": "hyperlink",
                    "format": "URL",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "О проекте",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "project_interactionType",
                    "localName": "Бизнес-модели взаимодействия с пользователями",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        8000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_businessModel",
                    "localName": "Бизнес-модели",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        24000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_locationCountry",
                    "localName": "Страна",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_location",
                    "localName": "Город",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_industry",
                    "localName": "Индустрии",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        3000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_technology",
                    "localName": "Технологии",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        13000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_note",
                    "localName": "Краткое описание проекта",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "questionnaire_logoFile",
                    "localName": "Загрузить логотип",
                    "type": "logo",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Прототип",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "project_mvpCode",
                    "localName": "Стадия развития продукта",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        27000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_demoSite",
                    "localName": "URL ссылка на демо",
                    "type": "string",
                    "triggerField": "project_haveMVP",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_demoVideo",
                    "localName": "Видео о продукте",
                    "type": "hyperlink",
                    "format": "URL",
                    "triggerField": "project_haveMVP",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "О проекте",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "project_problem",
                    "localName": "Проблема, которую решает проект",
                    "type": "string",
                    "note": "Опишите в 1–2 предложениях",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_auditory",
                    "localName": "Целевая аудитория",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "investment_businessPlan",
                    "localName": "Загрузить презентацию",
                    "type": "hyperlink",
                    "format": "URL",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_pitchVideo",
                    "localName": "Видео питча",
                    "type": "hyperlink",
                    "format": "URL",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Рынок",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_geography",
                    "localName": "Рынки, на которых вы работаете",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_expansion",
                    "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_sales",
                    "localName": "Продажи",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        5000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "investment_turnover",
                    "localName": "Оборот в год (в USD)",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Конкуренты",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "project_competitor",
                    "localName": "Прямые конкуренты",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_indirectCompetitor",
                    "localName": "Косвенные конкуренты",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_upSide",
                    "localName": "Преимущества перед конкурентами",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "project_downSide",
                    "localName": "Недостатки перед конкурентами",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Команда",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "project_staff",
                    "localName": "Общее количество сотрудников",
                    "type": "int",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "",
            "page": 1,
            "pageName": "",
            "isArray": "true",
            "fields": [
                {
                    "sysName": "workers[]_parentId",
                    "localName": "",
                    "type": "long",
                    "format": "hide",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_isFounder",
                    "localName": "Является основателем",
                    "type": "boolean",
                    "format": "hide",
                    "value": false,
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_role",
                    "localName": "Роль сотрудника в команде",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_note",
                    "localName": "Краткое описание опыта",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
            "page": 1,
            "pageName": "",
            "isArray": "true",
            "fields": [
                {
                    "sysName": "b2bPilots[]_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "value": "20007",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_reference",
                    "localName": "С кем был успешный кейс",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_suggestCase",
                    "localName": "Описание и результаты кейса",
                    "type": "string",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Успешные B2C-, C2C- кейсы",
            "page": 1,
            "pageName": "",
            "isArray": "true",
            "fields": [
                {
                    "sysName": "b2cPilots[]_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "value": "20007",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "b2cPilots[]_reference",
                    "localName": "С кем был успешный кейс",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "b2cPilots[]_suggestCase",
                    "localName": "Описание и результаты кейса",
                    "type": "string",
                    "triggerField": "questionnaire_successPilotsB2C",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Экосистема Сбера",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "questionnaire_pilot",
                    "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
                    "type": "boolean",
                    "format": "switch",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "value": "20008",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_suggestCase",
                    "localName": "Предлагаемый кейс*",
                    "type": "string",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_experience",
                    "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
                    "type": "boolean",
                    "format": "switch",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_businessUnit",
                    "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
                    "type": "string",
                    "triggerField": "ecoPilot_experience",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Инвестиции",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "investment_lastInvestment",
                    "localName": "Объем ранее привлеченных инвестиций, всего",
                    "type": "string",
                    "triggerField": "investment_investment",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "investment_coInvestment",
                    "localName": "Имя/ имена инвестора/ инвесторов",
                    "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
                    "type": "string",
                    "triggerField": "investment_investment",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Акселераторы Сбера",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "questionnaire_acceleratorCode",
                    "localName": "Является выпускником:",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        26000
                    ],
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Сообщества",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "questionnaire_community",
                    "localName": "Хотите участвовать в сообществах СберСтартап",
                    "type": "boolean",
                    "format": "switch",
                    "edited": false,
                    "required": false
                }
            ]
        },
        {
            "module": "Акселератор Sber500",
            "page": 1,
            "pageName": "Sber500",
            "fields": [
                {
                    "information": "Sber500 - уникальный акелератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global",
                    "sysName": "questionnaire_sber500",
                    "localName": "Хочет ли стартап подать заявку на участие в Sber500?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "sberFiveHundred_firsttime",
                    "localName": "Подавался ли стартап ранее в Sber500?",
                    "type": "boolean",
                    "format": "switch",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "sberFiveHundred_ecorequirement",
                    "localName": "Какую потребность Экосистемы Сбера закрывает стартап?",
                    "example": "Укажите потребность",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        38000
                    ],
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "multySelect": true,
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "sberFiveHundred_monthrevenue",
                    "localName": "Выручка за последний месяц",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false,
                    "showLength": false
                },
                {
                    "sysName": "sberFiveHundred_quarterrevenue",
                    "localName": "Выручка за последние 3 месяца",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false,
                    "showLength": false
                },
                {
                    "sysName": "sberFiveHundred_clients",
                    "localName": "Количество активных или платящих клиентов за последний месяц",
                    "example": "Укажите количество клиентов",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}'
where formname = 'startup_Administrator';