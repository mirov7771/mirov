--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-2412

update public.screen set formview = '{ "form": [{
  "module": "Основная информация",
  "page": 1,
  "fields": [{
    "sysName": "project_note",
    "localName": "Краткое описание проекта",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_problem",
    "localName": "Проблема, которую решает проект",
    "type": "string",
    "edited": false,
    "required": false
  },  {
    "sysName": "project_auditory",
    "localName": "Целевая аудитория",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "title": "Перейти",
    "type": "hyperlink",
    "format": "button",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_acceleratorCode",
    "localName": "Является выпускником:",
    "type": "array",
    "format": "text",
    "activity": [26000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_birthYear",
    "localName": "Год основания",
    "type": "int",
    "edited": false,
    "required": false
  },{
    "sysName": "project_interactionType",
    "localName": "Модель продаж",
    "type": "array",
    "format": "text",
    "activity": [8000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_businessModel",
    "localName": "Бизнес-модели",
    "type": "array",
    "format": "search_dropdown",
    "activity": [
      24000
    ],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_industry",
    "localName": "Индустрии проекта",
    "type": "array",
    "format": "text",
    "activity": [3000],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_technology",
    "localName": "Технологии проекта",
    "type": "array",
    "format": "text",
    "activity": [13000],
    "edited": false,
    "required": false
  },{
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false
        }
  ]
}, {
  "module": "Дополнительные ссылки",
  "page": 1,
  "pageName": "",
  "isArray": "true",
   "moduleFormat" : "button",
  "fields": [
    {
          "sysName": "contacts[]_type",
          "localName": "",
          "type": "array",
          "format": "heading",
          "activity": [
            21000
          ],
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "contacts[]_name",
          "title": "Перейти",
          "type": "info",
          "format": "button",
          "edited": false,
          "required": false
    }
  ]
},{
  "module": "О проекте",
  "page": 1,
  "fields": [{
    "sysName": "project_mvpCode",
    "localName": "Стадия развития продукта",
    "type": "array",
    "format": "text",
    "activity": [27000],
    "edited": false,
    "required": false
  }, {
      "sysName": "project_sales",
      "localName": "Продажи",
      "type": "array",
      "format": "text",
      "activity": [5000],
      "edited": false,
      "required": false
    }, {
      "sysName": "investment_turnover",
      "localName": "Оборот",
      "type": "string",
      "edited": false,
      "required": false
    }, {
    "sysName": "project_demoSite",
    "localName": "Ссылка на демо",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "project_demoVideo",
    "localName": "Видео о продукте",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },
    {
      "sysName": "investment_businessPlan",
      "localName": "Презентация",
      "type": "hyperlink",
      "title": "Смотреть",
      "format": "button",
      "edited": false,
      "required": false
    },{
      "sysName": "project_pitchVideo",
      "localName": "Видео питча",
      "type": "hyperlink",
      "title": "Смотреть",
      "format": "button",
      "edited": false,
      "required": false

    },  {
      "sysName": "project_geography",
      "localName": "Рынки, на которых работает стартап",
      "type": "array",
      "format": "text",
      "activity": [2000],
      "edited": false,
      "required": false
    },{
      "sysName": "project_expansion",
      "localName": "Рынки, на которые стартап планирует выйти в будущем",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }
  ]
}, {
  "module": "Конкуренты",
  "page": 1,
  "fields": [{
    "sysName": "project_competitor",
    "localName": "Прямые конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_indirectCompetitor",
    "localName": "Косвенные конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_upSide",
    "localName": "Преимущества перед конкурентами",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_downSide",
    "localName": "Недостатки перед конкурентами ",
    "type": "string",
    "edited": false,
    "required": false
  }
  ]
}, {
  "module": "Команда",
  "page": 1,
  "fields": [


    {
      "sysName": "questionnaire_locationCountry",
      "localName": "Страна, где находится команда",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },
    {
      "sysName": "questionnaire_location",
      "localName": "Город, где находится команда",
      "type": "string",
      "edited": false,
      "required": false
    },
    {
      "sysName": "project_staff",
      "localName": "Количество сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }, {
      "sysName": "project_hiringStaff",
      "localName": "Из них наемных сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }
  ]
},  {
  "module": "",
  "page": 1,
  "isArray": "true",
  "moduleFormat" : "card",
  "fields": [{
    "sysName": "workers[]_parentId",
    "localName": "",
    "type": "long",
    "format": "hide",
    "edited": false,
    "required": false
  },{
    "sysName": "workers[]_role",
    "localName": "Ключевые члены команды",
    "type": "string",
    "format": "heading",
    "edited": false,
    "required": false
  },{
    "sysName": "workers[]_note",
    "localName": "Опыт",
    "type": "string",
    "format": "body",
    "edited": false,
    "required": false
  }
  ]
}, {
"module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
"moduleNote": "",
"page": 1,
"pageName": "",
"isArray": "true",
"moduleFormat" : "card",
"fields": [
{
"sysName": "b2bPilots[]_state",
"localName": "",
"type": "array",
"format": "hide",
"value": "20007",
"edited": false,
"required": false
},
{
"sysName": "b2bPilots[]_reference",
"localName": "",
"type": "string",
"format": "heading",
"edited": false,
"required": false
},
{
"sysName": "b2bPilots[]_suggestCase",
"localName": "",
"type": "string",
"format": "body",
"edited": false,
"required": false
}
]
}, {
  "module": "Успешные B2C-, C2C- кейсы",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "moduleFormat" : "card",
  "fields": [
    {
      "sysName": "b2cPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "format": "heading",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "format": "body",
      "edited": false,
      "required": false
    }
  ]
},{
  "module": "Инвестиции",
  "page": 1,
  "fields": [{
    "sysName": "investment_investment",
    "localName": "Привлекаете ли вы инвестиции?",
    "type": "boolean",
    "format": "switch",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_round",
    "localName": "Раунд",
    "type": "array",
    "format": "chip",
    "activity": [6000],
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_sumInvestment",
    "localName": "Требуемая сумма (USD)",
    "type": "int",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_lastInvestment",
    "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_coInvestment",
    "localName": "Имя/ имена инвестора/ инвесторов",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }
  ]
},{
  "module": "Дополнительная информация",
  "page": 1,
  "fields": [
    {
      "sysName": "project_addNote",
      "localName": "Что еще важно знать о проекте?",
      "type": "string",
      "maxLength": "500",
      "edited": false,
      "required": false
    }
  ]
}
]
}' where formname = 'startup_SuperClient';
