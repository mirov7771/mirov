--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5156
delete from screen where formname = 'New_User';

insert into screen (type, formname, formedit, name, description, lang_id)
values (15, 'New_User', '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "note": "Отправим на него ссылку на авторизацию и временный пароль",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "login",
                    "required": true,
                    "example": "Корпоративный email"
                }
            ],
            "module": "",
            "moduleNote": ""
        }
    ]
}', 'Добавления пользователя', 'Новому пользователю не придётся самостоятельно регистрироваться. Он будет закреплен за профилем вашей компании. Приглашение будет действительно 5 дней.', 1);

insert into screen (type, formname, formedit, name, description, lang_id)
values (15, 'New_User', '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "note": "We will send a link to authorization and a temporary password to it",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "sysName": "login",
                    "required": true,
                    "example": "Corporate email"
                }
            ],
            "module": "",
            "moduleNote": ""
        }
    ]
}', 'Add new user', 'A new user will not have to register on their own. It will be assigned to your company profile. The invitation will be valid for 5 days.', 2);
