--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-4733_3
delete from pages where uri like '/import-substitution%' and lang_id = 2;

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_en', 'SberUnity Import substitution', '/import-substitution', 'Import substitution',  'auth',
        '{
   "features":[
      {
         "config":{

         },
         "type":"participantSearch",
         "foundsTitle":"Find: {0}",
         "header":"Import substitution solution",
         "participant":"startupsRecommend",
         "placeholder":"Find a startup",
         "position":1,
         "shownFromTitle":"Shown {0} from {1}",
         "sortLabels":{
            "alphabetically":"Alphabetically",
            "byUpdateDate":"By update date"
         },
         "sysName":"startupsRecommend_en_participantSearch",
         "title":"Import substitution solution",
         "isImport":true,
         "visible":true
      }
   ]
}', 2);

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_auth_rec_en', 'SberUnity import substitution', '/import-substitution/recommended', 'import substitution',  'auth',
        '{
   "features":[
      {
         "config":{

         },
         "type":"participantSearch",
         "foundsTitle":"Find: {0}",
         "header":"Recommended",
         "participant":"startupsRecommend",
         "placeholder":"Find a startup",
         "position":1,
         "shownFromTitle":"Shown {0} from {1}",
         "sortLabels":{
            "alphabetically":"Alphabetically",
            "byUpdateDate":"By update date"
         },
         "sysName":"startupsRecommend_en_participantSearch",
         "title":"Recommended",
         "goBackLink":{
            "to":"/main/import-substitution"
         },
         "isImport":true,
         "visible":true
      }
   ]
}', 2);