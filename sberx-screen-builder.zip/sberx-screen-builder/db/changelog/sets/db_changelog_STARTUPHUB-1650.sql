--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1650 добавление кнопок для карточки стартапа на лендинге

UPDATE public.screen SET   buttons='{
  "buttons": [
    {
      "icon": "",
      "type": "active",
      "text": "Зарегистрироваться",
      "action": "/participant-registration",
      "variant": "primary",
      "description": ""
    },{
      "icon": "",
      "type": "active",
      "text": "Войти",
      "action": "/auth",
      "variant": "primary",
      "description": ""
    }
  ]
}
  '::json::json WHERE formname='startup';
