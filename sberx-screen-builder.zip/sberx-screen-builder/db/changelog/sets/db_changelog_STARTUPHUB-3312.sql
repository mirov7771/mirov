--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3312

insert into public.screen_button (name, admin_check, state)
values ('pilot_Administrator', true, 20009);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button sb where name = 'pilot_Administrator' and state = 20009 limit 1), (select button_id from buttons where code = 20009 limit 1));