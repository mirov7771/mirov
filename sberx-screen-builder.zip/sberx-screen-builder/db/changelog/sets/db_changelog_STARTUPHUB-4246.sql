--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4246
update public."schemas"
set value = '{
    "value": {
        "clickable": true,
        "columns": [
            {
                "sysName": "pilot",
                "type": "string",
                "title": "Название запроса",
                "key": "pilotName"
            },
            {
                "sysName": "startup",
                "type": "string",
                "title": "Стартап",
                "key": "questionnaireName"
            },
            {
                "sysName": "view_date",
                "type": "date",
                "title": "Дата и время отклика",
                "key": "date"
            },
            {
                "sysName": "status",
                "type": "nameplate",
                "title": "Статус",
                "key": "state",
                "refs": {
                    "map": {
                        "20011": "Новый",
                        "20002": "В работе",
                        "20004": "Пилотируется",
                        "20009": "Отказ",
                        "20003": "Пауза",
                        "20007": "Завершен"
                    }
                }
            }
        ]
    }
}'
where name = 'reply_search';