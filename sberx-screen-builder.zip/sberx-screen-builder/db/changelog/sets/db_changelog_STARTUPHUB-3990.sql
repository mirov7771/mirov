--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3990
insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('startup_Administrator', true, true, false, 20001);
insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('startup_Administrator', true, true, false, 20003);
insert into public.screen_button (name, admin_check, main_check, state) values ('startup_Administrator', true, false, 20003);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('corporate_Administrator', true, true, false, 20001);
insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('corporate_Administrator', true, true, false, 20003);
insert into public.screen_button (name, admin_check, main_check, state) values ('corporate_Administrator', true, false, 20003);

insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('investor_Administrator', true, true, false, 20001);
insert into public.screen_button (name, admin_check, main_check, parent_check, state) values ('investor_Administrator', true, true, false, 20003);
insert into public.screen_button (name, admin_check, main_check, state) values ('investor_Administrator', true, false, 20003);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001 limit 1)
       ,(select button_id from buttons where code = 100002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001 limit 1)
       ,(select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 100002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'startup_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'startup_Administrator' and admin_check = true and main_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 20012));



insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001 limit 1)
       ,(select button_id from buttons where code = 100002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001 limit 1)
       ,(select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 100002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'corporate_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'corporate_Administrator' and admin_check = true and main_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 20012));



insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001 limit 1)
       ,(select button_id from buttons where code = 100002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20001 limit 1)
       ,(select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 100002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'investor_Administrator' and admin_check = true and main_check = true and parent_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where "name" = 'investor_Administrator' and admin_check = true and main_check = false and state = 20003 limit 1)
       ,(select button_id from buttons where code = 20012));