--liquibase formatted sql
--changeset Mirov AA:metric_add
update screen
set formedit = '{
    "form":
    [
        {
            "page": 1,
            "fields":
            [
                {
                    "localName": "Тип метрики",
                    "example": "Выберите тип",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "search_dropdown",
                    "sysName": "type",
                    "multySelect": false
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "1"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "2"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "3"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "4"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "5"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "6"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "7"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "9"
                },
                {
                    "localName": "Валюта",
                    "type": "array",
                    "required": true,
                    "edited": true,
                    "format": "dropdown",
                    "sysName": "currency",
                    "multySelect": false,
                    "activity":
                    [
                        41000
                    ],
                    "triggerField": "type",
                    "triggerValue": "10"
                }
            ]
        },
        {
            "page": 1,
            "module": "Значения метрики",
            "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
            "isArray": "true",
            "actionText": "Добавить значение",
			"triggerField": "currency",
 			"triggerValue": "",
            "fields":
            [
                {
	              "sysName": "items_value",
	              "localName": "Значение",
	              "type": "int",
	              "edited": true,
	              "required": true,
	              "direction": "row",
	              "example": "Введите число"
	            },
	            {
	              "sysName": "items_date",
	              "localName": "Дата",
	              "type": "date",
	              "edited": true,
	              "required": true,
	              "direction": "row",
	              "example": "Укажите дату"
	            }
            ]
        },
        {
            "page": 1,
            "module": "Значения метрики",
            "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
            "isArray": "true",
            "actionText": "Добавить значение",
          	"triggerField": "currency",
          	"triggerValue": "41001",
            "fields":
            [
	            {
	              "sysName": "items_value",
	              "localName": "Значение",
	              "type": "int",
	              "edited": true,
	              "required": true,
	              "mask": "$",
	              "direction": "row",
	              "example": "Введите число"
	            },
	            {
	              "sysName": "items_date",
	              "localName": "Дата",
	              "type": "date",
	              "edited": true,
	              "required": true,
	              "direction": "row",
	              "example": "Укажите дату"
	            }
            ]
        },
        {
            "page": 1,
            "module": "Значения метрики",
            "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
            "isArray": "true",
            "actionText": "Добавить значение",
          	"triggerField": "currency",
          	"triggerValue": "41002",
            "fields":
            [
                {
	              "sysName": "items_value",
	              "localName": "Значение",
	              "type": "int",
	              "edited": true,
	              "required": true,
	              "mask": "₽",
	              "direction": "row",
	              "example": "Введите число"
            	},
            	{
	              "sysName": "items_date",
	              "localName": "Дата",
	              "type": "date",
	              "edited": true,
	              "required": true,
	              "direction": "row",
	              "example": "Укажите дату"
            	}
            ]
        }
    ]
}'
where formname = 'add_metric';