--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.screen
set formedit = '{
  "form":[
    {
      "page":1,
      "fields":[
        {
          "note":"Enter the full juridical name of your company",
          "type":"string",
          "edited":true,
          "sysName":"questionnaire_fullName",
          "required":true,
          "localName":"Name of company",
          "maxLength":70,
          "showLength":false
        },
        {
          "note":"Specify the year your company was founded",
          "type":"int",
          "edited":true,
          "format":"[1991;2021]",
          "sysName":"questionnaire_birthYear",
          "required":true,
          "localName":"Year of registration",
          "maxLength":4,
          "showLength":false
        },
        {
          "note":"Specify under what name to display your profile for other platform participants",
          "type":"string",
          "edited":true,
          "sysName":"questionnaire_name",
          "required":true,
          "localName":"Public name",
          "maxLength":100,
          "showLength":false
        },
        {
          "note":"Select the country where your company is registered",
          "type":"array",
          "edited":true,
          "format":"text",
          "sysName":"questionnaire_registrationCountry",
          "activity":[
            2000
          ],
          "required":true,
          "localName":"Country of jurisdiction",
          "multySelect":false
        },
        {
          "note":"This mail will be visible to other members of the platform",
          "type":"string",
          "edited":true,
          "format":"e-mail",
          "sysName":"questionnaire_email",
          "required":true,
          "localName":"Public email"
        },
        {
          "note":"We recommend that you provide a link not to the main website of the company, but to a page that is most relevant to startups (for example, an accelerator landing page)",
          "type":"string",
          "edited":true,
          "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
          "sysName":"questionnaire_site",
          "required":true,
          "localName":"Corporation website",
          "maxLength":"100",
          "showLength":false,
          "regExpError":"You must specify the site in the format: https://sber-unity.ru"
        }
      ],
      "module":"Juridical information about the organization",
      "pageName":"Juridical information about the organization",
      "moduleNote":""
    },
    {
      "page":2,
      "fields":[
        {
          "type":"string",
          "edited":true,
          "sysName":"representative_fio",
          "required":true,
          "localName":"Name, surname of the representative"
        },
        {
          "type":"string",
          "edited":true,
          "sysName":"representative_role",
          "required":true,
          "localName":"Job title"
        },
        {
          "mask":"phone",
          "type":"string",
          "edited":true,
          "format":"phone",
          "example":"+",
          "sysName":"representative_phone",
          "required":true,
          "localName":"Mobile phone"
        },
        {
          "type":"string",
          "edited":true,
          "format":"e-mail",
          "sysName":"representative_email",
          "required":true,
          "localName":"Email"
        }
      ],
      "module":"Representative contact",
      "pageName":"Representative information",
      "moduleNote":"Specify an employee whom SberUnity administrators can contact regarding the placement of your profile"
    },
    {
      "page":2,
      "title":"",
      "fields":[
        {
          "type":"long",
          "edited":false,
          "format":"hide",
          "sysName":"workers[]_parentId",
          "required":false,
          "localName":""
        },
        {
          "type":"boolean",
          "value":false,
          "edited":true,
          "format":"hide",
          "sysName":"workers[]_isFounder",
          "required":false,
          "localName":""
        },
        {
          "note":" It is important for startups to see personalities. Specify the responsible person contact, which will be used by other participants of the platform",
          "type":"string",
          "edited":true,
          "sysName":"workers[]_fio",
          "required":false,
          "localName":"Name, surname of the representative",
          "maxLength":"100",
          "showLength":false
        },
        {
          "note":"Indicate the position of the responsible person from the previous question",
          "type":"string",
          "edited":true,
          "sysName":"workers[]_role",
          "required":false,
          "localName":"Position",
          "maxLength":"100",
          "showLength":false
        },
        {
          "type":"string",
          "edited":true,
          "format":"e-mail",
          "sysName":"workers[]_facebook",
          "required":false,
          "localName":"Email",
          "maxLength":"150",
          "showLength":false
        }
      ],
      "module":"Public contact",
      "isArray":"true",
      "pageName":"Representative information",
      "actionText":"Add contact person"
    },
    {
      "page":3,
      "fields":[
        {
          "note":"Describe your company in one sentence",
          "type":"string",
          "edited":true,
          "sysName":"questionnaire_note",
          "required":true,
          "localName":"Краткое описание",
          "maxLength":"150"
        },
        {
          "note":"Describe your company in more detail",
          "type":"string",
          "edited":true,
          "sysName":"questionnaire_fullNote",
          "required":true,
          "localName":"Full description",
          "maxLength":"480"
        },
        {
          "type":"array",
          "title":"Directions",
          "edited":true,
          "format":"search_dropdown",
          "sysName":"questionnaire_industry",
          "activity":[
            22000
          ],
          "required":true,
          "localName":"Direction of activity",
          "description":"List all industries relevant to your company",
          "multySelect":true
        },
        {
          "note":"Logo size: up to 1200x1200. File weight - no more than 5 MB, format png, jpg.",
          "type":"logo",
          "title":"Logofile",
          "edited":true,
          "format":"1200*1200",
          "sysName":"questionnaire_logoFile",
          "required":false,
          "localName":"Download logo",
          "maxLength":"5",
          "description":"We made the field required to improve the quality of the member base",
          "allowedTypes":[
            ".png",
            ".jpg"
          ]
        }
      ],
      "module":"Corporation",
      "pageName":"Corporation information"
    },
    {
      "page":4,
      "fields":[
        {
          "type":"array",
          "title":"Methods of working with innovations",
          "edited":true,
          "format":"search_dropdown",
          "sysName":"questionnaire_innovationMethod",
          "activity":[
            4000
          ],
          "required":true,
          "localName":"Specify methods",
          "description":"Choose methods of innovations implementation in your corporation",
          "multySelect":true
        },
        {
          "type":"array",
          "title":"Stages of startup development",
          "edited":true,
          "format":"search_dropdown",
          "sysName":"questionnaire_stady",
          "activity":[
            7000
          ],
          "required":true,
          "localName":"Development stage",
          "description":"Select the stages of startup development you are interested in",
          "multySelect":true
        },
        {
          "type":"array",
          "edited":true,
          "format":"search_dropdown",
          "sysName":"project_technology",
          "activity":[
            13000
          ],
          "required":true,
          "localName":"technologies",
          "multySelect":true
        },
        {
          "type":"array",
          "title":"Directions",
          "edited":true,
          "format":"search_dropdown",
          "sysName":"project_industry",
          "activity":[
            3000
          ],
          "required":true,
          "localName":"Industries",
          "description":"Indicate all areas relevant to your company",
          "multySelect":true
        }
      ],
      "module":"Working with startups",
      "pageName":"Conditions for working with startups"
    },
    {
      "page":5,
      "fields":[
        {
          "type":"boolean",
          "edited":true,
          "format":"switch",
          "sysName":"questionnaire_successPilots",
          "required":true,
          "localName":"Does your company have experience of cooperation with startups?"
        },
        {
          "note":"Optional",
          "type":"int",
          "title":"Information about cooperation with startups",
          "edited":true,
          "sysName":"questionnaire_startupInvestmentYears",
          "required":false,
          "localName":"How many years has your corporation been working with startups",
          "triggerField":"questionnaire_successPilots",
          "triggerValue":"true"
        },
        {
          "note":"Optional",
          "type":"int",
          "edited":true,
          "sysName":"questionnaire_overallPilots",
          "required":false,
          "localName":"Total number of pilots/contracts (implementations) with startups for all time",
          "triggerField":"questionnaire_successPilots",
          "triggerValue":"true"
        },
        {
          "note":"Optional",
          "type":"int",
          "edited":true,
          "sysName":"questionnaire_lastYearInvestmentsCount",
          "required":false,
          "localName":"Number of pilots with startups in the last year",
          "triggerField":"questionnaire_successPilots",
          "triggerValue":"true"
        },
        {
          "note":"Optional",
          "type":"int",
          "edited":true,
          "sysName":"questionnaire_overallContracts",
          "required":false,
          "localName":"Number of contracts (implements) with startups over the past year",
          "triggerField":"questionnaire_successPilots",
          "triggerValue":"true"
        }
      ],
      "module":"Successful cases",
      "pageName":"Piloting"
    },
    {
      "page":6,
      "fields":[
        {
          "type":"boolean",
          "edited":true,
          "format":"switch",
          "sysName":"investment_investment",
          "required":true,
          "localName":"Does your corporation invest in startups?"
        },
        {
          "type":"array",
          "edited":true,
          "format":"chip",
          "sysName":"investment_round",
          "activity":[
            6000
          ],
          "required":true,
          "localName":"Investment round",
          "multySelect":true,
          "triggerField":"investment_investment",
          "triggerValue":"true"
        },
        {
          "note":"In startups from which regions you are ready to invest",
          "type":"array",
          "edited":true,
          "format":"search_dropdown",
          "sysName":"project_geography",
          "activity":[
            2000
          ],
          "required":true,
          "localName":"Geography of startups",
          "multySelect":true,
          "triggerField":"investment_investment",
          "triggerValue":"true"
        }
      ],
      "module":"Investments",
      "pageName":"Investments"
    },
    {
      "page":6,
      "fields":[
        {
          "type":"long",
          "edited":false,
          "format":"hide",
          "sysName":"successPilots[]_pilotid",
          "required":false,
          "localName":""
        },
        {
          "type":"string",
          "edited":true,
          "sysName":"successPilots[]_company",
          "required":false,
          "localName":"Startup name",
          "maxLength":"140",
          "showLength":false
        },
        {
          "type":"string",
          "edited":true,
          "sysName":"successPilots[]_suggestCase",
          "required":false,
          "localName":"Case description",
          "maxLength":"300",
          "showLength":false
        }
      ],
      "module":"Successful cases",
      "isArray":true,
      "pageName":"Investments",
      "subTitle":"Startup №",
      "withIndex":true,
      "actionText":"Add case",
      "moduleNote":"Optional. Indicate the names of startups with which your company had successful implementations, if you want other SberUnity users to see information about them",
      "triggerField":"investment_investment",
      "triggerValue":true
    },
    {
      "page":7,
      "fields":[
        {
          "type":"boolean",
          "edited":true,
          "format":"switch",
          "sysName":"questionnaire_scouting",
          "required":true,
          "localName":"Do you consider custom scouting as a tool for finding the right startups?"
        }
      ],
      "module":"Scouting",
      "pageName":"Scouting"
    }
  ]
}'
where formname = 'corporate_edit'
  and lang_id = 2;