--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4429
alter table screen add column if not exists info text;