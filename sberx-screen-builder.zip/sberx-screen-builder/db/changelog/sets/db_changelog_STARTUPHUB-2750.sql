--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2750
update public.screen set
    formview = '{
      "form": [
        {
          "module": "Юридическая информация об организации",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Наименование организации",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год регистрации",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_name",
              "localName": "Публичное название / название бренда",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_registrationCountry",
              "localName": "Страна юрисдикции*",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Данные профиля",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_investorType",
              "localName": "Выберите тип инвестора",
              "type": "array",
              "format": "chip",
              "activity": [
                11000
              ],
              "edited": false,
              "required": false
            },{
              "sysName": "questionnaire_note",
              "localName": "Укажите краткое описание Вашего фонда",
              "note": "Например: Фонд и акселератор",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "type": "string",
              "maxLength": 150,
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_note",
              "localName": "Укажите свою краткую характеристику как бизнес-ангела",
              "note":"Например, Рассматриваю любые проекты",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11002",
              "type": "string",
              "maxLength": 150,
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_note",
              "localName": "Укажите краткое описание Вашего family-office",
              "note": "Например: Фонд семьи Безосов",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "type": "string",
              "maxLength": 150,
              "edited": false,
              "required": false
            },{
              "sysName": "questionnaire_fullNote",
              "localName": "Укажите полное описание Вашего фонда",
              "note": "Например: Фонд и акселератор",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "type": "string",
              "maxLength": 1000,
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_fullNote",
              "localName": "Укажите свою полную характеристику как бизнес-ангела",
              "note":"Например, Рассматриваю любые проекты",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11002",
              "type": "string",
              "maxLength": 1000,
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_fullNote",
              "localName": "Укажите полное описание Вашего family-office",
              "note": "Например: Фонд семьи Безосов",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "type": "string",
              "maxLength": 1000,
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "type": "hyperlink",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11003",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11002",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11003",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11001",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11003",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11004",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Ваши данные",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить фото",
              "type": "logo",
              "triggerField": "questionnaire_investorType",
              "triggerValue": "11002",
              "edited": false,
              "required": false
            },{
              "sysName": "questionnaire_portfolioNote",
              "localName": "Краткое описание портфельного стартапа",
              "type": "string",
              "maxLength": "300",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_fio",
              "localName": "Фамилия Имя",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_role",
              "localName": "Должность*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_phone",
              "localName": "Мобильный телефон*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "representative_facebook",
              "localName": "Профиль в Facebook*",
              "type": "hyperlink",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиции",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "investment_industry",
              "localName": "Направления",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "investment_geography",
              "title": "География стартапов",
              "localName": "География стартапов",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "investment_round",
              "localName": "Стадии инвестирования",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Данные о стартапах портфеля",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_activeDealsNumber",
              "localName": "Количество стартапов в портфеле",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_allDealsNumber",
              "localName": "Количество сделок, всего",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_exitDealsNumber",
              "localName": "Количество выходов",
              "type": "int",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "",
          "page": 1,
          "pageName": "",
          "withIndex": true,
          "isArray": "true",
          "fields": [
            {
              "sysName": "questionnairePilots[]_pilotid",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_site",
              "localName": "Ссылка на сайт стартапа",
              "type": "hyperlink",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиционные клубы",
          "page": 1,
          "pageName": "",
          "fields": [
            {
              "sysName": "questionnaire_club",
              "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false
            }
          ]
        },
        {
          "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
          "page": 1,
          "pageName": "",
          "withIndex": true,
          "isArray": "true",
          "fields": [
            {
              "sysName": "investorClubs[]_name",
              "localName": "Название клуба / сообщества*",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "investorClubs[]_role",
              "localName": "Ваша роль в клубе / сообществе*",
              "type": "string",
              "edited": false,
              "required": false
            }
          ]
        }
      ]
    }'
where formname = 'investor_Administrator';