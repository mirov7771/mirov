--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-4001

delete from public.screen where formname in ('startup_blur','corporate_blur','investor_blur');

INSERT INTO public.screen (clientid,"type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id) VALUES
                                                                                                                                                                     ('111260',0,'startup_blur',NULL,'{
                                                                                                                                                                       "form":
                                                                                                                                                                       [
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "project_note",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Краткое описание проекта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_problem",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Проблема, которую решает проект"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_auditory",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Целевая аудитория"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Перейти",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_site",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Сайт"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "questionnaire_birthYear",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Год основания"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "project_interactionType",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 8000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Модель продаж"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "search_dropdown",
                                                                                                                                                                               "sysName": "questionnaire_businessModel",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 24000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Бизнес-модели"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "project_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 3000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Индустрии проекта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_technology",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 13000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Технологии проекта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_inviteFio",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Контактное лицо"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_email",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Электронная почта"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Основная информация"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_mvpCode",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 27000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Стадия развития продукта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_sales",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 5000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Продажи"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "mask": "$",
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_turnover",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Оборот"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Смотреть",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_demoVideo",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Видео о продукте",
                                                                                                                                                                               "triggerField": "project_haveMVP",
                                                                                                                                                                               "triggerValue": "true"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Смотреть",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_businessPlan",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Презентация"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_geography",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Рынки, на которых работает стартап"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_expansion",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Рынки, на которые стартап планирует выйти в будущем"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "О проекте"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_competitor",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Прямые конкуренты"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_upSide",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Преимущества перед конкурентами"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Конкуренты"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_locationCountry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Страна, где находится команда"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_location",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Город, где находится команда"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_staff",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "direction": "row",
                                                                                                                                                                               "localName": "Количество сотрудников"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Команда"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "value": "20007",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "b2bPilots[]_state",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "heading",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "b2bPilots[]_reference",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "body",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "b2bPilots[]_suggestCase",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
                                                                                                                                                                           "isArray": "true",
                                                                                                                                                                           "pageName": "",
                                                                                                                                                                           "moduleNote": "",
                                                                                                                                                                           "moduleFormat": "card"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "mask": "$",
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_lastInvestment",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
                                                                                                                                                                               "triggerField": "investment_investment",
                                                                                                                                                                               "triggerValue": "true"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "investment_coInvestment",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Имя/ имена инвестора/ инвесторов",
                                                                                                                                                                               "triggerField": "investment_investment",
                                                                                                                                                                               "triggerValue": "true"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Инвестиции"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }','Просмотр анкеты стартапа в неавторизованной зоне',NULL,1,NULL,NULL,NULL,NULL,1),
                                                                                                                                                                     ('8385',1,'corporate_blur',NULL,'{
                                                                                                                                                                       "form":
                                                                                                                                                                       [
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "questionnaire_fullNote",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Описание"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 22000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Направление деятельности"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_innovationMethod",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 4000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Методы работы с инновациями"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Перейти",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "sysName": "questionnaire_site",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Сайт коорпорации"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_email",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Email"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Основная информация"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 3000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Индустрии"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_technology",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 13000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Технологии"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_stady",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 7000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Стадии развития продуктов"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Работа со стартапами"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnairePilots[]_pilotId",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnairePilots[]_suggestCase",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Описание потребности"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "",
                                                                                                                                                                           "isArray": "true"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_round",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 6000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Раунд инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_geography",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "География"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Инвестиции"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "successPilots[]_pilotid",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "body",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "successPilots[]_company",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Успешный кейсы"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "",
                                                                                                                                                                           "isArray": true,
                                                                                                                                                                           "moduleFormat": "card",
                                                                                                                                                                           "triggerField": "investment_investment",
                                                                                                                                                                           "triggerValue": "true"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }','Просмотр анкеты корпорации в неавторизованной зоне',NULL,1,NULL,NULL,NULL,NULL,1),
                                                                                                                                                                     ('111260',1,'corporate_blur',NULL,'{
                                                                                                                                                                       "form":
                                                                                                                                                                       [
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "questionnaire_fullNote",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Описание"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 22000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Направление деятельности"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_innovationMethod",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 4000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Методы работы с инновациями"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Перейти",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "sysName": "questionnaire_site",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Сайт коорпорации"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_email",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Email"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Основная информация"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 3000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Индустрии"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_technology",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 13000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Технологии"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_stady",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 7000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Стадии развития продуктов"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Работа со стартапами"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnairePilots[]_pilotId",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnairePilots[]_suggestCase",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Описание потребности"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "",
                                                                                                                                                                           "isArray": "true"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_round",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 6000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Раунд инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_geography",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "География"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Инвестиции"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "successPilots[]_pilotid",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "body",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "successPilots[]_company",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Успешный кейсы"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "",
                                                                                                                                                                           "isArray": true,
                                                                                                                                                                           "moduleFormat": "card",
                                                                                                                                                                           "triggerField": "investment_investment",
                                                                                                                                                                           "triggerValue": "true"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }','Просмотр анкеты корпорации в неавторизованной зоне',NULL,1,NULL,NULL,NULL,NULL,1),
                                                                                                                                                                     ('8385',0,'startup_blur',NULL,'{
                                                                                                                                                                       "form":
                                                                                                                                                                       [
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "project_note",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Краткое описание проекта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_problem",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Проблема, которую решает проект"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_auditory",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Целевая аудитория"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Перейти",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_site",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Сайт"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "questionnaire_birthYear",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Год основания"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "project_interactionType",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 8000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Модель продаж"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "search_dropdown",
                                                                                                                                                                               "sysName": "questionnaire_businessModel",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 24000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Бизнес-модели"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "project_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 3000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Индустрии проекта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_technology",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 13000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Технологии проекта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_inviteFio",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Контактное лицо"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_email",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Электронная почта"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Основная информация"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_mvpCode",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 27000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Стадия развития продукта"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_sales",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 5000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Продажи"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "mask": "$",
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_turnover",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Оборот"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Смотреть",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_demoVideo",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Видео о продукте",
                                                                                                                                                                               "triggerField": "project_haveMVP",
                                                                                                                                                                               "triggerValue": "true"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Смотреть",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_businessPlan",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Презентация"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_geography",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Рынки, на которых работает стартап"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_expansion",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Рынки, на которые стартап планирует выйти в будущем"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "О проекте"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_competitor",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Прямые конкуренты"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_upSide",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Преимущества перед конкурентами"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Конкуренты"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_locationCountry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Страна, где находится команда"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_location",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Город, где находится команда"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "project_staff",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "direction": "row",
                                                                                                                                                                               "localName": "Количество сотрудников"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Команда"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "value": "20007",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "b2bPilots[]_state",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "heading",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "b2bPilots[]_reference",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "body",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "b2bPilots[]_suggestCase",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
                                                                                                                                                                           "isArray": "true",
                                                                                                                                                                           "pageName": "",
                                                                                                                                                                           "moduleNote": "",
                                                                                                                                                                           "moduleFormat": "card"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "mask": "$",
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_lastInvestment",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
                                                                                                                                                                               "triggerField": "investment_investment",
                                                                                                                                                                               "triggerValue": "true"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "investment_coInvestment",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Имя/ имена инвестора/ инвесторов",
                                                                                                                                                                               "triggerField": "investment_investment",
                                                                                                                                                                               "triggerValue": "true"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Инвестиции"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }','Просмотр анкеты стартапа в неавторизованной зоне',NULL,1,NULL,NULL,NULL,NULL,1),
                                                                                                                                                                     ('111260',2,'investor_blur',NULL,'{
                                                                                                                                                                       "form":
                                                                                                                                                                       [
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_investorType",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 11000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Тип инвестора"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_note",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Краткое описание"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "questionnaire_fullnote",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Описание"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_portfolioNote",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Краткое описание портфельного стартапа",
                                                                                                                                                                               "maxLength": "300"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Перейти",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "sysName": "questionnaire_site",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Сайт"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_email",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Email"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Основная информация"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 3000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Индустрии инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_technology",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 13000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Технологии инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_geography",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "География стартапов"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_round",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 6000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Стадии инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "investment_note",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Особые условия инвестирования"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество стартапов, в которые инвестировал фонд",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11001"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество инвестиций в стартапы",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11002"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество стартапов, в которые инвестировал фонд",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11003"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество стартапов, в которые инвестировал фонд",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11004"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_exitDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество выходов"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Инвестиции"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnairePilots[]_pilotid",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "heading",
                                                                                                                                                                               "sysName": "questionnairePilots[]_company",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Название стартапа"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Портфель",
                                                                                                                                                                           "isArray": true,
                                                                                                                                                                           "moduleFormat": "card"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }','Просмотр анкеты инвестора в неавторизованной зоне',NULL,1,NULL,NULL,NULL,NULL,1),
                                                                                                                                                                     ('8385',2,'investor_blur',NULL,'{
                                                                                                                                                                       "form":
                                                                                                                                                                       [
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_investorType",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 11000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Тип инвестора"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "sysName": "questionnaire_note",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Краткое описание"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "questionnaire_fullnote",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Описание"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_portfolioNote",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Краткое описание портфельного стартапа",
                                                                                                                                                                               "maxLength": "300"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "hyperlink",
                                                                                                                                                                               "title": "Перейти",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "button",
                                                                                                                                                                               "sysName": "questionnaire_site",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Сайт"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": true,
                                                                                                                                                                               "sysName": "questionnaire_email",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Email"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Основная информация"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_industry",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 3000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Индустрии инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_technology",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 13000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Технологии инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_geography",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 2000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "География стартапов"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "array",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "text",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "investment_round",
                                                                                                                                                                               "activity":
                                                                                                                                                                               [
                                                                                                                                                                                 6000
                                                                                                                                                                               ],
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Стадии инвестиций"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "sysName": "investment_note",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Особые условия инвестирования"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество стартапов, в которые инвестировал фонд",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11001"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество инвестиций в стартапы",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11002"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество стартапов, в которые инвестировал фонд",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11003"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_allDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество стартапов, в которые инвестировал фонд",
                                                                                                                                                                               "triggerField": "questionnaire_investorType",
                                                                                                                                                                               "triggerValue": "11004"
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnaire_exitDealsNumber",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Количество выходов"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Инвестиции"
                                                                                                                                                                         },
                                                                                                                                                                         {
                                                                                                                                                                           "page": 1,
                                                                                                                                                                           "fields":
                                                                                                                                                                           [
                                                                                                                                                                             {
                                                                                                                                                                               "type": "int",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "hide",
                                                                                                                                                                               "isBlur": false,
                                                                                                                                                                               "sysName": "questionnairePilots[]_pilotid",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": ""
                                                                                                                                                                             },
                                                                                                                                                                             {
                                                                                                                                                                               "type": "string",
                                                                                                                                                                               "edited": false,
                                                                                                                                                                               "format": "heading",
                                                                                                                                                                               "sysName": "questionnairePilots[]_company",
                                                                                                                                                                               "required": false,
                                                                                                                                                                               "localName": "Название стартапа"
                                                                                                                                                                             }
                                                                                                                                                                           ],
                                                                                                                                                                           "module": "Портфель",
                                                                                                                                                                           "isArray": true,
                                                                                                                                                                           "moduleFormat": "card"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }','Просмотр анкеты инвестора в неавторизованной зоне',NULL,1,NULL,NULL,NULL,NULL,1);