--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4285
delete from screen_button where "name" = 'reply_SuperClient' and state = 20013;

insert into screen_button (name, state)
values ('reply_SuperClient', 20013);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20013 limit 1),
        (select button_id from public.buttons where code = 100000));