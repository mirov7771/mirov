--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4042
update public.buttons
set "text" = 'Полная анкета'
where code = 100000;

insert into public.screen_buttons_link (screen_id, button_id)
select screen_id , (select button_id from public.buttons b where code = 100000)
from public.screen_button sb
where "name" in ('round_Administrator', 'round_short_Administrator')
  and owner_check = false;