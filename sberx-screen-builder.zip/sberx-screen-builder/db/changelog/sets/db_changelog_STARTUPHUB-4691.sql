--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4691_sorting

delete from public.client_menu where menutype = 'topbar' and sysname = 'settings';

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", logofile, isdefault, ui, priority)

values (0, 'topbar', 'Настройки', 'settings', '', 'GET', '/file/icSettings.svg', null, null, null);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", logofile, isdefault, ui, priority)

values (1, 'topbar', 'Настройки', 'settings', '', 'GET', '/file/icSettings.svg', null, null, null);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", logofile, isdefault, ui, priority)

values (2, 'topbar', 'Настройки', 'settings', '', 'GET', '/file/icSettings.svg', null, null, null);

delete from public.client_menu where menutype = 'topbar' and sysname = 'exit';

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", logofile, isdefault, ui, priority)

values (0, 'topbar', 'Выйти', 'exit', '/logout', 'DELETE', '/file/768847', null, null, null);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", logofile, isdefault, ui, priority)

values (1, 'topbar', 'Выйти', 'exit', '/logout', 'DELETE', '/file/768847', null, null, null);

insert into public.client_menu ("type", menutype, name, sysname, "action", "method", logofile, isdefault, ui, priority)

values (2, 'topbar', 'Выйти', 'exit', '/logout', 'DELETE', '/file/768847', null, null, null);
