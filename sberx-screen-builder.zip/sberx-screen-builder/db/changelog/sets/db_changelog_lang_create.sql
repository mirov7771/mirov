--liquibase formatted sql
--changeset Fedorov EO:task_1
drop table if exists lang;
create table lang(
                     id bigserial primary key,
                     locale varchar
);