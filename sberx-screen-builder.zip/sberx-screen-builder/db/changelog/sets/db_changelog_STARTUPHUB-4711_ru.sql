--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4711_ru
update public.screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Полное юридическое название",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Укажите ваш ИНН или иной регистрационный номер",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Идентификационный номер компании",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Укажите год регистрации юрлица",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "Например, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну юрисдикции",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна регистрации юрлица",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Адрес сайта",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Иванов Иван Иванович",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Контактное лицо"
                },
                {
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Укажите почту для связи",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Электронная почта"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Номер телефона"
                }
            ],
            "module": "Организация",
            "pageName": "Юридическая информация",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Ресурс",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity": [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Адрес ссылки",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Дополнительные ссылки",
            "isArray": "true",
            "pageName": "Юридическая информация",
            "actionText": "Добавить ссылку",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах"
        },
        {
            "page": 2,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите ваш стартап одним предложением",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Краткое описание стартапа",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Модели продаж",
                    "edited": true,
                    "format": "chip",
                    "values": [],
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "Укажите модели взаимодействия с клиентами в вашем бизнесе",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values": [],
                    "example": "Укажите бизнес-модель стартапа",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": true,
                    "localName": "Бизнес-модель",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Выберите стадию развития",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": true,
                    "localName": "Стадия развития стартапа",
                    "multySelect": false
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип стартапа",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes": [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Ссылка на видео",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о стартапе",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Где базируется ваш стартап?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну",
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна",
                    "description": "Укажите, где фактически находится штаб-квартира вашего стартапа",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Введите город",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "Город",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "О стартапе",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите индустрии",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Индустрии и технологические вертикали, в которых функционирует ваш стартап",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите технологии",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                }
            ],
            "module": "Направления",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "Проблема, которую решает ваш продукт",
                    "maxLength": "300"
                },
                {
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите вашу целевую аудиторию",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Целевая аудитория",
                    "maxLength": "300"
                },
                {
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "type": "hyperlink",
                    "title": "Презентация",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes": [
                        ".pdf"
                    ]
                },
                {
                    "note": "Регионы, на которых уже представлен ваш продукт",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Рынки, на которых вы работаете",
                    "multySelect": true,
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Регионы, на которые вы планируете выйти в ближайший год",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые планируете выходить",
                    "multySelect": true
                },
                {
                    "note": "Укажите стадию продаж вашего продукта",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите тип продаж",
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": true,
                    "localName": "Продажи",
                    "multySelect": true,
                    "valueGroups": [
                        {
                            "1": "5001"
                        },
                        {
                            "2": "5002,5003,5004"
                        }
                    ]
                },
                {
                    "mask": "$",
                    "note": "Валовый оборот компании за последний год в $",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Оборот в год",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число",
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите название компаний-конкурентов",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Прямые конкуренты",
                    "maxLength": "300"
                },
                {
                    "note": "Перечислите предметно, чем вы лучше конкурентов",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите преимущества вашего продукта",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Преимущества перед конкурентами",
                    "maxLength": "300"
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Укажите число сотрудников в штате",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Количество сотрудников"
                }
            ],
            "module": "О продукте",
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 3,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Название сервиса/компании",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Укажите название сервиса"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите кратко, в каком аспекте ваш продукт является аналогом указанных сервисов"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите предметно, чем ваш продукт лучше замещаемого сервиса"
                }
            ]
        },
        {
            "page": 3,
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Название должности",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Опишите опыт сотрудника",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Краткое описание опыта",
                    "maxLength": "150"
                }
            ],
            "module": "Ключевые сотрудники",
            "isArray": "true",
            "pageName": "Команда",
            "actionText": "Добавить должность"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Успешные пилоты",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите, с какой корпорацией у вас был успешный кейс",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите про кейс и его результаты",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "actionText": "Добавить кейс",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "title": "Предлагаемый кейс",
                    "edited": true,
                    "example": "Если у вас есть идеи, как можно пилотировать ваш продукт, опишите их в нескольких предложениях",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Есть ли у вас опыт взаимодействия с экосистемой Сбера?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "Экосистема Сбера",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Находитесь ли вы в активном поиске инвестиций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число"
                },
                {
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Список инвесторов",
                    "maxLength": "300"
                },
                {
                    "sysName": "userConsent_mailingConsent",
                    "localName": "Я <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">соглашаюсь</a> на обработку персональных данных для цели проведения аналитических, статистических, маркетинговых исследований и формирования на их основе персональных предложений",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": false
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": ""
        }
    ]
}'
where formname = 'New_StartUp'
  and lang_id = 1;


update public.screen
set formview = '{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "type": "date",
          "edited": false,
          "sysName": "session_date",
          "required": false,
          "localName": "Время посещения"
        },
        {
          "type": "date",
          "edited": false,
          "sysName": "Questionnaire_Modified",
          "required": false,
          "localName": "Время обновления"
        },
        {
          "type": "date",
          "edited": false,
          "sysName": "Questionnaire_Modified",
          "required": false,
          "localName": "Время обновления"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Наименование организации"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_inn",
          "required": false,
          "localName": "ИНН организации"
        },
        {
          "type": "int",
          "edited": false,
          "sysName": "questionnaire_birthYear",
          "required": false,
          "localName": "Год регистрации",
          "maxLength": 4
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_name",
          "required": false,
          "localName": "Публичное название / название бренда"
        },
        {
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "sysName": "questionnaire_site",
          "required": false,
          "localName": "Сайт"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_transcription",
          "required": false,
          "localName": "Транскрипция"
        },
        {
          "type": "text",
          "edited": false,
          "format": "search_dropdown",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Страна юрисдикции"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_inviteFio",
          "required": false,
          "localName": "Контактное лицо"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_email",
          "required": false,
          "localName": "Электронная почта"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_phoneNumber",
          "required": false,
          "localName": "Номер телефона"
        }
      ],
      "module": "Организация",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "title": "Ресурс",
          "edited": false,
          "format": "chip",
          "sysName": "contacts[]_type",
          "activity": [
            21000
          ],
          "required": false,
          "localName": ""
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "contacts[]_name",
          "required": false,
          "localName": "Ссылка"
        }
      ],
      "module": "Дополнительные контакты",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "chip",
          "sysName": "project_interactionType",
          "activity": [
            8000
          ],
          "required": false,
          "localName": "Бизнес-модели взаимодействия с пользователями"
        },
        {
          "type": "array",
          "edited": false,
          "format": "chip",
          "sysName": "questionnaire_businessModel",
          "activity": [
            24000
          ],
          "required": false,
          "localName": "Бизнес-модели"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_locationCountry",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Страна"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_location",
          "required": false,
          "localName": "Город"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": false,
          "localName": "Индустрии"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": false,
          "localName": "Технологии"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_note",
          "required": false,
          "localName": "Краткое описание проекта"
        },
        {
          "type": "logo",
          "edited": false,
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип"
        }
      ],
      "module": "О проекте",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_mvpCode",
          "activity": [
            27000
          ],
          "required": false,
          "localName": "Стадия развития продукта"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_demoSite",
          "required": false,
          "localName": "URL ссылка на демо"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "project_demoVideo",
          "required": false,
          "localName": "Видео о продукте"
        }
      ],
      "module": "Прототип",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "note": "Опишите в 1–2 предложениях",
          "type": "string",
          "edited": false,
          "sysName": "project_problem",
          "required": false,
          "localName": "Проблема, которую решает проект"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_auditory",
          "required": false,
          "localName": "Целевая аудитория"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "investment_businessPlan",
          "required": false,
          "localName": "Загрузить презентацию"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "project_pitchVideo",
          "required": false,
          "localName": "Видео питча"
        }
      ],
      "module": "О проекте",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Рынки, на которых вы работаете"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_expansion",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_sales",
          "activity": [
            5000
          ],
          "required": false,
          "localName": "Продажи"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "investment_turnover",
          "required": false,
          "localName": "Оборот в год (в USD)"
        }
      ],
      "module": "Рынок",
      "moduleNote": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "string",
          "edited": false,
          "sysName": "project_competitor",
          "required": false,
          "localName": "Прямые конкуренты"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_indirectCompetitor",
          "required": false,
          "localName": "Косвенные конкуренты"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_upSide",
          "required": false,
          "localName": "Преимущества перед конкурентами"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_downSide",
          "required": false,
          "localName": "Недостатки перед конкурентами"
        }
      ],
      "module": "Конкуренты",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "int",
          "edited": false,
          "sysName": "project_staff",
          "required": false,
          "localName": "Общее количество сотрудников"
        }
      ],
      "module": "Команда",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Роль сотрудника в команде"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "workers[]_note",
          "required": false,
          "localName": "Краткое описание опыта"
        }
      ],
      "module": "",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_successPilots",
          "required": false,
          "localName": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?"
        }
      ],
      "module": "Успешные пилоты",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2bPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2bPilots[]_reference",
          "required": false,
          "localName": "С кем был успешный кейс"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2bPilots[]_suggestCase",
          "required": false,
          "localName": "Описание и результаты кейса"
        }
      ],
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2cPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2cPilots[]_reference",
          "required": false,
          "localName": "С кем был успешный кейс"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2cPilots[]_suggestCase",
          "required": false,
          "localName": "Описание и результаты кейса"
        }
      ],
      "module": "Успешные B2C-, C2C- кейсы",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_pilot",
          "required": false,
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "ecoPilot_suggestCase",
          "required": false,
          "localName": "Предлагаемый кейс"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "ecoPilot_experience",
          "required": false,
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "ecoPilot_businessUnit",
          "required": false,
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?"
        }
      ],
      "module": "Экосистема Сбера",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "investment_investment",
          "required": false,
          "localName": "Находитесь ли вы в активном поиске инвестиций?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "investment_lastInvestment",
          "required": false,
          "localName": "Объем ранее привлеченных инвестиций, всего"
        },
        {
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "edited": false,
          "sysName": "investment_coInvestment",
          "required": false,
          "localName": "Имя/ имена инвестора/ инвесторов"
        }
      ],
      "module": "Инвестиции",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_acceleratorCode",
          "activity": [
            26000
          ],
          "required": false,
          "localName": "Является выпускником:"
        }
      ],
      "module": "Акселераторы Сбера",
      "pageName": ""
    },
        {
            "page": 1,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "rows": "3",
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500"
                }
            ]
        },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_sber500",
          "required": false,
          "localName": "Хочет ли стартап подать заявку на участие в Sber500?",
          "information": "Sber500 - уникальный акелератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "sberFiveHundred_firsttime",
          "required": false,
          "localName": "Подавался ли стартап ранее в Sber500?"
        },
        {
          "type": "array",
          "edited": false,
          "format": "search_dropdown",
          "example": "Укажите потребность",
          "sysName": "sberFiveHundred_ecorequirement",
          "activity": [
            38000
          ],
          "required": false,
          "localName": "Какую потребность Экосистемы Сбера закрывает стартап?",
          "multySelect": true
        },
        {
          "type": "string",
          "edited": false,
          "regExp": "(^([0-9]{1,7}))",
          "sysName": "sberFiveHundred_monthrevenue",
          "required": false,
          "localName": "Выручка за последний месяц",
          "maxLength": "300",
          "showLength": false,
          "regExpError": "Необходимо указать число"
        },
        {
          "type": "string",
          "edited": false,
          "regExp": "(^([0-9]{1,7}))",
          "sysName": "sberFiveHundred_quarterrevenue",
          "required": false,
          "localName": "Выручка за последние 3 месяца",
          "maxLength": "300",
          "showLength": false,
          "regExpError": "Необходимо указать число"
        },
        {
          "type": "int",
          "edited": false,
          "format": "[1;1000]",
          "example": "Укажите количество клиентов",
          "sysName": "sberFiveHundred_clients",
          "maxValue": 1000,
          "minValue": 1,
          "required": false,
          "localName": "Количество активных или платящих клиентов за последний месяц"
        }
      ],
      "module": "Акселератор Sber500",
      "pageName": "Sber500"
    }
  ]
}'
where formname = 'startup_Administrator'
  and lang_id = 1;




update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_type",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":""
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      },
        {
            "page": 1,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "rows": "3",
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500"
                }
            ]
        }
   ]
}'
where formname = 'startup_SuperClient'
  and lang_id = 1;


update screen
set formview = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Название"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год основания"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": false,
                    "localName": "Тип взаимодействия с пользователем"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": false,
                    "localName": "Бизнес-модели"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрия проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_auditory",
                    "required": false,
                    "localName": "Целевая аудитория"
                }
            ],
            "module": "Основная информация"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "hyperlink",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "contacts[]_name",
                    "required": false,
                    "localName": "Ссылка"
                }
            ],
            "module": "Дополнительные контакты (Доступно по подписке)",
            "isArray": "true",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": false,
                    "localName": "Стадия развития продукта"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о продукте",
                    "triggerField": "project_haveMVP",
                    "triggerValue": "true"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_businessPlan",
                    "required": false,
                    "localName": "Презентация (Доступно по подписке)"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которых работает стартап"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые собираетесь выходить в ближайшее время"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": false,
                    "localName": "Продажи"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_turnover",
                    "required": false,
                    "localName": "Оборот"
                }
            ],
            "module": "О проекте (Доступно по подписке)"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_competitor",
                    "required": false,
                    "localName": "Прямые конкуренты"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_upSide",
                    "required": false,
                    "localName": "Преимущества перед конкурентами"
                }
            ],
            "module": "Конкуренты (Доступно по подписке)"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Страна, где находится команда"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "questionnaire_location",
                    "required": false,
                    "localName": "Город, где находится команда"
                },
                {
                    "type": "int",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_staff",
                    "required": false,
                    "localName": "Общее количество сотрудников"
                }
            ],
            "module": "Команда (Доступно по подписке)"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "worker_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "hide",
                    "sysName": "worker_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "worker_role",
                    "required": false,
                    "direction": "concatenation",
                    "localName": "Ключевые члены команды"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Опыт",
                    "maxLength": "150"
                }
            ],
            "module": "",
            "isArray": "true"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": false,
                    "format": "hide",
                    "isBlur": false,
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса"
                }
            ],
            "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы (Доступно по подписке)",
            "isArray": "true",
            "pageName": "",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "isBlur": false,
                    "sysName": "investment_investment",
                    "required": false,
                    "localName": "Проект привлекает инвестиции"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "isBlur": false,
                    "sysName": "investment_planInvestment",
                    "required": false,
                    "localName": "Проект планирует привлекать инвестиции в ближайшие 6 месяцев",
                    "triggerField": "investment_investment",
                    "triggerValue": "false"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Объем ранее привлеченных инвестиций, всего",
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Имя/ имена инвестора/ инвесторов",
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                }
            ],
            "module": "Инвестиции (Доступно по подписке)"
        },
        {
            "page": 1,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "rows": "3",
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500"
                }
            ]
        }
    ]
}'
where formname = 'startup_Client'
  and lang_id = 1;


update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
             {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }

         ],
         "module":"Основная информация"
      },
        {
            "page": 1,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "rows": "3",
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500"
                }
            ]
        }
   ]
}'
where formname = 'startup_SuperStartup'
  and lang_id = 1;


update screen
set formedit = '{
    "form":
    [
        {
            "page": 1,
            "fields":
            [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Полное юридическое название",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Укажите ваш ИНН или иной регистрационный номер",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Идентификационный номер компании",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Укажите год регистрации юрлица",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "Например, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну юрисдикции",
                    "sysName": "questionnaire_registrationCountry",
                    "activity":
                    [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна регистрации юрлица",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Адрес сайта",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Иванов Иван Иванович",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Контактное лицо"
                },
                {
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Укажите почту для связи",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Электронная почта"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Номер телефона"
                }
            ],
            "module": "Организация",
            "pageName": "Юридическая информация",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields":
            [
                {
                    "type": "array",
                    "title": "Ресурс",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity":
                    [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Адрес ссылки",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Дополнительные ссылки",
            "isArray": "true",
            "pageName": "Юридическая информация",
            "actionText": "Добавить ссылку",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах"
        },
        {
            "page": 2,
            "fields":
            [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите ваш стартап одним предложением",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Краткое описание стартапа",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Модели продаж",
                    "edited": true,
                    "format": "chip",
                    "values":
                    [],
                    "sysName": "project_interactionType",
                    "activity":
                    [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "Укажите модели взаимодействия с клиентами в вашем бизнесе",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values":
                    [],
                    "example": "Укажите бизнес-модель стартапа",
                    "sysName": "questionnaire_businessModel",
                    "activity":
                    [
                        24000
                    ],
                    "required": true,
                    "localName": "Бизнес-модель",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Выберите стадию развития",
                    "sysName": "project_mvpCode",
                    "activity":
                    [
                        27000
                    ],
                    "required": true,
                    "localName": "Стадия развития стартапа",
                    "multySelect": false
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип стартапа",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes":
                    [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Ссылка на видео",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о стартапе",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Где базируется ваш стартап?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну",
                    "sysName": "questionnaire_locationCountry",
                    "activity":
                    [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна",
                    "description": "Укажите, где фактически находится штаб-квартира вашего стартапа",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Введите город",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "Город",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "О стартапе",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields":
            [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите индустрии",
                    "sysName": "project_industry",
                    "activity":
                    [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Индустрии и технологические вертикали, в которых функционирует ваш стартап",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите технологии",
                    "sysName": "project_technology",
                    "activity":
                    [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                }
            ],
            "module": "Направления",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields":
            [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "Проблема, которую решает ваш продукт",
                    "maxLength": "300"
                },
                {
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите вашу целевую аудиторию",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Целевая аудитория",
                    "maxLength": "300"
                },
                {
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "type": "hyperlink",
                    "title": "Презентация",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes":
                    [
                        ".pdf"
                    ]
                },
                {
                    "note": "Регионы, на которых уже представлен ваш продукт",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_geography",
                    "activity":
                    [
                        2000
                    ],
                    "required": true,
                    "localName": "Рынки, на которых вы работаете",
                    "multySelect": true,
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Регионы, на которые вы планируете выйти в ближайший год",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_expansion",
                    "activity":
                    [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые планируете выходить",
                    "multySelect": true
                },
                {
                    "note": "Укажите стадию продаж вашего продукта",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите тип продаж",
                    "sysName": "project_sales",
                    "activity":
                    [
                        5000
                    ],
                    "required": true,
                    "localName": "Продажи",
                    "multySelect": true,
                    "valueGroups": [
                        {
                            "1": "5001"
                        },
                        {
                            "2": "5002,5003,5004"
                        }
                    ]
                },
                {
                    "mask": "$",
                    "note": "Валовый оборот компании за последний год в $",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Оборот в год",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число",
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите название компаний-конкурентов",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Прямые конкуренты",
                    "maxLength": "300"
                },
                {
                    "note": "Перечислите предметно, чем вы лучше конкурентов",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите преимущества вашего продукта",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Преимущества перед конкурентами",
                    "maxLength": "300"
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Укажите число сотрудников в штате",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Количество сотрудников"
                }
            ],
            "module": "О продукте",
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 3,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Название сервиса/компании",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Укажите название сервиса"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите кратко, в каком аспекте ваш продукт является аналогом указанных сервисов"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите предметно, чем ваш продукт лучше замещаемого сервиса"
                }
            ]
        },
        {
            "page": 3,
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "fields":
            [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Название должности",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Опишите опыт сотрудника",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Краткое описание опыта",
                    "maxLength": "150"
                }
            ],
            "module": "Ключевые сотрудники",
            "isArray": "true",
            "pageName": "Команда",
            "actionText": "Добавить должность"
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "boolean",
                    "title": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Успешные пилоты",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите, с какой корпорацией у вас был успешный кейс",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите про кейс и его результаты",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "actionText": "Добавить кейс",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "boolean",
                    "title": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "title": "Предлагаемый кейс",
                    "edited": true,
                    "example": "Если у вас есть идеи, как можно пилотировать ваш продукт, опишите их в нескольких предложениях",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Есть ли у вас опыт взаимодействия с экосистемой Сбера?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "Экосистема Сбера",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)"
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "boolean",
                    "title": "Находитесь ли вы в активном поиске инвестиций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число"
                },
                {
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Список инвесторов",
                    "maxLength": "300"
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": ""
        }
    ]
}'
where formname = 'startup_edit'
  and lang_id = 1;

delete from screen where formname = 'import_create' and lang_id = 1;

insert into screen(formname, type, lang_id, formedit, name, description, pages)
values ('import_create', 0, 1, '{
    "form": [{
            "page": 1,
            "module": "Добавьте информацию в анкету об импортозамещении",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 3,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Название сервиса/компании",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Укажите название сервиса"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите кратко, в каком аспекте ваш продукт является аналогом указанных сервисов"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите предметно, чем ваш продукт лучше замещаемого сервиса"
                }
            ]
        }]
}', 'Добавьте информацию в анкету об импортозамещении', 'Предложите свой продукт в качестве аналога зарубежным. Корпорации увидят ваш стартап в специальном разделе «Импортозамещение».', 1);