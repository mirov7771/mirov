--liquibase formatted sql
--changeset Mirov AA:schemas_update
update schemas
set value = '{
    "value": {
    "clickable": true,
    "columns": [
        {
            "sysName": "startup",
            "type": "img",
            "title": "Стартап",
            "key": "questionnaireLogo",
            "refs": {
                "labelKey": "questionnaireName"
            }
        },
        {
            "sysName": "phone",
            "type": "string",
            "title": "Телефон",
            "key": "phone"
        },
        {
            "sysName": "email",
            "type": "link",
            "title": "Электронная почта",
            "key": "email",
            "refs": {
                "hrefKey": "eMail",
                "format": "email"
            }
        },
        {
            "sysName": "view_date",
            "type": "date",
            "title": "Дата и время просмотра",
            "key": "date"
        }
    ]
    }
}'
where name = 'reply_search'