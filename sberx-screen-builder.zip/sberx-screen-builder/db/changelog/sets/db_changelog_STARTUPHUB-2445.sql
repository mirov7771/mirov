--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2445
UPDATE screen
SET formedit='{
  "form": [
    {
      "module": "Личная информация",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "representative_firstName",
          "localName": "Имя",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 200,
          "showLength": false
        },
        {
          "sysName": "representative_lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 250,
          "showLength": false
        },
        {
          "sysName": "representative_phone",
          "localName": "Номер телефона",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_position",
          "localName": "Должность",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 250,
          "showLength": false
        }
      ]
    },
    {
      "module": "Информация о компании",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Название",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 200,
          "showLength": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 200,
          "showLength": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Корпоративный email",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "note": "В случае использования личного email может потребоваться подтверждение у администратора платформыи",
          "description": "В случае использования личного email может потребоваться подтверждение у администратора платформы",
          "required": true
        },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}'
WHERE "type"=1 and formname='New_Corporate_Short';

UPDATE screen
SET formedit='{
  "form": [
    {
      "module": "Тип инвестора",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Личная информация",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "representative_firstName",
          "localName": "Имя",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 200,
          "showLength": false
        },
        {
          "sysName": "representative_lastName",
          "localName": "Фамилия",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 250,
          "showLength": false
        },
        {
          "sysName": "representative_phone",
          "localName": "Номер телефона",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_position",
          "localName": "Должность",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 250,
          "showLength": false
        }
      ]
    },
    {
      "module": "Информация о компании",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Название",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 200,
          "showLength": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Адрес сайта",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 200,
          "showLength": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Корпоративный email",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "note": "В случае использования личного email может потребоваться подтверждение у администратора платформыи",
          "description": "В случае использования личного email может потребоваться подтверждение у администратора платформы",
          "required": true
        },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}'
WHERE  "type"=1 and formname='New_Investor_Short';
