--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5081
UPDATE public.pages SET  page='{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "startups_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id": 1
        },
        {
          "name": "Импортозамещение",
          "id": 2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "startups_ru_pageTitle",
      "title": "Импортозамещающие решения",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "startups_ru_participantSearch",
      "visible": true,
      "position": 3,
      "isImport": true,
      "placeholder": "Поиск сервисов-аналогов",
      "participant": "startup",
      "shownFromTitle": "Всего %import_size_main% ",
      "helperText": "Введите название сервиса, аналог которого хотите найти, или название стартапа",
      "foundsTitle": "Найдено: {0}",
      "filterBar": {
        "title": "Фильтры",
        "acceptButtonText": "Применить фильтры",
        "resetButtonText": "Сбросить фильтры",
        "acceptButtonShortText": "Применить",
        "resetButtonShortText": "Сбросить",
        "placeholder": "поиск"
      },
      "popupFooter": {
        "title": "Зарегистрируйтесь, чтобы получить доступ к полной анкете",
        "caption": "После регистрации будут доступны: полное описание компании, информация о продукте, направления, ключевые сотрудники, успешные пилоты, инвестиции и трекшн стартапа.",
        "mainButtonText": "Зарегистрироваться",
        "secondButtonText": "Войти"
      },
      "features": [
        {
          "type": "authBanner",
          "sysName": "authBanner",
          "visible": true,
          "position": 1,
          "typeBanner": "participantSearch",
          "title": "Зарегистрируйтесь и получите доступ к %import_size% по импортозамещению",
          "mainButtonText": "Зарегистрироваться",
          "secondButtonText": "Войти",
          "placement": "bottom",
          "config": {
            "nowrap": true
          }
        },
        {
          "caption": "Расскажите корпорациям, какие сервисы заменяет ваш продукт",
          "buttonText": "Рассказать о продукте",
          "position": 1,
          "sysName": "importSubstitutionBanner",
          "title": "Будьте в тренде импортозамещения",
          "type": "importSubstitutionBanner",
          "isClosed": false,
          "redirectTo": "/participant-registration",
          "visible": true, "bannerUrl": "/file/p3.png",
          "placement": "middle",
          "config": {
            "nowrap": true,
            "styles": {
              "padding":{
                "xs":{
                  "top":32,
                  "bottom":0
                },
                "s":{
                  "top":32,
                  "bottom":0
                },
                "md":{
                  "top":48,
                  "bottom":0
                },
                "lg":{
                  "top":48,
                  "bottom":0
                }
              }
            }
          }
        }
      ]
    }
  ]
}'::json::json  WHERE code='import_unauth_ru' and lang_id=1;

delete from page_values_cache where name = '%import_size_main%';
insert into page_values_cache
values ('%import_size_main%', 0, 50, null, 'GET', '/list/questionnaire?type=0&isImport=true');
