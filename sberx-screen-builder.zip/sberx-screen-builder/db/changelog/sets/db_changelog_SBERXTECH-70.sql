--liquibase formatted sql
--changeset Timofeev V:SBERXTECH-70 Правки в анкету корпорации, проставил required = true по полям, скрытым за triggerField

update screen set
    formedit =
        '{
      "form": [
        {
          "module": "Условия соглашения",
          "page": 1,
          "pageName": "Юридическая информация об организации",
          "fields": [
            {
              "sysName": "userConsent_consent",
              "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
              "type": "boolean",
              "format": "checkbox",
              "edited": true,
              "required": true
            },
            {
              "sysName": "userConsent_contract",
              "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
              "type": "boolean",
              "format": "checkbox",
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Юридическая информация об организации",
          "page": 1,
          "pageName": "Юридическая информация об организации",
          "moduleNote": "Информация об организации автоматически перенесена из СберБизнес Онлайн. Пожалуйста, заполните недостающие данные.",
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Наименование организации",
              "type": "string",
              "edited": true,
              "required": false,
              "direction": "row",
              "maxLength": 70,
              "showLength": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год регистрации*",
              "type": "int",
              "format": "[1991;2021]",
              "maxLength": 4,
              "edited": true,
              "required": true,
              "direction": "row",
              "showLength": false
            },
            {
              "sysName": "questionnaire_name",
              "localName": "Публичное название / название бренда",
              "type": "string",
              "maxLength": 100,
              "edited": true,
              "required": true,
              "showLength": false
            },
            {
              "sysName": "questionnaire_registrationCountry",
              "localName": "Страна юрисдикции*",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": true,
              "required": true,
              "multySelect": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "format": "e-mail",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт корпорации",
              "type": "string",
              "maxLength": "100",
              "edited": true,
              "required": true,
              "showLength": false
            }
          ]
        },
        {
          "module": "Представитель",
          "page": 2,
          "pageName": "Информация о представителе",
          "moduleNote": "",
          "fields": [
            {
              "sysName": "representative_fio",
              "localName": "Фамилия Имя представителя*",
              "type": "string",
              "edited": true,
              "required": true
            },
            {
              "sysName": "representative_role",
              "localName": "Должность*",
              "type": "string",
              "edited": true,
              "required": true
            },
            {
              "sysName": "representative_phone",
              "localName": "Мобильный телефон*",
              "type": "string",
              "format": "phone",
              "edited": true,
              "required": true,
              "mask": "phone"
            },
            {
              "sysName": "representative_email",
              "localName": "Электронная почта*",
              "type": "string",
              "format": "e-mail",
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Корпорация",
          "page": 3,
          "pageName": "Информация о корпорации",
          "fields": [
            {
              "title": "Направления",
              "sysName": "questionnaire_industry",
              "localName": "Направление деятельности",
              "note": "Выберите направления работы Вашей корпорации",
              "description": "Выберите направления работы Вашей корпорации",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                22000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_innovationMethod",
              "title": "Методы работы с инновациями",
              "localName": "Укажите методы",
              "note": "Выберите методы внедрения инноваций в Вашей корпорации ",
              "description": "Выберите методы внедрения инноваций в Вашей корпорации",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                4000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "title": "Годовой оборот",
              "sysName": "questionnaire_turnover",
              "localName": "Годовой оборот",
              "note": "Опционально",
              "type": "array",
              "format": "search_dropdown",
              "edited": true,
              "required": true,
              "values": [
                {
                  "name": "Микропредприятия — до 120 млн",
                  "code": "Микропредприятия — до 120 млн"
                },
                {
                  "name": "Малые предприятия — до 800 млн",
                  "code": "Малые предприятия — до 800 млн"
                },
                {
                  "name": "Средние предприятия — до 2 млрд рублей",
                  "code": "Средние предприятия — до 2 млрд рублей"
                },
                {
                  "name": "Крупный бизнес — до 30 млрд рублей",
                  "code": "Крупный бизнес — до 30 млрд рублей"
                },
                {
                  "name": "Крупнейший бизнес — свыше 30 млрд рублей",
                  "code": "Крупнейший бизнес — свыше 30 млрд рублей"
                }
              ]
            },
            {
              "sysName": "questionnaire_note",
              "localName": "Описание",
              "note": "Опишите корпорацию в нескольких предложениях",
              "type": "string",
              "maxLength": "480",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "title": "Логотип",
              "type": "logo",
              "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
              "edited": true,
              "required": false,
              "allowedTypes": [
                ".png"
              ]
            }
          ]
        },
        {
          "module": "Работа со стартапами",
          "page": 4,
          "pageName": "Условия работы со стартапами",
          "fields": [
            {
              "sysName": "project_industry",
              "title": "Направления",
              "description": "Выберите направления, по которым Вы ищете стартапы",
              "localName": "Направления",
              "note": "Выберите направления, по которым Вы ищете стартапы",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                3000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_stady",
              "title": "Стадии развития стартапов",
              "description": "Выберите интересующие стадии развития стартапов",
              "localName": "Стадия развития",
              "note": "Выберите интересующие стадии развития стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                7000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "",
          "page": 4,
          "pageName": "Условия работы со стартапами",
          "title": "Потребности корпорации",
          "subTitle": "Потребность №",
          "withIndex": true,
          "actionText": "Добавить потребность",
          "isArray": "true",
          "fields": [
            {
              "sysName": "questionnairePilots[]_pilotId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_suggestCase",
              "localName": "Описание потребности",
              "note": "Кратко опишите суть Вашего запроса на пилотирование стартапа",
              "type": "string",
              "maxLength": "520",
              "edited": true,
              "required": false
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 5,
          "pageName": "Пилотирование",
          "fields": [
            {
              "sysName": "questionnaire_successPilots",
              "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_startupInvestmentYears",
              "title": "Информация о сотрудничестве со стартапами",
              "localName": "Сколько лет Ваша корпорация работает со стартапами",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_overallPilots",
              "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_lastYearInvestmentsCount",
              "localName": "Количество пилотов со стартапами за последний год",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_overallContracts",
              "localName": "Количество контрактов (внедрений) со стартапами за последний год",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиции",
          "page": 6,
          "pageName": "Инвестиции",
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Инвестирует ли Ваша корпорация в стартапы?",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            },
            {
              "sysName": "investment_industry",
              "title": "Направления",
              "description": "Выберите интересные для Вас направления инвестирования",
              "localName": "Направления",
              "note": "Выберите интересные для Вас направления инвестирования",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                3000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд инвестиций",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "project_geography",
              "localName": "География стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                2000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 6,
          "pageName": "Инвестиции",
          "triggerField": "investment_investment",
          "triggerValue": true,
          "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
          "isArray": true,
          "subTitle": "Стартап №",
          "withIndex": true,
          "actionText": "Добавить кейс",
          "fields": [
            {
              "sysName": "successPilots[]_pilotid",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "successPilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "maxLength": "140",
              "edited": true,
              "required": false,
              "showLength": false
            },
            {
              "sysName": "successPilots[]_suggestCase",
              "localName": "Описание кейса",
              "type": "string",
              "maxLength": "300",
              "edited": true,
              "required": false,
              "showLength": false
            }
          ]
        },
        {
          "module": "Скаутинг",
          "page": 7,
          "pageName": "Скаутинг",
          "moduleNote": "Подбор технологических решений стартапов под запрос заказчика",
          "fields": [
            {
              "sysName": "questionnaire_scouting",
              "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            }
          ]
        }
      ]
    }'
where "type" = 1 and formname = 'New_Corporate';

update screen set
    formedit =
        '{
          "form": [
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация об организации",
              "moduleNote": "Информация об организации автоматически перенесена из СберБизнес Онлайн. Пожалуйста, заполните недостающие данные.",
              "fields": [
                {
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации*",
                  "type": "int",
                  "format": "[1991;2021]",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": true,
                  "required": true,
                  "multySelect": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт корпорации",
                  "type": "string",
                  "maxLength": "100",
                  "edited": true,
                  "required": true,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Представитель",
              "page": 2,
              "pageName": "Информация о представителе",
              "moduleNote": "",
              "fields": [
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя представителя*",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_email",
                  "localName": "Электронная почта*",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Корпорация",
              "page": 3,
              "pageName": "Информация о корпорации",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "questionnaire_industry",
                  "localName": "Направление деятельности",
                  "note": "Выберите направления работы Вашей корпорации",
                  "description": "Выберите направления работы Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    22000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_innovationMethod",
                  "title": "Методы работы с инновациями",
                  "localName": "Укажите методы",
                  "note": "Выберите методы внедрения инноваций в Вашей корпорации ",
                  "description": "Выберите методы внедрения инноваций в Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    4000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "title": "Годовой оборот",
                  "sysName": "questionnaire_turnover",
                  "localName": "Годовой оборот",
                  "note": "Опционально",
                  "type": "array",
                  "format": "search_dropdown",
                  "edited": true,
                  "required": true,
                  "values": [
                    {
                      "name": "Микропредприятия — до 120 млн",
                      "code": "Микропредприятия — до 120 млн"
                    },
                    {
                      "name": "Малые предприятия — до 800 млн",
                      "code": "Малые предприятия — до 800 млн"
                    },
                    {
                      "name": "Средние предприятия — до 2 млрд рублей",
                      "code": "Средние предприятия — до 2 млрд рублей"
                    },
                    {
                      "name": "Крупный бизнес — до 30 млрд рублей",
                      "code": "Крупный бизнес — до 30 млрд рублей"
                    },
                    {
                      "name": "Крупнейший бизнес — свыше 30 млрд рублей",
                      "code": "Крупнейший бизнес — свыше 30 млрд рублей"
                    }
                  ]
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Описание",
                  "note": "Опишите корпорацию в нескольких предложениях",
                  "type": "string",
                  "maxLength": "480",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "localName": "Загрузить логотип",
                  "title": "Логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Работа со стартапами",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "fields": [
                {
                  "sysName": "project_industry",
                  "title": "Направления",
                  "description": "Выберите направления, по которым Вы ищете стартапы",
                  "localName": "Направления",
                  "note": "Выберите направления, по которым Вы ищете стартапы",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_stady",
                  "title": "Стадии развития стартапов",
                  "description": "Выберите интересующие стадии развития стартапов",
                  "localName": "Стадия развития",
                  "note": "Выберите интересующие стадии развития стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    7000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "title": "Потребности корпорации",
              "subTitle": "Потребность №",
              "withIndex": true,
              "actionText": "Добавить потребность",
              "isArray": "true",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotId",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_suggestCase",
                  "localName": "Описание потребности",
                  "note": "Кратко опишите суть Вашего запроса на пилотирование стартапа",
                  "type": "string",
                  "maxLength": "520",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 5,
              "pageName": "Пилотирование",
              "fields": [
                {
                  "sysName": "questionnaire_successPilots",
                  "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_startupInvestmentYears",
                  "title": "Информация о сотрудничестве со стартапами",
                  "localName": "Сколько лет Ваша корпорация работает со стартапами",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_overallPilots",
                  "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_lastYearInvestmentsCount",
                  "localName": "Количество пилотов со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },

                {
                  "sysName": "questionnaire_overallContracts",
                  "localName": "Количество контрактов (внедрений) со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 6,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "investment_investment",
                  "localName": "Инвестирует ли Ваша корпорация в стартапы?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_industry",
                  "title": "Направления",
                  "description": "Выберите интересные для Вас направления инвестирования",
                  "localName": "Направления",
                  "note": "Выберите интересные для Вас направления инвестирования",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Раунд инвестиций",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "project_geography",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 6,
              "pageName": "Инвестиции",
              "triggerField": "investment_investment",
              "triggerValue": true,
              "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
              "isArray": true,
              "subTitle": "Стартап №",
              "withIndex": true,
              "actionText": "Добавить кейс",
              "fields": [
                {
                  "sysName": "successPilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "successPilots[]_company",
                  "localName": "Название стартапа",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "successPilots[]_suggestCase",
                  "localName": "Описание кейса",
                  "type": "string",
                  "maxLength": "300",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Скаутинг",
              "page": 7,
              "pageName": "Скаутинг",
              "moduleNote": "Подбор технологических решений стартапов под запрос заказчика",
              "fields": [
                {
                  "sysName": "questionnaire_scouting",
                  "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            }
          ]
        }'
where "type" = 1 and formname = 'corporate_edit';