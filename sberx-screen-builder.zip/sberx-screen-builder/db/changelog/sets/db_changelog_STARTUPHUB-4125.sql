--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4125
delete from public.screen_buttons_link sbl
 where sbl.screen_id in (select sb.screen_id
                         from public.screen_button sb
                         where sb.name = 'corporate_Administrator' and sb.state = 20009)
 and sbl.button_id in (select b.button_id
                       from public.buttons b
                       where b.code = 20004);