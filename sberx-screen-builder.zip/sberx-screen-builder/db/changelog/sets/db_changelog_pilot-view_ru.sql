--liquibase formatted sql
--changeset Zakutskiy MY:pilot-view_ru

delete from pages where code = 'pilot-view_ru';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('pilot-view_ru', 'Пилот | SberUnity', '/pilot-view', 'Страница отображения пилота', 'auth', '{
      "features":[
         {
            "config":{
               "nowrap":true
            },
            "type":"pilotView",
            "visible":true,
            "labels":{
               "all":"Все",
               "respond":"Отклик",
               "responses":"Отклики",
               "commentFromCorporation":"Комментарий от корпорации:",
               "unableRemoveFavorites":"Не удалось отправить запрос на удаление из избранного",
               "unableAddFavorites":"Не удалось отправить запрос на добавление в избранное",
               "moreAboutCorporation":"Подробнее о корпорации",
               "otherPilots":"Другие пилоты",
               "applicationSent":"Заявка отправлена",
               "failedSendRespond":"Не удалось отправить отклик",
               "confirmCancel":"Да, отменить",
               "back":"Назад",
               "save":"Изменения сохранены",
               "failSave":"Не удалось сохранить изменения",
               "edit":"Редактировать",
               "cancel":"Отменить",
               "confirmCancelPilot":"Подтвердите отмену пилота",
               "confirm":"Да, подтверждаю",
               "forChecking":"На проверку",
               "noRespondYet":"Откликов пока нет",
               "cancel2":"Отмена"
            }
         }
      ]
   }', 1);