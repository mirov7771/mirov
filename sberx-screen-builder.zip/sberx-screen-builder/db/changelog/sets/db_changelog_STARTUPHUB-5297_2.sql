--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5297_2
update pages set name = 'Analogues | SberUnity' where uri = '/import-substitution' and lang_id = 2;
update pages set name = 'Мои метрики | SberUnity' where uri = '/metrics' and lang_id = 1;
update pages set name = 'Choose a role to register | SberUnity' where uri = '/participant-registration' and lang_id = 2;
update pages set name = 'Questionnaire | SberUnity' where uri = '/questionnaire' and lang_id = 2;
update pages set name = 'Анкета | SberUnity' where uri = '/questionnaire' and lang_id = 1;
update pages set name = 'Скидки для стартапов | SberUnity' where uri = '/vas' and lang_id = 1;
