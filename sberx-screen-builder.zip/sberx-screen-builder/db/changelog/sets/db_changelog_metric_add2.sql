--liquibase formatted sql
--changeset Mirov AA:metric_add2
update public.screen
set formedit = '{
  "form":
  [
    {
      "page": 1,
      "module": "Добавление значений",
      "moduleNote": "Укажите известные значения метрики %metricName% в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
		  "direction": "row",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
		  "direction": "row",
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
		  "direction": "row",
          "sysName": "items_date"
        }
      ]
    }
  ]
}'
where formname = 'add_metric_values';

update screen
set  formedit = '{
  "form":
  [
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные значения метрики в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
		  "direction": "row",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
		  "direction": "row",
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
		  "direction": "row",
          "sysName": "items_date"
        }
      ]
    }
  ]
}'
where formname = 'edit_metric'