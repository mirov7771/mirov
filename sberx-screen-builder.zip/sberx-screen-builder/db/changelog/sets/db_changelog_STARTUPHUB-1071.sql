--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1071
UPDATE screen SET formedit = cast(replace(cast(formedit as text),'Публичное название / название бренда','Фирменное наименование (Товарный знак)') as json) WHERE formname in ('New_StartUp', 'startup_edit');