--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3817
select setval('public.screen_id_seq',  (SELECT max(id)+1 FROM public.screen s));
delete from public.screen where formname = 'syndicate_SyndicateUser';
INSERT INTO public.screen (clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id) VALUES('111260', 12, 'syndicate_SyndicateUser', NULL, '{
    "form": [
        {
            "page": 1,
            "module": "Основная информация",
            "pageName": "",
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "firstName",
                    "required": false,
                    "localName": "Имя"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "lastName",
                    "required": false,
                    "localName": "Фамилия"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "phone",
                    "required": false,
                    "localName": "Номер телефона"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "email",
                    "required": false,
                    "localName": "Email"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "telegramLink",
                    "required": false,
                    "localName": "Никнейм в Telegram"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "site",
                    "required": false,
                    "localName": "Сайт проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "orgFullName",
                    "required": false,
                    "localName": "Название компании"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "ventureExperience",
                    "required": false,
                    "localName": "Венчурный опыт"
                },
                {
                    "type": "array",
                    "edited": false,
                    "activity": [
                        39000
                    ],
                    "format": "search_dropdown",
                    "sysName": "sumInvestment",
                    "required": false,
                    "localName": "Какую сумму вы готовы инвестировать?"
                }

            ]

        }
    ]
}'::json::json, 'Просмотр анкеты синдиката', NULL, 1, NULL, NULL, NULL, NULL, 1);

INSERT INTO public.screen (clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id) VALUES('8385', 12, 'syndicate_SyndicateUser', NULL, '{
    "form": [
        {
            "page": 1,
            "module": "Основная информация",
            "pageName": "",
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "firstName",
                    "required": false,
                    "localName": "Имя"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "lastName",
                    "required": false,
                    "localName": "Фамилия"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "phone",
                    "required": false,
                    "localName": "Номер телефона"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "email",
                    "required": false,
                    "localName": "Email"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "telegramLink",
                    "required": false,
                    "localName": "Никнейм в Telegram"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "site",
                    "required": false,
                    "localName": "Сайт проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "orgFullName",
                    "required": false,
                    "localName": "Название компании"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "ventureExperience",
                    "required": false,
                    "localName": "Венчурный опыт"
                },
                {
                    "type": "array",
                    "edited": false,
                    "activity": [
                        39000
                    ],
                    "format": "search_dropdown",
                    "sysName": "sumInvestment",
                    "required": false,
                    "localName": "Какую сумму вы готовы инвестировать?"
                }

            ]

        }
    ]
}'::json::json, 'Просмотр анкеты синдиката', NULL, 1, NULL, NULL, NULL, NULL, 1);

insert into public.screen_button (name, state) values('syndicate_SyndicateUser', 20002);
insert into public.screen_button (name, state) values('syndicate_SyndicateUser', 20012);
insert into public.screen_button (name, state) values('syndicate_SyndicateUser', 20009);
insert into public.screen_button (name, state) values('syndicate_SyndicateUser', 20004);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_SyndicateUser' and state = 20002 limit 1),
       (select button_id from buttons where code = 20012));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_SyndicateUser' and state = 20012 limit 1),
       (select button_id from buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_SyndicateUser' and state = 20012 limit 1),
       (select button_id from buttons where code = 20004));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_SyndicateUser' and state = 20009 limit 1),
       (select button_id from buttons where code = 20004));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'syndicate_SyndicateUser' and state = 20004 limit 1),
       (select button_id from buttons where code = 20009));