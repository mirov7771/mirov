--liquibase formatted sql
--changeset MOLOTKOV D:STARTUPHUB-1874 Добавление форм на редактирование и создание заявки на скаутинг
INSERT INTO public.screen ("type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(13, 'New_scouting', '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Иван",
                    "sysName": "name",
                    "required": true,
                    "localName": "Имя контактного лица",
                    "maxLength": 90,
                    "showLength": false
                },                 {
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "mail@example.u",
                    "sysName": "email",
                    "required": true,
                    "localName": "Email для связи"
                },               {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "phone",
                    "required": true,
                    "localName": "Телефон"
                },
{
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите потребность в скаутинг",
                    "sysName": "comment",
                    "required": false,
                    "localName": "Описание потребности",
                    "maxLength": "300",
                    "showLength": false
                }

            ],
            "module": "",
            "pageName": "",
            "moduleNote": ""
        }
    ]
}'::json::json, NULL, 'Запрос на скаутинг', 'Укажите данные контактного лица, ответственного в вашей компании за скаутинг. Ваша заявка отправится представителям SberUnity.', 1, NULL, NULL, NULL, NULL, 1, NULL);
INSERT INTO public.screen ("type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(13, 'scouting_edit', '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "name",
                    "required": false,
                    "localName": "Имя контактного лица",
                    "maxLength": 90,
                    "showLength": false
                },                 {
                    "type": "string",
                    "edited": false,
                    "format": "e-mail",
                    "sysName": "email",
                    "required": false,
                    "localName": "Email для связи"
                },               {
                    "mask": "phone",
                    "type": "string",
                    "edited": false,
                    "format": "phone",
                    "sysName": "phone",
                    "required": false,
                    "localName": "Телефон"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": false,
                    "example": "Опишите потребность в скаутинг",
                    "sysName": "comment",
                    "required": false,
                    "localName": "Описание потребности",
                    "maxLength": "300"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "sysName": "adminComment",
                    "required": false,
                    "localName": "Коментарий",
                    "maxLength": "300",
                    "note":"Комментарий доступен только администратору"
                }

            ],
            "module": "",
            "pageName": "",
            "moduleNote": ""
        }
    ]
}'::json::json, NULL, 'Запрос на скаутинг', NULL, 1, NULL, NULL, NULL, NULL, 1, NULL);