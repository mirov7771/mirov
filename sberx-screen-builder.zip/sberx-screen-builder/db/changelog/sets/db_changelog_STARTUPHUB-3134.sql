--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3134
update public.buttons
set text = 'Смотреть полную анкету стартапа',
    click_method = 'GET',
    click_action = '/view?type=0&action=1&id='
where code = '100000';