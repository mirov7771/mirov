--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-2548
CREATE TABLE screen_button (
                               screen_id bigserial PRIMARY KEY,
                               name character varying(150),
                               admin_check boolean,
                               main_check boolean,
                               parent_check boolean,
                               success_pilot_check boolean,
                               owner_check boolean,
                               state integer
);

CREATE TABLE buttons (
                         button_id bigserial PRIMARY KEY,
                         code integer,
                         text character varying(150)
);

CREATE TABLE screen_buttons_link (
                         id bigserial PRIMARY KEY,
                         screen_id bigserial,
                         button_id bigserial
);