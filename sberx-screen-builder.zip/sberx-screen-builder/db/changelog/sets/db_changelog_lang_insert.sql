--liquibase formatted sql
--changeset Fedorov EO:task_1
insert into lang (locale)
values ('ru'),('en');