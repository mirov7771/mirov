--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-4797 Добавление кнопок админу для отклонения пилотов из статусов черновик или согласовано

insert into screen_buttons_link(button_id, screen_id )
select
    (select b.button_id from buttons b where code = 20009 limit 1),
    (select sb.screen_id  from screen_button sb join screen_buttons_link sbl on sbl.screen_id = sb.screen_id  where sb."name" = 'pilot_Administrator' and state = 20001 limit 1)
where
    not exists
    (
    select sbl.id from screen_buttons_link sbl where
    button_id = (select b.button_id from buttons b where code = 20009 limit 1) and
    screen_id = (select sb.screen_id  from screen_button sb join screen_buttons_link sbl on sbl.screen_id = sb.screen_id  where sb."name" = 'pilot_Administrator' and state = 20001 limit 1)
    );

insert into screen_buttons_link(button_id, screen_id )
select
    (select b.button_id from buttons b where code = 20009 limit 1),
    (select sb.screen_id  from screen_button sb join screen_buttons_link sbl on sbl.screen_id = sb.screen_id  where sb."name" = 'pilot_Administrator' and state = 20004 limit 1)
where
    not exists
    (
    select sbl.id from screen_buttons_link sbl where
    button_id = (select b.button_id from buttons b where code = 20009 limit 1) and
    screen_id = (select sb.screen_id  from screen_button sb join screen_buttons_link sbl on sbl.screen_id = sb.screen_id  where sb."name" = 'pilot_Administrator' and state = 20004 limit 1)
    );