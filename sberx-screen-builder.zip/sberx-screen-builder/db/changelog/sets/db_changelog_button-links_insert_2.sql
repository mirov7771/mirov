--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-2548_insert_2
insert into screen_buttons_link (screen_id, button_id)
select screen_id , (select button_id from public.buttons b where code = 100003)
from public.screen_button sb
where state = 20004
  and name in ('corporate_SuperClient', 'investor_SuperClient', 'startup_SuperClient')
  and owner_check is null;