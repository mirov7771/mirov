--liquibase formatted sql
--changeset Mirov AA:community_forms
delete from public.screen where formname like 'New_Community%';
insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_Community_BusinessAngel', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "В каком сообществе бизнес-ангелов Вы уже состоите?",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 1
                }
            ]
        }
    ]
}', 'Заявка бизнес-ангела', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_Community_StartUp', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название стартапа*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт проекта*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в стартапе*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 0
                }
            ]
        }
    ]
}', 'Заявка стартапа', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_Community_VentureFond', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в фонде*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 2
                }
            ]
        }
    ]
}', 'Заявка венчурный фонд', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_Community_FamilyOffice', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название family office*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 3
                }
            ]
        }
    ]
}', 'Заявка family office', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_Community_Corporate', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Сайт компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в стартапе*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 4
                }
            ]
        }
    ]
}', 'Заявка корпората', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '111260', 11, 'New_Community_Mentor', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "facebook",
                    "localName": "Ваш сайт или аккаунт в Facebook*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "note": "Ссылка на сайт или аккаунт"
                },
                {
                    "sysName": "expert",
                    "localName": "В какой области Вы являетесь экспертом?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Маркетинг"
                },
                {
                    "sysName": "site",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 5
                }
            ]
        }
    ]
}', 'Заявка ментора/трекера', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_Community_BusinessAngel', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "В каком сообществе бизнес-ангелов Вы уже состоите?",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 1
                }
            ]
        }
    ]
}', 'Заявка бизнес-ангела', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_Community_StartUp', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название стартапа*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт проекта*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в стартапе*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 0
                }
            ]
        }
    ]
}', 'Заявка стартапа', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_Community_VentureFond', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в фонде*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 2
                }
            ]
        }
    ]
}', 'Заявка венчурный фонд', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_Community_FamilyOffice', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название family office*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Ссылка на сайт фонда*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "note": "Выберите направления",
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций*",
                    "note": "Выберите географию",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "round",
                    "note": "Выберите стадии",
                    "localName": "Интересующие стадии инвестиций*",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        7000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле*",
                    "note": "0",
                    "type": "int",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "note": "Ссылка на аккаунт",
                    "type": "string",
                    "edited": true,
                    "required": false,
                    "format": "hide"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 3
                }
            ]
        }
    ]
}', 'Заявка family office', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_Community_Corporate', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "Название компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "SberUnity"
                },
                {
                    "sysName": "site",
                    "localName": "Сайт компании*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "note": "https://sberunity.ru"
                },
                {
                    "sysName": "position",
                    "localName": "Ваша должность в стартапе*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Менеджер"
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 4
                }
            ]
        }
    ]
}', 'Заявка корпората', 1, 1);

insert into public.screen (id, clientid, type, formname, formedit, name, pages, lang_id)
values ((select max(id)+1 from screen ), '8385', 11, 'New_Community_Mentor', '{
    "form": [
        {
            "module": "Заявка на вступление в сообщество СберСтартап",
            "page": 1,
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "facebook",
                    "localName": "Ваш сайт или аккаунт в Facebook*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 250,
                    "showLength": false,
                    "note": "Ссылка на сайт или аккаунт"
                },
                {
                    "sysName": "expert",
                    "localName": "В какой области Вы являетесь экспертом?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 200,
                    "showLength": false,
                    "note": "Маркетинг"
                },
                {
                    "sysName": "site",
                    "localName": "Электронная почта*",
                    "note": "mail@sberunity.ru",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи*",
                    "note": "+7 000 000-00-00",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите об ожиданиях от участия в сообществе"
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?*",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 500,
                    "showLength": false,
                    "note": "Расскажите, чем вы можете быть полезны сообществу"
                },
                {
                    "sysName": "type",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": true,
                    "required": false,
                    "value": 5
                }
            ]
        }
    ]
}', 'Заявка ментора/трекера', 1, 1);