--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-4152

INSERT INTO public.screen ("type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(0, 'startup_SuperStartup', '{}'::json::json, '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
             {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }

         ],
         "module":"Основная информация"
      }
   ]
}'::json::json, 'Просмотр анкеты стартапа', NULL, NULL, '{
                                                                                                                                                                       "buttons": [
                                                                                                                                                                         {
                                                                                                                                                                           "text": "Поделиться",
                                                                                                                                                                           "сode": "100003"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }'::json::json, NULL, NULL, NULL, 1, NULL);
