--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-2548_insert
INSERT INTO buttons
(code, text)
VALUES (20003, 'На доработку'),
       (20004, 'Согласовать'),
       (20009, 'Отклонить'),
       (20012, 'В работу'),
       (100000, 'Перейти в анкету'),
       (100001, 'Запросы корпорации'),
       (100002, 'Удалить'),
       (100003, 'Поделиться');

INSERT INTO screen_button
(name, admin_check, main_check, parent_check, success_pilot_check, owner_check, state)
VALUES ('startup_Administrator', false, null, null, null, null, 20004),
    ('corporate_Administrator', false, null, null, null, null, 20004),
    ('investor_Administrator', false, null, null, null, null, 20004),

    ('startup_Administrator', true, true, false, null, null, 20001),
    ('startup_Administrator', true, true, false, null, null, 20002),
    ('startup_Administrator', true, true, false, null, null, 20003),
    ('startup_Administrator', true, true, false, null, null, 20004),
    ('startup_Administrator', true, true, false, null, null, 20009),

    ('startup_Administrator', true, true, true, null, null, 20004),

    ('startup_Administrator', true, false, null, null, null, 20002),

    ('corporate_Administrator', true, true, false, null, null, 20001),
    ('corporate_Administrator', true, true, false, null, null, 20002),
    ('corporate_Administrator', true, true, false, null, null, 20003),
    ('corporate_Administrator', true, true, false, null, null, 20004),
    ('corporate_Administrator', true, true, false, null, null, 20009),

    ('corporate_Administrator', true, true, true, null, null, 20004),

    ('corporate_Administrator', true, false, false, null, null, 20002),

    ('investor_Administrator', true, true, false, null, null, 20001),
    ('investor_Administrator', true, true, false, null, null, 20002),
    ('investor_Administrator', true, true, false, null, null, 20003),
    ('investor_Administrator', true, true, false, null, null, 20004),
    ('investor_Administrator', true, true, false, null, null, 20009),

    ('investor_Administrator', true, true, true, null, null, 20004),

    ('investor_Administrator', true, false, null, null, null, 20002),

    ('pilot_Administrator', true, null, null, null, null, 20002),
    ('pilot_Administrator', true, null, null, null, null, 20012),
    ('pilot_Administrator', true, null, null, null, null, 20003),
    ('pilot_Administrator', true, null, null, null, null, 20004),
    ('pilot_Administrator', true, null, null, null, null, 20012),

    ('New_Pilot', null, null, null, null, true, null),
    ('pilot_edit', null, null, null, null, true, 20002),
    ('pilot_edit', null, null, null, null, true, 20003),
    ('pilot_edit', null, null, null, null, true, 20004),
    ('pilot_edit', null, null, null, null, true, 20009),
    ('pilot_edit', null, null, null, null, true, 20012),

    ('pilot_SuperClient', null, null, null, null, null, 20004),

    ('corporate_SuperClient', null, null, null, false, true, 20004),
    ('corporate_SuperClient', null, null, null, true, true, 20004),
    ('investor_SuperClient', null, null, null, null, true, 20004),
    ('startup_SuperClient', null, null, null, null, true, 20004),

    ('corporate_SuperClient', null, null, null, null, null, 20004),
    ('investor_SuperClient', null, null, null, null, null, 20004),
    ('startup_SuperClient', null, null, null, null, null, 20004),

    ('reply_SuperClient', null, null, null, null, null, 20001),

    ('corp_app_Administrator', null, null, null, null, null, 20011),
    ('corp_app_Administrator', null, null, null, null, null, 20012),
    ('corp_app_Administrator', null, null, null, null, null, 20009),
    ('corp_app_Administrator', null, null, null, null, null, 20004),
    ('invest_app_Administrator', null, null, null, null, null, 20011),
    ('invest_app_Administrator', null, null, null, null, null, 20012),
    ('invest_app_Administrator', null, null, null, null, null, 20009),
    ('invest_app_Administrator', null, null, null, null, null, 20004),
    ('corp_app_Administrator', null, null, null, null, null, 20011),
    ('corp_app_Administrator', null, null, null, null, null, 20012),
    ('corp_app_Administrator', null, null, null, null, null, 20009),
    ('corp_app_Administrator', null, null, null, null, null, 20004),
    ('invest_app_Administrator', null, null, null, null, null, 20011),
    ('invest_app_Administrator', null, null, null, null, null, 20012),
    ('invest_app_Administrator', null, null, null, null, null, 20009),
    ('invest_app_Administrator', null, null, null, null, null, 20004);

create index x1_screen_button on screen_button (name, state);
create index x1_screen_buttons_link on screen_buttons_link (screen_id, button_id);















