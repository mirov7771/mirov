--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-lead_name
update public.screen
set formview = '{
  "form": [
    {
      "module": "Основная информация",
      "fields": [
        {
          "sysName": "roundType",
          "localName": "Стадия раунда",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "presentation",
          "localName": "Инвестиционная презентация",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": true
        },
        {
          "sysName": "geography",
          "localName": "Юрисдикция сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "transactionType",
          "localName": "Тип сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            14000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "endDate",
          "localName": "Дата закрытия сделки",
          "type": "date",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Оценка стартапа в раунде",
      "fields": [
        {
          "sysName": "sumInvestment",
          "localName": "Какую сумму инвестиций вы привлекаете?",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "$"
        },
        {
          "sysName": "percent",
          "localName": "За какой процент компании?",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "%"
        },
        {
          "sysName": "preMoney",
          "localName": "Pre-money",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "$"
        },
        {
          "sysName": "postMoney",
          "localName": "Post-money",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "$"
        },
        {
          "sysName": "result",
          "localName": "Какие результаты будут достигнуты?",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "На что пойдут деньги?",
      "fields": [
        {
          "sysName": "marketingPercent",
          "localName": "Маркетинг и продажи",
          "type": "string",
          "edited": false,
          "required": false,
          "mask": "%"
        },
        {
          "sysName": "softwarePercent",
          "localName": "Оборудование и ПО",
          "type": "string",
          "edited": false,
          "required": false,
          "mask": "%"
        },
        {
          "sysName": "teamPercent",
          "localName": "Оплата текущей команды",
          "type": "string",
          "edited": false,
          "required": false,
          "mask": "%"
        },
        {
          "sysName": "extensionPercent",
          "localName": "Расширение команды",
          "type": "string",
          "edited": false,
          "required": false,
          "mask": "%"
        },
        {
          "sysName": "otherDescription",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Статус раунда",
      "fields": [
        {
          "sysName": "leadCheck",
          "localName": "Есть ли лид-инвестор?",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": true
        },
        {
          "sysName": "leadName",
          "localName": "Лид-инвестор",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "lastInvestment",
          "localName": "Какая сумма уже собрана?",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "$"
        },
        {
          "sysName": "futureInvestment",
          "localName": "Осталось собрать",
          "type": "string",
          "edited": false,
          "required": true,
          "mask": "$"
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "fields": [
        {
          "sysName": "roundInfo",
          "localName": "Дополнительная информация о раунде",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Контакты",
      "fields": [
        {
          "sysName": "inviteFio",
          "localName": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "email",
          "localName": "Электронная почта сотрудника",
          "type": "string",
          "format": "e-mail",
          "edited": false,
          "required": true
        },
        {
          "sysName": "phone",
          "localName": "Телефон сотрудника",
          "type": "string",
          "format": "phone",
          "edited": false,
          "required": true
        }
      ]
    }
  ]
}'
where formname = 'round_Administrator'

