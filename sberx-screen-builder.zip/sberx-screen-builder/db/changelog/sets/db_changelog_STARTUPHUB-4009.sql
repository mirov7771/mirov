--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4009
insert into public.screen_buttons_link (screen_id, button_id)
select screen_id,
       (select button_id
        from public.buttons b
        where b.code = 20014)
from public.screen_button sb where name = 'syndicate_Administrator';
