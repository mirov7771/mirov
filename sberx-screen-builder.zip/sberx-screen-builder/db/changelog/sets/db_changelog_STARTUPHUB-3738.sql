--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3738

select setval('public.features_id_seq',  (SELECT max(id) FROM public.features));
select setval('public.feature_attributes_values_id_seq',  (SELECT max(id) FROM public.feature_attributes_values));
select setval('public.values_id_seq',  (SELECT max(id) FROM public.values));
select setval('public.pages_id_seq',  (SELECT max(id) FROM public.pages));


-- В ВИДЖЕТАХ С ТИПОМ mainHeader ВЫКЛЮЧИЛИ АТРИБУТ header, СКОРРЕКТИРОВАЛИ АТРИБУТ title.
update public.values
set  value='**СберСтартап**  \nсообщество'
where id IN (select fav.id_values from feature_attributes_values fav where fav.id_attributes =22 and id_features in (select f.id from features f where f.feature_type='mainHeader'));

update public.feature_attributes_values
set status='disabled' where id_attributes =21 and id_features in (select f.id from features f where f.feature_type='mainHeader');


INSERT INTO public.feature_types (code, name) VALUES
                                                  ('block', 'Объединяющий блок'),
                                                  ('tileList', 'Список плиток с описанием');

INSERT INTO public.features (id, code, name, status, feature_type, description) VALUES
                                                                                    (291,'syndicateMainHeader_1 and syndicateBulletBanner_1 block', 'Объединяющий блок 1','published','block',DEFAULT),
                                                                                    (292,'syndicateMainHeader_1', 'Венчурный клуб «Синдикат»','published','mainHeader',DEFAULT),
                                                                                    (293,'syndicateMainHeader_1_button_1', 'Кнопка баннера Заголовка','published','button',DEFAULT),
                                                                                    (294,'syndicateBulletBanner_1', 'Баннер с буллитами. Соинвестируйте с профессионалами рынка','published','bulletBanner',DEFAULT),
                                                                                    (295,'syndicateTileList_1', 'Плитки "Основатели клуба"','published','tileList',DEFAULT),
                                                                                    (296,'syndicateRoadMap_1', 'Как стать членом клуба и инвестировать в проекты?"','published','roadMap',DEFAULT),
                                                                                    (297,'syndicateSquareList_1 and syndicateFooter_button_1 block', 'Объединяющий блок 2','published','block',DEFAULT),
                                                                                    (298,'syndicateSquareList_1', 'Преимущества клуба Синдикат','published','squareList',DEFAULT),
                                                                                    (299,'syndicateFooter_button_1', 'Кнопка Присоединиться к клубу','published','button',DEFAULT);

INSERT INTO public.pages (id, code, name, uri, description, page_type, parent_id) VALUES
    (11, 'syndicate_nz', 'Невторизованная зона. СберСтартап. Синдикат','/syndicate','Начните инвестировать с профессионалами венчурного рынка и станьте частью международного инвестиционного сообщества', 'unauth', DEFAULT);

INSERT INTO public.pages_features (id_features, id_pages, is_visible,id_parent_feature) VALUES
                                                                                            (291,11,TRUE,DEFAULT),
                                                                                            (292,11,TRUE,291),
                                                                                            (293,11,TRUE,292),
                                                                                            (294,11,TRUE,291),
                                                                                            (295,11,TRUE,DEFAULT),
                                                                                            (296,11,TRUE,DEFAULT),
                                                                                            (297,11,TRUE,DEFAULT),
                                                                                            (298,11,TRUE,297),
                                                                                            (299,11,TRUE,297);

insert into public.values (id, value, locale) values
                                                  (3900, 'true', 'ru'),
                                                  (3901, '1', 'ru'),
                                                  (3902, 'Венчурный клуб **«Синдикат»**', 'ru'),
                                                  (3903, 'Получите доступ к эксклюзивным сделкам клуба', 'ru'),
                                                  (3904, 'Начните инвестировать с профессионалами венчурного рынка и станьте частью международного инвестиционного сообщества', 'ru'),
                                                  (3905, 'simple', 'ru'),
                                                  (3906, 'true', 'ru'),
                                                  (3907, 'active', 'ru'),
                                                  (3908, 'Присоединиться к клубу', 'ru'),
                                                  (3909, NULL, 'ru'),
                                                  (3910, 'redirect', 'ru'),
                                                  (3911, 'true', 'ru'),
                                                  (3912, NULL, 'ru'),
                                                  (3913, NULL, 'ru'),
                                                  (3914, '/syndicate/join', 'ru'),
                                                  (3915, 'yellow-gradient', 'ru'),
                                                  (3916, NULL, 'ru'),
                                                  (3917, '/file/main_header.png', 'ru'),
                                                  (3918, '1', 'ru'),
                                                  (3919, 'linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)', 'ru'),
                                                  (3920, NULL, 'ru'),
                                                  (3921, NULL, 'ru'),


                                                  (3922, 'true', 'ru'),
                                                  (3923, '**Соинвестируйте**  \nс профессионалами', 'ru'),
                                                  (3924, 'Снижайте риски, соинвестируя с лучшими венчурными фондами_|_Обеспечьте себе поток лучших сделок_|_Расширьте портфель за счёт низкого входного чека_|_Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки', 'ru'),
                                                  (3925, 'left', 'ru'),
                                                  (3926, '2', 'ru'),
                                                  (3927, NULL, 'ru'),
                                                  (3928, '/file/bullet_banner.png', 'ru'),



                                                  (3929, '**Основатели** клуба', 'ru'),
                                                  (3930, NULL, 'ru'),
                                                  (3931, 'linear-gradient(277.89deg, rgba(243, 198, 80, 0.7) -71.03%, rgba(21, 22, 26, 0) 105.5%)', 'ru'),

                                                  (3932, 'Сбер', 'ru'),
                                                  (3933, 'Крупнейшая в России экосистема, включающая 65+ компаний. Является не только одним из главных пользователей венчурной индустрии, но и активно строит ее. SberUnity - первая российская онлайн-платформа для объединения участников рынка технологий на федеральном уровне.', 'ru'),
                                                  (3934, '/file/tile_list_1.png', 'ru'),
                                                  (3935, 'МИК', 'ru'),
                                                  (3936, 'Московский инновационный кластер создает экосистему продуктов и сервисов, а также условия, необходимые для эффективного развития инноваций и новых проектов.', 'ru'),
                                                  (3937, '/file/tile_list_2.png', 'ru'),
                                                  (3938, 'Angelsdeck', 'ru'),
                                                  (3939, 'Клуб венчурных инвесторов, который даёт возможность участникам присоединяться к эксклюзивным сделкам и подключиться к сообществу доверенных инвесторов.', 'ru'),
                                                  (3940, '/file/tile_list_3.png', 'ru'),
                                                  (3941, '3', 'ru'),
                                                  (3942, NULL, 'ru'),


                                                  (3943, 'true', 'ru'),
                                                  (3944, '4', 'ru'),
                                                  (3945, NULL, 'ru'),
                                                  (3946, '**Как стать членом клуба** и инвестировать в проекты?', 'ru'),
                                                  (3947, NULL, 'ru'),
                                                  (3948, '[Подайте заявку](/syndicate/join)', 'ru'),
                                                  (3949, 'Заполните анкету на вступление в клуб', 'ru'),
                                                  (3950, '1', 'ru'),
                                                  (3951, 'Пройдите собеседование', 'ru'),
                                                  (3952, 'Дождитесь рассмотрения Вашей заявки модератором и пройдите интервью', 'ru'),
                                                  (3953, '2', 'ru'),
                                                  (3954, 'Подпишите  \nNDA', 'ru'),
                                                  (3955, 'Подключитесь к закрытому Telegram-каналу и чатам', 'ru'),
                                                  (3956, '3', 'ru'),
                                                  (3957, 'Присоединитесь  \nк клубу', 'ru'),
                                                  (3958, 'Подключитесь к закрытому Telegram-каналу и чатам', 'ru'),
                                                  (3959, '4', 'ru'),
                                                  (3960, '#383A43', 'ru'),


                                                  (3961, 'true', 'ru'),
                                                  (3962, '5', 'ru'),
                                                  (3963, 'linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)', 'ru'),
                                                  (3964, NULL, 'ru'),
                                                  (3965, NULL, 'ru'),

                                                  (3966, '**Преимущества** клуба Синдикат', 'ru'),
                                                  (3967, '5', 'ru'),
                                                  (3968, NULL, 'ru'),
                                                  (3969, NULL, 'ru'),
                                                  (3970, 'Соинвестиции', 'ru'),
                                                  (3971, 'Присоединяйтесь к сделкам с комфортным чеком', 'ru'),
                                                  (3972, '/file/square_list_1.png', 'ru'),
                                                  (3973, 'Экспертиза', 'ru'),
                                                  (3974, 'Связывайтесь с экспертами клуба на любом этапе заключения сделки', 'ru'),
                                                  (3975, '/file/square_list_2.png', 'ru'),
                                                  (3976, 'Обучение', 'ru'),
                                                  (3977, 'Сделайте первые шаги, избежав типичных ошибок', 'ru'),
                                                  (3978, '/file/square_list_3.png', 'ru'),
                                                  (3979, 'Нетворкинг', 'ru'),
                                                  (3980, 'Живое общение с близкими по интересам людьми для решения ваших бизнес-задач', 'ru'),
                                                  (3981, '/file/square_list_4.png', 'ru'),
                                                  (3982, 'Эксклюзивность', 'ru'),
                                                  (3983, 'Эксклюзивные мероприятия с инвесторами', 'ru'),
                                                  (3984, '/file/square_list_5.png', 'ru'),
                                                  (3985, 'Поддержка', 'ru'),
                                                  (3986, 'Обмен опытом и помощь в решении бизнес-кейсов', 'ru'),
                                                  (3987, '/file/square_list_6.png', 'ru'),


                                                  (3988, 'simple', 'ru'),
                                                  (3989, 'true', 'ru'),
                                                  (3990, 'active', 'ru'),
                                                  (3991, 'Присоединиться к клубу', 'ru'),
                                                  (3992, NULL, 'ru'),
                                                  (3993, 'redirect', 'ru'),
                                                  (3995, '/syndicate/join', 'ru'),
                                                  (3994, NULL, 'ru'),
                                                  (3996, 'center', 'ru'),
                                                  (3997, 'yellow-gradient', 'ru'),
                                                  (3998, '7', 'ru'),
                                                  (3999, 'true', 'ru'),
                                                  (4000, 'true', 'ru'),
--ДОБАВЛЕНИЕ ФОНОВОЙ КАРТИНКИ (backgroundUrl) В mainHeader

                                                  (4001, '/file/bg-main.png', 'ru'),
                                                  (4002, '/file/bg-main.png', 'ru'),
                                                  (4003, '/file/bg-main.png', 'ru'),
                                                  (4004, '/file/bg-main.png', 'ru'),
                                                  (4005, '/file/bg-main.png', 'ru'),
                                                  (4006, '/file/bg-main.png', 'ru'),
                                                  (4007, '/file/bg-main.png', 'ru'),
                                                  (4008, '/file/bg-main.png', 'ru'),
                                                  (4009, '/file/bg-main.png', 'ru'),
                                                  (4010, '/file/bg-main.png', 'ru');

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES

                                                                                                                          --"type" : "block"
                                                                                                                          --"visible": true,
                                                                                                                          (3999,1,3999,291,DEFAULT,'published',DEFAULT),
                                                                                                                          --"position": 1,
                                                                                                                          (3918,2,3918,291,DEFAULT,'published',DEFAULT),
                                                                                                                          --  "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
                                                                                                                          (3919,36,3919,291,DEFAULT,'published',DEFAULT),
                                                                                                                          --"config":{}
                                                                                                                          (3920,4,3920,291,DEFAULT,'published',DEFAULT),
                                                                                                                          --"features": [
                                                                                                                          (3921,31,3921,291,DEFAULT,'published',DEFAULT),

                                                                                                                          --"type" : "mainHeader"
                                                                                                                          --"visible": true,
                                                                                                                          (3900,1,3900,292,3921,'published',DEFAULT),
                                                                                                                          --"position": 1,
                                                                                                                          (3901,2,3901,292,3921,'published',DEFAULT),
                                                                                                                          --"title": "Венчурный клуб **«Синдикат»**",
                                                                                                                          (3902,22,3902,292,3921,'published',DEFAULT),
                                                                                                                          --"bullets": "Получите доступ к эксклюзивным сделкам клуба",
                                                                                                                          (3903,30,3903,292,3921,'published',DEFAULT),
                                                                                                                          --"description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
                                                                                                                          (3904,23,3904,292,3921,'published',DEFAULT),
                                                                                                                          --"config":{}
                                                                                                                          (3916,4,3916,292,3921,'published',DEFAULT),

--  "imageUrl": "/file/bullet-banner-invest.png",
                                                                                                                          (3917,5,3917,292,3921,'published',DEFAULT),
                                                                                                                          --"features": [
                                                                                                                          (3913,31,3913,292,3921,'published',DEFAULT),
                                                                                                                          -- {
                                                                                                                          --"type" : "button"
                                                                                                                          --"category": "simple"
                                                                                                                          (3905,24,3905,293,3913,'published',DEFAULT),
                                                                                                                          --"visible": true,
                                                                                                                          (3906,1,3906,293,3913,'published',DEFAULT),
                                                                                                                          --"default": "active",
                                                                                                                          (3907,10,3907,293,3913,'published',DEFAULT),
                                                                                                                          --"text": "Присоединиться к клубу",
                                                                                                                          (3908,25,3908,293,3913,'published',DEFAULT),
                                                                                                                          --"iconUrl": null,
                                                                                                                          (3912,26,3912,293,3913,'published',DEFAULT),
                                                                                                                          --"url": "",
                                                                                                                          (3914,27,3914,293,3913,'published',DEFAULT),
                                                                                                                          --"action": "redirect"
                                                                                                                          (3910,11,3910,293,3913,'published',DEFAULT),
                                                                                                                          --"config":{}
                                                                                                                          (3909,4,3909,293,3913,'published',DEFAULT),
                                                                                                                          --"theme": "yellow-gradient"
                                                                                                                          (3915,34,3915,293,3913,'published',DEFAULT),
                                                                                                                          -- }
                                                                                                                          -- {

                                                                                                                          --"type": "bulletBanner",
                                                                                                                          --"visible": true,
                                                                                                                          (3922,1,3922,294,3921,'published',DEFAULT),
                                                                                                                          --"header": "Соинвестируйте с профессионалами рынка",
                                                                                                                          (3923,21,3923,294,3921,'published',DEFAULT),
                                                                                                                          --"bullets": ["Снижайте риски, соинвестируя с лучшими венчурными фондами","Обеспечьте себе поток лучших сделок","Расширьте портфель за счёт низкого входного чека","Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"],
                                                                                                                          (3924,30,3924,294,3921,'published',DEFAULT),
                                                                                                                          --  "imageUrl": "/file/bullet-banner-invest.png",
                                                                                                                          (3928,5,3928,294,3921,'published',DEFAULT),
                                                                                                                          --"config": {
                                                                                                                          (3927,4,3927,294,3921,'published',DEFAULT),
                                                                                                                          --"direction": "left"
                                                                                                                          (3925,15,3925,294,3927,'published',DEFAULT),
                                                                                                                          -- }
                                                                                                                          --"position": 2
                                                                                                                          (3926,2,3926,294,3921,'published',DEFAULT),
                                                                                                                          -- }


                                                                                                                          --"type":"tileList"
                                                                                                                          --"header": "**Основатели** клуба"
                                                                                                                          (3929,21,3929,295,DEFAULT,'published',DEFAULT),
                                                                                                                          --  "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
                                                                                                                          (3931,36,3931,295,DEFAULT,'published',DEFAULT),
                                                                                                                          --"visible": true,
                                                                                                                          (4000,1,4000,295,DEFAULT,'published',DEFAULT),
                                                                                                                          --"items" : [
                                                                                                                          (3930,6,3930,295,DEFAULT,'published',DEFAULT),
                                                                                                                          --[1]
                                                                                                                          --"title": "**Сбер**"
                                                                                                                          (3932,22,3932,295,3930,'published',1),
                                                                                                                          --"description": "Живое общение с близкими по интересам",
                                                                                                                          (3933,23,3933,295,3930,'published',1),
                                                                                                                          --"imageUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3934,5,3934,295,3930,'published',1),
                                                                                                                          --[2]
                                                                                                                          --"title": "**МИК**",
                                                                                                                          (3935,22,3935,295,3930,'published',2),
                                                                                                                          --"description": "Московский инновационный кластер создает экосистему продуктов и сервисов, а также условия, необходимые для эффективного развития инноваций и новых проектов.",
                                                                                                                          (3936,23,3936,295,3930,'published',2),
                                                                                                                          --"imageUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3937,5,3937,295,3930,'published',2),
                                                                                                                          --[3]
                                                                                                                          --"title": "**Angelsdeck**",
                                                                                                                          (3938,22,3938,295,3930,'published',3),
                                                                                                                          --"description": "Клуб венчурных инвесторов, который даёт возможность участникам присоединяться к эксклюзивным сделкам и подключиться к сообществу доверенных инвесторов.",
                                                                                                                          (3939,23,3939,295,3930,'published',3),
                                                                                                                          --"imageUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3940,5,3940,295,3930,'published',3),

                                                                                                                          --"position": 3
                                                                                                                          (3941,2,3941,295,DEFAULT,'published',DEFAULT),
                                                                                                                          --"config": {}
                                                                                                                          (3942,4,3942,295,DEFAULT,'published',DEFAULT),
                                                                                                                          -- }




                                                                                                                          --"type": "roadMap",
                                                                                                                          --"visible": true,
                                                                                                                          (3943,1,3943,296,DEFAULT,'published',DEFAULT),
                                                                                                                          --"position": 4,
                                                                                                                          (3944,2,3944,296,DEFAULT,'published',DEFAULT),
                                                                                                                          --"config": {},
                                                                                                                          (3945,4,3945,296,DEFAULT,'published',DEFAULT),
                                                                                                                          -- "header": "**Как стать членом клуба** и инвестировать в проекты?",
                                                                                                                          (3946,21,3946,296,DEFAULT,'published',DEFAULT),
                                                                                                                          --  "backgroundColor": "#383A43",
                                                                                                                          (3960,36,3960,296,DEFAULT,'published',DEFAULT),
                                                                                                                          --"items": [
                                                                                                                          (3947,6,3947,296,DEFAULT,'published',DEFAULT),
                                                                                                                          --[1]
                                                                                                                          --"title": "[Подайте заявку]()",
                                                                                                                          (3948,22,3948,296,3947,'published',1),
                                                                                                                          --"description": "Заполните анкету на вступление в клуб",
                                                                                                                          (3949,23,3949,296,3947,'published',1),
                                                                                                                          --"stepNumber": "1"
                                                                                                                          (3950,35,3950,296,3947,'published',1),
                                                                                                                          --[2]
                                                                                                                          --"title": "Пройдите собеседование",
                                                                                                                          (3951,22,3951,296,3947,'published',2),
                                                                                                                          --"description": "Дождитесь рассмотрения Вашей заявки модератором и пройдите интервью",
                                                                                                                          (3952,23,3952,296,3947,'published',2),
                                                                                                                          --"stepNumber": "2"
                                                                                                                          (3953,35,3953,296,3947,'published',2),
                                                                                                                          --[3]
                                                                                                                          --"title": "Подпишите  \\nNDA",
                                                                                                                          (3954,22,3954,296,3947,'published',3),
                                                                                                                          --"description": "В случае принятия положительного решения, подпишите документы",
                                                                                                                          (3955,23,3955,296,3947,'published',3),
                                                                                                                          --"stepNumber": "3"
                                                                                                                          (3956,35,3956,296,3947,'published',3),
                                                                                                                          --[4]
                                                                                                                          --"title": "Присоединитесь  \\nк клубу",
                                                                                                                          (3957,22,3957,296,3947,'published',4),
                                                                                                                          --"description": "Подключитесь к закрытому Telegram-каналу и чатам",
                                                                                                                          (3958,23,3958,296,3947,'published',4),
                                                                                                                          --"stepNumber": "4"
                                                                                                                          (3959,35,3959,296,3947,'published',4),
                                                                                                                          -- ]
                                                                                                                          -- }

                                                                                                                          --"type" : "block"
                                                                                                                          --"visible": true,
                                                                                                                          (3961,1,3961,297,DEFAULT,'published',DEFAULT),
                                                                                                                          --"position": 5,
                                                                                                                          (3962,2,3962,297,DEFAULT,'published',DEFAULT),
                                                                                                                          --  "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
                                                                                                                          (3963,36,3963,297,DEFAULT,'published',DEFAULT),
                                                                                                                          --"config":{}
                                                                                                                          (3964,4,3964,297,DEFAULT,'published',DEFAULT),
                                                                                                                          --"features": [
                                                                                                                          (3965,31,3965,297,DEFAULT,'published',DEFAULT),


                                                                                                                          --"type":"squareList"
                                                                                                                          --"title": "**Преимущества** клуба Синдикат"
                                                                                                                          (3966,22,3966,298,3965,'published',DEFAULT),
                                                                                                                          --"position": 6,
                                                                                                                          (3967,2,3967,298,3965,'published',DEFAULT),
                                                                                                                          --"config":{}
                                                                                                                          (3968,4,3968,298,3965,'published',DEFAULT),
                                                                                                                          --"items" : [
                                                                                                                          (3969,6,3969,298,3965,'published',DEFAULT),
                                                                                                                          --[1]
                                                                                                                          --"title": "Соинвестиции"
                                                                                                                          (3970,22,3970,298,3969,'published',1),
                                                                                                                          --"description": "Присоединяйтесь к сделкам с комфортным чеком",
                                                                                                                          (3971,23,3971,298,3969,'published',1),
                                                                                                                          --"iconUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3972,26,3972,298,3969,'published',1),
                                                                                                                          --[2]
                                                                                                                          --"title": "Экспертиза",
                                                                                                                          (3973,22,3973,298,3969,'published',2),
                                                                                                                          --"description": "Связывайтесь с экспертами клуба на любом этапе заключения сделки",
                                                                                                                          (3974,23,3974,298,3969,'published',2),
                                                                                                                          --"iconUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3975,26,3975,298,3969,'published',2),
                                                                                                                          --[3]
                                                                                                                          --"title": "Обучение",
                                                                                                                          (3976,22,3976,298,3969,'published',3),
                                                                                                                          --"description": "Сделайте первые шаги, избежав типичных ошибок",
                                                                                                                          (3977,23,3977,298,3969,'published',3),
                                                                                                                          --"iconUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3978,26,3978,298,3969,'published',3),
                                                                                                                          --[4]
                                                                                                                          --"title": "Нетворкинг",
                                                                                                                          (3979,22,3979,298,3969,'published',4),
                                                                                                                          --"description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
                                                                                                                          (3980,23,3980,298,3969,'published',4),
                                                                                                                          --"iconUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3981,26,3981,298,3969,'published',4),
                                                                                                                          --[5]
                                                                                                                          --"title": "Эксклюзивность",
                                                                                                                          (3982,22,3982,298,3969,'published',5),
                                                                                                                          --"description": "Эксклюзивные мероприятия с инвесторами",
                                                                                                                          (3983,23,3983,298,3969,'published',5),
                                                                                                                          --"iconUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3984,26,3984,298,3969,'published',5),
                                                                                                                          --[6]
                                                                                                                          --"title": "Поддержка",
                                                                                                                          (3985,22,3985,298,3969,'published',6),
                                                                                                                          --"description": "Обмен опытом и помощь в решении бизнес-кейсов",
                                                                                                                          (3986,23,3986,298,3969,'published',6),
                                                                                                                          --"iconUrl": "https://cons.ru/im.jpg"
                                                                                                                          (3987,26,3987,298,3969,'published',6),
                                                                                                                          -- ]
                                                                                                                          -- {
                                                                                                                          --"type" : "button"
                                                                                                                          --"category": "simple"
                                                                                                                          (3988,24,3988,299,3965,'published',DEFAULT),
                                                                                                                          --"visible": true,
                                                                                                                          (3989,1,3989,299,3965,'published',DEFAULT),
                                                                                                                          --"position": 7,
                                                                                                                          (3998,2,3998,299,3965,'published',DEFAULT),
                                                                                                                          --"default": "active",
                                                                                                                          (3990,10,3990,299,3965,'published',DEFAULT),
                                                                                                                          --"text": "Присоединиться к клубу",
                                                                                                                          (3991,25,3991,299,3965,'published',DEFAULT),
                                                                                                                          --"iconUrl": null,
                                                                                                                          (3992,26,3992,299,3965,'published',DEFAULT),
                                                                                                                          --"url": "",
                                                                                                                          (3995,27,3995,299,3965,'published',DEFAULT),
                                                                                                                          --"action": "redirect"
                                                                                                                          (3993,11,3993,299,3965,'published',DEFAULT),
                                                                                                                          --"config":{}
                                                                                                                          (3994,4,3994,299,3965,'published',DEFAULT),
                                                                                                                          -- "position": "center"
                                                                                                                          (3996,2,3996,299,3994,'disabled',DEFAULT),
                                                                                                                          --"theme": "yellow-gradient"
                                                                                                                          (3997,34,3997,299,3965,'published',DEFAULT),
                                                                                                                          -- }
                                                                                                                          -- {
--ДОБАВЛЕНИЕ ФОНОВОЙ КАРТИНКИ (backgroundUrl) Во все виджеты mainHeader СООБЩЕСТВА
                                                                                                                          (4001,29,4001,1,DEFAULT,'published',DEFAULT),
                                                                                                                          (4002,29,4002,30,DEFAULT,'published',DEFAULT),
                                                                                                                          (4003,29,4003,59,DEFAULT,'published',DEFAULT),
                                                                                                                          (4004,29,4004,88,DEFAULT,'published',DEFAULT),
                                                                                                                          (4005,29,4005,117,DEFAULT,'published',DEFAULT),
                                                                                                                          (4006,29,4006,146,DEFAULT,'published',DEFAULT),
                                                                                                                          (4007,29,4007,175,DEFAULT,'published',DEFAULT),
                                                                                                                          (4008,29,4008,204,DEFAULT,'published',DEFAULT),
                                                                                                                          (4009,29,4009,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (4010,29,4010,262,DEFAULT,'published',DEFAULT);





select setval('public.features_id_seq',  (SELECT max(id) FROM public.features));
select setval('public.feature_attributes_values_id_seq',  (SELECT max(id) FROM public.feature_attributes_values));
select setval('public.values_id_seq',  (SELECT max(id) FROM public.values));
select setval('public.pages_id_seq',  (SELECT max(id) FROM public.pages));
