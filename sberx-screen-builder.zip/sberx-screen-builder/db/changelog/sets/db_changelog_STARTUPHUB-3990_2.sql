--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3990_2
delete from public.screen_buttons_link
where screen_id in (
    select screen_id from public.screen_button sb where state = 20001 and name in ('startup_Administrator', 'corporate_Administrator', 'investor_Administrator')
)
  and button_id in (select button_id from buttons b2 where code = 20003);