--liquibase formatted sql
--changeset Mirov AA:vas_page
update pages
set page = '{
   "features":[
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_ru",
         "visible":true,
         "position":2,
         "placeholder":"Введите название",
         "loginDescription":"Присоединяйтесь к платформе,<br/>чтобы воспользоваться предложением сервиса",
         "joinButtonName":"Присоединиться",
         "loginButtonName":"Войти",
		 "header": "Сервисы",
         "alphabetically":"По алфавиту",
         "byUpdateDate": "По дате обновления",
         "byCreationDate":"По дате создания",
		 "heading": "Сервисы для бизнеса"
      }
   ]
}'
where uri = '/vas'
  and code = 'vas_az_auth_ru';

update pages
set page = '{
   "features":[
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_en",
         "visible":true,
         "position":2,
         "placeholder":"Enter a name",
         "loginDescription": "Join the platform <br/>to take advantage of the service offer",
         "joinButtonName": "Join",
         "loginButtonName": "Enter",
		 "header": "Services",
         "alphabetically":"Alphabetically",
         "byUpdateDate": "By date modified",
         "byCreationDate":"By creation date",
		 "heading": "Services for business"
      }
   ]
}'
where uri = '/vas'
  and code = 'vas_az_auth_en';