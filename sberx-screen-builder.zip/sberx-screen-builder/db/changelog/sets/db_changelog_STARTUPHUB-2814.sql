--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2814
delete from screen where formname in ('round_Administrator', 'round_short_Administrator');
INSERT INTO screen
(id, clientid, "type", formname, formview)
VALUES((select max(id) + 1 from screen ), '111260', 10, 'round_Administrator',  '{
  "form": [
    {
      "module": "Основная информация",
      "fields": [
        {
          "sysName": "round_roundType",
          "localName": "Стадия раунда",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_presentation",
          "localName": "Инвестиционная презентация",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_geography",
          "localName": "Юрисдикция сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_transactionType",
          "localName": "Тип сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            14000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_endDate",
          "localName": "Дата закрытия сделки",
          "type": "date",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Оценка стартапа в раунде",
      "fields": [
        {
          "sysName": "round_sumInvestment",
          "localName": "Какую сумму инвестиций вы привлекаете?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_percent",
          "localName": "За какой процент компании?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_preMoney",
          "localName": "Pre-money",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_postMoney",
          "localName": "Post-money",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_result",
          "localName": "Какие результаты будут достигнуты?",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "На что пойдут деньги?",
      "fields": [
        {
          "sysName": "round_marketingPercent",
          "localName": "Маркетинг и продажи",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_softwarePercent",
          "localName": "Оборудование и ПО",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_teamPercent",
          "localName": "Оплата текущей команды",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_extensionPercent",
          "localName": "Расширение команды",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_otherDescription",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Статус раунда",
      "fields": [
        {
          "sysName": "round_leadCheck",
          "localName": "Есть ли лид-инвестор?",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_lastInvestment",
          "localName": "Какая сумма уже собрана?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_futureInvestment",
          "localName": "Осталось собрать",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "fields": [
        {
          "sysName": "round_roundInfo",
          "localName": "Дополнительная информация о раунде",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Контакты",
      "fields": [
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта сотрудника",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phone",
          "localName": "Телефон сотрудника",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}');

INSERT INTO screen
(id, clientid, "type", formname, formview)
VALUES((select max(id) + 1 from screen ), '8385', 10, 'round_Administrator',  '{
  "form": [
    {
      "module": "Основная информация",
      "fields": [
        {
          "sysName": "round_roundType",
          "localName": "Стадия раунда",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_presentation",
          "localName": "Инвестиционная презентация",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_geography",
          "localName": "Юрисдикция сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_transactionType",
          "localName": "Тип сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            14000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_endDate",
          "localName": "Дата закрытия сделки",
          "type": "date",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Оценка стартапа в раунде",
      "fields": [
        {
          "sysName": "round_sumInvestment",
          "localName": "Какую сумму инвестиций вы привлекаете?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_percent",
          "localName": "За какой процент компании?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_preMoney",
          "localName": "Pre-money",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_postMoney",
          "localName": "Post-money",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_result",
          "localName": "Какие результаты будут достигнуты?",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "На что пойдут деньги?",
      "fields": [
        {
          "sysName": "round_marketingPercent",
          "localName": "Маркетинг и продажи",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_softwarePercent",
          "localName": "Оборудование и ПО",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_teamPercent",
          "localName": "Оплата текущей команды",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_extensionPercent",
          "localName": "Расширение команды",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_otherDescription",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Статус раунда",
      "fields": [
        {
          "sysName": "round_leadCheck",
          "localName": "Есть ли лид-инвестор?",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_lastInvestment",
          "localName": "Какая сумма уже собрана?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_futureInvestment",
          "localName": "Осталось собрать",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "fields": [
        {
          "sysName": "round_roundInfo",
          "localName": "Дополнительная информация о раунде",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Контакты",
      "fields": [
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта сотрудника",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phone",
          "localName": "Телефон сотрудника",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}');

INSERT INTO screen
(id, clientid, "type", formname, formview)
VALUES((select max(id) + 1 from screen ), '111260', 10, 'round_short_Administrator',  '{
  "form": [
    {
      "module": "Основная информация",
      "fields": [
        {
          "sysName": "round_roundType",
          "localName": "Стадия раунда",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_otherDescription",
          "localName": "Цель привлечения инвестиций",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_geography",
          "localName": "Планируемая юрисдикция сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_transactionType",
          "localName": "Планируемый тип сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            14000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_planDate",
          "localName": "Планируемая дата начала сбора раунда",
          "type": "date",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Планируемая оценка стартапа в раунде",
      "fields": [
        {
          "sysName": "round_sumInvestment",
          "localName": "Какую сумму инвестиций вы планируете привлекать?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_percent",
          "localName": "За какой процент компании?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_preMoney",
          "localName": "Pre-money",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_postMoney",
          "localName": "Post-money",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Контакты",
      "fields": [
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта сотрудника",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phone",
          "localName": "Телефон сотрудника",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}');

INSERT INTO screen
(id, clientid, "type", formname, formview)
VALUES((select max(id) + 1 from screen ), '8385', 10, 'round_short_Administrator',  '{
  "form": [
    {
      "module": "Основная информация",
      "fields": [
        {
          "sysName": "round_roundType",
          "localName": "Стадия раунда",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_otherDescription",
          "localName": "Цель привлечения инвестиций",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "round_geography",
          "localName": "Планируемая юрисдикция сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_transactionType",
          "localName": "Планируемый тип сделки",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            14000
          ],
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_planDate",
          "localName": "Планируемая дата начала сбора раунда",
          "type": "date",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Планируемая оценка стартапа в раунде",
      "fields": [
        {
          "sysName": "round_sumInvestment",
          "localName": "Какую сумму инвестиций вы планируете привлекать?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_percent",
          "localName": "За какой процент компании?",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_preMoney",
          "localName": "Pre-money",
          "type": "string",
          "edited": false,
          "required": true
        },
        {
          "sysName": "round_postMoney",
          "localName": "Post-money",
          "type": "string",
          "edited": false,
          "required": true
        }
      ]
    },
    {
      "module": "Контакты",
      "fields": [
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта сотрудника",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phone",
          "localName": "Телефон сотрудника",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}');