--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4509
update public.screen set
    formview = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "date",
                    "edited": false,
                    "sysName": "session_date",
                    "required": false,
                    "localName": "Время посещения"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год регистрации*"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_name",
                    "required": false,
                    "localName": "Публичное название / название бренда"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Страна юрисдикции*"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_email",
                    "required": false,
                    "localName": "Публичный адрес электронной почты"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт корпорации"
                }
            ],
            "module": "Юридическая информация об организации",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "representative_fio",
                    "required": false,
                    "localName": "Фамилия Имя представителя*"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "representative_role",
                    "required": false,
                    "localName": "Должность"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "representative_phone",
                    "required": false,
                    "localName": "Мобильный телефон"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "representative_email",
                    "required": false,
                    "localName": "Электронная почта*"
                }
            ],
            "module": "Представитель",
            "pageName": "",
            "moduleNote": ""
        },
        {
            "page": 1,
            "title": "",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": "Основатель"
                },
                {
                    "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
                    "type": "string",
                    "edited": false,
                    "sysName": "workers[]_fio",
                    "required": false,
                    "localName": "Имя, фамилия представителя",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "note": "Укажите должность ответственного лица из предыдущего вопроса",
                    "type": "string",
                    "edited": false,
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100",
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "e-mail",
                    "sysName": "workers[]_facebook",
                    "required": false,
                    "localName": "Электронная почта",
                    "maxLength": "150",
                    "showLength": false
                }
            ],
            "module": "Публичный контакт",
            "isArray": "true",
            "pageName": "Информация о представителе",
            "actionText": "Добавить контактное лицо"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Направления",
                    "edited": false,
                    "format": "text",
                    "sysName": "questionnaire_industry",
                    "activity": [
                        22000
                    ],
                    "required": false,
                    "localName": "Направление деятельности"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "questionnaire_innovationMethod",
                    "activity": [
                        4000
                    ],
                    "required": false,
                    "localName": "Укажите методы"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_turnover",
                    "required": false,
                    "localName": "Годовой оборот"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_note",
                    "required": false,
                    "localName": "Краткое описание"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_fullNote",
                    "required": false,
                    "localName": "Полное описание"
                },
                {
                    "type": "logo",
                    "edited": false,
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип"
                }
            ],
            "module": "Корпорация",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": false,
                    "localName": "Технологии",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Направления"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "questionnaire_stady",
                    "activity": [
                        7000
                    ],
                    "required": false,
                    "localName": "Стадия развития"
                }
            ],
            "module": "Работа со стартапами",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "questionnairePilots[]_pilotId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnairePilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание потребности"
                }
            ],
            "module": "Потребности корпорации",
            "isArray": "true",
            "subTitle": "Потребность №",
            "withIndex": true
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": false,
                    "localName": "У вашей компании есть опыт сотрудничества со стартапами?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_startupInvestmentYears",
                    "required": false,
                    "localName": "Сколько лет ваша корпорация работает со стартапами"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_overallPilots",
                    "required": false,
                    "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_lastYearInvestmentsCount",
                    "required": false,
                    "localName": "Количество пилотов со стартапами за последний год"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_overallContracts",
                    "required": false,
                    "localName": "Количество контрактов (внедрений) со стартапами за последний год"
                }
            ],
            "module": "Успешные кейсы",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": false,
                    "localName": "Инвестирует ли ваша корпорация в стартапы?"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "investment_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Направления"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "investment_round",
                    "activity": [
                        6000
                    ],
                    "required": false,
                    "localName": "Раунд инвестиций"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "search_dropdown",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "География стартапов",
                    "multySelect": true
                }
            ],
            "module": "Инвестиции",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "successPilots[]_company",
                    "required": false,
                    "localName": "Название стартапа"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "successPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание кейса"
                }
            ],
            "module": "Успешные кейсы инвестирования",
            "isArray": true,
            "pageName": "",
            "subTitle": "Стартап №",
            "withIndex": true
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_scouting",
                    "required": false,
                    "localName": "Рассматриваете ли вы скаутинг как инструмент для поиска нужных стартапов?*"
                }
            ],
            "module": "Скаутинг",
            "pageName": ""
        }
    ]
}'
where formname = 'corporate_Administrator';