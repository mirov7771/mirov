--liquibase formatted sql
--changeset Mirov AA:features_table
create table FEATURE
(
    ID       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY ,
    FORM_NAME VARCHAR(150),
    NAME     VARCHAR(150),
    VISIBLE  BOOLEAN,
    TYPE     VARCHAR(150),
    CONFIG   JSON
);