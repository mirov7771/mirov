--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3678
update public."values"
set value = replace(value, 'инофрмацию', 'информацию')
where value like '%инофрмацию%';