--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2450
update public.buttons
set text = 'Смотреть запросы на технологии'
where code = 100001