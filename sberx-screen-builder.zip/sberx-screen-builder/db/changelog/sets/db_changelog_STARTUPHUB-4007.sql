--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4007
insert into public.buttons (code, text, lang_id) values (20014, 'Корзина', 1);
insert into public.screen_buttons_link (screen_id, button_id)
select screen_id,
       (select button_id
        from public.buttons b
        where b.code = 20014)
from public.screen_button sb where name = 'syndicate_SyndicateUser';
