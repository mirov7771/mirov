--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-3233 Разблюр карточек

UPDATE screen
SET    formview =
           REPLACE(formview::text, '"isBlur": true', '"isBlur": false')::jsonb
;