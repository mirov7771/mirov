--liquibase formatted sql
--changeset Mirov AA:recm_page_2
delete from public.pages where uri = '/startup/recommended';

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('startup_recommended_az_ru', 'SberUnity', '/startup/recommended', 'SberUnity', 'auth', '{
   "features":[
      {
         "config":{

         },
         "type":"participantSearch",
         "filterBar":{
            "acceptButtonShortText":"Применить",
            "acceptButtonText":"Применить фильтры",
            "placeholder":"Поиск",
            "resetButtonShortText":"Сбросить",
            "resetButtonText":"Сбросить фильтры",
            "title":"Фильтры"
         },
         "foundsTitle":"Найдено: {0}",
         "header":"Рекомендованные",
         "participant":"startupsRecommend",
         "placeholder":"Поиск стартапа",
         "position":1,
         "shownFromTitle":"Показано {0} из {1}",
         "sortLabels":{
            "alphabetically":"По алфавиту",
            "byUpdateDate":"По дате обновления"
         },
         "sysName":"startupsRecommend_ru_participantSearch",
         "title":"Рекомендованные",
         "goBackLink":{
            "to":"/main/startups"
         },
         "visible":true
      }
   ]
}', 1);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('startup_recommended_az_en', 'SberUnity', '/startup/recommended', 'SberUnity', 'auth', '{
   "features":[
      {
         "config":{

         },
         "type":"participantSearch",
         "filterBar":{
            "acceptButtonShortText":"Apply",
            "acceptButtonText":"Apply filter",
            "placeholder":"Search",
            "resetButtonShortText":"Clear",
            "resetButtonText":"Clear filters",
            "title":"Filters"
         },
         "foundsTitle":"Found: {0}",
         "header":"Recommended",
         "participant":"startupsRecommend",
         "placeholder":"Search startup",
         "position":1,
         "shownFromTitle":"Shown {0} из {1}",
         "sortLabels":{
            "alphabetically":"Alphabetically",
            "byUpdateDate":"By modified date"
         },
         "sysName":"startupsRecommend_ru_participantSearch",
         "title":"Recommended",
         "goBackLink":{
            "to":"/main/startups"
         },
         "visible":true
      }
   ]
}', 2);