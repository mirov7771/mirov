--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4208
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20011 limit 1),
        (select button_id from public.buttons where code = 20011));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20002 limit 1),
        (select button_id from public.buttons where code = 20002));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 20004));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20009 limit 1),
        (select button_id from public.buttons where code = 20009));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20003));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 20007));