--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-5144

ALTER TABLE client_menu ADD COLUMN IF NOT EXISTS user_role varchar(100);
ALTER TABLE client_menu ADD COLUMN IF NOT EXISTS "lock" varchar(100);

delete from client_menu where menutype = 'sidebar' and user_role in ('CorpPro', 'CorpProPlus', 'InvestPro', 'InvestAngel', 'SuperClient', 'Client', 'CorpDemo', 'InvestDemo');

INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Запросы корпораций','pilots','/menu?type=0&name=pilots','GET','icPilot',NULL,NULL,5,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Инвестиции','investment','','GET','icInvestment',NULL,NULL,3,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icCorp',NULL,NULL,4,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icInvestor',NULL,NULL,2,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Сервисы','services','/vas/list','GET','icSidebarService',NULL,NULL,6,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Сообщество','community',NULL,NULL,'icSidebarCommunity',NULL,NULL,7,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Мои метрики','metrics',NULL,NULL,'icSidebarMetrics',NULL,NULL,10,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Запросы корпораций','pilots','/menu?type=0&name=pilots','GET','icPilot',NULL,NULL,5,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Инвестиции','investment','','GET','icInvestment',NULL,NULL,3,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icCorp',NULL,NULL,4,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Сервисы','services','/vas/list','GET','icSidebarService',NULL,NULL,6,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Сообщество','community',NULL,NULL,'icSidebarCommunity',NULL,NULL,7,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Мои метрики','metrics',NULL,NULL,'icSidebarMetrics',NULL,NULL,10,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icCorp',NULL,NULL,4,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,2,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Мои запросы','pilots','/menu?type=0&name=pilots','GET','icPilot',NULL,NULL,5,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Отклики','reply',NULL,NULL,'icSidebarReply',NULL,NULL,9,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Отклики','reply',NULL,NULL,'icSidebarReply',NULL,NULL,9,'CorpDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'CorpDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'CorpDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icCorp',NULL,NULL,4,'CorpDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Мои запросы','pilots','/menu?type=0&name=pilots','GET','icPilot',NULL,NULL,5,'CorpDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Скаутинг','scouting',NULL,NULL,'icSidebarScouting',NULL,NULL,10,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (0,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,2,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icCorp',NULL,NULL,4,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,2,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Мои запросы','pilots','/menu?type=0&name=pilots','GET','icPilot',NULL,NULL,5,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Отклики','reply',NULL,NULL,'icSidebarReply',NULL,NULL,9,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Скаутинг','scouting',NULL,NULL,'icSidebarScouting',NULL,NULL,10,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,2,'CorpDemo','tariffLock');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (1,'sidebar','Скаутинг','scouting',NULL,NULL,'icSidebarScouting',NULL,NULL,10,'CorpDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Инвестиции','investment',NULL,NULL,'icSidebarInvestment',NULL,NULL,2,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Запросы корпораций','pilots','/menu?type=0&name=pilots','GET','icSidebarPilot',NULL,NULL,5,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icSidebarCorp',NULL,NULL,4,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Сообщество','community',NULL,NULL,'icSidebarCommunity',NULL,NULL,7,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,3,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Скаутинг','scouting',NULL,NULL,'icSidebarScouting',NULL,NULL,10,'Client','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'Client','disabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Инвестиции','investment',NULL,NULL,'icSidebarInvestment',NULL,NULL,2,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Запросы корпораций','pilots','/menu?type=0&name=pilots','GET','icSidebarPilot',NULL,NULL,5,'InvestDemo','tariffLock');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icSidebarCorp',NULL,NULL,4,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Сообщество','community',NULL,NULL,'icSidebarCommunity',NULL,NULL,7,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,3,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Скаутинг','scouting',NULL,NULL,'icSidebarScouting',NULL,NULL,10,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'InvestDemo','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Инвестиции','investment',NULL,NULL,'icSidebarInvestment',NULL,NULL,2,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004','GET','icSidebarStartup',NULL,NULL,1,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Запросы корпораций','pilots','/menu?type=0&name=pilots','GET','icSidebarPilot',NULL,NULL,5,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Корпорации','corporates','/v2/list?type=1&filters=corp_unity&state=20004','GET','icSidebarCorp',NULL,NULL,4,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Сообщество','community',NULL,NULL,'icSidebarCommunity',NULL,NULL,7,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Инвесторы','investors','/v2/list?type=2&filters=invest_unity&state=20004','GET','icSidebarInvestor',NULL,NULL,3,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Скаутинг','scouting',NULL,NULL,'icSidebarScouting',NULL,NULL,10,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (2,'sidebar','Импортозамещение','import-substitution',NULL,NULL,'icSidebarImportSubstitution',NULL,NULL,11,'SuperClient','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (4,'sidebar','Синдикат','SyndicateUser',NULL,NULL,'icSidebarSyndicate',NULL,NULL,8,'SyndicateUser','enabled');
INSERT INTO public.client_menu ("type",menutype,"name",sysname,"action","method",logofile,isdefault,ui,priority,user_role,"lock") VALUES (5,'sidebar','Стартапы','startups','/v2/list?type=0&filters=startup_unity&state=20004',NULL,'icSidebarStartup',NULL,NULL,1,NULL,'enabled');


insert into client_menu (type, menutype, "name", sysname, action, method, logofile, priority, user_role, "lock")
select type, menutype, "name", sysname, "action" ,"method" ,logofile ,priority , 'CorpPro', "lock"
from client_menu
where
        menutype = 'sidebar' and user_role = 'SuperClient' and "type" = 1;

insert into client_menu (type, menutype, "name", sysname, action, method, logofile, priority, user_role, "lock")
select type, menutype, "name", sysname, "action" ,"method" ,logofile ,priority , 'CorpProPlus', "lock"
from client_menu
where
        menutype = 'sidebar' and user_role = 'SuperClient' and "type" = 1;

insert into client_menu (type, menutype, "name", sysname, action, method, logofile, priority, user_role, "lock")
select type, menutype, "name", sysname, "action" ,"method" ,logofile ,priority , 'InvestPro', "lock"
from client_menu
where
        menutype = 'sidebar' and user_role = 'SuperClient' and "type" = 2;

insert into client_menu (type, menutype, "name", sysname, action, method, logofile, priority, user_role, "lock")
select type, menutype, "name", sysname, "action" ,"method" ,logofile ,priority , 'InvestAngel', "lock"
from client_menu
where
        menutype = 'sidebar' and user_role = 'SuperClient' and "type" = 2;
