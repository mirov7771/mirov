--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1108
update client_menu set action = replace(action, '_Client', '_SuperClient') where action like '%_Client%';