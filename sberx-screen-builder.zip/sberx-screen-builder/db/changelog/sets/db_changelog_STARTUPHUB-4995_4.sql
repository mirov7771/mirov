--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.pages
set page = '{
    "features": [
      {
        "type": "breadcrumbs",
        "sysName": "pilot_en_breadcrumbs",
        "visible": true,
        "position": 1,
        "items": [
          {
            "name": "Main",
            "pathname": "/",
            "id":1
          },
          {
            "name": "Pilot projects",
            "id":2
          }
        ]
      },
      {
        "type": "pageTitle",
        "visible": true,
        "position": 2,
        "sysName": "pilot_en_pageTitle",
        "title": "Corporate technology requests",
        "config": {
          "styles": {
            "padding": {
              "xs": {
                "top": 16,
                "bottom": 24
              },
              "s": {
                "top": 16,
                "bottom": 24
              },
              "md": {
                "top": 24,
                "bottom": 32
              },
              "lg": {
                "top": 24,
                "bottom": 32
              }
            }
          }
        }
      },
      {
        "type": "pilotSearch",
        "joinButtonName": "Join",
        "loginButtonName": "Log in",
        "popupPilotDescription": "To respond to the pilot request, register or log in to your profile on SberUnity",
        "popupAllPilotsDescription": "To view all pilots, register or log in to your profile on SberUnity",
        "menuTitle": "Corporations",
        "buttonCorporationMenu": "Choose a corporation",
       "buttonShowMore": "Show more",
        "sysName": "pilot_en_pilotSearch",
        "visible": true,
        "position": 3,
        "placeholder": "Enter a name"
      }
    ]
  }'
where uri = '/pilot'
  and code = 'pilot_nz_unauth_en';