--liquibase formatted sql
--changeset Mirov A:admin_pilots
update public.client_menu
set action = '/list?type=4&state=20001&state=20001&state=20002&state=20003&state=20004&state=20005&state=20007&state=20008'
where sysname = 'pilots'
  and type = 5;