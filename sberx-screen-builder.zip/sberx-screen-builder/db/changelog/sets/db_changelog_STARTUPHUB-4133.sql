--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-4133

UPDATE public.screen SET  formview='{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "fio",
                    "required": false,
                    "localName": "Имя, Фамилия"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "name",
                    "required": false,
                    "localName": "Название"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "position",
                    "required": false,
                    "localName": "Должность"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "site",
                    "required": false,
                    "localName": "Сайт проекта"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "В какие направления инвестируете?"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Интересующая география инвестиций"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "round",
                    "activity": [
                        7000
                    ],
                    "required": false,
                    "localName": "Интересующие стадии инвестиций"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "expectation",
                    "required": false,
                    "localName": "Что вы ожидаете получить от сообщества?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "useful",
                    "required": false,
                    "localName": "Что вы можете дать сообществу?"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "ventureProjectsCount",
                    "required": false,
                    "localName": "Количество венчурных проектов в портфеле"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "email",
                    "required": false,
                    "localName": "Электронная почта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "phoneNumber",
                    "required": false,
                    "localName": "Номер телефона для связи"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "button",
                    "sysName": "facebook",
                    "required": false,
                    "localName": "Ваш аккаунт в Facebook"
                }
            ],
            "module": "Основная информация",
            "pageName": ""
        }
    ]
}'::json::json WHERE formname='community_Administrator';


UPDATE public.screen SET   formedit='{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "note":"SberUnity",
               "type":"string",
               "edited":true,
               "sysName":"name",
               "required":true,
               "localName":"Название бизнес-ангела",
               "maxLength":200,
               "showLength":false
            },
            {
               "note":"https://sberunity.ru",
               "type":"string",
               "edited":true,
               "regExp":"^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
               "sysName":"site",
               "required":true,
               "localName":"Ссылка на сайт",
               "maxLength":250,
               "showLength":false
            },
            {
               "note":"Выберите направления",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"industry",
               "activity":[
                  3000
               ],
               "required":true,
               "localName":"В какие направления инвестируете?",
               "multySelect":true
            },
            {
               "note":"Выберите географию",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"geography",
               "activity":[
                  2000
               ],
               "required":true,
               "localName":"Интересующая география инвестиций",
               "multySelect":true
            },
            {
               "note":"Выберите стадии",
               "type":"array",
               "edited":true,
               "format":"search_dropdown",
               "sysName":"round",
               "activity":[
                  7000
               ],
               "required":true,
               "localName":"Интересующие стадии инвестиций",
               "multySelect":true
            },
            {
               "note":"0",
               "type":"int",
               "edited":true,
               "sysName":"ventureProjectsCount",
               "required":false,
               "localName":"Количество венчурных проектов в портфеле"
            },
            {
               "note":"mail@sberunity.ru",
               "type":"string",
               "edited":true,
               "format":"e-mail",
               "sysName":"email",
               "required":true,
               "localName":"Электронная почта"
            },
            {
               "mask":"phone",
               "note":"+7 000 000-00-00",
               "type":"string",
               "edited":true,
               "format":"phone",
               "sysName":"phoneNumber",
               "required":true,
               "localName":"Номер телефона для связи"
            },
            {
               "note":"Ссылка на аккаунт",
               "type":"string",
               "edited":true,
               "format":"hide",
               "sysName":"facebook",
               "required":false,
               "localName":"Ваш аккаунт в Facebook"
            },
            {
               "type":"int",
               "value":1,
               "edited":true,
               "format":"hide",
               "sysName":"type",
               "required":false,
               "localName":""
            }
         ],
         "module":"Заявка на вступление в сообщество СберСтартап",
         "moduleNote":""
      }
   ]
}'::json::json WHERE formname='New_Community_BusinessAngel';

