--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-5242
update pages set page = '{
    "features": [
        {
            "type": "changePasswordForm",
            "sysName": "participant-registration_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 12 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"
                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "participant-registration_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_ru_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "title": "Мы обновили пользовательское соглашение",
            "description": "Примите его условия, чтобы продолжить работу на платформе SberUnity",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Продолжить",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}' where uri = '/participant-registration'
     and lang_id = 1;

update pages set page = '{
    "features": [
        {
            "type": "changePasswordForm",
            "sysName": "participant-registration_en_changePasswordForm",
            "titleForm": "Creating a new password",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Latin characters only ",
                "Minimum of 12 characters",
                "At least 6 different characters",
                "At least 1 uppercase and 1 lowercase letters",
                "At least 1 special symbol, for example \"! _ : ;\""
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "New password"
                },
                {
                    "type": "confirmPassword",
                    "label": "Repeat password",
                    "confirmPasswordLabel": "Repeat password"
                }
            ],
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "participant-registration_en_userAgreementForm_button",
                "text": "Create a password",
                "theme": "purple-gradient",
                "url": "/",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_en_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "title": "We have updated the user agreement",
            "description": "Accept terms to continue using the SberUnity platform",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Continue",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}' where uri = '/participant-registration'
     and lang_id = 2;
