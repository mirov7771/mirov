--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3848
update feature_attributes_values
set status='disabled' where id_attributes =21 and id_features in (select f.id from features f where f.feature_type='mainHeader');
