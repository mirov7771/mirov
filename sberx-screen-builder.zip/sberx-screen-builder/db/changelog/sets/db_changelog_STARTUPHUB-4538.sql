--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4538
delete from public.pages
where code in ('syndicate_nz_en', 'pilot_az_auth_en', 'questionnaire_az_en', 'questionnaire_view_az_en', 'scouting_az_en', 'pilot_corporate_az_auth_en', 'pilot_investors_az_auth_en');
insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('syndicate_nz_en', 'Невторизованная зона. СберСтартап. Синдикат', '/syndicate',
        'Начните инвестировать с профессионалами венчурного рынка и станьте частью международного инвестиционного сообщества',
        'unauth', '{
    "features": [
        {
            "type": "block",
            "sysName": "syndicateMainHeader_1 and syndicateBulletBanner_1 block",
            "position": 1,
            "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
            "config": {},
            "features": [
                {
                    "type": "mainHeader",
                    "sysName": "syndicateMainHeader_1",
                    "visible": true,
                    "position": 1,
                    "title": "Venture club **«Syndicate»**",
                    "bullets": [
                        "Get access to exclusive club deals"
                    ],
                    "description": "Start investing with venture market professionals and become part of the international investment community",
                    "features": [
                        {
                            "type": "button",
                            "sysName": "syndicateMainHeader_1_button_1",
                            "category": "simple",
                            "visible": true,
                            "default": "active",
                            "text": "Join the club",
                            "config": {},
                            "action": "redirect",
                            "iconUrl": null,
                            "url": "/syndicate/join",
                            "theme": "yellow-gradient"
                        }
                    ],
                    "config": {},
                    "imageUrl": "/file/main_header.png"
                },
                {
                    "type": "bulletBanner",
                    "sysName": "syndicateBulletBanner_1",
                    "visible": true,
                    "header": "**Co-invest**  \\nwith professionals",
                    "bullets": [
                        "Reduce risk by co-investing with the best venture capital funds",
                        "Get the best deal flow",
                        "Expand your portfolio with a low entry check",
                        "Easily join rounds and offer your syndicated deals"
                    ],
                    "position": 2,
                    "config": {
                        "direction": "left"
                    },
                    "imageUrl": "/file/bullet_banner.png"
                }
            ],
            "visible": true
        },
        {
            "type": "tileList",
            "sysName": "syndicateTileList_1",
            "header": "**Founders** of the club",
            "items": [
                {
                    "title": "Sber",
                    "description": "The largest ecosystem in Russia, including 65+ companies. It is not only one of the main users of the venture capital industry, but also actively builds it. SberUnity is the first Russian online platform for uniting technology market participants at the federal level.",
                    "imageUrl": "/file/tile_list_1.png"
                },
                {
                    "title": "MIC",
                    "description": "The Moscow Innovation Cluster creates an ecosystem of products and services, as well as the conditions necessary for the effective development of innovations and new projects.",
                    "imageUrl": "/file/tile_list_2.png"
                }
            ],
            "backgroundColor": "linear-gradient(277.89deg, rgba(243, 198, 80, 0.7) -71.03%, rgba(21, 22, 26, 0) 105.5%)",
            "position": 3,
            "config": {},
            "visible": true
        },
        {
            "type": "roadMap",
            "sysName": "syndicateRoadMap_1",
            "visible": true,
            "position": 4,
            "config": {},
            "header": "**How to become a club member** and invest in projects?",
            "items": [
                {
                    "title": "[Apply](/syndicate/join)",
                    "description": "Fill out an application to join the club",
                    "stepNumber": "1"
                },
                {
                    "title": "Pass the interview",
                    "description": "Wait for your application to be reviewed by the moderator and go through the interview",
                    "stepNumber": "2"
                },
                {
                    "title": "Sign  \\nNDA",
                    "description": "Connect to a closed Telegram channel and chats",
                    "stepNumber": "3"
                },
                {
                    "title": "Join \\nthe club",
                    "description": "Connect to a closed Telegram channel and chats",
                    "stepNumber": "4"
                }
            ],
            "backgroundColor": "#383A43"
        },
        {
            "type": "block",
            "sysName": "syndicateSquareList_1 and syndicateFooter_button_1 block",
            "visible": true,
            "position": 5,
            "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
            "config": {},
            "features": [
                {
                    "type": "squareList",
                    "sysName": "syndicateSquareList_1",
                    "title": "**Benefits** of the Syndicate Club",
                    "position": 5,
                    "config": {},
                    "items": [
                        {
                            "title": "Co-investment",
                            "description": "Join deals with a comfortable check",
                            "iconUrl": "/file/square_list_1.png"
                        },
                        {
                            "title": "Expertise",
                            "description": "Contact the club''s experts at any stage of the transaction",
                            "iconUrl": "/file/square_list_2.png"
                        },
                        {
                            "title": "Education",
                            "description": "Take the first steps avoiding common mistakes",
                            "iconUrl": "/file/square_list_3.png"
                        },
                        {
                            "title": "Networking",
                            "description": "Live communication with people of similar interests to solve your business problems",
                            "iconUrl": "/file/square_list_4.png"
                        },
                        {
                            "title": "Exclusivity",
                            "description": "Exclusive events with investors",
                            "iconUrl": "/file/square_list_5.png"
                        },
                        {
                            "title": "Support",
                            "description": "Exchange of experience and assistance in solving business cases",
                            "iconUrl": "/file/square_list_6.png"
                        }
                    ]
                },
                {
                    "type": "button",
                    "sysName": "syndicateFooter_button_1",
                    "category": "simple",
                    "visible": true,
                    "default": "active",
                    "text": "Join the club",
                    "iconUrl": null,
                    "action": "redirect",
                    "url": "/syndicate/join",
                    "config": {},
                    "theme": "yellow-gradient",
                    "position": 7
                }
            ]
        }
    ]
}', 2),
       ('pilot_az_auth_en', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "pilotSearch",
            "menuItems": {
                "all": {
                    "action": "/v2/list?type=4",
                    "id": 1,
                    "name": "All pilots",
                    "sysname": "all"
                },
                "corporates": {
                    "action": "/v2/list?type=4&filters=user&schema=pilots_user",
                    "id": 2,
                    "name": "My responses",
                    "sysname": "corporates"
                }
            },
            "corporationBlock": {
                "menuTitle": "Corporations",
                "buttonChooseCorporation": "Choose a corporation"
            },
            "fastFilters": {
                "favoriteLabel": "Favorites",
                "viewedLabel": "Viewed"
            },
            "infoBanner": {
                "typeBanner": "successStory",
                "title": "Tell us how SberUnity helped you and get new opportunities!",
                "mainButtonText": "Tell",
                "popupData": {
                    "title": "SberUnity is looking for success stories!",
                    "description": "If you applied for a pilot through SberUnity and launched it with a corporation, attracted an investor and received an investment tranche from him, or found a business partner, tell us about it.",
                    "benefits": {
                        "title": "For your success story, SberUnity will give you:",
                        "list": [
                "Publication about your success in the telegram channel [SberStartup](https://t.me/sberstartup)",
                "Priority issuance of your startup in the search",
                "Warm intro for any investor or corporation to choose from",
                "Let''s talk about your success to the business media"
            ]
                    },
                    "radioBoxInfo": {
                        "title": "Choose your success story:",
                        "list": [
                            {
                                "name": "Successful pilot",
                                "code": "Successful pilot"
                            },
                            {
                                "name": "Attracted investment",
                                "code": "Attracted investment"
                            },
                            {
                                "name": "Found partner",
                                "code": "Found partner"
                            }
                        ],
                        "input": {
                            "placeholder": "Tell us briefly about your successful case",
                            "errorMessages": {
                                "storyType": "Choose the type of success story",
                                "text": "Fill in the field"
                            }
                        }
                    },
                    "caption": "Let us know about your success story and the SberUnity administrator will contact you to discuss the details",
                    "button": {
                        "title": "Share story"
                    },
                    "toastInfo": {
                        "success": "Success story sent",
                        "error": "Failed to send success story"
                    }
                }
            }
        }
    ]
}', 2),
       ('questionnaire_az_en', 'SberUnity', '/questionnaire', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "questionnaire",
            "sysName": "questionnaire",
            "visible": true,
            "position": 1,
            "config": {
                "nowrap": true
            },
            "commentOfAdministrator": {
                "title": "Comment from administrator:",
                "description": "Your last changes to the profile are not visible to other users. To publish the current questionnaire, please make changes:"
            },
            "buttonLabels": {
                "success": "Save and exit",
                "back": "Back",
                "next": "Next",
                "send": "Send"
            },
            "modalLabels": {
                "title": "Thank you for your application!",
                "description": "Within a few days, we will check your profile and open full access to the platform, or we will contact you to clarify the details. In the meantime, you can view the special offers of services. If the verification of the questionnaire is delayed, write to us at ",
                "cancelButton": "Edit questionnaire",
                "confirmButton": "Get started"
            }
        }
    ]
}', 2),
       ('questionnaire_view_az_en', 'SberUnity', '/questionnaire-view', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "questionnaireView",
            "sysName": "",
            "visible": true,
            "position": 1,
            "backButtonTitle": "back",
            "adminCommentTitles": {
                "title": "Required additional information",
                "additionalInfo": "Admin comment:"
            },
          "config": {
              "nowrap": true
          }
        }
    ]
}', 2),
       ('scouting_az_en', 'SberUnity', '/scouting', 'SberUnity', 'auth', '{
   "features":[
      {
         "type":"welcomeScreen",
         "visible":true,
         "position":1,
         "buttons":[
            {
               "text":"Order a selection",
               "url":"",
               "theme":"orange-gradient",
               "config":{
                  "scouting":{
                     "link":"/view?action=2&type=13&name=New_scouting"
                  }
               }
            }
         ],
         "imageUrl":"/file/scoutingBanner.png",
         "subtitle":"Selection of startups",
         "title":"Order startup scouting",
         "description":"In this section, you can order the service of selecting startups by professional scouts and Sber analysts for your personal request",
         "backgroundColorChip":"#F2F4F6",
         "welcomeScreenTheme":"baseBanner"
      },
      {
         "type":"squareList",
         "visible":true,
         "position":2,
         "title":"Selecting the best for you",
         "theme":"base",
         "isMobileCarousel":false,
         "items":[
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_document_with_star.png",
               "title":"Form a funnel of projects",
               "description":"on specified parameters",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_filter.png",
               "title":"Prepare a long-list and a short-list",
               "description":"with presentation, own initial evaluation and other materials",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_two_persons.png",
               "title":"Organize a pitch session and intro",
               "description":"with favorite projects",
               "isExternal":true
            }
         ]
      },
      {
         "type":"photoGallery",
         "visible":true,
         "position":3,
         "title":"Hold a pitch session online or in a modern co-working space",
         "description":"For more information, to discuss the conditions and your needs, write to us by mail [sberunity@sberbank.ru](mailto:sberunity@sberbank.ru) marked «Scouting» or contact your personal manager",
         "images":[
            "/file/photo_4077.jpg",
            "/file/photo_4078.jpg",
            "/file/photo_4079.jpg"
         ],
         "carouselResponsiveConfig":{
            "sm":{
               "slideGap":40,
               "slidesToShow":1,
               "showArrows":true
            },
            "md":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "lg":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "xl":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            }
         }
      }
   ]
}', 2),
       ('pilot_corporate_az_auth_en', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
  "features": [
    {
      "type": "pilotSearch",
      "menuItems": {
        "all": {
          "action": "/v2/list?type=4&schema=pilots_active",
          "id": 1,
          "name": "Active",
          "sysname": "all"
        },
        "archive": {
          "action": "/v2/list?type=4&schema=pilots_archive&state=20005",
          "id": 2,
          "name": "Archive",
          "sysname": "archive"
        }
      },
      "pilotCreation": {
        "createPilotButton": {
          "label": "Create a pilot",
          "action": "view?action=2&type=4&name=New_Pilot"
        },
        "cancelPilotButton": {
          "label": "Cancel"
        },
        "toast": {
          "successMessage": "Pilot created",
          "errorMessage": "Failed to create pilot"
        }
      },
      "infoBanner": {
        "typeBanner": "successStory",
        "title": "Tell us how SberUnity helped you and get new opportunities!",
        "mainButtonText": "Tell",
        "popupData": {
          "title": "SberUnity is looking for success stories!",
          "description": "If you applied for a pilot through SberUnity and launched it with a corporation, attracted an investor and received an investment tranche from him, or found a business partner, tell us about it.",
          "benefits": {
            "title": "For your success story, SberUnity will give you:",
            "list": [
                "Publication about your success in the telegram channel [SberStartup](https://t.me/sberstartup)",
                "Priority issuance of your startup in the search",
                "Warm intro for any investor or corporation to choose from",
                "Let''s talk about your success to the business media"
            ]
          },
          "radioBoxInfo": {
            "title": "Choose your success story:",
            "list": [
              {
                "name": "Successful pilot",
                "code": "Successful pilot"
              },
              {
                "name": "Attracted investment",
                "code": "Attracted investment"
              },
              {
                "name": "Found partner",
                "code": "Found partner"
              }
            ],
            "input": {
              "placeholder": "Tell us briefly about your successful case",
              "errorMessages": {
                "storyType": "Choose the type of success story",
                "text": "Fill in the field"
              }
            }
          },
          "caption": "Let us know about your success story and the SberUnity administrator will contact you to discuss the details",
          "button": {
            "title": "Share story"
          },
          "toastInfo": {
            "success": "Success story sent",
            "error": "Failed to send success story"
          }
        }
      }
    }
  ]
}', 2),
       ('pilot_investors_az_auth_en', 'SberUnity', '/pilots', 'SberUnity', 'auth', '{
  "features": [
    {
      "type": "pilotSearch",
      "menuItems": {
        "all": {
          "action": "/v2/list?type=4",
          "id": 1,
          "name": "Все пилоты",
          "sysname": "all"
        }
      },
      "corporationBlock": {
        "menuTitle": "Corporations",
        "buttonChooseCorporation": "Choose a corporation"
      },
      "fastFilters": {
        "favoriteLabel": "Favorites",
        "viewedLabel": "Viewed"
      },
      "infoBanner": {
        "typeBanner": "successStory",
        "title": "Tell us how SberUnity helped you and get new opportunities!",
        "mainButtonText": "Tell",
        "popupData": {
          "title": "SberUnity is looking for success stories!",
          "description": "If you applied for a pilot through SberUnity and launched it with a corporation, attracted an investor and received an investment tranche from him, or found a business partner, tell us about it.",
          "benefits": {
            "title": "For your success story, SberUnity will give you:",
            "list": [
                "Publication about your success in the telegram channel [SberStartup](https://t.me/sberstartup)",
                "Priority issuance of your startup in the search",
                "Warm intro for any investor or corporation to choose from",
                "Let''s talk about your success to the business media"
            ]
          },
          "radioBoxInfo": {
            "title": "Choose your success story:",
            "list": [
              {
                "name": "Successful pilot",
                "code": "Successful pilot"
              },
              {
                "name": "Attracted investment",
                "code": "Attracted investment"
              },
              {
                "name": "Found partner",
                "code": "Found partner"
              }
            ],
            "input": {
              "placeholder": "Tell us briefly about your successful case",
              "errorMessages": {
                "storyType": "Choose the type of success story",
                "text": "Fill in the field"
              }
            }
          },
          "caption": "Let us know about your success story and the SberUnity administrator will contact you to discuss the details",
          "button": {
            "title": "Share story"
          },
          "toastInfo": {
            "success": "Success story sent",
            "error": "Failed to send success story"
          }
        }
      }
    }
  ]
}', 2);