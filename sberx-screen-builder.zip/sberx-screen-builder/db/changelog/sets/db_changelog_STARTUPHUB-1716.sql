--liquibase formatted sql
--changeset MOLOTKOV D:STARTUPHUB-1716 Убрать рессурсы с карточки пилота

UPDATE public.screen SET  formedit='{}'::json::json, formview='{
        "form": [{
               "fields": [{
                        "sysName": "businessunit",
                        "localName": "Подразделение",
                        "note": "Потребность какого подразделения компании вы хотите закрыть?",
                        "type": "string",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "suggestCase",
                        "localName": "",
                        "type": "string",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "conditions",
                        "localName": "Условия пилотирования",
                        "type": "string",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "industry",
                        "localName": "",
                        "type": "array",
                        "format": "chip",
                        "activity": [3000],
                        "edited": false,
                        "required": false,
                        "multySelect": false
                    }
                ]
            }
        ]
    }'::json::json WHERE formname='pilot_SuperClient';

   UPDATE public.screen SET  formedit='{}'::json::json, formview='{
        "form": [{
               "fields": [{
                        "sysName": "businessunit",
                        "localName": "Подразделение",
                        "note": "Потребность какого подразделения компании вы хотите закрыть?",
                        "type": "string",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "suggestCase",
                        "localName": "",
                        "type": "string",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "conditions",
                        "localName": "Условия пилотирования",
                        "type": "string",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "industry",
                        "localName": "",
                        "type": "array",
                        "format": "chip",
                        "activity": [3000],
                        "edited": false,
                        "required": false,
                        "multySelect": false
                    }
                ]
            }
        ]
    }'::json::json WHERE formname='pilot_Client';