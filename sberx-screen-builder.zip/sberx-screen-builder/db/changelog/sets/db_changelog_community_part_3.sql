--liquibase formatted sql
--changeset Mirov AA:community_part_3
create index x1_features_attributes_values on public.feature_attributes_values(id_features);
create index x2_features_attributes_values on public.feature_attributes_values(id_parent);

create index x1_values on public.values(locale);