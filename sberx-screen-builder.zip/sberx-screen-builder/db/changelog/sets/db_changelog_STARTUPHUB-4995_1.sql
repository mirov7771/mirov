--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.pages
set page = '{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "corporates_en_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Main",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Corporations",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "corporates_en_pageTitle",
      "title": "Become a corporation partner",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "corporates_en_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Enter company name",
      "participant": "corporation",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}",
          "popupFooter": {
              "caption": "To view the full startup profile, register or login in to the platform",
              "mainButtonText": "Join",
              "secondButtonText": "Enter"
          }
    }
  ]
}'
where uri = '/corporates'
  and code = 'corporates_nz_unauth_en';