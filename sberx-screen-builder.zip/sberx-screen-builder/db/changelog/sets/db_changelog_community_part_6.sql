--liquibase formatted sql
--changeset Mirov AA:community_part_6
INSERT INTO public.features (id, code, name, status, feature_type, description) VALUES
                                                                                    (233,'INVESTOR_AZ_NOT_CONFIRMED_APP_cMainHeader_1', 'Заголовок, главный','published','mainHeader',DEFAULT),
                                                                                    (234,'INVESTOR_AZ_NOT_CONFIRMED_APPcMainHeader_1_button_1', 'Кнопка баннера Заголовка','published','button',DEFAULT),
                                                                                    (235,'INVESTOR_AZ_NOT_CONFIRMED_APPcMainHeader_1_bigNSmallGallery_1', 'Кнопка баннера Заголовка','published','bigNSmallGallery',DEFAULT),
                                                                                    (236,'INVESTOR_AZ_NOT_CONFIRMED_APPcMainTabs_1', 'Главные табы','disabled','mainTabs',DEFAULT),
                                                                                    (237,'INVESTOR_AZ_NOT_CONFIRMED_APPсSquareList_startup_1', 'Что вам будет доступно (плитки)','published','squareList',DEFAULT),
                                                                                    (238,'INVESTOR_AZ_NOT_CONFIRMED_APPcFlatTabs_startup_1', 'Плоские табы','disabled','flatTabs',DEFAULT),
                                                                                    (239,'INVESTOR_AZ_NOT_CONFIRMED_APPсRoadMap_startup_1', 'Роадмап "Новым участникам"','disabled','roadMap',DEFAULT),
                                                                                    (240,'INVESTOR_AZ_NOT_CONFIRMED_APPсRoadMap_startup_2', 'Роадмап "Участникам SberUnity"','published','roadMap',DEFAULT),
                                                                                    (241,'INVESTOR_AZ_NOT_CONFIRMED_APPcNearby_startup_1', 'Мы рядом','published','nearby',DEFAULT),
                                                                                    (242,'INVESTOR_AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_1', 'Баннер. Онлайн','published','banner',DEFAULT),
                                                                                    (243,'INVESTOR_AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_2', 'Баннер. Оффлайн','published','banner',DEFAULT),
                                                                                    (244,'INVESTOR_AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_3', 'Баннер. Сообщество СберСтартап','published','banner',DEFAULT),
                                                                                    (245,'INVESTOR_AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_3_button_1', 'Кнопка виджета "Мы рядом"','published','button',DEFAULT),
                                                                                    (246,'INVESTOR_AZ_NOT_CONFIRMED_APPcBulletBanner_investor_1', 'Баннер с буллитами. Соинвестируйте с профессионалами рынка','published','bulletBanner',DEFAULT),
                                                                                    (247,'INVESTOR_AZ_NOT_CONFIRMED_APPcRectangTiles_investor_1', 'Прямоугольные плитки. Уже в сообществе','published','rectangTiles',DEFAULT),
                                                                                    (248,'INVESTOR_AZ_NOT_CONFIRMED_APPcSquareRow_investor_1', 'Квадратные плитки. Большая воронка стартапов на российском рынке','published','squareRow',DEFAULT),
                                                                                    (249,'INVESTOR_AZ_NOT_CONFIRMED_APPcRectangTiles_investor_2', 'Прямоугольные плитки. Наши акселераторы','published','rectangTiles',DEFAULT),
                                                                                    (250,'INVESTOR_AZ_NOT_CONFIRMED_APPcBulletBanner_investor_2', 'Баннер с буллитами. Всё, что нужно — уже под рукой','published','bulletBanner',DEFAULT),
                                                                                    (251,'INVESTOR_AZ_NOT_CONFIRMED_APPcCarousel_1', 'Карусель изображений','published','carousel',DEFAULT),
                                                                                    (252,'INVESTOR_AZ_NOT_CONFIRMED_APPcEvents_1', 'Календарь событий','published','events',DEFAULT),
                                                                                    (253,'INVESTOR_AZ_NOT_CONFIRMED_APPcOffsetSquares_1', 'Плитки со смещением','published','offsetSquares',DEFAULT),
                                                                                    (254,'INVESTOR_AZ_NOT_CONFIRMED_APPcEvents_1_button_1', 'Кнопка календаря событий','published','button',DEFAULT),
                                                                                    (255,'INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1', 'Плитки социальных сетей','published','socialTiles',DEFAULT),
                                                                                    (256,'INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_1', 'Кнопка плитки Telegram','published','button',DEFAULT),
                                                                                    (257,'INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_2', 'Кнопка плитки подкаста','published','button',DEFAULT),
                                                                                    (258,'INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_3', 'Кнопка плитки блога','published','button',DEFAULT),
                                                                                    (259,'INVESTOR_AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_4', 'Кнопка плитки Youtube-шоу','published','button',DEFAULT),
                                                                                    (260,'INVESTOR_AZ_NOT_CONFIRMED_APPcFooterBanner_1', 'Баннер футера','published','banner',DEFAULT),
                                                                                    (261,'INVESTOR_AZ_NOT_CONFIRMED_APPcFooterBanner_1_button_1', 'Кнопка баннера футера','published','button',DEFAULT),
                                                                                    (262,'INVESTOR_AZ_CONFIRMED_cMainHeader_1', 'Заголовок, главный','published','mainHeader',DEFAULT),
                                                                                    (263,'INVESTOR_AZ_CONFIRMED_cMainHeader_1_button_1', 'Кнопка баннера Заголовка','published','button',DEFAULT),
                                                                                    (264,'INVESTOR_AZ_CONFIRMED_cMainHeader_1_bigNSmallGallery_1', 'Кнопка баннера Заголовка','published','bigNSmallGallery',DEFAULT),
                                                                                    (265,'INVESTOR_AZ_CONFIRMED_cMainTabs_1', 'Главные табы','disabled','mainTabs',DEFAULT),
                                                                                    (266,'INVESTOR_AZ_CONFIRMED_сSquareList_startup_1', 'Что вам будет доступно (плитки)','published','squareList',DEFAULT),
                                                                                    (267,'INVESTOR_AZ_CONFIRMED_cFlatTabs_startup_1', 'Плоские табы','disabled','flatTabs',DEFAULT),
                                                                                    (268,'INVESTOR_AZ_CONFIRMED_сRoadMap_startup_1', 'Роадмап "Новым участникам"','disabled','roadMap',DEFAULT),
                                                                                    (269,'INVESTOR_AZ_CONFIRMED_сRoadMap_startup_2', 'Роадмап "Участникам SberUnity"','disabled','roadMap',DEFAULT),
                                                                                    (270,'INVESTOR_AZ_CONFIRMED_cNearby_startup_1', 'Мы рядом','published','nearby',DEFAULT),
                                                                                    (271,'INVESTOR_AZ_CONFIRMED_cNearbyBanner_startup_1', 'Баннер. Онлайн','published','banner',DEFAULT),
                                                                                    (272,'INVESTOR_AZ_CONFIRMED_cNearbyBanner_startup_2', 'Баннер. Оффлайн','published','banner',DEFAULT),
                                                                                    (273,'INVESTOR_AZ_CONFIRMED_cNearbyBanner_startup_3', 'Баннер. Сообщество СберСтартап','published','banner',DEFAULT),
                                                                                    (274,'INVESTOR_AZ_CONFIRMED_cNearbyBanner_startup_3_button_1', 'Кнопка виджета "Мы рядом"','published','button',DEFAULT),
                                                                                    (275,'INVESTOR_AZ_CONFIRMED_cBulletBanner_investor_1', 'Баннер с буллитами. Соинвестируйте с профессионалами рынка','published','bulletBanner',DEFAULT),
                                                                                    (276,'INVESTOR_AZ_CONFIRMED_cRectangTiles_investor_1', 'Прямоугольные плитки. Уже в сообществе','published','rectangTiles',DEFAULT),
                                                                                    (277,'INVESTOR_AZ_CONFIRMED_cSquareRow_investor_1', 'Квадратные плитки. Большая воронка стартапов на российском рынке','published','squareRow',DEFAULT),
                                                                                    (278,'INVESTOR_AZ_CONFIRMED_cRectangTiles_investor_2', 'Прямоугольные плитки. Наши акселераторы','published','rectangTiles',DEFAULT),
                                                                                    (279,'INVESTOR_AZ_CONFIRMED_cBulletBanner_investor_2', 'Баннер с буллитами. Всё, что нужно — уже под рукой','published','bulletBanner',DEFAULT),
                                                                                    (280,'INVESTOR_AZ_CONFIRMED_cCarousel_1', 'Карусель изображений','published','carousel',DEFAULT),
                                                                                    (281,'INVESTOR_AZ_CONFIRMED_cEvents_1', 'Календарь событий','published','events',DEFAULT),
                                                                                    (282,'INVESTOR_AZ_CONFIRMED_cOffsetSquares_1', 'Плитки со смещением','published','offsetSquares',DEFAULT),
                                                                                    (283,'INVESTOR_AZ_CONFIRMED_cEvents_1_button_1', 'Кнопка календаря событий','published','button',DEFAULT),
                                                                                    (284,'INVESTOR_AZ_CONFIRMED_cSocialTiles_1', 'Плитки социальных сетей','published','socialTiles',DEFAULT),
                                                                                    (285,'INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_1', 'Кнопка плитки Telegram','published','button',DEFAULT),
                                                                                    (286,'INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_2', 'Кнопка плитки подкаста','published','button',DEFAULT),
                                                                                    (287,'INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_3', 'Кнопка плитки блога','published','button',DEFAULT),
                                                                                    (288,'INVESTOR_AZ_CONFIRMED_cSocialTiles_1_button_4', 'Кнопка плитки Youtube-шоу','published','button',DEFAULT),
                                                                                    (289,'INVESTOR_AZ_CONFIRMED_cFooterBanner_1', 'Баннер футера','disabled','banner',DEFAULT),
                                                                                    (290,'INVESTOR_AZ_CONFIRMED_cFooterBanner_1_button_1', 'Кнопка баннера футера','published','button',DEFAULT);


update public.pages
set  code='community_az_confrimed_app_startup'
where id = 7;
update public.pages
set  code='community_az_not_confrimed_app_startup'
where id = 8;

INSERT INTO public.pages (id, code, name, uri, description, page_type) VALUES
                                                                           (9,'community_az_confrimed_app_investor','Авторизованная зона. СберСтартап. Сообщество. Заявка подтверждена','/community','Вы уже в сообществе','auth'),
                                                                           (10,'community_az_not_confrimed_app_investor','Авторизованная зона. СберСтартап. Сообщество. Заявка не подтверждена','/community','Вы уже в сообществе','auth');


INSERT INTO public.pages_features (id_features, id_pages, is_visible, id_parent_feature) VALUES
                                                                                             (233,10,TRUE, DEFAULT),
                                                                                             (234,10,TRUE,233),
                                                                                             (235,10,TRUE,233),
                                                                                             (236,10,TRUE, DEFAULT),
                                                                                             (237,10,TRUE,236),
                                                                                             (238,10,TRUE,236),
                                                                                             (239,10,TRUE,238),
                                                                                             (240,10,TRUE,238),
                                                                                             (241,10,TRUE,236),
                                                                                             (242,10,TRUE,241),
                                                                                             (243,10,TRUE,241),
                                                                                             (244,10,TRUE,241),
                                                                                             (245,10,TRUE,244),
                                                                                             (246,10,TRUE,DEFAULT),
                                                                                             (247,10,TRUE,DEFAULT),
                                                                                             (248,10,TRUE,DEFAULT),
                                                                                             (249,10,TRUE,DEFAULT),
                                                                                             (250,10,TRUE,DEFAULT),
                                                                                             (251,10,TRUE, DEFAULT),
                                                                                             (252,10,TRUE, DEFAULT),
                                                                                             (253,10,TRUE,252),
                                                                                             (254,10,TRUE,252),
                                                                                             (255,10,TRUE, DEFAULT),
                                                                                             (256,10,TRUE,255),
                                                                                             (257,10,TRUE,255),
                                                                                             (258,10,TRUE,255),
                                                                                             (259,10,TRUE,255),
                                                                                             (260,10,TRUE, DEFAULT),
                                                                                             (261,10,TRUE,260),
                                                                                             (262,9,TRUE, DEFAULT),
                                                                                             (263,9,TRUE,262),
                                                                                             (264,9,TRUE,262),
                                                                                             (265,9,TRUE, DEFAULT),
                                                                                             (266,9,TRUE,265),
                                                                                             (267,9,TRUE,265),
                                                                                             (268,9,TRUE,267),
                                                                                             (269,9,TRUE,267),
                                                                                             (270,9,TRUE,265),
                                                                                             (271,9,TRUE,270),
                                                                                             (272,9,TRUE,270),
                                                                                             (273,9,TRUE,270),
                                                                                             (274,9,TRUE,273),
                                                                                             (275,9,TRUE,DEFAULT),
                                                                                             (276,9,TRUE,DEFAULT),
                                                                                             (277,9,TRUE,DEFAULT),
                                                                                             (278,9,TRUE,DEFAULT),
                                                                                             (279,9,TRUE,DEFAULT),
                                                                                             (280,9,TRUE, DEFAULT),
                                                                                             (281,9,TRUE, DEFAULT),
                                                                                             (282,9,TRUE,281),
                                                                                             (283,9,TRUE,281),
                                                                                             (284,9,TRUE, DEFAULT),
                                                                                             (285,9,TRUE,284),
                                                                                             (286,9,TRUE,284),
                                                                                             (287,9,TRUE,284),
                                                                                             (288,9,TRUE,284),
                                                                                             (289,9,TRUE, DEFAULT),
                                                                                             (290,9,TRUE,289);


------------------------------------------------------


insert into public.values (id, value, locale) values
                                                  (3000, 'true', 'ru'),
                                                  (3001, '1', 'ru'),
                                                  (3002, 'СберСтартап', 'ru'),
                                                  (3003, 'сообщество', 'ru'),
                                                  (3004, 'Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач', 'ru'),
                                                  (3005, 'simple', 'ru'),
                                                  (3006, 'true', 'ru'),
                                                  (3007, 'inactive', 'ru'),
                                                  (3008, 'Заявка уже отправлена', 'ru'),
                                                  (3009, NULL, 'ru'),
                                                  (3010, 'popup', 'ru'),
                                                  (3011, 'true', 'ru'),
                                                  (3012, '/file/welcome_headerImg_1.png', 'ru'),
                                                  (3013, 'true', 'ru'),
                                                  (3014, '/file/welcome_headerImg_2.png', 'ru'),
                                                  (3015, 'false', 'ru'),
                                                  (3016, 'true', 'ru'),
                                                  (3017, '2', 'ru'),
                                                  (3018, 'Стартапам', 'ru'),
                                                  (3019, 'true', 'ru'),
                                                  (3020, 'true', 'ru'),
                                                  (3021, 'true', 'ru'),
                                                  (3022, '/file/participants_ic-startups.svg', 'ru'),
                                                  (3023, 'Что вам **будет доступно**', 'ru'),
                                                  (3024, 'Нетворкинг', 'ru'),
                                                  (3025, 'Живое общение с близкими по интересам людьми для решения ваших бизнес-задач', 'ru'),
                                                  (3026, '/file/ic_96_bubbles.svg', 'ru'),
                                                  (3027, 'Экспертиза', 'ru'),
                                                  (3028, 'Консультации от профессиональных трекеров и опытных менторов', 'ru'),
                                                  (3029, '/file/ic_96_person_document.svg', 'ru'),
                                                  (3030, 'Контент', 'ru'),
                                                  (3031, 'Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка', 'ru'),
                                                  (3032, '/file/ic_96_media.svg', 'ru'),
                                                  (3033, 'Мероприятия', 'ru'),
                                                  (3034, 'Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны', 'ru'),
                                                  (3035, '/file/ic_96_calendar_mic.svg', 'ru'),
                                                  (3036, 'Закрытый стартап-клуб', 'ru'),
                                                  (3037, 'Эксклюзивные мероприятия с инвесторами', 'ru'),
                                                  (3038, '/file/ic_96_invite_letter.svg', 'ru'),
                                                  (3039, 'Поддержка', 'ru'),
                                                  (3040, 'Обмен опытом и помощь в решении бизнес-кейсов', 'ru'),
                                                  (3041, '/file/ic_96_question_notebook.svg', 'ru'),
                                                  (3042, '1', 'ru'),
                                                  (3043, 'Как попасть в сообщество СберСтартап', 'ru'),
                                                  (3044, 'true', 'ru'),
                                                  (3045, 'Новым участникам', 'ru'),
                                                  (3046, 'true', 'ru'),
                                                  (3047, '1', 'ru'),
                                                  (3048, 'true', 'ru'),
                                                  (3049, '1', 'ru'),
                                                  (3050, '[Зарегистрируйтесь](/participant-registration){:target="_blank"} на платформе', 'ru'),
                                                  (3051, 'Станьте резидентом SberUnity, чтобы присоединиться к сообществу', 'ru'),
                                                  (3052, NULL, 'ru'),
                                                  (3053, '[Заполните анкету сообщества]()', 'ru'),
                                                  (3054, 'Она находится в личном кабинете в разделе «Сообщество»', 'ru'),
                                                  (3055, NULL, 'ru'),
                                                  (3056, 'Дождитесь результата', 'ru'),
                                                  (3057, 'В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью', 'ru'),
                                                  (3058, NULL, 'ru'),
                                                  (3059, 'Присоединитесь к нам', 'ru'),
                                                  (3060, 'После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами', 'ru'),
                                                  (3061, NULL, 'ru'),
                                                  (3062, 'Участникам SberUnity', 'ru'),
                                                  (3063, 'false', 'ru'),
                                                  (3064, '2', 'ru'),
                                                  (3065, 'true', 'ru'),
                                                  (3066, '1', 'ru'),
                                                  (3067, 'Заполните анкету сообщества', 'ru'),
                                                  (3068, 'Она находится в личном кабинете в разделе «Сообщество»', 'ru'),
                                                  (3069, NULL, 'ru'),
                                                  (3070, 'Дождитесь результата', 'ru'),
                                                  (3071, 'В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью', 'ru'),
                                                  (3072, NULL, 'ru'),
                                                  (3073, 'Присоединитесь к нам', 'ru'),
                                                  (3074, 'После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами', 'ru'),
                                                  (3075, NULL, 'ru'),
                                                  (3076, '1', 'ru'),
                                                  (3077, 'Мы **рядом** с вами', 'ru'),
                                                  (3078, 'true', 'ru'),
                                                  (3079, 'Онлайн', 'ru'),
                                                  (3080, 'true', 'ru'),
                                                  (3081, 'На платформе Telegram и онлайн-событиях', 'ru'),
                                                  (3082, '/file/community_banner_il_online.png', 'ru'),
                                                  (3083, '1', 'ru'),
                                                  (3084, '1', 'ru'),
                                                  (3085, 'Оффлайн', 'ru'),
                                                  (3086, 'true', 'ru'),
                                                  (3087, 'В собственном коворкинге и на закрытых встречах', 'ru'),
                                                  (3088, '/file/community_banner_il_offline.png', 'ru'),
                                                  (3089, '2', 'ru'),
                                                  (3090, '1', 'ru'),
                                                  (3091, 'Сообщество СберСтартап', 'ru'),
                                                  (3092, 'true', 'ru'),
                                                  (3093, 'Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!', 'ru'),
                                                  (3094, '/file/community-banner.png', 'ru'),
                                                  (3095, 'simple', 'ru'),
                                                  (3096, 'active', 'ru'),
                                                  (3097, 'Стать частью сообщества', 'ru'),
                                                  (3098, NULL, 'ru'),
                                                  (3099, NULL, 'ru'),
                                                  (3100, '1', 'ru'),
                                                  (3101, '2', 'ru'),
                                                  (3102, '1', 'ru'),
                                                  (3103, '2', 'ru'),
                                                  (3104, '2', 'ru'),
                                                  (3105, '1', 'ru'),
                                                  (3106, '3', 'ru'),
                                                  (3107, '1', 'ru'),
                                                  (3108, 'true', 'ru'),
                                                  (3109, 'false', 'ru'),
                                                  (3110, 'true', 'ru'),
                                                  (3111, '/file/participants_ic-investors.svg', 'ru'),
                                                  (3112, 'true', 'ru'),
                                                  (3113, '**Соинвестируйте** с профессионалами', 'ru'),
                                                  (3114, 'Снижайте риски, соинвестируя с лучшими венчурными фондами_|_Обеспечьте себе поток лучших сделок_|_Расширьте портфель за счёт низкого входного чека_|_Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки', 'ru'),
                                                  (3115, 'left', 'ru'),
                                                  (3116, '2', 'ru'),
                                                  (3117, 'true', 'ru'),
                                                  (3118, 'Уже в сообществе', 'ru'),
                                                  (3119, '/file/rectang_tiles_logo1.png_|_/file/rectang_tiles_logo2.png_|_/file/rectang_tiles_logo3.png_|_/file/rectang_tiles_logo4.png', 'ru'),
                                                  (3120, '3', 'ru'),
                                                  (3121, 'true', 'ru'),
                                                  (3122, 'Большая **воронка стартапов** на российском рынке', 'ru'),
                                                  (3123, 'Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity', 'ru'),
                                                  (3124, 'Знакомим', 'ru'),
                                                  (3125, 'с основателями стартапов', 'ru'),
                                                  (3126, '/file/squareRow_1.svg', 'ru'),
                                                  (3127, 'Проводим', 'ru'),
                                                  (3128, 'предварительный скоринг', 'ru'),
                                                  (3129, '/file/squareRow_2.svg', 'ru'),
                                                  (3130, 'Рекомендуем', 'ru'),
                                                  (3131, 'только отобранные проекты', 'ru'),
                                                  (3132, '/file/squareRow_3.svg', 'ru'),
                                                  (3133, 'Объединяем', 'ru'),
                                                  (3134, 'инвесторов и стартапы', 'ru'),
                                                  (3135, '/file/squareRow_4.svg', 'ru'),
                                                  (3136, '4', 'ru'),
                                                  (3137, 'true', 'ru'),
                                                  (3138, 'Наши акселераторы', 'ru'),
                                                  (3139, '/file/logo_1_accelerator.png_|_/file/logo_2_accelerator.png_|_/file/logo_3_accelerator.png_|_/file/logo_4_accelerator.png', 'ru'),
                                                  (3140, '5', 'ru'),
                                                  (3141, 'true', 'ru'),
                                                  (3142, '**Всё, что нужно —** уже под рукой', 'ru'),
                                                  (3143, 'Мы организовали сообщество в Slack-каналах', 'ru'),
                                                  (3144, 'Разделите деловые и личный мессенджеры_|_Структурируйте инофрмацию в тематических каналах_|_Только релевантные сообщения, без спама и рекламы_|_Полная информация о сделке всегда доступна', 'ru'),
                                                  (3145, 'left', 'ru'),
                                                  (3146, '6', 'ru'),
                                                  (3147, '2', 'ru'),
                                                  (3148, 'Корпорациям', 'ru'),
                                                  (3149, 'true', 'ru'),
                                                  (3150, 'false', 'ru'),
                                                  (3151, 'false', 'ru'),
                                                  (3152, 'Скоро', 'ru'),
                                                  (3153, NULL, 'ru'),
                                                  (3154, '3', 'ru'),
                                                  (3155, 'true', 'ru'),
                                                  (3156, '7', 'ru'),
                                                  (3157, '**Направления** сообщества', 'ru'),
                                                  (3158, 'Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем Вас стать частью проектов сообщества', 'ru'),
                                                  (3159, '/file/carousel_slide_1.jpeg_|_/file/carousel_slide_2.jpeg_|_/file/carousel_slide_3.jpeg', 'ru'),
                                                  (3160, 'false', 'ru'),
                                                  (3161, '3', 'ru'),
                                                  (3162, '1000', 'ru'),
                                                  (3163, 'left', 'ru'),
                                                  (3164, 'true', 'ru'),
                                                  (3165, 'Событийная кухня', 'ru'),
                                                  (3166, 'Закрывайте бизнес-потребности через нетворкинг', 'ru'),
                                                  (3167, 'С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для Вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.', 'ru'),
                                                  (3168, '8', 'ru'),
                                                  (3169, 'true', 'ru'),
                                                  (3170, 'Партнерские мероприятия', 'ru'),
                                                  (3171, '/file/meetings.png', 'ru'),
                                                  (3172, '1', 'ru'),
                                                  (3173, '1', 'ru'),
                                                  (3174, 'Хакатоны и интенсивы', 'ru'),
                                                  (3175, '/file/hakatons.png', 'ru'),
                                                  (3176, '1', 'ru'),
                                                  (3177, '2', 'ru'),
                                                  (3178, 'Мероприятия с другими фондами и сообществами', 'ru'),
                                                  (3179, '/file/another_funds.png', 'ru'),
                                                  (3180, '2', 'ru'),
                                                  (3181, '1', 'ru'),
                                                  (3182, 'Выезды и вечеринки', 'ru'),
                                                  (3183, '/file/party.png', 'ru'),
                                                  (3184, '2', 'ru'),
                                                  (3185, '2', 'ru'),
                                                  (3186, 'Закрытые очные встречи', 'ru'),
                                                  (3187, '/file/close-meeting.png', 'ru'),
                                                  (3188, '3', 'ru'),
                                                  (3189, '1', 'ru'),
                                                  (3190, 'Онлайн-митапы', 'ru'),
                                                  (3191, '/file/onlline-meetings.png', 'ru'),
                                                  (3192, '3', 'ru'),
                                                  (3193, '2', 'ru'),
                                                  (3194, '1', 'ru'),
                                                  (3195, '2', 'ru'),
                                                  (3196, '2', 'ru'),
                                                  (3197, '2', 'ru'),
                                                  (3198, 'right', 'ru'),
                                                  (3199, '3', 'ru'),
                                                  (3200, '2', 'ru'),
                                                  (3201, 'simple', 'ru'),
                                                  (3202, 'true', 'ru'),
                                                  (3203, 'active', 'ru'),
                                                  (3204, 'Календарь событий', 'ru'),
                                                  (3205, '/file/calendar.svg', 'ru'),
                                                  (3206, 'http://sber.me/?p=k3w6h', 'ru'),
                                                  (3207, 'redirect', 'ru'),
                                                  (3208, 'Контент-студия', 'ru'),
                                                  (3209, 'true', 'ru'),
                                                  (3210, 'Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера', 'ru'),
                                                  (3211, 'Сберстартап', 'ru'),
                                                  (3212, 'Telegram-канал', 'ru'),
                                                  (3213, '/file/content_studio_tg_chanel.jpeg', 'ru'),
                                                  (3214, 'Советы экспертов, новости венчурной индустрии, анонсы событий', 'ru'),
                                                  (3215, 'simple', 'ru'),
                                                  (3216, 'active', 'ru'),
                                                  (3217, 'Подписаться', 'ru'),
                                                  (3218, NULL, 'ru'),
                                                  (3219, 'http://sber.me/?p=m6f1b', 'ru'),
                                                  (3220, 'redirect', 'ru'),
                                                  (3221, 'Три запятые', 'ru'),
                                                  (3222, 'Подкаст', 'ru'),
                                                  (3223, '/file/content_studio_podcast.jpeg', 'ru'),
                                                  (3224, 'Разговоры о том, как изменить мир и заработать заветный миллиард', 'ru'),
                                                  (3225, 'simple', 'ru'),
                                                  (3226, 'active', 'ru'),
                                                  (3227, 'Подписаться', 'ru'),
                                                  (3228, 'http://sber.me/?p=1V5r1', 'ru'),
                                                  (3229, 'redirect', 'ru'),
                                                  (3230, 'VC.RU', 'ru'),
                                                  (3231, 'Блог', 'ru'),
                                                  (3232, '/file/content_studio_blog.jpeg', 'ru'),
                                                  (3233, 'Успешные и не очень кейсы участников сообщества', 'ru'),
                                                  (3234, 'simple', 'ru'),
                                                  (3235, 'active', 'ru'),
                                                  (3236, 'Подписаться', 'ru'),
                                                  (3237, 'http://sber.me/?p=ZpLRc', 'ru'),
                                                  (3238, 'redirect', 'ru'),
                                                  (3239, 'Для стартапов', 'ru'),
                                                  (3240, 'YouTube-шоу', 'ru'),
                                                  (3241, '/file/content_studio_yb_show.jpeg', 'ru'),
                                                  (3242, 'Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями', 'ru'),
                                                  (3243, 'simple', 'ru'),
                                                  (3244, 'inactive', 'ru'),
                                                  (3245, 'Скоро', 'ru'),
                                                  (3246, '/file/content_studio_clock.svg', 'ru'),
                                                  (3247, 'redirect', 'ru'),
                                                  (3248, '9', 'ru'),
                                                  (3249, 'true', 'ru'),
                                                  (3250, 'Подайте заявку и станьте частью сообщества СберСтартап', 'ru'),
                                                  (3251, '/file/banner_banner.png', 'ru'),
                                                  (3252, '10', 'ru'),
                                                  (3253, 'simple', 'ru'),
                                                  (3254, 'inactive', 'ru'),
                                                  (3255, 'Заявка уже отправлена', 'ru'),
                                                  (3256, NULL, 'ru'),
                                                  (3257, 'popup', 'ru'),
                                                  (3258, null, 'ru'),
                                                  (3259, null, 'ru'),
                                                  (3260, null, 'ru'),
                                                  (3261, null, 'ru'),
                                                  (3262, null, 'ru'),
                                                  (3263, null, 'ru'),
                                                  (3264, null, 'ru'),
                                                  (3265, null, 'ru'),
                                                  (3266, null, 'ru'),
                                                  (3267, null, 'ru'),
                                                  (3268, null, 'ru'),
                                                  (3269, null, 'ru'),
                                                  (3270, null, 'ru'),
                                                  (3271, null, 'ru'),
                                                  (3272, null, 'ru'),
                                                  (3273, null, 'ru'),
                                                  (3274, null, 'ru'),
                                                  (3275, null, 'ru'),
                                                  (3276, null, 'ru'),
                                                  (3277, null, 'ru'),
                                                  (3278, null, 'ru'),
                                                  (3279, null, 'ru'),
                                                  (3280, null, 'ru'),
                                                  (3281, null, 'ru'),
                                                  (3282, null, 'ru'),
                                                  (3283, null, 'ru'),
                                                  (3284, null, 'ru'),
                                                  (3285, null, 'ru'),
                                                  (3286, 'Инвесторам', 'ru'),
                                                  (3287, null, 'ru'),
                                                  (3288, null, 'ru'),
                                                  (3289, null, 'ru'),
                                                  (3290, null, 'ru'),
                                                  (3291, null, 'ru'),
                                                  (3292, null, 'ru'),
                                                  (3293, null, 'ru'),
                                                  (3294, null, 'ru'),
                                                  (3295, null, 'ru'),
                                                  (3296, null, 'ru'),
                                                  (3297, null, 'ru'),
                                                  (3298, null, 'ru'),
                                                  (3299, null, 'ru'),
                                                  (3300, null, 'ru'),
                                                  (3301, null, 'ru'),
                                                  (3302, null, 'ru'),
                                                  (3303, null, 'ru'),
                                                  (3304, null, 'ru'),
                                                  (3305, null, 'ru'),
                                                  (3306, null, 'ru'),
                                                  (3307, null, 'ru'),
                                                  (3308, null, 'ru'),
                                                  (3309, null, 'ru'),
                                                  (3310, null, 'ru'),
                                                  (3311, null, 'ru'),
                                                  (3312, null, 'ru'),
                                                  (3313, null, 'ru'),
                                                  (3314, null, 'ru'),
                                                  (3315, null, 'ru'),
                                                  (3316, 'true', 'ru'),
                                                  (3317, null, 'ru'),
                                                  (3318, null, 'ru'),
                                                  (3319, null, 'ru'),
                                                  (3320, 'true', 'ru'),
                                                  (3321, null, 'ru'),
                                                  (3322, null, 'ru'),
                                                  (3323, null, 'ru'),
                                                  (3324, 'true', 'ru'),
                                                  (3325, null, 'ru'),
                                                  (3326, null, 'ru'),
                                                  (3327, null, 'ru'),
                                                  (3328, null, 'ru'),
                                                  (3329, null, 'ru'),
                                                  (3330, null, 'ru'),
                                                  (3331, 'true', 'ru'),
                                                  (3332, null, 'ru'),
                                                  (3333, null, 'ru'),
                                                  (3334, null, 'ru'),
                                                  (3335, null, 'ru'),
                                                  (3336, null, 'ru'),
                                                  (3337, null, 'ru'),
                                                  (3338, null, 'ru'),
                                                  (3339, '1', 'ru'),
                                                  (3340, null, 'ru'),
                                                  (3341, 'popup', 'ru'),
                                                  (3342, '3', 'ru'),
                                                  (3343, null, 'ru'),
                                                  (3344, 'true', 'ru'),
                                                  (3345, 'purple-gradient', 'ru'),
                                                  (3346, '1', 'ru'),
                                                  (3347, '2', 'ru'),
                                                  (3348, '3', 'ru'),
                                                  (3349, '4', 'ru'),
                                                  (3350, '1', 'ru'),
                                                  (3351, '2', 'ru'),
                                                  (3352, '3', 'ru'),
                                                  (3353, 'default', 'ru'),
                                                  (3354, 'default', 'ru'),
                                                  (3355, 'purple-gradient', 'ru'),
                                                  (3356, 'default', 'ru'),
                                                  (3357, '#FFFFFF', 'ru'),
                                                  (3358, '/file/bullet-banner-invest.png', 'ru'),
                                                  (3359, '#F4F5F9', 'ru'),
                                                  (3360, '/file/bullet-banner-opportunities.png', 'ru'),
                                                  (3361, 'purple-gradient', 'ru'),
                                                  (3362, 'default', 'ru'),
                                                  (3363, 'default', 'ru'),
                                                  (3364, 'default', 'ru'),
                                                  (3365, 'default', 'ru'),
                                                  (3366, 'purple-gradient', 'ru'),
                                                  (3367, 'default', 'ru'),
                                                  (3368, 'true', 'ru'),
                                                  (3369, '1', 'ru'),
                                                  (3370, 'СберСтартап', 'ru'),
                                                  (3371, 'сообщество', 'ru'),
                                                  (3372, 'Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач', 'ru'),
                                                  (3373, 'simple', 'ru'),
                                                  (3374, 'true', 'ru'),
                                                  (3375, 'inactive', 'ru'),
                                                  (3376, 'Вы уже в сообществе', 'ru'),
                                                  (3377, NULL, 'ru'),
                                                  (3378, 'popup', 'ru'),
                                                  (3379, 'true', 'ru'),
                                                  (3380, '/file/welcome_headerImg_1.png', 'ru'),
                                                  (3381, 'true', 'ru'),
                                                  (3382, '/file/welcome_headerImg_2.png', 'ru'),
                                                  (3383, 'false', 'ru'),
                                                  (3384, 'true', 'ru'),
                                                  (3385, '2', 'ru'),
                                                  (3386, 'Стартапам', 'ru'),
                                                  (3387, 'true', 'ru'),
                                                  (3388, 'true', 'ru'),
                                                  (3389, 'true', 'ru'),
                                                  (3390, '/file/participants_ic-startups.svg', 'ru'),
                                                  (3391, 'Что вам **доступно**', 'ru'),
                                                  (3392, 'Нетворкинг', 'ru'),
                                                  (3393, 'Живое общение с близкими по интересам людьми для решения ваших бизнес-задач', 'ru'),
                                                  (3394, '/file/ic_96_bubbles.svg', 'ru'),
                                                  (3395, 'Экспертиза', 'ru'),
                                                  (3396, 'Консультации от профессиональных трекеров и опытных менторов', 'ru'),
                                                  (3397, '/file/ic_96_person_document.svg', 'ru'),
                                                  (3398, 'Контент', 'ru'),
                                                  (3399, 'Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка', 'ru'),
                                                  (3400, '/file/ic_96_media.svg', 'ru'),
                                                  (3401, 'Мероприятия', 'ru'),
                                                  (3402, 'Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны', 'ru'),
                                                  (3403, '/file/ic_96_calendar_mic.svg', 'ru'),
                                                  (3404, 'Закрытый стартап-клуб', 'ru'),
                                                  (3405, 'Эксклюзивные мероприятия с инвесторами', 'ru'),
                                                  (3406, '/file/ic_96_invite_letter.svg', 'ru'),
                                                  (3407, 'Поддержка', 'ru'),
                                                  (3408, 'Обмен опытом и помощь в решении бизнес-кейсов', 'ru'),
                                                  (3409, '/file/ic_96_question_notebook.svg', 'ru'),
                                                  (3410, '1', 'ru'),
                                                  (3411, 'Как попасть в сообщество СберСтартап', 'ru'),
                                                  (3412, 'true', 'ru'),
                                                  (3413, 'Новым участникам', 'ru'),
                                                  (3414, 'true', 'ru'),
                                                  (3415, '1', 'ru'),
                                                  (3416, 'true', 'ru'),
                                                  (3417, '1', 'ru'),
                                                  (3418, '[Зарегистрируйтесь](/participant-registration){:target="_blank"} на платформе', 'ru'),
                                                  (3419, 'Станьте резидентом SberUnity, чтобы присоединиться к сообществу', 'ru'),
                                                  (3420, NULL, 'ru'),
                                                  (3421, '[Заполните анкету сообщества]()', 'ru'),
                                                  (3422, 'Она находится в личном кабинете в разделе «Сообщество»', 'ru'),
                                                  (3423, NULL, 'ru'),
                                                  (3424, 'Дождитесь результата', 'ru'),
                                                  (3425, 'В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью', 'ru'),
                                                  (3426, NULL, 'ru'),
                                                  (3427, 'Присоединитесь к нам', 'ru'),
                                                  (3428, 'После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами', 'ru'),
                                                  (3429, NULL, 'ru'),
                                                  (3430, 'Участникам SberUnity', 'ru'),
                                                  (3431, 'false', 'ru'),
                                                  (3432, '2', 'ru'),
                                                  (3433, 'true', 'ru'),
                                                  (3434, '1', 'ru'),
                                                  (3435, 'Заполните анкету сообщества', 'ru'),
                                                  (3436, 'Она находится в личном кабинете в разделе «Сообщество»', 'ru'),
                                                  (3437, NULL, 'ru'),
                                                  (3438, 'Дождитесь результата', 'ru'),
                                                  (3439, 'В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью', 'ru'),
                                                  (3440, NULL, 'ru'),
                                                  (3441, 'Присоединитесь к нам', 'ru'),
                                                  (3442, 'После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами', 'ru'),
                                                  (3443, NULL, 'ru'),
                                                  (3444, '1', 'ru'),
                                                  (3445, 'Мы **рядом** с вами', 'ru'),
                                                  (3446, 'true', 'ru'),
                                                  (3447, 'Онлайн', 'ru'),
                                                  (3448, 'true', 'ru'),
                                                  (3449, 'На платформе Telegram и онлайн-событиях', 'ru'),
                                                  (3450, '/file/community_banner_il_online.png', 'ru'),
                                                  (3451, '1', 'ru'),
                                                  (3452, '1', 'ru'),
                                                  (3453, 'Оффлайн', 'ru'),
                                                  (3454, 'true', 'ru'),
                                                  (3455, 'В собственном коворкинге и на закрытых встречах', 'ru'),
                                                  (3456, '/file/community_banner_il_offline.png', 'ru'),
                                                  (3457, '2', 'ru'),
                                                  (3458, '1', 'ru'),
                                                  (3459, 'Сообщество СберСтартап', 'ru'),
                                                  (3460, 'true', 'ru'),
                                                  (3461, 'Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!', 'ru'),
                                                  (3462, '/file/community-banner.png', 'ru'),
                                                  (3463, 'simple', 'ru'),
                                                  (3464, 'active', 'ru'),
                                                  (3465, 'Стать частью сообщества', 'ru'),
                                                  (3466, NULL, 'ru'),
                                                  (3467, NULL, 'ru'),
                                                  (3468, '1', 'ru'),
                                                  (3469, '2', 'ru'),
                                                  (3470, '1', 'ru'),
                                                  (3471, '2', 'ru'),
                                                  (3472, '2', 'ru'),
                                                  (3473, '1', 'ru'),
                                                  (3474, '3', 'ru'),
                                                  (3475, '1', 'ru'),
                                                  (3476, 'true', 'ru'),
                                                  (3477, 'false', 'ru'),
                                                  (3478, 'true', 'ru'),
                                                  (3479, '/file/participants_ic-investors.svg', 'ru'),
                                                  (3480, 'true', 'ru'),
                                                  (3481, '**Соинвестируйте** с профессионалами', 'ru'),
                                                  (3482, 'Снижайте риски, соинвестируя с лучшими венчурными фондами_|_Обеспечьте себе поток лучших сделок_|_Расширьте портфель за счёт низкого входного чека_|_Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки', 'ru'),
                                                  (3483, 'left', 'ru'),
                                                  (3484, '2', 'ru'),
                                                  (3485, 'true', 'ru'),
                                                  (3486, 'Уже в сообществе', 'ru'),
                                                  (3487, '/file/rectang_tiles_logo1.png_|_/file/rectang_tiles_logo2.png_|_/file/rectang_tiles_logo3.png_|_/file/rectang_tiles_logo4.png', 'ru'),
                                                  (3488, '3', 'ru'),
                                                  (3489, 'true', 'ru'),
                                                  (3490, 'Большая **воронка стартапов** на российском рынке', 'ru'),
                                                  (3491, 'Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity', 'ru'),
                                                  (3492, 'Знакомим', 'ru'),
                                                  (3493, 'с основателями стартапов', 'ru'),
                                                  (3494, '/file/squareRow_1.svg', 'ru'),
                                                  (3495, 'Проводим', 'ru'),
                                                  (3496, 'предварительный скоринг', 'ru'),
                                                  (3497, '/file/squareRow_2.svg', 'ru'),
                                                  (3498, 'Рекомендуем', 'ru'),
                                                  (3499, 'только отобранные проекты', 'ru'),
                                                  (3500, '/file/squareRow_3.svg', 'ru'),
                                                  (3501, 'Объединяем', 'ru'),
                                                  (3502, 'инвесторов и стартапы', 'ru'),
                                                  (3503, '/file/squareRow_4.svg', 'ru'),
                                                  (3504, '4', 'ru'),
                                                  (3505, 'true', 'ru'),
                                                  (3506, 'Наши акселераторы', 'ru'),
                                                  (3507, '/file/logo_1_accelerator.png_|_/file/logo_2_accelerator.png_|_/file/logo_3_accelerator.png_|_/file/logo_4_accelerator.png', 'ru'),
                                                  (3508, '5', 'ru'),
                                                  (3509, 'true', 'ru'),
                                                  (3510, '**Всё, что нужно —** уже под рукой', 'ru'),
                                                  (3511, 'Мы организовали сообщество в Slack-каналах', 'ru'),
                                                  (3512, 'Разделите деловые и личный мессенджеры_|_Структурируйте инофрмацию в тематических каналах_|_Только релевантные сообщения, без спама и рекламы_|_Полная информация о сделке всегда доступна', 'ru'),
                                                  (3513, 'left', 'ru'),
                                                  (3514, '6', 'ru'),
                                                  (3515, '2', 'ru'),
                                                  (3516, 'Корпорациям', 'ru'),
                                                  (3517, 'true', 'ru'),
                                                  (3518, 'false', 'ru'),
                                                  (3519, 'false', 'ru'),
                                                  (3520, 'Скоро', 'ru'),
                                                  (3521, NULL, 'ru'),
                                                  (3522, '3', 'ru'),
                                                  (3523, 'true', 'ru'),
                                                  (3524, '7', 'ru'),
                                                  (3525, '**Направления** сообщества', 'ru'),
                                                  (3526, 'Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем Вас стать частью проектов сообщества', 'ru'),
                                                  (3527, '/file/carousel_slide_1.jpeg_|_/file/carousel_slide_2.jpeg_|_/file/carousel_slide_3.jpeg', 'ru'),
                                                  (3528, 'false', 'ru'),
                                                  (3529, '3', 'ru'),
                                                  (3530, '1000', 'ru'),
                                                  (3531, 'left', 'ru'),
                                                  (3532, 'true', 'ru'),
                                                  (3533, 'Событийная кухня', 'ru'),
                                                  (3534, 'Закрывайте бизнес-потребности через нетворкинг', 'ru'),
                                                  (3535, 'С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для Вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.', 'ru'),
                                                  (3536, '8', 'ru'),
                                                  (3537, 'true', 'ru'),
                                                  (3538, 'Партнерские мероприятия', 'ru'),
                                                  (3539, '/file/meetings.png', 'ru'),
                                                  (3540, '1', 'ru'),
                                                  (3541, '1', 'ru'),
                                                  (3542, 'Хакатоны и интенсивы', 'ru'),
                                                  (3543, '/file/hakatons.png', 'ru'),
                                                  (3544, '1', 'ru'),
                                                  (3545, '2', 'ru'),
                                                  (3546, 'Мероприятия с другими фондами и сообществами', 'ru'),
                                                  (3547, '/file/another_funds.png', 'ru'),
                                                  (3548, '2', 'ru'),
                                                  (3549, '1', 'ru'),
                                                  (3550, 'Выезды и вечеринки', 'ru'),
                                                  (3551, '/file/party.png', 'ru'),
                                                  (3552, '2', 'ru'),
                                                  (3553, '2', 'ru'),
                                                  (3554, 'Закрытые очные встречи', 'ru'),
                                                  (3555, '/file/close-meeting.png', 'ru'),
                                                  (3556, '3', 'ru'),
                                                  (3557, '1', 'ru'),
                                                  (3558, 'Онлайн-митапы', 'ru'),
                                                  (3559, '/file/onlline-meetings.png', 'ru'),
                                                  (3560, '3', 'ru'),
                                                  (3561, '2', 'ru'),
                                                  (3562, '1', 'ru'),
                                                  (3563, '2', 'ru'),
                                                  (3564, '2', 'ru'),
                                                  (3565, '2', 'ru'),
                                                  (3566, 'right', 'ru'),
                                                  (3567, '3', 'ru'),
                                                  (3568, '2', 'ru'),
                                                  (3569, 'simple', 'ru'),
                                                  (3570, 'true', 'ru'),
                                                  (3571, 'active', 'ru'),
                                                  (3572, 'Календарь событий', 'ru'),
                                                  (3573, '/file/calendar.svg', 'ru'),
                                                  (3574, 'http://sber.me/?p=k3w6h', 'ru'),
                                                  (3575, 'redirect', 'ru'),
                                                  (3576, 'Контент-студия', 'ru'),
                                                  (3577, 'true', 'ru'),
                                                  (3578, 'Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера', 'ru'),
                                                  (3579, 'Сберстартап', 'ru'),
                                                  (3580, 'Telegram-канал', 'ru'),
                                                  (3581, '/file/content_studio_tg_chanel.jpeg', 'ru'),
                                                  (3582, 'Советы экспертов, новости венчурной индустрии, анонсы событий', 'ru'),
                                                  (3583, 'simple', 'ru'),
                                                  (3584, 'active', 'ru'),
                                                  (3585, 'Подписаться', 'ru'),
                                                  (3586, NULL, 'ru'),
                                                  (3587, 'http://sber.me/?p=m6f1b', 'ru'),
                                                  (3588, 'redirect', 'ru'),
                                                  (3589, 'Три запятые', 'ru'),
                                                  (3590, 'Подкаст', 'ru'),
                                                  (3591, '/file/content_studio_podcast.jpeg', 'ru'),
                                                  (3592, 'Разговоры о том, как изменить мир и заработать заветный миллиард', 'ru'),
                                                  (3593, 'simple', 'ru'),
                                                  (3594, 'active', 'ru'),
                                                  (3595, 'Подписаться', 'ru'),
                                                  (3596, 'http://sber.me/?p=1V5r1', 'ru'),
                                                  (3597, 'redirect', 'ru'),
                                                  (3598, 'VC.RU', 'ru'),
                                                  (3599, 'Блог', 'ru'),
                                                  (3600, '/file/content_studio_blog.jpeg', 'ru'),
                                                  (3601, 'Успешные и не очень кейсы участников сообщества', 'ru'),
                                                  (3602, 'simple', 'ru'),
                                                  (3603, 'active', 'ru'),
                                                  (3604, 'Подписаться', 'ru'),
                                                  (3605, 'http://sber.me/?p=ZpLRc', 'ru'),
                                                  (3606, 'redirect', 'ru'),
                                                  (3607, 'Для стартапов', 'ru'),
                                                  (3608, 'YouTube-шоу', 'ru'),
                                                  (3609, '/file/content_studio_yb_show.jpeg', 'ru'),
                                                  (3610, 'Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями', 'ru'),
                                                  (3611, 'simple', 'ru'),
                                                  (3612, 'inactive', 'ru'),
                                                  (3613, 'Скоро', 'ru'),
                                                  (3614, '/file/content_studio_clock.svg', 'ru'),
                                                  (3615, 'redirect', 'ru'),
                                                  (3616, '9', 'ru'),
                                                  (3617, 'true', 'ru'),
                                                  (3618, 'Подайте заявку и станьте частью сообщества СберСтартап', 'ru'),
                                                  (3619, '/file/banner_banner.png', 'ru'),
                                                  (3620, '10', 'ru'),
                                                  (3621, 'simple', 'ru'),
                                                  (3622, 'active', 'ru'),
                                                  (3623, 'Стать частью сообщества', 'ru'),
                                                  (3624, NULL, 'ru'),
                                                  (3625, 'popup', 'ru'),
                                                  (3626, null, 'ru'),
                                                  (3627, null, 'ru'),
                                                  (3628, null, 'ru'),
                                                  (3629, null, 'ru'),
                                                  (3630, null, 'ru'),
                                                  (3631, null, 'ru'),
                                                  (3632, null, 'ru'),
                                                  (3633, null, 'ru'),
                                                  (3634, null, 'ru'),
                                                  (3635, null, 'ru'),
                                                  (3636, null, 'ru'),
                                                  (3637, null, 'ru'),
                                                  (3638, null, 'ru'),
                                                  (3639, null, 'ru'),
                                                  (3640, null, 'ru'),
                                                  (3641, null, 'ru'),
                                                  (3642, null, 'ru'),
                                                  (3643, null, 'ru'),
                                                  (3644, null, 'ru'),
                                                  (3645, null, 'ru'),
                                                  (3646, null, 'ru'),
                                                  (3647, null, 'ru'),
                                                  (3648, null, 'ru'),
                                                  (3649, null, 'ru'),
                                                  (3650, null, 'ru'),
                                                  (3651, null, 'ru'),
                                                  (3652, null, 'ru'),
                                                  (3653, null, 'ru'),
                                                  (3654, 'Инвесторам', 'ru'),
                                                  (3655, null, 'ru'),
                                                  (3656, null, 'ru'),
                                                  (3657, null, 'ru'),
                                                  (3658, null, 'ru'),
                                                  (3659, null, 'ru'),
                                                  (3660, null, 'ru'),
                                                  (3661, null, 'ru'),
                                                  (3662, null, 'ru'),
                                                  (3663, null, 'ru'),
                                                  (3664, null, 'ru'),
                                                  (3665, null, 'ru'),
                                                  (3666, null, 'ru'),
                                                  (3667, null, 'ru'),
                                                  (3668, null, 'ru'),
                                                  (3669, null, 'ru'),
                                                  (3670, null, 'ru'),
                                                  (3671, null, 'ru'),
                                                  (3672, null, 'ru'),
                                                  (3673, null, 'ru'),
                                                  (3674, null, 'ru'),
                                                  (3675, null, 'ru'),
                                                  (3676, null, 'ru'),
                                                  (3677, null, 'ru'),
                                                  (3678, null, 'ru'),
                                                  (3679, null, 'ru'),
                                                  (3680, null, 'ru'),
                                                  (3681, null, 'ru'),
                                                  (3682, null, 'ru'),
                                                  (3683, null, 'ru'),
                                                  (3684, 'true', 'ru'),
                                                  (3685, null, 'ru'),
                                                  (3686, null, 'ru'),
                                                  (3687, null, 'ru'),
                                                  (3688, 'true', 'ru'),
                                                  (3689, null, 'ru'),
                                                  (3690, null, 'ru'),
                                                  (3691, null, 'ru'),
                                                  (3692, 'true', 'ru'),
                                                  (3693, null, 'ru'),
                                                  (3694, null, 'ru'),
                                                  (3695, null, 'ru'),
                                                  (3696, null, 'ru'),
                                                  (3697, null, 'ru'),
                                                  (3698, null, 'ru'),
                                                  (3699, 'true', 'ru'),
                                                  (3700, null, 'ru'),
                                                  (3701, null, 'ru'),
                                                  (3702, null, 'ru'),
                                                  (3703, null, 'ru'),
                                                  (3704, null, 'ru'),
                                                  (3705, null, 'ru'),
                                                  (3706, null, 'ru'),
                                                  (3707, '1', 'ru'),
                                                  (3708, null, 'ru'),
                                                  (3709, 'popup', 'ru'),
                                                  (3710, '3', 'ru'),
                                                  (3711, null, 'ru'),
                                                  (3712, 'true', 'ru'),
                                                  (3713, 'purple-gradient', 'ru'),
                                                  (3714, '1', 'ru'),
                                                  (3715, '2', 'ru'),
                                                  (3716, '3', 'ru'),
                                                  (3717, '4', 'ru'),
                                                  (3718, '1', 'ru'),
                                                  (3719, '2', 'ru'),
                                                  (3720, '3', 'ru'),
                                                  (3721, 'default', 'ru'),
                                                  (3722, 'default', 'ru'),
                                                  (3723, 'purple-gradient', 'ru'),
                                                  (3724, 'default', 'ru'),
                                                  (3725, '#FFFFFF', 'ru'),
                                                  (3726, '/file/bullet-banner-invest.png', 'ru'),
                                                  (3727, '#F4F5F9', 'ru'),
                                                  (3728, '/file/bullet-banner-opportunities.png', 'ru'),
                                                  (3729, 'purple-gradient', 'ru'),
                                                  (3730, 'default', 'ru'),
                                                  (3731, 'default', 'ru'),
                                                  (3732, 'default', 'ru'),
                                                  (3733, 'default', 'ru'),
                                                  (3734, 'purple-gradient', 'ru'),
                                                  (3735, 'default', 'ru'),
                                                  (3809, 'true', 'ru'),
                                                  (3810, 'true', 'ru'),
                                                  (3811, 'true', 'ru');

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES

                                                                                                                          (3000,1,3000,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3001,2,3001,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3002,21,3002,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3003,22,3003,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3004,23,3004,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3005,31,3264,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3006,24,3005,234,3005,'published',DEFAULT),
                                                                                                                          (3007,1,3006,234,3005,'published',DEFAULT),
                                                                                                                          (3008,10,3007,234,3005,'published',DEFAULT),
                                                                                                                          (3009,25,3008,234,3005,'published',DEFAULT),
                                                                                                                          (3010,26,3333,234,3005,'published',DEFAULT),
                                                                                                                          (3011,27,3009,234,3005,'published',DEFAULT),
                                                                                                                          (3012,11,3010,234,3005,'published',DEFAULT),
                                                                                                                          (3013,4,3260,234,3005,'published',DEFAULT),
                                                                                                                          (3014,1,3011,235,3005,'published',DEFAULT),
                                                                                                                          (3015,33,3334,235,3005,'published',DEFAULT),
                                                                                                                          (3016,27,3012,235,3015,'published',1),
                                                                                                                          (3017,9,3013,235,3015,'published',1),
                                                                                                                          (3018,27,3014,235,3015,'published',2),
                                                                                                                          (3019,9,3015,235,3015,'published',2),
                                                                                                                          (3020,4,3261,235,3005,'published',DEFAULT),
                                                                                                                          (3021,4,3259,233,DEFAULT,'published',DEFAULT),
                                                                                                                          (3022,1,3016,236,DEFAULT,'published',DEFAULT),
                                                                                                                          (3023,2,3017,236,DEFAULT,'published',DEFAULT),
                                                                                                                          (3024,4,3296,236,DEFAULT,'published',DEFAULT),
                                                                                                                          (3025,6,3262,236,DEFAULT,'published',DEFAULT),
                                                                                                                          (3026,22,3018,236,3025,'published',1),
                                                                                                                          (3027,1,3019,236,3025,'published',1),
                                                                                                                          (3028,7,3020,236,3025,'published',1),
                                                                                                                          (3029,8,3021,236,3025,'published',1),
                                                                                                                          (3030,28,3335,236,3025,'published',1),
                                                                                                                          (3031,26,3022,236,3025,'published',1),
                                                                                                                          (3032,2,3042,236,3025,'published',1),
                                                                                                                          (3033,4,3263,236,3025,'published',1),
                                                                                                                          (3034,31,3266,236,3025,'published',1),
                                                                                                                          (3035,22,3023,237,3034,'published',DEFAULT),
                                                                                                                          (3036,6,3265,237,3034,'published',DEFAULT),
                                                                                                                          (3037,22,3024,237,3036,'published',1),
                                                                                                                          (3038,23,3025,237,3036,'published',1),
                                                                                                                          (3039,26,3026,237,3036,'published',1),
                                                                                                                          (3040,22,3027,237,3036,'published',2),
                                                                                                                          (3041,23,3028,237,3036,'published',2),
                                                                                                                          (3042,26,3029,237,3036,'published',2),
                                                                                                                          (3043,22,3030,237,3036,'published',3),
                                                                                                                          (3044,23,3031,237,3036,'published',3),
                                                                                                                          (3045,26,3032,237,3036,'published',3),
                                                                                                                          (3046,22,3033,237,3036,'published',4),
                                                                                                                          (3047,23,3034,237,3036,'published',4),
                                                                                                                          (3048,26,3035,237,3036,'published',4),
                                                                                                                          (3049,22,3036,237,3036,'published',5),
                                                                                                                          (3050,23,3037,237,3036,'published',5),
                                                                                                                          (3051,26,3038,237,3036,'published',5),
                                                                                                                          (3052,22,3039,237,3036,'published',6),
                                                                                                                          (3053,23,3040,237,3036,'published',6),
                                                                                                                          (3054,26,3041,237,3036,'published',6),
                                                                                                                          (3055,2,3339,237,3034,'published',DEFAULT),
                                                                                                                          (3056,4,3340,237,3034,'published',DEFAULT),
                                                                                                                          (3057,21,3043,238,3034,'published',DEFAULT),
                                                                                                                          (3058,1,3044,238,3034,'published',DEFAULT),
                                                                                                                          (3059,6,3267,238,3034,'published',DEFAULT),
                                                                                                                          (3060,22,3045,238,3059,'published',1),
                                                                                                                          (3061,7,3046,238,3059,'published',1),
                                                                                                                          (3062,2,3047,238,3059,'published',1),
                                                                                                                          (3063,31,3268,238,3059,'published',1),
                                                                                                                          (3064,1,3048,239,3063,'published',DEFAULT),
                                                                                                                          (3065,2,3049,239,3063,'published',DEFAULT),
                                                                                                                          (3066,4,3269,239,3063,'published',DEFAULT),
                                                                                                                          (3067,6,3270,239,3063,'published',DEFAULT),
                                                                                                                          (3068,22,3050,239,3067,'published',1),
                                                                                                                          (3069,23,3051,239,3067,'published',1),
                                                                                                                          (3070,26,3052,239,3067,'published',1),
                                                                                                                          (3071,22,3053,239,3067,'published',2),
                                                                                                                          (3072,23,3054,239,3067,'published',2),
                                                                                                                          (3073,26,3055,239,3067,'published',2),
                                                                                                                          (3074,22,3056,239,3067,'published',3),
                                                                                                                          (3075,23,3057,239,3067,'published',3),
                                                                                                                          (3076,26,3058,239,3067,'published',3),
                                                                                                                          (3077,22,3059,239,3067,'published',4),
                                                                                                                          (3078,23,3060,239,3067,'published',4),
                                                                                                                          (3079,26,3061,239,3067,'published',4),
                                                                                                                          (3080,22,3062,238,3059,'published',2),
                                                                                                                          (3081,7,3063,238,3059,'published',2),
                                                                                                                          (3082,2,3064,238,3059,'published',2),
                                                                                                                          (3083,31,3271,238,3059,'published',2),
                                                                                                                          (3084,1,3065,240,3083,'published',DEFAULT),
                                                                                                                          (3085,2,3066,240,3083,'published',DEFAULT),
                                                                                                                          (3086,4,3272,240,3083,'published',DEFAULT),
                                                                                                                          (3087,6,3273,240,3083,'published',DEFAULT),
                                                                                                                          (3088,22,3067,240,3087,'published',1),
                                                                                                                          (3089,23,3068,240,3087,'published',1),
                                                                                                                          (3090,26,3069,240,3087,'published',1),
                                                                                                                          (3091,22,3070,240,3087,'published',2),
                                                                                                                          (3092,23,3071,240,3087,'published',2),
                                                                                                                          (3093,26,3072,240,3087,'published',2),
                                                                                                                          (3094,22,3073,240,3087,'published',3),
                                                                                                                          (3095,23,3074,240,3087,'published',3),
                                                                                                                          (3096,26,3075,240,3087,'published',3),
                                                                                                                          (3097,4,3274,238,3034,'published',DEFAULT),
                                                                                                                          (3098,2,3076,238,3034,'published',DEFAULT),
                                                                                                                          (3099,21,3077,241,3034,'published',DEFAULT),
                                                                                                                          (3100,1,3078,241,3034,'published',DEFAULT),
                                                                                                                          (3101,31,3275,241,3034,'published',DEFAULT),
                                                                                                                          (3102,22,3079,242,3101,'published',DEFAULT),
                                                                                                                          (3103,1,3080,242,3101,'published',DEFAULT),
                                                                                                                          (3104,23,3081,242,3101,'published',DEFAULT),
                                                                                                                          (3105,26,3082,242,3101,'published',DEFAULT),
                                                                                                                          (3106,3,3276,242,3101,'published',DEFAULT),
                                                                                                                          (3107,19,3083,242,3106,'published',DEFAULT),
                                                                                                                          (3108,20,3084,242,3106,'published',DEFAULT),
                                                                                                                          (3109,4,3277,242,3101,'published',DEFAULT),
                                                                                                                          (3110,22,3085,243,3101,'published',DEFAULT),
                                                                                                                          (3111,1,3086,243,3101,'published',DEFAULT),
                                                                                                                          (3112,23,3087,243,3101,'published',DEFAULT),
                                                                                                                          (3113,26,3088,243,3101,'published',DEFAULT),
                                                                                                                          (3114,3,3278,243,3101,'published',DEFAULT),
                                                                                                                          (3115,19,3089,243,3114,'published',DEFAULT),
                                                                                                                          (3116,20,3090,243,3114,'published',DEFAULT),
                                                                                                                          (3117,4,3279,243,3101,'published',DEFAULT),
                                                                                                                          (3118,22,3091,244,3101,'published',DEFAULT),
                                                                                                                          (3119,1,3092,244,3101,'published',DEFAULT),
                                                                                                                          (3120,23,3093,244,3101,'published',DEFAULT),
                                                                                                                          (3121,29,3094,244,3101,'published',DEFAULT),
                                                                                                                          (3122,3,3280,244,3101,'published',DEFAULT),
                                                                                                                          (3123,19,3100,244,3122,'published',DEFAULT),
                                                                                                                          (3124,20,3101,244,3122,'published',DEFAULT),
                                                                                                                          (3125,4,3281,244,3101,'published',DEFAULT),
                                                                                                                          (3126,31,3282,244,3101,'published',DEFAULT),
                                                                                                                          (3127,24,3095,245,3126,'published',DEFAULT),
                                                                                                                          (3128,10,3096,245,3126,'published',DEFAULT),
                                                                                                                          (3129,25,3097,245,3126,'published',DEFAULT),
                                                                                                                          (3130,26,3098,245,3126,'published',DEFAULT),
                                                                                                                          (3131,27,3099,245,3126,'published',DEFAULT),
                                                                                                                          (3132,11,3341,245,3126,'published',DEFAULT),
                                                                                                                          (3133,4,3283,245,3126,'published',DEFAULT),
                                                                                                                          (3134,4,3284,241,3034,'published',DEFAULT),
                                                                                                                          (3135,12,3285,241,3134,'published',DEFAULT),
                                                                                                                          (3136,13,3102,241,3135,'published',1),
                                                                                                                          (3137,14,3103,241,3135,'published',1),
                                                                                                                          (3138,13,3104,241,3135,'published',2),
                                                                                                                          (3139,14,3105,241,3135,'published',2),
                                                                                                                          (3140,2,3342,241,3034,'published',DEFAULT),
                                                                                                                          (3141,22,3286,236,3025,'published',2),
                                                                                                                          (3142,1,3108,236,3025,'published',2),
                                                                                                                          (3143,7,3109,236,3025,'published',2),
                                                                                                                          (3144,8,3110,236,3025,'published',2),
                                                                                                                          (3145,28,3337,236,3025,'published',2),
                                                                                                                          (3146,26,3111,236,3025,'published',2),
                                                                                                                          (3147,31,3287,236,3025,'published',2),
                                                                                                                          (3148,1,3112,246,3147,'published',DEFAULT),
                                                                                                                          (3149,21,3113,246,3147,'published',DEFAULT),
                                                                                                                          (3150,23,3336,246,3147,'published',DEFAULT),
                                                                                                                          (3151,30,3114,246,3147,'published',DEFAULT),
                                                                                                                          (3152,4,3288,246,3147,'published',DEFAULT),
                                                                                                                          (3153,15,3115,246,3152,'published',DEFAULT),
                                                                                                                          (3154,2,3116,246,3147,'published',DEFAULT),
                                                                                                                          (3155,1,3117,247,3147,'published',DEFAULT),
                                                                                                                          (3156,21,3118,247,3147,'published',DEFAULT),
                                                                                                                          (3157,23,3338,247,3147,'published',DEFAULT),
                                                                                                                          (3158,6,3119,247,3147,'published',DEFAULT),
                                                                                                                          (3159,4,3289,247,3147,'published',DEFAULT),
                                                                                                                          (3160,2,3120,247,3147,'published',DEFAULT),
                                                                                                                          (3161,1,3121,248,3147,'published',DEFAULT),
                                                                                                                          (3162,21,3122,248,3147,'published',DEFAULT),
                                                                                                                          (3163,23,3123,248,3147,'published',DEFAULT),
                                                                                                                          (3164,6,3290,248,3147,'published',DEFAULT),
                                                                                                                          (3165,22,3124,248,3164,'published',1),
                                                                                                                          (3166,23,3125,248,3164,'published',1),
                                                                                                                          (3167,26,3126,248,3164,'published',1),
                                                                                                                          (3168,22,3127,248,3164,'published',2),
                                                                                                                          (3169,23,3128,248,3164,'published',2),
                                                                                                                          (3170,26,3129,248,3164,'published',2),
                                                                                                                          (3171,22,3130,248,3164,'published',3),
                                                                                                                          (3172,23,3131,248,3164,'published',3),
                                                                                                                          (3173,26,3132,248,3164,'published',3),
                                                                                                                          (3174,22,3133,248,3164,'published',4),
                                                                                                                          (3175,23,3134,248,3164,'published',4),
                                                                                                                          (3176,26,3135,248,3164,'published',4),
                                                                                                                          (3177,4,3291,248,3147,'published',DEFAULT),
                                                                                                                          (3178,2,3136,248,3147,'published',DEFAULT),
                                                                                                                          (3179,1,3137,249,3147,'published',DEFAULT),
                                                                                                                          (3180,21,3138,249,3147,'published',DEFAULT),
                                                                                                                          (3181,23,3343,249,3147,'published',DEFAULT),
                                                                                                                          (3182,6,3139,249,3147,'published',DEFAULT),
                                                                                                                          (3183,4,3292,249,3147,'published',DEFAULT),
                                                                                                                          (3184,2,3140,249,3147,'published',DEFAULT),
                                                                                                                          (3185,1,3141,250,3147,'published',DEFAULT),
                                                                                                                          (3186,21,3142,250,3147,'published',DEFAULT),
                                                                                                                          (3187,23,3143,250,3147,'published',DEFAULT),
                                                                                                                          (3188,30,3144,250,3147,'published',DEFAULT),
                                                                                                                          (3189,4,3293,250,3147,'published',DEFAULT),
                                                                                                                          (3190,15,3145,250,3189,'published',DEFAULT),
                                                                                                                          (3191,2,3146,250,3147,'published',DEFAULT),
                                                                                                                          (3192,2,3147,236,3025,'published',2),
                                                                                                                          (3193,4,3294,236,3025,'published',2),
                                                                                                                          (3194,22,3148,236,3025,'published',3),
                                                                                                                          (3195,1,3149,236,3025,'published',3),
                                                                                                                          (3196,7,3150,236,3025,'published',3),
                                                                                                                          (3197,8,3151,236,3025,'published',3),
                                                                                                                          (3198,28,3152,236,3025,'published',3),
                                                                                                                          (3199,26,3153,236,3025,'published',3),
                                                                                                                          (3200,2,3154,236,3025,'published',3),
                                                                                                                          (3201,4,3295,236,3025,'published',3),
                                                                                                                          (3202,1,3155,251,DEFAULT,'published',DEFAULT),
                                                                                                                          (3203,2,3156,251,DEFAULT,'published',DEFAULT),
                                                                                                                          (3204,21,3157,251,DEFAULT,'published',DEFAULT),
                                                                                                                          (3205,23,3158,251,DEFAULT,'published',DEFAULT),
                                                                                                                          (3206,6,3159,251,DEFAULT,'published',DEFAULT),
                                                                                                                          (3207,4,3297,251,DEFAULT,'published',DEFAULT),
                                                                                                                          (3208,16,3160,251,3207,'published',DEFAULT),
                                                                                                                          (3209,17,3161,251,3207,'published',DEFAULT),
                                                                                                                          (3210,18,3162,251,3207,'published',DEFAULT),
                                                                                                                          (3211,15,3163,251,3207,'published',DEFAULT),
                                                                                                                          (3212,1,3164,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3213,21,3165,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3214,22,3166,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3215,23,3167,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3216,4,3298,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3217,2,3168,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3218,31,3299,252,DEFAULT,'published',DEFAULT),
                                                                                                                          (3219,1,3169,253,3218,'published',DEFAULT),
                                                                                                                          (3220,6,3300,253,3218,'published',DEFAULT),
                                                                                                                          (3221,22,3170,253,3220,'published',1),
                                                                                                                          (3222,5,3171,253,3220,'published',1),
                                                                                                                          (3223,3,3301,253,3220,'published',1),
                                                                                                                          (3224,19,3172,253,3223,'published',default),
                                                                                                                          (3225,20,3173,253,3223,'published',default),
                                                                                                                          (3226,22,3174,253,3220,'published',2),
                                                                                                                          (3227,5,3175,253,3220,'published',2),
                                                                                                                          (3228,3,3302,253,3220,'published',2),
                                                                                                                          (3229,19,3176,253,3228,'published',DEFAULT),
                                                                                                                          (3230,20,3177,253,3228,'published',DEFAULT),
                                                                                                                          (3231,22,3178,253,3220,'published',3),
                                                                                                                          (3232,5,3179,253,3220,'published',3),
                                                                                                                          (3233,3,3303,253,3220,'published',3),
                                                                                                                          (3234,19,3180,253,3233,'published',DEFAULT),
                                                                                                                          (3235,20,3181,253,3233,'published',DEFAULT),
                                                                                                                          (3236,22,3182,253,3220,'published',4),
                                                                                                                          (3237,5,3183,253,3220,'published',4),
                                                                                                                          (3238,3,3304,253,3220,'published',4),
                                                                                                                          (3239,19,3184,253,3238,'published',DEFAULT),
                                                                                                                          (3240,20,3185,253,3238,'published',DEFAULT),
                                                                                                                          (3241,22,3186,253,3220,'published',5),
                                                                                                                          (3242,5,3187,253,3220,'published',5),
                                                                                                                          (3243,3,3305,253,3220,'published',5),
                                                                                                                          (3244,19,3188,253,3243,'published',DEFAULT),
                                                                                                                          (3245,20,3189,253,3243,'published',DEFAULT),
                                                                                                                          (3246,22,3190,253,3220,'published',6),
                                                                                                                          (3247,5,3191,253,3220,'published',6),
                                                                                                                          (3248,3,3306,253,3220,'published',6),
                                                                                                                          (3249,19,3192,253,3248,'published',DEFAULT),
                                                                                                                          (3250,20,3193,253,3248,'published',DEFAULT),
                                                                                                                          (3251,4,3307,253,3218,'published',DEFAULT),
                                                                                                                          (3252,12,3308,253,3251,'deleted',DEFAULT),
                                                                                                                          (3253,13,3194,253,3252,'deleted',1),
                                                                                                                          (3254,14,3195,253,3252,'deleted',1),
                                                                                                                          (3255,32,3309,253,3252,'deleted',1),
                                                                                                                          (3256,13,3196,253,3252,'deleted',2),
                                                                                                                          (3257,14,3197,253,3252,'deleted',2),
                                                                                                                          (3258,32,3198,253,3252,'deleted',2),
                                                                                                                          (3259,13,3199,253,3252,'deleted',3),
                                                                                                                          (3260,14,3200,253,3252,'deleted',3),
                                                                                                                          (3261,32,3310,253,3252,'deleted',3),
                                                                                                                          (3262,24,3201,254,3218,'published',DEFAULT),
                                                                                                                          (3263,1,3202,254,3218,'published',DEFAULT),
                                                                                                                          (3264,10,3203,254,3218,'published',DEFAULT),
                                                                                                                          (3265,25,3204,254,3218,'published',DEFAULT),
                                                                                                                          (3266,26,3205,254,3218,'published',DEFAULT),
                                                                                                                          (3267,27,3206,254,3218,'published',DEFAULT),
                                                                                                                          (3268,11,3207,254,3218,'published',DEFAULT),
                                                                                                                          (3269,4,3311,254,3218,'published',DEFAULT),
                                                                                                                          (3270,21,3208,255,DEFAULT,'published',DEFAULT),
                                                                                                                          (3271,1,3209,255,DEFAULT,'published',DEFAULT),
                                                                                                                          (3272,23,3210,255,DEFAULT,'published',DEFAULT),
                                                                                                                          (3273,6,3312,255,DEFAULT,'published',DEFAULT),
                                                                                                                          (3274,22,3211,255,3273,'published',1),
                                                                                                                          (3275,24,3212,255,3273,'published',1),
                                                                                                                          (3276,5,3213,255,3273,'published',1),
                                                                                                                          (3277,23,3214,255,3273,'published',1),
                                                                                                                          (3278,31,3313,255,3273,'published',1),
                                                                                                                          (3279,24,3215,256,3278,'published',DEFAULT),
                                                                                                                          (3280,1,3344,256,3278,'published',DEFAULT),
                                                                                                                          (3281,10,3216,256,3278,'published',DEFAULT),
                                                                                                                          (3282,25,3217,256,3278,'published',DEFAULT),
                                                                                                                          (3283,26,3218,256,3278,'published',DEFAULT),
                                                                                                                          (3284,27,3219,256,3278,'published',DEFAULT),
                                                                                                                          (3285,11,3220,256,3278,'published',DEFAULT),
                                                                                                                          (3286,4,3314,256,3278,'published',DEFAULT),
                                                                                                                          (3287,22,3221,255,3273,'published',2),
                                                                                                                          (3288,24,3222,255,3273,'published',2),
                                                                                                                          (3289,5,3223,255,3273,'published',2),
                                                                                                                          (3290,23,3224,255,3273,'published',2),
                                                                                                                          (3291,31,3315,255,3273,'published',2),
                                                                                                                          (3292,24,3225,257,3291,'published',DEFAULT),
                                                                                                                          (3293,1,3316,257,3291,'published',DEFAULT),
                                                                                                                          (3294,10,3226,257,3291,'published',DEFAULT),
                                                                                                                          (3295,25,3227,257,3291,'published',DEFAULT),
                                                                                                                          (3296,26,3317,257,3291,'published',DEFAULT),
                                                                                                                          (3297,27,3228,257,3291,'published',DEFAULT),
                                                                                                                          (3298,11,3229,257,3291,'published',DEFAULT),
                                                                                                                          (3299,4,3318,257,3291,'published',DEFAULT),
                                                                                                                          (3300,22,3230,255,3273,'published',3),
                                                                                                                          (3301,24,3231,255,3273,'published',3),
                                                                                                                          (3302,5,3232,255,3273,'published',3),
                                                                                                                          (3303,23,3233,255,3273,'published',3),
                                                                                                                          (3304,31,3319,255,3273,'published',3),
                                                                                                                          (3305,24,3234,258,3304,'published',DEFAULT),
                                                                                                                          (3306,1,3320,258,3304,'published',DEFAULT),
                                                                                                                          (3307,10,3235,258,3304,'published',DEFAULT),
                                                                                                                          (3308,25,3236,258,3304,'published',DEFAULT),
                                                                                                                          (3309,26,3321,258,3304,'published',DEFAULT),
                                                                                                                          (3310,27,3237,258,3304,'published',DEFAULT),
                                                                                                                          (3311,11,3238,258,3304,'published',DEFAULT),
                                                                                                                          (3312,4,3322,258,3304,'published',DEFAULT),
                                                                                                                          (3313,22,3239,255,3273,'published',4),
                                                                                                                          (3314,24,3240,255,3273,'published',4),
                                                                                                                          (3315,5,3241,255,3273,'published',4),
                                                                                                                          (3316,23,3242,255,3273,'published',4),
                                                                                                                          (3317,31,3323,255,3273,'published',4),
                                                                                                                          (3318,24,3243,259,3317,'published',DEFAULT),
                                                                                                                          (3319,1,3324,259,3317,'published',DEFAULT),
                                                                                                                          (3320,10,3244,259,3317,'published',DEFAULT),
                                                                                                                          (3321,25,3245,259,3317,'published',DEFAULT),
                                                                                                                          (3322,26,3246,259,3317,'published',DEFAULT),
                                                                                                                          (3323,27,3325,259,3317,'published',DEFAULT),
                                                                                                                          (3324,11,3247,259,3317,'published',DEFAULT),
                                                                                                                          (3325,4,3326,259,3317,'published',DEFAULT),
                                                                                                                          (3326,4,3327,255,DEFAULT,'published',DEFAULT),
                                                                                                                          (3327,2,3248,255,DEFAULT,'published',DEFAULT),
                                                                                                                          (3328,1,3249,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3329,2,3252,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3330,22,3250,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3331,23,3328,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3332,29,3251,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3333,4,3329,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3334,31,3330,260,DEFAULT,'published',DEFAULT),
                                                                                                                          (3335,24,3253,261,3334,'published',DEFAULT),
                                                                                                                          (3336,1,3331,261,3334,'published',DEFAULT),
                                                                                                                          (3337,10,3254,261,3334,'published',DEFAULT),
                                                                                                                          (3338,25,3255,261,3334,'published',DEFAULT),
                                                                                                                          (3339,27,3256,261,3334,'published',DEFAULT),
                                                                                                                          (3340,11,3257,261,3334,'published',DEFAULT),
                                                                                                                          (3341,4,3332,261,3334,'published',DEFAULT),
                                                                                                                          (3342,34,3345,234,3005,'published',DEFAULT),
                                                                                                                          (3343,35,3346,239,3067,'published',1),
                                                                                                                          (3344,35,3347,239,3067,'published',2),
                                                                                                                          (3345,35,3348,239,3067,'published',3),
                                                                                                                          (3346,35,3349,239,3067,'published',4),
                                                                                                                          (3347,35,3350,240,3087,'published',1),
                                                                                                                          (3348,35,3351,240,3087,'published',3),
                                                                                                                          (3349,35,3352,240,3087,'published',2),
                                                                                                                          (3350,34,3353,242,3101,'published',DEFAULT),
                                                                                                                          (3351,34,3354,243,3101,'published',DEFAULT),
                                                                                                                          (3352,34,3355,244,3101,'published',DEFAULT),
                                                                                                                          (3353,34,3356,245,3126,'published',DEFAULT),
                                                                                                                          (3354,36,3357,246,3147,'published',DEFAULT),
                                                                                                                          (3355,5,3358,246,3147,'published',DEFAULT),
                                                                                                                          (3356,36,3359,250,3147,'published',DEFAULT),
                                                                                                                          (3357,5,3360,250,3147,'published',DEFAULT),
                                                                                                                          (3358,34,3361,254,3218,'published',DEFAULT),
                                                                                                                          (3359,34,3362,256,3278,'published',DEFAULT),
                                                                                                                          (3360,34,3363,257,3291,'published',DEFAULT),
                                                                                                                          (3361,34,3364,258,3304,'published',DEFAULT),
                                                                                                                          (3362,34,3365,259,3317,'published',DEFAULT),
                                                                                                                          (3363,34,3366,236,DEFAULT,'published',DEFAULT),
                                                                                                                          (3364,34,3367,261,3334,'published',DEFAULT),
                                                                                                                          (3368,1,3368,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3369,2,3369,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3370,21,3370,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3371,22,3371,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3372,23,3372,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3373,31,3632,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3374,24,3373,263,3373,'published',DEFAULT),
                                                                                                                          (3375,1,3374,263,3373,'published',DEFAULT),
                                                                                                                          (3376,10,3375,263,3373,'published',DEFAULT),
                                                                                                                          (3377,25,3376,263,3373,'published',DEFAULT),
                                                                                                                          (3378,26,3701,263,3373,'published',DEFAULT),
                                                                                                                          (3379,27,3377,263,3373,'published',DEFAULT),
                                                                                                                          (3380,11,3378,263,3373,'published',DEFAULT),
                                                                                                                          (3381,4,3628,263,3373,'published',DEFAULT),
                                                                                                                          (3382,1,3379,264,3373,'published',DEFAULT),
                                                                                                                          (3383,33,3702,264,3373,'published',DEFAULT),
                                                                                                                          (3384,27,3380,264,3383,'published',1),
                                                                                                                          (3385,9,3381,264,3383,'published',1),
                                                                                                                          (3386,27,3382,264,3383,'published',2),
                                                                                                                          (3387,9,3383,264,3383,'published',2),
                                                                                                                          (3388,4,3629,264,3373,'published',DEFAULT),
                                                                                                                          (3389,4,3627,262,DEFAULT,'published',DEFAULT),
                                                                                                                          (3390,1,3384,265,DEFAULT,'published',DEFAULT),
                                                                                                                          (3391,2,3385,265,DEFAULT,'published',DEFAULT),
                                                                                                                          (3392,4,3664,265,DEFAULT,'published',DEFAULT),
                                                                                                                          (3393,6,3630,265,DEFAULT,'published',DEFAULT),
                                                                                                                          (3394,22,3386,265,3393,'published',1),
                                                                                                                          (3395,1,3387,265,3393,'published',1),
                                                                                                                          (3396,7,3388,265,3393,'published',1),
                                                                                                                          (3397,8,3389,265,3393,'published',1),
                                                                                                                          (3398,28,3703,265,3393,'published',1),
                                                                                                                          (3399,26,3390,265,3393,'published',1),
                                                                                                                          (3400,2,3410,265,3393,'published',1),
                                                                                                                          (3401,4,3631,265,3393,'published',1),
                                                                                                                          (3402,31,3634,265,3393,'published',1),
                                                                                                                          (3403,22,3391,266,3402,'published',DEFAULT),
                                                                                                                          (3404,6,3633,266,3402,'published',DEFAULT),
                                                                                                                          (3405,22,3392,266,3404,'published',1),
                                                                                                                          (3406,23,3393,266,3404,'published',1),
                                                                                                                          (3407,26,3394,266,3404,'published',1),
                                                                                                                          (3408,22,3395,266,3404,'published',2),
                                                                                                                          (3409,23,3396,266,3404,'published',2),
                                                                                                                          (3410,26,3397,266,3404,'published',2),
                                                                                                                          (3411,22,3398,266,3404,'published',3),
                                                                                                                          (3412,23,3399,266,3404,'published',3),
                                                                                                                          (3413,26,3400,266,3404,'published',3),
                                                                                                                          (3414,22,3401,266,3404,'published',4),
                                                                                                                          (3415,23,3402,266,3404,'published',4),
                                                                                                                          (3416,26,3403,266,3404,'published',4),
                                                                                                                          (3417,22,3404,266,3404,'published',5),
                                                                                                                          (3418,23,3405,266,3404,'published',5),
                                                                                                                          (3419,26,3406,266,3404,'published',5),
                                                                                                                          (3420,22,3407,266,3404,'published',6),
                                                                                                                          (3421,23,3408,266,3404,'published',6),
                                                                                                                          (3422,26,3409,266,3404,'published',6),
                                                                                                                          (3423,2,3707,266,3402,'published',DEFAULT),
                                                                                                                          (3424,4,3708,266,3402,'published',DEFAULT),
                                                                                                                          (3425,21,3411,267,3402,'published',DEFAULT),
                                                                                                                          (3426,1,3412,267,3402,'published',DEFAULT),
                                                                                                                          (3427,6,3635,267,3402,'published',DEFAULT),
                                                                                                                          (3428,22,3413,267,3427,'published',1),
                                                                                                                          (3429,7,3414,267,3427,'published',1),
                                                                                                                          (3430,2,3415,267,3427,'published',1),
                                                                                                                          (3431,31,3636,267,3427,'published',1),
                                                                                                                          (3432,1,3416,268,3431,'published',DEFAULT),
                                                                                                                          (3433,2,3417,268,3431,'published',DEFAULT),
                                                                                                                          (3434,4,3637,268,3431,'published',DEFAULT),
                                                                                                                          (3435,6,3638,268,3431,'published',DEFAULT),
                                                                                                                          (3436,22,3418,268,3435,'published',1),
                                                                                                                          (3437,23,3419,268,3435,'published',1),
                                                                                                                          (3438,26,3420,268,3435,'published',1),
                                                                                                                          (3439,22,3421,268,3435,'published',2),
                                                                                                                          (3440,23,3422,268,3435,'published',2),
                                                                                                                          (3441,26,3423,268,3435,'published',2),
                                                                                                                          (3442,22,3424,268,3435,'published',3),
                                                                                                                          (3443,23,3425,268,3435,'published',3),
                                                                                                                          (3444,26,3426,268,3435,'published',3),
                                                                                                                          (3445,22,3427,268,3435,'published',4),
                                                                                                                          (3446,23,3428,268,3435,'published',4),
                                                                                                                          (3447,26,3429,268,3435,'published',4),
                                                                                                                          (3448,22,3430,267,3427,'published',2),
                                                                                                                          (3449,7,3431,267,3427,'published',2),
                                                                                                                          (3450,2,3432,267,3427,'published',2),
                                                                                                                          (3451,31,3639,267,3427,'published',2),
                                                                                                                          (3452,1,3433,269,3451,'published',DEFAULT),
                                                                                                                          (3453,2,3434,269,3451,'published',DEFAULT),
                                                                                                                          (3454,4,3640,269,3451,'published',DEFAULT),
                                                                                                                          (3455,6,3641,269,3451,'published',DEFAULT),
                                                                                                                          (3456,22,3435,269,3455,'published',1),
                                                                                                                          (3457,23,3436,269,3455,'published',1),
                                                                                                                          (3458,26,3437,269,3455,'published',1),
                                                                                                                          (3459,22,3438,269,3455,'published',2),
                                                                                                                          (3460,23,3439,269,3455,'published',2),
                                                                                                                          (3461,26,3440,269,3455,'published',2),
                                                                                                                          (3462,22,3441,269,3455,'published',3),
                                                                                                                          (3463,23,3442,269,3455,'published',3),
                                                                                                                          (3464,26,3443,269,3455,'published',3),
                                                                                                                          (3465,4,3642,267,3402,'published',DEFAULT),
                                                                                                                          (3466,2,3444,267,3402,'published',DEFAULT),
                                                                                                                          (3467,21,3445,270,3402,'published',DEFAULT),
                                                                                                                          (3468,1,3446,270,3402,'published',DEFAULT),
                                                                                                                          (3469,31,3643,270,3402,'published',DEFAULT),
                                                                                                                          (3470,22,3447,271,3469,'published',DEFAULT),
                                                                                                                          (3471,1,3448,271,3469,'published',DEFAULT),
                                                                                                                          (3472,23,3449,271,3469,'published',DEFAULT),
                                                                                                                          (3473,26,3450,271,3469,'published',DEFAULT),
                                                                                                                          (3474,3,3644,271,3469,'published',DEFAULT),
                                                                                                                          (3475,19,3451,271,3474,'published',DEFAULT),
                                                                                                                          (3476,20,3452,271,3474,'published',DEFAULT),
                                                                                                                          (3477,4,3645,271,3469,'published',DEFAULT),
                                                                                                                          (3478,22,3453,272,3469,'published',DEFAULT),
                                                                                                                          (3479,1,3454,272,3469,'published',DEFAULT),
                                                                                                                          (3480,23,3455,272,3469,'published',DEFAULT),
                                                                                                                          (3481,26,3456,272,3469,'published',DEFAULT),
                                                                                                                          (3482,3,3646,272,3469,'published',DEFAULT),
                                                                                                                          (3483,19,3457,272,3482,'published',DEFAULT),
                                                                                                                          (3484,20,3458,272,3482,'published',DEFAULT),
                                                                                                                          (3485,4,3647,272,3469,'published',DEFAULT),
                                                                                                                          (3486,22,3459,273,3469,'published',DEFAULT),
                                                                                                                          (3487,1,3460,273,3469,'published',DEFAULT),
                                                                                                                          (3488,23,3461,273,3469,'published',DEFAULT),
                                                                                                                          (3489,29,3462,273,3469,'published',DEFAULT),
                                                                                                                          (3490,3,3648,273,3469,'published',DEFAULT),
                                                                                                                          (3491,19,3468,273,3490,'published',DEFAULT),
                                                                                                                          (3492,20,3469,273,3490,'published',DEFAULT),
                                                                                                                          (3493,4,3649,273,3469,'published',DEFAULT),
                                                                                                                          (3494,31,3650,273,3469,'published',DEFAULT),
                                                                                                                          (3495,24,3463,274,3494,'published',DEFAULT),
                                                                                                                          (3496,10,3464,274,3494,'published',DEFAULT),
                                                                                                                          (3497,25,3465,274,3494,'published',DEFAULT),
                                                                                                                          (3498,26,3466,274,3494,'published',DEFAULT),
                                                                                                                          (3499,27,3467,274,3494,'published',DEFAULT),
                                                                                                                          (3500,11,3709,274,3494,'published',DEFAULT),
                                                                                                                          (3501,4,3651,274,3494,'published',DEFAULT),
                                                                                                                          (3502,4,3652,270,3402,'published',DEFAULT),
                                                                                                                          (3503,12,3653,270,3502,'published',DEFAULT),
                                                                                                                          (3504,13,3470,270,3503,'published',1),
                                                                                                                          (3505,14,3471,270,3503,'published',1),
                                                                                                                          (3506,13,3472,270,3503,'published',2),
                                                                                                                          (3507,14,3473,270,3503,'published',2),
                                                                                                                          (3508,2,3710,270,3402,'published',DEFAULT),
                                                                                                                          (3509,22,3654,265,3393,'published',2),
                                                                                                                          (3510,1,3476,265,3393,'published',2),
                                                                                                                          (3511,7,3477,265,3393,'published',2),
                                                                                                                          (3512,8,3478,265,3393,'published',2),
                                                                                                                          (3513,28,3705,265,3393,'published',2),
                                                                                                                          (3514,26,3479,265,3393,'published',2),
                                                                                                                          (3515,31,3655,265,3393,'published',2),
                                                                                                                          (3516,1,3480,275,3515,'published',DEFAULT),
                                                                                                                          (3517,21,3481,275,3515,'published',DEFAULT),
                                                                                                                          (3518,23,3704,275,3515,'published',DEFAULT),
                                                                                                                          (3519,30,3482,275,3515,'published',DEFAULT),
                                                                                                                          (3520,4,3656,275,3515,'published',DEFAULT),
                                                                                                                          (3521,15,3483,275,3520,'published',DEFAULT),
                                                                                                                          (3522,2,3484,275,3515,'published',DEFAULT),
                                                                                                                          (3523,1,3485,276,3515,'published',DEFAULT),
                                                                                                                          (3524,21,3486,276,3515,'published',DEFAULT),
                                                                                                                          (3525,23,3706,276,3515,'published',DEFAULT),
                                                                                                                          (3526,6,3487,276,3515,'published',DEFAULT),
                                                                                                                          (3527,4,3657,276,3515,'published',DEFAULT),
                                                                                                                          (3528,2,3488,276,3515,'published',DEFAULT),
                                                                                                                          (3529,1,3489,277,3515,'published',DEFAULT),
                                                                                                                          (3530,21,3490,277,3515,'published',DEFAULT),
                                                                                                                          (3531,23,3491,277,3515,'published',DEFAULT),
                                                                                                                          (3532,6,3658,277,3515,'published',DEFAULT),
                                                                                                                          (3533,22,3492,277,3532,'published',1),
                                                                                                                          (3534,23,3493,277,3532,'published',1),
                                                                                                                          (3535,26,3494,277,3532,'published',1),
                                                                                                                          (3536,22,3495,277,3532,'published',2),
                                                                                                                          (3537,23,3496,277,3532,'published',2),
                                                                                                                          (3538,26,3497,277,3532,'published',2),
                                                                                                                          (3539,22,3498,277,3532,'published',3),
                                                                                                                          (3540,23,3499,277,3532,'published',3),
                                                                                                                          (3541,26,3500,277,3532,'published',3),
                                                                                                                          (3542,22,3501,277,3532,'published',4),
                                                                                                                          (3543,23,3502,277,3532,'published',4),
                                                                                                                          (3544,26,3503,277,3532,'published',4),
                                                                                                                          (3545,4,3659,277,3515,'published',DEFAULT),
                                                                                                                          (3546,2,3504,277,3515,'published',DEFAULT),
                                                                                                                          (3547,1,3505,278,3515,'published',DEFAULT),
                                                                                                                          (3548,21,3506,278,3515,'published',DEFAULT),
                                                                                                                          (3549,23,3711,278,3515,'published',DEFAULT),
                                                                                                                          (3550,6,3507,278,3515,'published',DEFAULT),
                                                                                                                          (3551,4,3660,278,3515,'published',DEFAULT),
                                                                                                                          (3552,2,3508,278,3515,'published',DEFAULT),
                                                                                                                          (3553,1,3509,279,3515,'published',DEFAULT),
                                                                                                                          (3554,21,3510,279,3515,'published',DEFAULT),
                                                                                                                          (3555,23,3511,279,3515,'published',DEFAULT),
                                                                                                                          (3556,30,3512,279,3515,'published',DEFAULT),
                                                                                                                          (3557,4,3661,279,3515,'published',DEFAULT),
                                                                                                                          (3558,15,3513,279,3557,'published',DEFAULT),
                                                                                                                          (3559,2,3514,279,3515,'published',DEFAULT),
                                                                                                                          (3560,2,3515,265,3393,'published',2),
                                                                                                                          (3561,4,3662,265,3393,'published',2),
                                                                                                                          (3562,22,3516,265,3393,'published',3),
                                                                                                                          (3563,1,3517,265,3393,'published',3),
                                                                                                                          (3564,7,3518,265,3393,'published',3),
                                                                                                                          (3565,8,3519,265,3393,'published',3),
                                                                                                                          (3566,28,3520,265,3393,'published',3),
                                                                                                                          (3567,26,3521,265,3393,'published',3),
                                                                                                                          (3568,2,3522,265,3393,'published',3),
                                                                                                                          (3569,4,3663,265,3393,'published',3),
                                                                                                                          (3570,1,3523,280,DEFAULT,'published',DEFAULT),
                                                                                                                          (3571,2,3524,280,DEFAULT,'published',DEFAULT),
                                                                                                                          (3572,21,3525,280,DEFAULT,'published',DEFAULT),
                                                                                                                          (3573,23,3526,280,DEFAULT,'published',DEFAULT),
                                                                                                                          (3574,6,3527,280,DEFAULT,'published',DEFAULT),
                                                                                                                          (3575,4,3665,280,DEFAULT,'published',DEFAULT),
                                                                                                                          (3576,16,3528,280,3575,'published',DEFAULT),
                                                                                                                          (3577,17,3529,280,3575,'published',DEFAULT),
                                                                                                                          (3578,18,3530,280,3575,'published',DEFAULT),
                                                                                                                          (3579,15,3531,280,3575,'published',DEFAULT),
                                                                                                                          (3580,1,3532,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3581,21,3533,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3582,22,3534,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3583,23,3535,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3584,4,3666,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3585,2,3536,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3586,31,3667,281,DEFAULT,'published',DEFAULT),
                                                                                                                          (3587,1,3537,282,3586,'published',DEFAULT),
                                                                                                                          (3588,6,3668,282,3586,'published',DEFAULT),
                                                                                                                          (3589,22,3538,282,3588,'published',1),
                                                                                                                          (3590,5,3539,282,3588,'published',1),
                                                                                                                          (3591,3,3669,282,3588,'published',1),
                                                                                                                          (3592,19,3540,282,3591,'published',default),
                                                                                                                          (3593,20,3541,282,3591,'published',default),
                                                                                                                          (3594,22,3542,282,3588,'published',2),
                                                                                                                          (3595,5,3543,282,3588,'published',2),
                                                                                                                          (3596,3,3670,282,3588,'published',2),
                                                                                                                          (3597,19,3544,282,3596,'published',DEFAULT),
                                                                                                                          (3598,20,3545,282,3596,'published',DEFAULT),
                                                                                                                          (3599,22,3546,282,3588,'published',3),
                                                                                                                          (3600,5,3547,282,3588,'published',3),
                                                                                                                          (3601,3,3671,282,3588,'published',3),
                                                                                                                          (3602,19,3548,282,3601,'published',DEFAULT),
                                                                                                                          (3603,20,3549,282,3601,'published',DEFAULT),
                                                                                                                          (3604,22,3550,282,3588,'published',4),
                                                                                                                          (3605,5,3551,282,3588,'published',4),
                                                                                                                          (3606,3,3672,282,3588,'published',4),
                                                                                                                          (3607,19,3552,282,3606,'published',DEFAULT),
                                                                                                                          (3608,20,3553,282,3606,'published',DEFAULT),
                                                                                                                          (3609,22,3554,282,3588,'published',5),
                                                                                                                          (3610,5,3555,282,3588,'published',5),
                                                                                                                          (3611,3,3673,282,3588,'published',5),
                                                                                                                          (3612,19,3556,282,3611,'published',DEFAULT),
                                                                                                                          (3613,20,3557,282,3611,'published',DEFAULT),
                                                                                                                          (3614,22,3558,282,3588,'published',6),
                                                                                                                          (3615,5,3559,282,3588,'published',6),
                                                                                                                          (3616,3,3674,282,3588,'published',6),
                                                                                                                          (3617,19,3560,282,3616,'published',DEFAULT),
                                                                                                                          (3618,20,3561,282,3616,'published',DEFAULT),
                                                                                                                          (3619,4,3675,282,3586,'published',DEFAULT),
                                                                                                                          (3620,12,3676,282,3619,'deleted',DEFAULT),
                                                                                                                          (3621,13,3562,282,3620,'deleted',1),
                                                                                                                          (3622,14,3563,282,3620,'deleted',1),
                                                                                                                          (3623,32,3677,282,3620,'deleted',1),
                                                                                                                          (3624,13,3564,282,3620,'deleted',2),
                                                                                                                          (3625,14,3565,282,3620,'deleted',2),
                                                                                                                          (3626,32,3566,282,3620,'deleted',2),
                                                                                                                          (3627,13,3567,282,3620,'deleted',3),
                                                                                                                          (3628,14,3568,282,3620,'deleted',3),
                                                                                                                          (3629,32,3678,282,3620,'deleted',3),
                                                                                                                          (3630,24,3569,283,3586,'published',DEFAULT),
                                                                                                                          (3631,1,3570,283,3586,'published',DEFAULT),
                                                                                                                          (3632,10,3571,283,3586,'published',DEFAULT),
                                                                                                                          (3633,25,3572,283,3586,'published',DEFAULT),
                                                                                                                          (3634,26,3573,283,3586,'published',DEFAULT),
                                                                                                                          (3635,27,3574,283,3586,'published',DEFAULT),
                                                                                                                          (3636,11,3575,283,3586,'published',DEFAULT),
                                                                                                                          (3637,4,3679,283,3586,'published',DEFAULT),
                                                                                                                          (3638,21,3576,284,DEFAULT,'published',DEFAULT),
                                                                                                                          (3639,1,3577,284,DEFAULT,'published',DEFAULT),
                                                                                                                          (3640,23,3578,284,DEFAULT,'published',DEFAULT),
                                                                                                                          (3641,6,3680,284,DEFAULT,'published',DEFAULT),
                                                                                                                          (3642,22,3579,284,3641,'published',1),
                                                                                                                          (3643,24,3580,284,3641,'published',1),
                                                                                                                          (3644,5,3581,284,3641,'published',1),
                                                                                                                          (3645,23,3582,284,3641,'published',1),
                                                                                                                          (3646,31,3681,284,3641,'published',1),
                                                                                                                          (3647,24,3583,285,3646,'published',DEFAULT),
                                                                                                                          (3648,1,3712,285,3646,'published',DEFAULT),
                                                                                                                          (3649,10,3584,285,3646,'published',DEFAULT),
                                                                                                                          (3650,25,3585,285,3646,'published',DEFAULT),
                                                                                                                          (3651,26,3586,285,3646,'published',DEFAULT),
                                                                                                                          (3652,27,3587,285,3646,'published',DEFAULT),
                                                                                                                          (3653,11,3588,285,3646,'published',DEFAULT),
                                                                                                                          (3654,4,3682,285,3646,'published',DEFAULT),
                                                                                                                          (3655,22,3589,284,3641,'published',2),
                                                                                                                          (3656,24,3590,284,3641,'published',2),
                                                                                                                          (3657,5,3591,284,3641,'published',2),
                                                                                                                          (3658,23,3592,284,3641,'published',2),
                                                                                                                          (3659,31,3683,284,3641,'published',2),
                                                                                                                          (3660,24,3593,286,3659,'published',DEFAULT),
                                                                                                                          (3661,1,3684,286,3659,'published',DEFAULT),
                                                                                                                          (3662,10,3594,286,3659,'published',DEFAULT),
                                                                                                                          (3663,25,3595,286,3659,'published',DEFAULT),
                                                                                                                          (3664,26,3685,286,3659,'published',DEFAULT),
                                                                                                                          (3665,27,3596,286,3659,'published',DEFAULT),
                                                                                                                          (3666,11,3597,286,3659,'published',DEFAULT),
                                                                                                                          (3667,4,3686,286,3659,'published',DEFAULT),
                                                                                                                          (3668,22,3598,284,3641,'published',3),
                                                                                                                          (3669,24,3599,284,3641,'published',3),
                                                                                                                          (3670,5,3600,284,3641,'published',3),
                                                                                                                          (3671,23,3601,284,3641,'published',3),
                                                                                                                          (3672,31,3687,284,3641,'published',3),
                                                                                                                          (3673,24,3602,287,3672,'published',DEFAULT),
                                                                                                                          (3674,1,3688,287,3672,'published',DEFAULT),
                                                                                                                          (3675,10,3603,287,3672,'published',DEFAULT),
                                                                                                                          (3676,25,3604,287,3672,'published',DEFAULT),
                                                                                                                          (3677,26,3689,287,3672,'published',DEFAULT),
                                                                                                                          (3678,27,3605,287,3672,'published',DEFAULT),
                                                                                                                          (3679,11,3606,287,3672,'published',DEFAULT),
                                                                                                                          (3680,4,3690,287,3672,'published',DEFAULT),
                                                                                                                          (3681,22,3607,284,3641,'published',4),
                                                                                                                          (3682,24,3608,284,3641,'published',4),
                                                                                                                          (3683,5,3609,284,3641,'published',4),
                                                                                                                          (3684,23,3610,284,3641,'published',4),
                                                                                                                          (3685,31,3691,284,3641,'published',4),
                                                                                                                          (3686,24,3611,288,3685,'published',DEFAULT),
                                                                                                                          (3687,1,3692,288,3685,'published',DEFAULT),
                                                                                                                          (3688,10,3612,288,3685,'published',DEFAULT),
                                                                                                                          (3689,25,3613,288,3685,'published',DEFAULT),
                                                                                                                          (3690,26,3614,288,3685,'published',DEFAULT),
                                                                                                                          (3691,27,3693,288,3685,'published',DEFAULT),
                                                                                                                          (3692,11,3615,288,3685,'published',DEFAULT),
                                                                                                                          (3693,4,3694,288,3685,'published',DEFAULT),
                                                                                                                          (3694,4,3695,284,DEFAULT,'published',DEFAULT),
                                                                                                                          (3695,2,3616,284,DEFAULT,'published',DEFAULT),
                                                                                                                          (3696,1,3617,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3697,2,3620,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3698,22,3618,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3699,23,3696,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3700,29,3619,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3701,4,3697,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3702,31,3698,289,DEFAULT,'published',DEFAULT),
                                                                                                                          (3703,24,3621,290,3702,'published',DEFAULT),
                                                                                                                          (3704,1,3699,290,3702,'published',DEFAULT),
                                                                                                                          (3705,10,3622,290,3702,'published',DEFAULT),
                                                                                                                          (3706,25,3623,290,3702,'published',DEFAULT),
                                                                                                                          (3707,27,3624,290,3702,'published',DEFAULT),
                                                                                                                          (3708,11,3625,290,3702,'published',DEFAULT),
                                                                                                                          (3709,4,3700,290,3702,'published',DEFAULT),
                                                                                                                          (3710,34,3713,263,3373,'published',DEFAULT),
                                                                                                                          (3711,35,3714,268,3435,'published',1),
                                                                                                                          (3712,35,3715,268,3435,'published',2),
                                                                                                                          (3713,35,3716,268,3435,'published',3),
                                                                                                                          (3714,35,3717,268,3435,'published',4),
                                                                                                                          (3715,35,3718,269,3455,'published',1),
                                                                                                                          (3716,35,3719,269,3455,'published',3),
                                                                                                                          (3717,35,3720,269,3455,'published',2),
                                                                                                                          (3718,34,3721,271,3469,'published',DEFAULT),
                                                                                                                          (3719,34,3722,272,3469,'published',DEFAULT),
                                                                                                                          (3720,34,3723,273,3469,'published',DEFAULT),
                                                                                                                          (3721,34,3724,274,3494,'published',DEFAULT),
                                                                                                                          (3722,36,3725,275,3515,'published',DEFAULT),
                                                                                                                          (3723,5,3726,275,3515,'published',DEFAULT),
                                                                                                                          (3724,36,3727,279,3515,'published',DEFAULT),
                                                                                                                          (3725,5,3728,279,3515,'published',DEFAULT),
                                                                                                                          (3726,34,3729,283,3586,'published',DEFAULT),
                                                                                                                          (3727,34,3730,285,3646,'published',DEFAULT),
                                                                                                                          (3728,34,3731,286,3659,'published',DEFAULT),
                                                                                                                          (3729,34,3732,287,3672,'published',DEFAULT),
                                                                                                                          (3730,34,3733,288,3685,'published',DEFAULT),
                                                                                                                          (3731,34,3734,265,DEFAULT,'published',DEFAULT),
                                                                                                                          (3732,34,3735,290,3702,'published',DEFAULT),
                                                                                                                          (3809,1,3809,208,DEFAULT,'published',DEFAULT),
                                                                                                                          (3810,1,3810,34,DEFAULT,'published',DEFAULT),
                                                                                                                          (3811,1,3811,179,DEFAULT,'published',DEFAULT);

--текстовка для АЗ_Стартапа с аппрувленной анкетой
update public.values
set  value='Что вам **доступно**'
where id=2601;


--выключение вкладки "Корпорация" для всех страниц
update public.feature_attributes_values
set  status='disabled'
where id_features IN (4,33,62,91,120,149,178,207,236,265) and group_id = 3;



-----------Обновление структуры плиток для cRectangTiles_investor_1
--NZ

insert into public.values (id, value, locale) values
                                                  (3805, NULL, 'ru'),
                                                  (3806, '/file/rectang_tiles_logo2.png', 'ru'),
                                                  (3807, '/file/rectang_tiles_logo3.png', 'ru'),
                                                  (3808, '/file/rectang_tiles_logo4.png', 'ru');



update public.values
set  value='/file/rectang_tiles_logo1.png'
where id=120;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3805,6,3805,15,148,'published',DEFAULT),
                                                                                                                          (3806,5,3806,15,3805,'published',2),
                                                                                                                          (3807,5,3807,15,3805,'published',3),
                                                                                                                          (3808,5,3808,15,3805,'published',4);


update public.feature_attributes_values
set  id_attributes=5, id_parent=3805,group_id=1
where id_values=120 and id_features = 15;

--AZ_FAMILYOFFICE_id
insert into public.values (id, value, locale) values
                                                  (3745, NULL, 'ru'),
                                                  (3746, '/file/rectang_tiles_logo2.png', 'ru'),
                                                  (3747, '/file/rectang_tiles_logo3.png', 'ru'),
                                                  (3748, '/file/rectang_tiles_logo4.png', 'ru');



update public.values
set  value='/file/rectang_tiles_logo1.png'
where id=1225;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3745,6,3745,102,1247,'published',DEFAULT),
                                                                                                                          (3746,5,3746,102,3745,'published',2),
                                                                                                                          (3747,5,3747,102,3745,'published',3),
                                                                                                                          (3748,5,3748,102,3745,'published',4);


update public.feature_attributes_values
set  id_attributes=5, id_parent=3745,group_id=1
where id_values=1225 and id_features = 102;

--AZ_BUSINESSANGEL
insert into public.values (id, value, locale) values
                                                  (3757, NULL, 'ru'),
                                                  (3758, '/file/rectang_tiles_logo2.png', 'ru'),
                                                  (3759, '/file/rectang_tiles_logo3.png', 'ru'),
                                                  (3760, '/file/rectang_tiles_logo4.png', 'ru');

update public.values
set  value='/file/rectang_tiles_logo1.png'
where id=1593;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3757,6,3757,131,1612,'published',DEFAULT),
                                                                                                                          (3758,5,3758,131,3757,'published',2),
                                                                                                                          (3759,5,3759,131,3757,'published',3),
                                                                                                                          (3760,5,3760,131,3757,'published',4);


update public.feature_attributes_values
set  id_attributes=5, id_parent=3757,group_id=1
where id_values=1593 and id_features = 131;

--AZ_VENTUREFOND
insert into public.values (id, value, locale) values
                                                  (3761, NULL, 'ru'),
                                                  (3762, '/file/rectang_tiles_logo2.png', 'ru'),
                                                  (3763, '/file/rectang_tiles_logo3.png', 'ru'),
                                                  (3764, '/file/rectang_tiles_logo4.png', 'ru');

update public.values
set  value='/file/rectang_tiles_logo1.png'
where id=1961;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3761,6,3761,160,1977,'published',DEFAULT),
                                                                                                                          (3762,5,3762,160,3761,'published',2),
                                                                                                                          (3763,5,3763,160,3761,'published',3),
                                                                                                                          (3764,5,3764,160,3761,'published',4);


update public.feature_attributes_values
set  id_attributes=5, id_parent=3761,group_id=1
where id_values=1961 and id_features = 160;

--INVESTOR_AZ_NOT_CONFIRMED
insert into public.values (id, value, locale) values
                                                  (3765, NULL, 'ru'),
                                                  (3766, '/file/rectang_tiles_logo2.png', 'ru'),
                                                  (3767, '/file/rectang_tiles_logo3.png', 'ru'),
                                                  (3768, '/file/rectang_tiles_logo4.png', 'ru');

update public.values
set  value='/file/rectang_tiles_logo1.png'
where id=3119;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3765,6,3765,247,3147,'published',DEFAULT),
                                                                                                                          (3766,5,3766,247,3765,'published',2),
                                                                                                                          (3767,5,3767,247,3765,'published',3),
                                                                                                                          (3768,5,3768,247,3765,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3765,group_id=1
where id_values=3119 and id_features = 247;

--INVESTOR_AZ_CONFIRMED
insert into public.values (id, value, locale) values
                                                  (3769, NULL, 'ru'),
                                                  (3770, '/file/rectang_tiles_logo2.png', 'ru'),
                                                  (3771, '/file/rectang_tiles_logo3.png', 'ru'),
                                                  (3772, '/file/rectang_tiles_logo4.png', 'ru');

update public.values
set  value='/file/rectang_tiles_logo1.png'
where id=3487;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3769,6,3769,276,3515,'published',DEFAULT),
                                                                                                                          (3770,5,3770,276,3769,'published',2),
                                                                                                                          (3771,5,3771,276,3769,'published',3),
                                                                                                                          (3772,5,3772,276,3769,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3769,group_id=1
where id_values=3487 and id_features = 276;





-----
-----------
-------

--Обновление структуры плиток для cRectangTiles_investor_2

--NZ
insert into public.values (id, value, locale) values
                                                  (3737, NULL, 'ru'),
                                                  (3738, '//file/logo_2_accelerator.png', 'ru'),
                                                  (3739, '//file/logo_3_accelerator.png', 'ru'),
                                                  (3740, '//file/logo_4_accelerator.png', 'ru'),
                                                  (3741, 'https://sberbank-500.ru/', 'ru'),
                                                  (3742, 'https://sberstudent.sberclass.ru/', 'ru'),
                                                  (3743, 'https://sber-up.ru/', 'ru'),
                                                  (3744, 'https://sber-z.sberclass.ru/', 'ru');

update public.values
set  value='//file/logo_1_accelerator.png'
where id=140;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3737,6,3737,17,148,'published',DEFAULT),
                                                                                                                          (3738,5,3738,17,3737,'published',2),
                                                                                                                          (3739,5,3739,17,3737,'published',3),
                                                                                                                          (3740,5,3740,17,3737,'published',4),
                                                                                                                          (3741,27,3741,17,3737,'published',1),
                                                                                                                          (3742,27,3742,17,3737,'published',2),
                                                                                                                          (3743,27,3743,17,3737,'published',3),
                                                                                                                          (3744,27,3744,17,3737,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3737,group_id=1
where id_values=140 and id_features = 17;

--AZ_FAMILYOFFICE_id
insert into public.values (id, value, locale) values
                                                  (3749, NULL, 'ru'),
                                                  (3750, '//file/logo_2_accelerator.png', 'ru'),
                                                  (3751, '//file/logo_3_accelerator.png', 'ru'),
                                                  (3752, '//file/logo_4_accelerator.png', 'ru'),
                                                  (3753, 'https://sberbank-500.ru/', 'ru'),
                                                  (3754, 'https://sberstudent.sberclass.ru/', 'ru'),
                                                  (3755, 'https://sber-up.ru/', 'ru'),
                                                  (3756, 'https://sber-z.sberclass.ru/', 'ru');

update public.values
set  value='//file/logo_1_accelerator.png'
where id=1245;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3749,6,3749,104,1247,'published',DEFAULT),
                                                                                                                          (3750,5,3750,104,3749,'published',2),
                                                                                                                          (3751,5,3751,104,3749,'published',3),
                                                                                                                          (3752,5,3752,104,3749,'published',4),
                                                                                                                          (3753,27,3753,104,3749,'published',1),
                                                                                                                          (3754,27,3754,104,3749,'published',2),
                                                                                                                          (3755,27,3755,104,3749,'published',3),
                                                                                                                          (3756,27,3756,104,3749,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3749,group_id=1
where id_values=1245 and id_features = 104;


--AZ_BUSINESSANGEL_id
insert into public.values (id, value, locale) values
                                                  (3773, NULL, 'ru'),
                                                  (3774, '//file/logo_2_accelerator.png', 'ru'),
                                                  (3775, '//file/logo_3_accelerator.png', 'ru'),
                                                  (3776, '//file/logo_4_accelerator.png', 'ru'),
                                                  (3777, 'https://sberbank-500.ru/', 'ru'),
                                                  (3778, 'https://sberstudent.sberclass.ru/', 'ru'),
                                                  (3779, 'https://sber-up.ru/', 'ru'),
                                                  (3780, 'https://sber-z.sberclass.ru/', 'ru');

update public.values
set  value='//file/logo_1_accelerator.png'
where id=1613;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3773,6,3773,133,1612,'published',DEFAULT),
                                                                                                                          (3774,5,3774,133,3773,'published',2),
                                                                                                                          (3775,5,3775,133,3773,'published',3),
                                                                                                                          (3776,5,3776,133,3773,'published',4),
                                                                                                                          (3777,27,3777,133,3773,'published',1),
                                                                                                                          (3778,27,3778,133,3773,'published',2),
                                                                                                                          (3779,27,3779,133,3773,'published',3),
                                                                                                                          (3780,27,3780,133,3773,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3773,group_id=1
where id_values=1613 and id_features = 133;


--AZ_VENTUREFOND_id
insert into public.values (id, value, locale) values
                                                  (3781, NULL, 'ru'),
                                                  (3782, '//file/logo_2_accelerator.png', 'ru'),
                                                  (3783, '//file/logo_3_accelerator.png', 'ru'),
                                                  (3784, '//file/logo_4_accelerator.png', 'ru'),
                                                  (3785, 'https://sberbank-500.ru/', 'ru'),
                                                  (3786, 'https://sberstudent.sberclass.ru/', 'ru'),
                                                  (3787, 'https://sber-up.ru/', 'ru'),
                                                  (3788, 'https://sber-z.sberclass.ru/', 'ru');

update public.values
set  value='//file/logo_1_accelerator.png'
where id=1981;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3781,6,3781,162,1977,'published',DEFAULT),
                                                                                                                          (3782,5,3782,162,3781,'published',2),
                                                                                                                          (3783,5,3783,162,3781,'published',3),
                                                                                                                          (3784,5,3784,162,3781,'published',4),
                                                                                                                          (3785,27,3785,162,3781,'published',1),
                                                                                                                          (3786,27,3786,162,3781,'published',2),
                                                                                                                          (3787,27,3787,162,3781,'published',3),
                                                                                                                          (3788,27,3788,162,3781,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3781,group_id=1
where id_values=1981 and id_features = 162;


--INVESTOR_AZ_NOT_CONFIRMED_id
insert into public.values (id, value, locale) values
                                                  (3789, NULL, 'ru'),
                                                  (3790, '//file/logo_2_accelerator.png', 'ru'),
                                                  (3791, '//file/logo_3_accelerator.png', 'ru'),
                                                  (3792, '//file/logo_4_accelerator.png', 'ru'),
                                                  (3793, 'https://sberbank-500.ru/', 'ru'),
                                                  (3794, 'https://sberstudent.sberclass.ru/', 'ru'),
                                                  (3795, 'https://sber-up.ru/', 'ru'),
                                                  (3796, 'https://sber-z.sberclass.ru/', 'ru');

update public.values
set  value='//file/logo_1_accelerator.png'
where id=3139;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3789,6,3789,249,3147,'published',DEFAULT),
                                                                                                                          (3790,5,3790,249,3789,'published',2),
                                                                                                                          (3791,5,3791,249,3789,'published',3),
                                                                                                                          (3792,5,3792,249,3789,'published',4),
                                                                                                                          (3793,27,3793,249,3789,'published',1),
                                                                                                                          (3794,27,3794,249,3789,'published',2),
                                                                                                                          (3795,27,3795,249,3789,'published',3),
                                                                                                                          (3796,27,3796,249,3789,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3789,group_id=1
where id_values=3139 and id_features = 249;


--INVESTOR_AZ_CONFIRMED_id

insert into public.values (id, value, locale) values
                                                  (3797, NULL, 'ru'),
                                                  (3798, '//file/logo_2_accelerator.png', 'ru'),
                                                  (3799, '//file/logo_3_accelerator.png', 'ru'),
                                                  (3800, '//file/logo_4_accelerator.png', 'ru'),
                                                  (3801, 'https://sberbank-500.ru/', 'ru'),
                                                  (3802, 'https://sberstudent.sberclass.ru/', 'ru'),
                                                  (3803, 'https://sber-up.ru/', 'ru'),
                                                  (3804, 'https://sber-z.sberclass.ru/', 'ru');

update public.values
set  value='//file/logo_1_accelerator.png'
where id=3507;

INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
                                                                                                                          (3797,6,3797,278,3515,'published',DEFAULT),
                                                                                                                          (3798,5,3798,278,3797,'published',2),
                                                                                                                          (3799,5,3799,278,3797,'published',3),
                                                                                                                          (3800,5,3800,278,3797,'published',4),
                                                                                                                          (3801,27,3801,278,3797,'published',1),
                                                                                                                          (3802,27,3802,278,3797,'published',2),
                                                                                                                          (3803,27,3803,278,3797,'published',3),
                                                                                                                          (3804,27,3804,278,3797,'published',4);

update public.feature_attributes_values
set  id_attributes=5, id_parent=3797,group_id=1
where id_values=3507 and id_features = 278;

-------ОБНОВЛЕНИЕ ПОРЯДКА ФИЧЕЙ НА СТРАНИЦЕ И ИСКЛЮЧЕНИЕ ТАБОВ-------
--AZ_CONFIRMED


--Открепление фичей от 207 фичи AZ_CONFIRMED_cMainTabs_1

--207 feature DISABLING
update public.features
set  status='disabled'
where code ='AZ_CONFIRMED_cMainTabs_1';


--Открепление от 207 фичи
update public.pages_features
set  id_parent_feature=null
where id_features IN (208,209,212);

--СОРТИРОВКА ФИЧЕЙ
--208 feature
update public.values
set  value='2'
where id=2917;

--209  feature
update public.values
set  value='3'
where id=2625;

--209  feature
update public.values
set  value='5'
where id=2642;

--209  feature
update public.values
set  value='7'
where id=2654;

--210  feature
update public.values
set  value='4'
where id=2627;

--211  feature
update public.values
set  value='6'
where id=2944;

--212  feature
update public.values
set  value='8'
where id=2920;

--222  feature
update public.values
set  value='9'
where id=2734;

--223  feature
update public.values
set  value='10'
where id=2746;

--226  feature
update public.values
set  value='11'
where id=2826;

--231  feature
update public.values
set  value='12'
where id=2830;


--AZ_STARTUP

--Открепление фичей от 33 фичи AZ_STARTUP_cMainTabs_1

--Открепление от 33 фичи
update public.pages_features
set  id_parent_feature=null
where id_features IN (34,35,37,38);


--33 feature DISABLING
update public.features
set  status='disabled'
where code ='AZ_STARTUP_cMainTabs_1';


--СОРТИРОВКА ФИЧЕЙ


--34 feature
update public.values
set  value='2'
where id=709;

--37  feature
update public.values
set  value='3'
where id=436;

--38  feature
update public.values
set  value='4'
where id=712;


--48  feature
update public.values
set  value='5'
where id=526;

--49  feature
update public.values
set  value='6'
where id=538;


--52  feature
update public.values
set  value='7'
where id=618;

--57  feature
update public.values
set  value='8'
where id=622;




--AZ_NOT_CONFIRMED

--Открепление фичей от 178 фичи AZ_NOT_CONFIRMED_APPcMainTabs_1

--Открепление от 178 фичи
update public.pages_features
set  id_parent_feature=null
where id_features IN (179,183,182);


--33 feature DISABLING
update public.features
set  status='disabled'
where code ='AZ_NOT_CONFIRMED_APPcMainTabs_1';


--СОРТИРОВКА ФИЧЕЙ


--179 feature
update public.values
set  value='2'
where id=2549;

--182  feature
update public.values
set  value='3'
where id=2276;

--183  feature
update public.values
set  value='4'
where id=2552;


--193  feature
update public.values
set  value='5'
where id=2366;

--194  feature
update public.values
set  value='6'
where id=2378;


--197  feature
update public.values
set  value='7'
where id=2458;

--202  feature
update public.values
set  value='8'
where id=2462;








--AZ_VENTUREFOND

--Открепление фичей от 149 фичи AZ_VENTUREFOND_cMainTabs_1


--Открепление от 149 фичи
update public.pages_features
set  id_parent_feature=null
where id_features IN (159,160,161,162,163);

--149 feature DISABLING
update public.features
set  status='disabled'
where code ='AZ_VENTUREFOND_cMainTabs_1';


--СОРТИРОВКА ФИЧЕЙ
--159 feature
update public.values
set  value='2'
where id=1958;

--160  feature
update public.values
set  value='3'
where id=1962;

--161  feature
update public.values
set  value='4'
where id=1978;

--162  feature
update public.values
set  value='5'
where id=1982;

--163  feature
update public.values
set  value='6'
where id=1988;

--164  feature
update public.values
set  value='8'
where id=1998;

--165  feature
update public.values
set  value='9'
where id=2010;

--168  feature
update public.values
set  value='10'
where id=2090;

--173  feature
update public.values
set  value='11'
where id=2094;


--AZ_BUSINESSANGEL

--Открепление фичей от 120 фичи AZ_BUSINESSANGEL_cMainTabs_1


--Открепление от 120 фичи
update public.pages_features
set  id_parent_feature=null
where id_features IN (131,132,134,133,130);

--120 feature DISABLING
update public.features
set  status='disabled'
where code ='AZ_BUSINESSANGEL_cMainTabs_1';


--СОРТИРОВКА ФИЧЕЙ
--130 feature
update public.values
set  value='2'
where id=1590;

--131  feature
update public.values
set  value='3'
where id=1594;

--132  feature
update public.values
set  value='4'
where id=1610;

--133  feature
update public.values
set  value='5'
where id=1614;

--134  feature
update public.values
set  value='6'
where id=1620;

--135  feature
update public.values
set  value='7'
where id=1630;

--136  feature
update public.values
set  value='8'
where id=1642;

--139  feature
update public.values
set  value='9'
where id=1722;

--144  feature
update public.values
set  value='10'
where id=1726;






--AZ_FAMILYOFFICE

--Открепление фичей от 91 фичи AZ_FAMILYOFFICE_cMainTabs_1


--Открепление от 91 фичи
update public.pages_features
set  id_parent_feature=null
where id_features IN (101,102,103,104,105);

--91 feature DISABLING
update public.features
set  status='disabled'
where code ='AZ_FAMILYOFFICE_cMainTabs_1';


--СОРТИРОВКА ФИЧЕЙ
--101 feature
update public.values
set  value='2'
where id=1222;

--102  feature
update public.values
set  value='3'
where id=1226;

--103  feature
update public.values
set  value='4'
where id=1242;

--104  feature
update public.values
set  value='5'
where id=1246;

--105  feature
update public.values
set  value='6'
where id=1252;

--106  feature
update public.values
set  value='8'
where id=1262;

--107  feature
update public.values
set  value='9'
where id=1274;

--110  feature
update public.values
set  value='10'
where id=1354;

--115  feature
update public.values
set  value='11'
where id=1358;

