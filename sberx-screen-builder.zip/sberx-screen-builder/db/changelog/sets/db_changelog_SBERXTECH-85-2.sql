--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-85-2

update client_menu set
    action = action || '&id='
where menutype = 'pilots_corporate'
  and type = 1
  and sysname in ('all', 'archive');