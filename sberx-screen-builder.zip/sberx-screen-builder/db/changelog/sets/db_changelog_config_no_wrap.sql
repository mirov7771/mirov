--liquibase formatted sql
--changeset Mirov AA:config_no_wrap
update pages
set page = '{
  "features": [
    {
      "type": "participantSearch",
      "sysName": "startups_en_participantSearch",
      "visible": true,
      "title": "All startups",
      "header": "Startups",
      "position": 3,
      "placeholder": "Search startups",
      "participant": "startup",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}",
      "config": {
        "nowrap": true
      },
      "filterBar": {
        "title": "Filters",
        "acceptButtonText": "Apply filter",
        "resetButtonText": "Clear filter",
        "acceptButtonShortText": "Apply",
        "resetButtonShortText": "Clear",
        "placeholder": "search"
      },
      "sortLabels": {
        "alphabetically": "Alphabetically",
        "byUpdateDate": "By creation date",
        "byCreationDate": "By date modified"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Favorite",
        "viewedLabel": "Viewed",
        "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
      }
    }
  ]
}'
where uri = '/startup'
  and page_type = 'auth'
  and lang_id = 2;

update pages
set page = '{
  "features": [
    {
      "type": "participantSearch",
      "sysName": "startups_ru_participantSearch",
      "visible": true,
      "title": "Все стартапы",
      "header": "Стартапы",
      "position": 3,
      "placeholder": "Поиск стартапа",
      "participant": "startup",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}",
      "config": {
        "nowrap": true
      },
      "filterBar": {
        "title": "Фильтры",
        "acceptButtonText": "Применить фильтры",
        "resetButtonText": "Сбросить фильтры",
        "acceptButtonShortText": "Применить",
        "resetButtonShortText": "Сбросить",
        "placeholder": "поиск"
      },
      "sortLabels": {
        "alphabetically": "По алфавиту",
        "byUpdateDate": "По дате обновления",
        "byCreationDate": "По дате создания"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Избранные",
        "viewedLabel": "Просмотренное",
        "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
      }
    }
  ]
}'
where uri = '/startup'
  and page_type = 'auth'
  and lang_id = 1;

update pages
set page = '{
  "features": [
    {
      "type": "participantSearch",
      "sysName": "corporates_en_participantSearch",
      "title": "All corporates",
      "header": "Corporates",
      "visible": true,
      "position": 3,
      "placeholder": "Enter name",
      "participant": "corporation",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}",
      "config": {
        "nowrap": true
      },
      "filterBar": {
        "title": "Filters",
        "acceptButtonText": "Apply filter",
        "resetButtonText": "Clear filter",
        "acceptButtonShortText": "Apply",
        "resetButtonShortText": "Clear",
        "placeholder": "search"
      },
      "sortLabels": {
        "alphabetically": "Alphabetically",
        "byUpdateDate": "By creation date",
        "byCreationDate": "By date modified"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Favorite",
        "viewedLabel": "Viewed",
        "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
      }
    }
  ]
}'
where uri = '/corporates'
  and page_type = 'auth'
  and lang_id = 2;

update pages
set page = '{
  "features": [
    {
      "type": "participantSearch",
      "title": "Все корпорации",
      "header": "Корпорации",
      "sysName": "corporates_ru_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Введите название",
      "participant": "corporation",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}",
      "config": {
        "nowrap": true
      },
      "filterBar": {
        "title": "Фильтры",
        "acceptButtonText": "Применить фильтры",
        "resetButtonText": "Сбросить фильтры",
        "acceptButtonShortText": "Применить",
        "resetButtonShortText": "Сбросить",
        "placeholder": "поиск"
      },
      "sortLabels": {
        "alphabetically": "По алфавиту",
        "byUpdateDate": "По дате обновления",
        "byCreationDate": "По дате создания"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Избранные",
        "viewedLabel": "Просмотренное",
        "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
      }
    }
  ]
}'
where uri = '/corporates'
  and page_type = 'auth'
  and lang_id = 1;

update pages
set page = '{
  "features": [
    {
      "type": "participantSearch",
      "sysName": "investor_en_participantSearch",
      "visible": true,
      "title": "All investors",
      "header": "Investors",
      "position": 3,
      "placeholder": "Enter name or use the filter",
      "participant": "investor",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}",
      "config": {
        "nowrap": true
      },
      "filterBar": {
        "title": "Filters",
        "acceptButtonText": "Apply filter",
        "resetButtonText": "Clear filter",
        "acceptButtonShortText": "Apply",
        "resetButtonShortText": "Clear",
        "placeholder": "search"
      },
      "sortLabels": {
        "alphabetically": "Alphabetically",
        "byUpdateDate": "By creation date",
        "byCreationDate": "By date modified"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Favorite",
        "viewedLabel": "Viewed",
        "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
      }
    }
  ]
}'
where uri = '/investors'
  and page_type = 'auth'
  and lang_id = 2;

update pages
set page = '{
  "features": [
    {
      "type": "participantSearch",
      "sysName": "investor_ru_participantSearch",
      "visible": true,
      "title": "Все инвесторы",
      "header": "Инвесторы",
      "position": 3,
      "placeholder": "Введите название или воспользуйтесь фильтром",
      "participant": "investor",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}",
      "config": {
        "nowrap": true
      },
      "filterBar": {
        "title": "Фильтры",
        "acceptButtonText": "Применить фильтры",
        "resetButtonText": "Сбросить фильтры",
        "acceptButtonShortText": "Применить",
        "resetButtonShortText": "Сбросить",
        "placeholder": "поиск"
      },
      "sortLabels": {
        "alphabetically": "По алфавиту",
        "byUpdateDate": "По дате обновления",
        "byCreationDate": "По дате создания"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Избранные",
        "viewedLabel": "Просмотренное",
        "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
      }
    }
  ]
}'
where uri = '/investors'
  and page_type = 'auth'
  and lang_id = 1;
