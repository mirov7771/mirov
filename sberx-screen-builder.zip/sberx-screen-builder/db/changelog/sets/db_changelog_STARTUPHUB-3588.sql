--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3588
update public.screen
set formedit = '{
  "form": [
    {
      "module": "Заявка на пилотирование",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "reply_cost",
          "localName": "Какова стоимость Вашего решения",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "30",
          "mask": "$",
          "note": "Сумма, в которую Вы оцениваете ваш пилотный запуск",
          "example": "$"
        },
        {
          "sysName": "reply_process",
          "localName": "Как Вы видите процесс пилотирования",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "500",
          "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
          "example": "Комментарий",
          "rows": "3"
        },
        {
          "sysName": "reply_note",
          "localName": "Сопроводительное письмо",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "500",
          "example": "Опишите подробно Ваш оффер по данному пилоту",
          "rows": "3"
        },
        {
          "sysName": "pilotId",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_tableName",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "Pilot"
        },
        {
          "sysName": "reply_state",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "0"
        },
        {
          "sysName": "reply_fileURL",
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "format": "URL",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Вопросы корпорации",
      "page": 1,
      "isArray": "true",
      "moduleType": "question",
      "fields": [
        {
          "sysName": "response",
          "type": "string",
          "format": "question",
          "edited": false,
          "required": false,
          "example": "Ваш вопрос"
        }
      ]
    }
  ]
}'
where formname like 'pilot%Client%Extra';

update public.screen set
    formedit = '{
    "form": [
        {
            "module": "Организация",
            "page": 1,
            "pageName": "Юридическая информация",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Наименование организации",
                    "example": "Полное юридическое название",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_inn",
                    "localName": "Идентификационный номер компании",
                    "example": "Укажите Ваш ИНН или иной регистрационный номер",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_birthYear",
                    "localName": "Год регистрации",
                    "example": "Укажите год регистрации юрлица",
                    "type": "int",
                    "format": "year",
                    "mask": "2000;getyear",
                    "maxLength": 4,
                    "edited": true,
                    "required": true,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_name",
                    "localName": "Публичное название",
                    "example": "Например, SberUnity",
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "sysName": "questionnaire_registrationCountry",
                    "localName": "Страна регистрации юрлица",
                    "example": "Выберите страну юрисдикции",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Сайт",
                    "example": "Адрес сайта",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_inviteFio",
                    "localName": "Контактное лицо",
                    "example": "Иванов Иван Иванович",
                    "type": "string",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Электронная почта",
                    "example": "Укажите почту для связи",
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_phoneNumber",
                    "localName": "Номер телефона",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                }
            ]
        },
        {
            "module": "Дополнительные ссылки",
            "page": 1,
            "pageName": "Юридическая информация",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах",
            "isArray": "true",
            "actionText": "Добавить ссылку",
            "fields": [
                {
                    "sysName": "contacts[]_type",
                    "localName": "",
                    "title": "Ресурс",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        21000
                    ],
                    "edited": true,
                    "required": false,
                    "multySelect": false
                },
                {
                    "sysName": "contacts[]_name",
                    "example": "Адрес ссылки",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "maxLength": "70",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "О стартапе",
            "page": 2,
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_note",
                    "localName": "Краткое описание стартапа",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "200",
                    "example": "Опишите Ваш стартап одним предложением",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Модели продаж",
                    "description": "Укажите модели взаимодействия с клиентами в Вашем бизнесе",
                    "sysName": "project_interactionType",
                    "localName": "",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        8000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "questionnaire_businessModel",
                    "localName": "Бизнес-модель",
                    "example": "Укажите бизнес-модель стартапа",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        24000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "project_mvpCode",
                    "localName": "Стадия развития стартапа",
                    "example": "Выберите стадию развития",
                    "type": "array",
                    "format": "dropdown",
                    "activity": [
                        27000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_logoFile",
                    "title": "Логотип стартапа",
                    "note": "Размер логотипа: до 200x200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "format": "200*200",
                    "maxLength": "5",
                    "edited": true,
                    "required": true,
                    "allowedTypes": [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "sysName": "project_demoVideo",
                    "localName": "Видео о стартапе",
                    "example": "Ссылка на видео",
                    "type": "string",
                    "maxLength": "255",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "edited": true,
                    "required": false,
                    "showLength": false
                },
                {
                    "title": "Где базируется Ваш стартап?",
                    "description": "Укажите, где фактически находится штаб-квартира Вашего стартапа",
                    "sysName": "questionnaire_locationCountry",
                    "localName": "Страна",
                    "example": "Выберите страну",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_location",
                    "localName": "Город",
                    "example": "Введите город",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 30,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Направления",
            "page": 2,
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "description": "Индустрии и технологические вертикали, в которых функционирует Ваш стартап",
                    "sysName": "project_industry",
                    "localName": "Индустрии",
                    "example": "Выберите индустрии",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_technology",
                    "localName": "Технологии",
                    "example": "Выберите технологии",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        13000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "О продукте",
            "page": 3,
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_problem",
                    "localName": "Проблема, которую решает Ваш продукт",
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_auditory",
                    "localName": "Целевая аудитория",
                    "example": "Опишите Вашу целевую аудиторию",
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_businessPlan",
                    "localName": "Презентация",
                    "title": "Презентация",
                    "type": "hyperlink",
                    "maxLength": "50",
                    "format": "URL",
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "allowedTypes": [
                        ".pdf"
                    ],
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_geography",
                    "localName": "Рынки, на которых Вы работаете",
                    "example": "Введите или выберите страну",
                    "note": "Регионы, на которых уже представлен Ваш продукт",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_expansion",
                    "localName": "Рынки, на которые планируете выходить",
                    "example": "Введите или выберите страну",
                    "note": "Регионы, на которые Вы планируете выйти в ближайший год",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "project_sales",
                    "localName": "Продажи",
                    "example": "Выберите тип продаж",
                    "note": "Укажите стадию продаж Вашего продукта",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        5000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_turnover",
                    "localName": "Оборот в год",
                    "example": "$",
                    "type": "string",
                    "maxLength": "300",
                    "note": "Валовый оборот компании за последний год в $",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "project_competitor",
                    "localName": "Прямые конкуренты",
                    "example": "Перечислите название компаний-конкурентов",
                    "note": "Укажите конкурентов, близких к Вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_upSide",
                    "localName": "Преимущества перед конкурентами",
                    "example": "Опишите преимущества Вашего продукта",
                    "note": "Перечислите предметно, чем Вы лучше конкурентов",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_staff",
                    "localName": "Количество сотрудников",
                    "example": "Укажите число сотрудников в штате",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Ключевые сотрудники",
            "page": 3,
            "pageName": "Команда",
            "isArray": "true",
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "actionText": "Добавить должность",
            "fields": [
                {
                    "sysName": "workers[]_parentId",
                    "localName": "",
                    "type": "long",
                    "format": "hide",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_isFounder",
                    "localName": "",
                    "type": "boolean",
                    "format": "hide",
                    "value": false,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_role",
                    "localName": "Должность",
                    "example": "Название должности",
                    "type": "string",
                    "maxLength": "100",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_note",
                    "localName": "Краткое описание опыта",
                    "example": "Опишите опыт сотрудника",
                    "type": "string",
                    "maxLength": "150",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Успешные пилоты",
            "page": 4,
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_successPilots",
                    "title": "Если Вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "",
            "page": 4,
            "pageName": "Пилотирование, первые продажи и внедрения",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true",
            "isArray": "true",
            "actionText": "Добавить кейс",
            "fields": [
                {
                    "sysName": "b2bPilots[]_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "value": "20007",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_reference",
                    "localName": "С кем был успешный кейс",
                    "example": "Опишите, с какой корпорацией у Вас был успешный кейс",
                    "type": "string",
                    "maxLength": "140",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_suggestCase",
                    "localName": "Описание и результаты кейса",
                    "example": "Расскажите про кейс и его результаты",
                    "type": "string",
                    "maxLength": "200",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Экосистема Сбера",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)",
            "page": 4,
            "pageName": "Пилотирование, первые продажи и внедрения",
            "fields": [
                {
                    "sysName": "questionnaire_pilot",
                    "title": "Заинтересованы ли Вы в пилотировании Вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ecoPilot_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "value": "20008",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_suggestCase",
                    "title": "Предлагаемый кейс",
                    "example": "Если у Вас есть идеи, как можно пилотировать Ваш продукт, опишите их в нескольких предложениях",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "title": "Есть ли у Вас опыт взаимодействия с экосистемой Сбера?",
                    "sysName": "ecoPilot_experience",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Инвестиции",
            "page": 4,
            "pageName": "Инвестиции",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "investment_investment",
                    "title": "Находитесь ли Вы в активном поиске инвестиций?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_lastInvestment",
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "edited": true,
                    "required": false,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "investment_coInvestment",
                    "localName": "Список инвесторов",
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Акселератор Sber500",
            "page": 5,
            "pageName": "Sber500",
            "fields": [
                {
                    "title": "Хотите ли Вы подать заявку на участие в Sber500?",
                    "information": "Sber500 - уникальный акселератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global: [https://sberbank-500.ru](https://sberbank-500.ru)",
                    "sysName": "questionnaire_sber500",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "value": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Подавались ли Вы ранее в Sber500?",
                    "sysName": "sberFiveHundred_firsttime",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "sberFiveHundred_ecorequirement",
                    "title": "Какую потребность Экосистемы Сбера закрывает Ваш стартап?",
                    "information": "Подробные описания потребностей [опубликованы](https://sberbank-500.ru/ru) на сайте акселератора Sber500",
                    "example": "Укажите потребность",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        38000
                    ],
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "example": "$",
                    "sysName": "sberFiveHundred_monthrevenue",
                    "localName": "Выручка за последний месяц",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_quarterrevenue",
                    "localName": "Выручка за последние 3 месяца",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_clients",
                    "localName": "Количество активных или платящих клиентов за последний месяц",
                    "example": "Укажите количество клиентов",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500PrivacyPolicy",
                    "localName": "Я даю согласие на <a href=\"sber500PrivacyPolicyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">обработку персональных данных</a> с целью участия в акселераторе Sber500",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500Consent",
                    "localName": "Я даю согласие на обработку в <a href=\"sber500ConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">маркетинговых целях</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500TermOfUse",
                    "localName": "Я ознакомлен с <a href=\"sber500TermOfUseURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Правилами участия в программе Sber500</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                }
            ]
        }
    ]
}'
where formname = 'New_StartUp'
  and lang_id = 1;

update public.screen
set formedit = '{
    "form": [
        {
            "module": "Организация",
            "page": 1,
            "pageName": "Юридическая информация",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_fullName",
                    "localName": "Наименование организации",
                    "example": "Полное юридическое название",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_inn",
                    "localName": "Идентификационный номер компании",
                    "example": "Укажите Ваш ИНН или иной регистрационный номер",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_birthYear",
                    "localName": "Год регистрации",
                    "example": "Укажите год регистрации юрлица",
                    "type": "int",
                    "format": "year",
                    "mask": "2000;getyear",
                    "maxLength": 4,
                    "edited": true,
                    "required": true,
                    "showLength": false
                },
                {
                    "sysName": "questionnaire_name",
                    "localName": "Публичное название",
                    "example": "Например, SberUnity",
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 70,
                    "showLength": false,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "sysName": "questionnaire_registrationCountry",
                    "localName": "Страна регистрации юрлица",
                    "example": "Выберите страну юрисдикции",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": false
                },
                {
                    "sysName": "questionnaire_site",
                    "localName": "Сайт",
                    "example": "Адрес сайта",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_inviteFio",
                    "localName": "Контактное лицо",
                    "example": "Иванов Иван Иванович",
                    "type": "string",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_email",
                    "localName": "Электронная почта",
                    "example": "Укажите почту для связи",
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "format": "e-mail",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_phoneNumber",
                    "localName": "Номер телефона",
                    "type": "string",
                    "format": "phone",
                    "edited": true,
                    "required": true,
                    "mask": "phone"
                }
            ]
        },
        {
            "module": "Дополнительные ссылки",
            "page": 1,
            "pageName": "Юридическая информация",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах",
            "isArray": "true",
            "actionText": "Добавить ссылку",
            "fields": [
                {
                    "sysName": "contacts[]_type",
                    "localName": "",
                    "title": "Ресурс",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        21000
                    ],
                    "edited": true,
                    "required": false,
                    "multySelect": false
                },
                {
                    "sysName": "contacts[]_name",
                    "example": "Адрес ссылки",
                    "type": "string",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "maxLength": "70",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "О стартапе",
            "page": 2,
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_note",
                    "localName": "Краткое описание стартапа",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "200",
                    "example": "Опишите Ваш стартап одним предложением",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Модели продаж",
                    "description": "Укажите модели взаимодействия с клиентами в Вашем бизнесе",
                    "sysName": "project_interactionType",
                    "localName": "",
                    "type": "array",
                    "format": "chip",
                    "activity": [
                        8000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "questionnaire_businessModel",
                    "localName": "Бизнес-модель",
                    "example": "Укажите бизнес-модель стартапа",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        24000
                    ],
                    "edited": true,
                    "required": true,
                    "multySelect": true,
                    "values": []
                },
                {
                    "sysName": "project_mvpCode",
                    "localName": "Стадия развития стартапа",
                    "example": "Выберите стадию развития",
                    "type": "array",
                    "format": "dropdown",
                    "activity": [
                        27000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_logoFile",
                    "title": "Логотип стартапа",
                    "note": "Размер логотипа: до 200x200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "format": "200*200",
                    "maxLength": "5",
                    "edited": true,
                    "required": true,
                    "allowedTypes": [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "sysName": "project_demoVideo",
                    "localName": "Видео о стартапе",
                    "example": "Ссылка на видео",
                    "type": "string",
                    "maxLength": "255",
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
                    "edited": true,
                    "required": false,
                    "showLength": false
                },
                {
                    "title": "Где базируется Ваш стартап?",
                    "description": "Укажите, где фактически находится штаб-квартира Вашего стартапа",
                    "sysName": "questionnaire_locationCountry",
                    "localName": "Страна",
                    "example": "Выберите страну",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": false,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "questionnaire_location",
                    "localName": "Город",
                    "example": "Введите город",
                    "type": "string",
                    "edited": true,
                    "required": true,
                    "maxLength": 30,
                    "showLength": false
                }
            ]
        },
        {
            "module": "Направления",
            "page": 2,
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": "",
            "fields": [
                {
                    "description": "Индустрии и технологические вертикали, в которых функционирует Ваш стартап",
                    "sysName": "project_industry",
                    "localName": "Индустрии",
                    "example": "Выберите индустрии",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        3000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_technology",
                    "localName": "Технологии",
                    "example": "Выберите технологии",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        13000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "О продукте",
            "page": 3,
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "project_problem",
                    "localName": "Проблема, которую решает Ваш продукт",
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_auditory",
                    "localName": "Целевая аудитория",
                    "example": "Опишите Вашу целевую аудиторию",
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_businessPlan",
                    "localName": "Презентация",
                    "title": "Презентация",
                    "type": "hyperlink",
                    "maxLength": "50",
                    "format": "URL",
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "allowedTypes": [
                        ".pdf"
                    ],
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_geography",
                    "localName": "Рынки, на которых Вы работаете",
                    "example": "Введите или выберите страну",
                    "note": "Регионы, на которых уже представлен Ваш продукт",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_expansion",
                    "localName": "Рынки, на которые планируете выходить",
                    "example": "Введите или выберите страну",
                    "note": "Регионы, на которые Вы планируете выйти в ближайший год",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        2000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "project_sales",
                    "localName": "Продажи",
                    "example": "Выберите тип продаж",
                    "note": "Укажите стадию продаж Вашего продукта",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        5000
                    ],
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_turnover",
                    "localName": "Оборот в год",
                    "example": "$",
                    "type": "string",
                    "maxLength": "300",
                    "note": "Валовый оборот компании за последний год в $",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "project_competitor",
                    "localName": "Прямые конкуренты",
                    "example": "Перечислите название компаний-конкурентов",
                    "note": "Укажите конкурентов, близких к Вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_upSide",
                    "localName": "Преимущества перед конкурентами",
                    "example": "Опишите преимущества Вашего продукта",
                    "note": "Перечислите предметно, чем Вы лучше конкурентов",
                    "type": "string",
                    "rows": "3",
                    "maxLength": "300",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "project_staff",
                    "localName": "Количество сотрудников",
                    "example": "Укажите число сотрудников в штате",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Ключевые сотрудники",
            "page": 3,
            "pageName": "Команда",
            "isArray": "true",
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "actionText": "Добавить должность",
            "fields": [
                {
                    "sysName": "workers[]_parentId",
                    "localName": "",
                    "type": "long",
                    "format": "hide",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "workers[]_isFounder",
                    "localName": "",
                    "type": "boolean",
                    "format": "hide",
                    "value": false,
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_role",
                    "localName": "Должность",
                    "example": "Название должности",
                    "type": "string",
                    "maxLength": "100",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "workers[]_note",
                    "localName": "Краткое описание опыта",
                    "example": "Опишите опыт сотрудника",
                    "type": "string",
                    "maxLength": "150",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Успешные пилоты",
            "page": 4,
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "questionnaire_successPilots",
                    "title": "Если Вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "",
            "page": 4,
            "pageName": "Пилотирование, первые продажи и внедрения",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true",
            "isArray": "true",
            "actionText": "Добавить кейс",
            "fields": [
                {
                    "sysName": "b2bPilots[]_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "value": "20007",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_reference",
                    "localName": "С кем был успешный кейс",
                    "example": "Опишите, с какой корпорацией у Вас был успешный кейс",
                    "type": "string",
                    "maxLength": "140",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "b2bPilots[]_suggestCase",
                    "localName": "Описание и результаты кейса",
                    "example": "Расскажите про кейс и его результаты",
                    "type": "string",
                    "maxLength": "200",
                    "rows": "3",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Экосистема Сбера",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)",
            "page": 4,
            "pageName": "Пилотирование, первые продажи и внедрения",
            "fields": [
                {
                    "sysName": "questionnaire_pilot",
                    "title": "Заинтересованы ли Вы в пилотировании Вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "ecoPilot_state",
                    "localName": "",
                    "type": "array",
                    "format": "hide",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "value": "20008",
                    "edited": true,
                    "required": false
                },
                {
                    "sysName": "ecoPilot_suggestCase",
                    "title": "Предлагаемый кейс",
                    "example": "Если у Вас есть идеи, как можно пилотировать Ваш продукт, опишите их в нескольких предложениях",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true",
                    "edited": true,
                    "required": false
                },
                {
                    "title": "Есть ли у Вас опыт взаимодействия с экосистемой Сбера?",
                    "sysName": "ecoPilot_experience",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                }
            ]
        },
        {
            "module": "Инвестиции",
            "page": 4,
            "pageName": "Инвестиции",
            "moduleNote": "",
            "fields": [
                {
                    "sysName": "investment_investment",
                    "title": "Находитесь ли Вы в активном поиске инвестиций?",
                    "type": "boolean",
                    "format": "switch",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "investment_lastInvestment",
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "edited": true,
                    "required": false,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "investment_coInvestment",
                    "localName": "Список инвесторов",
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "type": "string",
                    "maxLength": "300",
                    "rows": "3",
                    "edited": true,
                    "required": false
                }
            ]
        },
        {
            "module": "Акселератор Sber500",
            "page": 5,
            "pageName": "Sber500",
            "fields": [
                {
                    "title": "Хотите ли Вы подать заявку на участие в Sber500?",
                    "information": "Sber500 - уникальный акселератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global: [https://sberbank-500.ru](https://sberbank-500.ru)",
                    "sysName": "questionnaire_sber500",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "value": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "title": "Подавались ли Вы ранее в Sber500?",
                    "sysName": "sberFiveHundred_firsttime",
                    "localName": "",
                    "type": "boolean",
                    "format": "switch",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "sberFiveHundred_ecorequirement",
                    "title": "Какую потребность Экосистемы Сбера закрывает Ваш стартап?",
                    "information": "Подробные описания потребностей [опубликованы](https://sberbank-500.ru/ru) на сайте акселератора Sber500",
                    "example": "Укажите потребность",
                    "type": "array",
                    "format": "search_dropdown",
                    "activity": [
                        38000
                    ],
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "multySelect": true,
                    "edited": true,
                    "required": true
                },
                {
                    "example": "$",
                    "sysName": "sberFiveHundred_monthrevenue",
                    "localName": "Выручка за последний месяц",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_quarterrevenue",
                    "localName": "Выручка за последние 3 месяца",
                    "example": "$",
                    "type": "string",
                    "regExp": "(^([0-9]{1,7}))",
                    "regExpError": "Необходимо указать число",
                    "maxLength": "300",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true,
                    "showLength": false,
                    "mask": "$"
                },
                {
                    "sysName": "sberFiveHundred_clients",
                    "localName": "Количество активных или платящих клиентов за последний месяц",
                    "example": "Укажите количество клиентов",
                    "type": "int",
                    "minValue": 1,
                    "maxValue": 1000,
                    "format": "[1;1000]",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500PrivacyPolicy",
                    "localName": "Я даю согласие на <a href=\"sber500PrivacyPolicyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">обработку персональных данных</a> с целью участия в акселераторе Sber500",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500Consent",
                    "localName": "Я даю согласие на обработку в <a href=\"sber500ConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">маркетинговых целях</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                },
                {
                    "sysName": "userConsent_sber500TermOfUse",
                    "localName": "Я ознакомлен с <a href=\"sber500TermOfUseURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Правилами участия в программе Sber500</a>",
                    "type": "boolean",
                    "format": "checkbox",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true",
                    "edited": true,
                    "required": true
                }
            ]
        }
    ]
}'
where formname = 'startup_edit'
  and lang_id = 1;