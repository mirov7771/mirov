--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3467
UPDATE screen
SET formedit='{
  "form": [
    {
      "module": "Основная информация",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "name",
          "localName": "Название пилота",
          "type": "string",
          "note": "Краткое название запрашиваемой технологии в именительном падеже",
          "edited": true,
          "required": true,
          "maxLength": "140",
          "showLength": false,
          "example": "Название запрашиваемой технологии"
        },
        {
          "sysName": "suggestCase",
          "localName": "Краткое описание запроса",
          "type": "string",
          "note": "Какую потребность бизнеса стартапы будут решать в рамках пилота?",
          "edited": true,
          "required": true,
          "maxLength": "300",
          "example": "Расскажите о запрашиваемой технологии"
        },
        {
          "sysName": "businessUnit",
          "localName": "Подразделение",
          "note": "Потребность какого подразделения компании Вы хотите закрыть?",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "200",
          "showLength": false,
          "example": "Название подразделения"
        },
        {
          "sysName": "industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "serch_dropdown",
          "activity": [
            3000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "example": "Укажите индустрию"
        }
      ]
    },
    {
      "module": "Техническое задание",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "demoFile",
          "localName": "Требования",
          "description": "Вы можете вложить более подробное ТЗ на пилот или описание кейса pdf-файлом. Поле опциональное.",
          "note": "Pdf или xlsx файл до 5 МБ",
          "type": "hyperlink",
          "maxLength": "5",
          "format": "URL",
          "allowedTypes": [
            ".pdf", "xlsx"
          ],
          "edited": true,
          "required": false
        },
        {
          "sysName": "file",
          "localName": "Разрешить загрузку файлов",
          "note": "Стартапы смогут загружать презентации под Вашу бизнеса-потребность",
          "type": "boolean",
          "format": "hide",
          "value": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "isHub",
          "localName": "Разрешить загрузку файлов",
          "note": "Стартапы смогут загружать презентации под Вашу бизнеса-потребность",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "value": "true",
          "required": false
        }
      ]
    },
    {
      "module": "Вопросы стартапу",
      "moduleNote": "Здесь Вы можете задать дополнительные вопросы стартапу, на которые необходимо ответить при подаче заявки на пилот",
      "actionText": "Добавить вопрос",
      "subTitle": "Вопрос №",
      "isArray": true,
      "page": 1,
      "fields": [
        {
          "sysName": "response[]_responseId",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": "true",
          "required": "false"
        },
        {
          "sysName": "response[]_pilotId",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": false
        },
        {
          "sysName": "response[]_question",
          "localName": "",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "100",
          "example": "Текст вопроса"
        }
      ]
    }
  ]
}', description='Чем лучше проработана заявка, тем более качественными будут отклики стартапов'
WHERE "type"=4 and  formname='New_Pilot';
