--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3676
update public.screen set
    formedit = '{
  "form": [
    {
      "module": "Юридическая информация об организации",
      "page": 1,
      "pageName": "Юридическая информация об организации",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "note": "Укажите полное юридическое название Вашей компании",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "format": "[1991;2021]",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт корпорации",
          "note" : "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "maxLength": "100",
          "edited": true,
          "required": true,
          "showLength": false
        }
      ]
    },
    {
      "module": "Контакт представителя",
      "page": 2,
      "pageName": "Информация о представителе",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения Вашей анкеты",
      "fields": [
        {
          "sysName": "representative_fio",
          "localName": "Имя, фамилия представителя",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_role",
          "localName": "Должность",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_phone",
          "localName": "Мобильный телефон",
          "type": "string",
          "format": "phone",
          "example": "+",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_email",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        }
      ]
    },{
      "module": "Публичный контакт",
      "page": 2,
      "pageName": "Информация о представителе",
      "isArray": "true",
      "title": "",
      "actionText": "Добавить контактное лицо",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_fio",
          "localName": "Имя, фамилия представителя",
          "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "note": "Укажите должность ответственного лица из предыдущего вопроса",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "workers[]_facebook",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "maxLength": "150",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Корпорация",
      "page": 3,
      "pageName": "Информация о корпорации",
      "fields": [
        {
          "sysName": "questionnaire_note",
          "localName": "Краткое описание",
          "note": "Опишите Вашу компанию одним предложением",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": true
        },{
          "sysName": "questionnaire_fullNote",
          "localName": "Полное описание",
          "note": "Опишите Вашу компанию более подробно",
          "type": "string",
          "maxLength": "480",
          "edited": true,
          "required": true
        },{
          "title": "Направления",
          "sysName": "questionnaire_industry",
          "localName": "Направление деятельности",
          "description": "Укажите все релевантные вашей компании отрасли",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            22000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },

        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "title": "Логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength" : "5",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Работа со стартапами",
      "page": 4,
      "pageName": "Условия работы со стартапами",
      "fields": [

        {
          "sysName": "questionnaire_innovationMethod",
          "title": "Методы работы с инновациями",
          "localName": "Укажите методы",
          "description": "Выберите методы внедрения инноваций в Вашей корпорации",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            4000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_industry",
          "title": "Направления",
          "description": "Укажите все релевантные вашей компании направления",
          "localName": "Индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_stady",
          "title": "Стадии развития стартапов",
          "description": "Выберите интересующие стадии развития стартапов",
          "localName": "Стадия развития",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            7000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "page": 5,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_startupInvestmentYears",
          "title": "Информация о сотрудничестве со стартапами",
          "localName": "Сколько лет Ваша корпорация работает со стартапами",
          "note": "Опционально",
          "type": "int",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_overallPilots",
          "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
          "note": "Опционально",
          "type": "int",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_lastYearInvestmentsCount",
          "localName": "Количество пилотов со стартапами за последний год",
          "note": "Опционально",
          "type": "int",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },

        {
          "sysName": "questionnaire_overallContracts",
          "localName": "Количество контрактов (внедрений) со стартапами за последний год",
          "note": "Опционально",
          "type": "int",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 6,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Инвестирует ли Ваша корпорация в стартапы?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_geography",
          "localName": "География стартапов",
          "note": "В стартапы из каких регионов Вы готовы инвестировать",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": true,
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "page": 6,
      "pageName": "Инвестиции",
      "triggerField": "investment_investment",
      "triggerValue": true,
      "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
      "isArray": true,
      "subTitle": "Стартап №",
      "withIndex": true,
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "successPilots[]_pilotid",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "successPilots[]_company",
          "localName": "Название стартапа",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "successPilots[]_suggestCase",
          "localName": "Описание кейса",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Скаутинг",
      "page": 7,
      "pageName": "Скаутинг",

      "fields": [
        {
          "sysName": "questionnaire_scouting",
          "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    }
  ]
}'
where formname = 'New_Corporate';


update public.screen set formedit = '{
  "form": [
  {
      "module": "Общая информация",
      "page": 1,
      "pageName": "Данные профиля и общая информация",
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Выберите тип инвестора",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },{
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },{
          "sysName": "questionnaire_name",
          "localName": "Ваши имя и фамилия",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },{
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },{
          "sysName": "questionnaire_questionnaireid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "note": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },{
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "note": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook",
          "type": "string",
          "edited": true,
          "required": false,
          "format": "hide"
        }
      ]
    },
    {
      "module": "Данные профиля",
      "page": 1,
      "pageName": "Данные профиля и общая информация",
      "fields": [
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего фонда",
          "note": "Например, \"Фонд и акселератор\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите свою краткую характеристику как бизнес-ангела",
          "note": "Например, \"Рассматриваю любые проекты\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },{
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Укажите страну, в которой Вы совершаете основной объем венчурных сделок",
          "type": "array",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего Family Office",
          "note": "Например, \"Фонд семьи Безосов\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего фонда",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите свою полную характеристику как бизнес-ангела",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего Family Office",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Добавьте фото",
          "localName": "Загрузить фото",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Контакт представителя",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения Вашей анкеты",
      "page": 2,
      "pageName": "Ваши данные",
      "fields": [
        {
          "sysName": "representative_fio",
          "localName": "Фамилия Имя",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_role",
          "localName": "Должность",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_phone",
          "localName": "Мобильный телефон",
          "type": "string",
          "format": "phone",
          "example": "+",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "edited": true,
          "required": false
        }
      ]
    },{
      "module": "Публичный контакт",
      "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в Вашей анкете в качестве контактного лица",
      "page": 2,
      "pageName": "Ваши данные",
      "isArray": "true",
      "title": "",
      "actionText": "Добавить контактное лицо",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_fio",
          "localName": "Фамилия Имя",
          "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "note": "Укажите должность лица из предыдущего вопроса",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "workers[]_facebook",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "maxLength": "150",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые Вами для инвестиций",
      "fields": [
        {
          "title": "Направления",
          "sysName": "investment_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "investment_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_geography",
          "title": "География стартапов",
          "localName": "География стартапов",
          "description": "В стартапы из каких регионов Вы готовы инвестировать",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестирования",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "investment_note",
          "localName": "Особые условия инвестирования",
          "note": "Например, impact startups, female founders и т.д.",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Данные о стартапах портфеля",
      "page": 3,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_activeDealsNumber",
          "localName": "Количество стартапов в портфеле",
          "note": "Число портфельных проектов на текущий момент",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество сделок, всего",
          "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых Вы уже вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "note": "Количество стартапов, в которые Вы инвестировали и вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        }
      ]
    },
    {
      "module": "Примеры стартапов",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Здесь Вы можете перечислить все или наиболее интересные стартапы из Вашего портфеля",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить стартап",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "note": "Опционально",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "questionnairePilots[]_site",
          "localName": "Ссылка на сайт стартапа",
          "note": "Опционально",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиционные клубы",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "fields": [
        {
          "sysName": "questionnaire_club",
          "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Сообщества",
      "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "subTitle": "Клуб / сообщество №",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить клуб",
      "triggerField": "questionnaire_club",
      "triggerValue": true,
      "fields": [
        {
          "sysName": "investorClubs[]_name",
          "localName": "Название клуба / сообщества",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investorClubs[]_role",
          "localName": "Ваша роль в клубе / сообществе",
          "note": "Например, \"Основатель клуба\"",
          "type": "string",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}' where formname = 'New_Investor';

update public.screen set formedit = '{
  "form": [
  {
      "module": "Общая информация",
      "page": 1,
      "pageName": "Данные профиля и общая информация",
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Выберите тип инвестора",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },{
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },{
          "sysName": "questionnaire_name",
          "localName": "Ваши имя и фамилия",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },{
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },{
          "sysName": "questionnaire_questionnaireid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "note": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },{
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "note": "Укажите полное юридическое название Вашей компании",
          "type": "string",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "note": "Укажите год создания Вашей компании",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "showLength": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Выберите страну, в которой зарегистрирована Ваша компания",
          "type": "array",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook",
          "type": "string",
          "edited": true,
          "required": false,
          "format": "hide"
        }
      ]
    },
    {
      "module": "Данные профиля",
      "page": 1,
      "pageName": "Данные профиля и общая информация",
      "fields": [
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего фонда",
          "note": "Например, \"Фонд и акселератор\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите свою краткую характеристику как бизнес-ангела",
          "note": "Например, \"Рассматриваю любые проекты\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },{
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции",
          "note": "Укажите страну, в которой Вы совершаете основной объем венчурных сделок",
          "type": "array",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего Family Office",
          "note": "Например, \"Фонд семьи Безосов\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего фонда",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите свою полную характеристику как бизнес-ангела",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего Family Office",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Публичный адрес электронной почты",
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "note": "Эта почта будет видна другим участниками платформы",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": true,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Добавьте фото",
          "localName": "Загрузить фото",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "type": "logo",
          "format": "1200*1200",
          "maxLength": "5",
          "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Контакт представителя",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения Вашей анкеты",
      "page": 2,
      "pageName": "Ваши данные",
      "fields": [
        {
          "sysName": "representative_fio",
          "localName": "Фамилия Имя",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_role",
          "localName": "Должность",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_phone",
          "localName": "Мобильный телефон",
          "type": "string",
          "format": "phone",
          "example": "+",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

          "edited": true,
          "required": false
        }
      ]
    },{
      "module": "Публичный контакт",
      "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в Вашей анкете в качестве контактного лица",
      "page": 2,
      "pageName": "Ваши данные",
      "isArray": "true",
      "title": "",
      "actionText": "Добавить контактное лицо",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_fio",
          "localName": "Фамилия Имя",
          "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "note": "Укажите должность лица из предыдущего вопроса",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "workers[]_facebook",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "maxLength": "150",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые Вами для инвестиций",
      "fields": [
        {
          "title": "Направления",
          "sysName": "investment_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "investment_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_geography",
          "title": "География стартапов",
          "localName": "География стартапов",
          "description": "В стартапы из каких регионов Вы готовы инвестировать",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестирования",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "investment_note",
          "localName": "Особые условия инвестирования",
          "note": "Например, impact startups, female founders и т.д.",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Данные о стартапах портфеля",
      "page": 3,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_activeDealsNumber",
          "localName": "Количество стартапов в портфеле",
          "note": "Число портфельных проектов на текущий момент",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество сделок, всего",
          "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых Вы уже вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "note": "Количество стартапов, в которые Вы инвестировали и вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        }
      ]
    },
    {
      "module": "Примеры стартапов",
      "page": 3,
      "pageName": "Инвестиции",
      "moduleNote": "Здесь Вы можете перечислить все или наиболее интересные стартапы из Вашего портфеля",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить стартап",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "note": "Опционально",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "questionnairePilots[]_site",
          "localName": "Ссылка на сайт стартапа",
          "note": "Опционально",
          "type": "string",
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиционные клубы",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "fields": [
        {
          "sysName": "questionnaire_club",
          "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Сообщества",
      "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "subTitle": "Клуб / сообщество №",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить клуб",
      "triggerField": "questionnaire_club",
      "triggerValue": true,
      "fields": [
        {
          "sysName": "investorClubs[]_name",
          "localName": "Название клуба / сообщества",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investorClubs[]_role",
          "localName": "Ваша роль в клубе / сообществе",
          "note": "Например, \"Основатель клуба\"",
          "type": "string",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'
where formname = 'investor_edit';


update public.screen set formedit = '{
          "form": [
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация об организации",
              "moduleNote": "",
              "fields": [
                {
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "type": "string",
                  "note": "Укажите полное юридическое название Вашей компании",
                  "edited": true,
                  "required": false,
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации",
                  "note": "Укажите год создания Вашей компании",
                  "type": "int",
                  "format": "[1991;2021]",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название",
                  "note": "Укажите, под каким именем отображать Вашу анкету для других участников платформы",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции",
                  "note": "Выберите страну, в которой зарегистрирована Ваша компания",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": true,
                  "required": true,
                  "multySelect": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "note": "Эта почта будет видна другим участниками платформы",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт корпорации",
                  "note" : "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
                  "type": "string",
                   "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",

                  "maxLength": "100",
                  "edited": true,
                  "required": true,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Контакт представителя",
              "page": 2,
              "pageName": "Информация о представителе",
              "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения Вашей анкеты",
              "fields": [
                {
                  "sysName": "representative_fio",
                  "localName": "Имя, фамилия представителя",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон",
                  "type": "string",
                  "format": "phone",
                  "example": "+",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_email",
                  "localName": "Электронная почта",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                }
              ]
            },{
      "module": "Публичный контакт",
      "page": 2,
      "pageName": "Информация о представителе",
      "isArray": "true",
      "title": "",
      "actionText": "Добавить контактное лицо",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_fio",
          "localName": "Имя, фамилия представителя",
          "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Должность",
          "note": "Укажите должность ответственного лица из предыдущего вопроса",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "workers[]_facebook",
          "localName": "Электронная почта",
          "type": "string",
          "format": "e-mail",
          "maxLength": "150",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
            {
              "module": "Корпорация",
              "page": 3,
              "pageName": "Информация о корпорации",
              "fields": [
                 {
              "sysName": "questionnaire_note",
              "localName": "Краткое описание",
              "note": "Опишите Вашу компанию одним предложением",
              "type": "string",
              "maxLength": "150",
              "edited": true,
              "required": true
            },{
              "sysName": "questionnaire_fullNote",
              "localName": "Полное описание",
              "note": "Опишите Вашу компанию более подробно",
              "type": "string",
              "maxLength": "480",
              "edited": true,
              "required": true
            },{
                  "title": "Направления",
                  "sysName": "questionnaire_industry",
                  "localName": "Направление деятельности",
                  "description": "Укажите все релевантные вашей компании отрасли",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    22000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },

                {
                  "sysName": "questionnaire_logoFile",
                  "localName": "Загрузить логотип",
                  "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
                  "title": "Логотип",
                  "type": "logo",
                  "format": "1200*1200",
                  "maxLength" : "5",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200. Формат PNG",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Работа со стартапами",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "fields": [

                {
                  "sysName": "questionnaire_innovationMethod",
                  "title": "Методы работы с инновациями",
                  "localName": "Укажите методы",
                  "description": "Выберите методы внедрения инноваций в Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    4000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },{
                  "sysName": "project_industry",
                  "title": "Направления",
                  "description": "Укажите все релевантные вашей компании направления",
                  "localName": "Индустрии",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },{
                  "sysName": "project_technology",
                  "localName": "Технологии",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    13000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_stady",
                  "title": "Стадии развития стартапов",
                  "description": "Выберите интересующие стадии развития стартапов",
                  "localName": "Стадия развития",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    7000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 5,
              "pageName": "Пилотирование",
              "fields": [
                {
                  "sysName": "questionnaire_successPilots",
                  "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_startupInvestmentYears",
                  "title": "Информация о сотрудничестве со стартапами",
                  "localName": "Сколько лет Ваша корпорация работает со стартапами",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_overallPilots",
                  "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_lastYearInvestmentsCount",
                  "localName": "Количество пилотов со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },

                {
                  "sysName": "questionnaire_overallContracts",
                  "localName": "Количество контрактов (внедрений) со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 6,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "investment_investment",
                  "localName": "Инвестирует ли Ваша корпорация в стартапы?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Раунд инвестиций",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "project_geography",
                  "localName": "География стартапов",
                  "note": "В стартапы из каких регионов Вы готовы инвестировать",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 6,
              "pageName": "Инвестиции",
              "triggerField": "investment_investment",
              "triggerValue": true,
              "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
              "isArray": true,
              "subTitle": "Стартап №",
              "withIndex": true,
              "actionText": "Добавить кейс",
              "fields": [
                {
                  "sysName": "successPilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "successPilots[]_company",
                  "localName": "Название стартапа",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "successPilots[]_suggestCase",
                  "localName": "Описание кейса",
                  "type": "string",
                  "maxLength": "300",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Скаутинг",
              "page": 7,
              "pageName": "Скаутинг",

              "fields": [
                {
                  "sysName": "questionnaire_scouting",
                  "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            }
          ]
        }'
where formname = 'corporate_edit';