--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-138
update client_menu set name = 'Мои отклики' where name = 'Ваши заявки';