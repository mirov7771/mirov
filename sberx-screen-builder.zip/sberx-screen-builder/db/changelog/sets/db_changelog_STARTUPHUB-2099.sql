--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-2099 Обновление пилота

UPDATE public.screen SET  formview='{
        "form": [{
               "fields": [{
                        "sysName": "businessunit",
                        "localName": "Подразделение",
                        "note": "Потребность какого подразделения компании вы хотите закрыть?",
                        "type": "string",
                        "format": "bold",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "suggestCase",
                        "localName": "",
                        "type": "string",
                        "edited": false,
                        "required": false
                    },{
                        "sysName": "industry",
                        "localName": "",
                        "type": "array",
                        "format": "chip",
                        "activity": [3000],
                        "edited": false,
                        "required": false,
                        "multySelect": false
                    }, {
    "sysName": "demoFile",
    "localName": "Дополнительные материалы",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "edited": false,
    "required": false
  }
                ]
            }
        ]
    }'::json::json, "name"=NULL, description=NULL, pages=NULL, buttons='{"buttons": [{
  "type": "archive",
  "code": 20009,
  "action": "/reply",
  "method": "POST",
  "variant": "disabled",
  "text": "Отправить заявку",
  "enabled": false,
  "description": "Дождитесь проверки анкеты стартапа, чтобы участвовать в пилотах"
}]}'::json::json WHERE formname='pilot_SuperClient';


UPDATE public.screen SET formedit=' {"form": [
          {
            "module": "Основная информация",
            "moduleNote": "",
            "page": 1,
            "fields": [
              {
                "sysName": "pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": true
              },{
                "sysName": "name",
                "localName": "Название пилота",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "140",
                "showLength": false
              },{
                "sysName": "suggestCase",
                "localName": "Краткое описание запроса",
                "type": "string",
                "note": "Какую потребность стартапы будут решать в рамках пилота?",
                "edited": true,
                "required": true,
                "maxLength": "300"
              },
              {
                "sysName": "businessUnit",
                "localName": "Подразделение",
                "note": "Потребность какого подразделения компании вы хотите закрыть?",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "200",
                "showLength": false
              },
              {
                "sysName": "industry",
                "localName": "Индустрии",
                "type": "array",
                "format": "serch_dropdown",
                "activity": [
                  3000
                ],
                "edited": true,
                "required": false,
                "multySelect": true
              }, {
        "sysName": "file",
        "localName": "Дополнительные материалы",
        "description": "Вы можете вложить более подробное ТЗ на пилот или описание кейса pdf-файлом. Поле опциоональное.",
        "note": "Pdf файл до 5 МБ",
        "type": "hyperlink",
        "format": "URL",
        "allowedTypes": [".pdf"],
        "edited": true,
        "required": false
      },
              {
                "sysName": "file",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "value": true,
                "edited": true,
                "required": true
              },
              {
                "sysName": "isHub",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "edited": true,
                "value": "true",
                "required": false
              }
            ]
          },
          {
            "module": "Вопросы стартапу",
            "moduleNote": "Здесь Вы можете задать дополнительные вопросы стартапу, на которые необходимо ответить при подаче заявки на пилот",
            "actionText": "Добавить вопрос",
            "subTitle": "Вопрос №",
            "isArray": true,
            "page": 1,
            "fields": [
              {
                "sysName": "response[]_responseId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": "true",
                "required": "false"
              },
              {
                "sysName": "response[]_pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": false
              },
              {
                "sysName": "response[]_question",
                "localName": "Текст вопроса стартапу",
                "type": "string",
                "edited": true,
                "required": false,
                "maxLength": "100"
              }
              ]
          }
        ]
        }'::json::json, "name"='Создание пилота', description='Укажите краткое описание запрашиваемой технологии в именительном падеже' WHERE formname='New_Pilot';
UPDATE public.screen SET   formview='{
        "form": [{
               "fields": [{
                        "sysName": "businessunit",
                        "localName": "Подразделение",
                        "note": "Потребность какого подразделения компании вы хотите закрыть?",
                        "type": "string",
                        "format": "bold",
                        "edited": false,
                        "required": false
                    }, {
                        "sysName": "suggestCase",
                        "localName": "",
                        "type": "string",
                        "edited": false,
                        "required": false
                    },{
                        "sysName": "industry",
                        "localName": "",
                        "type": "array",
                        "format": "chip",
                        "activity": [3000],
                        "edited": false,
                        "required": false,
                        "multySelect": false
                    }, {
    "sysName": "demoFile",
    "localName": "Дополнительные материалы",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "edited": false,
    "required": false
  }
                ]
            }
        ]
    }'::json::json WHERE formname='pilot_Client';

UPDATE public.screen SET formedit=' {"form": [
          {
            "module": "Основная информация",
            "moduleNote": "",
            "page": 1,
            "fields": [
              {
                "sysName": "pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": true
              },{
                "sysName": "name",
                "localName": "Название пилота",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "140",
                "showLength": false
              },{
                "sysName": "suggestCase",
                "localName": "Краткое описание запроса",
                "type": "string",
                "note": "Какую потребность стартапы будут решать в рамках пилота?",
                "edited": true,
                "required": true,
                "maxLength": "300"
              },
              {
                "sysName": "businessUnit",
                "localName": "Подразделение",
                "note": "Потребность какого подразделения компании вы хотите закрыть?",
                "type": "string",
                "edited": true,
                "required": true,
                "maxLength": "200",
                "showLength": false
              },
              {
                "sysName": "industry",
                "localName": "Индустрии",
                "type": "array",
                "format": "serch_dropdown",
                "activity": [
                  3000
                ],
                "edited": true,
                "required": false,
                "multySelect": true
              }, {
        "sysName": "file",
        "localName": "Дополнительные материалы",
        "description": "Вы можете вложить более подробное ТЗ на пилот или описание кейса pdf-файлом. Поле опциоональное.",
        "note": "Pdf файл до 5 МБ",
        "type": "hyperlink",
        "format": "URL",
        "allowedTypes": [".pdf"],
        "edited": true,
        "required": false
      },
              {
                "sysName": "file",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "value": true,
                "edited": true,
                "required": true
              },
              {
                "sysName": "isHub",
                "localName": "Разрешить загрузку файлов",
                "note": "Стартапы смогут загружать презентации под вашу бизнеса-потребность",
                "type": "boolean",
                "format": "hide",
                "edited": true,
                "value": "true",
                "required": false
              }
            ]
          },
          {
            "module": "Вопросы стартапу",
            "moduleNote": "Здесь Вы можете задать дополнительные вопросы стартапу, на которые необходимо ответить при подаче заявки на пилот",
            "actionText": "Добавить вопрос",
            "subTitle": "Вопрос №",
            "isArray": true,
            "page": 1,
            "fields": [
              {
                "sysName": "response[]_responseId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": "true",
                "required": "false"
              },
              {
                "sysName": "response[]_pilotId",
                "localName": "",
                "type": "int",
                "format": "hide",
                "edited": true,
                "required": false
              },
              {
                "sysName": "response[]_question",
                "localName": "Текст вопроса стартапу",
                "type": "string",
                "edited": true,
                "required": false,
                "maxLength": "100"
              }
              ]
          }
        ]
        }'::json::json, "name"='Редактирование пилота' WHERE formname='pilot_edit';
