--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-5463

INSERT INTO pages (code, "name", uri, description, page_type, page, lang_id) VALUES('investors_tariff_auth_en', 'Choose a plan | SberUnity', '/select-tariff-inv', 'Choose a plan', 'auth', '{
           "features":[
              {
                 "type":"spacer",
                 "visible":true,
                 "position":1,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"backButton",
                 "label":"Back",
                 "sysName":"back",
                 "visible":true,
                 "position":2
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":2,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Choose a plan",
                 "sysName":"title",
                 "visible":true,
                 "position":3,
                 "config":{
                    "styles":{
                       "padding":{
                          "xs":{
                             "top":16,
                             "bottom":8
                          },
                          "s":{
                             "top":16,
                             "bottom":8
                          },
                          "md":{
                             "top":24,
                             "bottom":16
                          },
                          "lg":{
                             "top":24,
                             "bottom":16
                          }
                       }
                    }
                 }
              },
              {
                 "type":"baseText",
                 "size":{
                    "mobile":"m",
                    "desktop":"l"
                 },
                 "text":"Depending on the plan you choose, you will have access to different SberUnity features",
                 "visible":true,
                 "position":4,
                 "sysName":"baseText"
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":5,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":32,
                    "desktop":40
                 }
              },
              {
                 "type":"tariffs",
                 "visible":true,
                 "position":6,
                 "sysName":"tariffs",
                 "tariffs":[
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"InvestLight",
                       "nameTariff":"Light",
                       "priceTariff":"12 000 rubles annually",
                       "descriptionTariff":[
                          "Brief description of the startup",
                          "9 investment requests available",
                          "1 user"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=2&tariff=InvestLight",
                          "text": " %isInvestLightText% ",
                          "disabled": " %isInvestLight% "
                       },
                       "isBestTariff":false,
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       }
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"InvestAngel",
                       "nameTariff":"Pro Angel Investor",
                       "priceTariff":"60 000 rubles annually",
                       "descriptionTariff":[
                          "Registration as an individual",
                          "Full startup information",
                          "All investment requests",
                          "All notifications",
                          "1 user"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=2&tariff=InvestAngel",
                          "text": " %isInvestAngelText% ",
                          "disabled": " %isInvestAngel% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":true
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"InvestPro",
                       "nameTariff":"Pro Fund",
                       "priceTariff":"120 000 rubles annually",
                       "descriptionTariff":[
                          "For venture funds and family office ",
                          "Full startup information",
                          "All investment requests",
                          "All notifications",
                          "Up to 3 users"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=2&tariff=InvestPro",
                          "text": " %isInvestProText% ",
                          "disabled": " %isInvestPro% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    }
                 ]
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":6,
                 "sysName":"spacer2",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":48,
                    "desktop":64
                 }
              },
              {
                 "type":"tariffsTable",
                 "position":7,
                 "sysName":"tariffsTable",
                 "visible":true,
                 "header":{
                    "highlightHeader":"Participant database",
                    "tariffs":[
                       "Light",
                       "Pro Angel Investor",
                       "Pro Fund"
                    ]
                 },
                 "content":[
                    {
                       "type":"subAdvantagesName",
                       "text":"Startup database"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Brief description of the startup"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Full startup informationv"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Full startup information"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Investment requests"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"9 last requests"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All startup requests"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All startup requests"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Filtration"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"By industry only"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All filters"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All filters"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Platfrom features"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Recommended startups"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only 3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Unlimited"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Unlimited"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Favorites"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Valid for 30 days"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Viewed"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Valid for 30 days"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Availability"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Number of users"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"3"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Email notifications"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only reminders"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All notifications"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All notifications"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"PR promotion"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Priority display in the list of investors"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"7 days per year"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Promotional emails to SberUnity subscribers"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 mailing activity, 1 news line in the digest"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Post in SberUnity Telegram channel"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 news line in the digest"
                    }
                 ],
                 "buttons":[
                    {
                       "type": " %isInvestLightButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"InvestLight"
                    },
                    {
                       "type": " %isInvestAngelButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"InvestAngel"
                    },
                    {
                       "type": " %isInvestProButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"InvestPro"
                    },
                    {
                       "type":"buttonMobile",
                       "text":"Choose a plan"
                    }
                 ],
                 "popup":{
                    "icon":"icIllustrationsSuccess",
                    "title":"Would you like to submit a request to change tariff plan?",
                    "text":"Our manager will contact you shortly",
                    "buttons":[
                       {
                          "type":"submit",
                          "text":"Submit",
                          "variant":"contained",
                          "colorScheme":"orange-gradient"
                       },
                       {
                          "type":"cancel",
                          "text":"Cancel",
                          "variant":"text",
                          "colorScheme":"link"
                       }
                    ]
                 },
                 "config":{
                    "nowrap":false,
                    "styles":{
                       "backgroundColor":"#fff",
                       "padding":{
                          "xs":{
                             "top":4,
                             "bottom":32
                          },
                          "s":{
                             "top":4,
                             "bottom":32
                          },
                          "md":{
                             "top":12,
                             "bottom":32
                          },
                          "lg":{
                             "top":12,
                             "bottom":32
                          }
                       }
                    }
                 }
              }
           ]
        }'::json::json, 2);
INSERT INTO pages (code, "name", uri, description, page_type, page, lang_id) VALUES('corporations_tariff_auth_en', 'Choose a plan | SberUnity', '/select-tariff-corp', 'Choose a plan', 'auth', '{
           "features":[
              {
                 "type":"spacer",
                 "visible":true,
                 "position":1,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"backButton",
                 "label":"Back",
                 "sysName":"back",
                 "visible":true,
                 "position":2
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":2,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Choose a plan",
                 "sysName":"title",
                 "visible":true,
                 "position":3,
                 "config":{
                    "styles":{
                       "padding":{
                          "xs":{
                             "top":16,
                             "bottom":8
                          },
                          "s":{
                             "top":16,
                             "bottom":8
                          },
                          "md":{
                             "top":24,
                             "bottom":16
                          },
                          "lg":{
                             "top":24,
                             "bottom":16
                          }
                       }
                    }
                 }
              },
              {
                 "type":"baseText",
                 "size":{
                    "mobile":"m",
                    "desktop":"l"
                 },
                 "text":"Depending on the plan you choose, you will have access to different SberUnity features",
                 "visible":true,
                 "position":4,
                 "sysName":"baseText"
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":5,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":32,
                    "desktop":40
                 }
              },
              {
                 "type":"tariffs",
                 "visible":true,
                 "position":6,
                 "sysName":"tariffs",
                 "tariffs":[
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpLight",
                       "nameTariff":"Light",
                       "priceTariff":"12 000 ₽ в год",
                       "descriptionTariff":[
                          "Brief description of the startup",
                          "5 corporate technology requests",
                          "Limited notifications",
                          "1 user"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpLight",
                          "text": " %isCorpLightText% ",
                          "disabled": " %isCorpLight% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpPro",
                       "nameTariff":"Pro",
                       "priceTariff":"1 200 000 rubles annually",
                       "descriptionTariff":[
                          "Full startup information",
                          "Unlimited technology requests",
                          "All notifications are available",
                          "Up to 3 users"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpPro",
                          "text": " %isCorpProText% ",
                          "disabled": " %isCorpPro% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":true
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpProPlus",
                       "nameTariff":"Pro Plus",
                       "priceTariff":"2 000 000  rubles annually",
                       "descriptionTariff":[
                          "All the advantages of the Pro plan",
                          "PR promotion on the platform",
                          "Scouting service included",
                          "Up to 5 users"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpProPlus",
                          "text": " %isCorpProPlusText% ",
                          "disabled": " %isCorpProPlus% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    }
                 ]
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":6,
                 "sysName":"spacer2",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":48,
                    "desktop":64
                 }
              },
              {
                 "type":"tariffsTable",
                 "position":7,
                 "sysName":"tariffsTable",
                 "visible":true,
                 "header":{
                    "highlightHeader":"Participants database",
                    "tariffs":[
                       "Light",
                       "Pro",
                       "Pro Plus"
                    ]
                 },
                 "content":[
                    {
                       "type":"subAdvantagesName",
                       "text":"Startups database"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Brief description of the startup"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Full startup information"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Full startup information"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Investors database"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Filtration"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only by industry"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All filters"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All filters"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Platfrom features"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Recommended startups"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only 3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Unlimited"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Unlimited"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Favorites"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Valid for 30 days"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Viewed"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Valid for 30 days"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Availability"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Number of users"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"5"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Email notifications"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only request responses"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All notifications"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All notifications"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"More"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Scouting (3 technological requests)"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"PR promotion"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Priority display in the list of corporations"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"No priority"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"7 days per year"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"30 days per year"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Promotional emails to SberUnity subscribers"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 time per digest"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 mailing activity, 1 news line in the digest"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Post in SberUnity Telegram channel"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 time per digest"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 post, 1 news line in the digest"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Post in SberStartup Telegram channel"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 mailing activity, 1 news line in the digest"
                    }
                 ],
                 "buttons":[
                    {
                       "type": " %isCorpLightButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"CorpLight"
                    },
                    {
                       "type": " %isCorpProButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"CorpPro"
                    },
                    {
                       "type": " %isCorpProPlusButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"CorpProPlus"
                    },
                    {
                       "type":"buttonMobile",
                       "text":"Choose a plan"
                    }
                 ],
                 "popup":{
                    "icon":"icIllustrationsSuccess",
                    "title":"Would you like to submit a request to change tariff plan?",
                    "text":"Our manager will contact you shortly.",
                    "buttons":[
                       {
                          "type":"submit",
                          "text":"Submit",
                          "variant":"contained",
                          "colorScheme":"orange-gradient"
                       },
                       {
                          "type":"cancel",
                          "text":"Cancel",
                          "variant":"text",
                          "colorScheme":"link"
                       }
                    ]
                 },
                 "config":{
                    "nowrap":false,
                    "styles":{
                       "backgroundColor":"#fff",
                       "padding":{
                          "xs":{
                             "top":4,
                             "bottom":32
                          },
                          "s":{
                             "top":4,
                             "bottom":32
                          },
                          "md":{
                             "top":12,
                             "bottom":32
                          },
                          "lg":{
                             "top":12,
                             "bottom":32
                          }
                       }
                    }
                 }
              }
           ]
        }'::json::json, 2);
INSERT INTO pages (code, "name", uri, description, page_type, page, lang_id) VALUES('tariff_auth_en', 'Choose a plan | SberUnity', '/select-tariff', 'Choose a plan', 'auth', '{
           "features":[
              {
                 "type":"spacer",
                 "visible":true,
                 "position":1,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"backButton",
                 "label":"Back",
                 "sysName":"back",
                 "visible":true,
                 "position":2
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":2,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":24,
                    "desktop":24
                 }
              },
              {
                 "type":"pageTitle",
                 "title":"Choose a plan",
                 "sysName":"title",
                 "visible":true,
                 "position":3,
                 "config":{
                    "styles":{
                       "padding":{
                          "xs":{
                             "top":16,
                             "bottom":8
                          },
                          "s":{
                             "top":16,
                             "bottom":8
                          },
                          "md":{
                             "top":24,
                             "bottom":16
                          },
                          "lg":{
                             "top":24,
                             "bottom":16
                          }
                       }
                    }
                 }
              },
              {
                 "type":"baseText",
                 "size":{
                    "mobile":"m",
                    "desktop":"l"
                 },
                 "text":"Depending on the plan you choose, you will have access to different SberUnity features",
                 "visible":true,
                 "position":4,
                 "sysName":"baseText"
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":5,
                 "sysName":"spacer",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":32,
                    "desktop":40
                 }
              },
              {
                 "type":"tariffs",
                 "visible":true,
                 "position":6,
                 "sysName":"tariffs",
                 "tariffs":[
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpLight",
                       "nameTariff":"Light",
                       "priceTariff":"12 000 rubles annually",
                       "descriptionTariff":[
                          "Brief description of the startup",
                          "5 corporate technology requests",
                          "Limited notifications",
                          "1 user"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpLight",
                          "text": " %isCorpLightText% ",
                          "disabled": " %isCorpLight% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpPro",
                       "nameTariff":"Pro",
                       "priceTariff":"1 200 000 rubles annually",
                       "descriptionTariff":[
                          "Full startup information",
                          "Unlimited technology requests",
                          "All notifications are available",
                          "Up to 3 users"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpPro",
                          "text": " %isCorpProText% ",
                          "disabled": " %isCorpPro% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":true
                    },
                    {
                       "columns":{
                          "xs":2,
                          "sm":2,
                          "md":4
                       },
                       "sysNameTariff":"CorpProPlus",
                       "nameTariff":"Pro Plus",
                       "priceTariff":"2 000 000 rubles annually",
                       "descriptionTariff":[
                          "All the advantages of the Pro plan",
                          "PR promotion on the platform",
                          "Scouting service included",
                          "Up to 5 users"
                       ],
                       "button":{
                          "linkTo":"/pre-questionnaire?type=1&tariff=CorpProPlus",
                          "text": " %isCorpProPlusText% ",
                          "disabled": " %isCorpProPlus% "
                       },
                       "popup":{
                          "icon":"icIllustrationsSuccess",
                          "title":"Would you like to submit a request to change tariff plan?",
                          "text":"Our manager will contact you shortly.",
                          "buttons":[
                             {
                                "type":"submit",
                                "text":"Submit",
                                "variant":"contained",
                                "colorScheme":"orange-gradient"
                             },
                             {
                                "type":"cancel",
                                "text":"Cancel",
                                "variant":"text",
                                "colorScheme":"link"
                             }
                          ]
                       },
                       "isBestTariff":false
                    }
                 ]
              },
              {
                 "type":"spacer",
                 "visible":true,
                 "position":6,
                 "sysName":"spacer2",
                 "width":{
                    "mobile":"100%",
                    "desktop":"100%"
                 },
                 "height":{
                    "mobile":48,
                    "desktop":64
                 }
              },
              {
                 "type":"tariffsTable",
                 "position":7,
                 "sysName":"tariffsTable",
                 "visible":true,
                 "header":{
                    "highlightHeader":"Participants database",
                    "tariffs":[
                       "Light",
                       "Pro",
                       "Pro Plus"
                    ]
                 },
                 "content":[
                    {
                       "type":"subAdvantagesName",
                       "text":"Startups database"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Brief description of the startup"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Full startup information"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Full startup information"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Investors database"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Filtration"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only by industry"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All filters"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All filters"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Platfrom features"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Recommended startups"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only 3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Unlimited"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Unlimited"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Favorites"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Valid for 30 days"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Viewed"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Valid for 30 days"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"Availability"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Number of users"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"3"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"5"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Email notifications"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"Only request responses"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All notifications"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"All notifications"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"More"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Scouting (3 technological requests)"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsAccess"
                    },
                    {
                       "type":"highlightHeaderSticky",
                       "text":"PR promotion"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Priority display in the list of corporations"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"No priority"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"7 days per year"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"30 days per year"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Promotional emails to SberUnity subscribers"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 time per digest"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 mailing activity, 1 news line in the digest"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Post in SberUnity Telegram channel"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 time per digest"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 post, 1 news line in the digest"
                    },
                    {
                       "type":"subAdvantagesName",
                       "text":"Post in SberStartup Telegram channel"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseIcon",
                       "name":"icTariffsDecline"
                    },
                    {
                       "type":"highlightBaseText",
                       "text":"1 post, 1 news line in the digest"
                    }
                 ],
                 "buttons":[
                    {
                       "type": " %isCorpLightButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"CorpLight"
                    },
                    {
                       "type": " %isCorpProButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"CorpPro"
                    },
                    {
                       "type": " %isCorpProPlusButton% ",
                       "text":"Choose a plan",
                       "sysNameTariff":"CorpProPlus"
                    },
                    {
                       "type":"buttonMobile",
                       "text":"Choose a plan"
                    }
                 ],
                 "popup":{
                    "icon":"icIllustrationsSuccess",
                    "title":"Would you like to submit a request to change tariff plan?",
                    "text":"Our manager will contact you shortly.",
                    "buttons":[
                       {
                          "type":"submit",
                          "text":"Submit",
                          "variant":"contained",
                          "colorScheme":"orange-gradient"
                       },
                       {
                          "type":"cancel",
                          "text":"Cancel",
                          "variant":"text",
                          "colorScheme":"link"
                       }
                    ]
                 },
                 "config":{
                    "nowrap":false,
                    "styles":{
                       "backgroundColor":"#fff",
                       "padding":{
                          "xs":{
                             "top":4,
                             "bottom":32
                          },
                          "s":{
                             "top":4,
                             "bottom":32
                          },
                          "md":{
                             "top":12,
                             "bottom":32
                          },
                          "lg":{
                             "top":12,
                             "bottom":32
                          }
                       }
                    }
                 }
              }
           ]
        }'::json::json, 2);
