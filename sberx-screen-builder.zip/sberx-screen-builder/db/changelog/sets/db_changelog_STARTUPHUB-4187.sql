--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-4187

UPDATE public.pages SET  page='{
  "features": [
    {
      "type": "breadcrumbs",
      "items": [
        {
          "id": 0,
          "name": "Главная",
          "pathname": "/"
        },
        {
          "id": 1,
          "name": "Выбор роли",
          "pathname": "/participant-registration"
        },
        {
          "id": 2,
          "name": "Инвестор"
        }
      ],
      "visible": true,
      "position": 1,
      "sysName": "breadcrumbs"
    },
    {
      "type": "pageTitle",
      "title": "Выберите тариф",
      "sysName": "title",
      "visible": true,
      "position": 2,
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 8
            },
            "s": {
              "top": 16,
              "bottom": 8
            },
            "md": {
              "top": 24,
              "bottom": 16
            },
            "lg": {
              "top": 24,
              "bottom": 16
            }
          }
        }
      }
    },
    {
      "type": "baseText",
      "size": {
        "mobile": "m",
        "desktop": "l"
      },
      "text": "В зависимости от выбранного тарифа, вам будут доступны разные возможности SberUnity",
      "visible": true,
      "position": 3,
      "sysName": "baseText"
    },
    {
      "type": "spacer",
      "visible": true,
      "position": 4,
      "sysName": "spacer",
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "height": {
        "mobile": 32,
        "desktop": 40
      }
    },
    {
      "type": "tariffs",
      "visible": true,
      "position": 5,
      "sysName": "tariffs",
      "tariffs": [
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Demo",
          "priceTariff": "12 000 ₽ в год",
          "descriptionTariff": [
            "Краткая информация о&nbsp;стартапе",
            "Доступно 9 запросов на&nbsp;инвестиции",
            "1 пользователь"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=2&tariff=InvestDemo",
            "text": "Выбрать тариф"
          },
          "isBestTariff": false
        },
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Pro Бизнес-ангел",
          "priceTariff": "60 000 ₽ в год",
          "descriptionTariff": [
            "Размещение от&nbsp;физлица",
            "Полная информация о&nbsp;стартапе",
            "Все запросы на&nbsp;инвестиции",
            "Все уведомления",
            "1 пользователь"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=2&tariff=InvestAngel",
            "text": "Выбрать тариф"
          },
          "isBestTariff": true
        },
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Pro Фонд",
          "priceTariff": "120 000 ₽ в год",
          "descriptionTariff": [
            "Для венчурных фондов и&nbsp;family&nbsp;office",
            "Полная информация о&nbsp;стартапе",
            "Все запросы на&nbsp;инвестиции",
            "Все уведомления",
            "До 3 пользователя"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=2&tariff=InvestPro",
            "text": "Выбрать тариф"
          },
          "isBestTariff": false
        }
      ]
    },
    {
      "type": "spacer",
      "visible": true,
      "position": 6,
      "sysName": "spacer2",
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "height": {
        "mobile": 48,
        "desktop": 64
      }
    },
    {
      "type": "tariffsTable",
      "position": 7,
      "sysName": "tariffsTable",
      "visible": true,
      "header": {
        "highlightHeader": "Базы участников",
        "tariffs": ["Demo", "Pro Бизнес-ангел", "Pro Фонд"]
      },
      "content": [
        {
          "type": "subAdvantagesName",
          "text": "База стартапов"
        },
        {
          "type": "highlightBaseText",
          "text": "Краткая информация о&nbsp;стартапе"
        },
        {
          "type": "highlightBaseText",
          "text": "Полная информация о&nbsp;стартапе"
        },
        {
          "type": "highlightBaseText",
          "text": "Полная информация о&nbsp;стартапе"
        },
        {
          "type": "subAdvantagesName",
          "text": "Запросы на инвестиции"
        },
        {
          "type": "highlightBaseText",
          "text": "9 последних запросов"
        },
        {
          "type": "highlightBaseText",
          "text": "Все запросы стартапов"
        },
        {
          "type": "highlightBaseText",
          "text": "Все запросы стартапов"
        },
        {
          "type": "subAdvantagesName",
          "text": "Фильтрация"
        },
        {
          "type": "highlightBaseText",
          "text": "Только по индустриям"
        },
        {
          "type": "highlightBaseText",
          "text": "Все фильтры"
        },
        {
          "type": "highlightBaseText",
          "text": "Все фильтры"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "Функции платформы"
        },
        {
          "type": "subAdvantagesName",
          "text": "Рекомендованные стартапы"
        },
        {
          "type": "highlightBaseText",
          "text": "Только 3"
        },
        {
          "type": "highlightBaseText",
          "text": "Без ограничений"
        },
        {
          "type": "highlightBaseText",
          "text": "Без ограничений"
        },
        {
          "type": "subAdvantagesName",
          "text": "Избранные"
        },
        {
          "type": "highlightBaseText",
          "text": "Сохранение на 30 дней"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "subAdvantagesName",
          "text": "Просмотренные"
        },
        {
          "type": "highlightBaseText",
          "text": "Сохранение на 30 дней"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "Доступность"
        },
        {
          "type": "subAdvantagesName",
          "text": "Количество пользователей"
        },
        {
          "type": "highlightBaseText",
          "text": "1"
        },
        {
          "type": "highlightBaseText",
          "text": "1"
        },
        {
          "type": "highlightBaseText",
          "text": "3"
        },
        {
          "type": "subAdvantagesName",
          "text": "Уведомления на почту"
        },
        {
          "type": "highlightBaseText",
          "text": "Только напоминания"
        },
        {
          "type": "highlightBaseText",
          "text": "Все уведомления"
        },
        {
          "type": "highlightBaseText",
          "text": "Все уведомления"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "PR-продвижение"
        },
        {
          "type": "subAdvantagesName",
          "text": "Приоритетный показ в списке инвесторов"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "7 дней в год"
        },
        {
          "type": "subAdvantagesName",
          "text": "Email-рассылка по базе SberUnity"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 рассылка, 1&nbsp;новость в&nbsp;дайджесте"
        },
        {
          "type": "subAdvantagesName",
          "text": "Пост в телеграм-канале SberUnity"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 новость в&nbsp;дайджесте"
        }
      ],
      "buttons": [
        {
          "type": "buttonLink",
          "text": "Выбрать тариф",
          "linkTo": "/pre-questionnaire?type=2&tariff=InvestDemo"
        },
        {
          "type": "buttonLink",
          "text": "Выбрать тариф",
          "linkTo": "/pre-questionnaire?type=2&tariff=InvestAngel"
        },
        {
          "type": "buttonLink",
          "text": "Выбрать тариф",
          "linkTo": "/pre-questionnaire?type=2&tariff=InvestPro"
        },
        {
          "type": "buttonMobile",
          "text": "Выбрать тариф"
        }
      ],
      "config": {
        "nowrap": true,
        "styles": {
          "backgroundColor": "#fff",
          "padding": {
            "xs": {
              "top": 0,
              "bottom": 24
            },
            "s": {
              "top": 0,
              "bottom": 24
            },
            "md": {
              "top": 16,
              "bottom": 48
            },
            "lg": {
              "top": 16,
              "bottom": 48
            }
          }
        }
      }
    }
  ]
}'::json::json WHERE code='participant-registration_investor_ru' and lang_id=1;

delete from public.pages where code = 'participant-registration_investor_en';


INSERT INTO public.pages (code, "name", uri, description, page_type, page, lang_id) VALUES('participant-registration_investor_en', 'SberUnity Registration Investors', '/participant-registration/investor', 'We unite startups, corporations and investors. Fill out the application to join', 'unauth', '{
  "features": [
    {
      "type": "breadcrumbs",
      "items": [
        {
          "id": 0,
          "name": "Main",
          "pathname": "/"
        },
        {
          "id": 1,
          "name": "Choose your role",
          "pathname": "/participant-registration"
        },
        {
          "id": 2,
          "name": "Investor"
        }
      ],
      "visible": true,
      "position": 1,
      "sysName": "breadcrumbs"
    },
    {
      "type": "pageTitle",
      "title": "Choose a plan",
      "sysName": "title",
      "visible": true,
      "position": 2,
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 8
            },
            "s": {
              "top": 16,
              "bottom": 8
            },
            "md": {
              "top": 24,
              "bottom": 16
            },
            "lg": {
              "top": 24,
              "bottom": 16
            }
          }
        }
      }
    },
    {
      "type": "baseText",
      "size": {
        "mobile": "m",
        "desktop": "l"
      },
      "text": "Depending on the plan you choose, you will have access to different SberUnity features",
      "visible": true,
      "position": 3,
      "sysName": "baseText"
    },
    {
      "type": "spacer",
      "visible": true,
      "position": 4,
      "sysName": "spacer",
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "height": {
        "mobile": 32,
        "desktop": 40
      }
    },
    {
      "type": "tariffs",
      "visible": true,
      "position": 5,
      "sysName": "tariffs",
      "tariffs": [
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Demo",
          "priceTariff": "12 000 ₽ annually",
          "descriptionTariff": [
            "Brief description of&nbsp;the startup",
            "9 investment requests&nbsp;available",
            "1 user"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=2&tariff=InvestDemo",
            "text": "Choose a plan"
          },
          "isBestTariff": false
        },
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Pro Angel Investor",
          "priceTariff": "60 000 ₽ annually",
          "descriptionTariff": [
            "Registration as&nbsp;an individual",
            "Full startup&nbsp;information",
            "All investment&nbsp;requests",
            "All notifications&nbsp;are available",
            "1 user"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=2&tariff=InvestAngel",
            "text": "Choose a plan"
          },
          "isBestTariff": true
        },
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Pro Fund",
          "priceTariff": "120 000 ₽ annually",
          "descriptionTariff": [
            "For venture funds and&nbsp;family&nbsp;offices",
            "Full startup&nbsp;information",
            "All investment&nbsp;requests",
            "All notifications&nbsp;are available",
            "Up to 3 users"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=2&tariff=InvestPro",
            "text": "Choose a plan"
          },
          "isBestTariff": false
        }
      ]
    },
    {
      "type": "spacer",
      "visible": true,
      "position": 6,
      "sysName": "spacer2",
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "height": {
        "mobile": 48,
        "desktop": 64
      }
    },
    {
      "type": "tariffsTable",
      "position": 7,
      "sysName": "tariffsTable",
      "visible": true,
      "header": {
        "highlightHeader": "Participant database",
        "tariffs": ["Demo", "Pro Angel Investor", "Pro Fund"]
      },
      "content": [
        {
          "type": "subAdvantagesName",
          "text": "Startup database"
        },
        {
          "type": "highlightBaseText",
          "text": "Brief description of&nbsp;the startup"
        },
        {
          "type": "highlightBaseText",
          "text": "Full startup information"
        },
        {
          "type": "highlightBaseText",
          "text": "Full startup information"
        },
        {
          "type": "subAdvantagesName",
          "text": "Investment requests"
        },
        {
          "type": "highlightBaseText",
          "text": "9 last requests"
        },
        {
          "type": "highlightBaseText",
          "text": "All startup requests"
        },
        {
          "type": "highlightBaseText",
          "text": "All startup requests"
        },
        {
          "type": "subAdvantagesName",
          "text": "Filtration"
        },
        {
          "type": "highlightBaseText",
          "text": "Only by industry"
        },
        {
          "type": "highlightBaseText",
          "text": "All filters"
        },
        {
          "type": "highlightBaseText",
          "text": "All filters"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "Platfrom features"
        },
        {
          "type": "subAdvantagesName",
          "text": "Recommended startups"
        },
        {
          "type": "highlightBaseText",
          "text": "Only 3"
        },
        {
          "type": "highlightBaseText",
          "text": "Unlimited"
        },
        {
          "type": "highlightBaseText",
          "text": "Unlimited"
        },
        {
          "type": "subAdvantagesName",
          "text": "Favorites"
        },
        {
          "type": "highlightBaseText",
          "text": "Valid for 30 days"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "subAdvantagesName",
          "text": "Viewed"
        },
        {
          "type": "highlightBaseText",
          "text": "Valid for 30 days"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "Availability"
        },
        {
          "type": "subAdvantagesName",
          "text": "Number of users"
        },
        {
          "type": "highlightBaseText",
          "text": "1"
        },
        {
          "type": "highlightBaseText",
          "text": "1"
        },
        {
          "type": "highlightBaseText",
          "text": "3"
        },
        {
          "type": "subAdvantagesName",
          "text": "Email notifications"
        },
        {
          "type": "highlightBaseText",
          "text": "Reminders only"
        },
        {
          "type": "highlightBaseText",
          "text": "All notifications"
        },
        {
          "type": "highlightBaseText",
          "text": "All notifications"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "PR promotion"
        },
        {
          "type": "subAdvantagesName",
          "text": "Priority display in the list of investors"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "7 days per year"
        },
        {
          "type": "subAdvantagesName",
          "text": "Promotional emails to SberUnity subscribers"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 mailing activity, 1&nbsp;news line in&nbsp;the digest"
        },
        {
          "type": "subAdvantagesName",
          "text": "Post in SberUnity Telegram channel"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 news line in&nbsp;the digest"
        }
      ],
      "buttons": [
        {
          "type": "buttonLink",
          "text": "Choose a plan",
          "linkTo": "/pre-questionnaire?type=2&tariff=InvestDemo"
        },
        {
          "type": "buttonLink",
          "text": "Choose a plan",
          "linkTo": "/pre-questionnaire?type=2&tariff=InvestAngel"
        },
        {
          "type": "buttonLink",
          "text": "Choose a plan",
          "linkTo": "/pre-questionnaire?type=2&tariff=InvestPro"
        },
        {
          "type": "buttonMobile",
          "text": "Choose a plan"
        }
      ],
      "config": {
        "nowrap": true,
        "styles": {
          "backgroundColor": "#fff",
          "padding": {
            "xs": {
              "top": 0,
              "bottom": 24
            },
            "s": {
              "top": 0,
              "bottom": 24
            },
            "md": {
              "top": 16,
              "bottom": 48
            },
            "lg": {
              "top": 16,
              "bottom": 48
            }
          }
        }
      }
    }
  ]
}'::json::json, 2);

delete from public.pages where code = 'participant-registration_corporate_en';
INSERT INTO public.pages (code, "name", uri, description, page_type, page, lang_id) VALUES('participant-registration_corporate_en', 'SberUnity Registration Corporations', '/participant-registration/corporate', 'We unite startups, corporations and investors. Fill out the application to join', 'unauth', '{
  "features": [
    {
      "type": "breadcrumbs",
      "items": [
        {
          "id": 0,
          "name": "Main",
          "pathname": "/"
        },
        {
          "id": 1,
          "name": "Choose your role",
          "pathname": "/participant-registration"
        },
        {
          "id": 2,
          "name": "Corporation"
        }
      ],
      "visible": true,
      "position": 1,
      "sysName": "breadcrumbs"
    },
    {
      "type": "pageTitle",
      "title": "Choose a plan",
      "sysName": "title",
      "visible": true,
      "position": 2,
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 8
            },
            "s": {
              "top": 16,
              "bottom": 8
            },
            "md": {
              "top": 24,
              "bottom": 16
            },
            "lg": {
              "top": 24,
              "bottom": 16
            }
          }
        }
      }
    },
    {
      "type": "baseText",
      "size": {
        "mobile": "m",
        "desktop": "l"
      },
      "text": "Depending on the plan you choose, you will have access to different SberUnity features",
      "visible": true,
      "position": 3,
      "sysName": "baseText"
    },
    {
      "type": "spacer",
      "visible": true,
      "position": 4,
      "sysName": "spacer",
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "height": {
        "mobile": 32,
        "desktop": 40
      }
    },
    {
      "type": "tariffs",
      "visible": true,
      "position": 5,
      "sysName": "tariffs",
      "tariffs": [
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Demo",
          "priceTariff": "12 000 ₽ annually",
          "descriptionTariff": [
            "Brief description of&nbsp;the startup",
            "5 corporate&nbsp;technology requests",
            "Limited notifications",
            "1 user"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=1&tariff=CorpDemo",
            "text": "Choose a plan"
          },
          "isBestTariff": false
        },
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Pro",
          "priceTariff": "1 200 000 ₽ annually",
          "descriptionTariff": [
            "Full startup information",
            "Unlimited technology&nbsp;requests",
            "All notifications are available",
            "Up to 3 users"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=1&tariff=CorpPro",
            "text": "Choose a plan"
          },
          "isBestTariff": true
        },
        {
          "columns": {
            "xs": 2,
            "sm": 2,
            "md": 4
          },
          "nameTariff": "Pro Plus",
          "priceTariff": "2 000 000 ₽ annually",
          "descriptionTariff": [
            "All the advantages of the Pro plan",
            "PR promotion on&nbsp;the platform",
            "Scouting service included",
            "Up to 5 users"
          ],
          "button": {
            "linkTo": "/pre-questionnaire?type=1&tariff=CorpProPlus",
            "text": "Choose a plan"
          },
          "isBestTariff": false
        }
      ]
    },
    {
      "type": "spacer",
      "visible": true,
      "position": 6,
      "sysName": "spacer2",
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "height": {
        "mobile": 48,
        "desktop": 64
      }
    },
    {
      "type": "tariffsTable",
      "position": 7,
      "sysName": "tariffsTable",
      "visible": true,
      "header": {
        "highlightHeader": "Participants database",
        "tariffs": ["Demo", "Pro", "Pro Plus"]
      },
      "content": [
        {
          "type": "subAdvantagesName",
          "text": "Startups database"
        },
        {
          "type": "highlightBaseText",
          "text": "Brief description of&nbsp;the startup"
        },
        {
          "type": "highlightBaseText",
          "text": "Full startup information"
        },
        {
          "type": "highlightBaseText",
          "text": "Full startup information"
        },
        {
          "type": "subAdvantagesName",
          "text": "Investors database"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "subAdvantagesName",
          "text": "Filtration"
        },
        {
          "type": "highlightBaseText",
          "text": "Industry only"
        },
        {
          "type": "highlightBaseText",
          "text": "All filters"
        },
        {
          "type": "highlightBaseText",
          "text": "All filters"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "Platfrom features"
        },
        {
          "type": "subAdvantagesName",
          "text": "Recommended startups"
        },
        {
          "type": "highlightBaseText",
          "text": "Up to 3"
        },
        {
          "type": "highlightBaseText",
          "text": "Unlimited"
        },
        {
          "type": "highlightBaseText",
          "text": "Unlimited"
        },
        {
          "type": "subAdvantagesName",
          "text": "Favorites"
        },
        {
          "type": "highlightBaseText",
          "text": "Valid for 30 days"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "subAdvantagesName",
          "text": "Viewed"
        },
        {
          "type": "highlightBaseText",
          "text": "Valid for 30 days"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "Availability"
        },
        {
          "type": "subAdvantagesName",
          "text": "Number of users"
        },
        {
          "type": "highlightBaseText",
          "text": "1"
        },
        {
          "type": "highlightBaseText",
          "text": "3"
        },
        {
          "type": "highlightBaseText",
          "text": "5"
        },
        {
          "type": "subAdvantagesName",
          "text": "Email notifications"
        },
        {
          "type": "highlightBaseText",
          "text": "Request responses&nbsp;only"
        },
        {
          "type": "highlightBaseText",
          "text": "All notifications&nbsp;are available"
        },
        {
          "type": "highlightBaseText",
          "text": "All notifications&nbsp;are available"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "More"
        },
        {
          "type": "subAdvantagesName",
          "text": "Scouting&nbsp;(3 technological requests)"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsAccess"
        },
        {
          "type": "highlightHeaderSticky",
          "text": "PR promotion"
        },
        {
          "type": "subAdvantagesName",
          "text": "Priority display in the list of corporations"
        },
        {
          "type": "highlightBaseText",
          "text": "No priority"
        },
        {
          "type": "highlightBaseText",
          "text": "7 days per year"
        },
        {
          "type": "highlightBaseText",
          "text": "30 days per year"
        },
        {
          "type": "subAdvantagesName",
          "text": "Promotional emails to&nbsp;SberUnity subscribers"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 time per digest"
        },
        {
          "type": "highlightBaseText",
          "text": "1 mailing activity, 1&nbsp; news line in&nbsp;the digest"
        },
        {
          "type": "subAdvantagesName",
          "text": "Post in SberUnity Telegram channel"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 time per digest"
        },
        {
          "type": "highlightBaseText",
          "text": "1 post, 1&nbsp;news line in&nbsp;the digest"
        },
        {
          "type": "subAdvantagesName",
          "text": "Post in SberStartup Telegram channel"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseIcon",
          "name": "icTariffsDecline"
        },
        {
          "type": "highlightBaseText",
          "text": "1 post, 1&nbsp;news line in&nbsp;the digest"
        }
      ],
      "buttons": [
        {
          "type": "buttonLink",
          "text": "Choose a plan",
          "linkTo": "/pre-questionnaire?type=1&tariff=CorpDemo"
        },
        {
          "type": "buttonLink",
          "text": "Choose a plan",
          "linkTo": "/pre-questionnaire?type=1&tariff=CorpPro"
        },
        {
          "type": "buttonLink",
          "text": "Choose a plan",
          "linkTo": "/pre-questionnaire?type=1&tariff=CorpProPlus"
        },
        {
          "type": "buttonMobile",
          "text": "Choose a plan"
        }
      ],
      "config": {
        "nowrap": true,
        "styles": {
          "backgroundColor": "#fff",
          "padding": {
            "xs": {
              "top": 0,
              "bottom": 24
            },
            "s": {
              "top": 0,
              "bottom": 24
            },
            "md": {
              "top": 16,
              "bottom": 48
            },
            "lg": {
              "top": 16,
              "bottom": 48
            }
          }
        }
      }
    }
  ]
}'::json::json, 2);

