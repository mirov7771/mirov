--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-5239 Правка JSON для скаутинга
update public.pages
set
    page ='{
   "features":[
      {
         "type":"welcomeScreen",
         "visible":true,
         "position":1,
         "buttons":[
            {
               "text":"Заказать подбор",
               "url":"",
               "theme":"orange-gradient",
               "config":{
                  "scouting":{
                     "link":"/view?action=2&type=13&name=New_scouting"
                  }
               }
            }
         ],
         "imageUrl":"/file/scoutingBanner.png",
         "subtitle":"Подбор стартапов",
         "title":"Закажите скаутинг стартапов",
         "description":"В данном разделе вы можете заказать услугу подбора стартапов профессиональными скаутами и аналитиками Сбера под ваш персональный запрос",
         "buttonDescription": " %available_scouting% ",
         "backgroundColorChip":"#F2F4F6",
         "welcomeScreenTheme":"baseBanner"
      },
      {
         "type":"squareList",
         "visible":true,
         "position":2,
         "title":"Отберём лучших для вас",
         "theme":"base",
         "isMobileCarousel":false,
         "items":[
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_document_with_star.png",
               "title":"Сформируем воронку проектов",
               "description":"по заданным параметрам",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_filter.png",
               "title":"Подготовим лонг-лист и шорт-лист",
               "description":"с презентацией, собственной первичной оценкой и другими материалами",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_two_persons.png",
               "title":"Организуем питч-сессию и интро",
               "description":"с понравившимися проектами",
               "isExternal":true
            }
         ]
      },
      {
         "type":"photoGallery",
         "visible":true,
         "position":3,
         "title":"Проведём питч-сессию онлайн или на площадке современного коворкинга",
         "description":"Для получения дополнительной информации, обсуждения условий и ваших потребностей, напишите нам на почту [sberunity@sberbank.ru](mailto:sberunity@sberbank.ru) с пометкой «Скаутинг» или обратитесь к вашему персональному менеджеру",
         "images":[
            "/file/photo_4077.jpg",
            "/file/photo_4078.jpg",
            "/file/photo_4079.jpg"
         ],
         "carouselResponsiveConfig":{
            "sm":{
               "slideGap":40,
               "slidesToShow":1,
               "showArrows":true
            },
            "md":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "lg":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "xl":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            }
         }
      }
   ]
}'
where
        code = 'scouting_az_ru';

update public.pages
set
    page ='{
   "features":[
      {
         "type":"welcomeScreen",
         "visible":true,
         "position":1,
         "buttons":[
            {
               "text":"Order a selection",
               "url":"",
               "theme":"orange-gradient",
               "config":{
                  "scouting":{
                     "link":"/view?action=2&type=13&name=New_scouting"
                  }
               }
            }
         ],
         "imageUrl":"/file/scoutingBanner.png",
         "subtitle":"Selection of startups",
         "title":"Order startup scouting",
         "description":"In this section, you can order the service of selecting startups by professional scouts and Sber analysts for your personal request",
         "buttonDescription": " %available_scouting% ",
         "backgroundColorChip":"#F2F4F6",
         "welcomeScreenTheme":"baseBanner"
      },
      {
         "type":"squareList",
         "visible":true,
         "position":2,
         "title":"Selecting the best for you",
         "theme":"base",
         "isMobileCarousel":false,
         "items":[
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_document_with_star.png",
               "title":"Form a funnel of projects",
               "description":"on specified parameters",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_filter.png",
               "title":"Prepare a long-list and a short-list",
               "description":"with presentation, own initial evaluation and other materials",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_two_persons.png",
               "title":"Organize a pitch session and intro",
               "description":"with favorite projects",
               "isExternal":true
            }
         ]
      },
      {
         "type":"photoGallery",
         "visible":true,
         "position":3,
         "title":"Hold a pitch session online or in a modern co-working space",
         "description":"For more information, to discuss the conditions and your needs, write to us by mail [sberunity@sberbank.ru](mailto:sberunity@sberbank.ru) marked «Scouting» or contact your personal manager",
         "images":[
            "/file/photo_4077.jpg",
            "/file/photo_4078.jpg",
            "/file/photo_4079.jpg"
         ],
         "carouselResponsiveConfig":{
            "sm":{
               "slideGap":40,
               "slidesToShow":1,
               "showArrows":true
            },
            "md":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "lg":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "xl":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            }
         }
      }
   ]
}'
where
        code = 'scouting_az_en';
