--liquibase formatted sql
--changeset Zakutskiy MY:reply_view
delete
from pages
where uri = '/reply-view' and lang_id = 1;

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('reply_view_ru', 'Просмотр отклика', '/reply-view', 'Просмотр отклика АЗ', 'auth', '{
  "features": [
    {
      "type": "backButton",
      "sysName": "",
      "visible": true,
      "position": 1,
      "label": "назад",
      "link": "/main/reply"
    },
    {
      "type": "questionnaireView",
      "sysName": "",
      "visible": true,
      "position": 2,
      "backButtonTitle": "назад",
      "adminCommentTitles": {
        "title": "Необходима дополнительная информация",
        "additionalInfo": "Комментарий администратора:"
      },
      "config": {
        "nowrap": true
      }
    }
  ]
}'::json::json, 1);