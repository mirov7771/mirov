--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-4495
update public.feature
set config = '[8 (499) 673-12-69](tel:8(499)673-12-69)'
where form_name = 'FooterPhone';