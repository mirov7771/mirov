--liquibase formatted sql
--changeset Timoshkin MA:STARTUBHUB-3174

alter table features
    drop column if exists client_id;

alter table feature_attributes_values
    drop constraint if exists feature_attributes_values_id_attributes_id_features_key,
    add constraint  feature_attributes_values_afg_key unique (id_attributes, id_features, group_id);

truncate feature_attributes_values;
INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
--"type" : "mainHeader"
--"visible": true,
(1,1,1,1,DEFAULT,'published',DEFAULT),
--"position": 1,
(2,2,2,1,DEFAULT,'published',DEFAULT),
--"header": "СберСтартап",
(3,21,3,1,DEFAULT,'published',DEFAULT),
--"title": "сообщество",
(4,22,4,1,DEFAULT,'published',DEFAULT),
--"description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
(5,23,5,1,DEFAULT,'published',DEFAULT),
--"features": [
(6,31,265,1,DEFAULT,'published',DEFAULT),
    -- {
        --"type" : "button"
        --"category": "simple"
        (7,24,6,2,6,'published',DEFAULT),
        --"visible": true,
        (8,1,7,2,6,'published',DEFAULT),
        --"default": "active",
        (9,10,8,2,6,'published',DEFAULT),
        --"text": "Стать частью сообщества",
        (10,25,9,2,6,'published',DEFAULT),
        --"iconUrl": null,
        (11,26,335,2,6,'published',DEFAULT),
        --"url": "",
        (12,27,10,2,6,'published',DEFAULT),
        --"action": "redirect"
        (13,11,11,2,6,'published',DEFAULT),
        --"config":{}
        (14,4,261,2,6,'published',DEFAULT),
    -- }
    -- {
        --"type" : "bigNSmallGallery"
        --"visible": true,
        (15,1,12,3,6,'published',DEFAULT),
        --"images": [
        (16,33,336,3,6,'published',DEFAULT),
            --[1]
                --"url": "https://cons.ru/im.jpg",
                (17,27,13,3,16,'published',1),
                --"isMain": true
                (18,9,14,3,16,'published',1),
            --[2]
                --"url": "https://cons.ru/im.jpg",
                (19,27,15,3,16,'published',2),
                --"isMain": true
                (20,9,16,3,16,'published',2),
        -- ]
        --"config":{}
        (21,4,262,3,6,'published',DEFAULT),
    -- }
-- ]
--"config": {}
(22,4,260,1,DEFAULT,'published',DEFAULT),


--"type": mainTabs
--"visible": true,
(23,1,17,4,DEFAULT,'published',DEFAULT),
--"position": 2,
(24,2,18,4,DEFAULT,'published',DEFAULT),
--"config": {}
(25,4,298,4,DEFAULT,'published',DEFAULT),
--"items" : [
(26,6,263,4,DEFAULT,'published',DEFAULT),
        --[1]
            --"title": "Стартапам",
            (27,22,19,4,26,'published',1),
            --"visible": true,
            (28,1,20,4,26,'published',1),
            --"isDefault": true,
            (29,7,21,4,26,'published',1),
            --"isActive": true,
            (30,8,22,4,26,'published',1),
            --"badgeText": null,
            (31,28,337,4,26,'published',1),
            --"iconUrl": "https://cons.ru/im.jpg",
            (32,26,23,4,26,'published',1),
            --"position": 1
            (33,2,43,4,26,'published',1),
            --"config": {}
            (34,4,264,4,26,'published',1),
            --"features": [
            (35,31,267,4,26,'published',1),
                -- {
                        --"type":"squareList"
                        --"title": "Что вам будет доступно"
                        (36,22,24,5,35,'published',DEFAULT),
                        --"items" : [
                        (37,6,266,5,35,'published',DEFAULT),
                                --[1]
                                    --"title": "Нетворкинг"
                                    (38,22,25,5,37,'published',1),
                                    --"description": "Живое общение с близкими по интересам",
                                    (39,23,26,5,37,'published',1),
                                    --"iconUrl": "https://cons.ru/im.jpg"
                                    (40,26,27,5,37,'published',1),
                                --[2]
                                    --"title": "Экспертиза",
                                    (41,22,28,5,37,'published',2),
                                    --"description": "Консультации от профи",
                                    (42,23,29,5,37,'published',2),
                                    --"iconUrl": "https://cons.ru/im.jpg"
                                    (43,26,30,5,37,'published',2),
                                --[3]
                                    --"title": "Контент",
                                    (44,22,31,5,37,'published',3),
                                    --"description": "Актуальные новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
                                    (45,23,32,5,37,'published',3),
                                    --"iconUrl": "https://cons.ru/im.jpg"
                                    (46,26,33,5,37,'published',3),
                                --[4]
                                    --"title": "Мероприятия",
                                    (47,22,34,5,37,'published',4),
                                    --"description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
                                    (48,23,35,5,37,'published',4),
                                    --"iconUrl": "https://cons.ru/im.jpg"
                                    (49,26,36,5,37,'published',4),
                                --[5]
                                    --"title": "Закрытый стартап-клуб",
                                    (50,22,37,5,37,'published',5),
                                    --"description": "Эксклюзивные мероприятия с инвесторами",
                                    (51,23,38,5,37,'published',5),
                                    --"iconUrl": "https://cons.ru/im.jpg"
                                    (52,26,39,5,37,'published',5),
                                --[6]
                                    --"title": "Поддержка",
                                    (53,22,40,5,37,'published',6),
                                    --"description": "Обмен опытом и помощь в решении бизнес-кейсов",
                                    (54,23,41,5,37,'published',6),
                                    --"iconUrl": "https://cons.ru/im.jpg"
                                    (55,26,42,5,37,'published',6),
                        -- ]
                        --"position": 1
                        (56,2,341,5,35,'published',DEFAULT),
                        --"config": {}
                        (57,4,342,5,35,'published',DEFAULT),
                -- }
                -- {
                        --"type": "flatTabs",
                        --"header": "Как попасть в сообщество СберСтартап",
                        (58,21,44,6,35,'published',DEFAULT),
                        --"visible": true,
                        (59,1,45,6,35,'published',DEFAULT),
                        --"items": [
                        (60,6,268,6,35,'published',DEFAULT),
                            --[1]
                                    --"title": "Новым участникам"
                                    (61,22,46,6,60,'published',1),
                                    --"isDefault": true,
                                    (62,7,47,6,60,'published',1),
                                    --"position": 1
                                    (63,2,48,6,60,'published',1),
                                    --"features": [
                                    (64,31,269,6,60,'published',1),
                                            -- {
                                                --"type": "roadMap",
                                                --"visible": true,
                                                (65,1,49,7,64,'published',DEFAULT),
                                                --"position": 1,
                                                (66,2,50,7,64,'published',DEFAULT),
                                                --"config": {},
                                                (67,4,270,7,64,'published',DEFAULT),
                                                --"items": [
                                                (68,6,271,7,64,'published',DEFAULT),
                                                        --[1]
                                                            --"title": "Зарегистрируйтесь на платформе",
                                                            (69,22,51,7,68,'published',1),
                                                            --"description": "Станьте резидентом SberUnity, чтобы присоединиться к сообществу",
                                                            (70,23,52,7,68,'published',1),
                                                            --"iconUrl": "https://cons.ru/im.jpg"
                                                            (71,26,53,7,68,'published',1),
                                                        --[2]
                                                            --"title": "Заполните анкету сообщества",
                                                            (72,22,54,7,68,'published',2),
                                                            --"description": "Она находится в личном кабинете в разделе «Сообщество»",
                                                            (73,23,55,7,68,'published',2),
                                                            --"iconUrl": "https://cons.ru/im.jpg"
                                                            (74,26,56,7,68,'published',2),
                                                        --[3]
                                                            --"title": "Дождитесь результата",
                                                            (75,22,57,7,68,'published',3),
                                                            --"description": "В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью",
                                                            (76,23,58,7,68,'published',3),
                                                            --"iconUrl": "https://cons.ru/im.jpg"
                                                            (77,26,59,7,68,'published',3),
                                                        --[4]
                                                            --"title": "Присоединитесь к нам",
                                                            (78,22,60,7,68,'published',4),
                                                            --"description": "После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                                                            (79,23,61,7,68,'published',4),
                                                            --"iconUrl": "https://cons.ru/im.jpg"
                                                            (80,26,62,7,68,'published',4),
                                                -- ]
                                            -- }
                                    -- ]
                            --[2]
                                    --"title": "Участникам SberUnity",
                                    (81,22,63,6,60,'published',2),
                                    --"isDefault": false,
                                    (82,7,64,6,60,'published',2),
                                    --"position": 2,
                                    (83,2,65,6,60,'published',2),
                                    --"features": [
                                    (84,31,273,6,60,'published',2),
                                        -- {
                                            --"type": "roadMap",
                                            --"visible": true,
                                            (85,1,66,8,84,'published',DEFAULT),
                                            --"position": 1,
                                            (86,2,67,8,84,'published',DEFAULT),
                                            --"config": {},
                                            (87,4,274,8,84,'published',DEFAULT),
                                            --"items": [
                                            (88,6,275,8,84,'published',DEFAULT),
                                                    --[1]
                                                        --"title": "Заполните анкету сообщества",
                                                        (89,22,68,8,88,'published',1),
                                                        --"description": "Она находится в личном кабинете в разделе «Сообщество»",
                                                        (90,23,69,8,88,'published',1),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (91,26,70,8,88,'published',1),
                                                    --[2]
                                                        --"title": "Дождитесь результата",
                                                        (92,22,71,8,88,'published',2),
                                                        --"description": "В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью",
                                                        (93,23,72,8,88,'published',2),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (94,26,73,8,88,'published',2),
                                                    --[3]
                                                        --"title": "Присоединитесь к нам",
                                                        (95,22,74,8,88,'published',3),
                                                        --"description": "После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                                                        (96,23,75,8,88,'published',3),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (97,26,76,8,88,'published',3),
                                            -- ]
                                        -- }
                                    -- ]
                        -- ]
                        --"config": {},
                        (98,4,276,6,35,'published',DEFAULT),
                        --"position": 1
                        (99,2,77,6,35,'published',DEFAULT),
                -- }
                -- {
                        --"type": "nearby"
                        --"header": "Мы рядом с вами",
                        (100,21,78,9,35,'published',DEFAULT),
                        --"visible": true,
                        (101,1,79,9,35,'published',DEFAULT),
                        --"features": [
                        (102,31,277,9,35,'published',DEFAULT),
                                -- {
                                        --"type": "banner"
                                        --"title": "Онлайн",
                                        (103,22,80,10,102,'published',DEFAULT),
                                        --"visible": true,
                                        (104,1,81,10,102,'published',DEFAULT),
                                        --"description": "На платформе Telegram и онлайн-событиях",
                                        (105,23,82,10,102,'published',DEFAULT),
                                        --"iconUrl": "https://cons.ru/im.jpg",
                                        (106,26,83,10,102,'published',DEFAULT),
                                        --"tablePosition": {
                                        (107,3,278,10,102,'published',DEFAULT),
                                                --"row": 1,
                                                (108,19,84,10,107,'published',DEFAULT),
                                                --"column": 1
                                                (109,20,85,10,107,'published',DEFAULT),
                                        -- }
                                        --"config": {}
                                        (110,4,279,10,102,'published',DEFAULT),
                                -- }
                                -- {
                                        --"type": "banner"
                                        --"title": "Оффлайн",
                                        (111,22,86,11,102,'published',DEFAULT),
                                        --"visible": true,
                                        (112,1,87,11,102,'published',DEFAULT),
                                        --"description": "В собственном коворкинге и на закрытых встречах",
                                        (113,23,88,11,102,'published',DEFAULT),
                                        --"iconUrl": "https://cons.ru/im.jpg",
                                        (114,26,89,11,102,'published',DEFAULT),
                                        --"tablePosition": {
                                        (115,3,280,11,102,'published',DEFAULT),
                                                --"row": 2,
                                                (116,19,90,11,115,'published',DEFAULT),
                                                --"column": 1
                                                (117,20,91,11,115,'published',DEFAULT),
                                        -- }
                                        --"config":{}
                                        (118,4,281,11,102,'published',DEFAULT),
                                -- }
                                -- {
                                        --"type": "banner"
                                        --"title": "Сообщество СберСтартап",
                                        (119,22,92,12,102,'published',DEFAULT),
                                        --"visible": true,
                                        (120,1,93,12,102,'published',DEFAULT),
                                        --"description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
                                        (121,23,94,12,102,'published',DEFAULT),
                                        --"backgroundUrl": "https://cons.ru/im.jpg",
                                        (122,29,95,12,102,'published',DEFAULT),
                                        --"tablePosition": {
                                        (123,3,282,12,102,'published',DEFAULT),
                                                --"row": 1,
                                                (124,19,101,12,123,'published',DEFAULT),
                                                --"column": 2
                                                (125,20,102,12,123,'published',DEFAULT),
                                        -- }
                                        --"config": {}
                                        (126,4,283,12,102,'published',DEFAULT),
                                        --"features": {
                                        (127,31,284,12,102,'published',DEFAULT),
                                                --"type": "button"
                                                --"category": "simple",
                                                (128,24,96,13,127,'published',DEFAULT),
                                                --"default": "active",
                                                (129,10,97,13,127,'published',DEFAULT),
                                                --"text": "Стать частью сообщества",
                                                (130,25,98,13,127,'published',DEFAULT),
                                                --"iconUrl": null,
                                                (131,26,99,13,127,'published',DEFAULT),
                                                --"url": "/anketa/zspolnenie",
                                                (132,27,100,13,127,'published',DEFAULT),
                                                --"action": "redirect",
                                                (133,11,343,13,127,'published',DEFAULT),
                                                --"config": {}
                                                (134,4,285,13,127,'published',DEFAULT),
                                        -- }
                                -- }
                        -- ]
                        --"config": {
                        (135,4,286,9,35,'published',DEFAULT),
                            --"tableConfiguration": [
                            (136,12,287,9,135,'published',DEFAULT),
                                    --[1]
                                        --"columnNumber": 1,
                                        (137,13,103,9,136,'published',1),
                                        --"rows": 2,
                                        (138,14,104,9,136,'published',1),
                                    --[2]
                                        --"columnNumber": 2,
                                        (139,13,105,9,136,'published',2),
                                        --"rows": 1
                                        (140,14,106,9,136,'published',2),
                            -- ]
                        -- }
                        --"position": 3
                        (141,2,344,9,35,'published',DEFAULT),
                -- }
            --]

        --[2]
            --"title": "Инвесторам",
            (142,22,288,4,26,'published',2),
            --"visible": true,
            (143,1,109,4,26,'published',2),
            --"isDefault": false,
            (144,7,110,4,26,'published',2),
            --"isActive": true,
            (145,8,111,4,26,'published',2),
            --"badgeText": null,
            (146,28,339,4,26,'published',2),
            --"iconUrl": "https://cons.ru/im.jpg",
            (147,26,112,4,26,'published',2),
            --"features": [
            (148,31,289,4,26,'published',2),
                 -- {
                        --"type": "bulletBanner",
                        --"visible": true,
                        (149,1,113,14,148,'published',DEFAULT),
                        --"header": "Соинвестируйте с профессионалами рынка",
                        (150,21,114,14,148,'published',DEFAULT),
                        --"description": null,
                        (151,23,338,14,148,'published',DEFAULT),
                        --"bullets": ["Снижайте риски, соинвестируя с лучшими венчурными фондами","Обеспечьте себе поток лучших сделок","Расширьте портфель за счёт низкого входного чека","Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"],
                        (152,30,115,14,148,'published',DEFAULT),
                        --"config": {
                        (153,4,290,14,148,'published',DEFAULT),
                                --"direction": "left"
                                (154,15,116,14,153,'published',DEFAULT),
                        -- }
                        --"position": 1
                        (155,2,117,14,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "rectangTiles",
                        --"visible": true,
                        (156,1,118,15,148,'published',DEFAULT),
                        --"header": "Уже в сообществе",
                        (157,21,119,15,148,'published',DEFAULT),
                        --"description": null,
                        (158,23,340,15,148,'published',DEFAULT),
                        --"items": ["https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg"],
                        (159,6,120,15,148,'published',DEFAULT),
                        --"config": {},
                        (160,4,291,15,148,'published',DEFAULT),
                        --"position": 2
                        (161,2,121,15,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "squareRow",
                        --"visible": true,
                        (162,1,122,16,148,'published',DEFAULT),
                        --"header": "Большая воронка стартапов на российском рынке",
                        (163,21,123,16,148,'published',DEFAULT),
                        --"description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
                        (164,23,124,16,148,'published',DEFAULT),
                        --"items": [
                        (165,6,292,16,148,'published',DEFAULT),
                                --[1]
                                        --"title": "Знакомим",
                                        (166,22,125,16,165,'published',1),
                                        --"description": "с основателями стартапов",
                                        (167,23,126,16,165,'published',1),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (168,26,127,16,165,'published',1),
                                --[2]
                                        --"title": "Проводим",
                                        (169,22,128,16,165,'published',2),
                                        --"description": "предварительный скоринг",
                                        (170,23,129,16,165,'published',2),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (171,26,130,16,165,'published',2),
                                --[3]
                                        --"title": "Рекомендуем",
                                        (172,22,131,16,165,'published',3),
                                        --"description": "только отобранные проекты",
                                        (173,23,132,16,165,'published',3),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (174,26,133,16,165,'published',3),
                                --[4]
                                        --"title": "Объединяем",
                                        (175,22,134,16,165,'published',4),
                                        --"description": "инвесторов и стартапы",
                                        (176,23,135,16,165,'published',4),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (177,26,136,16,165,'published',4),
                        -- ]
                        --"config": {},
                        (178,4,293,16,148,'published',DEFAULT),
                        --"position": 3
                        (179,2,137,16,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "rectangTiles",
                        --"visible": true,
                        (180,1,138,17,148,'published',DEFAULT),
                        --"header": "Наши акселераторы",
                        (181,21,139,17,148,'published',DEFAULT),
                        --"description": null,
                        (182,23,345,17,148,'published',DEFAULT),
                        --"items": ["https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg"],
                        (183,6,140,17,148,'published',DEFAULT),
                        --"config": {},
                        (184,4,294,17,148,'published',DEFAULT),
                        --"position": 4
                        (185,2,141,17,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "bulletBanner"
                        --"visible": true,
                        (186,1,142,18,148,'published',DEFAULT),
                        --"header": "Всё, что нужно — уже под рукой",
                        (187,21,143,18,148,'published',DEFAULT),
                        --"description": "Мы организовали сообщество в Slack-каналах",
                        (188,23,144,18,148,'published',DEFAULT),
                        --"bullets": ["Разделяйте деловые и личные мессенджеры","Структурируйте инофрмацию в тематических каналах","Только релевантные сообщения, без спама и рекламы","Полная информация о сделке всегда доступна"],
                        (189,30,145,18,148,'published',DEFAULT),
                        --"config": {
                        (190,4,295,18,148,'published',DEFAULT),
                                --"direction": "left"
                                (191,15,146,18,190,'published',DEFAULT),
                        -- }
                        --"position": 3
                        (192,2,147,18,148,'published',DEFAULT),
                -- }
            -- ]
            --"position": 2
            (193,2,148,4,26,'published',2),
            --"configuration": {}
            (194,4,296,4,26,'published',2),
        --[3]
            --"title": "Корпорациям",
            (195,22,149,4,26,'published',3),
            --"visible": true,
            (196,1,150,4,26,'published',3),
            --"isDefault": false,
            (197,7,151,4,26,'published',3),
            --"isActive": false,
            (198,8,152,4,26,'published',3),
            --"badgeText": "Скоро",
            (199,28,153,4,26,'published',3),
            --"iconUrl": "https://cons.ru/im.jpg",
            (200,26,154,4,26,'published',3),
            --"config": {},
            (201,2,155,4,26,'published',3),
            --"position": 3
            (202,4,297,4,26,'published',3),
-- ]



--"type": "carousel",
--"visible": true,
(203,1,156,19,DEFAULT,'published',DEFAULT),
--"position": 3,
(204,2,157,19,DEFAULT,'published',DEFAULT),
--"header": "Направления сообщества",
(205,21,158,19,DEFAULT,'published',DEFAULT),
--"description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем Вас стать частью проектов сообщества",
(206,23,159,19,DEFAULT,'published',DEFAULT),
--"items": ["https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg"],
(207,6,160,19,DEFAULT,'published',DEFAULT),
--"config": {
(208,4,299,19,DEFAULT,'published',DEFAULT),
        --"autorotation": false,
        (209,16,161,19,208,'published',DEFAULT),
        --"delay": 3,
        (210,17,162,19,208,'published',DEFAULT),
        --"speed": 100,
        (211,18,163,19,208,'published',DEFAULT),
        --"direction": "left"
        (212,15,164,19,208,'published',DEFAULT),
-- }



--"type": "events",
--"visible": true,
(213,1,165,20,DEFAULT,'published',DEFAULT),
--"header": "Событийная кухня",
(214,21,166,20,DEFAULT,'published',DEFAULT),
--"title": "Закрывайте бизнес-потребности через нетворкинг",
(215,22,167,20,DEFAULT,'published',DEFAULT),
--"description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для Вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
(216,23,168,20,DEFAULT,'published',DEFAULT),
--"config": {},
(217,4,300,20,DEFAULT,'published',DEFAULT),
--"position": 4,
(218,2,169,20,DEFAULT,'published',DEFAULT),
--"features": [
(219,31,301,20,DEFAULT,'published',DEFAULT),
        -- {
                --"type": "offsetSquares",
                --"visible": true,
                (220,1,170,21,219,'published',DEFAULT),
                --"items": [
                (221,6,302,21,219,'published',DEFAULT),
                            --[1]
                                    --"title": "Партнерские мероприятия",
                                    (222,22,171,21,221,'published',1),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (223,5,172,21,221,'published',1),
                                    --"tablePosition": {
                                    (224,3,303,21,221,'published',1),
                                                --"row": 1,
                                                (225,19,173,21,224,'published',default),
                                                --"column": 1
                                                (226,20,174,21,224,'published',default),
                                    -- }
                            --[2]
                                    --"title": "Хакатоны и интенсивы",
                                    (227,22,175,21,221,'published',2),
                                    --"imageUrl": "https://cons.ru/im.jpg"
                                    (228,5,176,21,221,'published',2),
                                    --"tablePosition": {
                                    (229,3,304,21,221,'published',2),
                                                --"row": 1,
                                                (230,19,177,21,229,'published',DEFAULT),
                                                --"column": 2
                                                (231,20,178,21,229,'published',DEFAULT),
                                    -- }
                            --[3]
                                    --"title": "Мероприятия с другими фондами и сообществами",
                                    (232,22,179,21,221,'published',3),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (233,5,180,21,221,'published',3),
                                    --"tablePosition": {
                                    (234,3,305,21,221,'published',3),
                                                --"row": 2,
                                                (235,19,181,21,234,'published',DEFAULT),
                                                --"column": 1
                                                (236,20,182,21,234,'published',DEFAULT),
                                    -- }
                            --[4]
                                    --"title": "Выезды и вечеринки",
                                    (237,22,183,21,221,'published',4),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (238,5,184,21,221,'published',4),
                                    --"tablePosition": {
                                    (239,3,306,21,221,'published',4),
                                                --"row": 2,
                                                (240,19,185,21,239,'published',DEFAULT),
                                                --"column": 2
                                                (241,20,186,21,239,'published',DEFAULT),
                                    -- }
                            --[5]
                                    --"title": "Закрытые очные встречи",
                                    (242,22,187,21,221,'published',5),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (243,5,188,21,221,'published',5),
                                    --"tablePosition": {
                                    (244,3,307,21,221,'published',5),
                                                --"row": 3,
                                                (245,19,189,21,244,'published',DEFAULT),
                                                --"column": 1
                                                (246,20,190,21,244,'published',DEFAULT),
                                    -- }
                            --[6]
                                    --"title": "Онлайн-митапы",
                                    (247,22,191,21,221,'published',6),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (248,5,192,21,221,'published',6),
                                    --"tablePosition": {
                                    (249,3,308,21,221,'published',6),
                                                --"row": 3,
                                                (250,19,193,21,249,'published',DEFAULT),
                                                --"column": 2
                                                (251,20,194,21,249,'published',DEFAULT),
                                    -- }

                -- ]
                --"config": {
                (252,4,309,21,219,'published',DEFAULT),
                            --"tableConfiguration": [
                            (253,12,310,21,252,'published',DEFAULT),
                                        --[1]
                                                --"columnNumber": 1,
                                                (254,13,195,21,253,'published',1),
                                                --"rows": 2,
                                                (255,14,196,21,253,'published',1),
                                                --"offsetDirection": null
                                                (256,32,311,21,253,'published',1),
                                        --[2]
                                                --"columnNumber": 2,
                                                (257,13,197,21,253,'published',2),
                                                --"rows": 2,
                                                (258,14,198,21,253,'published',2),
                                                --"offsetDirection": "right"
                                                (259,32,199,21,253,'published',2),
                                        --[3]
                                                --"columnNumber": 3,
                                                (260,13,200,21,253,'published',3),
                                                --"rows": 2,
                                                (261,14,201,21,253,'published',3),
                                                --"offsetDirection": null
                                                (262,32,312,21,253,'published',3),
                            -- ]
                -- }
        -- }
        -- {
                --"type":"button"
                --"category": "simple",
                (263,24,202,22,219,'published',DEFAULT),
                --"visible": true,
                (264,1,203,22,219,'published',DEFAULT),
                --"default": "active",
                (265,10,204,22,219,'published',DEFAULT),
                --"text": "Календарь событий",
                (266,25,205,22,219,'published',DEFAULT),
                --"iconUrl": "https://cons.ru/im.jpg",
                (267,26,206,22,219,'published',DEFAULT),
                --"url": "/anketa/zspolnenie",
                (268,27,207,22,219,'published',DEFAULT),
                --"action": "redirect",
                (269,11,208,22,219,'published',DEFAULT),
                --"config": {}
                (270,4,313,22,219,'published',DEFAULT),
        -- }
-- ]


--"type": "socialTiles"
--"header": "Контент-студия",
(271,21,209,23,DEFAULT,'published',DEFAULT),
--"visible": true,
(272,1,210,23,DEFAULT,'published',DEFAULT),
--"description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
(273,23,211,23,DEFAULT,'published',DEFAULT),
--"items": [
(274,6,314,23,DEFAULT,'published',DEFAULT),
        --[1]
                --"title": "Сберстартап",
                (275,22,212,23,274,'published',1),
                --"category": "Telegram-канал",
                (276,24,213,23,274,'published',1),
                --"imageUrl": "https://cons.ru/im.jpg",
                (277,5,214,23,274,'published',1),
                --"description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
                (278,23,215,23,274,'published',1),
                --"features": [
                (279,31,315,23,274,'published',1),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (280,24,216,24,279,'published',DEFAULT),
                                --"visible": true
                                (281,1,346,24,279,'published',DEFAULT),
                                --"default": "active",
                                (282,10,217,24,279,'published',DEFAULT),
                                --"text": "Подписаться",
                                (283,25,218,24,279,'published',DEFAULT),
                                --"iconUrl": "https://cons.ru/im.jpg",
                                (284,26,219,24,279,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (285,27,220,24,279,'published',DEFAULT),
                                --"action": "redirect"
                                (286,11,221,24,279,'published',DEFAULT),
                                --"config": {}
                                (287,4,316,24,279,'published',DEFAULT),

                        -- }
                -- ]

        --[2]
                --"title": "Три запятые",
                (288,22,222,23,274,'published',2),
                --"category": "Подкаст",
                (289,24,223,23,274,'published',2),
                --"imageUrl": "https://cons.ru/im.jpg",
                (290,5,224,23,274,'published',2),
                --"description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
                (291,23,225,23,274,'published',2),
                --"features": [
                (292,31,317,23,274,'published',2),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (293,24,226,25,292,'published',DEFAULT),
                                --"visible": true
                                (294,1,318,25,292,'published',DEFAULT),
                                --"default": "active",
                                (295,10,227,25,292,'published',DEFAULT),
                                --"text": "Подписаться",
                                (296,25,228,25,292,'published',DEFAULT),
                                --"iconUrl": null,
                                (297,26,319,25,292,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (298,27,229,25,292,'published',DEFAULT),
                                --"action": "redirect"
                                (299,11,230,25,292,'published',DEFAULT),
                                --"config": {}
                                (300,4,320,25,292,'published',DEFAULT),

                        -- }
                -- ]

        --[3]
                --"title": "VC.RU",
                (301,22,231,23,274,'published',3),
                --"category": "Блог",
                (302,24,232,23,274,'published',3),
                --"imageUrl": "https://cons.ru/im.jpg",
                (303,5,233,23,274,'published',3),
                --"description": "Успешные и не очень кейсы участников сообщества",
                (304,23,234,23,274,'published',3),
                --"features": [
                (305,31,321,23,274,'published',3),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (306,24,235,26,305,'published',DEFAULT),
                                --"visible": true
                                (307,1,322,26,305,'published',DEFAULT),
                                --"default": "active",
                                (308,10,236,26,305,'published',DEFAULT),
                                --"text": "Подписаться",
                                (309,25,237,26,305,'published',DEFAULT),
                                --"iconUrl": null,
                                (310,26,323,26,305,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (311,27,238,26,305,'published',DEFAULT),
                                --"action": "redirect"
                                (312,11,239,26,305,'published',DEFAULT),
                                --"config": {}
                                (313,4,324,26,305,'published',DEFAULT),

                        -- }
                -- ]

        --[4]
                --"title": "Для стартапов",
                (314,22,240,23,274,'published',4),
                --"category": "YouTube-шоу",
                (315,24,241,23,274,'published',4),
                --"imageUrl": "https://cons.ru/im.jpg",
                (316,5,242,23,274,'published',4),
                --"description": "Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями",
                (317,23,243,23,274,'published',4),
                --"features": [
                (318,31,325,23,274,'published',4),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (319,24,244,27,318,'published',DEFAULT),
                                --"visible": true
                                (320,1,326,27,318,'published',DEFAULT),
                                --"default": "inactive",
                                (321,10,245,27,318,'published',DEFAULT),
                                --"text": "Скоро",
                                (322,25,246,27,318,'published',DEFAULT),
                                --"iconUrl": "https://cons.ru/im.jpg",
                                (323,26,247,27,318,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (324,27,327,27,318,'published',DEFAULT),
                                --"action": "redirect"
                                (325,11,248,27,318,'published',DEFAULT),
                                --"config": {}
                                (326,4,328,27,318,'published',DEFAULT),
                        -- }
                -- ]

-- ]
--"config": {},
(327,4,329,23,DEFAULT,'published',DEFAULT),
--"position": 5
(328,2,249,23,DEFAULT,'published',DEFAULT),

--"type": "banner",
--"visible": true,
(329,1,250,28,DEFAULT,'published',DEFAULT),
--"position": 6,
(330,2,253,28,DEFAULT,'published',DEFAULT),
--"title": "Подайте заявку и станьте частью сообщества СберСтартап",
(331,22,251,28,DEFAULT,'published',DEFAULT),
--"description": null,
(332,23,330,28,DEFAULT,'published',DEFAULT),
--"backgroundUrl": "https://cons.ru/im.jpg",
(333,29,252,28,DEFAULT,'published',DEFAULT),
--"config": {},
(334,4,331,28,DEFAULT,'published',DEFAULT),
--"features": [
(335,31,332,28,DEFAULT,'published',DEFAULT),
        -- {
                --cFooterBanner_1_button_1
                --"type": "button"
                --"category": "simple",
                (336,24,254,29,335,'published',DEFAULT),
                --"visible": true
                (337,1,333,29,335,'published',DEFAULT),
                --"default": "active",
                (338,10,255,29,335,'published',DEFAULT),
                --"text": "Стать частью сообщества",
                (339,25,256,29,335,'published',DEFAULT),
                --"url": "/anketa/zspolnenie",
                (340,27,257,29,335,'published',DEFAULT),
                --"action": "redirect"
                (341,11,258,29,335,'published',DEFAULT),
                --"config": {}
                (342,4,334,29,335,'published',DEFAULT);

        -- }
-- ]

select setval('public.feature_attributes_values_id_seq',  (SELECT max(id) FROM public.feature_attributes_values));


update public.values
    set value = '5'
where id = 249;

update public.values
set value = '6'
where id = 253;

truncate pages_features;
INSERT INTO public.pages_features (id_features, id_pages, is_visible, id_parent_feature) VALUES
(1,2,TRUE, DEFAULT),
(2,2,TRUE, 1),
(3,2,TRUE, 1),
(4,2,TRUE, DEFAULT),
(5,2,TRUE, 4),
(6,2,TRUE, 4),
(7,2,TRUE, 6),
(8,2,TRUE, 6),
(9,2,TRUE, 4),
(10,2,TRUE, 9),
(11,2,TRUE, 9),
(12,2,TRUE, 9),
(13,2,TRUE, 12),
(14,2,TRUE, 4),
(15,2,TRUE, 4),
(16,2,TRUE, 4),
(17,2,TRUE, 4),
(18,2,TRUE, 4),
(19,2,TRUE, DEFAULT),
(20,2,TRUE, DEFAULT),
(21,2,TRUE, 20),
(22,2,TRUE, 20),
(23,2,TRUE, DEFAULT),
(24,2,TRUE, 23),
(25,2,TRUE, 23),
(26,2,TRUE, 23),
(27,2,TRUE, 23),
(28,2,TRUE, DEFAULT),
(29,2,TRUE, 29);