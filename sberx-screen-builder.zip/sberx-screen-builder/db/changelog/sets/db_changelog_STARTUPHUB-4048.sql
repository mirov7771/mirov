--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-4048

UPDATE public.screen SET  formedit='{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "note": "Укажите полное юридическое название вашей компании",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullName",
          "required": true,
          "localName": "Наименование организации",
          "maxLength": 70,
          "showLength": false
        },
        {
          "note": "Укажите год создания вашей компании",
          "type": "int",
          "edited": true,
          "format": "[1991;2021]",
          "sysName": "questionnaire_birthYear",
          "required": true,
          "localName": "Год регистрации",
          "maxLength": 4,
          "showLength": false
        },
        {
          "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_name",
          "required": true,
          "localName": "Публичное название",
          "maxLength": 100,
          "showLength": false
        },
        {
          "note": "Выберите страну, в которой зарегистрирована ваша компания",
          "type": "array",
          "edited": true,
          "format": "text",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "Страна юрисдикции",
          "multySelect": false
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты"
        },
        {
          "note": "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
          "sysName": "questionnaire_site",
          "required": true,
          "localName": "Сайт корпорации",
          "maxLength": "100",
          "showLength": false,
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
        }
      ],
      "module": "Юридическая информация об организации",
      "pageName": "Юридическая информация об организации",
      "moduleNote": ""
    },
    {
      "page": 2,
      "fields": [
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_fio",
          "required": true,
          "localName": "Имя, фамилия представителя"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_role",
          "required": true,
          "localName": "Должность"
        },
        {
          "mask": "phone",
          "type": "string",
          "edited": true,
          "format": "phone",
          "example": "+",
          "sysName": "representative_phone",
          "required": true,
          "localName": "Мобильный телефон"
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "representative_email",
          "required": true,
          "localName": "Электронная почта"
        }
      ],
      "module": "Контакт представителя",
      "pageName": "Информация о представителе",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
    },
    {
      "page": 2,
      "title": "",
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "boolean",
          "value": false,
          "edited": true,
          "format": "hide",
          "sysName": "workers[]_isFounder",
          "required": false,
          "localName": ""
        },
        {
          "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_fio",
          "required": false,
          "localName": "Имя, фамилия представителя",
          "maxLength": "100",
          "showLength": false
        },
        {
          "note": "Укажите должность ответственного лица из предыдущего вопроса",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Должность",
          "maxLength": "100",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "workers[]_facebook",
          "required": false,
          "localName": "Электронная почта",
          "maxLength": "150",
          "showLength": false
        }
      ],
      "module": "Публичный контакт",
      "isArray": "true",
      "pageName": "Информация о представителе",
      "actionText": "Добавить контактное лицо"
    },
    {
      "page": 3,
      "fields": [
        {
          "note": "Опишите вашу компанию одним предложением",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_note",
          "required": true,
          "localName": "Краткое описание",
          "maxLength": "150"
        },
        {
          "note": "Опишите вашу компанию более подробно",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullNote",
          "required": true,
          "localName": "Полное описание",
          "maxLength": "480"
        },
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_industry",
          "activity": [
            22000
          ],
          "required": true,
          "localName": "Направление деятельности",
          "description": "Укажите все релевантные вашей компании отрасли",
          "multySelect": true
        },
        {
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "title": "Логотип",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png", ".jpg"
          ]
        }
      ],
      "module": "Корпорация",
      "pageName": "Информация о корпорации"
    },
    {
      "page": 4,
      "fields": [
        {
          "type": "array",
          "title": "Методы работы с инновациями",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_innovationMethod",
          "activity": [
            4000
          ],
          "required": true,
          "localName": "Укажите методы",
          "description": "Выберите методы внедрения инноваций в вашей корпорации",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "Стадии развития стартапов",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_stady",
          "activity": [
            7000
          ],
          "required": true,
          "localName": "Стадия развития",
          "description": "Выберите интересующие стадии развития стартапов",
          "multySelect": true
        },
        {
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": true,
          "localName": "Технологии",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": true,
          "localName": "Индустрии",
          "description": "Укажите все релевантные вашей компании направления",
          "multySelect": true
        }
      ],
      "module": "Работа со стартапами",
      "pageName": "Условия работы со стартапами"
    },
    {
      "page": 5,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_successPilots",
          "required": true,
          "localName": "У вашей компании есть опыт сотрудничества со стартапами?"
        },
        {
          "note": "Опционально",
          "type": "int",
          "title": "Информация о сотрудничестве со стартапами",
          "edited": true,
          "sysName": "questionnaire_startupInvestmentYears",
          "required": false,
          "localName": "Сколько лет ваша корпорация работает со стартапами",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_overallPilots",
          "required": false,
          "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_lastYearInvestmentsCount",
          "required": false,
          "localName": "Количество пилотов со стартапами за последний год",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_overallContracts",
          "required": false,
          "localName": "Количество контрактов (внедрений) со стартапами за последний год",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        }
      ],
      "module": "Успешные кейсы",
      "pageName": "Пилотирование"
    },
    {
      "page": 6,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "investment_investment",
          "required": true,
          "localName": "Инвестирует ли ваша корпорация в стартапы?"
        },
        {
          "type": "array",
          "edited": true,
          "format": "chip",
          "sysName": "investment_round",
          "activity": [
            6000
          ],
          "required": true,
          "localName": "Раунд инвестиций",
          "multySelect": true,
          "triggerField": "investment_investment",
          "triggerValue": "true"
        },
        {
          "note": "В стартапы из каких регионов вы готовы инвестировать",
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "География стартапов",
          "multySelect": true,
          "triggerField": "investment_investment",
          "triggerValue": "true"
        }
      ],
      "module": "Инвестиции",
      "pageName": "Инвестиции"
    },
    {
      "page": 6,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "successPilots[]_pilotid",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "successPilots[]_company",
          "required": false,
          "localName": "Название стартапа",
          "maxLength": "140",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "successPilots[]_suggestCase",
          "required": false,
          "localName": "Описание кейса",
          "maxLength": "300",
          "showLength": false
        }
      ],
      "module": "Успешные кейсы",
      "isArray": true,
      "pageName": "Инвестиции",
      "subTitle": "Стартап №",
      "withIndex": true,
      "actionText": "Добавить кейс",
      "moduleNote": "Опционально. Укажите названия стартапов, с которыми у вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
      "triggerField": "investment_investment",
      "triggerValue": true
    },
    {
      "page": 7,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_scouting",
          "required": true,
          "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?"
        },        {

          "sysName": "userConsent_mailingConsent",

          "localName": "Я <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">соглашаюсь</a> на обработку персональных данных для цели проведения аналитических, статистических, маркетинговых исследований и формирования на их основе персональных предложений",

          "type": "boolean",

          "format": "checkbox",

          "edited": true,

          "required": false

        }
      ],
      "module": "Скаутинг",
      "pageName": "Скаутинг"
    }
  ]
}'::json::json

WHERE formname='New_Corporate' and lang_id=1 ;

UPDATE public.screen SET   formedit='{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": true,
          "format": "chip",
          "sysName": "questionnaire_investorType",
          "activity": [
            11000
          ],
          "required": true,
          "localName": "Выберите тип инвестора",
          "multySelect": false
        },
        {
          "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_name",
          "required": true,
          "localName": "Публичное название / название бренда",
          "maxLength": 100,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_name",
          "required": true,
          "localName": "Ваши имя и фамилия",
          "maxLength": 100,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        },
        {
          "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_name",
          "required": true,
          "localName": "Публичное название / название бренда",
          "maxLength": 100,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "type": "int",
          "edited": true,
          "format": "hide",
          "sysName": "questionnaire_questionnaireid",
          "required": true,
          "localName": ""
        },
        {
          "note": "Укажите полное юридическое название вашей компании",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Наименование организации",
          "maxLength": 70,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Укажите год создания вашей компании",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_birthYear",
          "required": true,
          "localName": "Год регистрации",
          "maxLength": 4,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Выберите страну, в которой зарегистрирована ваша компания",
          "type": "array",
          "edited": true,
          "format": "text",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "Страна юрисдикции",
          "multySelect": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Укажите полное юридическое название вашей компании",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Наименование организации",
          "maxLength": 70,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "note": "Укажите год создания вашей компании",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_birthYear",
          "required": true,
          "localName": "Год регистрации",
          "maxLength": 4,
          "showLength": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "note": "Выберите страну, в которой зарегистрирована ваша компания",
          "type": "array",
          "edited": true,
          "format": "text",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "Страна юрисдикции",
          "multySelect": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "type": "string",
          "edited": true,
          "format": "hide",
          "sysName": "representative_facebook",
          "required": false,
          "localName": "Профиль в Facebook"
        }
      ],
      "module": "Общая информация",
      "pageName": "Данные профиля и общая информация"
    },
    {
      "page": 1,
      "fields": [
        {
          "note": "Например, \"Фонд и акселератор\"",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_note",
          "required": true,
          "localName": "Укажите краткое описание вашего фонда",
          "maxLength": 85,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Например, \"Рассматриваю любые проекты\"",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_note",
          "required": true,
          "localName": "Укажите свою краткую характеристику как бизнес-ангела",
          "maxLength": 85,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        },
        {
          "note": "Укажите страну, в которой вы совершаете основной объем венчурных сделок",
          "type": "array",
          "edited": true,
          "format": "text",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "Страна юрисдикции",
          "multySelect": false,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        },
        {
          "note": "Например, \"Фонд семьи Безосов\"",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_note",
          "required": true,
          "localName": "Укажите краткое описание вашего Family Office",
          "maxLength": 85,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullNote",
          "required": true,
          "localName": "Укажите полное описание вашего фонда",
          "maxLength": 1000,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullNote",
          "required": false,
          "localName": "Укажите свою полную характеристику как бизнес-ангела",
          "maxLength": 1000,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullNote",
          "required": true,
          "localName": "Укажите полное описание вашего Family Office",
          "maxLength": 1000,
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
          "sysName": "questionnaire_site",
          "required": true,
          "localName": "Сайт",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "type": "string",
          "edited": false,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
          "sysName": "questionnaire_site",
          "required": false,
          "localName": "Сайт",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        },
        {
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
          "sysName": "questionnaire_site",
          "required": true,
          "localName": "Сайт",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003"
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "title": "Логотип",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": true,
          "localName": "Загрузить логотип",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png", ".jpg"
          ],
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001"
        },
        {
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "title": "Логотип",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png", ".jpg"
          ],
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003"
        },
        {
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "title": "Логотип",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png", ".jpg"
          ],
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004"
        },
        {
          "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
          "type": "logo",
          "title": "Добавьте фото",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить фото",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png", ".jpg"
          ],
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002"
        }
      ],
      "module": "Данные профиля",
      "pageName": "Данные профиля и общая информация"
    },
    {
      "page": 2,
      "fields": [
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_fio",
          "required": true,
          "localName": "Фамилия Имя"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_role",
          "required": true,
          "localName": "Должность"
        },
        {
          "mask": "phone",
          "type": "string",
          "edited": true,
          "format": "phone",
          "example": "+",
          "sysName": "representative_phone",
          "required": true,
          "localName": "Мобильный телефон"
        },
        {
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "sysName": "representative_facebook",
          "required": false,
          "localName": "Профиль в Facebook",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
        }
      ],
      "module": "Контакт представителя",
      "pageName": "Ваши данные",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
    },
    {
      "page": 2,
      "title": "",
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "boolean",
          "value": false,
          "edited": true,
          "format": "hide",
          "sysName": "workers[]_isFounder",
          "required": false,
          "localName": ""
        },
        {
          "note": "Стартапам важно видеть персоналии. Укажите ответственное лицо фонда, которое увидят другие участники платформы.",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_fio",
          "required": false,
          "localName": "Фамилия Имя",
          "maxLength": "100",
          "showLength": false
        },
        {
          "note": "Укажите должность лица из предыдущего вопроса",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Должность",
          "maxLength": "100",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "workers[]_facebook",
          "required": false,
          "localName": "Электронная почта",
          "maxLength": "150",
          "showLength": false
        }
      ],
      "module": "Публичный контакт",
      "isArray": "true",
      "pageName": "Ваши данные",
      "actionText": "Добавить контактное лицо",
      "modulenote": "Укажите сотрудника, которого другие пользователи платформы увидят в вашей анкете в качестве контактного лица"
    },
    {
      "page": 3,
      "fields": [
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "investment_industry",
          "activity": [
            3000
          ],
          "required": true,
          "localName": "Индустрии",
          "multySelect": true
        },
        {
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "investment_technology",
          "activity": [
            13000
          ],
          "required": true,
          "localName": "Технологии",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "География стартапов",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "investment_geography",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "География стартапов",
          "description": "В стартапы из каких регионов вы готовы инвестировать",
          "multySelect": true
        },
        {
          "type": "array",
          "edited": true,
          "format": "chip",
          "sysName": "investment_round",
          "activity": [
            6000
          ],
          "required": true,
          "localName": "Стадии инвестирования",
          "multySelect": true
        },
        {
          "note": "Например, impact startups, female founders и т.д.",
          "type": "string",
          "edited": true,
          "sysName": "investment_note",
          "required": false,
          "localName": "Особые условия инвестирования",
          "maxLength": "300",
          "showLength": false
        }
      ],
      "module": "Инвестиции",
      "pageName": "Инвестиции",
      "moduleNote": "Выберите все технологические направления, стадии стартапов и географию, рассматриваемые вами для инвестиций"
    },
    {
      "page": 3,
      "fields": [
        {
          "note": "Число портфельных проектов на текущий момент",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_activeDealsNumber",
          "required": true,
          "localName": "Количество стартапов в портфеле",
          "maxLength": 4,
          "showLength": false
        },
        {
          "note": "Общее число инвестиционных раундов, включая раунды со стартапами, из которых вы уже вышли",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_allDealsNumber",
          "required": true,
          "localName": "Количество сделок, всего",
          "maxLength": 4,
          "showLength": false
        },
        {
          "note": "Количество стартапов, в которые вы инвестировали и вышли",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_exitDealsNumber",
          "required": true,
          "localName": "Количество выходов",
          "maxLength": 4,
          "showLength": false
        }
      ],
      "module": "Данные о стартапах портфеля",
      "pageName": "Инвестиции"
    },
    {
      "page": 3,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "questionnairePilots[]_pilotid",
          "required": false,
          "localName": ""
        },
        {
          "note": "Опционально",
          "type": "string",
          "edited": true,
          "sysName": "b2bPilots[]_reference",
          "required": false,
          "localName": "Название стартапа",
          "maxLength": "140",
          "showLength": false
        },
        {
          "note": "Опционально",
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
          "sysName": "questionnairePilots[]_site",
          "required": false,
          "localName": "Ссылка на сайт стартапа",
          "maxLength": "140",
          "showLength": false,
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
        }
      ],
      "module": "Примеры стартапов",
      "isArray": "true",
      "pageName": "Инвестиции",
      "withIndex": true,
      "actionText": "Добавить стартап",
      "moduleNote": "Здесь вы можете перечислить все или наиболее интересные стартапы из вашего портфеля"
    },
    {
      "page": 4,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_club",
          "required": true,
          "localName": "Состоите ли вы в каком-либо инвестиционном клубе / сообществе?"
        }
      ],
      "module": "Инвестиционные клубы",
      "pageName": "Участие в инвестиционных клубах"
    },
    {
      "page": 4,
      "fields": [
        {
          "type": "string",
          "edited": true,
          "sysName": "investorClubs[]_name",
          "required": false,
          "localName": "Название клуба / сообщества"
        },
        {
          "note": "Например, \"Основатель клуба\"",
          "type": "string",
          "edited": true,
          "sysName": "investorClubs[]_role",
          "required": false,
          "localName": "Ваша роль в клубе / сообществе"
        }
      ],
      "module": "Сообщества",
      "isArray": "true",
      "pageName": "Участие в инвестиционных клубах",
      "subTitle": "Клуб / сообщество №",
      "withIndex": true,
      "actionText": "Добавить клуб",
      "moduleNote": "Мы будем рады начать сотрудничество с указанными сообществами и предложить дополнительные выгоды его участникам",
      "triggerField": "questionnaire_club",
      "triggerValue": true
    },        {

          "sysName": "userConsent_mailingConsent",

          "localName": "Я <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">соглашаюсь</a> на обработку персональных данных для цели проведения аналитических, статистических, маркетинговых исследований и формирования на их основе персональных предложений",

          "type": "boolean",

          "format": "checkbox",

          "edited": true,

          "required": false

        }
  ]
}'::json::json
WHERE formname='New_Investor' and lang_id=1 ;
UPDATE public.screen SET  formedit='{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Полное юридическое название",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Укажите ваш ИНН или иной регистрационный номер",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Идентификационный номер компании",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Укажите год регистрации юрлица",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "Например, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну юрисдикции",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна регистрации юрлица",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Адрес сайта",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Иванов Иван Иванович",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Контактное лицо"
                },
                {
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Укажите почту для связи",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Электронная почта"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Номер телефона"
                }
            ],
            "module": "Организация",
            "pageName": "Юридическая информация",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Ресурс",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity": [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Адрес ссылки",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Дополнительные ссылки",
            "isArray": "true",
            "pageName": "Юридическая информация",
            "actionText": "Добавить ссылку",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах"
        },
        {
            "page": 2,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите ваш стартап одним предложением",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Краткое описание стартапа",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Модели продаж",
                    "edited": true,
                    "format": "chip",
                    "values": [],
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "Укажите модели взаимодействия с клиентами в вашем бизнесе",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values": [],
                    "example": "Укажите бизнес-модель стартапа",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": true,
                    "localName": "Бизнес-модель",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Выберите стадию развития",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": true,
                    "localName": "Стадия развития стартапа",
                    "multySelect": false
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип стартапа",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes": [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Ссылка на видео",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о стартапе",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Где базируется ваш стартап?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну",
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна",
                    "description": "Укажите, где фактически находится штаб-квартира вашего стартапа",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Введите город",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "Город",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "О стартапе",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите индустрии",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Индустрии и технологические вертикали, в которых функционирует ваш стартап",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите технологии",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                }
            ],
            "module": "Направления",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "Проблема, которую решает ваш продукт",
                    "maxLength": "300"
                },
                {
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите вашу целевую аудиторию",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Целевая аудитория",
                    "maxLength": "300"
                },
                {
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "type": "hyperlink",
                    "title": "Презентация",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes": [
                        ".pdf"
                    ]
                },
                {
                    "note": "Регионы, на которых уже представлен ваш продукт",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Рынки, на которых вы работаете",
                    "multySelect": true
                },
                {
                    "note": "Регионы, на которые вы планируете выйти в ближайший год",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые планируете выходить",
                    "multySelect": true
                },
                {
                    "note": "Укажите стадию продаж вашего продукта",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите тип продаж",
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": true,
                    "localName": "Продажи",
                    "multySelect": true
                },
                {
                    "mask": "$",
                    "note": "Валовый оборот компании за последний год в $",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Оборот в год",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число"
                },
                {
                    "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите название компаний-конкурентов",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Прямые конкуренты",
                    "maxLength": "300"
                },
                {
                    "note": "Перечислите предметно, чем вы лучше конкурентов",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите преимущества вашего продукта",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Преимущества перед конкурентами",
                    "maxLength": "300"
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Укажите число сотрудников в штате",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Количество сотрудников"
                }
            ],
            "module": "О продукте",
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Название должности",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Опишите опыт сотрудника",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Краткое описание опыта",
                    "maxLength": "150"
                }
            ],
            "module": "Ключевые сотрудники",
            "isArray": "true",
            "pageName": "Команда",
            "actionText": "Добавить должность"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Успешные пилоты",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите, с какой корпорацией у вас был успешный кейс",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите про кейс и его результаты",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "actionText": "Добавить кейс",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "title": "Предлагаемый кейс",
                    "edited": true,
                    "example": "Если у вас есть идеи, как можно пилотировать ваш продукт, опишите их в нескольких предложениях",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Есть ли у вас опыт взаимодействия с экосистемой Сбера?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "Экосистема Сбера",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Находитесь ли вы в активном поиске инвестиций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число"
                },
                {
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Список инвесторов",
                    "maxLength": "300"
                },        {

          "sysName": "userConsent_mailingConsent",

          "localName": "Я <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">соглашаюсь</a> на обработку персональных данных для цели проведения аналитических, статистических, маркетинговых исследований и формирования на их основе персональных предложений",

          "type": "boolean",

          "format": "checkbox",

          "edited": true,

          "required": false

        }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": ""
        }
    ]
}'::json::json  WHERE formname='New_StartUp' and lang_id=1;
