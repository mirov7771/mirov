--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-5462

INSERT INTO public.screen ("type", formname, formedit, formview, name, description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(14, 'edit_metric', '{
  "form":
  [
    {
      "page": 1,
      "module": "Metric value",
      "moduleNote": "Specify the metric values on specific dates.",
      "isArray": "true",
      "actionText": "Add value",
      "isControlShow": true,
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "direction": "row",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Value",
          "example": "Choose a number",
          "type": "int",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_value"
        },
        {
          "localName": "Date",
          "example": "Specify a date",
          "type": "date",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_date",
          "maxDate": "",
          "dateError": "The date is incorrect"
        }
      ]
    }
  ]
}'::json::json, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, 2, NULL);
INSERT INTO public.screen ("type", formname, formedit, formview, name, description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(14, 'add_metric_values', '{
  "form":
  [
    {
      "page": 1,
      "moduleNote": "Specify the metric values %metricName% on specific dates.",
      "isArray": "true",
      "actionText": "Add value",
      "isControlShow": true,
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
          "direction": "row",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Choose a number",
          "type": "int",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_value"
        },
        {
          "localName": "Date",
          "example": "Specify a date",
          "type": "date",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_date",
          "maxDate": "",
          "dateError": "The date is incorrect"
        }
      ]
    }
  ]
}'::json::json, NULL, 'Add a value', NULL, 1, NULL, NULL, NULL, NULL, 2, NULL);
INSERT INTO public.screen ("type", formname, formedit, formview, name, description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(14, 'delete_metric', '{"form": []}'::json::json, '{"form": []}'::json::json, 'Delete metric?', 'After deleting the metric, all values of the Annual Recurring Revenue will be permanently deleted', 1, NULL, NULL, NULL, NULL, 2, NULL);
INSERT INTO public.screen ("type", formname, formedit, formview, name, description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info) VALUES(14, 'add_metric', '{
  "form":
  [
    {
      "page": 1,
      "fields":
      [
        {
          "localName": "Metric type",
          "example": "Choose metric type",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "search_dropdown",
          "sysName": "type",
          "multySelect": false
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "1"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "2"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "3"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "4"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "5"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "6"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "7"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "9"
        },
        {
          "localName": "Currency",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "10"
        }
      ]
    },
    {
      "page": 1,
      "module": "Metric value",
      "moduleNote": "Specify the metric values on specific dates. You will be able to add values after adding the metric.",
      "isArray": "true",
      "actionText": "Add value",
      "isControlShow": true,
      "triggerField": "currency",
      "triggerValue": "",
      "fields":
      [
        {
          "sysName": "items_value",
          "localName": "Value",
          "type": "int",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Enter a number"
        },
        {
          "sysName": "items_date",
          "localName": "Date",
          "type": "date",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Specify a date",
          "maxDate": "",
          "dateError": "The date is incorrect"
        }
      ]
    },
    {
      "page": 1,
      "module": "Metric value",
      "moduleNote": "Specify the metric values on specific dates. You will be able to add values after adding the metric.",
      "isArray": "true",
      "actionText": "Add value",
      "isControlShow": true,
      "triggerField": "currency",
      "triggerValue": "41001",
      "fields":
      [
        {
          "sysName": "items_value",
          "localName": "Value",
          "type": "int",
          "edited": true,
          "required": true,
          "mask": "$",
          "direction": "row",
          "example": "Enter a number"
        },
        {
          "sysName": "items_date",
          "localName": "Date",
          "type": "date",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Specify a date",
          "maxDate": "",
          "dateError": "The date is incorrect"
        }
      ]
    },
    {
      "page": 1,
      "module": "Metric value",
      "moduleNote": "Specify the metric values on specific dates. You will be able to add values after adding the metric.",
      "isArray": "true",
      "actionText": "Add value",
      "isControlShow": true,
      "triggerField": "currency",
      "triggerValue": "41002",
      "fields":
      [
        {
          "sysName": "items_value",
          "localName": "Value",
          "type": "int",
          "edited": true,
          "required": true,
          "mask": "₽",
          "direction": "row",
          "example": "Enter a number"
        },
        {
          "sysName": "items_date",
          "localName": "Date",
          "type": "date",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Specify a date",
          "maxDate": "",
          "dateError": "The date is incorrect"
        }
      ]
    }
  ]
}'::json::json, NULL, 'Add metric ', NULL, 1, NULL, NULL, NULL, NULL, 2, NULL);

INSERT INTO public.pages (code, "name", uri, description, page_type, page, lang_id) VALUES('metrics_en', 'My metrics  | SberUnity', '/metrics', 'Страница отображения метрик', 'auth', '{ "features":[
            {
              "type": "metrics",
              "sysName": "metrics",
              "position": 1,
              "visible": true,
              "headerTitle": "My metrics",
              "locationTitle": "Metric type",
              "toasts": {
                "success": "Values for the {0} metric have been added",
                "error": "We were not able to add the value of the metric {0}"
              },
              "buttons": {
                "addMetric": "Add metric",
                "addMetricValues": {
                  "submit": "Add",
                  "cancel": "Back"
                }
              },
              "noContent": {
                "metrics": {
                  "title": "We were not able to receive the information about the metric",
                  "subtitle": "Refresh the page or try again later",
                  "button": {
                    "text": "Refresh the page",
                    "colorScheme": "gray",
                    "variant": "outlined"
                  },
                  "alignToHeight": true
                },
                "graph": {
                  "title": "We were not able to receive the information about the {0} metric",
                  "subtitle": "Refresh the page or try again later",
                  "button": {
                    "text": "Refresh the page",
                    "colorScheme": "gray",
                    "variant": "outlined"
                  },
                  "alignToHeight": false
                }
              },
              "emptyData": {
                "title": "No metrics added yet",
                "description": "Add metrics and their values to track changes"
              }
            }
           ]
        }'::json::json, 2);

