--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5150

update screen
set formview = '{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "type": "date",
          "edited": false,
          "sysName": "session_date",
          "required": false,
          "localName": "Время посещения"
        },
        {
          "type": "date",
          "edited": false,
          "sysName": "Questionnaire_Modified",
          "required": false,
          "localName": "Время обновления"
        },
        {
          "type": "date",
          "edited": false,
          "sysName": "Questionnaire_Modified",
          "required": false,
          "localName": "Время обновления"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Наименование организации"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_inn",
          "required": false,
          "localName": "ИНН организации"
        },
        {
          "type": "int",
          "edited": false,
          "sysName": "questionnaire_birthYear",
          "required": false,
          "localName": "Год регистрации",
          "maxLength": 4
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_name",
          "required": false,
          "localName": "Публичное название / название бренда"
        },
        {
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "sysName": "questionnaire_site",
          "required": false,
          "localName": "Сайт"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_transcription",
          "required": false,
          "localName": "Транскрипция"
        },
        {
          "type": "text",
          "edited": false,
          "format": "search_dropdown",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Страна юрисдикции*"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_inviteFio",
          "required": false,
          "localName": "Контактное лицо"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_email",
          "required": false,
          "localName": "Электронная почта"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_phoneNumber",
          "required": false,
          "localName": "Номер телефона"
        }
      ],
      "module": "Организация",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "title": "Ресурс",
          "edited": false,
          "format": "chip",
          "sysName": "contacts[]_typeDisableDisableDisable",
          "activity": [
            21000
          ],
          "required": false,
          "localName": ""
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "contacts[]_name",
          "required": false,
          "localName": "Ссылка"
        }
      ],
      "module": "Дополнительные ссылки",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "chip",
          "sysName": "project_interactionType",
          "activity": [
            8000
          ],
          "required": false,
          "localName": "Бизнес-модели взаимодействия с пользователями"
        },
        {
          "type": "array",
          "edited": false,
          "format": "chip",
          "sysName": "questionnaire_businessModel",
          "activity": [
            24000
          ],
          "required": false,
          "localName": "Бизнес-модели"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_locationCountry",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Страна"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_location",
          "required": false,
          "localName": "Город"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": false,
          "localName": "Индустрии"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": false,
          "localName": "Технологии"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_note",
          "required": false,
          "localName": "Краткое описание проекта"
        },
        {
          "type": "logo",
          "edited": false,
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип"
        }
      ],
      "module": "О проекте",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_mvpCode",
          "activity": [
            27000
          ],
          "required": false,
          "localName": "Стадия развития продукта"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_demoSite",
          "required": false,
          "localName": "URL ссылка на демо"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "project_demoVideo",
          "required": false,
          "localName": "Видео о продукте"
        }
      ],
      "module": "Прототип",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "note": "Опишите в 1–2 предложениях",
          "type": "string",
          "edited": false,
          "sysName": "project_problem",
          "required": false,
          "localName": "Проблема, которую решает проект"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_auditory",
          "required": false,
          "localName": "Целевая аудитория"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "investment_businessPlan",
          "required": false,
          "localName": "Загрузить презентацию"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "project_pitchVideo",
          "required": false,
          "localName": "Видео питча"
        }
      ],
      "module": "О проекте",
      "pageName": ""
    },
    {
      "page": 1,
      "module": "Импортозамещение",
      "pageName": "Команда",
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_isImport",
          "required": false,
          "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?"
        },
        {
          "type": "array",
          "edited": false,
          "format": "tags",
          "sysName": "importReplace_name",
          "required": false,
          "localName": "Названия сервисов, которые заменяет продукт стартапа"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "importReplace_note",
          "required": false,
          "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
          "maxLength": "1000",
          "rows": "3"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "importReplace_benefits",
          "required": false,
          "rows": "3",
          "localName": "Преимущества перед перечисленными сервисами/компаниями",
          "maxLength": "500"
        }
      ]
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Рынки, на которых вы работаете"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_expansion",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_sales",
          "activity": [
            5000
          ],
          "required": false,
          "localName": "Продажи"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "investment_turnover",
          "required": false,
          "localName": "Оборот в год (в USD)"
        }
      ],
      "module": "Рынок",
      "moduleNote": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "string",
          "edited": false,
          "sysName": "project_competitor",
          "required": false,
          "localName": "Прямые конкуренты"
        },
        {
          "type": "string",
          "edited": false,
          "format": "hide",
          "sysName": "project_indirectCompetitor",
          "required": false,
          "localName": "Косвенные конкуренты"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_upSide",
          "required": false,
          "localName": "Преимущества перед конкурентами"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_acceleratorString",
          "localName": "Пройденные акселераторы"
        },
        {
          "type": "string",
          "edited": false,
          "format": "hide",
          "sysName": "project_downSide",
          "required": false,
          "localName": "Недостатки перед конкурентами"
        }
      ],
      "module": "Конкуренты",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "int",
          "edited": false,
          "sysName": "project_staff",
          "required": false,
          "localName": "Общее количество сотрудников"
        }
      ],
      "module": "Команда",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Роль сотрудника в команде"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "workers[]_note",
          "required": false,
          "localName": "Краткое описание опыта"
        }
      ],
      "module": "",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_successPilots",
          "required": false,
          "localName": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?"
        }
      ],
      "module": "Успешные пилоты",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2bPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2bPilots[]_reference",
          "required": false,
          "localName": "С кем был успешный кейс"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2bPilots[]_suggestCase",
          "required": false,
          "localName": "Описание и результаты кейса"
        }
      ],
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2cPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2cPilots[]_reference",
          "required": false,
          "localName": "С кем был успешный кейс"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2cPilots[]_suggestCase",
          "required": false,
          "localName": "Описание и результаты кейса"
        }
      ],
      "module": "Успешные B2C-, C2C- кейсы",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_pilot",
          "required": false,
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "ecoPilot_suggestCase",
          "required": false,
          "localName": "Предлагаемый кейс*"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "ecoPilot_experience",
          "required": false,
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "ecoPilot_businessUnit",
          "required": false,
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*"
        }
      ],
      "module": "Экосистема Сбера",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "investment_investment",
          "required": false,
          "localName": "Находитесь ли вы в активном поиске инвестиций?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "investment_lastInvestment",
          "required": false,
          "localName": "Объем ранее привлеченных инвестиций, всего"
        },
        {
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "edited": false,
          "sysName": "investment_coInvestment",
          "required": false,
          "localName": "Имя/ имена инвестора/ инвесторов"
        }
      ],
      "module": "Инвестиции",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_acceleratorCode",
          "activity": [
            26000
          ],
          "required": false,
          "localName": "Является выпускником:"
        }
      ],
      "module": "Акселераторы Сбера",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_sber500",
          "required": false,
          "localName": "Хочет ли стартап подать заявку на участие в Sber500?",
          "information": "Sber500 - уникальный акелератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "sberFiveHundred_firsttime",
          "required": false,
          "localName": "Подавался ли стартап ранее в Sber500?"
        },
        {
          "type": "array",
          "edited": false,
          "format": "search_dropdown",
          "example": "Укажите потребность",
          "sysName": "sberFiveHundred_ecorequirement",
          "activity": [
            38000
          ],
          "required": false,
          "localName": "Какую потребность Экосистемы Сбера закрывает стартап?",
          "multySelect": true
        },
        {
          "type": "string",
          "edited": false,
          "regExp": "(^([0-9]{1,7}))",
          "sysName": "sberFiveHundred_monthrevenue",
          "required": false,
          "localName": "Выручка за последний месяц",
          "maxLength": "300",
          "showLength": false,
          "regExpError": "Необходимо указать число"
        },
        {
          "type": "string",
          "edited": false,
          "regExp": "(^([0-9]{1,7}))",
          "sysName": "sberFiveHundred_quarterrevenue",
          "required": false,
          "localName": "Выручка за последние 3 месяца",
          "maxLength": "300",
          "showLength": false,
          "regExpError": "Необходимо указать число"
        },
        {
          "type": "int",
          "edited": false,
          "format": "[1;1000]",
          "example": "Укажите количество клиентов",
          "sysName": "sberFiveHundred_clients",
          "maxValue": 1000,
          "minValue": 1,
          "required": false,
          "localName": "Количество активных или платящих клиентов за последний месяц"
        }
      ],
      "module": "Акселератор Sber500",
      "pageName": "Sber500"
    }
  ]
}'
where formname = 'startup_Administrator'
  and lang_id = 1;

update screen
set formview = '{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "type": "date",
          "edited": false,
          "sysName": "session_date",
          "required": false,
          "localName": "Visit time"
        },
        {
          "type": "date",
          "edited": false,
          "sysName": "Questionnaire_Modified",
          "required": false,
          "localName": "Update time"
        },
        {
          "type": "date",
          "edited": false,
          "sysName": "Questionnaire_Modified",
          "required": false,
          "localName": "Update time"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Name of the organization"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_inn",
          "required": false,
          "localName": "INN of the organization"
        },
        {
          "type": "int",
          "edited": false,
          "sysName": "questionnaire_birthYear",
          "required": false,
          "localName": "Year of registration",
          "maxLength": 4
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_name",
          "required": false,
          "localName": "Public name / brand name"
        },
        {
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "sysName": "questionnaire_site",
          "required": false,
          "localName": "Website"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_transcription",
          "required": false,
          "localName": "Transcription"
        },
        {
          "type": "text",
          "edited": false,
          "format": "search_dropdown",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Country of jurisdiction"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_inviteFio",
          "required": false,
          "localName": "Contact person"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_email",
          "required": false,
          "localName": "Email"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_phoneNumber",
          "required": false,
          "localName": "Phone number"
        }
      ],
      "module": "Organization",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "title": "Resource",
          "edited": false,
          "format": "chip",
          "sysName": "contacts[]_typeDisableDisableDisable",
          "activity": [
            21000
          ],
          "required": false,
          "localName": ""
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "contacts[]_name",
          "required": false,
          "localName": "Linkg"
        }
      ],
      "module": "Additional contacts",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "chip",
          "sysName": "project_interactionType",
          "activity": [
            8000
          ],
          "required": false,
          "localName": "Business models of interaction with users"
        },
        {
          "type": "array",
          "edited": false,
          "format": "chip",
          "sysName": "questionnaire_businessModel",
          "activity": [
            24000
          ],
          "required": false,
          "localName": "Business models"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_locationCountry",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Страна"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_location",
          "required": false,
          "localName": "City"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": false,
          "localName": "Industries"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": false,
          "localName": "Technologies"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_note",
          "required": false,
          "localName": "Brief description of the project"
        },
        {
          "type": "logo",
          "edited": false,
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Upload a logo"
        }
      ],
      "module": "About the project",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_mvpCode",
          "activity": [
            27000
          ],
          "required": false,
          "localName": "Product development stage"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_demoSite",
          "required": false,
          "localName": "URL link to the demo"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "project_demoVideo",
          "required": false,
          "localName": "Video about the product"
        }
      ],
      "module": "About the project",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "note": "Опишите в 1–2 предложениях",
          "type": "string",
          "edited": false,
          "sysName": "project_problem",
          "required": false,
          "localName": "The problem that the project solves"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_auditory",
          "required": false,
          "localName": "Target audience"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "investment_businessPlan",
          "required": false,
          "localName": "Upload a presentation"
        },
        {
          "type": "hyperlink",
          "edited": false,
          "format": "URL",
          "sysName": "project_pitchVideo",
          "required": false,
          "localName": "Pitch Video"
        }
      ],
      "module": "About the project",
      "pageName": ""
    },
    {
      "page": 1,
      "module": "Import substitution",
      "pageName": "Team",
      "fields": [
        {
          "type": "boolean",
          "value": false,
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_isImport",
          "required": false,
          "localName": "Does your product replace any similar services or companies?"
        },
        {
          "type": "string",
          "edited": false,
          "format": "tags",
          "sysName": "importReplace_name",
          "required": false,
          "localName": "Name of the service/company"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "importReplace_note",
          "required": false,
          "localName": "How exactly do you replace the listed services/companies?",
          "maxLength": "1000",
          "rows": "3"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "importReplace_benefits",
          "required": false,
          "localName": "Advantages over the listed services/companies",
          "maxLength": "500",
          "rows": "3"
        }
      ]
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "The markets you work in"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_expansion",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "Markets that you are going to enter in the near future"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_sales",
          "activity": [
            5000
          ],
          "required": false,
          "localName": "Sales"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "investment_turnover",
          "required": false,
          "localName": "Turnover per year (в USD)"
        }
      ],
      "module": "Market",
      "moduleNote": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "string",
          "edited": false,
          "sysName": "project_competitor",
          "required": false,
          "localName": "Direct competitors"
        },
        {
          "type": "string",
          "edited": false,
          "format": "hide",
          "sysName": "project_indirectCompetitor",
          "required": false,
          "localName": "Indirect competitors"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "project_upSide",
          "required": false,
          "localName": "Advantages over competitors"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_acceleratorString",
          "localName": "Accelerators alumni"
        },
        {
          "type": "string",
          "edited": false,
          "format": "hide",
          "sysName": "project_downSide",
          "required": false,
          "localName": "Disadvantages to competitors"
        }
      ],
      "module": "Competitors",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "int",
          "edited": false,
          "sysName": "project_staff",
          "required": false,
          "localName": "Total number of employees"
        }
      ],
      "module": "Team",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Employees role in the team"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "workers[]_note",
          "required": false,
          "localName": "Brief description of the experience"
        }
      ],
      "module": "",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_successPilots",
          "required": false,
          "localName": "If you are B2B-, B2B-, B2C- startups: do you have successful pilots or implementations in corporations?"
        }
      ],
      "module": "Successful pilots",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2bPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2bPilots[]_reference",
          "required": false,
          "localName": "Who was the successful case with"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2bPilots[]_suggestCase",
          "required": false,
          "localName": "Description and results of the case"
        }
      ],
      "module": "Successful B2B-, B2G-, B2B2C-, B2O- cases",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "value": "20007",
          "edited": false,
          "format": "hide",
          "sysName": "b2cPilots[]_state",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2cPilots[]_reference",
          "required": false,
          "localName": "Who was the successful case with"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "b2cPilots[]_suggestCase",
          "required": false,
          "localName": "Description and results of the case"
        }
      ],
      "module": "Successful B2C-, C2C- cases",
      "isArray": "true",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_pilot",
          "required": false,
          "localName": "Are you interested in piloting your product in the Beber Ecosystem or with other corporations?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "ecoPilot_suggestCase",
          "required": false,
          "localName": "The proposed case"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "ecoPilot_experience",
          "required": false,
          "localName": "Have you interacted with the Sber ecosystem before?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "ecoPilot_businessUnit",
          "required": false,
          "localName": "Which business unit did Sber interact with?"
        }
      ],
      "module": "Sber ecosystem",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "investment_investment",
          "required": false,
          "localName": "Are you actively looking for investments?"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "investment_lastInvestment",
          "required": false,
          "localName": "The volume of previously attracted investments, total"
        },
        {
          "note": "List all the investors from whom you received investments, if the disclosure of this information does not contradict the agreements with them",
          "type": "string",
          "edited": false,
          "sysName": "investment_coInvestment",
          "required": false,
          "localName": "Name/ names of the investor/ investors"
        }
      ],
      "module": "Investment",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_acceleratorCode",
          "activity": [
            26000
          ],
          "required": false,
          "localName": "Is a graduate:"
        }
      ],
      "module": "Sber Accelerator",
      "pageName": ""
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "questionnaire_sber500",
          "required": false,
          "localName": "Does the startup want to apply for participation in Sber500?",
          "information": "Sber500 is a unique accelerator based on the capabilities of the Sber ecosystem and the expertise and experience of 500 Global"
        },
        {
          "type": "boolean",
          "edited": false,
          "format": "switch",
          "sysName": "sberFiveHundred_firsttime",
          "required": false,
          "localName": "Has the startup been submitted to Sber500 before?"
        },
        {
          "type": "array",
          "edited": false,
          "format": "search_dropdown",
          "sysName": "sberFiveHundred_ecorequirement",
          "activity": [
            38000
          ],
          "required": false,
          "localName": "What is the need of the Sber Ecosystem that the startup closes?",
          "multySelect": true
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "sberFiveHundred_monthrevenue",
          "required": false,
          "localName": "Revenue for the last month",
          "maxLength": "300",
          "showLength": false
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "sberFiveHundred_quarterrevenue",
          "required": false,
          "localName": "Revenue for the last 3 months",
          "maxLength": "300",
          "showLength": false
        },
        {
          "type": "int",
          "edited": false,
          "format": "[1;1000]",
          "sysName": "sberFiveHundred_clients",
          "maxValue": 1000,
          "minValue": 1,
          "required": false,
          "localName": "Number of active or paying customers in the last month"
        }
      ],
      "module": "Accelerator Sber500",
      "pageName": "Sber500"
    }
  ]
}'
where formname = 'startup_Administrator'
  and lang_id = 2;

update screen
set formview = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Название"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год основания"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": false,
                    "localName": "Тип взаимодействия с пользователем"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": false,
                    "localName": "Бизнес-модели"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрия проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_auditory",
                    "required": false,
                    "localName": "Целевая аудитория"
                }
            ],
            "module": "Основная информация"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "hyperlink",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "contacts[]_name",
                    "required": false,
                    "localName": "Ссылка"
                }
            ],
            "module": "Дополнительные ссылки (Доступно по подписке)",
            "isArray": "true",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": false,
                    "localName": "Стадия развития продукта"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о продукте",
                    "triggerField": "project_haveMVP",
                    "triggerValue": "true"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_businessPlan",
                    "required": false,
                    "localName": "Презентация (Доступно по подписке)"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которых работает стартап"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые собираетесь выходить в ближайшее время"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": false,
                    "localName": "Продажи"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_turnover",
                    "required": false,
                    "localName": "Оборот"
                }
            ],
            "module": "О проекте (Доступно по подписке)"
        },
        {
            "page": 1,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Названия сервисов, которые заменяет продукт стартапа"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "rows": "3",
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500"
                }
            ]
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_competitor",
                    "required": false,
                    "localName": "Прямые конкуренты"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_upSide",
                    "required": false,
                    "localName": "Преимущества перед конкурентами"
                }
            ],
            "module": "Конкуренты (Доступно по подписке)"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "isBlur": false,
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Страна, где находится команда"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "questionnaire_location",
                    "required": false,
                    "localName": "Город, где находится команда"
                },
                {
                    "type": "int",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "project_staff",
                    "required": false,
                    "localName": "Общее количество сотрудников"
                }
            ],
            "module": "Команда (Доступно по подписке)"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "worker_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "hide",
                    "sysName": "worker_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "worker_role",
                    "required": false,
                    "direction": "concatenation",
                    "localName": "Ключевые члены команды"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Опыт",
                    "maxLength": "150"
                }
            ],
            "module": "",
            "isArray": "true"
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": false,
                    "format": "hide",
                    "isBlur": false,
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса"
                }
            ],
            "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы (Доступно по подписке)",
            "isArray": "true",
            "pageName": "",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "isBlur": false,
                    "sysName": "investment_investment",
                    "required": false,
                    "localName": "Проект привлекает инвестиции"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "isBlur": false,
                    "sysName": "investment_planInvestment",
                    "required": false,
                    "localName": "Проект планирует привлекать инвестиции в ближайшие 6 месяцев",
                    "triggerField": "investment_investment",
                    "triggerValue": "false"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Объем ранее привлеченных инвестиций, всего",
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                },
                {
                    "type": "string",
                    "edited": false,
                    "isBlur": false,
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Имя/ имена инвестора/ инвесторов",
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                }
            ],
            "module": "Инвестиции (Доступно по подписке)"
        }
    ]
}'
where formname = 'startup_Client'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_fullName",
               "required":false,
               "localName":"Name"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"User interaction type"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Project industry"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"hyperlink",
               "edited":false,
               "isBlur":false,
               "sysName":"contacts[]_name",
               "required":false,
               "localName":"Link"
            }
         ],
         "module":"Additional contacts (Available by subscription)",
         "isArray":"true",
         "pageName":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "isBlur":false,
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Product Video",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation (Available by subscription)"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets you plan to enter in the near future"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover"
            }
         ],
         "module":"About the project (Available by subscription)"
      },
      {
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "isBlur":false,
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "isBlur":false,
               "sysName":"project_staff",
               "required":false,
               "localName":"Total number of employees"
            }
         ],
         "module":"Team (Available by subscription)"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"worker_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"boolean",
               "value":false,
               "edited":false,
               "format":"hide",
               "sysName":"worker_isFounder",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"worker_role",
               "required":false,
               "direction":"concatenation",
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience",
               "maxLength":"150"
            }
         ],
         "module":"",
         "isArray":"true"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "isBlur":false,
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who had successful cases"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О- cases (Available by subscription)",
         "isArray":"true",
         "pageName":"",
         "moduleNote":""
      },
      {
         "page":1,
         "fields":[
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "isBlur":false,
               "sysName":"investment_investment",
               "required":false,
               "localName":"The project attracts investments"
            },
            {
               "type":"boolean",
               "edited":false,
               "format":"switch",
               "isBlur":false,
               "sysName":"investment_planInvestment",
               "required":false,
               "localName":"The project plans to attract investments in the next 6 months",
               "triggerField":"investment_investment",
               "triggerValue":"false"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "isBlur":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments (Available by subscription)"
      }
   ]
}'
where formname = 'startup_Client'
  and lang_id = 2;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Пройденные акселераторы"
             }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
          "page": 1,
          "module": "Импортозамещение",
          "pageName": "Команда",
          "fields": [
              {
                  "type": "array",
                  "edited": false,
                  "format": "tags",
                  "sysName": "importReplace_name",
                  "required": false,
                  "localName": "Названия сервисов, которые заменяет продукт стартапа"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_note",
                  "required": false,
                  "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                  "maxLength": "1000",
                  "rows": "3"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_benefits",
                  "required": false,
                  "rows": "3",
                  "localName": "Преимущества перед перечисленными сервисами/компаниями",
                  "maxLength": "500"
              }
          ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"С кем был успешный кейс"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Описание и результаты кейса"
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      }
   ]
}'
where formname = 'startup_CorpPro'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Accelerators alumni"
             }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who was the successful case with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}'
where formname = 'startup_CorpPro'
  and lang_id = 2;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Пройденные акселераторы"
             }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
          "page": 1,
          "module": "Импортозамещение",
          "pageName": "Команда",
          "fields": [
              {
                  "type": "array",
                  "edited": false,
                  "format": "tags",
                  "sysName": "importReplace_name",
                  "required": false,
                  "localName": "Названия сервисов, которые заменяет продукт стартапа"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_note",
                  "required": false,
                  "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                  "maxLength": "1000",
                  "rows": "3"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_benefits",
                  "required": false,
                  "rows": "3",
                  "localName": "Преимущества перед перечисленными сервисами/компаниями",
                  "maxLength": "500"
              }
          ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"С кем был успешный кейс"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Описание и результаты кейса"
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      }
   ]
}'
where formname = 'startup_SuperClient'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Accelerators alumni"
             }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who was the successful case with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}'
where formname = 'startup_SuperClient'
  and lang_id = 2;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Пройденные акселераторы"
             }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
          "page": 1,
          "module": "Импортозамещение",
          "pageName": "Команда",
          "fields": [
              {
                  "type": "array",
                  "edited": false,
                  "format": "tags",
                  "sysName": "importReplace_name",
                  "required": false,
                  "localName": "Названия сервисов, которые заменяет продукт стартапа"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_note",
                  "required": false,
                  "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                  "maxLength": "1000",
                  "rows": "3"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_benefits",
                  "required": false,
                  "rows": "3",
                  "localName": "Преимущества перед перечисленными сервисами/компаниями",
                  "maxLength": "500"
              }
          ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"С кем был успешный кейс"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Описание и результаты кейса"
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      }
   ]
}'
where formname = 'startup_CorpProPlus'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Accelerators alumni"
             }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who was the successful case with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}'
where formname = 'startup_CorpProPlus'
  and lang_id = 2;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Пройденные акселераторы"
             }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
          "page": 1,
          "module": "Импортозамещение",
          "pageName": "Команда",
          "fields": [
              {
                  "type": "array",
                  "edited": false,
                  "format": "tags",
                  "sysName": "importReplace_name",
                  "required": false,
                  "localName": "Названия сервисов, которые заменяет продукт стартапа"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_note",
                  "required": false,
                  "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                  "maxLength": "1000",
                  "rows": "3"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_benefits",
                  "required": false,
                  "rows": "3",
                  "localName": "Преимущества перед перечисленными сервисами/компаниями",
                  "maxLength": "500"
              }
          ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"С кем был успешный кейс"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Описание и результаты кейса"
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      }
   ]
}'
where formname = 'startup_InvestAngel'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Accelerators alumni"
             }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who was the successful case with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}'
where formname = 'startup_InvestAngel'
  and lang_id = 2;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Краткое описание проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"Проблема, которую решает проект"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"Целевая аудитория"
            },
            {
               "type":"hyperlink",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Сайт"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Год основания"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Модель продаж"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Бизнес-модели"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Индустрии проекта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Технологии проекта"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"Контактное лицо"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Электронная почта"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Пройденные акселераторы"
             }
         ],
         "module":"Основная информация"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Перейти",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Дополнительные ссылки",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Стадия развития продукта"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Продажи"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Оборот в год (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Видео о продукте",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Смотреть",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Презентация"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которых работает стартап"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Рынки, на которые стартап планирует выйти в будущем"
            }
         ],
         "module":"О проекте"
      },
      {
          "page": 1,
          "module": "Импортозамещение",
          "pageName": "Команда",
          "fields": [
              {
                  "type": "array",
                  "edited": false,
                  "format": "tags",
                  "sysName": "importReplace_name",
                  "required": false,
                  "localName": "Названия сервисов, которые заменяет продукт стартапа"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_note",
                  "required": false,
                  "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                  "maxLength": "1000",
                  "rows": "3"
              },
              {
                  "type": "string",
                  "edited": false,
                  "sysName": "importReplace_benefits",
                  "required": false,
                  "rows": "3",
                  "localName": "Преимущества перед перечисленными сервисами/компаниями",
                  "maxLength": "500"
              }
          ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Прямые конкуренты"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Преимущества перед конкурентами"
            }
         ],
         "module":"Конкуренты"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Страна, где находится команда"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"Город, где находится команда"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Общее количество сотрудников"
            }
         ],
         "module":"Команда"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Ключевые члены команды"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Опыт"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"С кем был успешный кейс"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Описание и результаты кейса"
            }
         ],
         "module":"Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"Объем ранее привлеченных инвестиций, всего (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Имя/ имена инвестора/ инвесторов",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Инвестиции"
      }
   ]
}'
where formname = 'startup_InvestPro'
  and lang_id = 1;

update screen
set formview = '{
   "form":[
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_note",
               "required":false,
               "localName":"Brief description of the project"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_problem",
               "required":false,
               "localName":"The problem the project is solving"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_auditory",
               "required":false,
               "localName":"The target audience"
            },
            {
               "type":"hyperlink",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"questionnaire_site",
               "required":false,
               "localName":"Website"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"questionnaire_birthYear",
               "required":false,
               "localName":"Year of foundation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_interactionType",
               "activity":[
                  8000
               ],
               "required":false,
               "localName":"Sales model"
            },
            {
               "type":"array",
               "edited":false,
               "format":"search_dropdown",
               "sysName":"questionnaire_businessModel",
               "activity":[
                  24000
               ],
               "required":false,
               "localName":"Business models"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_industry",
               "activity":[
                  3000
               ],
               "required":false,
               "localName":"Peoject industries"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_technology",
               "activity":[
                  13000
               ],
               "required":false,
               "localName":"Project technologies"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_inviteFio",
               "required":false,
               "localName":"The contact person"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_email",
               "required":false,
               "localName":"Email"
            },
            {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_acceleratorString",
                    "localName": "Accelerators alumni"
             }
         ],
         "module":"Main information"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"heading",
               "sysName":"contacts[]_typeDisableDisableDisable",
               "activity":[
                  21000
               ],
               "required":false,
               "localName":"",
               "multySelect":false
            },
            {
               "type":"info",
               "title":"Go",
               "edited":false,
               "format":"button",
               "sysName":"contacts[]_name",
               "required":false
            }
         ],
         "module":"Additional links",
         "isArray":"true",
         "pageName":"",
         "moduleFormat":"button"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_mvpCode",
               "activity":[
                  27000
               ],
               "required":false,
               "localName":"Product development stage"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_sales",
               "activity":[
                  5000
               ],
               "required":false,
               "localName":"Sales"
            },
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_turnover",
               "required":false,
               "localName":"Turnover per year (USD)"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"button",
               "sysName":"project_demoVideo",
               "required":false,
               "localName":"Video about the project",
               "triggerField":"project_haveMVP",
               "triggerValue":"true"
            },
            {
               "type":"hyperlink",
               "title":"Look",
               "edited":false,
               "format":"filebutton",
               "sysName":"investment_businessPlan",
               "required":false,
               "localName":"Presentation"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_geography",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets in which the startup operates"
            },
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"project_expansion",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Markets the startup plans to enter in the future"
            }
         ],
         "module":"About the project"
      },
      {
            "page": 1,
            "module": "Import substitution",
            "pageName": "Team",
            "fields": [
            {
                    "type": "boolean",
                    "value": false,
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": false,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Name of the service/company"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_note",
                    "required": false,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "importReplace_benefits",
                    "required": false,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3"
                }
         ]
      },
      {
         "page":1,
         "fields":[
            {
               "type":"string",
               "edited":false,
               "sysName":"project_competitor",
               "required":false,
               "localName":"Direct competitors"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"project_upSide",
               "required":false,
               "localName":"Advantages over competitors"
            }
         ],
         "module":"Competitors"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "edited":false,
               "format":"text",
               "sysName":"questionnaire_locationCountry",
               "activity":[
                  2000
               ],
               "required":false,
               "localName":"Country where the team is located"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"questionnaire_location",
               "required":false,
               "localName":"City where the team is located"
            },
            {
               "type":"int",
               "edited":false,
               "sysName":"project_staff",
               "required":false,
               "direction":"row",
               "localName":"Total number of employees"
            }
         ],
         "module":"Team"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"long",
               "edited":false,
               "format":"hide",
               "sysName":"workers[]_parentId",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"workers[]_role",
               "required":false,
               "localName":"Key team members"
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"workers[]_note",
               "required":false,
               "localName":"Experience"
            }
         ],
         "module":"",
         "isArray":"true",
         "moduleFormat":"card"
      },
      {
         "page":1,
         "fields":[
            {
               "type":"array",
               "value":"20007",
               "edited":false,
               "format":"hide",
               "sysName":"b2bPilots[]_state",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"hideID",
               "sysName":"b2bPilots[]_companyUid",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"b2bPilots[]_reference",
               "required":false,
               "localName":"Who was the successful case with"
            },
            {
               "type":"string",
               "edited":false,
               "format":"heading",
               "sysName":"UIDquestionnaire_name",
               "required":false,
               "localName":""
            },
            {
               "type":"array",
               "value":"40000",
               "edited":false,
               "format":"state",
               "sysName":"b2bPilots[]_referenceState",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"icon",
               "sysName":"UIDquestionnaire_logoFile",
               "required":false,
               "localName":""
            },
            {
               "type":"string",
               "edited":false,
               "format":"body",
               "sysName":"b2bPilots[]_suggestCase",
               "required":false,
               "localName":"Description and results of the case"
            }
         ],
         "module":"Successful В2В-, В2G-, B2B2C-, В2О-cases",
         "isArray":"true",
         "pageName":"",
         "moduleNote":"",
         "moduleFormat":"clickCard"
      },
      {
         "page":1,
         "fields":[
            {
               "mask":"$",
               "type":"string",
               "edited":false,
               "sysName":"investment_lastInvestment",
               "required":false,
               "localName":"The volume of previously attracted investments, total (USD)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            },
            {
               "type":"string",
               "edited":false,
               "sysName":"investment_coInvestment",
               "required":false,
               "localName":"Name(s) of the investor(s)",
               "triggerField":"investment_investment",
               "triggerValue":"true"
            }
         ],
         "module":"Investments"
      }
   ]
}'
where formname = 'startup_InvestPro'
  and lang_id = 2;