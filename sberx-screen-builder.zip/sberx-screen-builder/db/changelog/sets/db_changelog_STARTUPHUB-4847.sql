--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-4847 Добавление новых условий для формирования кнопок и самих кнопок
ALTER TABLE screen_button ADD COLUMN IF NOT EXISTS investor_check boolean Null;
ALTER TABLE screen_button ADD COLUMN IF NOT EXISTS active_round_check boolean Null;
ALTER TABLE screen_button ADD COLUMN IF NOT EXISTS future_round_check boolean Null;

delete from buttons where code in (30001, 30002);
delete from screen_button where name = 'startup_SuperClient' and active_round_check = true;
delete from screen_button where name = 'startup_SuperClient' and future_round_check = true;


insert into buttons (code,text,lang_id)
values (30001,'Стартап сейчас собирает раунд инвестиций',1);

insert into buttons (code,text,lang_id)
values (30002,'Стартап планирует привлечение раунда инвестиций',1);

insert into screen_button (name,state,investor_check,active_round_check)
values ('startup_SuperClient',20004,true,true);

insert into screen_button (name,state,investor_check,future_round_check)
values ('startup_SuperClient',20004,true,true);

insert into screen_buttons_link (screen_id,button_id)
values ((select screen_id from screen_button where name = 'startup_SuperClient' and active_round_check = true limit 1), (select button_id from buttons where code = 30001 limit 1));

insert into screen_buttons_link (screen_id,button_id)
values ((select screen_id from screen_button where name = 'startup_SuperClient' and future_round_check = true limit 1), (select button_id from buttons where code = 30002 limit 1));