--liquibase formatted sql
--changeset Mirov AA:pages_refactoring
alter table pages drop column if exists parent_id;
alter table pages drop column if exists client_id;
alter table pages add column if not exists page json null;
alter table pages add column if not exists lang_id bigint null default 1;