--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-1127-2
update public.screen set name = 'Создать пилот' where type = 4 and formname = 'New_Pilot';