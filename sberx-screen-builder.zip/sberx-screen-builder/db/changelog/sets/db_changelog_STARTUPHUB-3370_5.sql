--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3370_5
insert into public.screen_button (name, admin_check, state) values ('corporate_Administrator', true, 20009);
insert into public.screen_button (name, admin_check, state) values ('startup_Administrator', true, 20009);
insert into public.screen_button (name, admin_check, state) values ('investor_Administrator', true, 20009);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'corporate_Administrator'
           and state = 20009
           and admin_check = true and main_check is null limit 1), (select button_id from public.buttons where code = '20003' limit 1));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'startup_Administrator'
           and state = 20009
           and admin_check = true and main_check is null limit 1), (select button_id from public.buttons where code = '20003' limit 1));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'investor_Administrator'
           and state = 20009
           and admin_check = true and main_check is null limit 1), (select button_id from public.buttons where code = '20003' limit 1));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'corporate_Administrator'
           and state = 20009
           and admin_check = true and main_check is null limit 1), (select button_id from public.buttons where code = '100002' limit 1));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'startup_Administrator'
           and state = 20009
           and admin_check = true and main_check is null limit 1), (select button_id from public.buttons where code = '100002' limit 1));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id
         from public.screen_button sb
         where name = 'investor_Administrator'
           and state = 20009
           and admin_check = true and main_check is null limit 1), (select button_id from public.buttons where code = '100002' limit 1));