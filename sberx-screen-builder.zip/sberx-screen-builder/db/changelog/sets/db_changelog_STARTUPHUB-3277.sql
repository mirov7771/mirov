--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-3277
update public.pages
    set page_type = 'auth'
where code = 'community_az';

update public.pages
set page_type = 'unauth'
where code = 'community_nz';