--liquibase formatted sql
--changeset Mirov A:SBERXTECH-253
update screen
set formview = '{
  "form": [
    {
      "module": "",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "",
          "type": "string",
          "format": "caption",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "",
          "type": "hyperlink",
          "format": "hyperlink",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_innovationMethod",
          "localName": "Метод работы с инновациями",
          "type": "array",
          "format": "chip",
          "activity": [
            4000
          ],
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'
where formname  = 'corporate_preauth';

