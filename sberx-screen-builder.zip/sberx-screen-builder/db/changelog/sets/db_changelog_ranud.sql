--liquibase formatted sql
--changeset Mirov AA:RANUD
UPDATE screen SET formview = cast(replace(cast(formview as text),'Рануд','Раунд') as json) WHERE cast(formview as text) like '%Рануд%';
UPDATE screen SET formedit = cast(replace(cast(formedit as text),'Рануд','Раунд') as json) WHERE cast(formedit as text) like '%Рануд%';