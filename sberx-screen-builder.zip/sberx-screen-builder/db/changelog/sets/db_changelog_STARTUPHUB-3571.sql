--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3571
update public.screen set
    formview = '{
    "form": [
        {
            "module": "Основная информация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "firstName",
                    "localName": "Имя",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "lastName",
                    "localName": "Фамилия",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "phone",
                    "localName": "Номер телефона",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Email",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "telegramLink",
                    "localName": "Никнейм в Telegram",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "site",
                    "localName": "Сайт проекта",
                    "type": "hyperlink",
                    "format": "button",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "orgFullName",
                    "localName": "Название компании",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ventureExperience",
                    "localName": "Венчурный опыт",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "sumInvestment",
                    "localName": "Какую сумму вы готовы инвестировать?",
                    "type": "text",
                    "format": "search_dropdown",
                    "activity": [
                        39000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "isUnity",
                    "localName": "Хотели бы опубликоваться на SberUnity",
                    "type": "boolean",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}'
where formname = 'syndicate_Administrator';