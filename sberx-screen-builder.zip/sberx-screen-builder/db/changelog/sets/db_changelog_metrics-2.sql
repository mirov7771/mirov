--liquibase formatted sql
--changeset Konovalenko VI:METRICS-2

delete
from pages
where code = 'metrics_ru';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('metrics_ru', 'SberUnity Метрики', '/metrics', 'Страница отображения метрик', 'auth', '{ "features":[
            {
              "type": "metrics",
              "sysName": "metrics",
              "position": 1,
              "visible": true,
              "headerTitle": "Мои метрики",
              "locationTitle": "Тип метрики",
              "toasts": {
                "success": "Значения метрики {0} добавлены",
                "error": "Не удалось добавить значения метрики {0}"
              },
              "buttons": {
                "addMetric": "Добавить метрику",
                "addMetricValues": {
                  "submit": "Добавить",
                  "cancel": "Назад"
                }
              },
              "noContent": {
                "metrics": {
                  "title": "Не удалось получить информацию о метриках",
                  "subtitle": "Обновите страницу или попробуйте позже",
                  "button": {
                    "text": "Обновить страницу",
                    "colorScheme": "gray",
                    "variant": "outlined"
                  },
                  "alignToHeight": true
                },
                "graph": {
                  "title": "Не удалось получить информацию о метрике {0}",
                  "subtitle": "Обновите страницу или попробуйте позже",
                  "button": {
                    "text": "Обновить страницу",
                    "colorScheme": "gray",
                    "variant": "outlined"
                  },
                  "alignToHeight": false
                }
              },
              "emptyData": {
                "title": "Метрики не добавлены",
                "description": "Добавьте метрики и их значения, чтобы отслеживать изменения"
              }
            }
           ]
        }', 1);

delete
from pages
where code = 'metric_add_ru';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('metric_add_ru', 'SberUnity Добавление метрики', '/add-metric', 'Страница добавления метрики', 'auth', '{ "features":[
              {
				  "type": "addMetric",
				  "sysName": "addMetric",
				  "position": 1,
				  "visible": true,
				  "toasts": {
				    "success": "Метрика {0} добавлена",
				    "error": "Не удалось добавить метрику"
				  },
				  "buttons": {
				    "back": "Назад",
				    "submit": "Добавить метрику"
				  }
			}
           ]
        }', 1);

delete
from pages
where code = 'metric_edit_ru';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('metric_edit_ru', 'SberUnity Редактирование метрики', '/edit-metric', 'Страница редактирования метрики', 'auth', '{ "features":[
              {
				  "type": "editMetric",
				  "sysName": "editMetric",
				  "position": 1,
				  "title": "Редактирование метрики",
				  "infoTitle": "Информация о метрике",
				  "metricTypeName": "Тип метрики:",
				  "currencyName": "Валюта:",
				  "visible": true,
				  "toasts": {
				    "form": {
				      "error": "Не удалось получить данные формы"
				    },
				    "deleteMetric": {
				      "success": "Метрика {0} удалена",
				      "error": "Не удалось удалить метрику"
				    },
				    "editMetric": {
				      "success": "Значения метрики {0} изменены",
				      "error": "Не удалось изменить значения метрики"
				    }
				  },
				  "buttons": {
				    "back": "Назад",
				    "save": "Сохранить изменения",
				    "delete": "Удалить метрику"
				  }
			}
           ]
        }', 1);

update public.pages
set page = '{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "startups_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id": 1
        },
        {
          "name": "Импортозамещение",
          "id": 2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "startups_ru_pageTitle",
      "title": "Импортозаме&shy;щающие решения",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "startups_ru_participantSearch",
      "visible": true,
      "position": 3,
      "isImport": true,
      "placeholder": "Поиск сервисов-аналогов",
      "participant": "startup",
      "shownFromTitle": "Всего %import_size_main% ",
      "helperText": "Введите название сервиса, аналог которого хотите найти, или название стартапа",
      "foundsTitle": "Найдено: {0}",
      "filterBar": {
        "title": "Фильтры",
        "acceptButtonText": "Применить фильтры",
        "resetButtonText": "Сбросить фильтры",
        "acceptButtonShortText": "Применить",
        "resetButtonShortText": "Сбросить",
        "placeholder": "поиск"
      },
      "popupFooter": {
        "title": "Зарегистрируйтесь, чтобы получить доступ к полной анкете",
        "caption": "После регистрации будут доступны: полное описание компании, информация о продукте, направления, ключевые сотрудники, успешные пилоты, инвестиции и трекшн стартапа.",
        "mainButtonText": "Зарегистрироваться",
        "secondButtonText": "Войти"
      },
      "features": [
        {
          "type": "authBanner",
          "sysName": "authBanner",
          "visible": true,
          "position": 1,
          "title": "Зарегистрируйтесь и получите доступ к %import_size% по импортозамещению",
          "mainButtonText": "Зарегистрироваться",
          "secondButtonText": "Войти",
          "placement": "bottom",
          "config": {
            "nowrap": true
          }
        },
        {
          "caption": "Расскажите корпорациям, какие сервисы заменяет ваш продукт",
          "buttonText": "Рассказать о продукте",
          "position": 1,
          "sysName": "importSubstitutionBanner",
          "title": "Будьте в тренде импортозамещения",
          "type": "importSubstitutionBanner",
          "isClosed": false,
          "redirectTo": "/participant-registration",
          "visible": true, "bannerUrl": "/file/p3.png",
          "placement": "middle",
          "config": {
            "nowrap": true,
            "styles": {
              "padding":{
                "xs":{
                  "top":32,
                  "bottom":0
                },
                "s":{
                  "top":32,
                  "bottom":0
                },
                "md":{
                  "top":48,
                  "bottom":0
                },
                "lg":{
                  "top":48,
                  "bottom":0
                }
              }
            }
          }
        }
      ]
    }
  ]
}'
where code = 'import_unauth_ru' and page_type = 'unauth';