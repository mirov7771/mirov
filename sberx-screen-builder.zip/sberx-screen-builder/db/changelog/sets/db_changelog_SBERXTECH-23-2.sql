--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-23-2
update client_menu
set action =
        case when type = 0 then '/view?type=0&action=1&name=startup_Administrator&id='
             when type = 1 then '/view?type=1&action=1&name=corporate_Administrator&id='
             when type = 2 then '/view?type=2&action=1&name=investor_Administrator&id='
            end
where menutype = 'topbar'
  and name = 'Просмотреть';
