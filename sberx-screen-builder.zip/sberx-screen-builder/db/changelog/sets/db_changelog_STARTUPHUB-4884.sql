--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4884
update pages set page = '{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_ru_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Войти",
            "links": [
                {
                    "text": "Забыли пароль? ",
                    "linkText": "Восстановить",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "Нет аккаунта? ",
                    "linkText": "Зарегистрироваться",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Логин (email)",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Пароль",
                    "placeholder": "Введите пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_loginForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_ru_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "title": "Мы обновили пользовательское соглашение",
            "description": "Примите его условия, чтобы продолжить работу на платформе SberUnity",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Продолжить",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 12 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"

                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_ru_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "titleInfoForm": "Временный пароль больше не действует",
            "textDescription": "Мы отправили на **{email}** новый пароль. Пройдите по ссылке из письма и придумайте постоянный.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от  **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_infoPasswordIsExpiredForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}' where uri = '/auth'
     and lang_id = 1;

update pages set page = '{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_en_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "links": [
                {
                    "text": "Forgot your password? ",
                    "linkText": "Recover",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "Don`t have an account? ",
                    "linkText": "Register",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Login",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Password",
                    "placeholder": "Enter password"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_loginForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_en_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "title": "We have updated the user agreement",
            "description": "Accept terms to continue using the SberUnity platform",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Continue",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_en_changePasswordForm",
            "titleForm": "Creating a new password",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Latin characters only ",
                "Minimum of 12 characters",
                "At least 6 different characters",
                "At least 1 uppercase and 1 lowercase letters",
                "At least 1 special symbol, for example \"! _ : ;\""
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "New password"

                },
                {
                    "type": "confirmPassword",
                    "label": "Confirm password",
                    "confirmPasswordLabel": "Confirm password"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Create a password",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_en_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "titleInfoForm": "The temporary password is no longer valid",
            "textDescription": "We have sent a new temporary password to your email **{email}**. After using it to login, you''''ll have to set your own one.",
            "text": " If you don`t see an email, check the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_infoPasswordIsExpiredForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}' where uri = '/auth'
     and lang_id = 2;
