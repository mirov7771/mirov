--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-4360
delete from pages where uri in ('/auth', '/registration', '/participant-registration', '/recovery');
delete from pages where uri in ('/vas') and page_type = 'auth';
INSERT INTO public.pages (code,name,uri,description,page_type,page,lang_id) VALUES
                                                                                ('auth_ru','SberUnity','/auth','SberUnity','unauth','{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_ru_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Войти",
            "links": [
                {
                    "text": "Забыли пароль? ",
                    "linkText": "Восстановить",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "Нет аккаунта? ",
                    "linkText": "Зарегистрироваться",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Логин (email)",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Пароль",
                    "placeholder": "Введите пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_loginForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_ru_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "title": "Мы обновили пользовательское соглашение",
            "description": "Примите его условия, чтобы продолжить работу на платформе SberUnity",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Continue",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 8 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"

                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_ru_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "titleInfoForm": "Временный пароль более не валиден",
            "textDescription": "Мы отправили на Вашу электронную почту $ временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от  **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_infoPasswordIsExpiredForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}',1),
                                                                                ('auth_en','SberUnity','/auth','SberUnity','unauth','{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_en_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "links": [
                {
                    "text": "Forgot your password? ",
                    "linkText": "Recover",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "No account? ",
                    "linkText": "Register",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Login",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Password",
                    "placeholder": "Type a password"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_loginForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_en_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "title": "We have updated the user agreement",
            "description": "Accept terms to continue using the SberUnity platform",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Continue",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_en_changePasswordForm",
            "titleForm": "Creating a new password",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Latin characters only ",
                "Minimum of 8 characters",
                "At least 6 different characters",
                "At least 1 uppercase and 1 lowercase letters",
                "At least 1 special symbol, for example \"! _ : ;\""
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "New password"

                },
                {
                    "type": "confirmPassword",
                    "label": "Repeat password",
                    "confirmPasswordLabel": "Repeat password"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_userAgreementForm_button",
                "text": "Create a password",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_en_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Log in",
            "titleInfoForm": "The temporary password is no longer valid",
            "textDescription": "We have sent a new temporary password to your email **{email}**. After using it to login, you''ll have to set your own one.",
            "text": "If the email has not arrived, look for it in the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_en_infoPasswordIsExpiredForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}',2),
                                                                                ('registration_ru','SberUnity','/registration','SberUnity','unauth','{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_ru_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Регистрация",
            "titleInfoForm": "Отправили пароль вам на почту",
            "textDescription": "Мы отправили на вашу электронную почту {email} временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_infoForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_ru_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Есть аккаунт? ",
                    "linkText": "Войти",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Регистрация",
            "emailField": {
                "label": "Корпоративный email",
                "errorCorporationEmail": "Введите почту на корпоративном домене",
                "helperText": "Он не будет доступен в публичной анкете. Контактный email вы сможете указать на следующем шаге"
            },
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_ru_lregistrationForm_button",
                "text": "Получить пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}',1),
                                                                                ('registration_en','SberUnity','/registration','SberUnity','unauth','{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_en_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Registration",
            "titleInfoForm": "A temporary password was send to your email",
            "textDescription": "We have sent a new temporary password to your email {email}. After using it to login, you''ll have to set your own one.",
            "text": "If the email has not arrived, look for it in the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_en_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_en_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Already have an account? ",
                    "linkText": "Log in",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Registration",
            "emailField": {
                "label": "Email",
                "errorCorporationEmail": "Enter corporate e-mail",
                "helperText": "It will not be available in the public profile. You can specify the contact email address in the next step"
            },
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_en_lregistrationForm_button",
                "text": "Get a password",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}',2),
                                                                                ('participant-registration_en','SberUnity','/participant-registration','SberUnity','unauth','{
    "features": [
        {
            "type": "changePasswordForm",
            "sysName": "participant-registration_en_changePasswordForm",
            "titleForm": "Creating a new password",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Latin characters only ",
                "Minimum of 8 characters",
                "At least 6 different characters",
                "At least 1 uppercase and 1 lowercase letters",
                "At least 1 special symbol, for example \"! _ : ;\""
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "New password"
                },
                {
                    "type": "confirmPassword",
                    "label": "Repeat password",
                    "confirmPasswordLabel": "Repeat password"
                }
            ],
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "participant-registration_en_userAgreementForm_button",
                "text": "Create a password",
                "theme": "purple-gradient",
                "url": "/",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}',2),
                                                                                ('participant-registration_ru','SberUnity','/participant-registration','SberUnity','unauth','{
    "features": [
        {
            "type": "changePasswordForm",
            "sysName": "participant-registration_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 8 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"
                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "participant-registration_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}',1),
                                                                                ('recovery_en','SberUnity','/recovery','SberUnity','unauth','{
    "features": [
        {
            "type": "infoForm",
            "sysName": "recovery_en_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Password Recovery",
            "titleInfoForm": "We have sent a password to your email",
            "textDescription": "We have sent a new temporary password to your email {email}. After using it to login, you''ll have to set your own one.",
            "text": "If the email has not arrived, look for it in the spam folder from [noreply_unity@sbermail-cloud.sber.ru]",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "rrecovery_en_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "recoveryForm",
            "sysName": "recovery_en_recoveryForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Password Recovery",
            "descriptionForm": "To recover your password, enter the email address you provided during registration",
            "subText": "SberUnity Support:",
            "subTextLink": "sberunity@sberbank.ru",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_en_recoveryForm_button",
                "text": "Get a password",
                "theme": "purple-gradient",
                "url": "/restore-password",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}',2),
                                                                                ('recovery_ru','SberUnity','/recovery','SberUnity','unauth','{
    "features": [
        {
            "type": "infoForm",
            "sysName": "recovery_ru_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Восстановление пароля",
            "titleInfoForm": "Отправили пароль Вам на почту",
            "textDescription": "Мы отправили на Вашу электронную почту временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от [noreply_unity@sbermail-cloud.sber.ru]",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_ru_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "recoveryForm",
            "sysName": "recovery_ru_recoveryForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Восстановление пароля",
            "descriptionForm": "Чтобы восстановить пароль, введите адрес электронной почты, указанный при регистрации",
            "subText": "Поддержка SberUnity:",
            "subTextLink": "sberunity@sberbank.ru",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_ru_recoveryForm_button",
                "text": "Получить пароль",
                "theme": "purple-gradient",
                "url": "/restore-password",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}',1);


insert into pages (code, "name", uri, description, page_type, page, lang_id)
values ('vas_az_auth_ru', 'SberUnity', '/vas', 'SberUnity', 'auth', '{
   "features":[
      {
         "type":"breadcrumbs",
         "sysName":"vas_ru_breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Главная",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Сервисы"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"vas_ru_pageTitle",
         "title":"Эксклюзивные предложения для стартапов",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_ru",
         "visible":true,
         "position":2,
         "placeholder":"Введите название",
         "loginDescription":"Присоединяйтесь к платформе,<br/>чтобы воспользоваться предложением сервиса",
         "joinButtonName":"Присоединиться",
         "loginButtonName":"Войти",
         "alphabetically":"По алфавиту",
         "byUpdateDate": "По дате обновления",
         "byCreationDate":"По дате создания"
      }
   ]
}', 1);

insert into pages (code, "name", uri, description, page_type, page, lang_id)
values ('vas_az_auth_en', 'SberUnity', '/vas', 'SberUnity', 'auth', '{
   "features":[
      {
         "type":"breadcrumbs",
         "sysName":"vas_en_breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Main",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Services"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"vas_en_pageTitle",
         "title":"Exclusive offers for startups",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_en",
         "visible":true,
         "position":2,
         "placeholder":"Enter a name",
         "loginDescription": "Join the platform <br/>to take advantage of the service offer",
         "joinButtonName": "Join",
         "loginButtonName": "Enter",
         "alphabetically":"Alphabetically",
         "byUpdateDate": "By update date",
         "byCreationDate":"By creation date"
      }
   ]
}', 2);

update public.pages
set page = '{
   "features":[
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_ru",
         "visible":true,
         "position":2,
         "placeholder":"Введите название",
         "loginDescription":"Присоединяйтесь к платформе,<br/>чтобы воспользоваться предложением сервиса",
         "joinButtonName":"Присоединиться",
         "loginButtonName":"Войти",
         "alphabetically":"По алфавиту",
         "byUpdateDate": "По дате обновления",
         "byCreationDate":"По дате создания"
      }
   ]
}'
where uri = '/vas'
  and lang_id = 1
  and page_type = 'auth';

update public.pages
set page = '{
   "features":[
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_en",
         "visible":true,
         "position":2,
         "placeholder":"Enter a name",
         "loginDescription": "Join the platform <br/>to take advantage of the service offer",
         "joinButtonName": "Join",
         "loginButtonName": "Enter",
         "alphabetically":"Alphabetically",
         "byUpdateDate": "By update date",
         "byCreationDate":"By creation date"
      }
   ]
}'
where uri = '/vas'
  and lang_id = 2
  and page_type = 'auth';

update public.pages
set page = '{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_ru_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Войти",
            "links": [
                {
                    "text": "Забыли пароль? ",
                    "linkText": "Восстановить",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "Нет аккаунта? ",
                    "linkText": "Зарегистрироваться",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Логин (email)",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Пароль",
                    "placeholder": "Введите пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_loginForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_ru_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "title": "Мы обновили пользовательское соглашение",
            "description": "Примите его условия, чтобы продолжить работу на платформе SberUnity",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Продолжить",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 8 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"

                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_ru_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "titleInfoForm": "Временный пароль более не валиден",
            "textDescription": "Мы отправили на Вашу электронную почту $ временный пароль. Воспользуйтесь им, после чего установите собственный пароль.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от  **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_infoPasswordIsExpiredForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}'
where uri = '/auth'
  and lang_id = 1;

update public.pages
set page = '{
    "features": [
        {
            "type": "loginForm",
            "sysName": "auth_ru_loginForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Войти",
            "links": [
                {
                    "text": "Забыли пароль? ",
                    "linkText": "Восстановить",
                    "linkUrl": "/recovery"
                },
                {
                    "text": "Нет аккаунта? ",
                    "linkText": "Зарегистрироваться",
                    "linkUrl": "/participant-registration"
                }
            ],
            "fields": [
                {
                    "type": "login",
                    "label": "Логин (email)",
                    "placeholder": "sberunity@sberbank.ru"
                },
                {
                    "type": "password",
                    "label": "Пароль",
                    "placeholder": "Введите пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_loginForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "userAgreementForm",
            "sysName": "auth_ru_userAgreementForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "title": "Мы обновили пользовательское соглашение",
            "description": "Примите его условия, чтобы продолжить работу на платформе SberUnity",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Продолжить",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "changePasswordForm",
            "sysName": "auth_ru_changePasswordForm",
            "titleForm": "Создание нового пароля",
            "visible": true,
            "position": 1,
            "config": {},
            "helpDescription": [
                "Только латинские буквы ",
                "Минимум 8 символов",
                "Не менее 6 различных символов",
                "Хотя бы 1 заглавная и 1 строчная буквы",
                "Хотя бы 1 специальный символ, например «! _ : ;»"
            ],
            "fields": [
                {
                    "type": "newPassword",
                    "label": "Новый пароль"

                },
                {
                    "type": "confirmPassword",
                    "label": "Повторить пароль",
                    "confirmPasswordLabel": "Повторить пароль"
                }
            ],
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_userAgreementForm_button",
                "text": "Создать пароль",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        },
        {
            "type": "infoPasswordIsExpiredForm",
            "sysName": "auth_ru_infoPasswordIsExpiredForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Вход",
            "titleInfoForm": "Временный пароль больше не действует",
            "textDescription": "Мы отправили на **{email}** новый пароль. Пройдите по ссылке из письма и придумайте постоянный.",
            "text": "Если письмо не пришло, поищите его в \"Спаме\" от  **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "auth_ru_infoPasswordIsExpiredForm_button",
                "text": "Войти",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        }
    ]
}'
where uri = '/auth'
  and lang_id = 1;