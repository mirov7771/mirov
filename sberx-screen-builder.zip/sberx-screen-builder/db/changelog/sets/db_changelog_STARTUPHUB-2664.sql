--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-2664
UPDATE screen
SET buttons='{
  "buttons": [
    {
      "text": "Поделиться",
      "сode": "100003"
    }
  ]
}'
WHERE formname='startup_SuperClient';


UPDATE screen
SET buttons='{
  "buttons": [
    {
      "text": "Поделиться",
      "сode": "100003"
    }
  ]
}'
WHERE formname='investor_SuperClient';

UPDATE screen
SET buttons='{
  "buttons": [
    {
      "text": "Поделиться",
      "сode": "100003"
    }
  ]
}'
WHERE formname='corporate_SuperClient';



INSERT INTO screen
(id, clientid, "type", formname, formview, "name", pages)
VALUES((select max(id) + 1 from screen ), '111260', 0, 'startup_blur', '{
  "form": [
    {
      "module": "Основная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "title": "Перейти",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Является выпускником:",
          "type": "array",
          "format": "text",
          "activity": [
            26000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год основания",
          "type": "int",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_interactionType",
          "localName": "Модель продаж",
          "type": "array",
          "format": "text",
          "activity": [
            8000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_industry",
          "localName": "Индустрии проекта",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии проекта",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "text",
          "activity": [
            27000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "text",
          "activity": [
            5000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "Ссылка на демо",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Презентация",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых работает стартап",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые стартап планирует выйти в будущем",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 1,
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами ",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Команда",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна, где находится команда",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город, где находится команда",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "edited": false,
          "required": false,
          "direction": "row",
          "isBlur": true
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "edited": false,
          "required": false,
          "direction": "row",
          "isBlur": true
        }
      ]
    },
    {
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "moduleNote": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Успешные B2C-, C2C- кейсы",
      "moduleNote": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Привлекаете ли вы инвестиции?",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма (USD)",
          "type": "int",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    }
  ]
}', 'Просмотр анкеты стартапа в неавторизованной зоне', 1);

INSERT INTO screen
(id, clientid, "type", formname, formview, "name", pages)
VALUES((select max(id) + 1 from screen ), '8385', 0, 'startup_blur', '{
  "form": [
    {
      "module": "Основная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "title": "Перейти",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Является выпускником:",
          "type": "array",
          "format": "text",
          "activity": [
            26000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год основания",
          "type": "int",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_interactionType",
          "localName": "Модель продаж",
          "type": "array",
          "format": "text",
          "activity": [
            8000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_industry",
          "localName": "Индустрии проекта",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии проекта",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "text",
          "activity": [
            27000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "text",
          "activity": [
            5000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "Ссылка на демо",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Презентация",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "hyperlink",
          "title": "Смотреть",
          "format": "button",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых работает стартап",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые стартап планирует выйти в будущем",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 1,
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами ",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Команда",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна, где находится команда",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город, где находится команда",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "edited": false,
          "required": false,
          "direction": "row",
          "isBlur": true
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "edited": false,
          "required": false,
          "direction": "row",
          "isBlur": true
        }
      ]
    },
    {
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "moduleNote": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Успешные B2C-, C2C- кейсы",
      "moduleNote": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Привлекаете ли вы инвестиции?",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма (USD)",
          "type": "int",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    }
  ]
}', 'Просмотр анкеты стартапа в неавторизованной зоне', 1);



INSERT INTO screen
(id, clientid, "type", formname, formview, "name", pages)
VALUES((select max(id) + 1 from screen ), '8385', 1, 'corporate_blur', '{
  "form": [
    {
      "module": "Основная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Описание",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_industry",
          "localName": "Направление деятельности",
          "type": "array",
          "format": "text",
          "activity": [
            22000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_innovationMethod",
          "localName": "Методы работы с инновациями",
          "type": "array",
          "format": "text",
          "activity": [
            4000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт коорпорации",
          "title": "Перейти",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Email",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Работа со стартапами",
      "page": 1,
      "fields": [
        {
          "sysName": "project_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_stady",
          "localName": "Стадии развития продуктов",
          "type": "array",
          "format": "text",
          "activity": [
            7000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "isArray": "true",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotId",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnairePilots[]_suggestCase",
          "localName": "Описание потребности",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "fields": [
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_geography",
          "localName": "География",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "triggerField": "investment_investment",
      "triggerValue": "true",
      "moduleFormat": "card",
      "isArray": true,
      "fields": [
        {
          "sysName": "successPilots[]_pilotid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "successPilots[]_company",
          "localName": "Успешный кейсы",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    }
  ]
}', 'Просмотр анкеты корпорации в неавторизованной зоне', 1);

INSERT INTO screen
(id, clientid, "type", formname, formview, "name", pages)
VALUES((select max(id) + 1 from screen ), '111260', 1, 'corporate_blur', '{
  "form": [
    {
      "module": "Основная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Описание",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_industry",
          "localName": "Направление деятельности",
          "type": "array",
          "format": "text",
          "activity": [
            22000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_innovationMethod",
          "localName": "Методы работы с инновациями",
          "type": "array",
          "format": "text",
          "activity": [
            4000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт коорпорации",
          "title": "Перейти",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Email",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Работа со стартапами",
      "page": 1,
      "fields": [
        {
          "sysName": "project_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_stady",
          "localName": "Стадии развития продуктов",
          "type": "array",
          "format": "text",
          "activity": [
            7000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "isArray": "true",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotId",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnairePilots[]_suggestCase",
          "localName": "Описание потребности",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "fields": [
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "project_geography",
          "localName": "География",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "triggerField": "investment_investment",
      "triggerValue": "true",
      "moduleFormat": "card",
      "isArray": true,
      "fields": [
        {
          "sysName": "successPilots[]_pilotid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "successPilots[]_company",
          "localName": "Успешный кейсы",
          "type": "string",
          "format": "body",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    }
  ]
}', 'Просмотр анкеты корпорации в неавторизованной зоне', 1);

INSERT INTO screen
(id, clientid, "type", formname, formview, "name", pages)
VALUES((select max(id) + 1 from screen ), '111260', 2, 'investor_blur', '{
  "form": [
    {
      "module": "Основная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Тип инвестора",
          "type": "array",
          "format": "text",
          "activity": [
            11000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Краткое описание",
          "type": "string",
          "format": "text",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_fullnote",
          "localName": "Описание",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_portfolioNote",
          "localName": "Краткое описание портфельного стартапа",
          "type": "string",
          "maxLength": "300",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "title": "Перейти",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Email",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "fields": [
        {
          "sysName": "investment_industry",
          "localName": "Индустрии инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_technology",
          "localName": "Технологии инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_geography",
          "localName": "География стартапов",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_note",
          "localName": "Особые условия инвестирования",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество стартапов, в которые инвестировал фонд",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество инвестиций в стартапы",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество стартапов, в которые инвестировал фонд",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество стартапов, в которые инвестировал фонд",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "type": "int",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Портфель",
      "page": 1,
      "isArray": true,
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}','Просмотр анкеты инвестора в неавторизованной зоне', 1);

INSERT INTO screen
(id, clientid, "type", formname, formview, "name", pages)
VALUES((select max(id) + 1 from screen ), '8385', 2, 'investor_blur', '{
  "form": [
    {
      "module": "Основная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Тип инвестора",
          "type": "array",
          "format": "text",
          "activity": [
            11000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Краткое описание",
          "type": "string",
          "format": "text",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_fullnote",
          "localName": "Описание",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_portfolioNote",
          "localName": "Краткое описание портфельного стартапа",
          "type": "string",
          "maxLength": "300",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "title": "Перейти",
          "type": "hyperlink",
          "format": "button",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Email",
          "type": "string",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "fields": [
        {
          "sysName": "investment_industry",
          "localName": "Индустрии инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_technology",
          "localName": "Технологии инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            13000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_geography",
          "localName": "География стартапов",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестиций",
          "type": "array",
          "format": "text",
          "activity": [
            6000
          ],
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "investment_note",
          "localName": "Особые условия инвестирования",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество стартапов, в которые инвестировал фонд",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество инвестиций в стартапы",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество стартапов, в которые инвестировал фонд",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество стартапов, в которые инвестировал фонд",
          "type": "int",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "type": "int",
          "edited": false,
          "required": false,
          "isBlur": true
        }
      ]
    },
    {
      "module": "Портфель",
      "page": 1,
      "isArray": true,
      "moduleFormat": "card",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": false,
          "required": false,
          "isBlur": true
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "type": "string",
          "format": "heading",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}','Просмотр анкеты инвестора в неавторизованной зоне', 1);