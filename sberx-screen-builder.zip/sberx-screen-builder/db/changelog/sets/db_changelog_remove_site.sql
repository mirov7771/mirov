--liquibase formatted sql
--changeset Mirov AA:remove_site
update  public.screen s
set formview = '
{
  "form":[
    {
      "module": "",
      "page": 1,
      "fields": [
        {
          "sysName": "Project_Note"
        ,"localName": ""
        ,"type": "string"
        ,"edited": false
        ,"required": false
        },{
          "sysName": "Questionnaire_Birthday"
        ,"localName": "Год основания"
        ,"type": "date"
        ,"edited": false
        ,"required": false
        ,"direction": "row"
        ,"format": "YYYY"
        },{
          "sysName": "Project_Staff"
        ,"localName": "Количество сотрудников"
        ,"type": "int"
        ,"edited": false
        ,"required": false
        ,"direction": "row"
        },{
          "sysName": "Project_Industry"
        ,"localName": "Технологии и направления"
        ,"type": "array"
        ,"format": "chip"
        ,"activity": [3000]
        ,"edited": false
        ,"required": false
        }
      ]
    }
  ]
}'
where formname = 'startup'