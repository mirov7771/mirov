--liquibase formatted sql
--changeset MirovAA:STARTUPHUB-4668_2
update public.screen
   set formedit = cast(replace(cast(formedit as text), 'triggered', 'trigger') as json)
 where cast(formedit as text) like '%triggered%'