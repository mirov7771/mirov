--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5237
delete from page_values_cache where name = '%available_scouting%';
insert into page_values_cache
values ('%available_scouting%', 0, 0, null, 'GET', '/scouting');

