--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4564


update public.pages
set page = '{
   "features":[
	{
         "type":"breadcrumbs",
         "sysName":"vas_ru_breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Главная",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Сервисы"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"vas_en_pageTitle",
         "title":"Эксклюзивные предложения для стартапов",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_ru",
         "visible":true,
         "position":2,
         "placeholder":"Введите название",
         "loginDescription":"Присоединяйтесь к платформе,<br/>чтобы воспользоваться предложением сервиса",
         "joinButtonName":"Присоединиться",
         "loginButtonName":"Войти",
         "alphabetically":"По алфавиту",
         "byUpdateDate": "По дате обновления",
         "byCreationDate":"По дате создания",
         "contractOffer": "Ознакомиться с договором на размещение в разделе \"Сервисы\" можно [здесь](https://sberunity.ru/sberx-gateway/file/vas_offer.pdf)"
      }
   ]
}'
where uri = '/vas'
  and page_type = 'unauth'
  and lang_id = 1;


update public.pages
set page = '{
   "features":[
      {
         "type":"breadcrumbs",
         "sysName":"vas_en_breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Main",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Services"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"vas_en_pageTitle",
         "title":"Exclusive offers for startups",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vas_vasSearch_en",
         "visible":true,
         "position":2,
         "placeholder":"Enter a name",
         "loginDescription": "Join the platform <br/>to take advantage of the service offer",
         "joinButtonName": "Join",
         "loginButtonName": "Log in",
         "alphabetically":"Alphabetically",
         "byUpdateDate": "By Update Date",
         "byCreationDate":"By Creation Date",
         "contractOffer": "You can read the accommodation agreement in the \"Services\" section [here](https://sberunity.ru/sberx-gateway/file/vas_offer.pdf)"
      }
   ]
}'
where uri = '/vas'
  and page_type = 'unauth'
  and lang_id = 2