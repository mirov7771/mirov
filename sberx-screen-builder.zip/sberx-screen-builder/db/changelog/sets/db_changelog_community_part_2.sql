--liquibase formatted sql
--changeset Mirov AA:community_part_2

INSERT INTO public.feature_types (code, name) VALUES
('mainHeader', 'Заголовок'),
('button', 'Кнопка'),
('bigNSmallGallery', 'Галерея с большим и малым изображениями'),
('mainTabs', 'Главные табы'),
('squareList', 'Список квадратных плиток'),
('flatTabs', 'Плоские табы'),
('nearby', 'Мы рядом'),
('banner', 'Баннер'),
('bulletBanner', 'Заголовок'),
('carousel', 'Карусель'),
('events', 'События'),
('offsetSquares', 'Плитки со смещениями'),
('socialTiles', 'Список квадратных плиток'),
('squareRow', 'Квадратные плитки'),
('roadMap', 'Роадмап'),
('rectangTiles', 'rectangTiles');



INSERT INTO public.status_types (code, name) VALUES
('created', 'Создан'),
('activated', 'Активный'),
('published', 'Опубликованный'),
('disabled', 'Неактивный'),
('deleted', 'Удален');






INSERT INTO public.features (id, code, name, status, feature_type, description) VALUES
(1,'cMainHeader_1', 'Заголовок, главный','published','mainHeader',DEFAULT),
(2,'cMainHeader_1_button_1', 'Кнопка баннера Заголовка','published','button',DEFAULT),
(3,'cMainHeader_1_bigNSmallGallery_1', 'Кнопка баннера Заголовка','published','bigNSmallGallery',DEFAULT),
(4,'cMainTabs_1', 'Главные табы','published','mainTabs',DEFAULT),
(5,'сSquareList_startup_1', 'Что вам будет доступно (плитки)','published','squareList',DEFAULT),
(6,'cFlatTabs_startup_1', 'Плоские табы','published','flatTabs',DEFAULT),
(7,'сRoadMap_startup_1', 'Роадмап "Новым участникам"','published','roadMap',DEFAULT),
(8,'сRoadMap_startup_2', 'Роадмап "Участникам SberUnity"','published','roadMap',DEFAULT),
(9,'cNearby_startup_1', 'Мы рядом','published','nearby',DEFAULT),
(10,'cNearbyBanner_startup_1', 'Баннер. Онлайн','published','banner',DEFAULT),
(11,'cNearbyBanner_startup_2', 'Баннер. Оффлайн','published','banner',DEFAULT),
(12,'cNearbyBanner_startup_3', 'Баннер. Сообщество СберСтартап','published','banner',DEFAULT),
(13,'cNearbyBanner_startup_3_button_1', 'Кнопка виджета "Мы рядом"','published','button',DEFAULT),
(14,'cBulletBanner_investor_1', 'Баннер с буллитами. Соинвестируйте с профессионалами рынка','published','bulletBanner',DEFAULT),
(15,'cRectangTiles_investor_1', 'Прямоугольные плитки. Уже в сообществе','published','rectangTiles',DEFAULT),
(16,'cSquareRow_investor_1', 'Квадратные плитки. Большая воронка стартапов на российском рынке','published','squareRow',DEFAULT),
(17,'cRectangTiles_investor_2', 'Прямоугольные плитки. Наши акселераторы','published','rectangTiles',DEFAULT),
(18,'cBulletBanner_investor_2', 'Баннер с буллитами. Всё, что нужно — уже под рукой','published','bulletBanner',DEFAULT),
(19,'cCarousel_1', 'Карусель изображений','published','carousel',DEFAULT),
(20,'cEvents_1', 'Календарь событий','published','events',DEFAULT),
(21,'cOffsetSquares_1', 'Плитки со смещением','published','offsetSquares',DEFAULT),
(22,'cEvents_1_button_1', 'Кнопка календаря событий','published','button',DEFAULT),
(23,'cSocialTiles_1', 'Плитки социальных сетей','published','socialTiles',DEFAULT),
(24,'cSocialTiles_1_button_1', 'Кнопка плитки Telegram','published','button',DEFAULT),
(25,'cSocialTiles_1_button_2', 'Кнопка плитки подкаста','published','button',DEFAULT),
(26,'cSocialTiles_1_button_3', 'Кнопка плитки блога','published','button',DEFAULT),
(27,'cSocialTiles_1_button_4', 'Кнопка плитки Youtube-шоу','published','button',DEFAULT),
(28,'cFooterBanner_1', 'Баннер футера','published','banner',DEFAULT),
(29,'cFooterBanner_1_button_1', 'Кнопка баннера футера','published','button',DEFAULT);

-- ALTER SEQUENCE public.features_id_seq  RESTART WITH 30;
select setval('public.features_id_seq',  (SELECT max(id) FROM public.features));



INSERT INTO public.attribute_types (code, name) VALUES
('varchar', 'Строка'),
('bigint', ' Большое целочисленное'),
('bool', 'Булевое'),
('list', 'Список'),
('object', 'Объект');




--is_system=TRUE
INSERT INTO public.attributes (id, name, code, is_system, attribute_type) VALUES
(1,'Видимость', 'visible',TRUE,'bool'),
(2,'Позиция (сортировка)', 'position',TRUE,'bigint'),
(3,'Позиция в таблице', 'tablePosition',TRUE,'object'),
(4,'Конфигурация', 'config',TRUE,'object'),
(5,'Ссылка на изображение', 'imageUrl',FALSE,'varchar'),
(6,'Список', 'items',TRUE,'list'),
(7,'Выставлен по умолчанию', 'isDefault',TRUE,'bool'),
(8,'Активен', 'isActive',TRUE,'bool'),
(9,'Главный', 'isMain',TRUE,'bool'),
(10,'Дефолтное состояние', 'default',TRUE,'varchar'),
(11,'Действие', 'action',TRUE,'varchar'),
(12,'Конфигурация таблицы', 'tableConfiguration',TRUE,'list'),
(13,'Порядковый номер столбца', 'columnNumber',TRUE,'bigint'),
(14,'Количество строк', 'rows',TRUE,'bigint'),
(15,'Направление', 'direction',TRUE,'varchar'),
(16,'Автовоспроизведение', 'autorotation',TRUE,'bool'),
(17,'Задержка', 'delay',TRUE,'bigint'),
(18,'Скорость', 'speed',TRUE,'bigint'),
(19,'Строка', 'row',TRUE,'bigint'),
(20,'Колонка', 'column',TRUE,'bigint'),
(31,'Фича', 'features',TRUE,'list'),
(32,'Направление смещения', 'offsetDirection',TRUE,'varchar'),
(33,' Массив изображений', 'images',TRUE,'list'),
--is_system=FALS,
(21,'Заголовок', 'header',FALSE,'varchar'),
(22,'Титул (подзаголовок)', 'title',FALSE,'varchar'),
(23,'Описание', 'description',FALSE,'varchar'),
(24,'Категория', 'category',FALSE,'varchar'),
(25,'Текст', 'text',FALSE,'varchar'),
(26,'Ссылка на иконку', 'iconUrl',FALSE,'varchar'),
(27,'Ссылка', 'url',FALSE,'varchar'),
(28,'Текст бейджа', 'badgeText',FALSE,'varchar'),
(29,'Ссылка на фоновое изображение', 'backgroundUrl',FALSE,'varchar'),
(30,'Текстовые буллеты', 'bullets',FALSE,'list');

select setval('public.attributes_id_seq',  (SELECT max(id) FROM public.attributes));




INSERT INTO public.page_types (code, name) VALUES
('unauth', 'Авторизованная зона'),
('auth', 'Неавторизованная зона');


INSERT INTO public.locale (code, name) VALUES
('ru', 'Русский'),
('en', 'Английский'),
('cn', 'Китайский'),
('es', 'Испанский'),
('tj', 'Таджикский'),
('uz', 'Узбекский'),
('ge', 'Грузинский');


INSERT INTO public.pages (id, code, name, uri, description, page_type, parent_id) VALUES
(1, 'community_az', 'Авторизованная зона. СберСтартап. Сообщество','/community','Подайте заявку и станьте частью сообщества СберСтартап', 'unauth', DEFAULT),
(2, 'community_nz', 'Неавторизованная зона. СберСтартап. Сообщество','/community','Оставайтесь частью сообщества СберСтартап' , 'auth', DEFAULT);

select setval('public.pages_id_seq',  (SELECT max(id) FROM public.pages));


INSERT INTO public.pages_features (id_features, id_pages, is_visible) VALUES
(1,2,TRUE),
(4,2,TRUE),
(19,2,TRUE),
(20,2,TRUE),
(23,2,TRUE),
(28,2,TRUE);




insert into public.values (id, value, locale) values
(1, 'true', 'ru'),
(2, '1', 'ru'),
(3, 'СберСтартап', 'ru'),
(4, 'сообщество', 'ru'),
(5, 'Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач', 'ru'),
(6, 'simple', 'ru'),
(7, 'true', 'ru'),
(8, 'active', 'ru'),
(9, 'Стать частью сообщества', 'ru'),
(10, 'URL', 'ru'),
(11, 'redirect', 'ru'),
(12, 'true', 'ru'),
(13, 'URL', 'ru'),
(14, 'true', 'ru'),
(15, 'URL', 'ru'),
(16, 'false', 'ru'),
(17, 'true', 'ru'),
(18, '2', 'ru'),
(19, 'Стартапам', 'ru'),
(20, 'true', 'ru'),
(21, 'true', 'ru'),
(22, 'true', 'ru'),
(23, 'URL', 'ru'),
(24, 'Что вам будет доступно', 'ru'),
(25, 'Нетворкинг', 'ru'),
(26, 'Живое общение с близкими по интересам', 'ru'),
(27, 'iconUrl', 'ru'),
(28, 'Экспертиза', 'ru'),
(29, 'Консультации от профи', 'ru'),
(30, 'iconUrl', 'ru'),
(31, 'Контент', 'ru'),
(32, 'Актуальные новости венчурной индустрии, советы экспертов, интервью с лидерами рынка', 'ru'),
(33, 'iconUrl', 'ru'),
(34, 'Мероприятия', 'ru'),
(35, 'Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны', 'ru'),
(36, 'iconUrl', 'ru'),
(37, 'Закрытый стартап-клуб', 'ru'),
(38, 'Эксклюзивные мероприятия с инвесторами', 'ru'),
(39, 'iconUrl', 'ru'),
(40, 'Поддержка', 'ru'),
(41, 'Обмен опытом и помощь в решении бизнес-кейсов', 'ru'),
(42, 'iconUrl', 'ru'),
(43, '1', 'ru'),
(44, 'Как попасть в сообщество СберСтартап', 'ru'),
(45, 'true', 'ru'),
(46, 'Новым участникам', 'ru'),
(47, 'true', 'ru'),
(48, '1', 'ru'),
(49, 'true', 'ru'),
(50, '1', 'ru'),
(51, 'Зарегистрируйтесь на платформе', 'ru'),
(52, 'Станьте резидентом SberUnity, чтобы присоединиться к сообществу', 'ru'),
(53, 'iconUrl', 'ru'),
(54, 'Заполните анкету сообщества', 'ru'),
(55, 'Она находится в личном кабинете в разделе «Сообщество»', 'ru'),
(56, 'iconUrl', 'ru'),
(57, 'Дождитесь результата', 'ru'),
(58, 'В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью', 'ru'),
(59, 'iconUrl', 'ru'),
(60, 'Присоединитесь к нам', 'ru'),
(61, 'После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами', 'ru'),
(62, 'iconUrl', 'ru'),
(63, 'Участникам SberUnity', 'ru'),
(64, 'false', 'ru'),
(65, '2', 'ru'),
(66, 'true', 'ru'),
(67, '1', 'ru'),
(68, 'Заполните анкету сообщества', 'ru'),
(69, 'Она находится в личном кабинете в разделе «Сообщество»', 'ru'),
(70, 'iconUrl', 'ru'),
(71, 'Дождитесь результата', 'ru'),
(72, 'В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью', 'ru'),
(73, 'iconUrl', 'ru'),
(74, 'Присоединитесь к нам', 'ru'),
(75, 'После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами', 'ru'),
(76, 'iconUrl', 'ru'),
(77, '1', 'ru'),
(78, 'Мы рядом с вами', 'ru'),
(79, 'true', 'ru'),
(80, 'Онлайн', 'ru'),
(81, 'true', 'ru'),
(82, 'На платформе Telegram и онлайн-событиях', 'ru'),
(83, 'iconUrl', 'ru'),
(84, '1', 'ru'),
(85, '1', 'ru'),
(86, 'Оффлайн', 'ru'),
(87, 'true', 'ru'),
(88, 'В собственном коворкинге и на закрытых встречах', 'ru'),
(89, 'iconUrl', 'ru'),
(90, '2', 'ru'),
(91, '1', 'ru'),
(92, 'Сообщество СберСтартап', 'ru'),
(93, 'true', 'ru'),
(94, 'Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!', 'ru'),
(95, 'backgroundUrl', 'ru'),
(96, 'simple', 'ru'),
(97, 'active', 'ru'),
(98, 'Стать частью сообщества', 'ru'),
(99, 'url', 'ru'),
(100, 'redirect', 'ru'),
(101, '1', 'ru'),
(102, '2', 'ru'),
(103, '1', 'ru'),
(104, '2', 'ru'),
(105, '2', 'ru'),
(106, '1', 'ru'),
(107, '3', 'ru'),
(108, '1', 'ru'),
(109, 'true', 'ru'),
(110, 'false', 'ru'),
(111, 'true', 'ru'),
(112, 'iconUrl', 'ru'),
(113, 'true', 'ru'),
(114, 'Соинвестируйте с профессионалами рынка', 'ru'),
(115, 'Снижайте риски, соинвестируя с лучшими венчурными фондами_|_Обеспечьте себе поток лучших сделок_|_Расширьте портфель за счёт низкого входного чека_|_Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки', 'ru'),
(116, 'left', 'ru'),
(117, '1', 'ru'),
(118, 'true', 'ru'),
(119, 'Уже в сообществе', 'ru'),
(120, 'https://.jpg_|_https://.jpg_|_https://.jpg_|_https://.jpg', 'ru'),
(121, '2', 'ru'),
(122, 'true', 'ru'),
(123, 'Большая воронка стартапов на российском рынке', 'ru'),
(124, 'Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity', 'ru'),
(125, 'Знакомим', 'ru'),
(126, 'с основателями стартапов', 'ru'),
(127, 'iconUrl', 'ru'),
(128, 'Проводим', 'ru'),
(129, 'предварительный скоринг', 'ru'),
(130, 'iconUrl', 'ru'),
(131, 'Рекомендуем', 'ru'),
(132, 'только отобранные проекты', 'ru'),
(133, 'iconUrl', 'ru'),
(134, 'Объединяем', 'ru'),
(135, 'инвесторов и стартапы', 'ru'),
(136, 'iconUrl', 'ru'),
(137, '3', 'ru'),
(138, 'true', 'ru'),
(139, 'Наши акселераторы', 'ru'),
(140, 'https://.jpg_|_https://.jpg_|_https://.jpg_|_https://.jpg', 'ru'),
(141, '4', 'ru'),
(142, 'true', 'ru'),
(143, 'Всё, что нужно — уже под рукой', 'ru'),
(144, 'Мы организовали сообщество в Slack-каналах', 'ru'),
(145, 'Разделяйте деловые и личные мессенджеры_|_Структурируйте инофрмацию в тематических каналах_|_Только релевантные сообщения, без спама и рекламы_|_Полная информация о сделке всегда доступна', 'ru'),
(146, 'left', 'ru'),
(147, '3', 'ru'),
(148, '2', 'ru'),
(149, 'Корпорациям', 'ru'),
(150, 'true', 'ru'),
(151, 'false', 'ru'),
(152, 'false', 'ru'),
(153, 'Скоро', 'ru'),
(154, 'iconUrl', 'ru'),
(155, '3', 'ru'),
(156, 'true', 'ru'),
(157, '3', 'ru'),
(158, 'Направления сообщества', 'ru'),
(159, 'Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем Вас стать частью проектов сообщества', 'ru'),
(160, 'https://.jpg_|_https://.jpg_|_https://.jpg_|_https://.jpg', 'ru'),
(161, 'false', 'ru'),
(162, '3', 'ru'),
(163, '100', 'ru'),
(164, 'left', 'ru'),
(165, 'true', 'ru'),
(166, 'Событийная кухня', 'ru'),
(167, 'Закрывайте бизнес-потребности через нетворкинг', 'ru'),
(168, 'С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для Вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.', 'ru'),
(169, '4', 'ru'),
(170, 'true', 'ru'),
(171, 'Партнерские мероприятия', 'ru'),
(172, 'imageUrl', 'ru'),
(173, '1', 'ru'),
(174, '1', 'ru'),
(175, 'Хакатоны и интенсивы', 'ru'),
(176, 'imageUrl', 'ru'),
(177, '1', 'ru'),
(178, '2', 'ru'),
(179, 'Мероприятия с другими фондами и сообществами', 'ru'),
(180, 'imageUrl', 'ru'),
(181, '2', 'ru'),
(182, '1', 'ru'),
(183, 'Выезды и вечеринки', 'ru'),
(184, 'imageUrl', 'ru'),
(185, '2', 'ru'),
(186, '2', 'ru'),
(187, 'Закрытые очные встречи', 'ru'),
(188, 'imageUrl', 'ru'),
(189, '3', 'ru'),
(190, '1', 'ru'),
(191, 'Онлайн-митапы', 'ru'),
(192, 'imageUrl', 'ru'),
(193, '3', 'ru'),
(194, '2', 'ru'),
(195, '1', 'ru'),
(196, '2', 'ru'),
(197, '2', 'ru'),
(198, '2', 'ru'),
(199, 'right', 'ru'),
(200, '3', 'ru'),
(201, '2', 'ru'),
(202, 'simple', 'ru'),
(203, 'true', 'ru'),
(204, 'active', 'ru'),
(205, 'Календарь событий', 'ru'),
(206, 'iconUrl', 'ru'),
(207, 'url', 'ru'),
(208, 'redirect', 'ru'),
(209, 'Контент-студия', 'ru'),
(210, 'true', 'ru'),
(211, 'Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера', 'ru'),
(212, 'Сберстартап', 'ru'),
(213, 'Telegram-канал', 'ru'),
(214, 'imageUrl', 'ru'),
(215, 'Советы экспертов, новости венчурной индустрии, анонсы событий', 'ru'),
(216, 'simple', 'ru'),
(217, 'active', 'ru'),
(218, 'Подписаться', 'ru'),
(219, 'https://cons.ru/im.jpg', 'ru'),
(220, 'url', 'ru'),
(221, 'redirect', 'ru'),
(222, 'Три запятые', 'ru'),
(223, 'Подкаст', 'ru'),
(224, 'imageUrl', 'ru'),
(225, 'Разговоры о том, как изменить мир и заработать заветный миллиард', 'ru'),
(226, 'simple', 'ru'),
(227, 'active', 'ru'),
(228, 'Подписаться', 'ru'),
(229, 'url', 'ru'),
(230, 'redirect', 'ru'),
(231, 'VC.RU', 'ru'),
(232, 'Блог', 'ru'),
(233, 'imageUrl', 'ru'),
(234, 'Успешные и не очень кейсы участников сообщества', 'ru'),
(235, 'simple', 'ru'),
(236, 'active', 'ru'),
(237, 'Подписаться', 'ru'),
(238, 'url', 'ru'),
(239, 'redirect', 'ru'),
(240, 'Для стартапов', 'ru'),
(241, 'YouTube-шоу', 'ru'),
(242, 'imageUrl', 'ru'),
(243, 'Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями', 'ru'),
(244, 'simple', 'ru'),
(245, 'inactive', 'ru'),
(246, 'Скоро', 'ru'),
(247, 'iconUrl', 'ru'),
(248, 'redirect', 'ru'),
(249, '4', 'ru'),
(250, 'true', 'ru'),
(251, 'Подайте заявку и станьте частью сообщества СберСтартап', 'ru'),
(252, 'backgroundUrl', 'ru'),
(253, '5', 'ru'),
(254, 'simple', 'ru'),
(255, 'active', 'ru'),
(256, 'Стать частью сообщества', 'ru'),
(257, 'url', 'ru'),
(258, 'redirect', 'ru'),
(259, null, 'ru'),
(260, null, 'ru'),
(261, null, 'ru'),
(262, null, 'ru'),
(263, null, 'ru'),
(264, null, 'ru'),
(265, null, 'ru'),
(266, null, 'ru'),
(267, null, 'ru'),
(268, null, 'ru'),
(269, null, 'ru'),
(270, null, 'ru'),
(271, null, 'ru'),
(273, null, 'ru'),
(274, null, 'ru'),
(275, null, 'ru'),
(276, null, 'ru'),
(277, null, 'ru'),
(278, null, 'ru'),
(279, null, 'ru'),
(280, null, 'ru'),
(281, null, 'ru'),
(282, null, 'ru'),
(283, null, 'ru'),
(284, null, 'ru'),
(285, null, 'ru'),
(286, null, 'ru'),
(287, null, 'ru'),
(288, 'Инвесторам', 'ru'),
(289, null, 'ru'),
(290, null, 'ru'),
(291, null, 'ru'),
(292, null, 'ru'),
(293, null, 'ru'),
(294, null, 'ru'),
(295, null, 'ru'),
(296, null, 'ru'),
(297, null, 'ru'),
(298, null, 'ru'),
(299, null, 'ru'),
(300, null, 'ru'),
(301, null, 'ru'),
(302, null, 'ru'),
(303, null, 'ru'),
(304, null, 'ru'),
(305, null, 'ru'),
(306, null, 'ru'),
(307, null, 'ru'),
(308, null, 'ru'),
(309, null, 'ru'),
(310, null, 'ru'),
(311, null, 'ru'),
(312, null, 'ru'),
(313, null, 'ru'),
(314, null, 'ru'),
(315, null, 'ru'),
(316, null, 'ru'),
(317, null, 'ru'),
(318, 'true', 'ru'),
(319, null, 'ru'),
(320, null, 'ru'),
(321, null, 'ru'),
(322, 'true', 'ru'),
(323, null, 'ru'),
(324, null, 'ru'),
(325, null, 'ru'),
(326, 'true', 'ru'),
(327, null, 'ru'),
(328, null, 'ru'),
(329, null, 'ru'),
(330, null, 'ru'),
(331, null, 'ru'),
(332, null, 'ru'),
(333, 'true', 'ru'),
(334, null, 'ru'),
(335, null, 'ru'),
(336, null, 'ru'),
(337, null, 'ru'),
(338, null, 'ru'),
(339, null, 'ru'),
(340, null, 'ru'),
(341, '1', 'ru'),
(342, null, 'ru'),
(343, 'redirect', 'ru'),
(344, '3', 'ru'),
(345, null, 'ru'),
(346, 'true', 'ru');


select setval('public.values_id_seq',  (SELECT max(id) FROM public.values));
--




INSERT INTO public.feature_attributes_values (id, id_attributes, id_values, id_features, id_parent, status, group_id) VALUES
--"type" : "mainHeader"
--"visible": true,
(1,1,1,1,DEFAULT,'published',DEFAULT),
--"position": 1,
(2,2,2,1,DEFAULT,'published',DEFAULT),
--"header": "СберСтартап",
(3,21,3,1,DEFAULT,'published',DEFAULT),
--"title": "сообщество",
(4,22,4,1,DEFAULT,'published',DEFAULT),
--"description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
(5,23,5,1,DEFAULT,'published',DEFAULT),
--"features": [
(6,31,265,1,DEFAULT,'published',DEFAULT),
    -- {
        --"type" : "button"
        --"category": "simple"
        (7,24,6,2,6,'published',DEFAULT),
        --"visible": true,
        (8,1,7,2,6,'published',DEFAULT),
        --"default": "active",
        (9,10,8,2,6,'published',DEFAULT),
        --"text": "Стать частью сообщества",
        (10,25,9,2,6,'published',DEFAULT),
        --"iconUrl": null,
        (11,26,335,2,6,'published',DEFAULT),
        --"url": "",
        (12,27,10,2,6,'published',DEFAULT),
        --"action": "redirect"
        (13,11,11,2,6,'published',DEFAULT),
        --"config":{}
        (14,4,261,2,6,'published',DEFAULT),
    -- }
    -- {
        --"type" : "bigNSmallGallery"
        --"visible": true,
        (15,1,12,3,6,'published',DEFAULT),
        --"images": [
        (16,33,336,3,6,'published',DEFAULT),
            --[1]
                --"url": "https://cons.ru/im.jpg",
                (17,27,13,DEFAULT,16,'published',1),
                --"isMain": true
                (18,9,14,DEFAULT,16,'published',1),
            --[2]
                --"url": "https://cons.ru/im.jpg",
                (19,27,15,DEFAULT,16,'published',2),
                --"isMain": true
                (20,9,16,DEFAULT,16,'published',2),
        -- ]
        --"config":{}
        (21,4,262,3,6,'published',DEFAULT),
    -- }
-- ]
--"config": {}
(22,4,260,1,DEFAULT,'published',DEFAULT),


--"type": mainTabs
--"visible": true,
(23,1,17,4,DEFAULT,'published',DEFAULT),
--"position": 2,
(24,2,18,4,DEFAULT,'published',DEFAULT),
--"config": {}
(25,4,298,4,DEFAULT,'published',DEFAULT),
--"items" : [
(26,6,263,4,DEFAULT,'published',DEFAULT),
        --[1]
            --"title": "Стартапам",
            (27,22,19,DEFAULT,26,'published',1),
            --"visible": true,
            (28,1,20,DEFAULT,26,'published',1),
            --"isDefault": true,
            (29,7,21,DEFAULT,26,'published',1),
            --"isActive": true,
            (30,8,22,DEFAULT,26,'published',1),
            --"badgeText": null,
            (31,28,337,DEFAULT,26,'published',1),
            --"iconUrl": "https://cons.ru/im.jpg",
            (32,26,23,DEFAULT,26,'published',1),
            --"position": 1
            (33,2,43,DEFAULT,26,'published',1),
            --"config": {}
            (34,4,264,DEFAULT,26,'published',1),
            --"features": [
            (35,31,267,DEFAULT,26,'published',1),
                -- {
                    --"type":"squareList"
                    --"title": "Что вам будет доступно"
                    (36,22,24,5,35,'published',DEFAULT),
                    --"items" : [
                    (37,6,266,5,35,'published',DEFAULT),
                            --[1]
                                --"title": "Нетворкинг"
                                (38,22,25,DEFAULT,37,'published',1),
                                --"description": "Живое общение с близкими по интересам",
                                (39,23,26,DEFAULT,37,'published',1),
                                --"iconUrl": "https://cons.ru/im.jpg"
                                (40,26,27,DEFAULT,37,'published',1),
                            --[2]
                                --"title": "Экспертиза",
                                (41,22,28,DEFAULT,37,'published',2),
                                --"description": "Консультации от профи",
                                (42,23,29,DEFAULT,37,'published',2),
                                --"iconUrl": "https://cons.ru/im.jpg"
                                (43,26,30,DEFAULT,37,'published',2),
                            --[3]
                                --"title": "Контент",
                                (44,22,31,DEFAULT,37,'published',3),
                                --"description": "Актуальные новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
                                (45,23,32,DEFAULT,37,'published',3),
                                --"iconUrl": "https://cons.ru/im.jpg"
                                (46,26,33,DEFAULT,37,'published',3),
                            --[4]
                                --"title": "Мероприятия",
                                (47,22,34,DEFAULT,37,'published',4),
                                --"description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
                                (48,23,35,DEFAULT,37,'published',4),
                                --"iconUrl": "https://cons.ru/im.jpg"
                                (49,26,36,DEFAULT,37,'published',4),
                            --[5]
                                --"title": "Закрытый стартап-клуб",
                                (50,22,37,DEFAULT,37,'published',5),
                                --"description": "Эксклюзивные мероприятия с инвесторами",
                                (51,23,38,DEFAULT,37,'published',5),
                                --"iconUrl": "https://cons.ru/im.jpg"
                                (52,26,39,DEFAULT,37,'published',5),
                            --[6]
                                --"title": "Поддержка",
                                (53,22,40,DEFAULT,37,'published',6),
                                --"description": "Обмен опытом и помощь в решении бизнес-кейсов",
                                (54,23,41,DEFAULT,37,'published',6),
                                --"iconUrl": "https://cons.ru/im.jpg"
                                (55,26,42,DEFAULT,37,'published',6),
                    -- ]
                    --"position": 1
                    (56,2,341,5,35,'published',DEFAULT),
                    --"config": {}
                    (57,4,342,5,35,'published',DEFAULT),
                -- }
                -- {
                    --"type": "flatTabs",
                    --"header": "Как попасть в сообщество СберСтартап",
                    (58,21,44,6,35,'published',DEFAULT),
                    --"visible": true,
                    (59,1,45,6,35,'published',DEFAULT),
                    --"items": [
                    (60,6,268,6,35,'published',DEFAULT),
                        --[1]
                                --"title": "Новым участникам"
                                (61,22,46,DEFAULT,60,'published',1),
                                --"isDefault": true,
                                (62,7,47,DEFAULT,60,'published',1),
                                --"position": 1
                                (63,2,48,DEFAULT,60,'published',1),
                                --"features": [
                                (64,31,269,DEFAULT,60,'published',1),
                                        -- {
                                            --"type": "roadMap",
                                            --"visible": true,
                                            (65,1,49,7,64,'published',DEFAULT),
                                            --"position": 1,
                                            (66,2,50,7,64,'published',DEFAULT),
                                            --"config": {},
                                            (67,4,270,7,64,'published',DEFAULT),
                                            --"items": [
                                            (68,6,271,7,64,'published',DEFAULT),
                                                    --[1]
                                                        --"title": "Зарегистрируйтесь на платформе",
                                                        (69,22,51,DEFAULT,68,'published',1),
                                                        --"description": "Станьте резидентом SberUnity, чтобы присоединиться к сообществу",
                                                        (70,23,52,DEFAULT,68,'published',1),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (71,26,53,DEFAULT,68,'published',1),
                                                    --[2]
                                                        --"title": "Заполните анкету сообщества",
                                                        (72,22,54,DEFAULT,68,'published',2),
                                                        --"description": "Она находится в личном кабинете в разделе «Сообщество»",
                                                        (73,23,55,DEFAULT,68,'published',2),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (74,26,56,DEFAULT,68,'published',2),
                                                    --[3]
                                                        --"title": "Дождитесь результата",
                                                        (75,22,57,DEFAULT,68,'published',3),
                                                        --"description": "В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью",
                                                        (76,23,58,DEFAULT,68,'published',3),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (77,26,59,DEFAULT,68,'published',3),
                                                    --[4]
                                                        --"title": "Присоединитесь к нам",
                                                        (78,22,60,DEFAULT,68,'published',4),
                                                        --"description": "После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                                                        (79,23,61,DEFAULT,68,'published',4),
                                                        --"iconUrl": "https://cons.ru/im.jpg"
                                                        (80,26,62,DEFAULT,68,'published',4),
                                            -- ]
                                        -- }
                                -- ]
                        --[2]
                                --"title": "Участникам SberUnity",
                                (81,22,63,DEFAULT,60,'published',2),
                                --"isDefault": false,
                                (82,7,64,DEFAULT,60,'published',2),
                                --"position": 2,
                                (83,2,65,DEFAULT,60,'published',2),
                                --"features": [
                                (84,31,273,DEFAULT,60,'published',2),
                                    -- {
                                        --"type": "roadMap",
                                        --"visible": true,
                                        (85,1,66,8,84,'published',DEFAULT),
                                        --"position": 1,
                                        (86,2,67,8,84,'published',DEFAULT),
                                        --"config": {},
                                        (87,4,274,8,84,'published',DEFAULT),
                                        --"items": [
                                        (88,6,275,8,84,'published',DEFAULT),
                                                --[1]
                                                    --"title": "Заполните анкету сообщества",
                                                    (89,22,68,DEFAULT,88,'published',1),
                                                    --"description": "Она находится в личном кабинете в разделе «Сообщество»",
                                                    (90,23,69,DEFAULT,88,'published',1),
                                                    --"iconUrl": "https://cons.ru/im.jpg"
                                                    (91,26,70,DEFAULT,88,'published',1),
                                                --[2]
                                                    --"title": "Дождитесь результата",
                                                    (92,22,71,DEFAULT,88,'published',2),
                                                    --"description": "В течение 3-х дней мы рассмотрим Вашу заявку и вернёмся с обратной связью",
                                                    (93,23,72,DEFAULT,88,'published',2),
                                                    --"iconUrl": "https://cons.ru/im.jpg"
                                                    (94,26,73,DEFAULT,88,'published',2),
                                                --[3]
                                                    --"title": "Присоединитесь к нам",
                                                    (95,22,74,DEFAULT,88,'published',3),
                                                    --"description": "После прохождения отбора Вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
                                                    (96,23,75,DEFAULT,88,'published',3),
                                                    --"iconUrl": "https://cons.ru/im.jpg"
                                                    (97,26,76,DEFAULT,88,'published',3),
                                        -- ]
                                    -- }
                                -- ]
                    -- ]
                    --"config": {},
                    (98,4,276,6,35,'published',DEFAULT),
                    --"position": 1
                    (99,2,77,6,35,'published',DEFAULT),
                -- }
                -- {
                        --"type": "nearby"
                        --"header": "Мы рядом с вами",
                        (100,21,78,9,35,'published',DEFAULT),
                        --"visible": true,
                        (101,1,79,9,35,'published',DEFAULT),
                        --"features": [
                        (102,31,277,9,35,'published',DEFAULT),
                                -- {
                                        --"type": "banner"
                                        --"title": "Онлайн",
                                        (103,22,80,10,102,'published',DEFAULT),
                                        --"visible": true,
                                        (104,1,81,10,102,'published',DEFAULT),
                                        --"description": "На платформе Telegram и онлайн-событиях",
                                        (105,23,82,10,102,'published',DEFAULT),
                                        --"iconUrl": "https://cons.ru/im.jpg",
                                        (106,26,83,10,102,'published',DEFAULT),
                                        --"tablePosition": {
                                        (107,3,278,10,102,'published',DEFAULT),
                                                --"row": 1,
                                                (108,19,84,DEFAULT,107,'published',DEFAULT),
                                                --"column": 1
                                                (109,20,85,DEFAULT,107,'published',DEFAULT),
                                        -- }
                                        --"config": {}
                                        (110,4,279,10,102,'published',DEFAULT),
                                -- }
                                -- {
                                        --"type": "banner"
                                        --"title": "Оффлайн",
                                        (111,22,86,11,102,'published',DEFAULT),
                                        --"visible": true,
                                        (112,1,87,11,102,'published',DEFAULT),
                                        --"description": "В собственном коворкинге и на закрытых встречах",
                                        (113,23,88,11,102,'published',DEFAULT),
                                        --"iconUrl": "https://cons.ru/im.jpg",
                                        (114,26,89,11,102,'published',DEFAULT),
                                        --"tablePosition": {
                                        (115,3,280,11,102,'published',DEFAULT),
                                                --"row": 2,
                                                (116,19,90,DEFAULT,115,'published',DEFAULT),
                                                --"column": 1
                                                (117,20,91,DEFAULT,115,'published',DEFAULT),
                                        -- }
                                        --"config":{}
                                        (118,4,281,11,102,'published',DEFAULT),
                                -- }
                                -- {
                                        --"type": "banner"
                                        --"title": "Сообщество СберСтартап",
                                        (119,22,92,12,102,'published',DEFAULT),
                                        --"visible": true,
                                        (120,1,93,12,102,'published',DEFAULT),
                                        --"description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
                                        (121,23,94,12,102,'published',DEFAULT),
                                        --"backgroundUrl": "https://cons.ru/im.jpg",
                                        (122,29,95,12,102,'published',DEFAULT),
                                        --"tablePosition": {
                                        (123,3,282,12,102,'published',DEFAULT),
                                                --"row": 1,
                                                (124,19,101,DEFAULT,123,'published',DEFAULT),
                                                --"column": 2
                                                (125,20,102,DEFAULT,123,'published',DEFAULT),
                                        -- }
                                        --"config": {}
                                        (126,4,283,12,102,'published',DEFAULT),
                                        --"features": {
                                        (127,31,284,12,102,'published',DEFAULT),
                                                --"type": "button"
                                                --"category": "simple",
                                                (128,24,96,13,127,'published',DEFAULT),
                                                --"default": "active",
                                                (129,10,97,13,127,'published',DEFAULT),
                                                --"text": "Стать частью сообщества",
                                                (130,25,98,13,127,'published',DEFAULT),
                                                --"iconUrl": null,
                                                (131,26,99,13,127,'published',DEFAULT),
                                                --"url": "/anketa/zspolnenie",
                                                (132,27,100,13,127,'published',DEFAULT),
                                                --"action": "redirect",
                                                (133,11,343,13,127,'published',DEFAULT),
                                                --"config": {}
                                                (134,4,285,13,127,'published',DEFAULT),
                                        -- }
                                -- }
                        -- ]
                        --"config": {
                        (135,4,286,9,35,'published',DEFAULT),
                            --"tableConfiguration": [
                            (136,12,287,DEFAULT,135,'published',DEFAULT),
                                    --[1]
                                        --"columnNumber": 1,
                                        (137,13,103,DEFAULT,136,'published',1),
                                        --"rows": 2,
                                        (138,14,104,DEFAULT,136,'published',1),
                                    --[2]
                                        --"columnNumber": 2,
                                        (139,13,105,DEFAULT,136,'published',2),
                                        --"rows": 1
                                        (140,14,106,DEFAULT,136,'published',2),
                            -- ]
                        -- }
                        --"position": 3
                        (141,2,344,9,35,'published',DEFAULT),
                -- }
            --]

        --[2]
            --"title": "Инвесторам",
            (142,22,288,DEFAULT,26,'published',2),
            --"visible": true,
            (143,1,109,DEFAULT,26,'published',2),
            --"isDefault": false,
            (144,7,110,DEFAULT,26,'published',2),
            --"isActive": true,
            (145,8,111,DEFAULT,26,'published',2),
            --"badgeText": null,
            (146,28,339,DEFAULT,26,'published',2),
            --"iconUrl": "https://cons.ru/im.jpg",
            (147,26,112,DEFAULT,26,'published',2),
            --"features": [
            (148,31,289,DEFAULT,26,'published',2),
                 -- {
                        --"type": "bulletBanner",
                        --"visible": true,
                        (149,1,113,14,148,'published',DEFAULT),
                        --"header": "Соинвестируйте с профессионалами рынка",
                        (150,21,114,14,148,'published',DEFAULT),
                        --"description": null,
                        (151,23,338,14,148,'published',DEFAULT),
                        --"bullets": ["Снижайте риски, соинвестируя с лучшими венчурными фондами","Обеспечьте себе поток лучших сделок","Расширьте портфель за счёт низкого входного чека","Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"],
                        (152,30,115,14,148,'published',DEFAULT),
                        --"config": {
                        (153,4,290,14,148,'published',DEFAULT),
                                --"direction": "left"
                                (154,15,116,DEFAULT,153,'published',DEFAULT),
                        -- }
                        --"position": 1
                        (155,2,117,14,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "rectangTiles",
                        --"visible": true,
                        (156,1,118,15,148,'published',DEFAULT),
                        --"header": "Уже в сообществе",
                        (157,21,119,15,148,'published',DEFAULT),
                        --"description": null,
                        (158,23,340,15,148,'published',DEFAULT),
                        --"items": ["https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg"],
                        (159,6,120,15,148,'published',DEFAULT),
                        --"config": {},
                        (160,4,291,15,148,'published',DEFAULT),
                        --"position": 2
                        (161,2,121,15,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "squareRow",
                        --"visible": true,
                        (162,1,122,16,148,'published',DEFAULT),
                        --"header": "Большая воронка стартапов на российском рынке",
                        (163,21,123,16,148,'published',DEFAULT),
                        --"description": "Первыми делимся доступом к российским и международным стартапам из различных акселераторов и SberUnity",
                        (164,23,124,16,148,'published',DEFAULT),
                        --"items": [
                        (165,6,292,16,148,'published',DEFAULT),
                                --[1]
                                        --"title": "Знакомим",
                                        (166,22,125,DEFAULT,165,'published',1),
                                        --"description": "с основателями стартапов",
                                        (167,23,126,DEFAULT,165,'published',1),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (168,26,127,DEFAULT,165,'published',1),
                                --[2]
                                        --"title": "Проводим",
                                        (169,22,128,DEFAULT,165,'published',2),
                                        --"description": "предварительный скоринг",
                                        (170,23,129,DEFAULT,165,'published',2),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (171,26,130,DEFAULT,165,'published',2),
                                --[3]
                                        --"title": "Рекомендуем",
                                        (172,22,131,DEFAULT,165,'published',3),
                                        --"description": "только отобранные проекты",
                                        (173,23,132,DEFAULT,165,'published',3),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (174,26,133,DEFAULT,165,'published',3),
                                --[4]
                                        --"title": "Объединяем",
                                        (175,22,134,DEFAULT,165,'published',4),
                                        --"description": "инвесторов и стартапы",
                                        (176,23,135,DEFAULT,165,'published',4),
                                        --"iconUrl": "https://cons.ru/im.jpg"
                                        (177,26,136,DEFAULT,165,'published',4),
                        -- ]
                        --"config": {},
                        (178,4,293,16,148,'published',DEFAULT),
                        --"position": 3
                        (179,2,137,16,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "rectangTiles",
                        --"visible": true,
                        (180,1,138,17,148,'published',DEFAULT),
                        --"header": "Наши акселераторы",
                        (181,21,139,17,148,'published',DEFAULT),
                        --"description": null,
                        (182,23,345,17,148,'published',DEFAULT),
                        --"items": ["https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg"],
                        (183,6,140,17,148,'published',DEFAULT),
                        --"config": {},
                        (184,4,294,17,148,'published',DEFAULT),
                        --"position": 4
                        (185,2,141,17,148,'published',DEFAULT),
                -- }
                -- {
                        --"type": "bulletBanner"
                        --"visible": true,
                        (186,1,142,18,148,'published',DEFAULT),
                        --"header": "Всё, что нужно — уже под рукой",
                        (187,21,143,18,148,'published',DEFAULT),
                        --"description": "Мы организовали сообщество в Slack-каналах",
                        (188,23,144,18,148,'published',DEFAULT),
                        --"bullets": ["Разделяйте деловые и личные мессенджеры","Структурируйте инофрмацию в тематических каналах","Только релевантные сообщения, без спама и рекламы","Полная информация о сделке всегда доступна"],
                        (189,30,145,18,148,'published',DEFAULT),
                        --"config": {
                        (190,4,295,18,148,'published',DEFAULT),
                                --"direction": "left"
                                (191,15,146,DEFAULT,190,'published',DEFAULT),
                        -- }
                        --"position": 3
                        (192,2,147,18,148,'published',DEFAULT),
                -- }
            -- ]
            --"position": 2
            (193,2,148,DEFAULT,26,'published',2),
            --"configuration": {}
            (194,4,296,DEFAULT,26,'published',2),
        --[3]
            --"title": "Корпорациям",
            (195,22,149,DEFAULT,26,'published',3),
            --"visible": true,
            (196,1,150,DEFAULT,26,'published',3),
            --"isDefault": false,
            (197,7,151,DEFAULT,26,'published',3),
            --"isActive": false,
            (198,8,152,DEFAULT,26,'published',3),
            --"badgeText": "Скоро",
            (199,28,153,DEFAULT,26,'published',3),
            --"iconUrl": "https://cons.ru/im.jpg",
            (200,26,154,DEFAULT,26,'published',3),
            --"config": {},
            (201,2,155,DEFAULT,26,'published',3),
            --"position": 3
            (202,4,297,DEFAULT,26,'published',3),
-- ]



--"type": "carousel",
--"visible": true,
(203,1,156,19,DEFAULT,'published',DEFAULT),
--"position": 3,
(204,2,157,19,DEFAULT,'published',DEFAULT),
--"header": "Направления сообщества",
(205,21,158,19,DEFAULT,'published',DEFAULT),
--"description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем Вас стать частью проектов сообщества",
(206,23,159,19,DEFAULT,'published',DEFAULT),
--"items": ["https://cons.ru/im.jpg","https://cons.ru/im.jpg","https://cons.ru/im.jpg"],
(207,6,160,19,DEFAULT,'published',DEFAULT),
--"config": {
(208,4,299,19,DEFAULT,'published',DEFAULT),
        --"autorotation": false,
        (209,16,161,DEFAULT,208,'published',DEFAULT),
        --"delay": 3,
        (210,17,162,DEFAULT,208,'published',DEFAULT),
        --"speed": 100,
        (211,18,163,DEFAULT,208,'published',DEFAULT),
        --"direction": "left"
        (212,15,164,DEFAULT,208,'published',DEFAULT),
-- }



--"type": "events",
--"visible": true,
(213,1,165,20,DEFAULT,'published',DEFAULT),
--"header": "Событийная кухня",
(214,21,166,20,DEFAULT,'published',DEFAULT),
--"title": "Закрывайте бизнес-потребности через нетворкинг",
(215,22,167,20,DEFAULT,'published',DEFAULT),
--"description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для Вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
(216,23,168,20,DEFAULT,'published',DEFAULT),
--"config": {},
(217,4,300,20,DEFAULT,'published',DEFAULT),
--"position": 4,
(218,2,169,20,DEFAULT,'published',DEFAULT),
--"features": [
(219,31,301,20,DEFAULT,'published',DEFAULT),
        -- {
                --"type": "offsetSquares",
                --"visible": true,
                (220,1,170,21,219,'published',DEFAULT),
                --"items": [
                (221,6,302,21,219,'published',DEFAULT),
                            --[1]
                                    --"title": "Партнерские мероприятия",
                                    (222,22,171,DEFAULT,221,'published',1),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (223,5,172,DEFAULT,221,'published',1),
                                    --"tablePosition": {
                                    (224,3,303,DEFAULT,221,'published',1),
                                                --"row": 1,
                                                (225,19,173,DEFAULT,224,'published',default),
                                                --"column": 1
                                                (226,20,174,DEFAULT,224,'published',default),
                                    -- }
                            --[2]
                                    --"title": "Хакатоны и интенсивы",
                                    (227,22,175,DEFAULT,221,'published',2),
                                    --"imageUrl": "https://cons.ru/im.jpg"
                                    (228,5,176,DEFAULT,221,'published',2),
                                    --"tablePosition": {
                                    (229,3,304,DEFAULT,221,'published',2),
                                                --"row": 1,
                                                (230,19,177,DEFAULT,229,'published',DEFAULT),
                                                --"column": 2
                                                (231,20,178,DEFAULT,229,'published',DEFAULT),
                                    -- }
                            --[3]
                                    --"title": "Мероприятия с другими фондами и сообществами",
                                    (232,22,179,DEFAULT,221,'published',3),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (233,5,180,DEFAULT,221,'published',3),
                                    --"tablePosition": {
                                    (234,3,305,DEFAULT,221,'published',3),
                                                --"row": 2,
                                                (235,19,181,DEFAULT,234,'published',DEFAULT),
                                                --"column": 1
                                                (236,20,182,DEFAULT,234,'published',DEFAULT),
                                    -- }
                            --[4]
                                    --"title": "Выезды и вечеринки",
                                    (237,22,183,DEFAULT,221,'published',4),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (238,5,184,DEFAULT,221,'published',4),
                                    --"tablePosition": {
                                    (239,3,306,DEFAULT,221,'published',4),
                                                --"row": 2,
                                                (240,19,185,DEFAULT,239,'published',DEFAULT),
                                                --"column": 2
                                                (241,20,186,DEFAULT,239,'published',DEFAULT),
                                    -- }
                            --[5]
                                    --"title": "Закрытые очные встречи",
                                    (242,22,187,DEFAULT,221,'published',5),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (243,5,188,DEFAULT,221,'published',5),
                                    --"tablePosition": {
                                    (244,3,307,DEFAULT,221,'published',5),
                                                --"row": 3,
                                                (245,19,189,DEFAULT,244,'published',DEFAULT),
                                                --"column": 1
                                                (246,20,190,DEFAULT,244,'published',DEFAULT),
                                    -- }
                            --[6]
                                    --"title": "Онлайн-митапы",
                                    (247,22,191,DEFAULT,221,'published',6),
                                    --"imageUrl": "https://cons.ru/im.jpg",
                                    (248,5,192,DEFAULT,221,'published',6),
                                    --"tablePosition": {
                                    (249,3,308,DEFAULT,221,'published',6),
                                                --"row": 3,
                                                (250,19,193,DEFAULT,249,'published',DEFAULT),
                                                --"column": 2
                                                (251,20,194,DEFAULT,249,'published',DEFAULT),
                                    -- }

                -- ]
                --"config": {
                (252,4,309,21,219,'published',DEFAULT),
                            --"tableConfiguration": [
                            (253,12,310,DEFAULT,252,'published',DEFAULT),
                                        --[1]
                                                --"columnNumber": 1,
                                                (254,13,195,DEFAULT,253,'published',1),
                                                --"rows": 2,
                                                (255,14,196,DEFAULT,253,'published',1),
                                                --"offsetDirection": null
                                                (256,32,311,DEFAULT,253,'published',1),
                                        --[2]
                                                --"columnNumber": 2,
                                                (257,13,197,DEFAULT,253,'published',2),
                                                --"rows": 2,
                                                (258,14,198,DEFAULT,253,'published',2),
                                                --"offsetDirection": "right"
                                                (259,32,199,DEFAULT,253,'published',2),
                                        --[3]
                                                --"columnNumber": 3,
                                                (260,13,200,DEFAULT,253,'published',3),
                                                --"rows": 2,
                                                (261,14,201,DEFAULT,253,'published',3),
                                                --"offsetDirection": null
                                                (262,32,312,DEFAULT,253,'published',3),
                            -- ]
                -- }
        -- }
        -- {
                --"type":"button"
                --"category": "simple",
                (263,24,202,22,219,'published',DEFAULT),
                --"visible": true,
                (264,1,203,22,219,'published',DEFAULT),
                --"default": "active",
                (265,10,204,22,219,'published',DEFAULT),
                --"text": "Календарь событий",
                (266,25,205,22,219,'published',DEFAULT),
                --"iconUrl": "https://cons.ru/im.jpg",
                (267,26,206,22,219,'published',DEFAULT),
                --"url": "/anketa/zspolnenie",
                (268,27,207,22,219,'published',DEFAULT),
                --"action": "redirect",
                (269,11,208,22,219,'published',DEFAULT),
                --"config": {}
                (270,4,313,22,219,'published',DEFAULT),
        -- }
-- ]


--"type": "socialTiles"
--"header": "Контент-студия",
(271,21,209,23,DEFAULT,'published',DEFAULT),
--"visible": true,
(272,1,210,23,DEFAULT,'published',DEFAULT),
--"description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
(273,23,211,23,DEFAULT,'published',DEFAULT),
--"items": [
(274,6,314,23,DEFAULT,'published',DEFAULT),
        --[1]
                --"title": "Сберстартап",
                (275,22,212,DEFAULT,274,'published',1),
                --"category": "Telegram-канал",
                (276,24,213,DEFAULT,274,'published',1),
                --"imageUrl": "https://cons.ru/im.jpg",
                (277,5,214,DEFAULT,274,'published',1),
                --"description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
                (278,23,215,DEFAULT,274,'published',1),
                --"features": [
                (279,31,315,DEFAULT,274,'published',1),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (280,24,216,24,279,'published',DEFAULT),
                                --"visible": true
                                (281,1,346,24,279,'published',DEFAULT),
                                --"default": "active",
                                (282,10,217,24,279,'published',DEFAULT),
                                --"text": "Подписаться",
                                (283,25,218,24,279,'published',DEFAULT),
                                --"iconUrl": "https://cons.ru/im.jpg",
                                (284,26,219,24,279,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (285,27,220,24,279,'published',DEFAULT),
                                --"action": "redirect"
                                (286,11,221,24,279,'published',DEFAULT),
                                --"config": {}
                                (287,4,316,24,279,'published',DEFAULT),

                        -- }
                -- ]

        --[2]
                --"title": "Три запятые",
                (288,22,222,DEFAULT,274,'published',2),
                --"category": "Подкаст",
                (289,24,223,DEFAULT,274,'published',2),
                --"imageUrl": "https://cons.ru/im.jpg",
                (290,5,224,DEFAULT,274,'published',2),
                --"description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
                (291,23,225,DEFAULT,274,'published',2),
                --"features": [
                (292,31,317,DEFAULT,274,'published',2),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (293,24,226,25,292,'published',DEFAULT),
                                --"visible": true
                                (294,1,318,25,292,'published',DEFAULT),
                                --"default": "active",
                                (295,10,227,25,292,'published',DEFAULT),
                                --"text": "Подписаться",
                                (296,25,228,25,292,'published',DEFAULT),
                                --"iconUrl": null,
                                (297,26,319,25,292,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (298,27,229,25,292,'published',DEFAULT),
                                --"action": "redirect"
                                (299,11,230,25,292,'published',DEFAULT),
                                --"config": {}
                                (300,4,320,25,292,'published',DEFAULT),

                        -- }
                -- ]

        --[3]
                --"title": "VC.RU",
                (301,22,231,DEFAULT,274,'published',3),
                --"category": "Блог",
                (302,24,232,DEFAULT,274,'published',3),
                --"imageUrl": "https://cons.ru/im.jpg",
                (303,5,233,DEFAULT,274,'published',3),
                --"description": "Успешные и не очень кейсы участников сообщества",
                (304,23,234,DEFAULT,274,'published',3),
                --"features": [
                (305,31,321,DEFAULT,274,'published',3),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (306,24,235,26,305,'published',DEFAULT),
                                --"visible": true
                                (307,1,322,26,305,'published',DEFAULT),
                                --"default": "active",
                                (308,10,236,26,305,'published',DEFAULT),
                                --"text": "Подписаться",
                                (309,25,237,26,305,'published',DEFAULT),
                                --"iconUrl": null,
                                (310,26,323,26,305,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (311,27,238,26,305,'published',DEFAULT),
                                --"action": "redirect"
                                (312,11,239,26,305,'published',DEFAULT),
                                --"config": {}
                                (313,4,324,26,305,'published',DEFAULT),

                        -- }
                -- ]

        --[4]
                --"title": "Для стартапов",
                (314,22,240,DEFAULT,274,'published',4),
                --"category": "YouTube-шоу",
                (315,24,241,DEFAULT,274,'published',4),
                --"imageUrl": "https://cons.ru/im.jpg",
                (316,5,242,DEFAULT,274,'published',4),
                --"description": "Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями",
                (317,23,243,DEFAULT,274,'published',4),
                --"features": [
                (318,31,325,DEFAULT,274,'published',4),
                        -- {
                                --"type": "button"
                                --"category": "simple",
                                (319,24,244,27,318,'published',DEFAULT),
                                --"visible": true
                                (320,1,326,27,318,'published',DEFAULT),
                                --"default": "inactive",
                                (321,10,245,27,318,'published',DEFAULT),
                                --"text": "Скоро",
                                (322,25,246,27,318,'published',DEFAULT),
                                --"iconUrl": "https://cons.ru/im.jpg",
                                (323,26,247,27,318,'published',DEFAULT),
                                --"url": "/anketa/zspolnenie",
                                (324,27,327,27,318,'published',DEFAULT),
                                --"action": "redirect"
                                (325,11,248,27,318,'published',DEFAULT),
                                --"config": {}
                                (326,4,328,27,318,'published',DEFAULT),
                        -- }
                -- ]

-- ]
--"config": {},
(327,4,329,23,DEFAULT,'published',DEFAULT),
--"position": 4
(328,2,249,23,DEFAULT,'published',DEFAULT),

--"type": "banner",
--"visible": true,
(329,1,250,28,DEFAULT,'published',DEFAULT),
--"position": 5,
(330,2,253,28,DEFAULT,'published',DEFAULT),
--"title": "Подайте заявку и станьте частью сообщества СберСтартап",
(331,22,251,28,DEFAULT,'published',DEFAULT),
--"description": null,
(332,23,330,28,DEFAULT,'published',DEFAULT),
--"backgroundUrl": "https://cons.ru/im.jpg",
(333,29,252,28,DEFAULT,'published',DEFAULT),
--"config": {},
(334,4,331,28,DEFAULT,'published',DEFAULT),
--"features": [
(335,31,332,28,DEFAULT,'published',DEFAULT),
        -- {
                --cFooterBanner_1_button_1
                --"type": "button"
                --"category": "simple",
                (336,24,254,29,335,'published',DEFAULT),
                --"visible": true
                (337,1,333,29,335,'published',DEFAULT),
                --"default": "active",
                (338,10,255,29,335,'published',DEFAULT),
                --"text": "Стать частью сообщества",
                (339,25,256,29,335,'published',DEFAULT),
                --"url": "/anketa/zspolnenie",
                (340,27,257,29,335,'published',DEFAULT),
                --"action": "redirect"
                (341,11,258,29,335,'published',DEFAULT),
                --"config": {}
                (342,4,334,29,335,'published',DEFAULT);

        -- }
-- ]

select setval('public.feature_attributes_values_id_seq',  (SELECT max(id) FROM public.feature_attributes_values));
