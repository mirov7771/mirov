--liquibase formatted sql
--changeset Mirov AA:syndicate_nz
update public.pages
set page = '{
    "features": [
        {
            "type": "block",
            "sysName": "syndicateMainHeader_1 and syndicateBulletBanner_1 block",
            "position": 1,
            "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
            "config": {},
            "features": [
                {
                    "type": "mainHeader",
                    "sysName": "syndicateMainHeader_1",
                    "visible": true,
                    "position": 1,
                    "title": "Венчурный клуб **«Синдикат»**",
                    "bullets": [
                        "Получите доступ к эксклюзивным сделкам клуба"
                    ],
                    "description": "Начните инвестировать с профессионалами венчурного рынка и станьте частью международного инвестиционного сообщества",
                    "features": [
                        {
                            "type": "button",
                            "sysName": "syndicateMainHeader_1_button_1",
                            "category": "simple",
                            "visible": true,
                            "default": "active",
                            "text": "Присоединиться к клубу",
                            "config": {},
                            "action": "redirect",
                            "iconUrl": null,
                            "url": "/syndicate/join",
                            "theme": "yellow-gradient"
                        }
                    ],
                    "config": {},
                    "imageUrl": "/file/main_header.png"
                },
                {
                    "type": "bulletBanner",
                    "sysName": "syndicateBulletBanner_1",
                    "visible": true,
                    "header": "**Соинвестируйте**  \\nс профессионалами",
                    "bullets": [
                        "Снижайте риски, соинвестируя с лучшими венчурными фондами",
                        "Обеспечьте себе поток лучших сделок",
                        "Расширьте портфель за счёт низкого входного чека",
                        "Легко присоединяйтесь к раундам и предлагайте свои синдицированные сделки"
                    ],
                    "position": 2,
                    "config": {
                        "direction": "left"
                    },
                    "imageUrl": "/file/bullet_banner.png"
                }
            ],
            "visible": true
        },
        {
            "type": "tileList",
            "sysName": "syndicateTileList_1",
            "header": "**Основатели** клуба",
            "items": [
                {
                    "title": "Сбер",
                    "description": "Крупнейшая в России экосистема, включающая 65+ компаний. Является не только одним из главных пользователей венчурной индустрии, но и активно строит ее. SberUnity - первая российская онлайн-платформа для объединения участников рынка технологий на федеральном уровне.",
                    "imageUrl": "/file/tile_list_1.png"
                },
                {
                    "title": "МИК",
                    "description": "Московский инновационный кластер создает экосистему продуктов и сервисов, а также условия, необходимые для эффективного развития инноваций и новых проектов.",
                    "imageUrl": "/file/tile_list_2.png"
                },
                {
                    "title": "Angelsdeck",
                    "description": "Клуб венчурных инвесторов, который даёт возможность участникам присоединяться к эксклюзивным сделкам и подключиться к сообществу доверенных инвесторов.",
                    "imageUrl": "/file/tile_list_3.png"
                }
            ],
            "backgroundColor": "linear-gradient(277.89deg, rgba(243, 198, 80, 0.7) -71.03%, rgba(21, 22, 26, 0) 105.5%)",
            "position": 3,
            "config": {},
            "visible": true
        },
        {
            "type": "roadMap",
            "sysName": "syndicateRoadMap_1",
            "visible": true,
            "position": 4,
            "config": {},
            "header": "**Как стать членом клуба** и инвестировать в проекты?",
            "items": [
                {
                    "title": "[Подайте заявку](/syndicate/join)",
                    "description": "Заполните анкету на вступление в клуб",
                    "stepNumber": "1"
                },
                {
                    "title": "Пройдите собеседование",
                    "description": "Дождитесь рассмотрения вашей заявки модератором и пройдите интервью",
                    "stepNumber": "2"
                },
                {
                    "title": "Подпишите  \\nNDA",
                    "description": "Подключитесь к закрытому Telegram-каналу и чатам",
                    "stepNumber": "3"
                },
                {
                    "title": "Присоединитесь  \\nк клубу",
                    "description": "Подключитесь к закрытому Telegram-каналу и чатам",
                    "stepNumber": "4"
                }
            ],
            "backgroundColor": "#383A43"
        },
        {
            "type": "block",
            "sysName": "syndicateSquareList_1 and syndicateFooter_button_1 block",
            "visible": true,
            "position": 5,
            "backgroundColor": "linear-gradient(275.64deg, rgba(21, 22, 26, 0) 10.53%, rgba(243, 198, 80, 0.7) 169.4%)",
            "config": {},
            "features": [
                {
                    "type": "squareList",
                    "sysName": "syndicateSquareList_1",
                    "title": "**Преимущества** клуба Синдикат",
                    "position": 5,
                    "config": {},
                    "items": [
                        {
                            "title": "Соинвестиции",
                            "description": "Присоединяйтесь к сделкам с комфортным чеком",
                            "iconUrl": "/file/square_list_1.png"
                        },
                        {
                            "title": "Экспертиза",
                            "description": "Связывайтесь с экспертами клуба на любом этапе заключения сделки",
                            "iconUrl": "/file/square_list_2.png"
                        },
                        {
                            "title": "Обучение",
                            "description": "Сделайте первые шаги, избежав типичных ошибок",
                            "iconUrl": "/file/square_list_3.png"
                        },
                        {
                            "title": "Нетворкинг",
                            "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
                            "iconUrl": "/file/square_list_4.png"
                        },
                        {
                            "title": "Эксклюзивность",
                            "description": "Эксклюзивные мероприятия с инвесторами",
                            "iconUrl": "/file/square_list_5.png"
                        },
                        {
                            "title": "Поддержка",
                            "description": "Обмен опытом и помощь в решении бизнес-кейсов",
                            "iconUrl": "/file/square_list_6.png"
                        }
                    ]
                },
                {
                    "type": "button",
                    "sysName": "syndicateFooter_button_1",
                    "category": "simple",
                    "visible": true,
                    "default": "active",
                    "text": "Присоединиться к клубу",
                    "iconUrl": null,
                    "action": "redirect",
                    "url": "/syndicate/join",
                    "config": {},
                    "theme": "yellow-gradient",
                    "position": 7
                }
            ]
        }
    ]
}'
where code = 'syndicate_nz';