--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "recovery_en_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Password Recovery",
            "titleInfoForm": "We have sent a password to your email",
            "textDescription": "We have sent a new temporary password to your email **{email}**. Use it, then set your own password.",
            "text": "If you don`t see an email, check the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "rrecovery_en_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "recoveryForm",
            "sysName": "recovery_en_recoveryForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Password Recovery",
            "descriptionForm": "To recover your password, enter the email address you provided during registration",
            "subText": "SberUnity Support:",
            "subTextLink": "sberunity@sberbank.ru",
            "button": {
                "action": "request",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "recovery_en_recoveryForm_button",
                "text": "Get a password",
                "theme": "purple-gradient",
                "url": "/restore-password",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/recovery'
  and code = 'recovery_en';