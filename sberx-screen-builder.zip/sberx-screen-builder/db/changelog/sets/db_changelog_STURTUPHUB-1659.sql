--liquibase formatted sql
--changeset Molotkov D:SBERXTECH-1659 Добавление полного и краткого описания



UPDATE public.screen SET  formedit='{
      "form": [
        {
          "module": "Условия соглашения",
          "page": 1,
          "pageName": "Юридическая информация об организации",
          "fields": [
            {
              "sysName": "userConsent_consent",
              "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
              "type": "boolean",
              "format": "checkbox",
              "edited": true,
              "required": true
            },
            {
              "sysName": "userConsent_contract",
              "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
              "type": "boolean",
              "format": "checkbox",
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Юридическая информация об организации",
          "page": 1,
          "pageName": "Юридическая информация об организации",
          "moduleNote": "Информация об организации автоматически перенесена из СберБизнес Онлайн. Пожалуйста, заполните недостающие данные.",
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Наименование организации",
              "type": "string",
              "edited": true,
              "required": false,
              "direction": "row",
              "maxLength": 70,
              "showLength": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год регистрации*",
              "type": "int",
              "format": "[1991;2021]",
              "maxLength": 4,
              "edited": true,
              "required": true,
              "direction": "row",
              "showLength": false
            },
            {
              "sysName": "questionnaire_name",
              "localName": "Публичное название / название бренда",
              "type": "string",
              "maxLength": 100,
              "edited": true,
              "required": true,
              "showLength": false
            },
            {
              "sysName": "questionnaire_registrationCountry",
              "localName": "Страна юрисдикции*",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": true,
              "required": true,
              "multySelect": false
            },
            {
              "sysName": "questionnaire_email",
              "localName": "Публичный адрес электронной почты",
              "type": "string",
              "format": "e-mail",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт корпорации",
              "type": "string",
              "maxLength": "100",
              "edited": true,
              "required": true,
              "showLength": false
            }
          ]
        },
        {
          "module": "Представитель",
          "page": 2,
          "pageName": "Информация о представителе",
          "moduleNote": "",
          "fields": [
            {
              "sysName": "representative_fio",
              "localName": "Фамилия Имя представителя*",
              "type": "string",
              "edited": true,
              "required": true
            },
            {
              "sysName": "representative_role",
              "localName": "Должность*",
              "type": "string",
              "edited": true,
              "required": true
            },
            {
              "sysName": "representative_phone",
              "localName": "Мобильный телефон*",
              "type": "string",
              "format": "phone",
              "edited": true,
              "required": true,
              "mask": "phone"
            },
            {
              "sysName": "representative_email",
              "localName": "Электронная почта*",
              "type": "string",
              "format": "e-mail",
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Корпорация",
          "page": 3,
          "pageName": "Информация о корпорации",
          "fields": [
            {
              "title": "Направления",
              "sysName": "questionnaire_industry",
              "localName": "Направление деятельности",
              "note": "Выберите направления работы Вашей корпорации",
              "description": "Выберите направления работы Вашей корпорации",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                22000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_innovationMethod",
              "title": "Методы работы с инновациями",
              "localName": "Укажите методы",
              "note": "Выберите методы внедрения инноваций в Вашей корпорации ",
              "description": "Выберите методы внедрения инноваций в Вашей корпорации",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                4000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "title": "Годовой оборот",
              "sysName": "questionnaire_turnover",
              "localName": "Годовой оборот",
              "note": "Опционально",
              "type": "array",
              "format": "search_dropdown",
              "edited": true,
              "required": true,
              "values": [
                {
                  "name": "Микропредприятия — до 120 млн",
                  "code": "Микропредприятия — до 120 млн"
                },
                {
                  "name": "Малые предприятия — до 800 млн",
                  "code": "Малые предприятия — до 800 млн"
                },
                {
                  "name": "Средние предприятия — до 2 млрд рублей",
                  "code": "Средние предприятия — до 2 млрд рублей"
                },
                {
                  "name": "Крупный бизнес — до 30 млрд рублей",
                  "code": "Крупный бизнес — до 30 млрд рублей"
                },
                {
                  "name": "Крупнейший бизнес — свыше 30 млрд рублей",
                  "code": "Крупнейший бизнес — свыше 30 млрд рублей"
                }
              ]
            },
            {
              "sysName": "questionnaire_note",
              "localName": "Краткое описание",
              "type": "string",
              "maxLength": "150",
              "edited": true,
              "required": true
            },{
              "sysName": "questionnaire_fullNote",
              "localName": "Полное описание",
              "note": "Опишите корпорацию в нескольких предложениях",
              "type": "string",
              "maxLength": "480",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_logoFile",
              "localName": "Загрузить логотип",
              "title": "Логотип",
              "type": "logo",
              "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
              "edited": true,
              "required": false,
              "allowedTypes": [
                ".png"
              ]
            }
          ]
        },
        {
          "module": "Работа со стартапами",
          "page": 4,
          "pageName": "Условия работы со стартапами",
          "fields": [
            {
              "sysName": "project_industry",
              "title": "Направления",
              "description": "Выберите направления, по которым Вы ищете стартапы",
              "localName": "Направления",
              "note": "Выберите направления, по которым Вы ищете стартапы",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                3000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_stady",
              "title": "Стадии развития стартапов",
              "description": "Выберите интересующие стадии развития стартапов",
              "localName": "Стадия развития",
              "note": "Выберите интересующие стадии развития стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                7000
              ],
              "multySelect": true,
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "",
          "page": 4,
          "pageName": "Условия работы со стартапами",
          "title": "Потребности корпорации",
          "subTitle": "Потребность №",
          "withIndex": true,
          "actionText": "Добавить потребность",
          "isArray": "true",
          "fields": [
            {
              "sysName": "questionnairePilots[]_pilotId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnairePilots[]_suggestCase",
              "localName": "Описание потребности",
              "note": "Кратко опишите суть Вашего запроса на пилотирование стартапа",
              "type": "string",
              "maxLength": "520",
              "edited": true,
              "required": false
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 5,
          "pageName": "Пилотирование",
          "fields": [
            {
              "sysName": "questionnaire_successPilots",
              "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            },
            {
              "sysName": "questionnaire_startupInvestmentYears",
              "title": "Информация о сотрудничестве со стартапами",
              "localName": "Сколько лет Ваша корпорация работает со стартапами",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_overallPilots",
              "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_lastYearInvestmentsCount",
              "localName": "Количество пилотов со стартапами за последний год",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            },
            {
              "sysName": "questionnaire_overallContracts",
              "localName": "Количество контрактов (внедрений) со стартапами за последний год",
              "note": "Опционально",
              "type": "int",
              "triggerField": "questionnaire_successPilots",
              "triggerValue": "true",
              "edited": true,
              "required": false
            }
          ]
        },
        {
          "module": "Инвестиции",
          "page": 6,
          "pageName": "Инвестиции",
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Инвестирует ли Ваша корпорация в стартапы?",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            },
            {
              "sysName": "investment_industry",
              "title": "Направления",
              "description": "Выберите интересные для Вас направления инвестирования",
              "localName": "Направления",
              "note": "Выберите интересные для Вас направления инвестирования",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                3000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд инвестиций",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            },
            {
              "sysName": "project_geography",
              "localName": "География стартапов",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                2000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "multySelect": true,
              "edited": true,
              "required": true
            }
          ]
        },
        {
          "module": "Успешные кейсы",
          "page": 6,
          "pageName": "Инвестиции",
          "triggerField": "investment_investment",
          "triggerValue": true,
          "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
          "isArray": true,
          "subTitle": "Стартап №",
          "withIndex": true,
          "actionText": "Добавить кейс",
          "fields": [
            {
              "sysName": "successPilots[]_pilotid",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "successPilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "maxLength": "140",
              "edited": true,
              "required": false,
              "showLength": false
            },
            {
              "sysName": "successPilots[]_suggestCase",
              "localName": "Описание кейса",
              "type": "string",
              "maxLength": "300",
              "edited": true,
              "required": false,
              "showLength": false
            }
          ]
        },
        {
          "module": "Скаутинг",
          "page": 7,
          "pageName": "Скаутинг",
          "moduleNote": "Подбор технологических решений стартапов под запрос заказчика",
          "fields": [
            {
              "sysName": "questionnaire_scouting",
              "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
              "type": "boolean",
              "format": "switch",
              "edited": true,
              "required": true
            }
          ]
        }
      ]
    }'::json::json where formname='New_Corporate';

 UPDATE public.screen SET  formedit='{
          "form": [
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация об организации",
              "moduleNote": "Информация об организации автоматически перенесена из СберБизнес Онлайн. Пожалуйста, заполните недостающие данные.",
              "fields": [
                {
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации*",
                  "type": "int",
                  "format": "[1991;2021]",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": true,
                  "required": true,
                  "multySelect": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт корпорации",
                  "type": "string",
                  "maxLength": "100",
                  "edited": true,
                  "required": true,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Представитель",
              "page": 2,
              "pageName": "Информация о представителе",
              "moduleNote": "",
              "fields": [
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя представителя*",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_email",
                  "localName": "Электронная почта*",
                  "type": "string",
                  "format": "e-mail",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Корпорация",
              "page": 3,
              "pageName": "Информация о корпорации",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "questionnaire_industry",
                  "localName": "Направление деятельности",
                  "note": "Выберите направления работы Вашей корпорации",
                  "description": "Выберите направления работы Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    22000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_innovationMethod",
                  "title": "Методы работы с инновациями",
                  "localName": "Укажите методы",
                  "note": "Выберите методы внедрения инноваций в Вашей корпорации ",
                  "description": "Выберите методы внедрения инноваций в Вашей корпорации",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    4000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "title": "Годовой оборот",
                  "sysName": "questionnaire_turnover",
                  "localName": "Годовой оборот",
                  "note": "Опционально",
                  "type": "array",
                  "format": "search_dropdown",
                  "edited": true,
                  "required": true,
                  "values": [
                    {
                      "name": "Микропредприятия — до 120 млн",
                      "code": "Микропредприятия — до 120 млн"
                    },
                    {
                      "name": "Малые предприятия — до 800 млн",
                      "code": "Малые предприятия — до 800 млн"
                    },
                    {
                      "name": "Средние предприятия — до 2 млрд рублей",
                      "code": "Средние предприятия — до 2 млрд рублей"
                    },
                    {
                      "name": "Крупный бизнес — до 30 млрд рублей",
                      "code": "Крупный бизнес — до 30 млрд рублей"
                    },
                    {
                      "name": "Крупнейший бизнес — свыше 30 млрд рублей",
                      "code": "Крупнейший бизнес — свыше 30 млрд рублей"
                    }
                  ]
                },
                {
              "sysName": "questionnaire_note",
              "localName": "Краткое описание",
              "type": "string",
              "maxLength": "150",
              "edited": true,
              "required": true
            },{
              "sysName": "questionnaire_fullNote",
              "localName": "Полное описание",
              "note": "Опишите корпорацию в нескольких предложениях",
              "type": "string",
              "maxLength": "480",
              "edited": true,
              "required": true
            },
                {
                  "sysName": "questionnaire_logoFile",
                  "localName": "Загрузить логотип",
                  "title": "Логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Работа со стартапами",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "fields": [
                {
                  "sysName": "project_industry",
                  "title": "Направления",
                  "description": "Выберите направления, по которым Вы ищете стартапы",
                  "localName": "Направления",
                  "note": "Выберите направления, по которым Вы ищете стартапы",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_stady",
                  "title": "Стадии развития стартапов",
                  "description": "Выберите интересующие стадии развития стартапов",
                  "localName": "Стадия развития",
                  "note": "Выберите интересующие стадии развития стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    7000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "",
              "page": 4,
              "pageName": "Условия работы со стартапами",
              "title": "Потребности корпорации",
              "subTitle": "Потребность №",
              "withIndex": true,
              "actionText": "Добавить потребность",
              "isArray": "true",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotId",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_suggestCase",
                  "localName": "Описание потребности",
                  "note": "Кратко опишите суть Вашего запроса на пилотирование стартапа",
                  "type": "string",
                  "maxLength": "520",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 5,
              "pageName": "Пилотирование",
              "fields": [
                {
                  "sysName": "questionnaire_successPilots",
                  "localName": "У Вашей компании есть опыт сотрудничества со стартапами?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_startupInvestmentYears",
                  "title": "Информация о сотрудничестве со стартапами",
                  "localName": "Сколько лет Ваша корпорация работает со стартапами",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_overallPilots",
                  "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_lastYearInvestmentsCount",
                  "localName": "Количество пилотов со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                },

                {
                  "sysName": "questionnaire_overallContracts",
                  "localName": "Количество контрактов (внедрений) со стартапами за последний год",
                  "note": "Опционально",
                  "type": "int",
                  "triggerField": "questionnaire_successPilots",
                  "triggerValue": "true",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 6,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "investment_investment",
                  "localName": "Инвестирует ли Ваша корпорация в стартапы?",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_industry",
                  "title": "Направления",
                  "description": "Выберите интересные для Вас направления инвестирования",
                  "localName": "Направления",
                  "note": "Выберите интересные для Вас направления инвестирования",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Раунд инвестиций",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "project_geography",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "triggerField": "investment_investment",
                  "triggerValue": "true",
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Успешные кейсы",
              "page": 6,
              "pageName": "Инвестиции",
              "triggerField": "investment_investment",
              "triggerValue": true,
              "moduleNote": "Опционально. Укажите названия стартапов, с которыми у Вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
              "isArray": true,
              "subTitle": "Стартап №",
              "withIndex": true,
              "actionText": "Добавить кейс",
              "fields": [
                {
                  "sysName": "successPilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "successPilots[]_company",
                  "localName": "Название стартапа",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "successPilots[]_suggestCase",
                  "localName": "Описание кейса",
                  "type": "string",
                  "maxLength": "300",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Скаутинг",
              "page": 7,
              "pageName": "Скаутинг",
              "moduleNote": "Подбор технологических решений стартапов под запрос заказчика",
              "fields": [
                {
                  "sysName": "questionnaire_scouting",
                  "localName": "Рассматриваете ли Вы скаутинг как инструмент для поиска нужных стартапов?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            }
          ]
        }'
      WHERE formname='corporate_edit' ;

     UPDATE public.screen SET   formview='{
    "form": [{
            "module": "Основная информация",
            "page": 1,
            "fields": [{
                    "sysName": "questionnaire_fullName",
                    "localName": "Наименование корпорации",
                    "type": "string",
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_name",
                    "localName": "Название",
                    "type": "string",
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_industry",
                    "localName": "Направление деятельности",
                    "type": "array",
          "format": "text",
                    "activity": [
                       22000
                    ],
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_fullNote",
                    "localName": "Описание",
                    "type": "string",
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_innovationMethod",
                    "localName": "Методы работы с инновациями",
                    "type": "array",
                    "format": "chip",
                    "activity": [4000],
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_turnover",
                    "localName": "Оборот",
                    "type": "string",
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_site",
                    "localName": "Сайт корпорации",
                   "type": "hyperlink",
                    "edited": false,
                    "required": false
                },{
                    "sysName": "questionnaire_email",
                    "localName": "Email",
                    "type": "string",
                    "edited": false,
                    "required": false
                }
            ]
        }, {
            "module": "Работа со стартапами (Доступно по подписке)",
            "page": 1,
            "fields": [{
                    "sysName": "project_industry",
                    "localName": "Индустрия",
                    "type": "array",
          "format": "text",
                    "activity": [
                        3000
                    ],
                    "edited": false,
                    "required": false,
          "isBlur": true
                },{
                    "sysName": "questionnaire_stady",
                    "localName": "Стадии развития продуктов",
                    "type": "array",
          "format": "text",
                    "activity": [
                        7000
                    ],
                    "edited": false,
                    "required": false,
          "isBlur": true
                }
        ]
        },{
            "module": "",
            "page": 1,
            "isArray": "true",
            "fields": [{
                    "sysName": "questionnairePilots[]_pilotId",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": false,
                    "required": false
                }, {
                    "sysName": "questionnairePilots[]_suggestCase",
                    "localName": "Описание потребности",
                    "type": "string",
                    "edited": false,
                    "required": false,
          "isBlur": true
                }
            ]
        }, {
            "module": "Инвестиции (Доступно по подписке)",
            "page": 1,
      "triggerField": "investment_investment",
            "triggerValue": "true",
            "fields": [{
                    "sysName": "investment_industry",
                    "localName": "Индустрия",
                    "type": "array",
          "format": "text",
                    "activity": [
                        3000
                    ],
                    "edited": false,
                    "required": false,
          "isBlur": true
                },{
                    "sysName": "investment_round",
                    "localName": "Раунд инвестиций",
                    "type": "array",
          "format": "text",
                    "activity": [
                        6000
                    ],
                    "edited": false,
                    "required": false,
          "isBlur": true
                },{
                    "sysName": "project_geography",
                    "localName": "География",
                    "type": "array",
          "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false,
          "isBlur": true
                }
            ]
        },{
            "module": "",
            "page": 1,
            "triggerField": "investment_investment",
            "triggerValue": "true",
            "isArray": true,
            "fields": [{
                    "sysName": "successPilots[]_pilotid",
                    "localName": "",
                    "type": "int",
                    "format": "hide",
                    "edited": false,
                    "required": false
                }, {
                    "sysName": "successPilots[]_company",
                    "localName": "Успешный кейсы",
                    "type": "string",
                    "edited": false,
                    "required": false,
          "isBlur": true
                }
            ]
        }
    ]
}
'::json::json WHERE formname='corporate_Client';


UPDATE public.screen SET   formview='{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_fullName",
      "localName": "Наименование корпорации",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_name",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_industry",
      "localName": "Направление деятельности",
      "type": "array",
      "format": "text",
      "activity": [
        22000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_fullNote",
      "localName": "Описание",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_innovationMethod",
      "localName": "Методы работы с инновациями",
      "type": "array",
      "format": "text",
      "activity": [4000],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_turnover",
      "localName": "Оборот",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_site",
      "localName": "Сайт корпорации",
      "type": "hyperlink",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_email",
      "localName": "Email",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Работа со стартапами",
    "page": 1,
    "fields": [{
      "sysName": "project_industry",
      "localName": "Индустрия",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_stady",
      "localName": "Стадии развития продуктов",
      "type": "array",
      "format": "text",
      "activity": [
        7000
      ],
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "",
    "page": 1,
    "isArray": "true",
    "fields": [{
      "sysName": "questionnairePilots[]_pilotId",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_suggestCase",
      "localName": "Описание потребности",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Индустрия",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_round",
      "localName": "Раунд инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "",
    "page": 1,
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "isArray": true,
    "fields": [{
      "sysName": "successPilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "successPilots[]_company",
      "localName": "Успешный кейсы",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}'::json::json WHERE formname='corporate_SuperClient';

UPDATE public.screen SET  formedit='{
          "form": [
            {
              "module": "Условия соглашения",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "userConsent_consent",
                  "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
                  "type": "boolean",
                  "format": "checkbox",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "userConsent_contract",
                  "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
                  "type": "boolean",
                  "format": "checkbox",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "note": "Перенесено из СберБизнес Онлайн",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации",
                  "type": "int",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": false,
                  "required": true,
                  "multySelect": false
                }
              ]
            },
            {
              "module": "Данные профиля",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_investorType",
                  "localName": "Выберите тип инвестора",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    11000
                  ],
                  "multySelect": false,
                  "edited": true,
                  "required": true
                }, {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего фонда",
                  "note": "Например: Фонд и акселератор",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                  "note":"Например, Рассматриваю любые проекты",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего family-office",
                  "note": "Например: Фонд семьи Безосов",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Ваши данные",
              "page": 2,
              "pageName": "Ваши данные",
              "fields": [
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Добавьте фото",
                  "localName": "Загрузить фото",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Описание",
                  "note": "Опишите ваш фонд/себя в нескольких предложениях",
                  "type": "string",
                  "maxLength": "480",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_portfolioNote",
                  "localName": "Краткое описание портфельного стартапа",
                  "type": "string",
                  "maxLength": "300",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "note": "Например, Управляющий партнёр",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_facebook",
                  "localName": "Профиль в Facebook*",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "investment_industry",
                  "localName": "Направления",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_geography",
                  "title": "География стартапов",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Стадии инвестирования",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Данные о стартапах портфеля",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "questionnaire_activeDealsNumber",
                  "localName": "Количество стартапов в портфеле",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_allDealsNumber",
                  "localName": "Количество сделок, всего",
                  "note": "Количество стартапов, в которые Вы инвестировали",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_exitDealsNumber",
                  "localName": "Количество выходов",
                  "note": "Количество стартапов, в которые Вы инвестировали и вышли",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                }
              ]
            },
            {
              "module": "",
              "page": 3,
              "pageName": "Инвестиции",
              "subTitle": "Стартап №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить стартап",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_company",
                  "localName": "Название стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "questionnairePilots[]_site",
                  "localName": "Ссылка на сайт стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Инвестиционные клубы",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "fields": [
                {
                  "sysName": "questionnaire_club",
                  "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "subTitle": "Клуб / сообщество №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить клуб",
              "triggerField": "questionnaire_club",
              "triggerValue": true,
              "fields": [
                {
                  "sysName": "investorClubs[]_name",
                  "localName": "Название клуба / сообщества*",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "investorClubs[]_role",
                  "localName": "Ваша роль в клубе / сообществе*",
                  "note": "Например, Основатель клуба",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            }
          ]
        }'::json::json WHERE formname='New_Investor';


       UPDATE public.screen SET  formedit='{
          "form": [
            {
              "module": "Юридическая информация об организации",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_questionnaireid",
                  "localName": "",
                  "type": "int",
                  "format": "hide",
                  "edited": true,
                  "required": true
                },{
                  "sysName": "questionnaire_fullName",
                  "localName": "Наименование организации",
                  "note": "Перенесено из СберБизнес Онлайн",
                  "type": "string",
                  "edited": false,
                  "required": false,
                  "direction": "row",
                  "maxLength": 70,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_birthYear",
                  "localName": "Год регистрации",
                  "type": "int",
                  "maxLength": 4,
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_name",
                  "localName": "Публичное название / название бренда",
                  "type": "string",
                  "maxLength": 100,
                  "edited": true,
                  "required": true,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_registrationCountry",
                  "localName": "Страна юрисдикции*",
                  "type": "array",
                  "format": "text",
                  "activity": [
                    2000
                  ],
                  "edited": false,
                  "required": true,
                  "multySelect": false
                },
                {
                  "sysName": "representative_facebook",
                  "localName": "Профиль в Facebook*",
                  "type": "string",
                  "edited": true,
                  "required": false,
                  "format": "hide"
                }
              ]
            },
            {
              "module": "Данные профиля",
              "page": 1,
              "pageName": "Юридическая информация и данные профиля",
              "fields": [
                {
                  "sysName": "questionnaire_investorType",
                  "localName": "Выберите тип инвестора",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    11000
                  ],
                  "multySelect": false,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего фонда",
                  "note": "Например: Фонд и акселератор",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите свою краткую характеристику как бизнес-ангела",
                  "note":"Например, Рассматриваю любые проекты",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "type": "string",
                   "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_note",
                  "localName": "Укажите краткое описание Вашего family-office",
                  "note": "Например: Фонд семьи Безосов",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "maxLength": 150,
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_site",
                  "localName": "Сайт",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_email",
                  "note": "Опционально",
                  "localName": "Публичный адрес электронной почты",
                  "type": "string",
                  "format": "e-mail",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11001",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11003",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Логотип",
                  "localName": "Загрузить логотип",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11004",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                }
              ]
            },
            {
              "module": "Ваши данные",
              "page": 2,
              "pageName": "Ваши данные",
              "fields": [
                {
                  "sysName": "questionnaire_logoFile",
                  "title": "Добавьте фото",
                  "localName": "Загрузить фото",
                  "type": "logo",
                  "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
                  "triggerField": "questionnaire_investorType",
                  "triggerValue": "11002",
                  "edited": true,
                  "required": false,
                  "allowedTypes": [
                    ".png"
                  ]
                },
                {
                  "sysName": "questionnaire_portfolioNote",
                  "localName": "Краткое описание портфельного стартапа",
                  "type": "string",
                  "maxLength": "300",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "representative_fio",
                  "localName": "Фамилия Имя",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_role",
                  "localName": "Должность*",
                  "note": "Например, Управляющий партнёр",
                  "type": "string",
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "representative_phone",
                  "localName": "Мобильный телефон*",
                  "type": "string",
                  "format": "phone",
                  "edited": true,
                  "required": true,
                  "mask": "phone"
                },
                {
                  "sysName": "representative_facebook",
                  "localName": "Профиль в Facebook*",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            },
            {
              "module": "Инвестиции",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "title": "Направления",
                  "sysName": "investment_industry",
                  "localName": "Направления",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    3000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_geography",
                  "title": "География стартапов",
                  "localName": "География стартапов",
                  "type": "array",
                  "format": "search_dropdown",
                  "activity": [
                    2000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                },
                {
                  "sysName": "investment_round",
                  "localName": "Стадии инвестирования",
                  "type": "array",
                  "format": "chip",
                  "activity": [
                    6000
                  ],
                  "multySelect": true,
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Данные о стартапах портфеля",
              "page": 3,
              "pageName": "Инвестиции",
              "fields": [
                {
                  "sysName": "questionnaire_activeDealsNumber",
                  "localName": "Количество стартапов в портфеле",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_allDealsNumber",
                  "localName": "Количество сделок, всего",
                  "note": "Количество стартапов, в которые Вы инвестировали",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                },
                {
                  "sysName": "questionnaire_exitDealsNumber",
                  "localName": "Количество выходов",
                  "note": "Количество стартапов, в которые Вы инвестировали и вышли",
                  "type": "int",
                  "edited": true,
                  "required": true,
                  "direction": "row",
                  "maxLength": 4,
                  "showLength": false
                }
              ]
            },
            {
              "module": "",
              "page": 3,
              "pageName": "Инвестиции",
              "subTitle": "Стартап №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить стартап",
              "fields": [
                {
                  "sysName": "questionnairePilots[]_pilotid",
                  "localName": "",
                  "type": "long",
                  "format": "hide",
                  "edited": false,
                  "required": false
                },
                {
                  "sysName": "questionnairePilots[]_company",
                  "localName": "Название стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                },
                {
                  "sysName": "questionnairePilots[]_site",
                  "localName": "Ссылка на сайт стартапа",
                  "note": "Опционально",
                  "type": "string",
                  "maxLength": "140",
                  "edited": true,
                  "required": false,
                  "showLength": false
                }
              ]
            },
            {
              "module": "Инвестиционные клубы",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "fields": [
                {
                  "sysName": "questionnaire_club",
                  "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
                  "type": "boolean",
                  "format": "switch",
                  "edited": true,
                  "required": true
                }
              ]
            },
            {
              "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
              "page": 4,
              "pageName": "Участие в инвестиционных клубах",
              "subTitle": "Клуб / сообщество №",
              "withIndex": true,
              "isArray": "true",
              "actionText": "Добавить клуб",
              "triggerField": "questionnaire_club",
              "triggerValue": true,
              "fields": [
                {
                  "sysName": "investorClubs[]_name",
                  "localName": "Название клуба / сообщества*",
                  "type": "string",
                  "edited": true,
                  "required": false
                },
                {
                  "sysName": "investorClubs[]_role",
                  "localName": "Ваша роль в клубе / сообществе*",
                  "note": "Например, Основатель клуба",
                  "type": "string",
                  "edited": true,
                  "required": false
                }
              ]
            }
          ]
        }'::json::json WHERE formname='investor_edit';

       UPDATE public.screen SET   formview='{
          "form": [{
            "module": "Основная информация",
            "page": 1,
            "fields": [{
              "sysName": "questionnaire_investorType",
              "localName": "Тип инвестора",
              "type": "array",
              "format": "text",
              "activity": [
                11000
              ],
              "edited": false,
              "required": false
            },{
              "sysName": "questionnaire_fullName",
              "localName": "Название/имя",
              "type": "string",
              "edited": false,
              "required": false
            },{
                  "sysName": "questionnaire_note",
                  "localName": "Краткое описание",
                  "type": "string",
                  "edited": false,
                  "required": false
            },{
              "sysName": "questionnaire_site",
              "localName": "Сайт (Доступно по подписке)",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_email",
              "localName": "Email (Доступно по подписке)",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
            ]
          }, {
            "module": "Инвестиции (Доступно по подписке)",
            "page": 1,
            "fields": [{
              "sysName": "investment_industry",
              "localName": "Направление инвестиций",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "project_geography",
              "localName": "География стартапов",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "investment_round",
              "localName": "Стадии инвестиций",
              "type": "array",
              "format": "text",
              "activity": [
                6000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "investment_note",
              "localName": "Особые условия инвестирования",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_portfolioNote",
              "localName": "Краткое описание портфельного стартапа",
              "type": "string",
              "maxLength": "300",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_allDealsNumber",
              "localName": "Количество стартапов, в которые инвестировал фонд",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            },{
              "sysName": "questionnaire_exitDealsNumber",
              "localName": "Количество выходов",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            }
            ]
          },{
            "module": "Портфель",
            "page": 1,
            "isArray": true,
            "fields": [{
              "sysName": "pilots[]_pilotid",
              "localName": "",
              "type": "int",
              "format": "hide",
              "edited": false,
              "required": false
            }, {
              "sysName": "pilots[]_company",
              "localName": "Название стартапа",
              "type": "string",
              "edited": false,
              "required": false
            }
            ]
          }
          ]
        }'::json::json where formname='investor_Client';

       UPDATE public.screen SET formview='{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_investorType",
      "localName": "Тип инвестора",
      "type": "array",
      "format": "text",
      "activity": [
        11000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_fullName",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },{
                  "sysName": "questionnaire_note",
                  "localName": "Краткое описание",
                  "type": "string",
                  "edited": false,
                  "required": false
            },
      {
        "sysName": "questionnaire_portfolioNote",
        "localName": "Краткое описание портфельного стартапа",
        "type": "string",
        "maxLength": "300",
        "edited": false,
        "required": false
      },{
        "sysName": "questionnaire_site",
        "localName": "Сайт",
        "type": "hyperlink",
        "edited": false,
        "required": false
      },{
        "sysName": "questionnaire_email",
        "localName": "Email",
        "type": "string",
        "edited": false,
        "required": false
      }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Направление инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География стартапов",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_round",
      "localName": "Стадии инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_note",
      "localName": "Особые условия инвестирования",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_allDealsNumber",
      "localName": "Количество стартапов, в которые инвестировал фонд",
      "type": "int",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_exitDealsNumber",
      "localName": "Количество выходов",
      "type": "int",
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "Портфель",
    "page": 1,
    "isArray": true,
    "fields": [{
      "sysName": "questionnairePilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_company",
      "localName": "Название стартапа",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}
'::json::json WHERE formname='investor_SuperClient' ;