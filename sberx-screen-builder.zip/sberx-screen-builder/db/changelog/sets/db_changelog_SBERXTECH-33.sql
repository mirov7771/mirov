--liquibase formatted sql
--changeset Rakhimova NV:SBERXTECH-33
INSERT INTO public.screen
(id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription)
VALUES((select max(id)+1 from public.screen ), '111260', 1, 'corporate_preauth', '{}', '{"form":[{"module":"","page":1,"fields":[{"sysName":"Project_Note","localName":"","type":"string","edited":false,"required":false},{"sysName":"Questionnaire_Site","localName":"","type":"hyperlink","edited":false,"required":false},{"sysName":"Questionnaire_Innovationmethod","localName":"Метод работы с инновациями","type":"array","format":"chip","activity":[4000],"edited":false,"required":false}]}]}', 'Карточка корпорации в неавторизованной зоне', '', 1, '{"buttons":[{"icon":"","type":"active","text":"Присоединиться","action":"/auth","variant":"primary","description":""}]}', '', '', '');
 
INSERT INTO public.screen
(id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription)
VALUES((select max(id)+1 from public.screen ),'8385', 1, 'corporate_preauth', '{}', '{"form":[{"module":"","page":1,"fields":[{"sysName":"Project_Note","localName":"","type":"string","edited":false,"required":false},{"sysName":"Questionnaire_Site","localName":"","type":"hyperlink","edited":false,"required":false},{"sysName":"Questionnaire_Innovationmethod","localName":"Метод работы с инновациями","type":"array","format":"chip","activity":[4000],"edited":false,"required":false}]}]}', 'Карточка корпорации в неавторизованной зоне', '', 1, '{"buttons":[{"icon":"","type":"active","text":"Присоединиться","action":"/auth","variant":"primary","description":""}]}', '', '', '');
 