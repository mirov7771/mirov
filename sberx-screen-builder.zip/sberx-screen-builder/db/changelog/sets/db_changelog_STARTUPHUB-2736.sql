--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-2736
UPDATE public.screen SET formview='{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_fullNote",
      "localName": "Описание",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_industry",
      "localName": "Направление деятельности",
      "type": "array",
      "format": "text",
      "activity": [
        22000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_innovationMethod",
      "localName": "Методы работы с инновациями",
      "type": "array",
      "format": "text",
      "activity": [4000],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_site",
      "localName": "Сайт корпорации",
      "title": "Перейти",
      "type": "hyperlink",
      "format": "button",
      "edited": false,
      "required": false
    },
    {
      "sysName": "questionnaire_email",
      "localName": "Email",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Работа со стартапами",
    "page": 1,
    "fields": [{
      "sysName": "project_industry",
      "localName": "Индустрии",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_technology",
      "localName": "Технологии",
      "type": "array",
      "format": "text",
      "activity": [
        13000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_stady",
      "localName": "Стадии развития продуктов",
      "type": "array",
      "format": "text",
      "activity": [
        7000
      ],
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "",
    "page": 1,
    "isArray": "true",
    "fields": [{
      "sysName": "questionnairePilots[]_pilotId",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_suggestCase",
      "localName": "Описание потребности",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_round",
      "localName": "Раунд инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "",
    "page": 1,
    "triggerField": "investment_investment",
    "triggerValue": "true",
     "moduleFormat" : "card",
    "isArray": true,
    "fields": [{
      "sysName": "successPilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "successPilots[]_company",
      "localName": "Успешный кейсы",

      "type": "string",
      "format": "body",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}' WHERE formname='corporate_SuperClient';
