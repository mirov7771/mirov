--liquibase formatted sql
--changeset Mirov A:scouting_page
delete
from public.pages
where uri = '/scouting';

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('scouting_az_ru', 'SberUnity', '/scouting', 'SberUnity', 'auth', '{
   "features":[
      {
         "type":"welcomeScreen",
         "visible":true,
         "position":1,
         "buttons":[
            {
               "text":"Заказать подбор",
               "url":"",
               "theme":"orange-gradient",
               "config":{
                  "scouting":{
                     "link":"/view?action=2&type=13&name=New_scouting"
                  }
               }
            }
         ],
         "imageUrl":"/file/scoutingBanner.png",
         "subtitle":"Подбор стартапов",
         "title":"Закажите скаутинг стартапов",
         "description":"В данном разделе вы можете заказать услугу подбора стартапов профессиональными скаутами и аналитиками Сбера под ваш персональный запрос",
         "backgroundColorChip":"#F2F4F6",
         "welcomeScreenTheme":"baseBanner"
      },
      {
         "type":"squareList",
         "visible":true,
         "position":2,
         "title":"Отберём лучших для вас",
         "theme":"base",
         "isMobileCarousel":false,
         "items":[
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_document_with_star.png",
               "title":"Сформируем воронку проектов",
               "description":"по заданным параметрам",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_filter.png",
               "title":"Подготовим лонг-лист и шорт-лист",
               "description":"с презентацией, собственной первичной оценкой и другими материалами",
               "isExternal":true
            },
            {
               "theme":"base",
               "iconUrl":"/file/ic_88_two_persons.png",
               "title":"Организуем питч-сессию и интро",
               "description":"с понравившимися проектами",
               "isExternal":true
            }
         ]
      },
      {
         "type":"photoGallery",
         "visible":true,
         "position":3,
         "title":"Проведём питч-сессию онлайн или на площадке современного коворкинга",
         "description":"Для получения дополнительной информации, обсуждения условий и ваших потребностей, напишите нам на почту [sberunity@sberbank.ru](mailto:sberunity@sberbank.ru) с пометкой «Скаутинг» или обратитесь к вашему персональному менеджеру",
         "images":[
            "/file/photo_4077.jpg",
            "/file/photo_4078.jpg",
            "/file/photo_4079.jpg"
         ],
         "carouselResponsiveConfig":{
            "sm":{
               "slideGap":40,
               "slidesToShow":1,
               "showArrows":true
            },
            "md":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "lg":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            },
            "xl":{
               "slideGap":40,
               "slidesToShow":3,
               "showArrows":false
            }
         }
      }
   ]
}',1)