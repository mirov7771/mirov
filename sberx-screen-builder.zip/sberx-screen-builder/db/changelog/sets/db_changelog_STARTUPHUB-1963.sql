--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-1963

UPDATE public.screen SET   formview='{
      "form": [
        {
          "module": "Основная информация",
          "page": 1,
          "fields": [
            {
              "sysName": "questionnaire_fullName",
              "localName": "Название",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_site",
              "localName": "Сайт",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_acceleratorCode",
              "localName": "Является выпускником:",
              "type": "array",
              "format": "text",
              "activity": [
                26000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_birthYear",
              "localName": "Год основания",
              "type": "int",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_interactionType",
              "localName": "Тип взаимодействия с пользователем",
              "type": "array",
              "format": "text",
              "activity": [
                8000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "questionnaire_businessModel",
              "localName": "Бизнес-модели",
              "type": "array",
              "format": "search_dropdown",
              "activity": [
                24000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_industry",
              "localName": "Индустрия проекта",
              "type": "array",
              "format": "text",
              "activity": [
                3000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_note",
              "localName": "Краткое описание проекта",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_problem",
              "localName": "Проблема, которую решает проект",
              "type": "string",
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_auditory",
              "localName": "Целевая аудитория",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Дополнительные контакты (Доступно по подписке)",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "contacts[]_name",
              "localName": "Ссылка",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "О проекте (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_mvpCode",
              "localName": "Стадия развития продукта",
              "type": "array",
              "format": "text",
              "activity": [
                27000
              ],
              "edited": false,
              "required": false
            },
            {
              "sysName": "project_demoSite",
              "localName": "Ссылка на демо",
              "type": "hyperlink",
              "triggerField": "project_haveMVP",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_demoVideo",
              "localName": "Видео о продукте",
              "type": "hyperlink",
              "triggerField": "project_haveMVP",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_businessPlan",
              "localName": "Презентация (Доступно по подписке)",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_pitchVideo",
              "localName": "Видео питча",
              "type": "hyperlink",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_geography",
              "localName": "Рынки, на которых работает стартап",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_expansion",
              "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_sales",
              "localName": "Продажи",
              "type": "array",
              "format": "text",
              "activity": [
                5000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_turnover",
              "localName": "Оборот",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Конкуренты (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_competitor",
              "localName": "Прямые конкуренты",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_indirectCompetitor",
              "localName": "Косвенные конкуренты",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_upSide",
              "localName": "Преимущества перед конкурентами",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_downSide",
              "localName": "Недостатки перед конкурентами ",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Команда (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "questionnaire_locationCountry",
              "localName": "Страна, где находится команда",
              "type": "array",
              "format": "text",
              "activity": [
                2000
              ],
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "questionnaire_location",
              "localName": "Город, где находится команда",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_staff",
              "localName": "Количество сотрудников",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "project_hiringStaff",
              "localName": "Из них наемных сотрудников",
              "type": "int",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "",
          "page": 1,
          "isArray": "true",
          "fields": [
            {
              "sysName": "worker_parentId",
              "localName": "",
              "type": "long",
              "format": "hide",
              "edited": false,
              "required": false
            },
            {
              "sysName": "worker_isFounder",
              "localName": "",
              "type": "boolean",
              "format": "hide",
              "value": false,
              "edited": false,
              "required": false
            },
            {
              "sysName": "worker_role",
              "localName": "Ключевые члены команды",
              "type": "string",
              "edited": false,
              "required": false,
              "direction": "concatenation",
              "isBlur": true
            },
            {
              "sysName": "workers[]_note",
              "localName": "Опыт",
              "type": "string",
              "maxLength": "150",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы (Доступно по подписке)",
          "moduleNote": "",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "b2bPilots[]_state",
              "localName": "",
              "type": "array",
              "format": "hide",
              "value": "20007",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2bPilots[]_reference",
              "localName": "С кем был успешный кейс",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2bPilots[]_suggestCase",
              "localName": "Описание и результаты кейса",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Успешные B2C-, C2C- кейсы (Доступно по подписке)",
          "moduleNote": "",
          "page": 1,
          "pageName": "",
          "isArray": "true",
          "fields": [
            {
              "sysName": "b2cPilots[]_state",
              "localName": "",
              "type": "array",
              "format": "hide",
              "value": "20007",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2cPilots[]_reference",
              "localName": "С кем был успешный кейс",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "b2cPilots[]_suggestCase",
              "localName": "Описание и результаты кейса",
              "type": "string",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Инвестиции (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "investment_investment",
              "localName": "Проект привлекает инвестиции",
              "type": "boolean",
              "format": "switch",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_round",
              "localName": "Раунд",
              "type": "array",
              "format": "chip",
              "activity": [
                6000
              ],
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_sumInvestment",
              "localName": "Требуемая сумма",
              "type": "int",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_lastInvestment",
              "localName": "Объем ранее привлеченных инвестиций, всего",
              "type": "string",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            },
            {
              "sysName": "investment_coInvestment",
              "localName": "Имя/ имена инвестора/ инвесторов",
              "type": "string",
              "triggerField": "investment_investment",
              "triggerValue": "true",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        },
        {
          "module": "Дополнительная информация (Доступно по подписке)",
          "page": 1,
          "fields": [
            {
              "sysName": "project_addNote",
              "localName": "Что еще важно знать о проекте?",
              "type": "string",
              "maxLength": "500",
              "edited": false,
              "required": false,
              "isBlur": true
            }
          ]
        }
      ]
    }'::json::json where formname='startup_Client';

UPDATE public.screen SET  formview='{
  "form": [
    {
      "module": "Организация",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "Questionnaire_Modified",
          "localName": "Время обновления",
          "type": "date",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": false,
          "required": false
        },{
          "sysName": "questionnaire_inn",
          "localName": "ИНН организации",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "maxLength": 4,
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "type": "string",
          "edited": false,
          "required": false
        },

        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "text",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "chip",
          "activity": [
            24000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_industry",
          "localName": "Направления",
          "type": "array",
          "format": "text",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "type": "logo",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Прототип",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "text",
          "activity": [27000],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "hyperlink",
          "format": "URL",
          "triggerField": "project_haveMVP",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }

      ]
    },
    {
      "module": "О проекте",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "hyperlink",
          "format": "URL",
          "edited": false,
          "required": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 1,
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "text",
          "activity": [
            5000
          ],
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в месяц и оборот в год",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "edited": false,
          "required": false
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные B2C-, C2C- кейсы",
      "page": 1,
      "pageName": "",
      "isArray": "true",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "type": "string",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "edited": false,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "edited": false,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Проект привлекает инвестиции",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций",
          "type": "int",
          "mask": "splitter",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Является выпускником:",
          "type": "array",
          "format": "text",
          "activity": [26000],
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщества",
      "page": 1,
      "pageName": "",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществах СберСтартап",
          "type": "boolean",
          "format": "switch",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 1,
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'  WHERE formname='startup_Administrator' ;
UPDATE public.screen SET formview='{ "form": [{
  "module": "Основная информация",
  "page": 1,
  "fields": [{
    "sysName": "project_note",
    "localName": "Краткое описание проекта",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_problem",
    "localName": "Проблема, которую решает проект",
    "type": "string",
    "edited": false,
    "required": false
  },  {
    "sysName": "project_auditory",
    "localName": "Целевая аудитория",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_site",
    "localName": "Сайт",
    "title": "Перейти",
    "type": "hyperlink",
    "format": "button",
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_acceleratorCode",
    "localName": "Является выпускником:",
    "type": "array",
    "format": "text",
    "activity": [26000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_birthYear",
    "localName": "Год основания",
    "type": "int",
    "edited": false,
    "required": false
  },{
    "sysName": "project_interactionType",
    "localName": "Модель продаж",
    "type": "array",
    "format": "text",
    "activity": [8000],
    "edited": false,
    "required": false
  },{
    "sysName": "questionnaire_businessModel",
    "localName": "Бизнес-модели",
    "type": "array",
    "format": "search_dropdown",
    "activity": [
      24000
    ],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_industry",
    "localName": "Индустрии проекта",
    "type": "array",
    "format": "text",
    "activity": [3000],
    "edited": false,
    "required": false
  }, {
    "sysName": "project_technology",
    "localName": "Технологии проекта",
    "type": "array",
    "format": "text",
    "activity": [13000],
    "edited": false,
    "required": false
  },{
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "type": "string",
          "edited": false,
          "required": false
        }
  ]
}, {
  "module": "Дополнительные ссылки",
  "page": 1,
  "pageName": "",
  "isArray": "true",
   "moduleFormat" : "button",
  "fields": [
    {
          "sysName": "contacts[]_type",
          "localName": "",
          "type": "array",
          "format": "heading",
          "activity": [
            21000
          ],
          "edited": false,
          "required": false,
          "multySelect": false
    },
    {
          "sysName": "contacts[]_name",
          "title": "Перейти",
          "type": "info",
          "format": "button",
          "edited": false,
          "required": false
    }
  ]
},{
  "module": "О проекте",
  "page": 1,
  "fields": [{
    "sysName": "project_mvpCode",
    "localName": "Стадия развития продукта",
    "type": "array",
    "format": "text",
    "activity": [27000],
    "edited": false,
    "required": false
  }, {
      "sysName": "project_sales",
      "localName": "Продажи",
      "type": "array",
      "format": "text",
      "activity": [5000],
      "edited": false,
      "required": false
    }, {
      "sysName": "investment_turnover",
      "localName": "Оборот",
      "type": "string",
      "edited": false,
      "required": false
    }, {
    "sysName": "project_demoSite",
    "localName": "Ссылка на демо",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "project_demoVideo",
    "localName": "Видео о продукте",
    "type": "hyperlink",
    "title": "Смотреть",
    "format": "button",
    "triggerField": "project_haveMVP",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },
    {
      "sysName": "investment_businessPlan",
      "localName": "Презентация",
      "type": "hyperlink",
      "title": "Смотреть",
      "format": "filebutton",
      "edited": false,
      "required": false
    },{
      "sysName": "project_pitchVideo",
      "localName": "Видео питча",
      "type": "hyperlink",
      "title": "Смотреть",
      "format": "button",
      "edited": false,
      "required": false

    },  {
      "sysName": "project_geography",
      "localName": "Рынки, на которых работает стартап",
      "type": "array",
      "format": "text",
      "activity": [2000],
      "edited": false,
      "required": false
    },{
      "sysName": "project_expansion",
      "localName": "Рынки, на которые стартап планирует выйти в будущем",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }
  ]
}, {
  "module": "Конкуренты",
  "page": 1,
  "fields": [{
    "sysName": "project_competitor",
    "localName": "Прямые конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_indirectCompetitor",
    "localName": "Косвенные конкуренты",
    "type": "string",
    "edited": false,
    "required": false
  },{
    "sysName": "project_upSide",
    "localName": "Преимущества перед конкурентами",
    "type": "string",
    "edited": false,
    "required": false
  }, {
    "sysName": "project_downSide",
    "localName": "Недостатки перед конкурентами ",
    "type": "string",
    "edited": false,
    "required": false
  }
  ]
}, {
  "module": "Команда",
  "page": 1,
  "fields": [


    {
      "sysName": "questionnaire_locationCountry",
      "localName": "Страна, где находится команда",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },
    {
      "sysName": "questionnaire_location",
      "localName": "Город, где находится команда",
      "type": "string",
      "edited": false,
      "required": false
    },
    {
      "sysName": "project_staff",
      "localName": "Количество сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }, {
      "sysName": "project_hiringStaff",
      "localName": "Из них наемных сотрудников",
      "type": "int",
      "edited": false,
      "required": false,
      "direction": "row"
    }
  ]
},  {
  "module": "",
  "page": 1,
  "isArray": "true",
  "moduleFormat" : "card",
  "fields": [{
    "sysName": "workers[]_parentId",
    "localName": "",
    "type": "long",
    "format": "hide",
    "edited": false,
    "required": false
  },{
    "sysName": "workers[]_role",
    "localName": "Ключевые члены команды",
    "type": "string",
    "format": "heading",
    "edited": false,
    "required": false
  },{
    "sysName": "workers[]_note",
    "localName": "Опыт",
    "type": "string",
    "format": "body",
    "edited": false,
    "required": false
  }
  ]
}, {
"module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
"moduleNote": "",
"page": 1,
"pageName": "",
"isArray": "true",
"moduleFormat" : "card",
"fields": [
{
"sysName": "b2bPilots[]_state",
"localName": "",
"type": "array",
"format": "hide",
"value": "20007",
"edited": false,
"required": false
},
{
"sysName": "b2bPilots[]_reference",
"localName": "",
"type": "string",
"format": "heading",
"edited": false,
"required": false
},
{
"sysName": "b2bPilots[]_suggestCase",
"localName": "",
"type": "string",
"format": "body",
"edited": false,
"required": false
}
]
}, {
  "module": "Успешные B2C-, C2C- кейсы",
  "moduleNote": "",
  "page": 1,
  "pageName": "",
  "isArray": "true",
  "moduleFormat" : "card",
  "fields": [
    {
      "sysName": "b2cPilots[]_state",
      "localName": "",
      "type": "array",
      "format": "hide",
      "value": "20007",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_reference",
      "localName": "С кем был успешный кейс",
      "type": "string",
      "format": "heading",
      "edited": false,
      "required": false
    },
    {
      "sysName": "b2cPilots[]_suggestCase",
      "localName": "Описание и результаты кейса",
      "type": "string",
      "format": "body",
      "edited": false,
      "required": false
    }
  ]
},{
  "module": "Инвестиции",
  "page": 1,
  "fields": [{
    "sysName": "investment_investment",
    "localName": "Проект привлекает инвестиции",
    "type": "boolean",
    "format": "switch",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_round",
    "localName": "Раунд",
    "type": "array",
    "format": "chip",
    "activity": [6000],
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }, {
    "sysName": "investment_sumInvestment",
    "localName": "Требуемая сумма (USD)",
    "type": "int",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_lastInvestment",
    "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  },{
    "sysName": "investment_coInvestment",
    "localName": "Имя/ имена инвестора/ инвесторов",
    "type": "string",
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "edited": false,
    "required": false
  }
  ]
},{
  "module": "Дополнительная информация",
  "page": 1,
  "fields": [
    {
      "sysName": "project_addNote",
      "localName": "Что еще важно знать о проекте?",
      "type": "string",
      "maxLength": "500",
      "edited": false,
      "required": false
    }
  ]
}
]
}' WHERE formname='startup_SuperClient';
