--liquibase formatted sql
--changeset Mirov AA:import_unauth
delete from pages where code = 'import_unauth_ru';
insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('import_unauth_ru', 'SberUnity Ипортозамещение', '/import-substitution', 'Импортозамещение', 'unauth',
        '{
    "features": [
        {
            "type": "breadcrumbs",
            "sysName": "startups_ru_breadcrumbs",
            "visible": true,
            "position": 1,
            "items": [
                {
                    "name": "Главная",
                    "pathname": "/",
                    "id": 1
                },
                {
                    "name": "Импортозамещение",
                    "id": 2
                }
            ]
        },
        {
            "type": "pageTitle",
            "visible": true,
            "position": 2,
            "sysName": "startups_ru_pageTitle",
            "title": "Импортозамещающие решения",
            "config": {
                "styles": {
                    "padding": {
                        "xs": {
                            "top": 16,
                            "bottom": 24
                        },
                        "s": {
                            "top": 16,
                            "bottom": 24
                        },
                        "md": {
                            "top": 24,
                            "bottom": 32
                        },
                        "lg": {
                            "top": 24,
                            "bottom": 32
                        }
                    }
                }
            }
        },
        {
            "type": "participantSearch",
            "sysName": "startups_ru_participantSearch",
            "visible": true,
            "position": 3,
            "isImport": true,
            "placeholder": "Поиск сервисов-аналогов",
            "participant": "startup",
            "shownFromTitle": "Всего {1} решений",
            "helperText": "Введите название сервиса, аналог которого хотите найти, или название стартапа",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "popupFooter": {
                "title": "Зарегистрируйтесь, чтобы получить доступ к полной анкете",
                "caption": "После регистрации будут доступны: полное описание компании, информация о продукте, направления, ключевые сотрудники, успешные пилоты, инвестиции и трекшн стартапа.",
                "mainButtonText": "Зарегистрироваться",
                "secondButtonText": "Войти"
            },
            "features": [
                {
                    "type": "authBanner",
                    "sysName": "authBanner",
                    "visible": true,
                    "position": 1,
                    "typeBanner": "participantSearch",
                    "title": "Зарегистрируйте и получите доступ к %import_size% по импортозамещению",
                    "mainButtonText": "Зарегистрироваться",
                    "secondButtonText": "Войти",
                    "placement": "bottom",
                    "config": {
                        "nowrap": true
                    }
                },
                {
                    "caption": "Расскажите корпорациям, какие сервисы заменяет ваш продукт",
                    "buttonText": "Рассказать о продукте",
                    "position": 1,
                    "sysName": "importSubstitutionBanner",
                    "title": "Будьте в тренде импортозамещения",
                    "type": "importSubstitutionBanner",
                    "isClosed": false,
                    "redirectTo": "/participant-registration",
                    "visible": true, "bannerUrl": "/file/p3.png",
                    "placement": "middle",
                    "config": {
                        "nowrap": true,
                        "styles": {
                           "padding":{
                              "xs":{
                                 "top":32,
                                 "bottom":0
                              },
                              "s":{
                                 "top":32,
                                 "bottom":0
                              },
                              "md":{
                                 "top":48,
                                 "bottom":0
                              },
                              "lg":{
                                 "top":48,
                                 "bottom":0
                              }
                           }
                        }
                    }
                }
            ]
        }
    ]
}',1);

delete from screen where formname = 'startup_import';
delete from screen where formname = 'serviceCompany_import';
insert into screen (type, formname, formview,lang_id)
values (0, 'startup_import',
        '{
            "form": [
                {
                    "page": 1,
                    "fields": [
                        {
                            "type": "string",
                            "edited": false,
                            "sysName": "Project_Note",
                            "required": false,
                            "localName": ""
                        },
                        {
                            "type": "array",
                            "edited": false,
                            "format": "tags",
                            "sysName": "importReplace_name",
                            "required": false,
                            "localName": "Названия сервисов, которые заменяет продукт стартапа"
                        },
                        {
                            "type": "date",
                            "edited": false,
                            "format": "YYYY",
                            "sysName": "Questionnaire_Birthday",
                            "required": false,
                            "direction": "row",
                            "localName": "Год основания"
                        }
                    ],
                    "module": ""
                }
            ]
        }', 1);

insert into screen (type, formname, formview,lang_id)
values (3, 'serviceCompany_import', '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "serviceCompany_name",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "tags",
                    "sysName": "importReplace_name",
                    "required": false,
                    "localName": "Сервисы-аналоги"
                }
            ],
            "module": ""
        }
    ]
}', 1);

update public.pages
set page = '{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "corporates_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Корпорации",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "corporates_ru_pageTitle",
      "title": "Станьте партнером корпорации",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "corporates_ru_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Введите название",
      "participant": "corporation",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}",
          "popupFooter": {
              "caption": "Для просмотра полной анкеты корпорации зарегистрируйтесь или войдите на платформу",
              "mainButtonText": "Присоединиться",
              "secondButtonText": "Войти"
          }
    }
  ]
}'
where page_type = 'unauth'
  and uri = '/corporates'
  and lang_id = 1;


update public.pages
set page = (select page from pages where uri = '/syndicate' and lang_id = 1)
where uri = '/syndicate'
  and lang_id = 2;

delete from page_values_cache where name = '%import_size%';
insert into page_values_cache
values ('%import_size%', 0, 50, null, 'GET', '/list/questionnaire?type=0&isImport=true');