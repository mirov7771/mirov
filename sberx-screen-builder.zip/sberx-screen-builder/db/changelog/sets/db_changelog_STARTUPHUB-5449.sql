--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5449
update client_menu set priority = 1 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Запросы корпораций';
update client_menu set priority = 2 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Импортозамещение';
update client_menu set priority = 3 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Инвестиции';
update client_menu set priority = 4 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Корпорации';
update client_menu set priority = 5 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Инвесторы';
update client_menu set priority = 6 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Стартапы';
update client_menu set priority = 7 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Сервисы';
update client_menu set priority = 8 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Сообщество';
update client_menu set priority = 9 where type = 0 and menutype = 'sidebar' and user_role = 'SuperClient' and name = 'Мои метрики';

update client_menu set priority = 1 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Запросы корпораций';
update client_menu set priority = 2 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Импортозамещение';
update client_menu set priority = 3 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Инвестиции';
update client_menu set priority = 4 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Корпорации';
update client_menu set priority = 5 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Инвесторы';
update client_menu set priority = 6 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Стартапы';
update client_menu set priority = 7 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Сервисы';
update client_menu set priority = 8 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Сообщество';
update client_menu set priority = 9 where type = 0 and menutype = 'sidebar' and user_role = 'Client' and name = 'Мои метрики';


update client_menu set priority = 1 where type = 1 and menutype = 'sidebar' and name = 'Стартапы';
update client_menu set priority = 2 where type = 1 and menutype = 'sidebar' and name = 'Импортозамещение';
update client_menu set priority = 3 where type = 1 and menutype = 'sidebar' and name = 'Мои запросы';
update client_menu set priority = 4 where type = 1 and menutype = 'sidebar' and name = 'Отклики';
update client_menu set priority = 5 where type = 1 and menutype = 'sidebar' and name = 'Скаутинг';
update client_menu set priority = 6 where type = 1 and menutype = 'sidebar' and name = 'Инвесторы';
update client_menu set priority = 7 where type = 1 and menutype = 'sidebar' and name = 'Корпорации';

update client_menu set priority = 1 where type = 2 and menutype = 'sidebar' and name = 'Инвестиции';
update client_menu set priority = 2 where type = 2 and menutype = 'sidebar' and name = 'Стартапы';
update client_menu set priority = 3 where type = 2 and menutype = 'sidebar' and name = 'Сообщество';
update client_menu set priority = 4 where type = 2 and menutype = 'sidebar' and name = 'Запросы корпораций';
update client_menu set priority = 5 where type = 2 and menutype = 'sidebar' and name = 'Корпорации';
update client_menu set priority = 6 where type = 2 and menutype = 'sidebar' and name = 'Инвесторы';
update client_menu set priority = 7 where type = 2 and menutype = 'sidebar' and name = 'Скаутинг';
update client_menu set priority = 7 where type = 2 and menutype = 'sidebar' and name = 'Импортозамещение';

update client_menu set user_role = 'CorpLight' where user_role = 'CorpDemo';
update client_menu set user_role = 'InvestLight' where user_role = 'InvestDemo';
