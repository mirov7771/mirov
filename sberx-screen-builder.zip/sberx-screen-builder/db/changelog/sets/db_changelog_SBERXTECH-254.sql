--liquibase formatted sql
--changeset Mirov A:SBERXTECH-254
update screen
set formview = '{
  "form": [
    {
      "module": "",
      "page": 1,
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "",
          "type": "string",
          "format": "caption",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "",
          "type": "string",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnaire_investorType",
          "localName": "Тип инвестора",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "edited": false,
          "required": false,
          "direction": "row"
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестирования",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "edited": false,
          "required": false,
          "direction": "row"
        },
        {
          "sysName": "investment_industry",
          "localName": "Направления",
          "type": "array",
          "format": "chip",
          "activity": [
            3000
          ],
          "edited": false,
          "required": false
        }
      ]
    }
  ]
}'
where formname  = 'investor_preauth';

