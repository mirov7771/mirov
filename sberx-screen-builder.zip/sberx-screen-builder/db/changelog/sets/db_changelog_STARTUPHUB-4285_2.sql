--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4285_2
update public."schemas"
set value = '{   "value": {
    "itemIdKey": "pilotId",
    "clickable": true,
    "columns": [
        {
            "sysName": "company",
            "type": "img",
            "title": "Компания",
            "key": "questionnaire.logoFile",
            "refs": {
                "labelKey": "questionnaire.name"
            }
        },
        {
            "sysName": "description",
            "type": "string",
            "title": "Потребность",
            "key": "suggestCase"
        },
        {
            "sysName": "status",
            "type": "nameplate",
            "title": "Статус",
            "key": "replyStatus",
            "refs": {
                "map": {
						"20011": "Новый",
						"20002": "В работе",
						"20004": "Пилотируется",
						"20009": "Отказ",
						"20003": "Пауза",
						"20007": "Завершен",
                        "20013": "Отозван"
                    }
                }
            }

    ]
}
}'
where "name" = 'pilots_user';