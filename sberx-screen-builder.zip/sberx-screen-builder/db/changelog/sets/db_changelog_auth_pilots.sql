--liquibase formatted sql
--changeset Leskov-LS:auth_pilots_pages
delete
from pages
where uri = '/auth-pilots-corporate' and lang_id = 1;

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('auth-pilots-corporate_ru', 'Мои запросы', '/auth-pilots-corporate', 'Мои запросы АЗ', 'auth', '{
  "features": [
    {
      "type": "authPilotSearch",
      "sysName": "authPilotSearch",
      "visible": true,
      "header": "Мои запросы",
      "position": 1,
      "buttons": {
        "createPilot": "Создать пилот"
      },
      "emptyLabel": {
        "offers": "Вы пока не предлагали пилоты корпорациям.",
        "myReplies": "Вы пока не откликались на запросы корпораций.",
        "common": "Предложить пилот можно во вкладке",
        "button": "Все пилоты"
      },
      "menuItems": [
        {
          "label": "Активные",
          "value": "all"
        },
        {
          "label": "Архивные",
          "value": "archive"
        }
      ],
      "modalTexts": {
        "buttons": {
          "confirm": "Создать пилот",
          "cancel": "Отменить"
        }
      }
    }
  ]
}'::json::json, 1);

delete
from pages
where uri = '/auth-pilots-investor' and lang_id = 1;

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('auth-pilots-investor_ru', 'Запросы корпораций', '/auth-pilots-investor', 'Запросы корпораций АЗ', 'auth', '{
  "features": [
    {
      "type": "authBanner",
      "typeBanner": "successStory",
      "title": "Расскажите как вам помог SberUnity и получите новые возможности!",
      "mainButtonText": "Рассказать",
      "position": 1
    },
    {
      "type": "spacer",
      "height": {
        "mobile": 32,
        "desktop": 32
      },
      "width": {
        "mobile": "100%",
        "desktop": "100%"
      },
      "position": 2
    },
    {
      "type": "authPilotSearch",
      "sysName": "authPilotSearch",
      "visible": true,
      "header": "Запросы корпораций",
      "menuTitle": "Корпорации",
      "notFoundTitle": "Ничего не найдено",
      "fastFilterLabels": {
        "favoriteLabel": "Избранные",
        "viewedLabel": "Просмотренное",
        "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
      },
      "menuDescription": "Здесь появится список корпораций, запросы которых вы добавите в избранное",
      "position": 3
    }
  ]
}'::json::json, 1);

delete
from pages
where uri = '/auth-pilots-startup' and lang_id = 1;

insert into pages (code, name, uri, description, page_type, page, lang_id)
values ('auth-pilots-startup_ru', 'Запросы корпораций', '/auth-pilots-startup', 'Запросы корпораций АЗ', 'auth', '{
  "features": [
    {
      "type": "slimBanner",
      "sysName": "slimBanner",
      "visible": true,
      "title": "Какие сервисы заменяет ваш продукт?",
      "subTitle": "Добавьте информацию, чтобы стать заметнее для корпораций",
      "buttonTexts": {
        "confirm": "Добавить информацию",
        "cancel": "Не показывать больше"
      },
      "modalTexts": {
        "buttons": {
          "confirm": "Добавить",
          "cancel": "Неактуально"
        },
        "description": "Добавить информацию можно позже на странице редактирования анкеты"
      },
      "position": 1
    },
    {
      "type": "authBanner",
      "typeBanner": "successStory",
      "title": "Расскажите как вам помог SberUnity и получите новые возможности!",
      "mainButtonText": "Рассказать",
      "position": 2
    },
    {
      "type": "authPilotSearch",
      "sysName": "authPilotSearch",
      "visible": true,
      "header": "Запросы корпораций",
      "placeholder": "Поиск пилотов",
      "notFoundTitle": "Ничего не найдено",
      "chooseCorp": "Выбрать корпорацию",
      "menuTitle": "Корпорации",
      "showMoreBtn": "Показать ещё",
      "menuDescription": "Здесь появится список корпораций, запросы которых вы добавите в избранное",
      "emptyLabel": {
        "offers": "Вы пока не предлагали пилоты корпорациям.",
        "myReplies": "Вы пока не откликались на запросы корпораций.",
        "common": "Предложить пилот можно во вкладке",
        "button": "Все пилоты"
      },
      "modalTexts": {
        "buttons": {
          "confirm": "Создать пилот",
          "cancel": "Отменить"
        },
        "alert": {
          "title": "Необходима дополнительная информация",
          "additionalInfo": "Комментарий администратора:"
        }
      },
      "filterBar": {
        "title": "Фильтры",
        "acceptButtonText": "Применить фильтры",
        "resetButtonText": "Сбросить фильтры",
        "acceptButtonShortText": "Применить",
        "resetButtonShortText": "Сбросить",
        "placeholder": "поиск"
      },
      "fastFilterLabels": {
        "favoriteLabel": "Избранные",
        "viewedLabel": "Просмотренное",
        "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
      },
      "toasts": {
        "createPilot": {
          "success": "Пилот создан",
          "error": "Не удалось создать пилот"
        }
      },
      "menuItems": [
        {
          "label": "Все пилоты",
          "value": "all"
        },
        {
          "label": "Мои отклики",
          "value": "corporates"
        },
        {
          "label": "Исходящие предложения",
          "value": "offers"
        }
      ],
      "position": 3
    }
  ]
}'::json::json, 1);