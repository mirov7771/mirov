--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-4995
update  public.pages
set page = '{
    "features": [
        {
            "type": "infoForm",
            "sysName": "registration_en_infoForm",
            "visible": true,
            "position": 1,
            "config": {},
            "titleForm": "Registration",
            "titleInfoForm": "A temporary password was send to your email",
            "textDescription": "We have sent a new temporary password to your email **{email}**. Use it, then set your own password.",
            "text": "If you don`t see an email, check the spam folder from **noreply_unity@sbermail-cloud.sber.ru**",
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_en_infoForm_button",
                "text": "Log in",
                "theme": "purple-gradient",
                "url": "/auth",
                "methodUrl": "GET",
                "visible": true
            }
        },
        {
            "type": "registrationForm",
            "sysName": "registration_en_registrationForm",
            "visible": true,
            "position": 1,
            "config": {},
            "links": [
                {
                    "text": "Already have an account? ",
                    "linkText": "Log in",
                    "linkUrl": "/auth"
                }
            ],
            "titleForm": "Registration",
            "emailField": {
                "label": "Email",
                "errorCorporationEmail": "Enter corporate e-mail",
                "helperText": "It will not be available in the public profile. You can specify the contact email address in the next step"
            },
            "button": {
                "action": "redirect",
                "category": "simple",
                "config": {},
                "default": "active",
                "iconUrl": null,
                "sysName": "registration_en_lregistrationForm_button",
                "text": "Get a password",
                "theme": "purple-gradient",
                "url": "/sberx-gateway/auth/client",
                "methodUrl": "POST",
                "visible": true
            }
        }
    ]
}'
where uri = '/registration'
  and code = 'registration_en';