--liquibase formatted sql
--changeset Mirov A:SBERXTECH-1640
update public.screen
set formedit = '{
  "form": [
    {
      "module": "Юридическая информация об организации",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "questionnaire_questionnaireid",
          "localName": "",
          "type": "int",
          "format": "hide",
          "edited": true,
          "required": true
        },{
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": true,
          "required": false,
          "direction": "row",
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "direction": "row",
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Публичное название / название бренда",
          "type": "string",
          "maxLength": 100,
          "edited": true,
          "required": true,
          "showLength": false
        },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "array",
          "format": "text",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook*",
          "type": "string",
          "edited": true,
          "required": false,
          "format": "hide"
        }
      ]
    },
    {
      "module": "Данные профиля",
      "page": 1,
      "pageName": "Юридическая информация и данные профиля",
      "fields": [
        {
          "sysName": "questionnaire_investorType",
          "localName": "Выберите тип инвестора",
          "type": "array",
          "format": "chip",
          "activity": [
            11000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего фонда",
          "note": "Например, \"Фонд и акселератор\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите свою краткую характеристику как бизнес-ангела",
          "note":"Например, \"Рассматриваю любые проекты\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_note",
          "localName": "Укажите краткое описание Вашего Family-Office",
          "note": "Например, \"Фонд семьи Безосов\"",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 150,
          "edited": true,
          "required": false
        },{
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полно описание Вашего фонда",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите свою полную характеристику как бизнес-ангела",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_fullNote",
          "localName": "Укажите полное описание Вашего Family-Office",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "maxLength": 1000,
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Опционально",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Опционально",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_email",
          "note": "Опционально",
          "localName": "Публичный адрес электронной почты",
          "type": "string",
          "format": "e-mail",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11001",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11003",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "questionnaire_logoFile",
          "title": "Логотип",
          "localName": "Загрузить логотип",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120.\nФормат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11004",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Ваши данные",
      "page": 2,
      "pageName": "Ваши данные",
      "fields": [
        {
          "sysName": "questionnaire_logoFile",
          "title": "Добавьте фото",
          "localName": "Загрузить фото",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение. Формат PNG",
          "triggerField": "questionnaire_investorType",
          "triggerValue": "11002",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        },
        {
          "sysName": "representative_fio",
          "localName": "Фамилия Имя",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_role",
          "localName": "Должность*",
          "note": "Например, \"Управляющий партнёр\"",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "representative_phone",
          "localName": "Мобильный телефон*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        },
        {
          "sysName": "representative_facebook",
          "localName": "Профиль в Facebook*",
          "type": "string",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 3,
      "pageName": "Инвестиции",
      "fields": [
        {
          "title": "Направления",
          "sysName": "investment_industry",
          "localName": "Направления",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_geography",
          "title": "География стартапов",
          "localName": "География стартапов",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Стадии инвестирования",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Данные о стартапах портфеля",
      "page": 3,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_activeDealsNumber",
          "localName": "Количество стартапов в портфеле",
          "type": "int",
          "edited": true,
          "required": true,
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_allDealsNumber",
          "localName": "Количество сделок, всего",
          "note": "Количество стартапов, в которые Вы инвестировали",
          "type": "int",
          "edited": true,
          "required": true,
          "direction": "row",
          "maxLength": 4,
          "showLength": false
        },
        {
          "sysName": "questionnaire_exitDealsNumber",
          "localName": "Количество выходов",
          "note": "Количество стартапов, в которые Вы инвестировали и вышли",
          "type": "int",
          "edited": true,
          "required": true,
          "direction": "row",
          "maxLength": 4,
          "showLength": false
        }
      ]
    },
    {
      "module": "",
      "page": 3,
      "pageName": "Инвестиции",
      "subTitle": "Стартап №",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить стартап",
      "fields": [
        {
          "sysName": "questionnairePilots[]_pilotid",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "questionnairePilots[]_company",
          "localName": "Название стартапа",
          "note": "Опционально",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "questionnairePilots[]_site",
          "localName": "Ссылка на сайт стартапа",
          "note": "Опционально",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Инвестиционные клубы",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "fields": [
        {
          "sysName": "questionnaire_club",
          "localName": "Состоите ли Вы в каком-либо инвестиционном клубе / сообществе?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Укажите название инвестиционного клуба / сообщества и свою роль",
      "page": 4,
      "pageName": "Участие в инвестиционных клубах",
      "subTitle": "Клуб / сообщество №",
      "withIndex": true,
      "isArray": "true",
      "actionText": "Добавить клуб",
      "triggerField": "questionnaire_club",
      "triggerValue": true,
      "fields": [
        {
          "sysName": "investorClubs[]_name",
          "localName": "Название клуба / сообщества*",
          "type": "string",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investorClubs[]_role",
          "localName": "Ваша роль в клубе / сообществе*",
          "note": "Например, \"Основатель клуба\"",
          "type": "string",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'
where formname = 'investor_edit';