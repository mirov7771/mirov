--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4536
update public.pages
set page = cast(replace(cast(page as text), '//file/', '/file/') as json)
where cast(page as text) like '%//file/%'