--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4360_4
update "schemas" set value = '{
  "value": {
    "clickable": true,
    "columns": [
      {
        "sysName": "company",
        "type": "img",
        "title": "Корпорация",
        "key": "questionnaireLogo",
        "refs": {
          "labelKey": "questionnaireName"
        }
      },
      {
        "sysName": "pilot",
        "type": "string",
        "title": "Название запроса",
        "key": "offerName"
      },
      {
        "sysName": "view_date",
        "type": "date",
        "title": "Дата и время предложения",
        "key": "date"
      },
      {
        "sysName": "status",
        "type": "nameplate",
        "title": "Статус",
        "key": "state",
        "refs": {
          "map": {
            "20002": "В работе",
            "20003": "Пауза",
            "20004": "Пилотируется",
            "20007": "Завершен",
            "20009": "Отказ",
            "20011": "Новый",
            "20013": "Отозван"
          }
        }
      }
    ]
  }
}'
where name = 'offer_search_startup';