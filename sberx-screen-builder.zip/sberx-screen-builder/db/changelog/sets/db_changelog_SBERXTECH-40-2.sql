--liquibase formatted sql
--changeset Rakhimova NV:SBERXTECH-40-2
DELETE FROM screen
WHERE formname in ('investor_preauth', 'corporate_preauth' );



INSERT INTO screen
(id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription)
VALUES((select max (id)+1 from screen), '111260', 2, 'investor_preauth', '{}', '{"form":[{"module":"","page":1,"fields":[{"sysName":"Project_Note","localName":"","type":"string","edited":false,"required":false},{"sysName":"questionnaire_investortype","localName":"Тип инвестора","type":"array","format":"chip","activity":[11000],"edited":false,"required":false,"direction":"row"},{"sysName":"questionnaire_round","localName":"Стадии инвестирования","type":"array","format":"chip","activity":[6000],"edited":false,"required":false,"direction":"row"},{"sysName":"questionnaire_industry","localName":"Направления","type":"array","format":"chip","activity":[3000],"edited":false,"required":false}]}]}', 'Карточка инвестора в неавторизованной зоне', '', NULL, '{"buttons":[{"icon":"","type":"active","text":"Присоединиться","action":"/auth","variant":"primary","description":""}]}', '', '', '');
INSERT INTO screen
(id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription)
VALUES((select max (id)+1 from screen), '111260', 1, 'corporate_preauth', '{}', '{"form":[{"module":"","page":1,"fields":[{"sysName":"Project_Note","localName":"","type":"string","edited":false,"required":false},{"sysName":"questionnaire_site","localName":"","type":"hyperlink","edited":false,"required":false},{"sysName":"questionnaire_innovationmethod","localName":"Метод работы с инновациями","type":"array","format":"chip","activity":[4000],"edited":false,"required":false}]}]}', 'Карточка корпорации в неавторизованной зоне', '', 1, '{"buttons":[{"icon":"","type":"active","text":"Присоединиться","action":"/auth","variant":"primary","description":""}]}', '', '', '');


INSERT INTO screen
(id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription)
VALUES((select max (id)+1 from screen), '8385', 2, 'investor_preauth', '{}', '{"form":[{"module":"","page":1,"fields":[{"sysName":"Project_Note","localName":"","type":"string","edited":false,"required":false},{"sysName":"questionnaire_investortype","localName":"Тип инвестора","type":"array","format":"chip","activity":[11000],"edited":false,"required":false,"direction":"row"},{"sysName":"questionnaire_round","localName":"Стадии инвестирования","type":"array","format":"chip","activity":[6000],"edited":false,"required":false,"direction":"row"},{"sysName":"questionnaire_industry","localName":"Направления","type":"array","format":"chip","activity":[3000],"edited":false,"required":false}]}]}', 'Карточка инвестора в неавторизованной зоне', '', NULL, '{"buttons":[{"icon":"","type":"active","text":"Присоединиться","action":"/auth","variant":"primary","description":""}]}', '', '', '');
INSERT INTO screen
(id, clientid, "type", formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription)
VALUES((select max (id)+1 from screen), '8385', 1, 'corporate_preauth', '{}', '{"form":[{"module":"","page":1,"fields":[{"sysName":"Project_Note","localName":"","type":"string","edited":false,"required":false},{"sysName":"questionnaire_site","localName":"","type":"hyperlink","edited":false,"required":false},{"sysName":"questionnaire_innovationmethod","localName":"Метод работы с инновациями","type":"array","format":"chip","activity":[4000],"edited":false,"required":false}]}]}', 'Карточка корпорации в неавторизованной зоне', '', 1, '{"buttons":[{"icon":"","type":"active","text":"Присоединиться","action":"/auth","variant":"primary","description":""}]}', '', '', '');
