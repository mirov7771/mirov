--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5299
update pages
set page = '{
  "features": [
    {
      "type": "authPilotSearch",
      "sysName": "authPilotSearch",
      "visible": true,
      "header": "Мои запросы",
      "position": 1,
      "buttons": {
        "createPilot": "Создать пилот"
      },
      "emptyLabel": {
        "offers": "Вы пока не предлагали пилоты корпорациям.",
        "myReplies": "Вы пока не откликались на запросы корпораций.",
        "common": "Создайте пилот, чтобы получать отклики от стартапов"
      },
      "menuItems": [
        {
          "label": "Активные",
          "value": "all"
        },
        {
          "label": "Архивные",
          "value": "archive"
        }
      ],
      "modalTexts": {
        "buttons": {
          "confirm": "Создать пилот",
          "cancel": "Отменить"
        }
      }
    }
  ]
}'
where uri = '/auth-pilots-corporate'
