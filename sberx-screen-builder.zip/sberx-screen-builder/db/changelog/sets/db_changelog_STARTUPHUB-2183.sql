--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2183
update public.screen
set formedit = '{
  "form": [
    {
      "module": "Заявка на выполнение пилота",
      "page": 1,
      "isArray": "true",
      "moduleType": "question",
      "fields": [
        {
          "sysName": "response",
          "localName": "Ваш вопрос",
          "type": "string",
          "format": "question",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "reply_note",
          "localName": "Сопроводительное письмо",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "512"
        },
        {
          "sysName": "pilotId",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_tableName",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "Pilot"
        },
        {
          "sysName": "reply_state",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "0"
        },
        {
          "sysName": "reply_fileURL",
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "format": "URL",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'
where formname like '%Extra%';

update public.screen
set buttons = '{"buttons": [{
  "type": "archive",
  "code": 20009,
  "action": "/reply",
  "method": "POST",
  "variant": "disabled",
  "text": "Отправить заявку",
  "enabled": false,
  "description": "Дождитесь проверки анкеты стартапа, чтобы участвовать в пилотах"
}]}'
where formname in ('pilot_Client', 'pilot_SuperClient');
