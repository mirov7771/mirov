--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3407
update public.screen set formedit = cast(replace(cast(formedit as text), 'sysName": ""', 'sysName": "empty_field"') as json)
where cast(formedit as text) like '%sysName": ""%'
