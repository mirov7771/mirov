--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4439
delete from public.buttons where code = 20015;
insert into public.buttons (code,text) values (20015, 'Выполнена');

delete from public.screen_button where name = 'scouting_edit';
insert into public.screen_button (name, state) values ('scouting_edit', 20002);
insert into public.screen_button (name, state) values ('scouting_edit', 20012);

insert into public.screen_buttons_link (screen_id , button_id)
values ((select screen_id from screen_button where name = 'scouting_edit' and state = 20002 limit 1), (select button_id from public.buttons where code = 20012 limit 1));

insert into public.screen_buttons_link (screen_id , button_id)
values ((select screen_id from screen_button where name = 'scouting_edit' and state = 20012 limit 1), (select button_id from public.buttons where code = 20009 limit 1));

insert into public.screen_buttons_link (screen_id , button_id)
values ((select screen_id from screen_button where name = 'scouting_edit' and state = 20012 limit 1), (select button_id from public.buttons where code = 20015 limit 1));