--liquibase formatted sql
--changeset Timofeev V:STARTUPHUB-4668 Заведение JSON по метрикам

delete from public.screen where formname in ('edit_metric','add_metric_values','delete_metric','add_metric');

INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'edit_metric','{
  "form":
  [
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные значения метрики в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "sysName": "items_date"
        }
      ]
    }
  ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'add_metric_values','{
  "form":
  [
    {
      "page": 1,
      "module": "Добавление значений",
      "moduleNote": "Укажите известные значения метрики Annual Recurring Revenue в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "sysName": "items_date"
        }
      ]
    }
  ]
}',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'delete_metric','{}','{}','Удалить метрику?','После удаления все значения метрики Annual Recurring Revenue будут удалены без возможности восстановления.',1,NULL,NULL,NULL,NULL,1,NULL);
INSERT INTO public.screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'add_metric','{
  "form":
  [
    {
      "page": 1,
      "fields":
      [
        {
          "localName": "Тип метрики",
          "example": "Выберите тип",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "search_dropdown",
          "sysName": "type",
          "multySelect": false
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "dropdown",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggeredField": "type",
          "triggeredValue": "1,2,3"
        }

      ]
    },
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
      "isArray": "true",
      "actionText": "Добавить значение",
      "fields":
      [
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "sysName": "items_date"
        }
      ]
    }
  ]
}',NULL,'Добавление метрики',NULL,1,NULL,NULL,NULL,NULL,1,NULL);