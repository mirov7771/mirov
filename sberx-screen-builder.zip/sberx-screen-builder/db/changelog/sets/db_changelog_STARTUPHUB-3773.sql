--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-3773 убираем заглавные "Вы"

UPDATE screen
SET    formedit =
           REPLACE(formedit::text, ' Вы', ' вы')::jsonb;

UPDATE screen
SET    formedit =
           REPLACE(formedit::text, ' Ва', ' ва')::jsonb;

UPDATE screen
SET    formview =
           REPLACE(formview::text, ' Вы', ' вы')::jsonb;

UPDATE screen
SET    formview =
           REPLACE(formview::text, ' Ва', ' ва')::jsonb;

UPDATE "values"
SET    value =
           REPLACE(value, ' Ва', ' ва');

