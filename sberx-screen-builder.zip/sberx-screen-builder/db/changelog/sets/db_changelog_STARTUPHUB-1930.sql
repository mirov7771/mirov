--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1930 Обновление анкеты на редактирование и заведение

UPDATE public.screen SET  formedit='{
  "form": [
    {
      "module": "Условия соглашения",
      "page": 1,
      "pageName": "Юридическая информация",
      "fields": [
        {
          "sysName": "userConsent_consent",
          "localName": "Подтверждаю своё согласие с обработкой персональных данных на условиях <a href=\"policyURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Политики конфиденциальности.</a>",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        },
        {
          "sysName": "userConsent_contract",
          "localName": "Подтверждаю, что я ознакомился с <a href=\"termsURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">Пользовательским соглашением</a> и принимаю его условия без оговорок и ограничений.",
          "type": "boolean",
          "format": "checkbox",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": true,
          "required": true,
          "direction": "row",
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "mask": "2000;getyear",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "direction": "row",
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Фирменное наименование (Товарный знак)",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО|ПАО|ЗАО|ООО|ИП|АО).)*$",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },{
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "note": "Название на другом языке (англ/рус)",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },{
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
           "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
       },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо*",
          "note": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "note":"Почта сотрудника, с которым можно связаться",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Опционально. Укажите ссылки на внешние ресурсы",
      "isArray": "true",
      "actionText": "Добавить ресурс",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },{
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "title": "Где базируется ваш проект?",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true

        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": true,
          "required": true,

          "maxLength": 30,
          "showLength": false
        },
        {
          "sysName": "project_industry",
          "localName": "Индустии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "maxLength": "200",
          "note": "Опишите Ваш проект одним предложением",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
    {
      "module": "Стадия развития продукта",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27002,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "triggerValue": 27002,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27003,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "triggerValue": 27003,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "title": "Презентация",
          "description": "Не обязательно загружать, но повышает шансы заинтересовать инвесторов и корпорации",
          "type": "hyperlink",
          "format": "URL",
          "note": "Принимаем файлы до 50 Мб. Формат — PDF",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },{
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "string",
          "maxLength": "255",
          "edited": true,
          "required": false,
          "showLength": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_expansion",
          "localName": "Регионы, в которые планируете выходить в ближайшем будущем",
          "note":"Регионы, в которые планируете выходить в ближайшем будущем",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в месяц и оборот в год",
          "type": "string",
          "maxLength": "300",
          "note": "Опционально. Если у вас пока нет оборота, то напишите, сколько есть первых клиентов, было ли проведено исследование Customer Development и с каким количеством пользователей",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 4,
      "pageName": "Конкуренты",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },{
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 5,
      "pageName": "Команда",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "format": "[1;1000]",
          "minValue": 1,
          "maxValue": 1000,
          "edited": true,
          "required": false,
          "direction": "row"
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "format": "[0;1000]",
          "minValue": 0,
          "maxValue": 1000,
          "edited": true,
          "required": false,
          "direction": "row"
        }
      ]
    },
    {
      "module": "",
      "page": 5,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые роли / должности в стартапе закрыты",
      "actionText": "Добавить роль",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "Если вы В2В-, В2G-, B2B2C-, В2О- стартап: у вас есть успешные пилоты / внедрения?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "moduleNote": "Опционально. Укажите, с кем у вас были успешные пилоты / внедрения, и опишите их суть и результаты, но только если раскрытие этой информации не противоречит договоренностям с корпорацией и пр. Эту информацию увидят другие пользователи SberUnity",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilotsB2C",
          "localName": "Если вы B2C-, C2C- стартап: у вас есть первые продажи на реальных клиентах (не FFF)?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование",
      "triggerField": "questionnaire_successPilotsB2C",
      "triggerValue": "true",
      "moduleNote": "",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 6,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "note": "Если у Вас уже есть идеи, как можно пилотировать Ваш продукт, опишите их в 1-2 предложениях",
          "type": "string",
          "maxLength": "300",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "maxLength": "120",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 7,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Заинтересованы ли вы сейчас в привлечении инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций (USD)",
          "type": "int",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите объем ранее привлеченных инвестиций",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Укажите, выпускником каких акселераторов Сбера вы являетесь",
          "type": "array",
          "format": "dropdown",
          "activity": [
            26000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщества",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществе СберСтартап?*",
          "note": "и получать советы экспертов, разбирать кейсы фаундеров стартапов, узнавать первым новости венчурного рынка и иметь доступ к стартап-вакансиям?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 8,
      "pageName": "Дополнительная информация",
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'::json::json WHERE formname='New_StartUp';


UPDATE public.screen SET  formedit='{
  "form": [

    {
      "module": "Организация",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_fullName",
          "localName": "Наименование организации",
          "type": "string",
          "edited": true,
          "required": false,
          "direction": "row",
          "maxLength": 70,
          "showLength": false
        },
        {
          "sysName": "questionnaire_birthYear",
          "localName": "Год регистрации",
          "type": "int",
          "format": "year",
          "mask": "year:[2000]",
          "maxLength": 4,
          "edited": true,
          "required": true,
          "direction": "row",
          "showLength": false
        },
        {
          "sysName": "questionnaire_name",
          "localName": "Фирменное наименование (Товарный знак)",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": 70,
          "showLength": false,
          "regExp": "^((?!ОАО|ПАО|ЗАО|ООО|ИП|АО).)*$",
          "regExpError": "Введите краткое название без организационно-правовой формы"
        },{
          "sysName": "questionnaire_transcription",
          "localName": "Транскрипция",
          "note": "Название на другом языке (англ/рус)",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": 70,
          "showLength": false
        },{
          "sysName": "questionnaire_site",
          "localName": "Сайт",
          "type": "string",
           "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "edited": true,
          "required": true
       },
        {
          "sysName": "questionnaire_registrationCountry",
          "localName": "Страна юрисдикции*",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "edited": true,
          "required": true,
          "multySelect": false
        },
        {
          "sysName": "questionnaire_inviteFio",
          "localName": "Контактное лицо*",
          "note": "Имя сотрудника, с которым можно связаться",
          "type": "string",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_email",
          "localName": "Электронная почта",
          "note": "Почта сотрудника, с которым можно связаться",
          "type": "string",
          "format": "e-mail",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_phoneNumber",
          "localName": "Номер телефона*",
          "type": "string",
          "format": "phone",
          "edited": true,
          "required": true,
          "mask": "phone"
        }
      ]
    },
    {
      "module": "Дополнительные контакты",
      "page": 1,
      "pageName": "Юридическая информация",
      "moduleNote": "Опционально. Укажите ссылки на внешние ресурсы",
      "isArray": "true",
      "actionText": "Добавить ресурс",
      "fields": [
        {
          "sysName": "contacts[]_type",
          "localName": "",
          "title": "Ресурс",
          "type": "array",
          "format": "chip",
          "activity": [
            21000
          ],
          "edited": true,
          "required": false,
          "multySelect": false
        },
        {
          "sysName": "contacts[]_name",
          "localName": "Ссылка",
          "type": "string",
          "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "maxLength": "70",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_interactionType",
          "localName": "Бизнес-модели взаимодействия с пользователями",
          "type": "array",
          "format": "chip",
          "activity": [
            8000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },{
          "sysName": "questionnaire_businessModel",
          "localName": "Бизнес-модели",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            24000
          ],
          "edited": true,
          "required": true,
          "multySelect": true,
          "values": []
        },
        {
          "sysName": "questionnaire_locationCountry",
          "localName": "Страна",
          "title": "Где базируется ваш проект?",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": false,
          "edited": true,
          "required": true

        },
        {
          "sysName": "questionnaire_location",
          "localName": "Город",
          "type": "string",
          "edited": true,
          "required": true,

          "maxLength": 30,
          "showLength": false
        },
        {
          "sysName": "project_industry",
          "localName": "Индустрии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            3000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
         {
          "sysName": "project_technology",
          "localName": "Технологии",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            13000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_note",
          "localName": "Краткое описание проекта",
          "type": "string",
          "maxLength": "200",
          "note": "Опишите Ваш проект одним предложением",
          "edited": true,
          "required": true
        },
        {
          "sysName": "questionnaire_logoFile",
          "localName": "Загрузить логотип",
          "title": "Логотип компании",
          "type": "logo",
          "note": "Рекомендуем загружать квадратное изображение разрешением 120x120. Формат PNG",
          "edited": true,
          "required": false,
          "allowedTypes": [
            ".png"
          ]
        }
      ]
    },
     {
      "module": "Стадия развития продукта",
      "page": 2,
      "pageName": "Информация о проекте 1/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_mvpCode",
          "localName": "Стадия развития продукта",
          "type": "array",
          "format": "dropdown",
          "activity": [
            27000
          ],
          "multySelect": false,
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27002,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27003,
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27004,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerField": "project_mvpCode",
          "triggerValue": 27004,
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27005,
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoSite",
          "localName": "URL ссылка на демо",
          "type": "string",
          "maxLength": "100",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "note": "Это не обязательное поле. Демо должно показывать, как работает продукт. Обычно это видео или запись экрана",
          "edited": true,
          "required": false,
          "showLength": false
        },{
          "sysName": "project_demoVideo",
          "localName": "Видео о продукте",
          "type": "string",
          "maxLength": "255",
          "triggerField": "project_mvpCode",
                    "regExp" : "((https|http?):\\/\\/)?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru",
          "triggerValue": 27006,
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "О проекте",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_problem",
          "localName": "Проблема, которую решает проект",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_auditory",
          "localName": "Целевая аудитория",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_businessPlan",
          "localName": "Загрузить презентацию",
          "title": "Презентация",
          "description": "Не обязательно загружать, но повышает шансы заинтересовать инвесторов и корпорации",
          "type": "hyperlink",
          "format": "URL",
          "note": "Принимаем файлы до 50 Мб. Формат — PDF",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        },{
          "sysName": "project_pitchVideo",
          "localName": "Видео питча",
          "type": "string",
          "maxLength": "255",
          "edited": true,
          "required": false,
          "showLength": false

        }
      ]
    },
    {
      "module": "Рынок",
      "page": 3,
      "pageName": "Информация о проекте 2/2",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_geography",
          "localName": "Рынки, на которых вы работаете",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },{
          "sysName": "project_expansion",
          "localName": "Рынки, на которые собираетесь выходить в ближайшее время",
          "note": "Регионы, в которые планируете выходить в ближайшем будущем",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            2000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        },
        {
          "sysName": "project_sales",
          "localName": "Продажи",
          "type": "array",
          "format": "search_dropdown",
          "activity": [
            5000
          ],
          "multySelect": true,
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_turnover",
          "localName": "Оборот в месяц и оборот в год",
          "type": "string",
          "maxLength": "300",
          "note": "Опционально. Если у вас пока нет оборота, то напишите, сколько есть первых клиентов, было ли проведено исследование Customer Development и с каким количеством пользователей",
          "edited": true,
          "required": false,
          "showLength": false
        }
      ]
    },
    {
      "module": "Конкуренты",
      "page": 4,
      "pageName": "Конкуренты",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_competitor",
          "localName": "Прямые конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },{
          "sysName": "project_indirectCompetitor",
          "localName": "Косвенные конкуренты",
          "type": "string",
          "maxLength": "300",
          "note": "Перечислите 2-3 конкурентов",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_upSide",
          "localName": "Преимущества перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": true
        },
        {
          "sysName": "project_downSide",
          "localName": "Недостатки перед конкурентами",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Команда",
      "page": 5,
      "pageName": "Команда",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "project_staff",
          "localName": "Количество сотрудников",
          "type": "int",
          "minValue": 1,
          "maxValue": 1000,
          "format": "[1;1000]",
          "edited": true,
          "required": false,
          "direction": "row"
        },
        {
          "sysName": "project_hiringStaff",
          "localName": "Из них наемных сотрудников",
          "type": "int",
          "minValue": 0,
          "maxValue": 1000,
          "format": "[0;1000]",
          "edited": true,
          "required": false,
          "direction": "row"
        }
      ]
    },
    {
      "module": "",
      "page": 5,
      "pageName": "Команда",
      "isArray": "true",
      "title": "Укажите, какие ключевые роли / должности в стартапе закрыты",
      "actionText": "Добавить роль",
      "fields": [
        {
          "sysName": "workers[]_parentId",
          "localName": "",
          "type": "long",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "workers[]_isFounder",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "value": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "workers[]_role",
          "localName": "Роль сотрудника в команде",
          "type": "string",
          "maxLength": "100",
          "edited": true,
          "required": false
        },{
          "sysName": "workers[]_note",
          "localName": "Краткое описание опыта",
          "type": "string",
          "maxLength": "150",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Успешные пилоты",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilots",
          "localName": "Если вы В2В-, В2G-, B2B2C-, В2О- стартап: у вас есть успешные пилоты / внедрения?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Успешные кейсы",
      "moduleNote": "Опционально. Укажите, с кем у вас были успешные пилоты / внедрения, и опишите их суть и результаты, но только если раскрытие этой информации не противоречит договоренностям с корпорацией и пр. Эту информацию увидят другие пользователи SberUnity",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "triggerField": "questionnaire_successPilots",
      "triggerValue": "true",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2bPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2bPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование, первые продажи и внедрения",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "questionnaire_successPilotsB2C",
          "localName": "Если вы B2C-, C2C- стартап: у вас есть первые продажи на реальных клиентах (не FFF)?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "",
      "page": 6,
      "pageName": "Пилотирование",
      "triggerField": "questionnaire_successPilotsB2C",
      "triggerValue": "true",
      "moduleNote": "",
      "isArray": "true",
      "actionText": "Добавить кейс",
      "fields": [
        {
          "sysName": "b2cPilots[]_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "value": "20007",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_reference",
          "localName": "С кем был успешный кейс",
          "type": "string",
          "maxLength": "140",
          "edited": true,
          "required": false
        },
        {
          "sysName": "b2cPilots[]_suggestCase",
          "localName": "Описание и результаты кейса",
          "type": "string",
          "note": "Опишите в 1–2 предложениях",
          "maxLength": "200",
          "triggerField": "questionnaire_successPilotsB2C",
          "triggerValue": "true",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Экосистема Сбера",
      "page": 6,
      "pageName": "Пилотирование",
      "fields": [
        {
          "sysName": "questionnaire_pilot",
          "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "ecoPilot_state",
          "localName": "",
          "type": "array",
          "format": "hide",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": "20008",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_suggestCase",
          "localName": "Предлагаемый кейс*",
          "note": "Если у Вас уже есть идеи, как можно пилотировать Ваш продукт, опишите их в 1-2 предложениях",
          "type": "string",
          "maxLength": "300",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_experience",
          "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
          "type": "boolean",
          "format": "switch",
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "ecoPilot_businessUnit",
          "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
          "type": "string",
          "maxLength": "120",
          "triggerField": "ecoPilot_experience",
          "triggerValue": "true",
          "edited": true,
          "required": false,
          "showLength": false
        },
        {
          "sysName": "ecoPilot_ecoSystem",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        },
        {
          "sysName": "ecoPilot_pilot",
          "localName": "",
          "type": "string",
          "maxLength": "120",
          "edited": true,
          "format": "hide",
          "required": false,
          "triggerField": "questionnaire_pilot",
          "triggerValue": "true",
          "value": true
        }
      ]
    },
    {
      "module": "Инвестиции",
      "page": 7,
      "pageName": "Инвестиции",
      "moduleNote": "",
      "fields": [
        {
          "sysName": "investment_investment",
          "localName": "Заинтересованы ли вы сейчас в привлечении инвестиций?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        },
        {
          "sysName": "investment_round",
          "localName": "Раунд инвестиций",
          "type": "array",
          "format": "chip",
          "activity": [
            6000
          ],
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "multySelect": false,
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_sumInvestment",
          "localName": "Требуемая сумма инвестиций (USD)",
          "type": "int",
          "minValue": 0,
          "maxValue": 2000000000,
          "format": "[0;10000000000000]",
          "triggerField": "investment_investment",
          "triggerValue": "true",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_lastInvestment",
          "localName": "Объем ранее привлеченных инвестиций, всего (USD)",
          "type": "string",
          "maxLength": "300",
          "note": "Укажите объем ранее привлеченных инвестиций",
          "edited": true,
          "required": false
        },
        {
          "sysName": "investment_coInvestment",
          "localName": "Имя/ имена инвестора/ инвесторов",
          "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
          "type": "string",
          "maxLength": "300",
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Акселераторы Сбера",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_acceleratorCode",
          "localName": "Укажите, выпускником каких акселераторов Сбера вы являетесь",
          "type": "array",
          "format": "dropdown",
          "activity": [
            26000
          ],
          "multySelect": true,
          "edited": true,
          "required": false
        }
      ]
    },
    {
      "module": "Сообщества",
      "page": 7,
      "pageName": "Инвестиции",
      "fields": [
        {
          "sysName": "questionnaire_community",
          "localName": "Хотите участвовать в сообществе СберСтартап?*",
          "note": "и получать советы экспертов, разбирать кейсы фаундеров стартапов, узнавать первым новости венчурного рынка и иметь доступ к стартап-вакансиям?",
          "type": "boolean",
          "format": "switch",
          "edited": true,
          "required": true
        }
      ]
    },
    {
      "module": "Дополнительная информация",
      "page": 8,
      "pageName": "Дополнительная информация",
      "fields": [
        {
          "sysName": "project_addNote",
          "localName": "Что еще важно знать о проекте?",
          "type": "string",
          "maxLength": "500",
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'::json::json WHERE formname='startup_edit';



