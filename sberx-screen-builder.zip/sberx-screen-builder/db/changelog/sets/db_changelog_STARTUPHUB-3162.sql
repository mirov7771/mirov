--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3162
drop index if exists x2_screen_buttons_link;
create index x2_screen_buttons_link on screen_buttons_link(screen_id);