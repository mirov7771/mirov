--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3775
UPDATE screen
SET formedit='{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "note": "Укажите полное юридическое название вашей компании",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Наименование организации",
          "maxLength": 70,
          "showLength": false
        },
        {
          "note": "Укажите год создания вашей компании",
          "type": "int",
          "edited": true,
          "format": "[1991;2021]",
          "sysName": "questionnaire_birthYear",
          "required": true,
          "localName": "Год регистрации",
          "maxLength": 4,
          "showLength": false
        },
        {
          "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_name",
          "required": true,
          "localName": "Публичное название",
          "maxLength": 100,
          "showLength": false
        },
        {
          "note": "Выберите страну, в которой зарегистрирована ваша компания",
          "type": "array",
          "edited": true,
          "format": "text",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "Страна юрисдикции",
          "multySelect": false
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты"
        },
        {
          "note": "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "sysName": "questionnaire_site",
          "required": true,
          "localName": "Сайт корпорации",
          "maxLength": "100",
          "showLength": false,
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
        }
      ],
      "module": "Юридическая информация об организации",
      "pageName": "Юридическая информация об организации",
      "moduleNote": ""
    },
    {
      "page": 2,
      "fields": [
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_fio",
          "required": true,
          "localName": "Имя, фамилия представителя"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_role",
          "required": true,
          "localName": "Должность"
        },
        {
          "mask": "phone",
          "type": "string",
          "edited": true,
          "format": "phone",
          "example": "+",
          "sysName": "representative_phone",
          "required": true,
          "localName": "Мобильный телефон"
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "representative_email",
          "required": true,
          "localName": "Электронная почта"
        }
      ],
      "module": "Контакт представителя",
      "pageName": "Информация о представителе",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
    },
    {
      "page": 2,
      "title": "",
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "boolean",
          "value": false,
          "edited": true,
          "format": "hide",
          "sysName": "workers[]_isFounder",
          "required": false,
          "localName": ""
        },
        {
          "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_fio",
          "required": false,
          "localName": "Имя, фамилия представителя",
          "maxLength": "100",
          "showLength": false
        },
        {
          "note": "Укажите должность ответственного лица из предыдущего вопроса",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Должность",
          "maxLength": "100",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "workers[]_facebook",
          "required": false,
          "localName": "Электронная почта",
          "maxLength": "150",
          "showLength": false
        }
      ],
      "module": "Публичный контакт",
      "isArray": "true",
      "pageName": "Информация о представителе",
      "actionText": "Добавить контактное лицо"
    },
    {
      "page": 3,
      "fields": [
        {
          "note": "Опишите вашу компанию одним предложением",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_note",
          "required": true,
          "localName": "Краткое описание",
          "maxLength": "150"
        },
        {
          "note": "Опишите вашу компанию более подробно",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullNote",
          "required": true,
          "localName": "Полное описание",
          "maxLength": "480"
        },
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_industry",
          "activity": [
            22000
          ],
          "required": true,
          "localName": "Направление деятельности",
          "description": "Укажите все релевантные вашей компании отрасли",
          "multySelect": true
        },
        {
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200. Формат PNG",
          "type": "logo",
          "title": "Логотип",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png"
          ]
        }
      ],
      "module": "Корпорация",
      "pageName": "Информация о корпорации"
    },
    {
      "page": 4,
      "fields": [
        {
          "type": "array",
          "title": "Методы работы с инновациями",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_innovationMethod",
          "activity": [
            4000
          ],
          "required": true,
          "localName": "Укажите методы",
          "description": "Выберите методы внедрения инноваций в вашей корпорации",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "Стадии развития стартапов",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_stady",
          "activity": [
            7000
          ],
          "required": true,
          "localName": "Стадия развития",
          "description": "Выберите интересующие стадии развития стартапов",
          "multySelect": true
        },
        {
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": true,
          "localName": "Технологии",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": true,
          "localName": "Индустрии",
          "description": "Укажите все релевантные вашей компании направления",
          "multySelect": true
        }
      ],
      "module": "Работа со стартапами",
      "pageName": "Условия работы со стартапами"
    },
    {
      "page": 5,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_successPilots",
          "required": true,
          "localName": "У вашей компании есть опыт сотрудничества со стартапами?"
        },
        {
          "note": "Опционально",
          "type": "int",
          "title": "Информация о сотрудничестве со стартапами",
          "edited": true,
          "sysName": "questionnaire_startupInvestmentYears",
          "required": false,
          "localName": "Сколько лет ваша корпорация работает со стартапами",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_overallPilots",
          "required": false,
          "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_lastYearInvestmentsCount",
          "required": false,
          "localName": "Количество пилотов со стартапами за последний год",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_overallContracts",
          "required": false,
          "localName": "Количество контрактов (внедрений) со стартапами за последний год",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        }
      ],
      "module": "Успешные кейсы",
      "pageName": "Пилотирование"
    },
    {
      "page": 6,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "investment_investment",
          "required": true,
          "localName": "Инвестирует ли ваша корпорация в стартапы?"
        },
        {
          "type": "array",
          "edited": true,
          "format": "chip",
          "sysName": "investment_round",
          "activity": [
            6000
          ],
          "required": true,
          "localName": "Раунд инвестиций",
          "multySelect": true,
          "triggerField": "investment_investment",
          "triggerValue": "true"
        },
        {
          "note": "В стартапы из каких регионов вы готовы инвестировать",
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "География стартапов",
          "multySelect": true,
          "triggerField": "investment_investment",
          "triggerValue": "true"
        }
      ],
      "module": "Инвестиции",
      "pageName": "Инвестиции"
    },
    {
      "page": 6,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "successPilots[]_pilotid",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "successPilots[]_company",
          "required": false,
          "localName": "Название стартапа",
          "maxLength": "140",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "successPilots[]_suggestCase",
          "required": false,
          "localName": "Описание кейса",
          "maxLength": "300",
          "showLength": false
        }
      ],
      "module": "Успешные кейсы",
      "isArray": true,
      "pageName": "Инвестиции",
      "subTitle": "Стартап №",
      "withIndex": true,
      "actionText": "Добавить кейс",
      "moduleNote": "Опционально. Укажите названия стартапов, с которыми у вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
      "triggerField": "investment_investment",
      "triggerValue": true
    },
    {
      "page": 7,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_scouting",
          "required": true,
          "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?"
        }
      ],
      "module": "Скаутинг",
      "pageName": "Скаутинг"
    }
  ]
}'
WHERE formname='New_Corporate';


UPDATE screen
SET formedit='{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "note": "Укажите полное юридическое название вашей компании",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullName",
          "required": false,
          "localName": "Наименование организации",
          "maxLength": 70,
          "showLength": false
        },
        {
          "note": "Укажите год создания вашей компании",
          "type": "int",
          "edited": true,
          "format": "[1991;2021]",
          "sysName": "questionnaire_birthYear",
          "required": true,
          "localName": "Год регистрации",
          "maxLength": 4,
          "showLength": false
        },
        {
          "note": "Укажите, под каким именем отображать вашу анкету для других участников платформы",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_name",
          "required": true,
          "localName": "Публичное название",
          "maxLength": 100,
          "showLength": false
        },
        {
          "note": "Выберите страну, в которой зарегистрирована ваша компания",
          "type": "array",
          "edited": true,
          "format": "text",
          "sysName": "questionnaire_registrationCountry",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "Страна юрисдикции",
          "multySelect": false
        },
        {
          "note": "Эта почта будет видна другим участниками платформы",
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "questionnaire_email",
          "required": true,
          "localName": "Публичный адрес электронной почты"
        },
        {
          "note": "Рекомендуем указать ссылку не на основной сайт компании, а на страницу, максимально релевантную стартапам (например, лендинг акселератора)",
          "type": "string",
          "edited": true,
          "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
          "sysName": "questionnaire_site",
          "required": true,
          "localName": "Сайт корпорации",
          "maxLength": "100",
          "showLength": false,
          "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
        }
      ],
      "module": "Юридическая информация об организации",
      "pageName": "Юридическая информация об организации",
      "moduleNote": ""
    },
    {
      "page": 2,
      "fields": [
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_fio",
          "required": true,
          "localName": "Имя, фамилия представителя"
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "representative_role",
          "required": true,
          "localName": "Должность"
        },
        {
          "mask": "phone",
          "type": "string",
          "edited": true,
          "format": "phone",
          "example": "+",
          "sysName": "representative_phone",
          "required": true,
          "localName": "Мобильный телефон"
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "representative_email",
          "required": true,
          "localName": "Электронная почта"
        }
      ],
      "module": "Контакт представителя",
      "pageName": "Информация о представителе",
      "moduleNote": "Укажите сотрудника, с кем администраторы SberUnity могут связаться по вопросам размещения вашей анкеты"
    },
    {
      "page": 2,
      "title": "",
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "workers[]_parentId",
          "required": false,
          "localName": ""
        },
        {
          "type": "boolean",
          "value": false,
          "edited": true,
          "format": "hide",
          "sysName": "workers[]_isFounder",
          "required": false,
          "localName": ""
        },
        {
          "note": " Стартапам важно видеть персоналии. Укажите ответственное лицо корпорации, которое увидят другие участники платформы",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_fio",
          "required": false,
          "localName": "Имя, фамилия представителя",
          "maxLength": "100",
          "showLength": false
        },
        {
          "note": "Укажите должность ответственного лица из предыдущего вопроса",
          "type": "string",
          "edited": true,
          "sysName": "workers[]_role",
          "required": false,
          "localName": "Должность",
          "maxLength": "100",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "format": "e-mail",
          "sysName": "workers[]_facebook",
          "required": false,
          "localName": "Электронная почта",
          "maxLength": "150",
          "showLength": false
        }
      ],
      "module": "Публичный контакт",
      "isArray": "true",
      "pageName": "Информация о представителе",
      "actionText": "Добавить контактное лицо"
    },
    {
      "page": 3,
      "fields": [
        {
          "note": "Опишите вашу компанию одним предложением",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_note",
          "required": true,
          "localName": "Краткое описание",
          "maxLength": "150"
        },
        {
          "note": "Опишите вашу компанию более подробно",
          "type": "string",
          "edited": true,
          "sysName": "questionnaire_fullNote",
          "required": true,
          "localName": "Полное описание",
          "maxLength": "480"
        },
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_industry",
          "activity": [
            22000
          ],
          "required": true,
          "localName": "Направление деятельности",
          "description": "Укажите все релевантные вашей компании отрасли",
          "multySelect": true
        },
        {
          "note": "Рекомендуем загружать квадратное изображение разрешением 1200x1200. Формат PNG",
          "type": "logo",
          "title": "Логотип",
          "edited": true,
          "format": "1200*1200",
          "sysName": "questionnaire_logoFile",
          "required": false,
          "localName": "Загрузить логотип",
          "maxLength": "5",
          "description": "Мы сделали поле обязательным, чтобы повысить качество базы участников",
          "allowedTypes": [
            ".png"
          ]
        }
      ],
      "module": "Корпорация",
      "pageName": "Информация о корпорации"
    },
    {
      "page": 4,
      "fields": [
        {
          "type": "array",
          "title": "Методы работы с инновациями",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_innovationMethod",
          "activity": [
            4000
          ],
          "required": true,
          "localName": "Укажите методы",
          "description": "Выберите методы внедрения инноваций в вашей корпорации",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "Стадии развития стартапов",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "questionnaire_stady",
          "activity": [
            7000
          ],
          "required": true,
          "localName": "Стадия развития",
          "description": "Выберите интересующие стадии развития стартапов",
          "multySelect": true
        },
        {
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": true,
          "localName": "Технологии",
          "multySelect": true
        },
        {
          "type": "array",
          "title": "Направления",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": true,
          "localName": "Индустрии",
          "description": "Укажите все релевантные вашей компании направления",
          "multySelect": true
        }
      ],
      "module": "Работа со стартапами",
      "pageName": "Условия работы со стартапами"
    },
    {
      "page": 5,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_successPilots",
          "required": true,
          "localName": "У вашей компании есть опыт сотрудничества со стартапами?"
        },
        {
          "note": "Опционально",
          "type": "int",
          "title": "Информация о сотрудничестве со стартапами",
          "edited": true,
          "sysName": "questionnaire_startupInvestmentYears",
          "required": false,
          "localName": "Сколько лет ваша корпорация работает со стартапами",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_overallPilots",
          "required": false,
          "localName": "Общее количество пилотов/ контрактов (внедрений) со стартапами за все время",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_lastYearInvestmentsCount",
          "required": false,
          "localName": "Количество пилотов со стартапами за последний год",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        },
        {
          "note": "Опционально",
          "type": "int",
          "edited": true,
          "sysName": "questionnaire_overallContracts",
          "required": false,
          "localName": "Количество контрактов (внедрений) со стартапами за последний год",
          "triggerField": "questionnaire_successPilots",
          "triggerValue": "true"
        }
      ],
      "module": "Успешные кейсы",
      "pageName": "Пилотирование"
    },
    {
      "page": 6,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "investment_investment",
          "required": true,
          "localName": "Инвестирует ли ваша корпорация в стартапы?"
        },
        {
          "type": "array",
          "edited": true,
          "format": "chip",
          "sysName": "investment_round",
          "activity": [
            6000
          ],
          "required": true,
          "localName": "Раунд инвестиций",
          "multySelect": true,
          "triggerField": "investment_investment",
          "triggerValue": "true"
        },
        {
          "note": "В стартапы из каких регионов вы готовы инвестировать",
          "type": "array",
          "edited": true,
          "format": "search_dropdown",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": true,
          "localName": "География стартапов",
          "multySelect": true,
          "triggerField": "investment_investment",
          "triggerValue": "true"
        }
      ],
      "module": "Инвестиции",
      "pageName": "Инвестиции"
    },
    {
      "page": 6,
      "fields": [
        {
          "type": "long",
          "edited": false,
          "format": "hide",
          "sysName": "successPilots[]_pilotid",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "successPilots[]_company",
          "required": false,
          "localName": "Название стартапа",
          "maxLength": "140",
          "showLength": false
        },
        {
          "type": "string",
          "edited": true,
          "sysName": "successPilots[]_suggestCase",
          "required": false,
          "localName": "Описание кейса",
          "maxLength": "300",
          "showLength": false
        }
      ],
      "module": "Успешные кейсы",
      "isArray": true,
      "pageName": "Инвестиции",
      "subTitle": "Стартап №",
      "withIndex": true,
      "actionText": "Добавить кейс",
      "moduleNote": "Опционально. Укажите названия стартапов, с которыми у вашей компании были успешные внедрения, если хотите, чтобы информацию о них увидели другие пользователи SberUnity",
      "triggerField": "investment_investment",
      "triggerValue": true
    },
    {
      "page": 7,
      "fields": [
        {
          "type": "boolean",
          "edited": true,
          "format": "switch",
          "sysName": "questionnaire_scouting",
          "required": true,
          "localName": "Рассматриваете ли вы заказной скаутинг как инструмент для поиска нужных стартапов?"
        }
      ],
      "module": "Скаутинг",
      "pageName": "Скаутинг"
    }
  ]
}'
WHERE formname='corporate_edit';


UPDATE screen
SET formview='{
  "form": [
    {
      "page": 1,
      "fields": [
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_fullNote",
          "required": false,
          "localName": "Описание"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_industry",
          "activity": [
            22000
          ],
          "required": false,
          "localName": "Направление деятельности"
        },
        {
          "type": "hyperlink",
          "title": "Перейти",
          "edited": false,
          "format": "button",
          "sysName": "questionnaire_site",
          "required": false,
          "localName": "Сайт корпорации"
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnaire_email",
          "required": false,
          "localName": "Email"
        }
      ],
      "module": "Основная информация"
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_innovationMethod",
          "activity": [
            4000
          ],
          "required": false,
          "localName": "Методы работы с инновациями"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "questionnaire_stady",
          "activity": [
            7000
          ],
          "required": false,
          "localName": "Стадии развития продуктов"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_technology",
          "activity": [
            13000
          ],
          "required": false,
          "localName": "Технологии"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_industry",
          "activity": [
            3000
          ],
          "required": false,
          "localName": "Индустрии"
        }
      ],
      "module": "Работа со стартапами"
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "int",
          "edited": false,
          "format": "hide",
          "sysName": "questionnairePilots[]_pilotId",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "sysName": "questionnairePilots[]_suggestCase",
          "required": false,
          "localName": "Описание потребности"
        }
      ],
      "module": "",
      "isArray": "true"
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "investment_round",
          "activity": [
            6000
          ],
          "required": false,
          "localName": "Раунд инвестиций"
        },
        {
          "type": "array",
          "edited": false,
          "format": "text",
          "sysName": "project_geography",
          "activity": [
            2000
          ],
          "required": false,
          "localName": "География"
        }
      ],
      "module": "Инвестиции"
    },
    {
      "page": 1,
      "fields": [
        {
          "type": "int",
          "edited": false,
          "format": "hide",
          "sysName": "successPilots[]_pilotid",
          "required": false,
          "localName": ""
        },
        {
          "type": "string",
          "edited": false,
          "format": "body",
          "sysName": "successPilots[]_company",
          "required": false,
          "localName": "Успешный кейсы"
        }
      ],
      "module": "",
      "isArray": true,
      "moduleFormat": "card",
      "triggerField": "investment_investment",
      "triggerValue": "true"
    }
  ]
}'
WHERE formname='corporate_SuperClient';