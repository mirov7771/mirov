--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3489
UPDATE screen
SET formedit='{
  "form": [
    {
      "module": "Заявка на пилотирование",
      "page": 1,
      "isArray": "true",
      "moduleType": "question",
      "fields": [
        {
          "sysName": "response",
          "localName": "Ваш вопрос",
          "type": "string",
          "format": "question",
          "edited": false,
          "required": false
        }
      ]
    },
    {
      "module": "",
      "moduleNote": "",
      "page": 1,
      "fields": [
        {
          "sysName": "reply_cost",
          "localName": "Какова стоимость Вашего решения",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "30",
          "mask": "$",
          "example": "Сумма, в которую Вы оцениваете ваш пилотный запуск"
        },
        {
          "sysName": "reply_process",
          "localName": "Как Вы видите процесс пилотирования",
          "type": "string",
          "edited": true,
          "required": true,
          "maxLength": "500",
          "example": "Сроки, шаги, спецусловия, ограничения и т.п."
        },
        {
          "sysName": "reply_note",
          "localName": "Сопроводительное письмо",
          "type": "string",
          "edited": true,
          "required": false,
          "maxLength": "500",
          "example": "Опишите подробно Ваш оффер по данному пилоту"
        },
        {
          "sysName": "pilotId",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": false,
          "required": false
        },
        {
          "sysName": "reply_tableName",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "Pilot"
        },
        {
          "sysName": "reply_state",
          "localName": "",
          "type": "boolean",
          "format": "hide",
          "edited": true,
          "required": false,
          "value": "0"
        },
        {
          "sysName": "reply_fileURL",
          "localName": "Презентация",
          "description": "Презентация повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "format": "URL",
          "allowedTypes": [
            ".pdf"
          ],
          "edited": true,
          "required": false
        }
      ]
    }
  ]
}'
WHERE formname='pilot_Client_Extra';
