--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2925
delete from buttons where code in (100004, 20013);
insert into buttons(code, text)
values(100004, 'Редактировать');
insert into buttons(code, text)
values(20013, 'Снять с публикации');

delete from screen_button where name in ('round_Administrator', 'round_short_Administrator');
insert into screen_button(name,admin_check,owner_check,state)
values ('round_Administrator', null, true, 20011);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_Administrator', null, true, 20004);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_Administrator', null, true, 20003);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_short_Administrator', null, true, 20011);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_short_Administrator', null, true, 20004);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_short_Administrator', null, true, 20003);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_Administrator', true, null, 20011);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_Administrator', true, false, 20004);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_short_Administrator', true, null, 20011);
insert into screen_button(name,admin_check,owner_check,state)
values ('round_short_Administrator', true, null, 20004);

delete from screen_buttons_link where screen_id not in (select screen_id from screen_button);
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and owner_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '100004'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and owner_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '100004'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and owner_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '20013'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and owner_check = true and state = 20003 limit 1),
        (select button_id from public.buttons where code = '100004'));

insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and owner_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '100004'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and owner_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '100004'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and owner_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '20013'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and owner_check = true and state = 20003 limit 1),
        (select button_id from public.buttons where code = '100004'));

insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and admin_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '20004'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and admin_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '20009'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and admin_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '20003'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and admin_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '20013'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_Administrator' and admin_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '20003'));


insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and admin_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '20004'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and admin_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '20009'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and admin_check = true and state = 20011 limit 1),
        (select button_id from public.buttons where code = '20003'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and admin_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '20013'));
insert into screen_buttons_link(screen_id, button_id)
values ((select screen_id from screen_button where name = 'round_short_Administrator' and admin_check = true and state = 20004 limit 1),
        (select button_id from public.buttons where code = '20003'));