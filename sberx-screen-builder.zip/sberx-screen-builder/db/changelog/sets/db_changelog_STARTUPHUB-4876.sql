--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4876
update public.pages
set page = cast(replace(cast(page as text), 'startupsRecommend', 'startup') as json)
where uri = '/import-substitution'