--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5120
update public.screen
set formedit = '{
  "form":
  [
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные значения метрики в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "isControlShow": true,
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "direction": "row",
          "sysName": "items_type",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_date",
          "maxDate": "",
          "dateError": "Дата указана неверно"
        }
      ]
    }
  ]
}'
where formname = 'edit_metric'
  and lang_id = 1;