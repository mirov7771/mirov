--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5167-1
delete from screen
where formname like '%Pro%'
   or formname like '%InvestAngel%'
   or formname like '%Demo';

-- Форма startup_SuperClient

INSERT INTO screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'startup_CorpDemo','{}','{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год основания"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрии проекта"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "project_staff",
                    "required": false,
                    "direction": "row",
                    "localName": "Общее количество сотрудников"
                },
                {
                    "type": "banner",
                    "title": "На тарифах Pro будут доступны:",
                    "note": "Целевая аудитория, сайт, модель продаж, бизнес-модели, технологии проекта, контактное лицо, электронная почта, а также разделы «О проекте», «Команда», «Дополнительные контакты», «Кейсы пилотирования» и «Инвестиции».",
                    "edited": false,
                    "format": "banner",
                    "required": false,
                    "localName": "Подробнее о тарифах",
                    "value": "/main/select-tariff",
					"icon": "icPro"
                }
            ],
            "module": "Основная информация"
        }
    ]
}
','Просмотр анкеты стартапа',NULL,NULL,'{
                                                                                                                                                                       "buttons": [
                                                                                                                                                                         {
                                                                                                                                                                           "text": "Поделиться",
                                                                                                                                                                           "сode": "100003"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }',NULL,NULL,NULL,1,NULL);
INSERT INTO screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'startup_InvestDemo','{}','{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год основания"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрии проекта"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "project_staff",
                    "required": false,
                    "direction": "row",
                    "localName": "Общее количество сотрудников"
                },
                {
                    "type": "banner",
                    "title": "На тарифах Pro будут доступны:",
                    "note": "Целевая аудитория, сайт, модель продаж, бизнес-модели, технологии проекта, контактное лицо, электронная почта, а также разделы «О проекте», «Команда», «Дополнительные контакты», «Кейсы пилотирования» и «Инвестиции».",
                    "edited": false,
                    "format": "banner",
                    "required": false,
                    "localName": "Подробнее о тарифах",
                    "value": "/main/select-tariff",
					"icon": "icPro"
                }
            ],
            "module": "Основная информация"
        }
    ]
}
','Просмотр анкеты стартапа',NULL,NULL,'{
                                                                                                                                                                       "buttons": [
                                                                                                                                                                         {
                                                                                                                                                                           "text": "Поделиться",
                                                                                                                                                                           "сode": "100003"
                                                                                                                                                                         }
                                                                                                                                                                       ]
                                                                                                                                                                     }',NULL,NULL,NULL,1,NULL);
INSERT INTO screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'startup_CorpDemo',NULL,'{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год основания"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрии проекта"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "project_staff",
                    "required": false,
                    "direction": "row",
                    "localName": "Общее количество сотрудников"
                },
                {
                    "type": "banner",
                    "title": "На тарифах Pro будут доступны:",
                    "note": "Целевая аудитория, сайт, модель продаж, бизнес-модели, технологии проекта, контактное лицо, электронная почта, а также разделы «О проекте», «Команда», «Дополнительные контакты», «Кейсы пилотирования» и «Инвестиции».",
                    "edited": false,
                    "format": "banner",
                    "required": false,
                    "localName": "Подробнее о тарифах",
                    "value": "/main/select-tariff",
					"icon": "icPro"
                }
            ],
            "module": "Основная информация"
        }
    ]
}
','Viewing the startup profile',NULL,NULL,NULL,NULL,NULL,NULL,2,NULL);
INSERT INTO screen ("type",formname,formedit,formview,"name",description,pages,buttons,logofile,offerdescription,secondofferdescription,lang_id,info) VALUES (0,'startup_InvestDemo',NULL,'{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год основания"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрии проекта"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "project_staff",
                    "required": false,
                    "direction": "row",
                    "localName": "Общее количество сотрудников"
                },
                {
                    "type": "banner",
                    "title": "На тарифах Pro будут доступны:",
                    "note": "Целевая аудитория, сайт, модель продаж, бизнес-модели, технологии проекта, контактное лицо, электронная почта, а также разделы «О проекте», «Команда», «Дополнительные контакты», «Кейсы пилотирования» и «Инвестиции».",
                    "edited": false,
                    "format": "banner",
                    "required": false,
                    "localName": "Подробнее о тарифах",
                    "value": "/main/select-tariff",
					"icon": "icPro"
                }
            ],
            "module": "Основная информация"
        }
    ]
}
','Viewing the startup profile',NULL,NULL,NULL,NULL,NULL,NULL,2,NULL);

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'startup_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'startup_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'startup_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'startup_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'startup_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'startup_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'startup_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'startup_SuperClient';

-- Форма company_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'company_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'company_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'company_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'company_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'company_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'company_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'company_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'company_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'company_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'company_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'company_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'company_SuperClient';

-- Форма corporate_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'corporate_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'corporate_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'corporate_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'corporate_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'corporate_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'corporate_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'corporate_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'corporate_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'corporate_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'corporate_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'corporate_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'corporate_SuperClient';

-- Форма investor_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'investor_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'investor_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'investor_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'investor_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'investor_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'investor_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'investor_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'investor_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'investor_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'investor_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'investor_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'investor_SuperClient';

-- Форма offer_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'offer_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'offer_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'offer_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'offer_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'offer_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'offer_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'offer_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'offer_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'offer_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'offer_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'offer_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'offer_SuperClient';

-- Форма pilot_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient';

-- Форма pilot_SuperClient_Extra
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_CorpDemo_Extra', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient_Extra';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_CorpPro_Extra', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient_Extra';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_CorpProPlus_Extra', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient_Extra';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_InvestDemo_Extra', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient_Extra';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_InvestAngel_Extra', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient_Extra';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'pilot_InvestPro_Extra', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'pilot_SuperClient_Extra';

-- Форма reply_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'reply_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'reply_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'reply_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'reply_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'reply_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'reply_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'reply_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'reply_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'reply_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'reply_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'reply_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'reply_SuperClient';

-- Форма vas_SuperClient
insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'vas_CorpDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'vas_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'vas_CorpPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'vas_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'vas_CorpProPlus', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'vas_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'vas_InvestDemo', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'vas_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'vas_InvestAngel', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'vas_SuperClient';

insert into screen ("type",formname, formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info)
select "type", 'vas_InvestPro', formedit, formview, "name", description, pages, buttons, logofile, offerdescription, secondofferdescription, lang_id, info
from screen where formname = 'vas_SuperClient';
