--liquibase formatted sql
--changeset Mirov AA:auth-investment-round-view-ru
delete from pages where code = 'auth-investment-round-view-ru';

insert into pages (code, name, uri, description, page_type, page, lang_id)
values('auth-investment-round-view-ru', 'Инвестии | SberUnity', '/investment-round-view', 'SberUnity', 'auth', '{
   "features":[
      {
         "type":"investmentRoundView",
         "sysName":"investmentRoundView",
         "position":1,
         "visible":true,
         "config":{
            "nowrap":true
         },
         "unPublishModalContent":{
            "title":"Снять раунд с публикации?",
            "description":"Инвесторы не будут видеть этот раунд, если снять его с публикации1",
            "confirmButtonName":"Снять с публикации",
            "cancelButtonName":"Назад"
         },
         "backLinkText":"Назад",
         "editRoundQuestionnaireModal":{
            "title":"Информация о раунде",
            "fields":{
               "progress":{
                  "label":"На что пойдут деньги?",
                  "text":[
                     "Заполнено",
                     " из 100%"
                  ]
               },
               "marketingPercent":{
                  "label":"Маркетинг и продажи",
                  "required":false,
                  "placeholder":"0%",
                  "disabled":false,
                  "mask":"suffix=%withoutSeparator"
               },
               "softwarePercent":{
                  "label":"Оборудование и ПО",
                  "required":false,
                  "placeholder":"0%",
                  "disabled":false,
                  "mask":"suffix=%withoutSeparator"
               },
               "teamPercent":{
                  "label":"Оплата текущей команды",
                  "required":false,
                  "placeholder":"0%",
                  "disabled":false,
                  "mask":"suffix=%withoutSeparator"
               },
               "extensionPercent":{
                  "label":"Расширение команды",
                  "required":false,
                  "placeholder":"0%",
                  "disabled":false,
                  "mask":"suffix=%withoutSeparator"
               },
               "otherPercentState":{
                  "label":"Другое"
               },
               "otherDescription":{
                  "label":"",
                  "required":false,
                  "placeholder":"Дополнительные расходы"
               },
               "otherPercent":{
                  "label":"",
                  "required":false,
                  "placeholder":"0%",
                  "disabled":false,
                  "mask":"suffix=%withoutSeparator"
               },
               "result":{
                  "label":"Какие результаты будут достигнуты?",
                  "required":true,
                  "placeholder":"Ожидаемый результат привлечения раунда",
                  "disabled":false,
                  "mask":"",
                  "info":"Рекомендуем указывать конкретные числа, например, на сколько процентов вырастут продажи, во сколько раз увеличится число клиентов и т.п."
               },
               "leadCheck":{
                  "label":"Есть ли лид-инвестор?"
               },
               "leadName":{
                  "label":"Укажите лид-инвестора",
                  "required":false,
                  "placeholder":"Название фонда или имя бизнес-ангела",
                  "disabled":false,
                  "mask":"",
                  "info":"Инвестор, вкладывающий наибольшую сумму в текущий раунд и привлекающий других инвесторов."
               },
               "lastInvestment":{
                  "label":"Какая сумма уже собрана?",
                  "placeholder":"0 $",
                  "mask":"suffix=$"
               },
               "futureInvestment":{
                  "label":"Осталось собрать",
                  "required":false,
                  "placeholder":"0 $",
                  "disabled":true,
                  "mask":"suffix=$"
               },
               "roundInfo":{
                  "label":"Дополнительная информация о раунде",
                  "required":false,
                  "placeholder":"Что еще может быть важно инвестору",
                  "disabled":false,
                  "mask":"",
                  "info":"Например, текущие инвесторы, минимальный чек, ESOP и др."
               },
               "endDate":{
                  "label":"Предполагаемая дата закрытия сделки"
               },
               "presentation":{
                  "label":"Инвестиционная презентация"
               },
               "roundType":{
                  "label":"Стадия раунда",
                  "placeholder":"Выберите стадию"
               },
               "geography":{
                  "labelInvestment":"Юрисдикция сделки",
                  "label":"Планируемая юрисдикция сделки",
                  "placeholder":"Укажите страну"
               },
               "transactionType":{
                  "labelInvestment":"Тип сделки",
                  "label":"Планируемый тип сделки",
                  "placeholder":"Укажите тип",
                  "info":"Инвестиции в капитал - непосредственно вхождение в капитал компании, покупка доли в стартапе в текущем раунде.\nКонвертируемый займ (Convertible Note) - соглашение с обязательством стартапа привлечь следующий раунд к определенному сроку или вернуть займ инвестору. В случае привлечения раунда инвестиции конвертируются в долю компании пропорционально оценке стартапа на следующем раунде.\nSAFE (Simple Agreement for Future Equity) - соглашение о будущем вхождении инвестора в капитал без определенной процентной ставки и дедлайна по привлечению следующего раунда. Размер доли инвестора зависит от оценки компании на следующем раунде.\n KISS - Keep It Simple Security. Форма документа, разработанная 500 Startups как альтернатива Convertible Note и SAFE для стартапов ранних стадий."
               },
               "otherDescriptionNonInvestment":{
                  "label":"Цель привлечения инвестиций",
                  "required":true,
                  "placeholder":"Укажите цель"
               },
               "noFieldLabels":{
                  "labelInvestment":"Оценка стартапа в раунде",
                  "label":"Планируемая оценка стартапа в раунде",
                  "info":"Укажите приблизительно по какой оценке компании вы планируете поднимать следующий раунд. Оценка должна быть реалистичной."
               },
               "sumInvestment":{
                  "labelInvestment":"Какую сумму инвестиций вы привлекаете?",
                  "label":"Какую сумму инвестиций вы планируете привлекать?",
                  "placeholder":"0 $",
                  "mask":"suffix=$"
               },
               "percent":{
                  "label":"За какой процент компании?",
                  "placeholder":"0%",
                  "mask":"suffix=%withoutSeparator"
               },
               "preMoney":{
                  "label":"Pre-money",
                  "required":false,
                  "placeholder":"0 $",
                  "disabled":true,
                  "mask":"suffix=$",
                  "info":"Pre-money valuation – стоимость компании до получения денег инвесторов в текущем раунде."
               },
               "postMoney":{
                  "label":"Post-money",
                  "required":false,
                  "placeholder":"0 $",
                  "disabled":true,
                  "mask":"suffix=$",
                  "info":"Post-money valuation – оценка компании, по которой вносятся деньги инвесторов, т.е. стоимость стартапа после получения денег инвесторов в текущем раунде."
               },
               "planDate":{
                  "blockHeader":"Планируемая дата начала сбора раунда",
                  "label":"Укажите дату"
               },
               "inviteFio":{
                  "blockHeader":"Контакты",
                  "label":"Имя сотрудника, с которым можно связаться",
                  "required":true
               },
               "email":{
                  "label":"Электронная почта сотрудника",
                  "required":true
               },
               "phone":{
                  "label":"Телефон сотрудника",
                  "required":true,
                  "placeholder":"",
                  "disabled":false,
                  "mask":"phone"
               }
            },
            "buttons":{
               "secondary":"Отменить",
               "main":{
                  "roundId":"Сохранить изменения",
                  "nonRoundId":"Добавить информацию"
               }
            },
            "toasts":{
               "roundId":{
                  "success":"Изменения сохранены",
                  "error":"Не удалось сохранить изменения"
               },
               "nonRoundId":{
                  "success":[
                     "Раунд",
                     "создан"
                  ],
                  "error":"Не удалось создать раунд"
               }
            }
         }
      }
   ]
}', 1);
