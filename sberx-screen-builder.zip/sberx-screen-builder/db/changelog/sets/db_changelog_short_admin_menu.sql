--liquibase formatted sql
--changeset Mirov AA:short_admin_menu
update client_menu
set action = action || '&state=20010'
where menutype = 'sidebar'
  and "type" in (4,5,6)
  and sysname = 'questionary';