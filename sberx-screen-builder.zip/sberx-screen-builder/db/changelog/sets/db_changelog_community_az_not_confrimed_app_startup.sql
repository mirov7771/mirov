--liquibase formatted sql
--changeset Mirov AA:community_az_not_confrimed_app_startup
update public.pages
set page = '{
  "features": [
    {
      "type": "mainHeader",
      "sysName": "AZ_NOT_CONFIRMED_APP_cMainHeader_1",
      "visible": true,
      "position": 1,
      "description": "Общайтесь с предпринимателями, инвесторами, экспертами венчурной индустрии и находите решения ваших бизнес-задач",
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_NOT_CONFIRMED_APPcMainHeader_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "inactive",
          "text": "Заявка уже направлена",
          "url": null,
          "action": "popup",
          "config": {},
          "iconUrl": null,
          "theme": "purple-gradient"
        },
        {
          "type": "bigNSmallGallery",
          "sysName": "AZ_NOT_CONFIRMED_APPcMainHeader_1_bigNSmallGallery_1",
          "visible": true,
          "config": {},
          "images": [
            {
              "url": "/file/welcome_headerImg_1.png",
              "isMain": true
            },
            {
              "url": "/file/welcome_headerImg_2.png",
              "isMain": false
            }
          ]
        }
      ],
      "title": "**СберСтартап**  \\nсообщество",
      "backgroundUrl": "/file/bg-main.png"
    },
    {
      "type": "carousel",
      "sysName": "AZ_NOT_CONFIRMED_APPcCarousel_1",
      "visible": true,
      "header": "**Направления** сообщества",
      "description": "Мы создаём качественный контент, проводим полезные мероприятия и развиваем проактивное отношение к венчурному бизнесу и приглашаем вас стать частью проектов сообщества",
      "items": [
        "/file/carousel_slide_1.jpeg",
        "/file/carousel_slide_2.jpeg",
        "/file/carousel_slide_3.jpeg"
      ],
      "position": 5,
      "config": {
        "autorotation": false,
        "delay": 3,
        "speed": 1000,
        "direction": "left"
      }
    },
    {
      "type": "events",
      "sysName": "AZ_NOT_CONFIRMED_APPcEvents_1",
      "visible": true,
      "header": "Событийная кухня",
      "title": "Закрывайте бизнес-потребности через нетворкинг",
      "description": "С помощью событий мы выстраиваем доверительную обстановку и сопричастность к общему делу. Знакомим со стратегически важными для вашего бизнеса людьми и выстраиваем диалог между участниками сообщества.",
      "config": {},
      "features": [
        {
          "type": "offsetSquares",
          "sysName": "AZ_NOT_CONFIRMED_APPcOffsetSquares_1",
          "visible": true,
          "items": [
            {
              "title": "Партнерские мероприятия",
              "imageUrl": "/file/meetings.png",
              "tablePosition": {
                "row": 1,
                "column": 1
              }
            },
            {
              "title": "Хакатоны и интенсивы",
              "imageUrl": "/file/hakatons.png",
              "tablePosition": {
                "row": 1,
                "column": 2
              }
            },
            {
              "title": "Мероприятия с другими фондами и сообществами",
              "imageUrl": "/file/another_funds.png",
              "tablePosition": {
                "row": 2,
                "column": 1
              }
            },
            {
              "title": "Выезды и вечеринки",
              "imageUrl": "/file/party.png",
              "tablePosition": {
                "row": 2,
                "column": 2
              }
            },
            {
              "title": "Закрытые очные встречи",
              "imageUrl": "/file/close-meeting.png",
              "tablePosition": {
                "row": 3,
                "column": 1
              }
            },
            {
              "title": "Онлайн-митапы",
              "imageUrl": "/file/onlline-meetings.png",
              "tablePosition": {
                "row": 3,
                "column": 2
              }
            }
          ],
          "config": {}
        },
        {
          "type": "button",
          "sysName": "AZ_NOT_CONFIRMED_APPcEvents_1_button_1",
          "category": "simple",
          "visible": true,
          "default": "active",
          "text": "Календарь событий",
          "iconUrl": "/file/calendar.svg",
          "url": "http://sber.me/?p=k3w6h",
          "action": "redirect",
          "config": {},
          "theme": "purple-gradient"
        }
      ],
      "position": 6
    },
    {
      "type": "socialTiles",
      "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1",
      "header": "Контент-студия",
      "visible": true,
      "description": "Мы делаем полезный, оригинальный контент о венчурной индустрии и продвигаем тему технологического предпринимательства через медиаресурсы Сбера",
      "config": {},
      "items": [
        {
          "title": "Сберстартап",
          "category": "Telegram-канал",
          "imageUrl": "/file/content_studio_tg_chanel.jpeg",
          "description": "Советы экспертов, новости венчурной индустрии, анонсы событий",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_1",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "iconUrl": null,
              "url": "http://sber.me/?p=m6f1b",
              "action": "redirect",
              "config": {},
              "visible": true,
              "theme": "default"
            }
          ]
        },
        {
          "title": "Три запятые",
          "category": "Подкаст",
          "imageUrl": "/file/content_studio_podcast.jpeg",
          "description": "Разговоры о том, как изменить мир и заработать заветный миллиард",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_2",
              "iconUrl": null,
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=1V5r1",
              "action": "redirect",
              "visible": true,
              "theme": "default",
              "config": {}
            }
          ]
        },
        {
          "title": "VC.RU",
          "category": "Блог",
          "imageUrl": "/file/content_studio_blog.jpeg",
          "description": "Успешные и не очень кейсы участников сообщества",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_3",
              "category": "simple",
              "default": "active",
              "text": "Подписаться",
              "url": "http://sber.me/?p=ZpLRc",
              "action": "redirect",
              "visible": true,
              "iconUrl": null,
              "config": {},
              "theme": "default"
            }
          ]
        },
        {
          "title": "Для стартапов",
          "category": "YouTube-шоу",
          "imageUrl": "/file/content_studio_yb_show.jpeg",
          "description": "Страхи интеграции, пивоты, экстримальные питчи и погоня за инвестициями",
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcSocialTiles_1_button_4",
              "category": "simple",
              "default": "inactive",
              "text": "Скоро",
              "iconUrl": "/file/content_studio_clock.svg",
              "action": "redirect",
              "visible": true,
              "url": null,
              "config": {},
              "theme": "default"
            }
          ]
        }
      ],
      "position": 7
    },
    {
      "type": "banner",
      "sysName": "AZ_NOT_CONFIRMED_APPcFooterBanner_1",
      "visible": true,
      "title": "Подайте заявку и станьте частью сообщества СберСтартап",
      "backgroundUrl": "/file/banner_banner.png",
      "description": null,
      "config": {},
      "features": [
        {
          "type": "button",
          "sysName": "AZ_NOT_CONFIRMED_APPcFooterBanner_1_button_1",
          "category": "simple",
          "default": "inactive",
          "text": "Заявка уже отправлена",
          "url": null,
          "action": "popup",
          "visible": true,
          "config": {},
          "theme": "default"
        }
      ],
      "position": 8
    },
    {
      "type": "squareList",
      "sysName": "AZ_NOT_CONFIRMED_APPсSquareList_startup_1",
      "title": "Что вам **будет доступно**",
      "items": [
        {
          "title": "Нетворкинг",
          "description": "Живое общение с близкими по интересам людьми для решения ваших бизнес-задач",
          "iconUrl": "/file/ic_96_bubbles.svg"
        },
        {
          "title": "Экспертиза",
          "description": "Консультации от профессиональных трекеров и опытных менторов",
          "iconUrl": "/file/ic_96_person_document.svg"
        },
        {
          "title": "Контент",
          "description": "Новости венчурной индустрии, советы экспертов, интервью с лидерами рынка",
          "iconUrl": "/file/ic_96_media.svg"
        },
        {
          "title": "Мероприятия",
          "description": "Совместные выезды, закрытые вечеринки, митапы, конференции, хакатоны",
          "iconUrl": "/file/ic_96_calendar_mic.svg"
        },
        {
          "title": "Закрытый стартап-клуб",
          "description": "Эксклюзивные мероприятия с инвесторами",
          "iconUrl": "/file/ic_96_invite_letter.svg"
        },
        {
          "title": "Поддержка",
          "description": "Обмен опытом и помощь в решении бизнес-кейсов",
          "iconUrl": "/file/ic_96_question_notebook.svg"
        }
      ],
      "config": {},
      "visible": true,
      "position": 2
    },
    {
      "type": "roadMap",
      "sysName": "AZ_NOT_CONFIRMED_APPсRoadMap_startup_2",
      "visible": true,
      "config": {},
      "items": [
        {
          "title": "Вы уже заполнили анкету",
          "description": "В ближайшее время наш комьюнити-менеджер свяжется с вами",
          "iconUrl": "/file/roadmap_done.svg",
          "stepNumber": null
        },
        {
          "title": "Дождитесь результата",
          "description": "В течение 3-х дней мы рассмотрим вашу заявку и вернёмся с обратной связью",
          "iconUrl": null,
          "stepNumber": "2"
        },
        {
          "title": "Присоединитесь к нам",
          "description": "После прохождения отбора вам станет доступен Telegram-чат с полезными контактами, идеями и эксклюзивами",
          "iconUrl": null,
          "stepNumber": "3"
        }
      ],
      "backgroundColor": "#EBECF1",
      "header": "**Как попасть** в сообщество СберСтартап",
      "position": 3
    },
    {
      "type": "nearby",
      "sysName": "AZ_NOT_CONFIRMED_APPcNearby_startup_1",
      "header": "Мы **рядом** с вами",
      "visible": true,
      "features": [
        {
          "type": "banner",
          "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_1",
          "title": "Онлайн",
          "visible": true,
          "description": "На платформе Telegram и онлайн-событиях",
          "iconUrl": "/file/community_banner_il_online.png",
          "tablePosition": {
            "row": 1,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_2",
          "title": "Оффлайн",
          "visible": true,
          "description": "В собственном коворкинге и на закрытых встречах",
          "iconUrl": "/file/community_banner_il_offline.png",
          "tablePosition": {
            "row": 2,
            "column": 1
          },
          "config": {},
          "theme": "default"
        },
        {
          "type": "banner",
          "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_3",
          "title": "Сообщество СберСтартап",
          "visible": true,
          "description": "Среди участников: инвесторы, предприниматели и венчурные эксперты. Присоединяйтесь!",
          "backgroundUrl": "/file/community-banner.png",
          "tablePosition": {
            "row": 1,
            "column": 2
          },
          "config": {},
          "features": [
            {
              "type": "button",
              "sysName": "AZ_NOT_CONFIRMED_APPcNearbyBanner_startup_3_button_1",
              "category": "simple",
              "default": "inactive",
              "text": "Заявка уже отправлена",
              "iconUrl": null,
              "url": null,
              "config": {},
              "action": "popup",
              "theme": "default"
            }
          ],
          "theme": "purple-gradient"
        }
      ],
      "config": {
        "tableConfiguration": [
          {
            "columnNumber": 1,
            "rows": 2
          },
          {
            "columnNumber": 2,
            "rows": 1
          }
        ]
      },
      "position": 4
    }
  ]
}'
where code = 'community_az_not_confrimed_app_startup';
