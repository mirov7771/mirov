--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-2548_insert_3
insert into screen_button (name, success_pilot_check, state)
values ('corporate_SuperClient', true, 20004);

insert into screen_buttons_link (screen_id, button_id)
select screen_id , (select button_id from public.buttons b where code = 100001)
from public.screen_button sb
where state = 20004
  and name in ('corporate_SuperClient')
  and owner_check is null
  and success_pilot_check = true;