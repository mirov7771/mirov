--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3958
delete from public.screen_button where name = 'reply_SuperClient';
delete from public.buttons where code in (20007, 20011);
insert into public.screen_button(name, state) values ('reply_SuperClient', 20011);
insert into public.screen_button(name, state) values ('reply_SuperClient', 20003);
insert into public.screen_button(name, state) values ('reply_SuperClient', 20004);
insert into public.screen_button(name, state) values ('reply_SuperClient', 20009);
insert into public.screen_button(name, state) values ('reply_SuperClient', 20007);
insert into public.screen_button(name, state) values ('reply_SuperClient', 20002);

insert into public.buttons (code, "text", lang_id) values (20007, 'Завершить', 1);
insert into public.buttons (code, "text", lang_id) values (20011, 'Новый', 1);

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20011 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20011 limit 1),
        (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20011 limit 1),
        (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20011 limit 1),
        (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20011 limit 1),
        (select button_id from public.buttons where code = 20003));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20011));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20003 limit 1),
        (select button_id from public.buttons where code = 20011));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 20007));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 20003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 20011));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20004 limit 1),
        (select button_id from public.buttons where code = 20009));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20009 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20009 limit 1),
        (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20009 limit 1),
        (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20009 limit 1),
        (select button_id from public.buttons where code = 20011));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20009 limit 1),
        (select button_id from public.buttons where code = 20003));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 20002));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 20003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20007 limit 1),
        (select button_id from public.buttons where code = 20011));

insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20002 limit 1),
        (select button_id from public.buttons where code = 100000));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20002 limit 1),
        (select button_id from public.buttons where code = 20004));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20002 limit 1),
        (select button_id from public.buttons where code = 20009));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20002 limit 1),
        (select button_id from public.buttons where code = 20003));
insert into public.screen_buttons_link (screen_id, button_id)
values ((select screen_id from public.screen_button where name = 'reply_SuperClient' and state = 20002 limit 1),
        (select button_id from public.buttons where code = 20011));