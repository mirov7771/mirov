--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-4119
update public.screen
set formview='{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "date",
                    "edited": false,
                    "sysName": "Questionnaire_Modified",
                    "required": false,
                    "localName": "Время обновления"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_fullName",
                    "required": false,
                    "localName": "Наименование организации"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_inn",
                    "required": false,
                    "localName": "ИНН организации"
                },
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "questionnaire_birthYear",
                    "required": false,
                    "localName": "Год регистрации",
                    "maxLength": 4
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_name",
                    "required": false,
                    "localName": "Публичное название / название бренда"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "sysName": "questionnaire_site",
                    "required": false,
                    "localName": "Сайт"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_transcription",
                    "required": false,
                    "localName": "Транскрипция"
                },
                {
                    "type": "text",
                    "edited": false,
                    "format": "search_dropdown",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Страна юрисдикции*"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_inviteFio",
                    "required": false,
                    "localName": "Контактное лицо"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_email",
                    "required": false,
                    "localName": "Электронная почта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_phoneNumber",
                    "required": false,
                    "localName": "Номер телефона"
                }
            ],
            "module": "Организация",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Ресурс",
                    "edited": false,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity": [
                        21000
                    ],
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "URL",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "localName": "Ссылка"
                }
            ],
            "module": "Дополнительные контакты",
            "isArray": "true",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "chip",
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": false,
                    "localName": "Бизнес-модели взаимодействия с пользователями"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "chip",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": false,
                    "localName": "Бизнес-модели"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Страна"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "questionnaire_location",
                    "required": false,
                    "localName": "Город"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": false,
                    "localName": "Индустрии"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": false,
                    "localName": "Технологии"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_note",
                    "required": false,
                    "localName": "Краткое описание проекта"
                },
                {
                    "type": "logo",
                    "edited": false,
                    "sysName": "questionnaire_logoFile",
                    "required": false,
                    "localName": "Загрузить логотип"
                }
            ],
            "module": "О проекте",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": false,
                    "localName": "Стадия развития продукта"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_demoSite",
                    "required": false,
                    "localName": "URL ссылка на демо",
                    "triggerField": "project_haveMVP",
                    "triggerValue": "true"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "URL",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о продукте",
                    "triggerField": "project_haveMVP",
                    "triggerValue": "true"
                }
            ],
            "module": "Прототип",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "note": "Опишите в 1–2 предложениях",
                    "type": "string",
                    "edited": false,
                    "sysName": "project_problem",
                    "required": false,
                    "localName": "Проблема, которую решает проект"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_auditory",
                    "required": false,
                    "localName": "Целевая аудитория"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": false,
                    "localName": "Загрузить презентацию"
                },
                {
                    "type": "hyperlink",
                    "edited": false,
                    "format": "URL",
                    "sysName": "project_pitchVideo",
                    "required": false,
                    "localName": "Видео питча"
                }
            ],
            "module": "О проекте",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которых вы работаете"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые собираетесь выходить в ближайшее время"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": false,
                    "localName": "Продажи"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "investment_turnover",
                    "required": false,
                    "localName": "Оборот в год (в USD)"
                }
            ],
            "module": "Рынок",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_competitor",
                    "required": false,
                    "localName": "Прямые конкуренты"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_indirectCompetitor",
                    "required": false,
                    "localName": "Косвенные конкуренты"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_upSide",
                    "required": false,
                    "localName": "Преимущества перед конкурентами"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "project_downSide",
                    "required": false,
                    "localName": "Недостатки перед конкурентами"
                }
            ],
            "module": "Конкуренты",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "int",
                    "edited": false,
                    "sysName": "project_staff",
                    "required": false,
                    "localName": "Общее количество сотрудников"
                }
            ],
            "module": "Команда",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Роль сотрудника в команде"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Краткое описание опыта"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": false,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "Успешные В2В-, В2G-, B2B2C-, В2О- кейсы",
            "isArray": "true",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": false,
                    "format": "hide",
                    "sysName": "b2cPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "b2cPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "b2cPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "triggerField": "questionnaire_successPilotsB2C",
                    "triggerValue": "true"
                }
            ],
            "module": "Успешные B2C-, C2C- кейсы",
            "isArray": "true",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": false,
                    "localName": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?*"
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": false,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "localName": "Предлагаемый кейс*",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": false,
                    "localName": "Взаимодействовали ли вы с экосистемой Сбера раньше?*",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "ecoPilot_businessUnit",
                    "required": false,
                    "localName": "С каким бизнес юнитом Сбера взаимодействовали?*",
                    "triggerField": "ecoPilot_experience",
                    "triggerValue": "true"
                }
            ],
            "module": "Экосистема Сбера",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": false,
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Объем ранее привлеченных инвестиций, всего",
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                },
                {
                    "note": "Перечислите всех инвесторов, от которых получали инвестиции, если раскрытие этой информации не противоречит договоренностям с ними",
                    "type": "string",
                    "edited": false,
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Имя/ имена инвестора/ инвесторов",
                    "triggerField": "investment_investment",
                    "triggerValue": "true"
                }
            ],
            "module": "Инвестиции",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "edited": false,
                    "format": "text",
                    "sysName": "questionnaire_acceleratorCode",
                    "activity": [
                        26000
                    ],
                    "required": false,
                    "localName": "Является выпускником:"
                }
            ],
            "module": "Акселераторы Сбера",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_community",
                    "required": false,
                    "localName": "Хотите участвовать в сообществах СберСтартап"
                }
            ],
            "module": "Сообщества",
            "pageName": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "questionnaire_sber500",
                    "required": false,
                    "localName": "Хочет ли стартап подать заявку на участие в Sber500?",
                    "information": "Sber500 - уникальный акелератор, основанный на возможностях экосистемы Сбера и экспертизе и опыте 500 Global"
                },
                {
                    "type": "boolean",
                    "edited": false,
                    "format": "switch",
                    "sysName": "sberFiveHundred_firsttime",
                    "required": false,
                    "localName": "Подавался ли стартап ранее в Sber500?",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true"
                },
                {
                    "type": "array",
                    "edited": false,
                    "format": "search_dropdown",
                    "example": "Укажите потребность",
                    "sysName": "sberFiveHundred_ecorequirement",
                    "activity": [
                        38000
                    ],
                    "required": false,
                    "localName": "Какую потребность Экосистемы Сбера закрывает стартап?",
                    "multySelect": true,
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true"
                },
                {
                    "type": "string",
                    "edited": false,
                    "regExp": "(^([0-9]{1,7}))",
                    "sysName": "sberFiveHundred_monthrevenue",
                    "required": false,
                    "localName": "Выручка за последний месяц",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true"
                },
                {
                    "type": "string",
                    "edited": false,
                    "regExp": "(^([0-9]{1,7}))",
                    "sysName": "sberFiveHundred_quarterrevenue",
                    "required": false,
                    "localName": "Выручка за последние 3 месяца",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true"
                },
                {
                    "type": "int",
                    "edited": false,
                    "format": "[1;1000]",
                    "example": "Укажите количество клиентов",
                    "sysName": "sberFiveHundred_clients",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": false,
                    "localName": "Количество активных или платящих клиентов за последний месяц",
                    "triggerField": "questionnaire_sber500",
                    "triggerValue": "true"
                }
            ],
            "module": "Акселератор Sber500",
            "pageName": "Sber500"
        }
    ]
}' where formname = 'startup_Administrator';