--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5188
update screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Полное юридическое название",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Укажите ваш ИНН или иной регистрационный номер",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Идентификационный номер компании",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Укажите год регистрации юрлица",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "Например, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну юрисдикции",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна регистрации юрлица",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Адрес сайта",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Иванов Иван Иванович",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Контактное лицо"
                },
                {
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Укажите почту для связи",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Электронная почта"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Номер телефона"
                }
            ],
            "module": "Организация",
            "pageName": "Юридическая информация",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Ресурс",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity": [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Адрес ссылки",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Дополнительные ссылки",
            "isArray": "true",
            "pageName": "Юридическая информация",
            "actionText": "Добавить ссылку",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах"
        },
        {
            "page": 2,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите ваш стартап одним предложением",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Краткое описание стартапа",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Модели продаж",
                    "edited": true,
                    "format": "chip",
                    "values": [],
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "Укажите модели взаимодействия с клиентами в вашем бизнесе",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values": [],
                    "example": "Укажите бизнес-модель стартапа",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": true,
                    "localName": "Бизнес-модель",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Выберите стадию развития",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": true,
                    "localName": "Стадия развития стартапа",
                    "multySelect": false
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Укажите число сотрудников в штате",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Количество сотрудников"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип стартапа",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes": [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Ссылка на видео",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о стартапе",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Где базируется ваш стартап?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну",
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна",
                    "description": "Укажите, где фактически находится штаб-квартира вашего стартапа",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Введите город",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "Город",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "О стартапе",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите индустрии",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Индустрии и технологические вертикали, в которых функционирует ваш стартап",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите технологии",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                }
            ],
            "module": "Направления",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "Проблема, которую решает ваш продукт",
                    "maxLength": "300"
                },
                {
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите вашу целевую аудиторию",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Целевая аудитория",
                    "maxLength": "300"
                },
                {
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "type": "hyperlink",
                    "title": "Презентация",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes": [
                        ".pdf"
                    ]
                },
                {
                    "note": "Регионы, на которых уже представлен ваш продукт",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Рынки, на которых вы работаете",
                    "multySelect": true,
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Регионы, на которые вы планируете выйти в ближайший год",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые планируете выходить",
                    "multySelect": true
                },
                {
                    "note": "Укажите стадию продаж вашего продукта",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите тип продаж",
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": true,
                    "localName": "Продажи",
                    "multySelect": true,
                    "valueGroups": [
                        {
                            "1": "5001"
                        },
                        {
                            "2": "5002,5003,5004"
                        }
                    ]
                },
                {
                    "mask": "$",
                    "note": "Валовый оборот компании за последний год в $",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Оборот в год",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число",
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите название компаний-конкурентов",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Прямые конкуренты",
                    "maxLength": "300"
                },
                {
                    "note": "Перечислите предметно, чем вы лучше конкурентов",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите преимущества вашего продукта",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Преимущества перед конкурентами",
                    "maxLength": "300"
                },{
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите названия",
                    "sysName": "questionnaire_acceleratorString",
                    "required": false,
                    "localName": "В каких акселераторах участвовал ваш стартап?",
                    "maxLength": "300",
                     "showLength": false
                }
            ],
            "module": "О продукте",
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?*"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 2,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Названия заменяемых сервисов/компаний",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Укажите названия сервисов",
                    "maxLength": "10",
                    "note": "Перечислите через запятую не более 10 сервисов",
                     "multySelect": true
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите кратко, в каком аспекте ваш продукт является аналогом указанных сервисов"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите предметно, чем ваш продукт лучше замещаемого сервиса"
                }
            ]
        },
        {
            "page": 3,
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Название должности",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Опишите опыт сотрудника",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Краткое описание опыта",
                    "maxLength": "150"
                }
            ],
            "module": "Ключевые сотрудники",
            "isArray": "true",
            "pageName": "Команда",
            "actionText": "Добавить должность"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Успешные пилоты",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите, с какой корпорацией у вас был успешный кейс",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите про кейс и его результаты",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "actionText": "Добавить кейс",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "title": "Предлагаемый кейс",
                    "edited": true,
                    "example": "Если у вас есть идеи, как можно пилотировать ваш продукт, опишите их в нескольких предложениях",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Есть ли у вас опыт взаимодействия с экосистемой Сбера?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "Экосистема Сбера",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Находитесь ли вы в активном поиске инвестиций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число"
                },
                {
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Список инвесторов",
                    "maxLength": "300"
                },
                {
                    "sysName": "userConsent_mailingConsent",
                    "localName": "Я <a href=\"mailingConsentURL\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"text-decoration:none;color:#AB4278;\">соглашаюсь</a> на обработку персональных данных для цели проведения аналитических, статистических, маркетинговых исследований и формирования на их основе персональных предложений",
                    "type": "boolean",
                    "format": "checkbox",
                    "edited": true,
                    "required": false
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": ""
        }
    ]
}'
where formname = 'New_StartUp'
  and lang_id = 1;

update screen
set formedit = '{
    "form":
    [
        {
            "page": 1,
            "fields":
            [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Полное юридическое название",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Наименование организации",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Укажите ваш ИНН или иной регистрационный номер",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Идентификационный номер компании",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Укажите год регистрации юрлица",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Год регистрации",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Под каким названием отображать анкету другим участникам платформы",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "Например, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Публичное название",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Введите краткое название без организационно-правовой формы"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну юрисдикции",
                    "sysName": "questionnaire_registrationCountry",
                    "activity":
                    [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна регистрации юрлица",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Адрес сайта",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Сайт",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Иванов Иван Иванович",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Контактное лицо"
                },
                {
                    "note": "Данный email будет виден другим участникам платформы как контактный",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Укажите почту для связи",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Электронная почта"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Номер телефона"
                }
            ],
            "module": "Организация",
            "pageName": "Юридическая информация",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields":
            [
                {
                    "type": "array",
                    "title": "Ресурс",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity":
                    [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Адрес ссылки",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                }
            ],
            "module": "Дополнительные ссылки",
            "isArray": "true",
            "pageName": "Юридическая информация",
            "actionText": "Добавить ссылку",
            "moduleNote": "Укажите ссылки на страницы стартапа на других ресурсах"
        },
        {
            "page": 2,
            "fields":
            [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите ваш стартап одним предложением",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Краткое описание стартапа",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Модели продаж",
                    "edited": true,
                    "format": "chip",
                    "values":
                    [],
                    "sysName": "project_interactionType",
                    "activity":
                    [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "Укажите модели взаимодействия с клиентами в вашем бизнесе",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values":
                    [],
                    "example": "Укажите бизнес-модель стартапа",
                    "sysName": "questionnaire_businessModel",
                    "activity":
                    [
                        24000
                    ],
                    "required": true,
                    "localName": "Бизнес-модель",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Выберите стадию развития",
                    "sysName": "project_mvpCode",
                    "activity":
                    [
                        27000
                    ],
                    "required": true,
                    "localName": "Стадия развития стартапа",
                    "multySelect": false
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Укажите число сотрудников в штате",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Количество сотрудников"
                },
                {
                    "note": "Размер логотипа: до 1200x1200. Вес файла — не более 5 МБ, формат png, jpg.",
                    "type": "logo",
                    "title": "Логотип стартапа",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes":
                    [
                        ".png",
                        ".jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Ссылка на видео",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Видео о стартапе",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Необходимо указать сайт в формате: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Где базируется ваш стартап?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите страну",
                    "sysName": "questionnaire_locationCountry",
                    "activity":
                    [
                        2000
                    ],
                    "required": true,
                    "localName": "Страна",
                    "description": "Укажите, где фактически находится штаб-квартира вашего стартапа",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Введите город",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "Город",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "О стартапе",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields":
            [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите индустрии",
                    "sysName": "project_industry",
                    "activity":
                    [
                        3000
                    ],
                    "required": true,
                    "localName": "Индустрии",
                    "description": "Индустрии и технологические вертикали, в которых функционирует ваш стартап",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите технологии",
                    "sysName": "project_technology",
                    "activity":
                    [
                        13000
                    ],
                    "required": true,
                    "localName": "Технологии",
                    "multySelect": true
                }
            ],
            "module": "Направления",
            "pageName": "Информация о стартапе 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields":
            [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите, какую задачу или проблему решает продукт",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "Проблема, которую решает ваш продукт",
                    "maxLength": "300"
                },
                {
                    "note": "Возраст, род деятельности, интересы и т.д.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите вашу целевую аудиторию",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Целевая аудитория",
                    "maxLength": "300"
                },
                {
                    "note": "Вес файла — не более 20 МБ, формат pdf",
                    "type": "hyperlink",
                    "title": "Презентация",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes":
                    [
                        ".pdf"
                    ]
                },
                {
                    "note": "Регионы, на которых уже представлен ваш продукт",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_geography",
                    "activity":
                    [
                        2000
                    ],
                    "required": true,
                    "localName": "Рынки, на которых вы работаете",
                    "multySelect": true,
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Регионы, на которые вы планируете выйти в ближайший год",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Введите или выберите страну",
                    "sysName": "project_expansion",
                    "activity":
                    [
                        2000
                    ],
                    "required": false,
                    "localName": "Рынки, на которые планируете выходить",
                    "multySelect": true
                },
                {
                    "note": "Укажите стадию продаж вашего продукта",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Выберите тип продаж",
                    "sysName": "project_sales",
                    "activity":
                    [
                        5000
                    ],
                    "required": true,
                    "localName": "Продажи",
                    "multySelect": true,
                    "valueGroups": [
                        {
                            "1": "5001"
                        },
                        {
                            "2": "5002,5003,5004"
                        }
                    ]
                },
                {
                    "mask": "$",
                    "note": "Валовый оборот компании за последний год в $",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Оборот в год",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число",
                    "triggerField": "project_sales",
                    "triggerValue": "5002,5003,5004",
                    "exceptionList": [
                        4182
                    ]
                },
                {
                    "note": "Укажите конкурентов, близких к вам по типу продукта и бизнеса (если прямых конкурентов нет, укажите это)",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите название компаний-конкурентов",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Прямые конкуренты",
                    "maxLength": "300"
                },
                {
                    "note": "Перечислите предметно, чем вы лучше конкурентов",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите преимущества вашего продукта",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Преимущества перед конкурентами",
                    "maxLength": "300"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите названия",
                    "sysName": "questionnaire_acceleratorString",
                    "required": false,
                    "localName": "В каких акселераторах участвовал ваш стартап?",
                    "maxLength": "300",
                     "showLength": false
                }
            ],
            "module": "О продукте",
            "pageName": "Информация о стартапе 2/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "module": "Импортозамещение",
            "pageName": "Команда",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Заменяет ли ваш продукт какие-либо аналогичные сервисы или компании?*"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 2,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Названия заменяемых сервисов/компаний",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Укажите названия сервисов",
                    "maxLength": "10",
                    "note": "Перечислите через запятую не более 10 сервисов",
                     "multySelect": true
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "Как именно вы заменяете перечисленные сервисы/компании?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите кратко, в каком аспекте ваш продукт является аналогом указанных сервисов"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Преимущества перед перечисленными сервисами/компаниями",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Расскажите предметно, чем ваш продукт лучше замещаемого сервиса"
                }
            ]
        },
        {
            "page": 3,
            "title": "Укажите, какие ключевые должности в стартапе закрыты",
            "fields":
            [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Название должности",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Должность",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Опишите опыт сотрудника",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Краткое описание опыта",
                    "maxLength": "150"
                }
            ],
            "module": "Ключевые сотрудники",
            "isArray": "true",
            "pageName": "Команда",
            "actionText": "Добавить должность"
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "boolean",
                    "title": "Если вы В2В-, В2G-, B2B2C- стартап: есть ли у вас успешные пилоты или внедрения в корпорации?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Успешные пилоты",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Опишите, с какой корпорацией у вас был успешный кейс",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "С кем был успешный кейс",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Расскажите про кейс и его результаты",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Описание и результаты кейса",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "actionText": "Добавить кейс",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "boolean",
                    "title": "Заинтересованы ли вы в пилотировании вашего продукта в Экосистеме Сбера или у других корпораций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "title": "Предлагаемый кейс",
                    "edited": true,
                    "example": "Если у вас есть идеи, как можно пилотировать ваш продукт, опишите их в нескольких предложениях",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Есть ли у вас опыт взаимодействия с экосистемой Сбера?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "Экосистема Сбера",
            "pageName": "Пилотирование, первые продажи и внедрения",
            "information": "В экосистему Сбера входят десятки различных компаний. Ознакомьтесь подробнее на [сайте](https://www.sber.ru/ecosystem)"
        },
        {
            "page": 4,
            "fields":
            [
                {
                    "type": "boolean",
                    "title": "Находитесь ли вы в активном поиске инвестиций?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Общий объём ранее привлеченных инвестиций",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Необходимо указать число"
                },
                {
                    "note": "При условии, что раскрытие данной информации не противоречит договоренности с указанным инвестором",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Перечислите инвесторов, от которых получали инвестиции",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Список инвесторов",
                    "maxLength": "300"
                }
            ],
            "module": "Инвестиции",
            "pageName": "Инвестиции",
            "moduleNote": ""
        }
    ]
}'
where formname = 'startup_edit'
  and lang_id = 1;

update screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Full legal name of your company",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Name of organization",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Company identification number, for example, EIN",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Company identification number, for example, EIN",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Specify the year your company was founded",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Year of registration",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Other users of the platform will see it in your profile",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "For example, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Public name/Brand name",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Use short name without legal form"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select country of jurisdiction",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Country of jurisdiction",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Website",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Website",
                    "regExpError": "Please use specific format: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "John Doe",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Contact person"
                },
                {
                    "note": "This email will be visible to other platform users as your contact",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Provide contact email",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Email"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Phone number"
                }
            ],
            "module": "Organization",
            "pageName": "Legal information",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Resource",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity": [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Link",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Please use specific format: https://sber-unity.ru"
                }
            ],
            "module": "Additional links",
            "isArray": "true",
            "pageName": "Legal information",
            "actionText": "Add link",
            "moduleNote": "Specify links to external resources that give information about your product"
        },
        {
            "page": 2,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Describe your startup in one sentence",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Brief descriprion of your product",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Sales models",
                    "edited": true,
                    "format": "chip",
                    "values": [],
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "What is your business model?",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values": [],
                    "example": "Select your revenue model",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": true,
                    "localName": "What is your revenue model?",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Select your development stage",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": true,
                    "localName": "Startup stage",
                    "multySelect": false
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Specify total number of employees",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Number of employees"
                },
                {
                    "note": "Logo requirements: size should not exceed 200x200, 5mb, png or jpg",
                    "type": "logo",
                    "title": "Startup logo",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes": [
                        ".png",
                        "jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Link to the video",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Video about the product",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Please use specific link format: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Where is your startup based?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select country",
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Country",
                    "description": "Indicate where your startup''s headquarters are actually based",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Enter city",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "City",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "About the startup",
            "pageName": "Startup information 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select industries",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Industries",
                    "description": "Industries and technological verticals in which your startup operates",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select technologies",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Technologies",
                    "multySelect": true
                }
            ],
            "module": "Tech verticals",
            "pageName": "Startup information 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "What client needs does your product fulfill",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "The client problem that your product solves",
                    "maxLength": "300"
                },
                {
                    "note": "Age, occupation, interests, etc.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Describe your target audience",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Target audience",
                    "maxLength": "300"
                },
                {
                    "note": "File size should not exceed 20mb, pdf",
                    "type": "hyperlink",
                    "title": "Presentation",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes": [
                        ".pdf"
                    ]
                },
                {
                    "note": "Regions where your product is already presented",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Type or select country",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Countries of presence",
                    "multySelect": true
                },
                {
                    "note": "Markets that you plan to access in a year",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Type or select country",
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Markets that you are going to enter in the nearest future",
                    "multySelect": true
                },
                {
                    "note": "Indicate if you have sales",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Choose your sales stage",
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": true,
                    "localName": "Sales",
                    "multySelect": true
                },
                {
                    "mask": "$",
                    "note": "Gross turnover of the company for the last year",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Annual turnover",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Specify a number"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Specify your competitors",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Competitors",
                    "maxLength": "300"
                },
                {
                    "note": "Specify in detail why you are better than your competitors",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Tell about your advantages",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Advantages over competitors",
                    "maxLength": "300"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "List the titles",
                    "sysName": "questionnaire_acceleratorString",
                    "required": false,
                    "localName": "What acceleration programs has your startup participated in?",
                    "maxLength": "300",
                     "showLength": false
                }
            ],
            "module": "About the product",
            "pageName": "Startup information 2/2",
            "moduleNote": ""
        },{
            "page": 3,
            "module": "Import substitution",
            "pageName": "Startup information 2/2",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 1,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Name the products/companies you can substitute",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Specify the name of the service"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Tell us briefly in what aspect your product is an analogue of these services"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Tell us in detail how your product is better than the replaced service"
                }
            ]
        },
        {
            "page": 3,
            "title": "Tell about key team members",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Team member role/position",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Role",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Tell about your team member experience",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Brief role description",
                    "maxLength": "150"
                }
            ],
            "module": "Key employees",
            "isArray": "true",
            "pageName": "Team",
            "actionText": "Add team member"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "If you are B2B-, B2G-, B2B2C-startup: do you have successful pilot projects with corporations?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Successful pilot projects",
            "pageName": "Piloting, First sales and Integrations",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Specify company name",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "Company name you had a successful case with",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Provide detailed information on the results of the above-mentioned case",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Description and results of the pilot project",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Piloting, first sales and Integrations",
            "actionText": "Add case",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Are you interested in piloting your product with Sber or other corporations?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "If you have ideas on how to pilot your product, share them here",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "localName": "Suggest a case",
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Have you interacted with Sber Ecosystem?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "The Sber Ecosystem",
            "pageName": "Pilots",
            "information": "Sber Ecosystem includes a wide range of companies. Read more on the [website](https://www.sberbank.com/eco)"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Are you looking for investments?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Amount of previously raised investments, total",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Please specify a number"
                },
                {
                    "note": "Provided that the disclosure of this information does not contradict the agreements with investors",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "List the investors from your captable",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Investors list",
                    "maxLength": "300"
                }
            ],
            "module": "Investments",
            "pageName": "Investments",
            "moduleNote": ""
        }
    ]
}'
where formname = 'New_StartUp'
  and lang_id = 2;

update screen
set formedit = '{
    "form": [
        {
            "page": 1,
            "fields": [
                {
                    "type": "string",
                    "edited": true,
                    "example": "Full legal name of your company",
                    "sysName": "questionnaire_fullName",
                    "required": true,
                    "localName": "Name of organization",
                    "maxLength": 70,
                    "showLength": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Company identification number, for example, EIN",
                    "sysName": "questionnaire_inn",
                    "required": true,
                    "localName": "Company identification number, for example, EIN",
                    "maxLength": 40,
                    "showLength": false
                },
                {
                    "mask": "2000;getyear",
                    "type": "int",
                    "edited": true,
                    "format": "year",
                    "example": "Specify the year your company was founded",
                    "sysName": "questionnaire_birthYear",
                    "required": true,
                    "localName": "Year of registration",
                    "maxLength": 4,
                    "showLength": false
                },
                {
                    "note": "Other users of the platform will see it in your profile",
                    "type": "string",
                    "edited": true,
                    "regExp": "^((?!ОАО |ПАО |ЗАО |ООО |ИП |АО |ОАО\"|ПАО\"|ЗАО\"|ООО\"|ИП\"|АО\").)",
                    "example": "For example, SberUnity",
                    "sysName": "questionnaire_name",
                    "required": true,
                    "localName": "Public name/Brand name",
                    "maxLength": 70,
                    "showLength": false,
                    "regExpError": "Use short name without legal form"
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select country of jurisdiction",
                    "sysName": "questionnaire_registrationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Country of jurisdiction",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-zA-Zа-яА-Я0-9-.]+(\\.[a-zA-Zа-яА-Я]{2,}){1,3}(#?\\/?[a-zA-Zа-яА-Я0-9#-_]+)*\\/?(\\?[a-zA-Zа-яА-Я0-9-_]+=[a-zA-Zа-яА-Я0-9-%]+&?)?$",
                    "example": "Website",
                    "sysName": "questionnaire_site",
                    "required": true,
                    "localName": "Website",
                    "regExpError": "Please use specific format: https://sber-unity.ru"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "John Doe",
                    "sysName": "questionnaire_inviteFio",
                    "required": true,
                    "localName": "Contact person"
                },
                {
                    "note": "This email will be visible to other platform users as your contact",
                    "type": "string",
                    "edited": true,
                    "format": "e-mail",
                    "example": "Provide contact email",
                    "sysName": "questionnaire_email",
                    "required": true,
                    "localName": "Email"
                },
                {
                    "mask": "phone",
                    "type": "string",
                    "edited": true,
                    "format": "phone",
                    "example": "+",
                    "sysName": "questionnaire_phoneNumber",
                    "required": true,
                    "localName": "Phone number"
                }
            ],
            "module": "Organization",
            "pageName": "Legal information",
            "moduleNote": ""
        },
        {
            "page": 1,
            "fields": [
                {
                    "type": "array",
                    "title": "Resource",
                    "edited": true,
                    "format": "chip",
                    "sysName": "contacts[]_type",
                    "activity": [
                        21000
                    ],
                    "required": false,
                    "localName": "",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Link",
                    "sysName": "contacts[]_name",
                    "required": false,
                    "maxLength": "70",
                    "regExpError": "Please use specific format: https://sber-unity.ru"
                }
            ],
            "module": "Additional links",
            "isArray": "true",
            "pageName": "Legal information",
            "actionText": "Add link",
            "moduleNote": "Specify links to external resources that give information about your product"
        },
        {
            "page": 2,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Describe your startup in one sentence",
                    "sysName": "project_note",
                    "required": true,
                    "localName": "Brief descriprion of your product",
                    "maxLength": "200"
                },
                {
                    "type": "array",
                    "title": "Sales models",
                    "edited": true,
                    "format": "chip",
                    "values": [],
                    "sysName": "project_interactionType",
                    "activity": [
                        8000
                    ],
                    "required": true,
                    "localName": "",
                    "description": "What is your business model?",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "values": [],
                    "example": "Select your revenue model",
                    "sysName": "questionnaire_businessModel",
                    "activity": [
                        24000
                    ],
                    "required": true,
                    "localName": "What is your revenue model?",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "dropdown",
                    "example": "Select your development stage",
                    "sysName": "project_mvpCode",
                    "activity": [
                        27000
                    ],
                    "required": true,
                    "localName": "Startup stage",
                    "multySelect": false
                },
                {
                    "type": "int",
                    "edited": true,
                    "format": "[1;1000]",
                    "example": "Specify total number of employees",
                    "sysName": "project_staff",
                    "maxValue": 1000,
                    "minValue": 1,
                    "required": true,
                    "localName": "Number of employees"
                },
                {
                    "note": "Logo requirements: size should not exceed 200x200, 5mb, png or jpg",
                    "type": "logo",
                    "title": "Startup logo",
                    "edited": true,
                    "format": "1200*1200",
                    "sysName": "questionnaire_logoFile",
                    "required": true,
                    "maxLength": "5",
                    "allowedTypes": [
                        ".png",
                        "jpg"
                    ]
                },
                {
                    "type": "string",
                    "edited": true,
                    "regExp": "^((https|http?):\\/\\/){1}?(www.)?[a-z0-9-]+(\\.[a-z]{2,}){1,3}(#?\\/?[a-zA-Z0-9#-_]+)*\\/?(\\?[a-zA-Z0-9-_]+=[a-zA-Z0-9-%]+&?)?$",
                    "example": "Link to the video",
                    "sysName": "project_demoVideo",
                    "required": false,
                    "localName": "Video about the product",
                    "maxLength": "255",
                    "showLength": false,
                    "regExpError": "Please use specific link format: https://sber-unity.ru"
                },
                {
                    "type": "array",
                    "title": "Where is your startup based?",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select country",
                    "sysName": "questionnaire_locationCountry",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Country",
                    "description": "Indicate where your startup''s headquarters are actually based",
                    "multySelect": false
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Enter city",
                    "sysName": "questionnaire_location",
                    "required": true,
                    "localName": "City",
                    "maxLength": 30,
                    "showLength": false
                }
            ],
            "module": "About the startup",
            "pageName": "Startup information 1/2",
            "moduleNote": ""
        },
        {
            "page": 2,
            "fields": [
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select industries",
                    "sysName": "project_industry",
                    "activity": [
                        3000
                    ],
                    "required": true,
                    "localName": "Industries",
                    "description": "Industries and technological verticals in which your startup operates",
                    "multySelect": true
                },
                {
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Select technologies",
                    "sysName": "project_technology",
                    "activity": [
                        13000
                    ],
                    "required": true,
                    "localName": "Technologies",
                    "multySelect": true
                }
            ],
            "module": "Tech verticals",
            "pageName": "Startup information 1/2",
            "moduleNote": ""
        },
        {
            "page": 3,
            "fields": [
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "What client needs does your product fulfill",
                    "sysName": "project_problem",
                    "required": true,
                    "localName": "The client problem that your product solves",
                    "maxLength": "300"
                },
                {
                    "note": "Age, occupation, interests, etc.",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Describe your target audience",
                    "sysName": "project_auditory",
                    "required": true,
                    "localName": "Target audience",
                    "maxLength": "300"
                },
                {
                    "note": "File size should not exceed 20mb, pdf",
                    "type": "hyperlink",
                    "title": "Presentation",
                    "edited": true,
                    "format": "URL",
                    "sysName": "investment_businessPlan",
                    "required": true,
                    "localName": "",
                    "maxLength": "20",
                    "allowedTypes": [
                        ".pdf"
                    ]
                },
                {
                    "note": "Regions where your product is already presented",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Type or select country",
                    "sysName": "project_geography",
                    "activity": [
                        2000
                    ],
                    "required": true,
                    "localName": "Countries of presence",
                    "multySelect": true,
					"triggerField": "project_sales",
					"triggerValue": "5002,5003,5004",
					"exceptionList": [
						4182
					]
                },
                {
                    "note": "Markets that you plan to access in a year",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Type or select country",
                    "sysName": "project_expansion",
                    "activity": [
                        2000
                    ],
                    "required": false,
                    "localName": "Markets that you are going to enter in the nearest future",
                    "multySelect": true
                },
                {
                    "note": "Indicate if you have sales",
                    "type": "array",
                    "edited": true,
                    "format": "search_dropdown",
                    "example": "Choose your sales stage",
                    "sysName": "project_sales",
                    "activity": [
                        5000
                    ],
                    "required": true,
                    "localName": "Sales",
                    "multySelect": true,
                    "valueGroups": [
						{
							"1": "5001"
						},
						{
							"2": "5002,5003,5004"
						}
					]
                },
                {
                    "mask": "$",
                    "note": "Gross turnover of the company for the last year",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_turnover",
                    "required": true,
                    "localName": "Annual turnover",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Specify a number",
					"triggerField": "project_sales",
					"triggerValue": "5002,5003,5004",
					"exceptionList": [
						4182
					]
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Specify your competitors",
                    "sysName": "project_competitor",
                    "required": true,
                    "localName": "Competitors",
                    "maxLength": "300"
                },
                {
                    "note": "Specify in detail why you are better than your competitors",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Tell about your advantages",
                    "sysName": "project_upSide",
                    "required": true,
                    "localName": "Advantages over competitors",
                    "maxLength": "300"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "List the titles",
                    "sysName": "questionnaire_acceleratorString",
                    "required": false,
                    "localName": "What acceleration programs has your startup participated in?",
                    "maxLength": "300",
                     "showLength": false
                }
            ],
            "module": "About the product",
            "pageName": "Startup information 2/2",
            "moduleNote": ""
        },{
            "page": 3,
            "module": "Import substitution",
            "pageName": "Startup information 2/2",
            "fields": [
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_isImport",
                    "required": true,
                    "localName": "Does your product replace any similar services or companies?"
                },
                {
                    "type": "string",
                    "edited": true,
                    "format": "tags",
                    "dadataService": "/search?text=",
                    "dadataStart": 1,
                    "sysName": "importReplace_name",
                    "required": true,
                    "localName": "Name the products/companies you can substitute",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Specify the name of the service"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_note",
                    "required": true,
                    "localName": "How exactly do you replace the listed services/companies?",
                    "maxLength": "1000",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Tell us briefly in what aspect your product is an analogue of these services"
                },
                {
                    "type": "string",
                    "edited": true,
                    "sysName": "importReplace_benefits",
                    "required": true,
                    "localName": "Advantages over the listed services/companies",
                    "maxLength": "500",
                    "rows": "3",
                    "triggerField": "questionnaire_isImport",
                    "triggerValue": "true",
                    "example": "Tell us in detail how your product is better than the replaced service"
                }
            ]
        },
        {
            "page": 3,
            "title": "Tell about key team members",
            "fields": [
                {
                    "type": "long",
                    "edited": false,
                    "format": "hide",
                    "sysName": "workers[]_parentId",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "boolean",
                    "value": false,
                    "edited": true,
                    "format": "hide",
                    "sysName": "workers[]_isFounder",
                    "required": false,
                    "localName": ""
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Team member role/position",
                    "sysName": "workers[]_role",
                    "required": false,
                    "localName": "Role",
                    "maxLength": "100"
                },
                {
                    "type": "string",
                    "edited": true,
                    "example": "Tell about your team member experience",
                    "sysName": "workers[]_note",
                    "required": false,
                    "localName": "Brief role description",
                    "maxLength": "150"
                }
            ],
            "module": "Key employees",
            "isArray": "true",
            "pageName": "Team",
            "actionText": "Add team member"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "If you are B2B-, B2G-, B2B2C-startup: do you have successful pilot projects with corporations?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_successPilots",
                    "required": true
                }
            ],
            "module": "Successful pilot projects",
            "pageName": "Piloting, First sales and Integrations",
            "moduleNote": ""
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "array",
                    "value": "20007",
                    "edited": true,
                    "format": "hide",
                    "sysName": "b2bPilots[]_state",
                    "required": false,
                    "localName": ""
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Specify company name",
                    "sysName": "b2bPilots[]_reference",
                    "required": false,
                    "localName": "Company name you had a successful case with",
                    "maxLength": "140",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "Provide detailed information on the results of the above-mentioned case",
                    "sysName": "b2bPilots[]_suggestCase",
                    "required": false,
                    "localName": "Description and results of the pilot project",
                    "maxLength": "200",
                    "triggerField": "questionnaire_successPilots",
                    "triggerValue": "true"
                }
            ],
            "module": "",
            "isArray": "true",
            "pageName": "Piloting, first sales and Integrations",
            "actionText": "Add case",
            "triggerField": "questionnaire_successPilots",
            "triggerValue": "true"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Are you interested in piloting your product with Sber or other corporations?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "questionnaire_pilot",
                    "required": true
                },
                {
                    "type": "array",
                    "value": "20008",
                    "edited": true,
                    "format": "hide",
                    "sysName": "ecoPilot_state",
                    "required": false,
                    "localName": "",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "If you have ideas on how to pilot your product, share them here",
                    "sysName": "ecoPilot_suggestCase",
                    "required": false,
                    "localName": "Suggest a case",
                    "maxLength": "300",
                    "triggerField": "questionnaire_pilot",
                    "triggerValue": "true"
                },
                {
                    "type": "boolean",
                    "title": "Have you interacted with Sber Ecosystem?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "ecoPilot_experience",
                    "required": true,
                    "localName": ""
                }
            ],
            "module": "The Sber Ecosystem",
            "pageName": "Pilots",
            "information": "Sber Ecosystem includes a wide range of companies. Read more on the [website](https://www.sberbank.com/eco)"
        },
        {
            "page": 4,
            "fields": [
                {
                    "type": "boolean",
                    "title": "Are you looking for investments?",
                    "edited": true,
                    "format": "switch",
                    "sysName": "investment_investment",
                    "required": true
                },
                {
                    "mask": "$",
                    "type": "string",
                    "edited": true,
                    "regExp": "(^([0-9]{1,7}))",
                    "example": "$",
                    "sysName": "investment_lastInvestment",
                    "required": false,
                    "localName": "Amount of previously raised investments, total",
                    "maxLength": "300",
                    "showLength": false,
                    "regExpError": "Please specify a number"
                },
                {
                    "note": "Provided that the disclosure of this information does not contradict the agreements with investors",
                    "rows": "3",
                    "type": "string",
                    "edited": true,
                    "example": "List the investors from your captable",
                    "sysName": "investment_coInvestment",
                    "required": false,
                    "localName": "Investors list",
                    "maxLength": "300"
                }
            ],
            "module": "Investments",
            "pageName": "Investments",
            "moduleNote": ""
        }
    ]
}'
where formname = 'startup_edit'
  and lang_id = 2;
