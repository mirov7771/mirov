--liquibase formatted sql
--changeset Mirov AA:recm_page
delete from public.pages where uri = '/startup/recommended';

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('startup_recommended_az_ru', 'SberUnity', '/startup/recommended', 'SberUnity', 'auth', '{
	"features": [
		{
			"type": "participantSearch",
			"filterBar": {
				"acceptButtonShortText": "Применить",
				"acceptButtonText": "Применить фильтры",
				"placeholder": "Поиск",
				"resetButtonShortText": "Сбросить",
				"resetButtonText": "Сбросить фильтры",
				"title": "Фильтры"
			},
			"foundsTitle": "Найдено: {0}",
			"header": "Стартапы",
			"participant": "startup",
			"placeholder": "Поиск стартапа",
			"position": 3,
			"shownFromTitle": "Показано {0} из {1}",
			"sortLabels": {
				"alphabetically": "По алфавиту",
				"byUpdateDate": "По дате обновления"
			},
			"sysName": "startupsRecommend_ru_participantSearch",
			"title": "Рекомендованные",
			"isRecommended": true,
			"visible": true
		}
	]
}', 1);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('startup_recommended_az_en', 'SberUnity', '/startup/recommended', 'SberUnity', 'auth', '{
	"features": [
		{
			"type": "participantSearch",
			"filterBar": {
				"acceptButtonShortText": "Applu",
				"acceptButtonText": "Apply filters",
				"placeholder": "Search",
				"resetButtonShortText": "Clear",
				"resetButtonText": "Clear filters",
				"title": "Filters"
			},
			"foundsTitle": "Found: {0}",
			"header": "StartUp",
			"participant": "startup",
			"placeholder": "Search startup",
			"position": 3,
			"shownFromTitle": "Found {0} из {1}",
			"sortLabels": {
				"alphabetically": "Alphabetically",
				"byUpdateDate": "By modifing date"
			},
			"sysName": "startupsRecommend_ru_participantSearch",
			"title": "Recommended",
			"isRecommended": true,
			"visible": true
		}
	]
}', 2);