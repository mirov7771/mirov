--liquibase formatted sql
--changeset Molotkov D:SBERXTECH-249
UPDATE public.screen SET  formedit='{}'::json::json, formview='{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_investorType",
      "localName": "Тип инвестора",
      "type": "array",
      "format": "text",
      "activity": [
        11000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_fullName",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },
      {
        "sysName": "questionnaire_portfolioNote",
        "localName": "Краткое описание портфельного стартапа",
        "type": "string",
        "maxLength": "300",
        "edited": false,
        "required": false
      },{
        "sysName": "questionnaire_site",
        "localName": "Сайт",
        "type": "hyperlink",
        "edited": false,
        "required": false
      },{
        "sysName": "questionnaire_email",
        "localName": "Email",
        "type": "string",
        "edited": false,
        "required": false
      }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Направление инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География стартапов",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_round",
      "localName": "Стадии инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_note",
      "localName": "Особые условия инвестирования",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_allDealsNumber",
      "localName": "Количество стартапов, в которые инвестировал фонд",
      "type": "int",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_exitDealsNumber",
      "localName": "Количество выходов",
      "type": "int",
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "Портфель",
    "page": 1,
    "isArray": true,
    "fields": [{
      "sysName": "questionnairePilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_company",
      "localName": "Название стартапа",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}
'::json::json WHERE formname='investor_SuperClient';

UPDATE public.screen SET   formedit='{}'::json::json, formview='{
  "form": [{
    "module": "Основная информация",
    "page": 1,
    "fields": [{
      "sysName": "questionnaire_fullName",
      "localName": "Наименование корпорации",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_name",
      "localName": "Название/имя",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_industry",
      "localName": "Направление деятельности",
      "type": "array",
      "format": "text",
      "activity": [
        22000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_note",
      "localName": "Описание",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_innovationMethod",
      "localName": "Методы работы с инновациями",
      "type": "array",
      "format": "text",
      "activity": [4000],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_turnover",
      "localName": "Оборот",
      "type": "string",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_site",
      "localName": "Сайт корпорации",
      "type": "hyperlink",
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_email",
      "localName": "Email",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Работа со стартапами",
    "page": 1,
    "fields": [{
      "sysName": "project_industry",
      "localName": "Индустрия",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "questionnaire_stady",
      "localName": "Стадии развития продуктов",
      "type": "array",
      "format": "text",
      "activity": [
        7000
      ],
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "",
    "page": 1,
    "isArray": "true",
    "fields": [{
      "sysName": "questionnairePilots[]_pilotId",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "questionnairePilots[]_suggestCase",
      "localName": "Описание потребности",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }, {
    "module": "Инвестиции",
    "page": 1,
    "fields": [{
      "sysName": "investment_industry",
      "localName": "Индустрия",
      "type": "array",
      "format": "text",
      "activity": [
        3000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "investment_round",
      "localName": "Раунд инвестиций",
      "type": "array",
      "format": "text",
      "activity": [
        6000
      ],
      "edited": false,
      "required": false
    },{
      "sysName": "project_geography",
      "localName": "География",
      "type": "array",
      "format": "text",
      "activity": [
        2000
      ],
      "edited": false,
      "required": false
    }
    ]
  },{
    "module": "",
    "page": 1,
    "triggerField": "investment_investment",
    "triggerValue": "true",
    "isArray": true,
    "fields": [{
      "sysName": "successPilots[]_pilotid",
      "localName": "",
      "type": "int",
      "format": "hide",
      "edited": false,
      "required": false
    }, {
      "sysName": "successPilots[]_company",
      "localName": "Успешный кейсы",
      "type": "string",
      "edited": false,
      "required": false
    }
    ]
  }
  ]
}'::json::json WHERE formname='corporate_SuperClient';

