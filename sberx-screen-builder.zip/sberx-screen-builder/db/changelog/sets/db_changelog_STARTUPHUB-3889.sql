--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-3889
delete from public.pages where uri in ('/pilot', '/investors', '/startup', '/corporates', '/vas');
INSERT INTO public.pages (code, name, uri, description, page_type, page, lang_id) VALUES
('pilot_nz_unauth_ru','SberUnity', '/pilot','SberUnity','unauth','{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "pilot_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Пилоты",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "pilot_ru_pageTitle",
      "title": "Запросы корпораций на технологии",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "pilotSearch",
      "sysName": "pilot_ru_pilotSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Введите название"
    }
  ]
}',1),
('pilot_nz_unauth_en','SberUnity', '/pilot','SberUnity','unauth','{
    "features": [
      {
        "type": "breadcrumbs",
        "sysName": "pilot_en_breadcrumbs",
        "visible": true,
        "position": 1,
        "items": [
          {
            "name": "Main",
            "pathname": "/",
            "id":1
          },
          {
            "name": "Pilots",
            "id":2
          }
        ]
      },
      {
        "type": "pageTitle",
        "visible": true,
        "position": 2,
        "sysName": "pilot_en_pageTitle",
        "title": "Corporate technology requests",
        "config": {
          "styles": {
            "padding": {
              "xs": {
                "top": 16,
                "bottom": 24
              },
              "s": {
                "top": 16,
                "bottom": 24
              },
              "md": {
                "top": 24,
                "bottom": 32
              },
              "lg": {
                "top": 24,
                "bottom": 32
              }
            }
          }
        }
      },
      {
        "type": "pilotSearch",
        "sysName": "pilot_en_pilotSearch",
        "visible": true,
        "position": 3,
        "placeholder": "Enter a name"
      }
    ]
  }',2),
('investors_nz_unauth_ru','SberUnity', '/investors','SberUnity','unauth','{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "investor_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Инвесторы",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "investor_ru_pageTitle",
      "title": "Найди своего инвестора",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "investor_ru_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Введите название или воспользуйтесь фильтром",
      "participant": "investor",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}"
    }
  ]
}',1),
('investors_nz_unauth_en','SberUnity', '/investors','SberUnity','unauth','{
    "features": [
      {
        "type": "breadcrumbs",
        "sysName": "investor_en_breadcrumbs",
        "visible": true,
        "position": 1,
        "items": [
          {
            "name": "Main",
            "pathname": "/",
            "id":1
          },
          {
            "name": "Investors",
            "id":2
          }
        ]
      },
      {
        "type": "pageTitle",
        "visible": true,
        "position": 2,
        "sysName": "investor_en_pageTitle",
        "title": "Find your investor",
        "config": {
          "styles": {
            "padding": {
              "xs": {
                "top": 16,
                "bottom": 24
              },
              "s": {
                "top": 16,
                "bottom": 24
              },
              "md": {
                "top": 24,
                "bottom": 32
              },
              "lg": {
                "top": 24,
                "bottom": 32
              }
            }
          }
        }
      },
      {
        "type": "participantSearch",
        "sysName": "investor_en_participantSearch",
        "visible": true,
        "position": 3,
        "placeholder": "Enter name or use the filter",
        "participant": "investor",
        "shownFromTitle": "Shown {0} of {1}",
        "foundsTitle": "Find: {0}"
      }
    ]
  }',2),
('startups_nz_unauth_ru','SberUnity', '/startup','SberUnity','unauth','{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "startups_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Найти стартап",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "startups_ru_pageTitle",
      "title": "Стартапы, которые уже с нами",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "startups_ru_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Поиск стартапа",
      "participant": "startup",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}",
      "features": [
        {
          "type": "authBanner",
          "sysName": "authBanner",
          "visible": true,
          "position": 1,
          "typeBanner": "participantSearch",
          "title": "Больше стартапов",
          "caption": "Доступно после регистрации на платформе SberUnity",
          "mainButtonText": "Присоединиться",
          "secondButtonText": "Войти",
          "config": {
            "nowrap": true
          }
        }
      ]
    }
  ]
}',1),
('startups_nz_unauth_en','SberUnity', '/startup','SberUnity','unauth','{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "startups_en_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Main",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Find a startup",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "startups_en_pageTitle",
      "title": "Startups on the platform",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "startups_en_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Search startups",
      "participant": "startup",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}",
      "features": [
        {
          "type": "authBanner",
          "sysName": "startups_en_authBanner",
          "visible": true,
          "position": 1,
          "typeBanner": "participantSearch",
          "title": "More startups",
          "caption": "Available after registration on the SberUnity platform",
          "mainButtonText": "Join",
          "secondButtonText": "Log in",
          "config": {
            "nowrap": true
          }
        }
      ]
    }
  ]
}',2),
('corporates_nz_unauth_ru','SberUnity', '/corporates','SberUnity','unauth','{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "corporates_ru_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Главная",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Корпорации",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "corporates_ru_pageTitle",
      "title": "Станьте партнером корпорации",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "corporates_ru_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Введите название",
      "participant": "corporation",
      "shownFromTitle": "Показано {0} из {1}",
      "foundsTitle": "Найдено: {0}"
    }
  ]
}',1),
('corporates_nz_unauth_en','SberUnity', '/corporates','SberUnity','unauth','{
  "features": [
    {
      "type": "breadcrumbs",
      "sysName": "corporates_en_breadcrumbs",
      "visible": true,
      "position": 1,
      "items": [
        {
          "name": "Main",
          "pathname": "/",
          "id":1
        },
        {
          "name": "Corporation",
          "id":2
        }
      ]
    },
    {
      "type": "pageTitle",
      "visible": true,
      "position": 2,
      "sysName": "corporates_en_pageTitle",
      "title": "Become a corporation partner",
      "config": {
        "styles": {
          "padding": {
            "xs": {
              "top": 16,
              "bottom": 24
            },
            "s": {
              "top": 16,
              "bottom": 24
            },
            "md": {
              "top": 24,
              "bottom": 32
            },
            "lg": {
              "top": 24,
              "bottom": 32
            }
          }
        }
      }
    },
    {
      "type": "participantSearch",
      "sysName": "corporates_en_participantSearch",
      "visible": true,
      "position": 3,
      "placeholder": "Enter name",
      "participant": "corporation",
      "shownFromTitle": "Shown {0} of {1}",
      "foundsTitle": "Find: {0}"
    }
  ]
}',2),
('vas_nz_unauth_ru','SberUnity', '/vas','SberUnity','unauth','{
   "features":[
      {
         "type":"breadcrumbs",
         "sysName":"breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Главная",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Сервисы"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"pageTitle",
         "title":"Эксклюзивные предложения для стартапов",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vasSearch",
         "visible":true,
         "position":2,
         "placeholder":"Введите название"
      }
   ]
}',1),
('vas_nz_unauth_en','SberUnity', '/vas','SberUnity','unauth','{
   "features":[
      {
         "type":"breadcrumbs",
         "sysName":"breadcrumbs",
         "visible":true,
         "position":1,
         "items":[
            {
               "id":1,
               "name":"Main",
               "pathname":"/"
            },
            {
               "id":2,
               "name":"Services"
            }
         ]
      },
      {
         "type":"pageTitle",
         "visible":true,
         "position":1,
         "sysName":"pageTitle",
         "title":"Exclusive offers for startups",
         "config":{
            "styles":{
               "padding":{
                  "xs":{
                     "top":16,
                     "bottom":24
                  },
                  "s":{
                     "top":16,
                     "bottom":24
                  },
                  "md":{
                     "top":24,
                     "bottom":32
                  },
                  "lg":{
                     "top":24,
                     "bottom":32
                  }
               }
            }
         }
      },
      {
         "type":"vasSearch",
         "sysName":"vasSearch",
         "visible":true,
         "position":2,
         "placeholder":"Enter a name"
      }
   ]
}',2);