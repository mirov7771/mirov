--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-3805

update public.values
set  value='5' where id = (select id_values from public.feature_attributes_values where id_attributes=2 and id_features=18);

update public.values
set value='Разделите деловые и личный мессенджеры_|_Структурируйте инофрмацию в тематических каналах_|_Только релевантные сообщения, без спама и рекламы_|_Полная информация о любой сделке всегда в паре кликов'
where value='Разделите деловые и личный мессенджеры_|_Структурируйте инофрмацию в тематических каналах_|_Только релевантные сообщения, без спама и рекламы_|_Полная информация о сделке всегда доступна';