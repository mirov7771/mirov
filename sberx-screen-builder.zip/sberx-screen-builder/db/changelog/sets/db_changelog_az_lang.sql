--liquibase formatted sql
--changeset Mirov AA:az_lang
delete from public.pages where page_type = 'auth' and uri in ('/corporates', '/investors', '/startups', '/startup');

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('corporates_nz_auth_ru', 'SberUnity', '/corporates', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "corporates_ru_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Введите название",
            "participant": "corporation",
            "shownFromTitle": "Показано {0} из {1}",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "sortLabels": {
                "alphabetically": "По алфавиту",
                "byUpdateDate": "По дате обновления",
                "byCreationDate": "По дате создания"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            }
        }
    ]
}', 1);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('investors_nz_auth_ru', 'SberUnity', '/investors', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "investor_ru_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Введите название или воспользуйтесь фильтром",
            "participant": "investor",
            "shownFromTitle": "Показано {0} из {1}",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "sortLabels": {
                "alphabetically": "По алфавиту",
                "byUpdateDate": "По дате обновления",
                "byCreationDate": "По дате создания"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            }
        }
    ]
}', 1);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('startups_nz_auth_ru', 'SberUnity', '/startup', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "startups_ru_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Поиск стартапа",
            "participant": "startup",
            "shownFromTitle": "Показано {0} из {1}",
            "foundsTitle": "Найдено: {0}",
            "filterBar": {
                "title": "Фильтры",
                "acceptButtonText": "Применить фильтры",
                "resetButtonText": "Сбросить фильтры",
                "acceptButtonShortText": "Применить",
                "resetButtonShortText": "Сбросить",
                "placeholder": "поиск"
            },
            "sortLabels": {
                "alphabetically": "По алфавиту",
                "byUpdateDate": "По дате обновления",
                "byCreationDate": "По дате создания"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Избранные",
                "viewedLabel": "Просмотренное",
                "emptyFavoriteLabel": "Вы пока ничего не добавили в избранное"
            }
        }
    ]
}', 1);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('corporates_nz_auth_en', 'SberUnity', '/corporates', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "corporates_en_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Enter name",
            "participant": "corporation",
            "shownFromTitle": "Shown {0} of {1}",
            "foundsTitle": "Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
            "sortLabels": {
                "alphabetically": "Alphabetically",
                "byUpdateDate": "By creation date",
                "byCreationDate": "By update date"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Favorite",
                "viewedLabel": "Viewed",
                "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
            }
        }
    ]
}', 2);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('investors_nz_auth_en', 'SberUnity', '/investors', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "investor_en_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Enter name or use the filter",
            "participant": "investor",
            "shownFromTitle": "Shown {0} of {1}",
            "foundsTitle": "Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
            "sortLabels": {
                "alphabetically": "Alphabetically",
                "byUpdateDate": "By creation date",
                "byCreationDate": "By update date"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Favorite",
                "viewedLabel": "Viewed",
                "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
            }
        }
    ]
}', 2);

insert into public.pages (code, name, uri, description, page_type, page, lang_id)
values ('startups_nz_auth_en', 'SberUnity', '/startup', 'SberUnity', 'auth', '{
    "features": [
        {
            "type": "participantSearch",
            "sysName": "startups_en_participantSearch",
            "visible": true,
            "position": 3,
            "placeholder": "Search startups",
            "participant": "startup",
            "shownFromTitle": "Shown {0} of {1}",
            "foundsTitle": "Find: {0}",
            "filterBar": {
                "title": "Filters",
                "acceptButtonText": "Apply filter",
                "resetButtonText": "Clear filter",
                "acceptButtonShortText": "Apply",
                "resetButtonShortText": "Clear",
                "placeholder": "search"
            },
            "sortLabels": {
                "alphabetically": "Alphabetically",
                "byUpdateDate": "By creation date",
                "byCreationDate": "By update date"
            },
            "fastFilterLabels": {
                "favoriteLabel": "Favorite",
                "viewedLabel": "Viewed",
                "emptyFavoriteLabel": "You haven''t added anything to your favorites yet"
            }
        }
    ]
}', 2);