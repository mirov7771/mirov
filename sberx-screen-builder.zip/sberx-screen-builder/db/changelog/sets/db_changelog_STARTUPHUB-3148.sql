--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-3148
alter table public.features
    add column client_id varchar;

alter table public.pages
    add column client_id varchar;
