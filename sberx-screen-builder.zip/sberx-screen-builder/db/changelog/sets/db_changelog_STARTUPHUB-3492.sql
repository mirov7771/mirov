--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3492
update public.screen set
    formview = '{
    "form": [
        {
            "module": "Основная информация",
            "page": 1,
            "pageName": "",
            "fields": [
                {
                    "sysName": "name",
                    "localName": "В каком сообществе Вы уже состоите?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "position",
                    "localName": "Должность",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "site",
                    "localName": "Сайт проекта",
                    "type": "hyperlink",
                    "format": "button",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "industry",
                    "localName": "В какие направления инвестируете?",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        3000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "geography",
                    "localName": "Интересующая география инвестиций",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        2000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "round",
                    "localName": "Интересующие стадии инвестиций",
                    "type": "array",
                    "format": "text",
                    "activity": [
                        7000
                    ],
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "expectation",
                    "localName": "Что вы ожидаете получить от сообщества?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "useful",
                    "localName": "Что вы можете дать сообществу?",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "ventureProjectsCount",
                    "localName": "Количество венчурных проектов в портфеле",
                    "type": "int",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "email",
                    "localName": "Электронная почта",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "phoneNumber",
                    "localName": "Номер телефона для связи",
                    "type": "string",
                    "edited": false,
                    "required": false
                },
                {
                    "sysName": "facebook",
                    "localName": "Ваш аккаунт в Facebook",
                    "type": "hyperlink",
                    "format": "button",
                    "edited": false,
                    "required": false
                }
            ]
        }
    ]
}'
where formname = 'community_Administrator'
