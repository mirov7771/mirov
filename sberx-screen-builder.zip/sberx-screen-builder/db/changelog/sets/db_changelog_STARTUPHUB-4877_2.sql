--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4877_2
update screen
   set formedit = cast(replace(cast(formedit as text),'"dadataStart": 3','"dadataStart": 1') as json )
where cast(formedit as text) like '%"dadataStart": 3%';