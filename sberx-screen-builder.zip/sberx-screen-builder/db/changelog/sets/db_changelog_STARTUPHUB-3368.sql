--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3368
update public.buttons
    set click_action = '/main/startups/{id}'
where code = '100000';