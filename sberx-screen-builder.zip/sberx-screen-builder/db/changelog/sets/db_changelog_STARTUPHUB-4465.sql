--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4465
UPDATE screen
SET  formedit='{
  "form": [
    {
      "page": 1,
      "module": "Основная информация",
      "moduleNote": "",
      "fields": [
        {
          "rows": "1",
          "type": "string",
          "edited": true,
          "example": "Название предлагаемого пилота",
          "sysName": "reply_offerName",
          "required": true,
          "localName": "Название пилота",
          "maxLength": "140"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Расскажите о предлагаемой технологии",
          "sysName": "reply_offerDescription",
          "required": true,
          "localName": "Краткое описание пилота",
          "maxLength": "500"
        },
        {
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Описание",
          "sysName": "reply_note",
          "required": true,
          "localName": "Какую потребность корпорации вы решите?",
          "maxLength": "300"
        },
        {
          "mask": "$",
          "note": "Сумма, в которую вы оцениваете ваш пилотный запуск",
          "type": "string",
          "edited": true,
          "example": "$",
          "sysName": "reply_cost",
          "required": false,
          "localName": "Какова стоимость вашего решения",
          "maxLength": "30"
        },
        {
          "note": "Сроки, шаги, спецусловия, ограничения и т.п.",
          "rows": "3",
          "type": "string",
          "edited": true,
          "example": "Комментарий",
          "sysName": "reply_process",
          "required": true,
          "localName": "Как вы видите процесс пилотирования",
          "minLength": "50",
          "maxLength": "500"
        }
      ]
    },
    {
      "page": 1,
      "module": "Презентация",
      "moduleNote": "",
      "fields": [
        {
          "note": "Вес файла — не более 5 МБ, формата PDF",
          "type": "hyperlink",
          "edited": true,
          "format": "URL",
          "sysName": "reply_fileURL",
          "required": false,
          "localName": "Презентация",
          "description": "Повышает шансы заинтересовать инвесторов и корпорации, но необязательна",
          "maxLength": "5",
          "allowedTypes": [
            ".pdf"
          ]
        }
      ]
    }
  ]
}'
where "type"=7 and formname='offer_Client' and lang_id=1;