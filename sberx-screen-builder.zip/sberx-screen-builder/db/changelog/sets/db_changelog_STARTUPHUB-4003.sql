--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4003
delete
from public.screen_buttons_link sbl
where screen_id in (
    select screen_id
    from public.screen_button sb
    where success_pilot_check is null
      and name = 'corporate_SuperClient'
      and state = 20004
)
  and button_id in (
    select button_id
    from public.buttons b
    where code = '100001'
);
