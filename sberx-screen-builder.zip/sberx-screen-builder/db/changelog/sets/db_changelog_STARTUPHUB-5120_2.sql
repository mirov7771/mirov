--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5120
update public.screen
set formedit = '{
  "form":
  [
    {
      "page": 1,
      "fields":
      [
        {
          "localName": "Тип метрики",
          "example": "Выберите тип",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "search_dropdown",
          "sysName": "type",
          "multySelect": false
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "1"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "2"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "3"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "4"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "5"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "6"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "7"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "9"
        },
        {
          "localName": "Валюта",
          "type": "array",
          "required": true,
          "edited": true,
          "format": "chip",
          "sysName": "currency",
          "multySelect": false,
          "activity":
          [
            41000
          ],
          "triggerField": "type",
          "triggerValue": "10"
        }
      ]
    },
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
      "isArray": "true",
      "actionText": "Добавить значение",
      "isControlShow": true,
      "triggerField": "currency",
      "triggerValue": "",
      "fields":
      [
        {
          "sysName": "items_value",
          "localName": "Значение",
          "type": "int",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Введите число"
        },
        {
          "sysName": "items_date",
          "localName": "Дата",
          "type": "date",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Укажите дату",
          "maxDate": "",
          "dateError": "Дата указана неверно"
        }
      ]
    },
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
      "isArray": "true",
      "actionText": "Добавить значение",
      "isControlShow": true,
      "triggerField": "currency",
      "triggerValue": "41001",
      "fields":
      [
        {
          "sysName": "items_value",
          "localName": "Значение",
          "type": "int",
          "edited": true,
          "required": true,
          "mask": "$",
          "direction": "row",
          "example": "Введите число"
        },
        {
          "sysName": "items_date",
          "localName": "Дата",
          "type": "date",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Укажите дату",
          "maxDate": "",
          "dateError": "Дата указана неверно"
        }
      ]
    },
    {
      "page": 1,
      "module": "Значения метрики",
      "moduleNote": "Укажите известные вам значения метрики в определённую дату. Вы сможете добавлять значения после добавления метрики.",
      "isArray": "true",
      "actionText": "Добавить значение",
      "isControlShow": true,
      "triggerField": "currency",
      "triggerValue": "41002",
      "fields":
      [
        {
          "sysName": "items_value",
          "localName": "Значение",
          "type": "int",
          "edited": true,
          "required": true,
          "mask": "₽",
          "direction": "row",
          "example": "Введите число"
        },
        {
          "sysName": "items_date",
          "localName": "Дата",
          "type": "date",
          "edited": true,
          "required": true,
          "direction": "row",
          "example": "Укажите дату",
          "maxDate": "",
          "dateError": "Дата указана неверно"
        }
      ]
    }
  ]
}'
where formname = 'add_metric'
  and lang_id = 1;

update public.screen
set formedit = '{
  "form":
  [
    {
      "page": 1,
      "moduleNote": "Укажите известные значения метрики %metricName% в определённые даты",
      "isArray": "true",
      "actionText": "Добавить значение",
      "isControlShow": true,
      "fields":
      [
        {
          "type": "int",
          "required": false,
          "edited": false,
          "format": "hide",
          "sysName": "items_type",
          "direction": "row",
          "localName": ""
        },
        {
          "localName": "Значение",
          "example": "Выберите число",
          "type": "int",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_value"
        },
        {
          "localName": "Дата",
          "example": "Укажите дату",
          "type": "date",
          "required": true,
          "edited": true,
          "direction": "row",
          "sysName": "items_date",
          "maxDate": "",
          "dateError": "Дата указана неверно"
        }
      ]
    }
  ]
}'
where formname = 'add_metric_values'
  and lang_id = 1;