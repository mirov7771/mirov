# Сервис работы с анкетой

### sberx-questionary service

Confluence: https://sbtatlas.sigma.sbrf.ru/wiki/pages/viewpage.action?pageId=3930230035