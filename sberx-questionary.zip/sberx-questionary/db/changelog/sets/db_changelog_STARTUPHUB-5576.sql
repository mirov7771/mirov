--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5576
create table if not exists questionnaire_local
(
    uuid uuid,
    questionnaireid bigint not null,
    lang varchar(3),
    fullname varchar(255),
    inn varchar(255),
    birthday timestamp without time zone,
    name varchar(255),
    registrationCountry bigint,
    site text,
    inviteFio varchar(255),
    email varchar(50) null,
    phonenumber varchar(30) null,
    logo_file text,
    accelerator_string varchar,
    fullNote text,
    note text,
    primary key(questionnaireid, lang)
);

create table if not exists project_local
(
    projectid bigint not null,
    lang varchar(3),
    note text,
    demoVideo varchar (300),
    problem text,
    auditory varchar(400),
    competitor varchar(400),
    upside varchar(400),
    primary key(projectid, lang)
);

create table if not exists investment_local
(
    questionnaireid bigint,
    lang varchar(3),
    businessplan varchar(255),
    investment boolean default false,
    lastinvestment varchar(300),
    coinvestment varchar(300),
    primary key(questionnaireid, lang)
);

create table if not exists import_replace_lang
(

    questionnaireid bigint,
    lang varchar(3),
    note text,
    benefits text,
    primary key(questionnaireid, lang)
);

alter table questionnaire add column if not exists languages varchar(3)[];
alter table questionnaire add column if not exists main_language varchar(3);
alter table contact add column if not exists lang varchar(3);
alter table worker add column if not exists lang varchar(3);
alter table pilot add column if not exists lang varchar(3);