--liquibase formatted sql
--changeset Belov DI:ROUND
ALTER TABLE round
    ADD marketing_percent integer,
    ADD software_percent integer,
    ADD team_percent integer,
    ADD extension_percent integer,
    ADD other_description varchar (150),
    ADD other_percent integer,
    ADD invite_fio varchar (150),
    ADD email varchar (150),
    ADD phone varchar (30);