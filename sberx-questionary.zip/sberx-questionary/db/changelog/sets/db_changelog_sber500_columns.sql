--liquibase formatted sql
--changeset Mirov AA:sber500_columns
ALTER TABLE public.SBER_FIVE_HUNDRED ALTER COLUMN "month_revenue" TYPE varchar USING "month_revenue"::varchar;
ALTER TABLE public.SBER_FIVE_HUNDRED ALTER COLUMN "quarter_revenue" TYPE varchar USING "quarter_revenue"::varchar;