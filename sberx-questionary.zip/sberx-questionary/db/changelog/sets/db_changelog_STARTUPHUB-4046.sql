--liquibase formatted sql
--changeset Leskov LS:STARTUPHUB-4046
alter table public.questionnaire add update_date_for_sort timestamp null;

update public.questionnaire set update_date_for_sort = modified;