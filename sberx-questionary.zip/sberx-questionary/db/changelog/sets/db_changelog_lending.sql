--liquibase formatted sql
--changeset Mirov AA:lending
update questionnaire set forlending = true where questionnaireid in (1, 84, 95, 93, 87, 77, 91, 111);
