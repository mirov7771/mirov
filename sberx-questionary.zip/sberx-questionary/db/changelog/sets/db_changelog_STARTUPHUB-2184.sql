--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2184
ALTER TABLE pilot ADD demofile varchar(350) null;