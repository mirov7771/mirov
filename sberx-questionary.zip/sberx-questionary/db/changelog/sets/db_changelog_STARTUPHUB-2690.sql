--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2690
ALTER TABLE popup_info DROP constraint if exists popup_info_questionnaireid_fkey;