--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5106
alter table object_favorite add column if not exists user_id bigint null;
alter table round_favorite add column if not exists user_id bigint null;

update object_favorite
set user_id = (
    select userid
    from user_questionnaire q
    where q.questionnaireid = object_favorite.questionnaire_id
    limit 1
);

update round_favorite
set user_id = (
    select userid
    from user_questionnaire q
    where q.questionnaireid = round_favorite.questionnaire_id
    limit 1
);
