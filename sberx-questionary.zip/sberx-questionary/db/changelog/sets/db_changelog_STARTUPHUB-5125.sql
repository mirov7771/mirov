--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5125
alter table POPUP_INFO add column if not exists USER_ID bigint null;

update POPUP_INFO
set user_id = (
    select userid
    from user_questionnaire q
    where q.questionnaireid = POPUP_INFO.questionnaireid
    limit 1
);
