--liquibase formatted sql
--changeset Zakutskiy MY:drop-not-null-fullname
alter table questionnaire alter column fullname drop not null;
alter table questionnaire alter column name drop not null;