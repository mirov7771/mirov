--liquibase formatted sql
--changeset Mirov AA:scouting_db
alter table scouting_application add column if not exists questionnaire_id bigint;