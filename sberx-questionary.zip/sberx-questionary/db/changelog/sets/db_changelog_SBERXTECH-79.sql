--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-79
update questionnaire set email = 'sberunity@sberbank.ru', round = '{6001,6002,6003,6004,6005}',
                                stady = '{7001,7002,7003,7004,7005,7006,7007}',industry = '{3003
, 3005
, 3001
, 3002
, 3004
, 3041
, 3006
, 3007
, 3008
, 3009
, 3010
, 3039
, 3011
, 3012
, 3013
, 3014
, 3015
, 3016
, 3017
, 3018
, 3019
, 3037
, 3020
, 3036
, 3021
, 3022
, 3023
, 3025
, 3024
, 3035
, 3026
, 3028
, 3027
, 3029
, 3030
, 3031
, 3032
, 3040
, 3038
, 3033
, 3034}'
where questionnaireid = (
    select questionnaireid from public.questionnaire q where name = 'Сбер'
);

update representative set email = 'sberunity@sberbank.ru' where questionnaireid = (
    select questionnaireid from public.questionnaire q where name = 'Сбер'
);

update project set
    industry = '{3003
, 3005
, 3001
, 3002
, 3004
, 3041
, 3006
, 3007
, 3008
, 3009
, 3010
, 3039
, 3011
, 3012
, 3013
, 3014
, 3015
, 3016
, 3017
, 3018
, 3019
, 3037
, 3020
, 3036
, 3021
, 3022
, 3023
, 3025
, 3024
, 3035
, 3026
, 3028
, 3027
, 3029
, 3030
, 3031
, 3032
, 3040
, 3038
, 3033
, 3034}'
where questionnaireid = (
    select questionnaireid from public.questionnaire q where name = 'Сбер'
);