--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4708_5
delete from popup_info where status = 'corporate_import';
