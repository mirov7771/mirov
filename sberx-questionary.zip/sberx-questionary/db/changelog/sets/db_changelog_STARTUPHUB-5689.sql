--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5689
alter table response add column if not exists lang varchar(3);
update response r set lang = (select p.lang from pilot p where p.pilotid = r.pilotid) where lang is null;
update response set lang = 'ru' where lang is null;

create table if not exists pilot_local(
    pilotid bigint not null,
    lang varchar(3),
    name varchar (255),
    suggestcase varchar (655),
    businessunit varchar (255),
    demofile varchar(350),
    primary key(pilotid, lang)
    );

truncate pilot_local;
insert into pilot_local
select p.pilotid,
       case when p.lang is null then 'ru' else p.lang end,
       p.name,
       p.suggestcase,
       p.businessunit,
       p.demofile
from pilot p;
update pilot_local set lang = 'ru' where lang is null;

alter table pilot drop column if exists lang;

