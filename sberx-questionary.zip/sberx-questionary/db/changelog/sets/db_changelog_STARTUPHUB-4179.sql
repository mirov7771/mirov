--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4179
create table if not exists table_comment
(
    id bigserial,
    table_id bigint,
    table_name varchar(50),
    body text,
    date timestamptz,
    user_id bigint,
    role varchar(100),
    edited boolean default false
);

CREATE TABLE if not exists reply (
    replyid bigserial NOT NULL,
    tablename varchar(50) NULL,
    tableid int8 NULL,
    userid int8 NULL,
    note text NULL,
    fileurl text NULL,
    "date" timestamp NULL,
    state int8 NULL,
    "cost" varchar NULL,
    process varchar NULL,
    isviewed bool NULL,
    "comment" varchar NULL,
    modified timestamp NULL,
    ispilotoffer bool NULL DEFAULT false,
    offername varchar NULL,
    offerdescription text NULL,
    CONSTRAINT reply_pkey PRIMARY KEY (replyid)
);
CREATE INDEX x1_reply ON reply USING btree (tableid, tablename);

CREATE TABLE question_link (
     questionid bigserial NOT NULL,
     responsenote text NULL,
     replyid int8 NULL,
     responseid int8 NULL,
     question varchar(255) NULL,
     CONSTRAINT question_link_pkey PRIMARY KEY (questionid)
);
CREATE INDEX x1_question_link ON question_link USING btree (replyid);