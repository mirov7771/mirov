--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3346
alter table community_application drop column if exists preauth;
alter table community_application add column preauth boolean null default true;