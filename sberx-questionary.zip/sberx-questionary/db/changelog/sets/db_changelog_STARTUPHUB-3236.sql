--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3236
alter table questionnaire add column send_invest_notify bool NULL DEFAULT false ;

