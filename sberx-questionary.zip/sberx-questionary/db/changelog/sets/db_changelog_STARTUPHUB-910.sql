--liquibase formatted sql
--changeset Mirov AA:update_sber_questionary
UPDATE questionnaire SET note = 'Сбер — больше, чем банк. Мы окружаем клиентов сервисами на все случаи жизни — от покупки продуктов до передвижения по городу' WHERE name = 'Сбер'