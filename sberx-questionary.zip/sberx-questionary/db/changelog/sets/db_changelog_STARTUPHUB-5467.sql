--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5467
drop table if exists recommend_notification;
create table recommend_notification (
 id bigserial primary key,
 questionnaire_id bigint,
 user_id bigint,
 notification_date timestamp,
 notification_questionnaire_id bigint[]
);
