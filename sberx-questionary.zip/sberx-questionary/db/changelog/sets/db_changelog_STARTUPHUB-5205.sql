--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5205
alter table object_action add column if not exists created timestamp null;

