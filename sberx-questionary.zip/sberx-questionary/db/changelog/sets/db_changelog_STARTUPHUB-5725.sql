--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-5725

UPDATE popup_info
SET  watched=false , "date"=NULL
WHERE status='community';