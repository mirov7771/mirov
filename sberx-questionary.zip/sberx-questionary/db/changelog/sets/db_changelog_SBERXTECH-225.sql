--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-225
ALTER TABLE questionnaire ADD transcription varchar(255) null;