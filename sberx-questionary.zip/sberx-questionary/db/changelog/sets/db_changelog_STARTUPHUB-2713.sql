--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2713
ALTER TABLE questionnaire ADD inn varchar(50) null;