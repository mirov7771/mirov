--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3402
drop table if exists sber_five_hundred;
create table sber_five_hundred
(
    questionnaire_id bigint primary key,
    first_time       boolean DEFAULT false,
    motivation       varchar(1000),
    month_revenue    bigint,
    quarter_revenue  bigint,
    clients          integer,
    eco_requirement  integer[]
);