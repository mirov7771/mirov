--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4439
alter table STATUS_INFO add column if not exists uid varchar null;