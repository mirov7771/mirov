--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5379
update tariff_settings set sysname = 'CorpLight', name = 'Light' where sysname = 'CorpDemo';
update tariff_settings set sysname = 'InvestLight', name = 'Light' where sysname = 'InvestDemo';

update tariff set sysname = 'CorpLight' where sysname = 'CorpDemo';
update tariff set sysname = 'InvestLight' where sysname = 'InvestDemo';

update application set tariff = 'CorpLight' where tariff = 'CorpDemo';
update application set tariff = 'InvestLight' where tariff = 'InvestDemo';
