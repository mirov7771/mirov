--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2293-2
alter table application add column comment varchar;