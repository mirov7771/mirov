--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3413
alter table questionnaire drop column if exists sber500;
alter table questionnaire add column sber500 boolean  default false;