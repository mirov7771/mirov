--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2187
create index x3_pilot on pilot (ISQUESTIONNAIRE, ISSUCCESS, ISB2C, ISB2B, ECOSYSTEM);
create index x4_pilot on pilot (QUESTIONNAIREID) where ISQUESTIONNAIRE and ISSUCCESS and ISB2C and ISB2B and ECOSYSTEM;

create index x5_pilot on pilot (QuestionnaireId) where ISB2C;
create index x6_pilot on pilot (QuestionnaireId) where ISB2B;
create index x7_pilot on pilot (QuestionnaireId) where ISSUCCESS;
create index x8_pilot on pilot (QuestionnaireId) where ECOSYSTEM;
create index x9_pilot on pilot (QuestionnaireId) where ISQUESTIONNAIRE;

create index x10_pilot on pilot (QuestionnaireId) where isDisabled;
create index x11_pilot on pilot (pilotId) where isDisabled;