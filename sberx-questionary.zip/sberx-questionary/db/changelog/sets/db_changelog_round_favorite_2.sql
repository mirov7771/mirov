--liquibase formatted sql
--changeset Belov DI:add_favorite_column
ALTER TABLE round ADD favorite boolean;