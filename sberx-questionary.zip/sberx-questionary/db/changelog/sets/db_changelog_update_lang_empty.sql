--liquibase formatted sql
--changeset Zakutskiy MY:update_lang_empty
update questionnaire set languages = array['ru','en']
                     where questionnaireid in (select ql.questionnaireid from questionnaire_local ql where ql.lang in('ru','en') group by 1 having count(*) > 1)
                       and ('' = any (languages) or languages is null);

update questionnaire set languages = array['ru']
                     where questionnaireid in (select ql.questionnaireid from questionnaire_local ql where ql.lang = 'ru')
                       and questionnaireid not in (select ql2.questionnaireid from questionnaire_local ql2 where ql2.lang = 'en')
                       and ('' = any (languages) or languages is null);

update questionnaire set languages = array['en']
                     where questionnaireid in (select ql.questionnaireid from questionnaire_local ql where ql.lang = 'en')
                       and questionnaireid not in (select ql2.questionnaireid from questionnaire_local ql2 where ql2.lang = 'ru')
                       and ('' = any (languages) or languages is null);

update questionnaire
set main_language = case
                        when 'ru' = any(languages) then 'ru'
                        when 'en' = any(languages) then 'en'
                        else null
                    end
where (main_language = '' or main_language is null) and languages is not null;




