--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5459
alter table QUESTIONNAIRE add column if not exists last_enter timestamp null;
