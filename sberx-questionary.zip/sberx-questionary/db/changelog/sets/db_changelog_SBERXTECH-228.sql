--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-228
ALTER TABLE questionnaire ADD forlending boolean null default false;