--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-3964
alter table public.questionnaire drop column if exists responsible;
alter table public.questionnaire drop column if exists responsibleLogin;
alter table public.questionnaire add column responsible bigint null;
alter table public.questionnaire add column responsibleLogin varchar(255) null;