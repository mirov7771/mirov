--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-252
ALTER TABLE pilot ALTER COLUMN conditions TYPE varchar(655) USING conditions::varchar;
ALTER TABLE response ALTER COLUMN question TYPE varchar(655) USING question::varchar;
ALTER TABLE response ALTER COLUMN question_descriprion TYPE varchar(655) USING question_descriprion::varchar;