--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-5663

alter table questionnaire add column if not exists utm varchar;
alter table application add column if not exists utm varchar;