--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3286
alter table status_info
    add column parent_id bigint;