--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5657
create table if not exists legal_application
(
    id bigint NOT NULL GENERATED ALWAYS AS IDENTITY primary key, -- идентификатор записи
    user_id bigint, -- идентификатор пользователя подавшего заявку
    name varchar(255), -- контактное лицо
    phone_number varchar(30), -- контактный номер телефона
    email varchar(50),
    ipservice bigint, -- услуга
    problem varchar(1000), -- описание вопроса
    questionnaire_id bigint, -- идентификатор анкеты для которой осуществлена рассылка
    state bigint
    );