--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-3815

update public.questionnaire set sber500 = true
where questionnaireid in (
    select distinct sfh.questionnaire_id
    from public.sber_five_hundred sfh left join public.questionnaire q
                                                on sfh.questionnaire_id = q.questionnaireid
    where q.sber500 = false and sfh.clients is not null
);
