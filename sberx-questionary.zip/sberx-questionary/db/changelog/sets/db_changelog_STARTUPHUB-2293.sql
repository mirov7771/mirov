--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2293
create table application
(
    application_id   bigserial primary key,
    type             int,
    state            int,
    modified         timestamp,
    created          timestamp,
    first_name       varchar,
    last_name        varchar,
    phone            varchar,
    position         varchar,
    org_full_name    varchar,
    site             varchar,
    email            varchar,
    investor_type    int,
    questionnaire_id bigint references questionnaire (questionnaireid)
);

create index x1_application on application (type);