--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5149
ALTER TABLE round ALTER COLUMN pre_money TYPE bigint USING pre_money::bigint;
ALTER TABLE round ALTER COLUMN post_money TYPE bigint USING post_money::bigint;
ALTER TABLE round ALTER COLUMN LAST_INVESTMENT TYPE bigint USING LAST_INVESTMENT::bigint;
ALTER TABLE round ALTER COLUMN SUM_INVESTMENT TYPE bigint USING SUM_INVESTMENT::bigint;

