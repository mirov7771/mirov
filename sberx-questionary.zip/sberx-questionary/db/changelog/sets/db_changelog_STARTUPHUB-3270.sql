--liquibase formatted sql
--changeset Kiryushin MG:STARTUPHUB-3270
alter table community_application
    add column email varchar(150) null,
    add column expert text null,
    add column fio varchar (250) null;