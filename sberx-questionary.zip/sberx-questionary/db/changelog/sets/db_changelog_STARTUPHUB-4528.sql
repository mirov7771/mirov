--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4528
drop table if exists recommend_coefficient;
create table recommend_coefficient(
    coef_type varchar primary key,
    coef_value float
);

insert into recommend_coefficient(coef_type, coef_value)
values ('industry_1', 0.273);
insert into recommend_coefficient(coef_type, coef_value)
values ('round_1', 0.267);
insert into recommend_coefficient(coef_type, coef_value)
values ('technology_1', 0.247);
insert into recommend_coefficient(coef_type, coef_value)
values ('geography_1', 0.213);

insert into recommend_coefficient(coef_type, coef_value)
values ('industry_2', 0.242);
insert into recommend_coefficient(coef_type, coef_value)
values ('round_2', 0.25);
insert into recommend_coefficient(coef_type, coef_value)
values ('technology_2', 0.233);
insert into recommend_coefficient(coef_type, coef_value)
values ('geography_2', 0.267);