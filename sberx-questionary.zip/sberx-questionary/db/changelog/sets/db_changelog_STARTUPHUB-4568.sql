--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4568
create table if not exists metric_type (
    type_id bigserial primary key ,
    name varchar,
    money boolean default false,
    description text null
);

create table if not exists metric_settings (
    questionnaire_id bigint,
    type_id bigint,
    currency varchar
);