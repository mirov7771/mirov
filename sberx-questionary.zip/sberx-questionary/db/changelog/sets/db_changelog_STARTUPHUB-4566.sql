--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-4566
alter table public.table_comment add column if not exists login varchar(50);