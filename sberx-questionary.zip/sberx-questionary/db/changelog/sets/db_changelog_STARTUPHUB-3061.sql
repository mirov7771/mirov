--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3061
alter table investment add column plan_investment bool NOT NULL DEFAULT false ;

