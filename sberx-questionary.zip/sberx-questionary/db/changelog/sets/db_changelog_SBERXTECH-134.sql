--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-134
ALTER TABLE questionnaire ADD portfolionote varchar(350) null;