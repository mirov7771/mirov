--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1784
ALTER TABLE project ADD mvpcode bigint[] null;