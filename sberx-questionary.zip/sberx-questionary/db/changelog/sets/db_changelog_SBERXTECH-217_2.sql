--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-217_2
ALTER TABLE questionnaire ADD businessmodel bigint[] null;