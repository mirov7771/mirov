--liquibase formatted sql
--changeset Timoshkin Ma:STARTUPHUB-2446
create table popup_info (
  id bigserial primary key,
  questionnaireid bigint references questionnaire(questionnaireid) not null,
  status varchar not null,
  watched boolean not null
);