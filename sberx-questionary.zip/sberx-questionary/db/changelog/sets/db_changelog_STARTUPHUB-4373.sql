--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-4373
ALTER TABLE questionnaire add column if not exists enableoffers boolean default false;
UPDATE questionnaire set enableoffers = false;