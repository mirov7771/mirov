--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2763
ALTER TABLE pilot ADD created timestamp null;