--liquibase formatted sql
--changeset Fedorov EO:STARTUPHUB-round
create table round (
                            round_id bigserial primary key,
                            questionnaireid bigint references questionnaire(questionnaireid) not null,
                            state bigint,
                            modified timestamp,
                            created timestamp,
                            investment boolean,
                            round_type bigint[],
                            investment_purpose varchar,
                            sum_investment bigint,
                            percent bigint,
                            pre_money bigint,
                            post_money bigint,
                            result varchar,
                            lead_check boolean,
                            lead_name varchar,
                            last_investment bigint,
                            future_investment bigint,
                            geography bigint[],
                            transaction_type bigint,
                            round_info varchar,
                            end_date timestamp,
                            presentation varchar


);