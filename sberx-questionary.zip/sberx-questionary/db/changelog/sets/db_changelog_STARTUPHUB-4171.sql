--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-4171
update project
set expansion = ARRAY(select unnest(expansion) except select unnest(geography))
where expansion && geography;
