--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4174
ALTER TABLE questionnaire ADD COLUMN if not exists not_new boolean null default false;
update questionnaire set not_new = true;