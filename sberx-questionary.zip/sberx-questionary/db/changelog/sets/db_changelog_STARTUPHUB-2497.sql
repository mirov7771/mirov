--liquibase formatted sql
--changeset Timoshkin Ma:STARTUPHUB-2497
alter table questionnaire add UNIQUE(priority);
create index x5_questionnaire on questionnaire(priority);