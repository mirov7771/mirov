--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4708_2
delete from popup_info where status = 'import';