--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2187_2
create index x12_pilot on pilot (QuestionnaireId) where isDisabled = false;
create index x13_pilot on pilot (pilotId) where isDisabled = false;
