--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2183
ALTER TABLE response ADD response_note varchar(350) null;