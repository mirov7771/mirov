--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-3649
alter table public.questionnaire
    add column uid uuid default md5(random()::text || clock_timestamp()::text)::uuid;

create index x6_questionnaire on public.questionnaire (uid);