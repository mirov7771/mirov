--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5357
alter table round add column if not exists view_count bigint null;

