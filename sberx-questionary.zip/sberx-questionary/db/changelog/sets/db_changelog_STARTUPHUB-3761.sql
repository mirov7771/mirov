--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-3761
alter table public.community_application drop column if exists telegram;
ALTER TABLE public.community_application ADD telegram varchar(200);