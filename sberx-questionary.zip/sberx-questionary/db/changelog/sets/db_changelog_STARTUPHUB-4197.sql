--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4197
update public.pilot set modified = (select case when q2.modified is null then q2.created else q2.modified end from questionnaire q2 where pilot.questionnaireid = q2.questionnaireid)
where modified is null;