--liquibase formatted sql
--changeset Leskov-LS:tariff-settings_2
delete from tariff_settings where (sysname like 'Corp%') or (sysname like 'Invest%');
INSERT INTO public.tariff_settings (sysname,"type",subtype,name,description,duration,max_users) VALUES ('CorpProPlus',1,'{}','Pro Plus','',365,5);
INSERT INTO public.tariff_settings (sysname,"type",subtype,name,description,duration,max_users) VALUES ('InvestAngel',2,'{11002}','Pro Бизнес-ангел','',365,1);
INSERT INTO public.tariff_settings (sysname,"type",subtype,name,description,duration,max_users) VALUES ('InvestPro',2,'{11001,11002,11004}','Pro Фонд','',365,3);
INSERT INTO public.tariff_settings (sysname,"type",subtype,name,description,duration,max_users) VALUES ('CorpDemo',1,NULL,'Demo','',365,1);
INSERT INTO public.tariff_settings (sysname,"type",subtype,name,description,duration,max_users) VALUES ('CorpPro',1,'{}','Pro','',365,3);
INSERT INTO public.tariff_settings (sysname,"type",subtype,name,description,duration,max_users) VALUES ('InvestDemo',2,'{11001,11002,11004}','Demo','',365,1);