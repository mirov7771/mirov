--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4708_4
alter table questionnaire drop column if exists is_import;
alter table questionnaire add column if not exists is_import boolean null;

