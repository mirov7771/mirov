--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-297
ALTER TABLE questionnaire ADD acceleratorCode bigint[] null;