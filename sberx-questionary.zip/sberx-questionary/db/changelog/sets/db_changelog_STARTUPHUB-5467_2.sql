--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5467_2
alter table recommend_notification drop column if exists notification_questionnaire_id;
