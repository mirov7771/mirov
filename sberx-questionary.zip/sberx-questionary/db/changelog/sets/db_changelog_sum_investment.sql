--liquibase formatted sql
--changeset Mirov AA:sum_investment_to_varchar
ALTER TABLE public.investment ALTER COLUMN suminvestment TYPE varchar(255) USING suminvestment::varchar(255);