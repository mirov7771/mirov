--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2055
ALTER TABLE project ADD technology bigint[] null;
ALTER TABLE investment ADD technology bigint[] null;