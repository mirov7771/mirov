--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4447_2
drop table if exists recommend_coefficient;
create table recommend_coefficient(
    coef_type varchar primary key,
    coef_value float
);

insert into recommend_coefficient(coef_type, coef_value)
values ('industry', 0.273);
insert into recommend_coefficient(coef_type, coef_value)
values ('round', 0.267);
insert into recommend_coefficient(coef_type, coef_value)
values ('technology', 0.247);
insert into recommend_coefficient(coef_type, coef_value)
values ('geography', 0.213);