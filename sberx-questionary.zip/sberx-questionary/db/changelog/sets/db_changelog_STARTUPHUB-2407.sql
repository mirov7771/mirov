--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2407
create index x_upper_questionnaire on questionnaire (upper(name));
create index x_upper_pilot on pilot (upper(name));