--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2663
alter table questionnaire add revision_date timestamp null;