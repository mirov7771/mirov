--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-3966
drop table if exists questionnaire_funds;
create table questionnaire_funds

(
    fundid          bigserial primary key,
    questionnaireid bigint,
    budget          varchar(100),
    avginvestment   varchar(100)
);

create index x1_questionnaire_funds on questionnaire_funds (questionnaireid);

