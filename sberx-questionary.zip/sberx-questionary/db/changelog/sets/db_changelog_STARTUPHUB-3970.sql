--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-3974
alter table public.pilot rename column parentid to creatorid;