--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-3123
alter table application
    add column login varchar,
    add column uid varchar,
    add column notification_dttm timestamp;