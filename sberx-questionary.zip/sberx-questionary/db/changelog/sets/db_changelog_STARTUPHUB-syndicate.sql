--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-syndicate
alter table syndicate_application add consent timestamp null;
alter table syndicate_application add iMoscowConsent timestamp null;
alter table syndicate_application add syndicateConsent timestamp null;