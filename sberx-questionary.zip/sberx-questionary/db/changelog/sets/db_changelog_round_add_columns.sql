--liquibase formatted sql
--changeset Mirov AA:add_round_columns
ALTER TABLE round ADD PLAN_DATE timestamp null;