--liquibase formatted sql
--changeset Fedorov AA:STARTUPHUB-2796
ALTER TABLE questionnaire ADD acceleratorSite varchar(150) null;