--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-227
ALTER TABLE project ADD expansion bigint[] null;