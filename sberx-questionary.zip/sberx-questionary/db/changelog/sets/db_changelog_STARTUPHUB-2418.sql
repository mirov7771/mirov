--liquibase formatted sql
--changeset Timoshkin Ma:STARTUPHUB-2293-3
create index x_upper_application on application (upper(org_full_name));
