--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5104
create table if not exists tariff
(
    id                 bigserial PRIMARY KEY,
    questionnaireid    bigint      not null,
    questionnaire_uuid varchar     not null,
    sysname            varchar(30) not null,
    state              varchar     not null,
    create_dttm        timestamp   not null,
    end_dttm           timestamp,
    requested_userid   bigint,
    validated_userid   bigint,
    parent_id          bigint
);

create index if not exists x1_tariff on tariff (id);
create index if not exists x2_tariff on tariff (questionnaireid) INCLUDE (state);

create table if not exists tariff_settings
(
    id          bigserial PRIMARY KEY,
    sysname     varchar(30)  not null,
    type        int          not null,
    subtype     int[],
    name        varchar(100) not null,
    description varchar(500),
    duration    int,
    max_users   int
);

create index if not exists x1_tariff_settings on tariff_settings (id);
create index if not exists x2_tariff_settings on tariff_settings (sysname);