--liquibase formatted sql
--changeset Leskov-LS:NT_tuning
CREATE INDEX IF NOT EXISTS idx_parentid_modified ON questionnaire(parentid, modified);