--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-2417
create table status_info
(
    id          bigserial primary key,
    object_id   bigint,
    object_type varchar,
    from_state  bigint,
    to_state    bigint,
    comment     varchar,
    user_id     bigint,
    date        timestamp
);