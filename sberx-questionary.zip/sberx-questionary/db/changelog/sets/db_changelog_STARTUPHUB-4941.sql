--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4941
alter table questionnaire add column if not exists accelerator_string varchar;