--liquibase formatted sql
--changeset Filatov EA:STARTUPHUB-4254
alter table pilot add column if not exists company_uid uuid null;
alter table pilot add column if not exists REFERENCE_STATE bigint null;