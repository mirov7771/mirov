--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4372

update public.questionnaire
   set enableoffers = true
 where type = 1;
