--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4589
update questionnaire
   set site = null
 where site like '%facebook.com%' or site like '%instagram.com%';

update project
   set demovideo = null
 where demovideo like '%facebook.com%' or demovideo like '%instagram.com%';

update pilot
   set site = null
 where site like '%facebook.com%' or site like '%instagram.com%';

delete from contact
 where name like '%facebook.com%' or name like '%instagram.com%';

update contact
   set type = 21003
 where type = 21002;