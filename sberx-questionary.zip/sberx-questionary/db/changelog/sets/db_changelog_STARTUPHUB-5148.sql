--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-5148
CREATE INDEX IF NOT EXISTS idx_email ON user_questionnaire(email);