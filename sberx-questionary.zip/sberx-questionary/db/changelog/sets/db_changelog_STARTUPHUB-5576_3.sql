--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5576_3

truncate questionnaire_local;
insert into questionnaire_local
select q.uid,
       q.questionnaireid,
       'ru',
       q.fullname,
       q.inn,
       q.birthday,
       q.name,
       q.registrationcountry,
       q.site,
       q.invitefio,
       q.email,
       q.phonenumber,
       q.logo_file,
       q.accelerator_string,
       q.fullnote,
       q.note
from questionnaire q;

truncate project_local;
insert into project_local
select p.projectid,
       'ru',
       p.note,
       p.demovideo,
       p.problem,
       p.auditory,
       p.competitor,
       p.upside
from project p;

truncate investment_local;
insert into investment_local
select i.questionnaireid, 'ru', i.businessplan, i.investment, i.lastinvestment, i.coinvestment
from investment i;

truncate import_replace_lang;
insert into import_replace_lang
select ir.questionnaire_id, 'ru', ir.note, ir.benefits
from import_replace ir;

update questionnaire set main_language = 'ru', languages = array['ru'] where main_language is null;
update contact set lang = 'ru' where lang is null;
update worker set lang = 'ru' where lang is null;
update pilot set lang = 'ru' where lang is null;
