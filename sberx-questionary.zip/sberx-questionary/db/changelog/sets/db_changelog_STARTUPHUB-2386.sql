--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2386
ALTER TABLE public.questionnaire ALTER COLUMN locationcountry TYPE bigint USING locationcountry::bigint;