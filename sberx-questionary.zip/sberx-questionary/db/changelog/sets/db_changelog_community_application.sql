--liquibase formatted sql
--changeset Belov DI:community_application
drop table if exists community_application;
create table community_application
(
    id bigserial primary key,
    questionnaireid bigint references questionnaire(questionnaireid) not null,
    state bigint,
    modified timestamp,
    created timestamp,
    type smallint,
    name varchar(255),
    site varchar(200),
    position varchar(200),
    phone_number varchar(100),
    expectation text,
    useful text,
    industry bigint[],
    technology bigint[],
    geography bigint,
    round bigint[],
    venture_projects_count bigint,
    facebook varchar(200),
    comment text
);

create index x1_community_application on community_application(questionnaireid);
create index x2_community_application on community_application(state);