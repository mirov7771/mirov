--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1902
ALTER TABLE questionnaire ADD technology bigint[] null;