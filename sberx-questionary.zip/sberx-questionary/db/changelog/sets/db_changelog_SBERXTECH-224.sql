--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-224
ALTER TABLE project ADD indirectCompetitor varchar(300) null ;
ALTER TABLE project ADD demoVideo varchar(300) null ;
ALTER TABLE project ADD pitchVideo varchar(300) null ;
ALTER TABLE project ADD addNote text null ;