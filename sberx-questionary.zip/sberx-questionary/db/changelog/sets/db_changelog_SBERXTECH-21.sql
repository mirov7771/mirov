--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-21
ALTER TABLE questionnaire ADD isnew BOOLEAN default false;