--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4754
update popup_info
set status = 'csi'
where status = 'CSI';

