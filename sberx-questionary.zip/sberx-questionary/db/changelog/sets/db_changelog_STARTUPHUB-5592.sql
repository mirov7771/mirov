--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5592
update popup_info
set status =
        case
            when
                (select q.questionnaireid from questionnaire q where q.questionnaireid = questionnaireid and q.type = 0 limit 1) is not null
                then 'active_startup'
            when
                (select q.questionnaireid from questionnaire q where q.questionnaireid = questionnaireid and q.type = 1 limit 1) is not null
                then 'active_corporate'
            when
                (select q.questionnaireid from questionnaire q where q.questionnaireid = questionnaireid and q.type = 2 limit 1) is not null
                then 'active_investor'
end
where status = 'active';

update popup_info
set status =
        case
            when
                (select q.questionnaireid from questionnaire q where q.questionnaireid = questionnaireid and q.type = 0 limit 1) is not null
                then 'processing_startup'
            when
                (select q.questionnaireid from questionnaire q where q.questionnaireid = questionnaireid and q.type = 1 limit 1) is not null
                then 'processing_corporate'
            when
                (select q.questionnaireid from questionnaire q where q.questionnaireid = questionnaireid and q.type = 2 limit 1) is not null
                then 'processing_investor'
end
where status = 'processing';