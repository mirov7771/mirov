--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5104_2
alter table application add column if not exists tariff varchar null;