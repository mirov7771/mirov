--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4708
alter table questionnaire add column if not exists is_import boolean default false;

create table if not exists import_replace (
    questionnaire_id bigint primary key,
    name varchar[],
    note text null,
    benefits text null
);