--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1072
ALTER TABLE questionnaire ALTER COLUMN name DROP NOT NULL;