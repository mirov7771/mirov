--liquibase formatted sql
--changeset Belov DI:STARTUPHUB-3796
drop table if exists object_favorite;
create table object_favorite
(
    id               bigserial,
    object_id        bigint  not null,
    object_type      varchar not null,
    questionnaire_id bigint  not null
);