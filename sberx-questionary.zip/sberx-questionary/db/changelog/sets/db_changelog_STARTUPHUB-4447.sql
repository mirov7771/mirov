--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4447
create table if not exists recommend_link(
    id bigserial,
    questionnaire_id bigint,
    recommend_questionnaire_id bigint,
    cache_time timestamp null
);

create index x1_recommend_link on recommend_link(recommend_questionnaire_id);
create index x2_recommend_link on recommend_link(questionnaire_id);