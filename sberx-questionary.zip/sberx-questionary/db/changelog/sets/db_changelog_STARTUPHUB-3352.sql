--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-3352
create index x1_upper_status_info on public.status_info (object_type);