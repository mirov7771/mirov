--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5125_2
update POPUP_INFO
set user_id = (
    select userid
    from user_questionnaire q
    where q.questionnaireid = POPUP_INFO.questionnaireid
    limit 1
)
where user_id is null;
