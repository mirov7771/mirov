--liquibase formatted sql
--changeset Fedorov EO:STARTUPHUB-community
alter table community_application drop column questionnaireid;
alter table community_application add questionnaireid bigint null;