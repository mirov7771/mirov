--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5458
alter table recommend_link add column if not exists recommend_date timestamp null;
