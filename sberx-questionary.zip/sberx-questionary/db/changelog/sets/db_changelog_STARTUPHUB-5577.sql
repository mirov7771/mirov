--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5577
alter table questionnaire add column if not exists label_new timestamp null;