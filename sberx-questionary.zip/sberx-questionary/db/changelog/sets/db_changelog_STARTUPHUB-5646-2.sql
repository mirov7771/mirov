--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-5646-2

create table if not exists round_local
(
    round_id bigint,
    lang varchar(3),
    investment_purpose text,
    other_description text,
    result text,
    lead_name varchar,
    round_info text,
    presentation varchar,
    invite_fio varchar,
    email varchar,
    phone varchar
);

alter table round add column if not exists main_language varchar(3);
alter table round add column if not exists languages varchar(3)[];