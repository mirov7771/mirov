--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4423
create table if not exists scouting_application
(
    uid uuid default md5(random()::text || clock_timestamp()::text)::uuid primary key ,
    name varchar,
    email varchar,
    phone varchar,
    comment text,
    admin_comment text,
    state bigint,
    created timestamp,
    modified timestamp
);