--liquibase formatted sql
--changeset Mirov AA:site_column_change
ALTER TABLE public.questionnaire ALTER COLUMN site TYPE text USING site::text;