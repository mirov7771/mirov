--liquibase formatted sql
--changeset Timofeev VV:STARTUPHUB-5103

truncate table public.metric_type;

ALTER TABLE metric_type ADD COLUMN IF NOT EXISTS short_name varchar(20);

INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (1,'Annual Recurring Revenue',true,'Суммарный ежегодный доход от повторяющихся (не разовых, а возобновляемых, рекуррентных) платежей. Актуально для подписных моделей.','ARR');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (2,'Monthly Recurring Revenue',true,'Суммарный месячный доход от повторяющихся (не разовых, а возобновляемых, рекуррентных) платежей. Актуально для подписных моделей.','MRR');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (3,'Gross Merchandise Value',true,'Совокупная стоимость проданных через ваш маркетплейс товаров без учета возвратов, обмена и скидок. Актуально для модели маркетплейса.','GMV');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (4,'Gross Transaction Volume',true,'Суммарный объем вашей комиссии, полученный с товарооборота. Актуально для транзакционных моделей, например, маркетплейса.','GTV');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (5,'Revenue ',true,'Общая выручка компании. Сумма поступлений до вычета всех затрат.','Revenue');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (6,'Gross Profit',true,'Валовая прибыль. Разница между выручкой и себестоимостью проданной продукции или услуги.','GP');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (7,'LTV - Lifetime Value',true,'Пожизненная ценность клиента. Средний доход, получаемый от одного платящего клиента за весь срок его пользования услугами компании.','LTV');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (8,'LT - Lifetime ',false,'Продолжительность "жизни" клиента. Среднее число месяцев взаимодействия клиента с компанией от первого до последнего заказа.','LT');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (9,'ARPU - Average Revenue Per User',true,'Средняя выручка с одного клиента. Может высчитываться как за определенный период, так и за весь срок "жизни" клиента.','ARPU');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (10,'PCAC - Paid Customer Acquisition Cost',true,'Стоимость привлечения одного платящего пользователя.','PCAC');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (11,'DAU - Daily Active Users',false,'Количество уникальных пользователей, которые взаимодействовали с вашим продуктом за день.','DAU');
INSERT INTO public.metric_type (type_id,"name","money",description,short_name) VALUES (12,'MAU - Mounthly Active Users',false,'Количество уникальных пользователей, которые взаимодействовали с вашим продуктом за месяц.','MAU');