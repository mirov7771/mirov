--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3095
drop table if exists round_favorite;
create table round_favorite (
    id bigserial primary key,
    questionnaire_id bigint references questionnaire(questionnaireid) not null,
    round_id bigint
);

create index x1_round_favorite on round_favorite(questionnaire_id, round_id);