--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2765
update public.pilot p
set created = (select created from questionnaire q2 where p.questionnaireid = q2.questionnaireid)
where created is null;