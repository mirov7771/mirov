--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4708_3
delete from popup_info where status = 'import';
delete from popup_info pi2 where questionnaireid in (select questionnaireid from questionnaire q where type != 0) and status = 'update_questionnaire';