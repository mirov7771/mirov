--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3236_2
alter table questionnaire add column send_invest_plan_notify bool NULL DEFAULT false ;

