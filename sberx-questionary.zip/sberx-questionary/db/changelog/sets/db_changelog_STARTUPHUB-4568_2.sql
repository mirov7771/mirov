--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4568_2
alter table metric_settings drop column if exists id;
alter table metric_settings add column IF not exists id bigserial primary key;

drop table if exists metric;
create table metric (
    id              bigserial  primary key,
    questionnaireid bigserial  not null,
    date            timestamp  not null,
    value           bigint     not null,
    type            bigint     not null,
    createdttm      timestamp  not null,
    active          boolean    default false
);