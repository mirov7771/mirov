--liquibase formatted sql
--changeset Mirov AA:syndicate_column
alter table syndicate_application drop column if exists is_IMoscow;
alter table syndicate_application add column is_IMoscow boolean null default true;