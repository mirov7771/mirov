--liquibase formatted sql
--changeset Mirov AA:short
ALTER TABLE representative ADD last_name varchar(255) null ;
ALTER TABLE representative ADD first_name varchar(255) null ;
ALTER TABLE representative ADD position varchar(255) null ;

ALTER TABLE user_questionnaire ADD last_name varchar(255) null ;
ALTER TABLE user_questionnaire ADD first_name varchar(255) null ;
ALTER TABLE user_questionnaire ADD position varchar(255) null ;
