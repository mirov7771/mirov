--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4469
alter table questionnaire add column if not exists is_send_processing boolean default false;