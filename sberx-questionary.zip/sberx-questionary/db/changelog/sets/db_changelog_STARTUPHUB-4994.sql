--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4994
alter table POPUP_INFO add column if not exists DATE timestamp null;
