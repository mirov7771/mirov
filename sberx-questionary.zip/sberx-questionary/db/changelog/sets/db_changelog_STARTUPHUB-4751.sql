--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4751
drop table if exists csi;
create table csi
(
    questionnaire_id bigint    primary key,
    user_id          bigint    not null,
    value            smallint  not null,
    createdttm       timestamp not null
);
