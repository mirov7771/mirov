--liquibase formatted sql
--changeset Shcherbakov AS:STARTUPHUB-3705
alter table public.pilot drop column if exists modified;
ALTER TABLE public.pilot ADD modified timestamp null;