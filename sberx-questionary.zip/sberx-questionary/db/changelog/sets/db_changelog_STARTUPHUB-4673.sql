--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4673
insert into popup_info (questionnaireid, status, watched)
select questionnaireid, 'update_questionnaire', false
from questionnaire q
where type = 0
  and state = 20004
  and not exists (select 1 from popup_info p where p.questionnaireid = q.questionnaireid and status = 'update_questionnaire' and watched = false);