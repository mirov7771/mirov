--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5149
ALTER TABLE round ALTER COLUMN FUTURE_INVESTMENT TYPE bigint USING FUTURE_INVESTMENT::bigint;

