--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1953
delete from public.pilot where questionnaireid in (
    select questionnaireid
    from public.pilot p
    where (ISQUESTIONNAIRE = true  or ISSUCCESS = true or ISB2C = true or ISB2B = true  or ECOSYSTEM = true)
    group by questionnaireid
    having count(1)>3
);