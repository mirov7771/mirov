--liquibase formatted sql
--changeset Demenkov RV:STARTUPHUB-3517
drop table if exists syndicate_application;
create table syndicate_application
(
    id                 bigserial NOT NULL primary key,
    type               smallint NULL,
    state              smallint NULL,
    modified           timestamp NULL,
    created            timestamp NULL,
    first_name         varchar NULL,
    last_name          varchar NULL,
    phone              varchar NULL,
    position           varchar NULL,
    org_full_name      varchar NULL,
    site               varchar NULL,
    email              varchar NULL,
    investor_type      bigint NULL,
    questionnaire_id   bigint NULL,
    comment            text NULL,
    uid                varchar null,
    venture_experience text null,
    is_unity           boolean null default false,
    telegram_link      varchar null,
    sum_investment     bigint null
);

create index x1_syndicate_application on syndicate_application (questionnaire_id);
create index x2_syndicate_application on syndicate_application (state);