--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1659
ALTER TABLE questionnaire ADD fullnote text null;