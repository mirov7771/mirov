--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-1850

UPDATE public.questionnaire set "type" = 1 where questionnaireid = 138;


DELETE FROM public.questionnaire WHERE questionnaireid = 190;

update public.questionnaire set priority = 300 where questionnaireid = 153;
update public.questionnaire set priority = 200 where questionnaireid = 157;
update public.questionnaire set priority = 100 where questionnaireid = 167;
update public.questionnaire set priority = 0 where questionnaireid = 152;

update public.questionnaire set priority = 800 where questionnaireid = 85;
update public.questionnaire set priority = 700, email = 'anna@around.capital' where questionnaireid = 75;