--liquibase formatted sql
--changeset Mirov AA:db_project
ALTER TABLE public.project ALTER COLUMN staff TYPE int8 USING staff::int8;