--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-metric_type
delete from public.metric_type;
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (1,'Annual Recurring Revenue',true,'Суммарный ежегодный доход от повторяющихся (не разовых, а возобновляемых, рекуррентных) платежей. Актуально для подписных моделей.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (2,'Monthly Recurring Revenue',true,'Суммарный месячный доход от повторяющихся (не разовых, а возобновляемых, рекуррентных) платежей. Актуально для подписных моделей.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (3,'Gross Merchandise Value',true,'Совокупная стоимость проданных через ваш маркетплейс товаров без учета возвратов, обмена и скидок. Актуально для модели маркетплейса.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (4,'Gross Transaction Volume',true,'Суммарный объем вашей комиссии, полученный с товарооборота. Актуально для транзакционных моделей, например, маркетплейса.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (5,'Revenue ',true,'Общая выручка компании. Сумма поступлений до вычета всех затрат.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (6,'Gross Profit',true,'Валовая прибыль. Разница между выручкой и себестоимостью проданной продукции или услуги.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (7,'LTV - Lifetime Value',true,'Пожизненная ценность клиента. Средний доход, получаемый от одного платящего клиента за весь срок его пользования услугами компании.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (8,'LT - Lifetime ',false,'Продолжительность "жизни" клиента. Среднее число месяцев взаимодействия клиента с компанией от первого до последнего заказа.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (9,'ARPU - Average Revenue Per User',true,'Средняя выручка с одного клиента. Может высчитываться как за определенный период, так и за весь срок "жизни" клиента.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (10,'PCAC - Paid Customer Acquisition Cost',true,'Стоимость привлечения одного платящего пользователя.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (11,'DAU - Daily Active Users',false,'Количество уникальных пользователей, которые взаимодействовали с вашим продуктом за день.');
INSERT INTO public.metric_type (type_id,name,money,description) VALUES (12,'MAU - Mounthly Active Users',false,'Количество уникальных пользователей, которые взаимодействовали с вашим продуктом за месяц.');