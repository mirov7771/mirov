--liquibase formatted sql
--changeset Fedorov EO:STARTUPHUB-2906
CREATE table metric
(
    questionnaireid bigserial primary key,
    date timestamp NOT NULL,
    value bigint NOT NULL,
    type bigint NOT NULL
);

