--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4363
drop table if exists object_action;
create table object_action
(
    id               bigserial,
    object_id        bigint  not null,
    object_type      varchar not null,
    action           varchar not null,
    user_id          bigint  not null
);

create index x1_object_action on object_action(object_id, object_type, action, user_id);