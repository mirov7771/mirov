--liquibase formatted sql
--changeset Konovalenko VI:STARTUPHUB-5646-3

create index round_id_idx on round_local (round_id);