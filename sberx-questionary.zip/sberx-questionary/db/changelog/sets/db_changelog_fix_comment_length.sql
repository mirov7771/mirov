--liquibase formatted sql
--changeset Timoshkin MA:fix_comments_length
ALTER TABLE questionnaire ALTER COLUMN comment TYPE text;
ALTER TABLE application ALTER COLUMN comment TYPE text;
ALTER TABLE status_info ALTER COLUMN comment TYPE text;
ALTER TABLE feedback ALTER COLUMN comment TYPE text;
