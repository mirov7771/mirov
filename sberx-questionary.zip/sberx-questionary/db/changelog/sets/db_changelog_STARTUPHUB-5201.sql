--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5201
alter table object_favorite add column if not exists modified timestamp null;
alter table round_favorite add column if not exists modified timestamp null;

