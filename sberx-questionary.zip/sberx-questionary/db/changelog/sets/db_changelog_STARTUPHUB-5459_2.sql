--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-5459_2
update questionnaire
set last_enter = modified
where last_enter is null
