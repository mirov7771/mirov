--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1493
ALTER TABLE questionnaire ADD priority bigint null;

update public.questionnaire q
set priority = 777
where forlending = true
  and name = 'Сбер';

update public.questionnaire q
set priority = -1 * questionnaireid
where forlending = true
  and name != 'Сбер';