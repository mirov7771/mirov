--liquibase formatted sql
--changeset Mirov AA:od_column_change
ALTER TABLE public.round ALTER COLUMN OTHER_DESCRIPTION TYPE text USING OTHER_DESCRIPTION::text;