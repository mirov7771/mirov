--liquibase formatted sql
--changeset Leskov-LS:NT_tuning_popup
CREATE INDEX IF NOT EXISTS idx_watched ON popup_info(questionnaireid, watched);
CREATE INDEX IF NOT EXISTS idx_status ON popup_info(questionnaireid, status);