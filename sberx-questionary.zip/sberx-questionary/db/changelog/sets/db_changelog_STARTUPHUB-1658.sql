--liquibase formatted sql
--changeset Molotkov D:STARTUPHUB-1658 Изменения пользовательских данных и поядка отображения в анкетах


UPDATE  public.questionnaire SET  note='Early stage инвестиции' WHERE questionnaireid=88;
UPDATE  public.questionnaire SET  note='Инвестиции в pre-seed' WHERE questionnaireid=100;
UPDATE  public.questionnaire SET  note='Инвестируем в неконтрольные доли владения компаний по разработке прорывных технологий и оборудования', forlending = true, priority = 400 WHERE questionnaireid=90;
UPDATE  public.questionnaire SET  note='Развиваем инновации через стартап-программы, сообщество и инвестиции на ранних стадиях', forlending = true, priority = 700 WHERE questionnaireid=85;
UPDATE  public.questionnaire SET  note='Венчурные инвестиции в стартапы на стадиях pre-seed & seed и консалтинг', forlending = true, priority = 1000 WHERE questionnaireid=91;
UPDATE  public.questionnaire SET  note='Предоставляем капитал, связи и возможности, превращающие стартапы в мировых лидеров', forlending = true, priority = 1100 WHERE questionnaireid=111;
UPDATE  public.questionnaire SET  note='Инвестируем в стартапы ранних стадий с сильной командой и потенциалом развития', forlending = true, priority = 900 WHERE questionnaireid=77;
UPDATE  public.questionnaire SET  note='Венчурная студия для русскоговорящих фаундеров с глобальными амбициями', forlending = true, priority = 800 WHERE questionnaireid=75;
UPDATE  public.questionnaire SET  note='Частный фонд, специализирующийся на российских стартапах seed-стадии с MVP и перспективой глобального масштабирования', forlending = true, priority = 500 WHERE questionnaireid=124;
UPDATE  public.questionnaire SET  note='Помогаем HR и ED-tech стартапам развивать бизнес на территории России, СНГ и Европы', forlending = true, priority = 600 WHERE questionnaireid=82;



UPDATE  public.questionnaire SET  note='Компания, занимающаяся вычислениями в области искусственного интеллекта', forlending = true, priority = 1400 WHERE questionnaireid=87;
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(87, 'Разработки в области искусственного интеллекта для видеокарт ', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);

UPDATE  public.questionnaire SET  note='Вертикально интегрированная горнодобывающая компания с активами в России и за рубежом' , forlending = true, priority = 200 WHERE questionnaireid=152;
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(152, 'Металургия:
•	Система измерения объемов материалов на открытых складах;
•	Система непрерывного измерения температуры металла в стальковше;
•	Повышение стойкости гуммированного покрытия отжимных роликов;
•	Решения по повышению стойкости плит кристаллизаторов и роликов УНРС (установки непрерывной разливки стали);
•	Решения по контролю химического состава жидкого металла в режиме онлайн
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(152, 'Энергетика:
•	Защита внутренних поверхностей газопроводов и горелок коксового газа от образования отложений;
•	Защита поверхностей нагрева паровых котлов от образования солевых отложений при ухудшении водно-химического режима;
•	Новые технологии получения водорода;
•	Беспроводные технологии передачи информации с первичных датчиков;
•	Снижение потерь при передаче энергоресурсов
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(152, 'Экология﻿:
•	Переработка накопителя химических отходов (НХО);
•	Переработка накопителя нефтешламов (ННШ) ;
•	Необходимо решение по полной рекультивации и восстановлению нарушенных земель
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(152, 'Горное дело:
•	Точное измерение веса мелющих тел в шаровых мельницах в режиме реального времени;
•	Система предотвращения столкновения/наезда шахтной автотехники на кабельную продукцию, оборудование в стесненных условиях и плохой освещенности;
•	Налипание горной массы к кузову (дну) думпкаров;
•	Брикетирование в промышленных масштабах отходов флотации угольных концентратов класса 0-0,5 мм, влажностью 100%;
•	Выявление и отделение инородных тел (дерево, железо, бетон) из потока немагнитной железной руды
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(152, 'Транспорт:
•	Контроль состояния фитинговых упоров (узлов) на платформе с контейнером;
•	Снижение затрат на зачистку вагонов перед погрузкой готовой продукции;
•	Ускорение процесса подготовки подвижного состава к выгрузке на вагоноопрокидывателе;
•	Оптимизация маневровых работ ж/д транспорта внутри предприятия;
•	Машинное зрение при погрузочных работах', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(152, 'Другое:
•	Новые решения по 3D печати материалов из меди и ее сплавов;
•	Влагозащитный материал для нанесения на пористые поверхности;
•	Система прогнозирования потребления товаров;
•	Онлайн-регистрация физиологических параметров человека через видеоканал;
•	Регистрация физиологии человека через видеосвязь
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);


UPDATE  public.questionnaire SET  note='Международный концерн, специализирующийся на медико-биологических решениях для здравоохранения и сельского хозяйства',  forlending = true, priority = 1300 WHERE questionnaireid=93;
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(93, 'Питание:
•	Увеличение объемов урожая;
•	ПовышеD2:E2ие качества продуктов;
•	Усовершенствование продуктов', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(93, 'Здравоохранение:
•	Consumer Health;
•	Pharmaceuticals', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);

UPDATE  public.questionnaire SET  note='Предприятие с полным металлургическим циклом, активами в России, ЕС и США. Металлопродукция НЛМК применяется в стратегически важных отраслях экономики' WHERE questionnaireid=144;
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(144, 'Новые продукты и технологии для металлургии:
•	Повышение эффективности технологических процессов;
•	Новые продукты и сервисы;
•	Порошковая металлургия', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(144, 'Технологии ремонтов:
•	Новые материалы и технологии для улучшения эксплуатационных характеристик оборудования;
•	Сервисы для повышения эффективности ремонтов', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(144, 'Цифровые решения и DATA SCIENCE:
•	Анализ данных;
•	Машинное обучение;
•	Компьютерное зрение;
•	Робототехника;
•	Блокчейн;
•	IoT', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(144, 'Энергетика и экология:
•	Технологии накопления и хранения энергии;
•	Утилизации низкопотенциального тепла;
•	Проекты в области экологии и сокращения выбросов парниковых газов', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(144, 'Улучшение бизнес-процессов:
•	Решения для улучшения уровня клиентского сервиса;
•	Развития персонала и охраны труда;
•	Оптимизации логистики;
•	Повышения эффективности снабжения', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);

UPDATE  public.questionnaire SET  note='Один из мировых лидеров по производству товаров повседневного спроса. Наша цель — сделать экологически ответственную жизнь обычным явлением' , forlending = true, priority = 1500, site = 'https://www.unilever.ru/https://www.unilever.ru/' WHERE questionnaireid=84;

UPDATE  public.questionnaire SET  note='Научно исследовательский центр Samsung Electronics в России, разрабатывающий технические решения в интересах штаб-квартиры', site = 'https://www.samsung.com/ru/'  WHERE questionnaireid=79;

UPDATE  public.questionnaire SET  note='Одна из крупнейших сетей гипермаркетов в России с возможностями заказа онлайн и экспресс-доставки' , forlending = true, priority = 300  WHERE questionnaireid=145;
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(145, 'Автоматизация операций в магазине:
•	Роботизация процессов собственного производства, в том числе 3D печать;
•	Цифровизация выбора товаров и чекаута, включая чекаут контролируемых товаров – проверка возраста, товары защищенные антикражными средствами и т.п.;
•	Адресное хранение для гипермаркетов;
•	Новые подходы к выкладке товара и контроля исполнения;
•	Предотвращение мошенничества в магазинах', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(145, 'Автоматизация операций в логистике:
•	Роботизация складких операций;
•	Автоматизация приемки товаров и контроля операций;
•	Экзоскелеты для погрузо-разгрузочных работ;
•	Технологии, направленные на повышение эффективности и безопасности процессов
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(145, 'Новые сервисы для покупателей:
•	Дополнительные сервисы для покупателей в магазинах и на парковках;
•	Фудтраки - трансформеры, в том числе беспилотные;
•	Интерактивные помощники внутри магазинов;
•	Технологии самообслуживания в магазине
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(145, 'Новые материалы:
•	Упаковки, продлевающие срок годности продуктов;
•	Биоразлагаемые упаковки;
•	Переработка пищевых отходов в функциональные материалы', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(145, 'Маркетинг:
•	Умный вендинг, взаимодействующий с покупателем;
•	Новые сервисы для онлайн продажи товаров;
•	Диджитализация клиентского сервиса;
•	Персонализация покупателя в онлайн и офлайн формате', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);

UPDATE  public.questionnaire SET  note='Одна из ведущих розничных сетей в России, обладает собственными предприятиями', forlending = true, priority = 1200, site = 'https://www.magnit.ru/'  WHERE questionnaireid=95;
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(95, 'Управление операциями:
•	Аналитические и прогнозные решения для анализа плотности продаж на квадратный метр;
•	Голосовое управление как сервис для покупателей и сотрудников;
•	Решения для управления корзиной (или списком) покупок в голосовом формате;
•	Системы голосового сопровождения - ассистенты для сотрудников магазинов;
•	Технологические направления: Video Analytics, Wearable devices, Computer vision, sensors, IoT, HRTech, EdTech, Robotics, e-Commerce, FinTech, AR/VR, Telemedicine, FoodTech, MarTech', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(95, 'Логистика и цепочки поставок:
•	"Цифровые двойники" для моделирования процессов складской логистики;
•	Автоматизация полного цикла RFID-трекинга;
•	Автоматизированная линия штучной комплектации;
•	Анализ видеопотока с целью контроля операций, ускорения процесса приемки, а также качества и состояния скоропортящейся продукции;
•	Антикражные системы для распределительных центров', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);
INSERT INTO public.pilot (
questionnaireid, suggestcase, businessunit, reference, department, conditions, name, state, target, relevance, effect, resources, deadline, "exp", company, decision, decision_company, ishub, targetoption, ispublished, parentid, ecosystem, isb2b, isb2c, issuccess, isquestionnaire, site, industry, pilot, experience, isdisabled, file, isbran, "search", isforeign)
VALUES(95, 'Собственное производство:
•	IoT-решения для контроля работы оборудования;
•	IoT-решения для теплиц и почвы;
•	Автоматизация уборки и клининга: автоматические установки для мойки и дезинфекции помещений, оборудования, дозация моющих средств и дезинфицирующих растворов;
•	Безопасное для человека средство, предотвращающее появление вредителей в орехах;
•	Роботизированные решения по сбору урожая
', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, NULL, false, false, false, false, true, NULL, NULL, false, false, false, false, false, false, false);


UPDATE  public.questionnaire SET  note='Флагман отечественного рынка страхования', forlending = true, priority = 100, site = 'https://www.rgs.ru/' WHERE questionnaireid=153;

UPDATE  public.questionnaire SET  forlending = true, priority = 1600 WHERE questionnaireid=1;

UPDATE  public.questionnaire SET   site = 'https://www.askona.ru/' WHERE questionnaireid=155;



UPDATE  public.questionnaire SET  note='Крупнейший производитель природной минеральной воды, лидер в категории природных бутилированных вод в СНГ и странах Балтии' WHERE questionnaireid=154;


UPDATE  public.questionnaire SET  note='MyBonus' WHERE questionnaireid=13;
UPDATE  public.questionnaire SET  note='Prex' WHERE questionnaireid=50;
UPDATE  public.questionnaire SET  note='Malivar' WHERE questionnaireid=16;


