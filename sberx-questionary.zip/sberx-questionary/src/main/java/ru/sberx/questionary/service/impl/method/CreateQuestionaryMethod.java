package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.DaoBuilder;
import ru.sberx.questionary.controller.dto.req.QuestionnaireReq;
import ru.sberx.questionary.controller.dto.res.TypeRes;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.service.tariff.TariffService;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.PopUpStatus;
import ru.sberx.questionary.util.Utils;
import ru.sberx.utils.validator.ConditionValidator;

import javax.transaction.Transactional;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
public class CreateQuestionaryMethod {

    @Value("${application.redirect}")
    private String action;

    private final QuestionnaireRepository questionnaireRepository;
    private final ProjectRepository projectRepository;
    private final InvestmentRepository investmentRepository;
    private final WorkerRepository workerRepository;
    private final PilotRepository pilotRepository;
    private final RepresentativeRepository representativeRepository;
    private final ContactRepository contactRepository;
    private final ResponseRepository responseRepository;
    private final FounderRepository founderRepository;
    private final CommunityUserRepository communityUserRepository;
    private final InvestmentClubRepository investmentClubRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final PopupInfoRepository popupInfoRepository;
    private final StatusInfoRepository statusInfoRepository;
    private final SberFiveHundredRepository sberFiveHundredRepository;
    private final UserAuth userAuth;
    private final MidService midService;
    private final QuestionnaireFundsRepository questionnaireFundsRepository;
    private final ImportReplaceDAORepository importReplaceDAORepository;
    private final QuestionnaireLocaleDaoRepository questionnaireLocaleDaoRepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final InvestmentLocaleDaoRepository investmentLocaleDaoRepository;
    private final ImportReplaceLangDaoRepository importReplaceLangDaoRepository;
    private final TariffService tariffService;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;

    @Transactional
    public TypeRes execute(QuestionnaireReq req) {
        Long questionnaireId = getReqQuestionnaireId(req);
        Long oldState = null;
        Long newState;
        if (questionnaireId != null) {
            oldState = questionnaireRepository.findByQuestionnaireId(questionnaireId).getState();
        }
        Questionnaire questionnaire = saveQuestionnaire(questionnaireId, req);
        TypeRes res = new TypeRes();
        res.setQuestionnaireId(questionnaireId);
        Long parentId = questionnaire.getParentId();
        if (questionnaireId != null) {
            newState = questionnaireRepository.findByQuestionnaireId(questionnaireId).getState();
            if (!Objects.equals(oldState, newState)) {
                createStatusInfo(questionnaire, "Изменение анкеты", null, oldState, newState, req.getSessionId());
            } else {
                createStatusInfo(questionnaire, parentId == null ? "Анкета отредактирована" : "Дочерняя анкета отредактирована", parentId, null, newState, req.getSessionId());
            }
        }
        res.setAction(action.replace("{type}", questionnaire.getType().toString()));
        CompletableFuture.runAsync(() -> saveConsent(req));
        if (GuideService.PROCESSING_STATE.equals(questionnaire.getState())
                && req.getQuestionnaireId() != null
                && !Boolean.TRUE.equals(questionnaire.getNotNew())) {
            Map<String, Object> params = new HashMap<>();
            params.put("name", questionnaire.getName() == null ? (questionnaire.getFullName() == null ? "" : questionnaire.getFullName()) : questionnaire.getName());
            QuestionnaireLocaleDao questionnaireLocale = questionnaireLocaleDaoRepository.findByQuestionnaireIdAndLang(questionnaire.getQuestionnaireId(), req.getLang());
            String email = questionnaireLocale != null ? questionnaireLocale.getEmail() : questionnaire.getEmail();
            Long id = questionnaire.getQuestionnaireId();
            if (!StringUtils.hasText(email)) {
                Representative representative = representativeRepository.findByQuestionnaireId(id);
                email = representative.getEmail();
            }
            String route = questionnaire.getType().equals(0) ? "/startups/"
                    : (questionnaire.getType().equals(1) ? "/corporates/" : "/investors/") + questionnaire.getUuid();
            midService.notify("QUESTIONNAIRE_ADD_UPDATE", params, email, req.getUserId(), "Статус заявки", route, null, null);
            questionnaireRepository.updateNotNewFlag(req.getQuestionnaireId());
        }
        if (req.getPilot() != null && req.getPilot().getCompanyUid() != null) {
            pilotRepository.updateByCompanyUid(req.getPilot().getCompanyUid());
        }
        return res;
    }

    private void saveConsent(QuestionnaireReq req) {
        try {
            if (req.getUserConsent() != null && (req.getUserConsent().getSber500PrivacyPolicy() != null ||
                    req.getUserConsent().getSber500Consent() != null ||
                    req.getUserConsent().getSber500PersonalDataConsent() != null ||
                    req.getUserConsent().getSber500TermOfUse() != null ||
                    req.getUserConsent().getMailingConsent() != null)) {
                userAuth.saveConsent(req.getUserConsent(), req.getUserId());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Questionnaire saveQuestionnaire(Long questionnaireId, QuestionnaireReq req) {
        Questionnaire savedQuestionnaire;
        if (req.getQuestionnaire() != null && Boolean.TRUE.equals(req.getQuestionnaire().getSber500())) {
            req.getQuestionnaire().setSber500(Boolean.TRUE.equals(req.isSber500()));
        } else if (req.getQuestionnaire() != null && Boolean.TRUE.equals(req.isSber500())) {
            req.getQuestionnaire().setSber500(true);
        }
        if (questionnaireId != null) {
            Questionnaire questionnaire = questionnaireRepository.findByQuestionnaireId(questionnaireId);
            if (questionnaire == null)
                throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            savedQuestionnaire = updateWithChildQuestionnaire(questionnaire, req);
        } else {
            savedQuestionnaire = createNewQuestionnaire(req);
        }
        if (Integer.valueOf(2).equals(req.getAction())
                && questionnaireId != null
                && !GuideService.CONFIRMED_STATE.equals(savedQuestionnaire.getState())) {
            savePopup(questionnaireId, savedQuestionnaire.getType());
        }
        return savedQuestionnaire;
    }

    private Long getReqQuestionnaireId(QuestionnaireReq req) {
        Long questionnaireId = req.getQuestionnaireId();
        if (questionnaireId == null
                && req.getQuestionnaire() != null
                && req.getQuestionnaire().getQuestionnaireId() != null) {
            questionnaireId = req.getQuestionnaire().getQuestionnaireId();
        }
        if (Long.valueOf(0L).equals(questionnaireId)) {
            questionnaireId = null;
        }
        return questionnaireId;
    }

    private Questionnaire updateWithChildQuestionnaire(Questionnaire questionnaire, QuestionnaireReq req) {
        Questionnaire savedQuestionnaire;
        Long id = questionnaire.getQuestionnaireId();
        if (req.getQuestionnaire() != null && !Boolean.TRUE.equals(req.getQuestionnaire().getSber500()))
            req.getQuestionnaire().setSber500(Boolean.TRUE.equals(questionnaire.getSber500()));
        if (GuideService.CONFIRMED_STATE.equals(questionnaire.getState())) {
            Questionnaire childQuestionnaire = questionnaireRepository.findByParentId(id);
            if (req.getQuestionnaire() != null)
                req.getQuestionnaire().setType(questionnaire.getType());
            if (childQuestionnaire == null) {
                questionnaire.setIsMarketing((req.getUserConsent() != null && Boolean.TRUE.equals(req.getUserConsent().getMailingConsent())) ? "ДА" : "НЕТ");
                questionnaireRepository.save(questionnaire);
                createNewChildQuestionnaire(req, id);
            } else {
                Questionnaire updatedQuestionnaire = updateQuestionnaire(childQuestionnaire, req);
                createStatusInfo(updatedQuestionnaire, "Дочерняя анкета отредактирована", id, updatedQuestionnaire.getState(), 20002L, req.getSessionId());
                childQuestionnaire.setModified(new Date());
                childQuestionnaire.setIsMarketing((req.getUserConsent() != null && Boolean.TRUE.equals(req.getUserConsent().getMailingConsent())) ? "ДА" : "НЕТ");
                questionnaireRepository.save(childQuestionnaire);
            }
            savedQuestionnaire = questionnaire;
        } else {
            savedQuestionnaire = updateQuestionnaire(questionnaire, req);
        }
        return savedQuestionnaire;
    }

    private Questionnaire updateQuestionnaire(Questionnaire questionnaire, QuestionnaireReq req) {
        Long questionnaireId = questionnaire.getQuestionnaireId();
        Investment investment = null;
        Project project = null;
        List<Pilot> pilots = new ArrayList<>();
        List<Worker> workers = new ArrayList<>();
        List<Representative> representatives = new ArrayList<>();
        List<Contact> contacts = new ArrayList<>();
        List<InvestmentClub> investmentClubs = new ArrayList<>();
        List<QuestionnaireFunds> questionnaireFunds = new ArrayList<>();
        SberFiveHundred sberFiveHundred = null;
        ImportReplaceDAO importReplaceDAO = null;
        QuestionnaireLocaleDao questionnaireLocaleDao = null;
        List<ProjectLocaleDao> projectLocaleDao = new ArrayList<>();
        InvestmentLocaleDao investmentLocaleDao = null;
        ImportReplaceLangDao importReplaceLangDao = null;
        if ((GuideService.DRAFT_STATE.equals(questionnaire.getState()) || GuideService.TO_EDIT.equals(questionnaire.getState()))
                && !req.getLang().equals(questionnaire.getMainLanguage()) && questionnaireRepository.findByParentId(questionnaireId) == null) {
            Project projectDel = projectRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            questionnaire.cleanFields();
            questionnaire.setMainLanguage(req.getLang());
            questionnaire.setLanguages(new String[]{req.getLang()});
            if (projectDel != null)
                projectLocaleDaoRepository.deleteByProjectId(projectDel.getProjectId());
            questionnaireLocaleDaoRepository.deleteByQuestionnaireId(questionnaireId);
            investmentLocaleDaoRepository.deleteByQuestionnaireId(questionnaireId);
            importReplaceLangDaoRepository.deleteByQuestionnaireId(questionnaireId);
            pilotRepository.deleteByQuestionnaireId(questionnaireId);
            pilotLocalDaoRepository.deleteByQuestionnaireId(questionnaireId);
            workerRepository.deleteById(questionnaireId);
            representativeRepository.deleteById(questionnaireId);
            contactRepository.deleteById(questionnaireId);
            investmentClubRepository.deleteById(questionnaireId);
            questionnaireFundsRepository.deleteByQuestionnaireId(questionnaireId);
            projectRepository.deleteByQuestionnaireId(questionnaireId);
            investmentRepository.deleteByQuestionnaireId(questionnaireId);
            sberFiveHundredRepository.deleteByQuestionnaireId(questionnaireId);
            importReplaceDAORepository.deleteByQuestionnaireId(questionnaireId);
        } else {
            investment = investmentRepository.findByQuestionnaireId(questionnaireId);
            project = projectRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            workers = workerRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            pilots = pilotRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            representatives = representativeRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            contacts = contactRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            investmentClubs = investmentClubRepository.findByQuestionnaireId(questionnaireId);
            sberFiveHundred = sberFiveHundredRepository.findByQuestionnaireId(questionnaireId);
            importReplaceDAO = importReplaceDAORepository.findByQuestionnaireId(questionnaireId);
            questionnaireFunds = questionnaireFundsRepository.findByQuestionnaireId(questionnaireId);
            questionnaireLocaleDao = questionnaireLocaleDaoRepository.findByQuestionnaireIdAndLang(questionnaireId, req.getLang());
            Project projectLoc = projectRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            if (projectLoc != null)
                projectLocaleDao = projectLocaleDaoRepository.findByProjectIdIn(List.of(projectLoc.getProjectId()));
            investmentLocaleDao = investmentLocaleDaoRepository.findByQuestionnaireIdAndLang(questionnaireId, req.getLang());
            importReplaceLangDao = importReplaceLangDaoRepository.findByQuestionnaireIdAndLang(questionnaireId, req.getLang());
        }
        if (project == null)
            project = new Project();
        if (investment == null)
            investment = new Investment();
        if (sberFiveHundred == null)
            sberFiveHundred = new SberFiveHundred();
        if (importReplaceDAO == null)
            importReplaceDAO = new ImportReplaceDAO();
        if (questionnaireLocaleDao == null)
            questionnaireLocaleDao = new QuestionnaireLocaleDao();
        if (investmentLocaleDao == null)
            investmentLocaleDao = new InvestmentLocaleDao();
        if (importReplaceLangDao == null)
            importReplaceLangDao = new ImportReplaceLangDao();

        return save(req, questionnaire, project, investment, workers, pilots, representatives,
                contacts, investmentClubs, sberFiveHundred, questionnaireFunds, importReplaceDAO,
                questionnaireLocaleDao, projectLocaleDao, investmentLocaleDao, importReplaceLangDao);

    }

    private Questionnaire createNewQuestionnaire(QuestionnaireReq req) {
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setUuid(UUID.randomUUID());
        Investment investment = new Investment();
        Project project = new Project();
        List<Worker> workers = new ArrayList<>();
        List<Pilot> pilots = new ArrayList<>();
        List<Representative> representatives = new ArrayList<>();
        List<Contact> contacts = new ArrayList<>();
        List<InvestmentClub> investmentClubs = new ArrayList<>();
        SberFiveHundred sberFiveHundred = new SberFiveHundred();
        List<QuestionnaireFunds> questionnaireFunds = new ArrayList<>();
        ImportReplaceDAO importReplaceDAO = new ImportReplaceDAO();
        QuestionnaireLocaleDao questionnaireLocaleDao = new QuestionnaireLocaleDao();
        List<ProjectLocaleDao> projectLocaleDao = new ArrayList<>();
        InvestmentLocaleDao investmentLocaleDao = new InvestmentLocaleDao();
        ImportReplaceLangDao importReplaceLangDao = new ImportReplaceLangDao();
        return save(req, questionnaire, project, investment, workers, pilots, representatives,
                contacts, investmentClubs, sberFiveHundred, questionnaireFunds, importReplaceDAO,
                questionnaireLocaleDao, projectLocaleDao, investmentLocaleDao, importReplaceLangDao);
    }

    private void createNewChildQuestionnaire(QuestionnaireReq req, Long parentId) {
        Questionnaire questionnaire = new Questionnaire();
        questionnaire.setParentId(parentId);
        questionnaire.setUuid(UUID.randomUUID());
        Investment investment = new Investment();
        Project project = new Project();
        List<Worker> workers = new ArrayList<>();
        List<Pilot> pilots = new ArrayList<>();
        List<Representative> representatives = new ArrayList<>();
        List<Contact> contacts = new ArrayList<>();
        List<InvestmentClub> investmentClubs = new ArrayList<>();
        SberFiveHundred sberFiveHundred = new SberFiveHundred();
        List<QuestionnaireFunds> questionnaireFunds = new ArrayList<>();
        ImportReplaceDAO importReplaceDAO = new ImportReplaceDAO();
        QuestionnaireLocaleDao questionnaireLocaleDao = new QuestionnaireLocaleDao();
        List<ProjectLocaleDao> projectLocaleDao = new ArrayList<>();
        InvestmentLocaleDao investmentLocaleDao = new InvestmentLocaleDao();
        ImportReplaceLangDao importReplaceLangDao = new ImportReplaceLangDao();
        Questionnaire childQuestionnaire = save(req, questionnaire, project, investment, workers, pilots, representatives,
                contacts, investmentClubs, sberFiveHundred, questionnaireFunds, importReplaceDAO,
                questionnaireLocaleDao, projectLocaleDao, investmentLocaleDao, importReplaceLangDao);
        createStatusInfo(childQuestionnaire, "Дочерняя анкета создана", parentId, null, 20002L, req.getSessionId());
        tariffService.createTariffChildQuestionnaire(parentId);
    }

    private void createStatusInfo(Questionnaire questionnaire, String comment, Long parentId, Long fromState, Long toState, String sessionId) {
        Long userId = userAuth.getUserId2(sessionId);
        StatusInfo statusInfo = new StatusInfo();
        Long id = questionnaire.getQuestionnaireId();
        statusInfo.setObjectId(id);
        statusInfo.setObjectType("Questionnaire");
        statusInfo.setFromState(fromState);
        statusInfo.setToState(toState);
        statusInfo.setComment(comment);
        statusInfo.setDate(new Date());
        statusInfo.setParentId(parentId);
        statusInfo.setUserId(userId);
        statusInfoRepository.save(statusInfo);
    }

    private Questionnaire save(QuestionnaireReq req,
                               Questionnaire questionnaire,
                               Project project,
                               Investment investment,
                               List<Worker> workers,
                               List<Pilot> pilots,
                               List<Representative> representatives,
                               List<Contact> contacts,
                               List<InvestmentClub> investmentClubs,
                               SberFiveHundred sberFiveHundred,
                               List<QuestionnaireFunds> questionnaireFunds,
                               ImportReplaceDAO importReplaceDAO,
                               QuestionnaireLocaleDao questionnaireLocaleDao,
                               List<ProjectLocaleDao> projectLocaleDao,
                               InvestmentLocaleDao investmentLocaleDao,
                               ImportReplaceLangDao importReplaceLangDao) {
        if (!ConditionValidator.isEmptyList(workers))
            workerRepository.deleteByQuestionnaireIdAndLang(workers.get(0).getQuestionnaireId(), req.getLang());
        if (!ConditionValidator.isEmptyList(representatives))
            representativeRepository.deleteById(representatives.get(0).getQuestionnaireId());
        if (!ConditionValidator.isEmptyList(contacts))
            contactRepository.deleteByQuestionnaireIdAndLang(contacts.get(0).getQuestionnaireId(), req.getLang());
        if (!ConditionValidator.isEmptyList(investmentClubs))
            investmentClubRepository.deleteById(investmentClubs.get(0).getQuestionnaireId());
        if (!ConditionValidator.isEmptyList(questionnaireFunds))
            questionnaireFundsRepository.deleteById(questionnaireFunds.get(0).getQuestionnaireId());

        DaoBuilder daoBuilder = new DaoBuilder();
        daoBuilder.setQuestionnaire(questionnaire);
        daoBuilder.mainBuild(req);
        Questionnaire q = questionnaireRepository.save(daoBuilder.getQuestionnaire());
        Long qId = q.getQuestionnaireId();
        Long questionnaireId = qId;
        if (questionnaire != null) {
            questionnaireId = questionnaire.getQuestionnaireId();
        }
        daoBuilder.setId(qId);

        daoBuilder.setProject(project);
        daoBuilder.setInvestment(investment);
        daoBuilder.setWorkers(workers);
        daoBuilder.setPilots(pilots);
        daoBuilder.setRepresentatives(representatives);
        daoBuilder.setContacts(contacts);
        sberFiveHundred.setQuestionnaireId(qId);
        daoBuilder.setSberFiveHundred(sberFiveHundred);
        importReplaceDAO.setQuestionnaireId(qId);
        daoBuilder.setImportReplaceDAO(importReplaceDAO);
        daoBuilder.setQuestionnaireLocaleDao(questionnaireLocaleDao);
        daoBuilder.setProjectLocaleDao(projectLocaleDao.stream().filter(projectLoc -> req.getLang().equals(projectLoc.getLang())).findFirst().orElse(new ProjectLocaleDao()));
        daoBuilder.setInvestmentLocaleDao(investmentLocaleDao);
        daoBuilder.setImportReplaceLangDao(importReplaceLangDao);
        daoBuilder.build(req);

        if (daoBuilder.getQuestionnaireLocaleDao() != null)
            questionnaireLocaleDaoRepository.save(daoBuilder.getQuestionnaireLocaleDao());

        if (daoBuilder.getProject() != null && daoBuilder.getProject().getQuestionnaireId() != null) {
            Project savedProject = projectRepository.save(daoBuilder.getProject());
            ProjectLocaleDao projectLocale = daoBuilder.getProjectLocaleDao();
            projectLocale.setProjectId(savedProject.getProjectId());
            projectLocaleDao.stream()
                    .filter(projectLoc -> !req.getLang().equals(projectLoc.getLang()))
                    .forEach(pl -> {
                        pl.setProjectId(savedProject.getProjectId());
                        projectLocaleDaoRepository.save(pl);
                    });
            projectLocaleDaoRepository.save(projectLocale);
        }

        if (daoBuilder.getInvestment() != null && daoBuilder.getInvestment().getQuestionnaireId() != null) {
            investmentRepository.save(daoBuilder.getInvestment());
            investmentLocaleDaoRepository.save(daoBuilder.getInvestmentLocaleDao());
        }

        Boolean sber500 = req.getQuestionnaire() != null && Boolean.TRUE.equals(req.getQuestionnaire().getSber500());
        if (Boolean.TRUE.equals(sber500) || Boolean.TRUE.equals(daoBuilder.isSber500())) {
            sberFiveHundredRepository.save(daoBuilder.getSberFiveHundred());
        }

        Boolean isImport = req.getQuestionnaire() != null && Boolean.TRUE.equals(req.getQuestionnaire().getIsImport());
        if (Boolean.TRUE.equals(isImport)) {
            importReplaceDAORepository.save(daoBuilder.getImportReplaceDAO());
            importReplaceLangDaoRepository.save(daoBuilder.getImportReplaceLangDao());
        } else {
            importReplaceDAORepository.deleteByQuestionnaireId(qId);
            importReplaceLangDaoRepository.deleteByQuestionnaireId(qId);
        }
        pilotLocalDaoRepository.deleteByQuestionnaireIdAndPilot(questionnaireId);
        pilotRepository.deletePilotsByQuestionnaireId(questionnaireId);
        if (!CollectionUtils.isEmpty(req.getPilots())) {
            for (PilotDTO item : req.getPilots()) {
                if ((item.getName() != null
                        && !"".equals(item.getName())
                        && item.getSuggestCase() != null
                        && !"".equals(item.getSuggestCase()))
                        || Boolean.TRUE.equals(item.getEcoSystem())
                        || Boolean.TRUE.equals(item.getIsB2C())
                        || Boolean.TRUE.equals(item.getIsB2B())
                        || Boolean.TRUE.equals(item.getIsQuestionnaire())
                        || Boolean.TRUE.equals(item.getIsSuccess())) {
                    Pilot p = new Pilot();
                    p.setQuestionnaireId(qId);
                    p.setIsDisabled(nvl(item.getIsDisabled(), false));
                    p.setExperience(nvl(item.getExperience(), false));
                    p.setBusinessUnit(item.getBusinessUnit());
                    p.setConditions(item.getConditions());
                    p.setDepartment(item.getDepartment());
                    p.setPilot(nvl(item.getPilot(), false));
                    p.setReference(item.getReference());
                    p.setSuggestCase(item.getSuggestCase());
                    p.setFile(nvl(item.getFile(), false));
                    p.setName(item.getName());
                    p.setState(item.getState());
                    p.setIsBran(nvl(item.getIsBran(), false));
                    p.setTarget(item.getTarget());
                    p.setRelevance(item.getRelevance());
                    p.setEffect(item.getEffect());
                    p.setResources(item.getResources());
                    p.setSearch(nvl(item.getSearch(), false));
                    p.setDeadLine(item.getDeadLine());
                    p.setExp(item.getExp());
                    p.setCompany(item.getCompany());
                    p.setDecision(item.getDecision());
                    p.setIsForeign(nvl(item.getIsForeign(), false));
                    p.setDecisionCompany(item.getDecisionCompany());
                    p.setIsHub(nvl(item.getIsHub(), false));
                    p.setEcoSystem(nvl(item.getEcoSystem(), false));
                    p.setIsB2B(nvl(item.getIsB2B(), false));
                    p.setIsB2C(nvl(item.getIsB2C(), false));
                    p.setIsSuccess(nvl(item.getIsSuccess(), false));
                    p.setIsQuestionnaire(nvl(item.getIsQuestionnaire(), false));
                    p.setSite(item.getSite());
                    if (item.getPilotId() != null)
                        p.setPilotId(item.getPilotId());
                    else if (item.getPilot_id() != null)
                        p.setPilotId(item.getPilot_id());
                    Pilot pilotSaved = pilotRepository.save(p);
                    PilotLocalDao savedPilotLocal = pilotLocalDaoRepository.save(new PilotLocalDao(pilotSaved, req.getLang()));
                    if (!CollectionUtils.isEmpty(item.getResponse())) {
                        List<Response> resps = item
                                .getResponse()
                                .stream()
                                .map(i -> {
                                    Response r = new Response();
                                    r.setIsDisabled(i.getIsDisabled());
                                    r.setQuestion(i.getQuestion());
                                    r.setQuestionDescription(i.getQuestionDescription());
                                    r.setPilot(savedPilotLocal);
                                    return r;
                                })
                                .collect(Collectors.toList());
                        responseRepository.saveAll(resps);
                    }
                }
            }
        }

        if (!ConditionValidator.isEmptyList(daoBuilder.getContacts()))
            contactRepository.saveAll(daoBuilder.getContacts());

        if (!ConditionValidator.isEmptyList(daoBuilder.getRepresentatives()))
            representativeRepository.saveAll(daoBuilder.getRepresentatives());

        if (!ConditionValidator.isEmptyList(daoBuilder.getWorkers()))
            workerRepository.saveAll(daoBuilder.getWorkers());

        if (!CollectionUtils.isEmpty(req.getFounders())) {
            founderRepository.saveAll(req.getFounders().stream().map(item -> {
                Founder f = new Founder();
                f.setFio(item.getFio());
                f.setQuestionnaireId(qId);
                return f;
            }).collect(Collectors.toList()));
        }

        if (!CollectionUtils.isEmpty(req.getCommunityUsers())) {
            communityUserRepository.saveAll(req.getCommunityUsers().stream().map(item -> {
                CommunityUser c = new CommunityUser();
                c.setQuestionnaireId(qId);
                c.setAmbition(item.getAmbition());
                c.setState(item.getState());
                c.setUserId(item.getUserId());
                c.setExpectation(item.getExpectation());
                return c;
            }).collect(Collectors.toList()));
        }

        if (!CollectionUtils.isEmpty(req.getInvestorClubs())) {
            investmentClubRepository.saveAll(
                    req.getInvestorClubs().stream().map(item -> {
                        InvestmentClub c = new InvestmentClub();
                        c.setName(item.getName());
                        c.setRole(item.getRole());
                        c.setQuestionnaireId(qId);
                        c.setUserId(item.getUserId());
                        return c;
                    }).collect(Collectors.toList()));
        }

        if (req.getUserQuestionnaire() != null) {
            UserQuestionnaire u = new UserQuestionnaire();
            u.setPhoneNumber(req.getUserQuestionnaire().getPhoneNumber());
            u.setName(req.getUserQuestionnaire().getName());
            u.setPhoneNumber(req.getUserQuestionnaire().getPhoneNumber());
            u.setUserId(req.getUserQuestionnaire().getUserId());
            u.setQuestionnaireId(qId);
            u.setIsDisabled(false);
            u.setIsBran(false);
            u.setSberFh(false);
            u.setFirstName(req.getUserQuestionnaire().getFirstName());
            u.setLastName(req.getUserQuestionnaire().getLastName());
            u.setPosition(req.getUserQuestionnaire().getPosition());
            if (u.getName() == null
                    && req.getUserQuestionnaire().getFirstName() != null
                    && req.getUserQuestionnaire().getLastName() != null) {
                u.setName(req.getUserQuestionnaire().getFirstName() + " " + req.getUserQuestionnaire().getLastName());
            }
            userQuestionnaireRepository.save(u);
        }

        if (!CollectionUtils.isEmpty(req.getQuestionnaireFunds())) {
            questionnaireFundsRepository.saveAll(
                    req.getQuestionnaireFunds().stream().map(item -> {
                        QuestionnaireFunds qf = new QuestionnaireFunds();
                        qf.setQuestionnaireId(item.getQuestionnaireId());
                        qf.setBudget(item.getBudget());
                        qf.setAvgInvestment(item.getAvgInvestment());
                        return qf;
                    }).collect(Collectors.toList()));
        }
        return q;
    }

    private void savePopup(Long questionnaireId, Integer type) {
        popupInfoRepository.updatePopupByQuestionnaireIdWhereWatchedIsFalse(questionnaireId);
        PopupInfoDao newPopup = new PopupInfoDao();
        newPopup.setQuestionnaireId(questionnaireId);
        newPopup.setWatched(false);
        newPopup.setStatus(PopUpStatus.getProcessingStatus(type).getValue());
        Long usrId = Utils.getUserId(questionnaireId, userQuestionnaireRepository);
        newPopup.setUserId(usrId);
        popupInfoRepository.save(newPopup);
    }

}
