package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "FOUNDER")
@Data
public class Founder implements Serializable {

    private static final long serialVersionUID = -6413541142866687414L;

    @Id
    @Column(name = "FOUNDERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long founderId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "fio")
    private String fio;

}
