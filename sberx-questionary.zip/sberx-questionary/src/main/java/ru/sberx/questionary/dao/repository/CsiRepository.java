package ru.sberx.questionary.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.CsiDao;

import java.util.List;

@Repository
public interface CsiRepository extends CrudRepository<CsiDao, Long> {
    @NonNull
    @Override
    List<CsiDao> findAll();
}
