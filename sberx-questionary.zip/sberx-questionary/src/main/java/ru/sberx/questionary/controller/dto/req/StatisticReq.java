package ru.sberx.questionary.controller.dto.req;

import java.util.List;
import lombok.Data;

@Data
public class StatisticReq {
    private List<Integer> type;
    private Long dateFrom;
    private Long dateTo;
    private Long userId;
}
