package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Date;
import javax.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class ApplicationDto {

    private Long applicationId;
    @NotNull
    private Integer type;
    private Integer state;
    @JsonFormat(timezone = "GMT+3")
    private Date created;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    @NotNull
    private String firstName;
    @NotNull
    private String lastName;
    @NotNull
    private String phone;
    @NotNull
    private String position;
    @NotNull
    private String orgFullName;
    @NotNull
    private String site;
    @NotNull
    private String email;
    private Integer investorType;
    private String clickMethod;
    private String clickAction;
    private String login;
    private String tariff;
    private String tariffName;
    private String utm;
}
