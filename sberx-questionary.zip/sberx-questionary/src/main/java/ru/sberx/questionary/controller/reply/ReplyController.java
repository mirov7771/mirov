package ru.sberx.questionary.controller.reply;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.reply.dto.req.ReplyListReq;
import ru.sberx.questionary.controller.reply.dto.support.ReplyInfoDTO;
import ru.sberx.questionary.service.reply.ReplyService;

@RestController
@RequestMapping("${spring.application.name}/reply")
@RequiredArgsConstructor
public class ReplyController {

    private final ReplyService service;

    @GetMapping(value = "list", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> list(@RequestHeader(value = "user-id", required = false) Long userId,
                                  @RequestHeader(value = "locale", defaultValue = "ru") String locale,
                                  @RequestHeader(value = "role", defaultValue = "Client") String role,
                                  ReplyListReq req){
        req.setUserId(userId);
        req.setLocale(locale);
        req.setRole(role);
        return ResponseBuilder.build(service.list(req));
    }

    @GetMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@PathVariable("id") Long id,
                                 @RequestParam(value = "type", required = false) Integer type){
        return ResponseBuilder.build(service.get(id, type));
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestHeader("user-id") Long userId,
                                  @RequestBody ReplyInfoDTO req){
        req.setUserId(userId);
        return ResponseBuilder.build(service.post(req));
    }

    @PutMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> put(@PathVariable("id") Long id,
                                 @RequestBody ReplyInfoDTO req){
        req.setReplyId(id);
        return ResponseBuilder.build(service.put(req));
    }

}
