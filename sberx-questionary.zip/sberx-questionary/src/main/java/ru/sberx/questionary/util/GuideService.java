package ru.sberx.questionary.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.sberx.questionary.service.impl.method.ListMethod;

import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor
public class GuideService {

    //todo переделать на мидл
    public static String getState(Long state) {
        if (state != null) {
            if (state.equals(20001L)) {
                return "Draft";
            } else if (state.equals(20002L)) {
                return "На рассмотрении";
            } else if (state.equals(20003L)) {
                return "На доработку";
            } else if (state.equals(20004L)) {
                return "Активный";
            } else if (state.equals(20005L)) {
                return "Архивный";
            } else if (state.equals(20007L)) {
                return "Удачный пилот";
            } else if (state.equals(20008L)) {
                return "Предлагаемый кейс";
            } else if (state.equals(20009L)) {
                return "Отклоненный";
            } else if (state.equals(20012L)) {
                return "В работе";
            } else if (state.equals(20011L)) {
                return "На проверке";
            } else if (state.equals(20013L)) {
                return "Снято с публикации";
            } else if (state.equals(20014L)) {
                return "Не активна";
            } else if (state.equals(20015L)){
                return "Выполнена";
            }
        }
        return null;
    }

    public static String getStateV2(Long state) {
        if (state != null) {
            if (state.equals(20011L)) {
                return "Новый";
            } else if (state.equals(20002L)) {
                return "В работе";
            } else if (state.equals(20009L)) {
                return "Отказ";
            } else if (state.equals(20004L)) {
                return "Пилотируется";
            } else if (state.equals(20007L)) {
                return "Завершен";
            } else if (state.equals(20003L)) {
                return "Пауза";
            } else if (state.equals(20013L)) {
                return "Отозван";
            }
        }
        return null;
    }

    public static String getTypeName(Integer type) {
        if (type.equals(0))
            return "Стартап";
        else if (type.equals(1))
            return "Корпорация";
        else if (type.equals(2))
            return "Инвестор";
        return null;
    }

    public static String getStateSysName(Long sysName) {
        if (sysName.equals(20011L)) {
            return "verify";
        } else if (sysName.equals(20012L)) {
            return "to_work";
        } else if (sysName.equals(20001L)) {
            return "draft";
        } else if (sysName.equals(20002L)) {
            return "in_progress";
        } else if (sysName.equals(20004L)) {
            return "active";
        } else if (sysName.equals(20005L)) {
            return "archive";
        } else if (sysName.equals(20009L)) {
            return "rejected";
        } else if (sysName.equals(20013L)){
            return "round";
        } else if (sysName.equals(20003L)){
            return "revision";
        } else if (sysName.equals(20015L)){
            return "done";
        }
        return null;
    }

    public static String getTypeNameComApp(Integer type) {
        if (type == 0){
            return "StartUp";
        } else if (type == 1) {
            return "Corporate";
        } else if (type == 2) {
            return "BusinessAngel";
        } else if (type == 3) {
            return "VentureFund";
        } else if (type == 4) {
            return "FamilyOffice";
        } else if (type == 5) {
            return "MentorTracker";
        }
        return null;
    }

    public static final Long DRAFT_STATE = 20001L;
    public static final Long PROCESSING_STATE = 20002L;
    public static final Long TO_EDIT = 20003L;
    public static final Long CONFIRMED_STATE = 20004L;
    public static final Long ARCHIVE = 20005L;
    public static final Long FINISHED = 20007L;
    public static final Long SUGGEST_CASE_STATE = 20008L;
    public static final Long DENIED = 20009L;
    public static final Long SHORT_STATE = 20010L;
    public static final Long CHECKING_STATE = 20011L;
    public static final Long IN_PROGRESS_STATE = 20012L;
    public static final Long REMOVED = 20013L;
    public static final Long DISABLED = 20014L;
    public static final Long TO_DELETION = 20016L;
    public static final String QUESTIONNAIRE = "Questionnaire";
    public static final String PILOT = "Pilot";
    public static final String APPLICATION = "Application";
    public static final String ROUND = "Round";
    public static final String COMMUNITY = "Community_application";
    public static final String SYNDICATE_APPLICATION = "Syndicate_application";
    public static final String SCOUTING_APPLICATION = "Scouting_application";
    public static final String REPLY = "Reply";
    public static final String GEOGRAPHY = "Geography";

    public static final Integer STARTUP = 0;
    public static final Integer CORPORATE = 1;
    public static final Integer INVESTOR = 2;

    public static final String LANG_RU = "ru";

    public static final String ADMINISTRATOR_ROLE = "Administrator";

    public static String getRoundTypeName(Long l) {
        if (l.equals(6001L)) {
            return "Pre-seed";
        } else if (l.equals(6002L)) {
            return "Seed";
        } else if (l.equals(6006L)) {
            return "Late Seed";
        } else if (l.equals(6003L)) {
            return "Round A";
        } else if (l.equals(6004L)) {
            return "Round B";
        } else if (l.equals(6005L)) {
            return "Round C+";
        }
        return null;
    }

    //TODO переделать на справочник из sberx_guide
    @Getter
    public enum Staff {
        S9001(9001L, 1, 10),
        S9002(9002L, 11, 20),
        S9003(9003L, 21, 50),
        S9004(9004L, 51, 100),
        S9005(9005L, 101, 500),
        S9006(9006L, 501, 1000);

        private final Long code;
        public final Integer minValue;
        private final Integer maxValue;

        Staff(Long code, Integer minValue, Integer maxValue) {
            this.code = code;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }

        public static Staff getStaff(Long code){
            if (code != null){
                for(Staff s : Staff.values()){
                    if (s.getCode().equals(code))
                        return s;
                }
            }
            return null;
        }
    }

    public static String getInvestorType(Long id){
        if (id.equals(11001L)) {
            return "Венчурный фонд";
        } else if (id.equals(11002L)) {
            return "Бизнес-ангел";
        } else if (id.equals(11004L)) {
            return "Family Office";
        }
        //TODO добавить институт развития
        return null;
    }

    private static final ObjectMapper mapper = new ObjectMapper();
    private static final Map<String, String> SCHEMAS_MAP = new HashMap<>();
    static {
        SCHEMAS_MAP.put("reply_search_ru", "{\"clickable\": true,\"columns\": [{\"sysName\": \"pilot\",\"type\": \"string\",\"title\": \"Название запроса\",\"key\": \"pilotName\"},{\"sysName\": \"startup\",\"type\": \"string\",\"title\": \"Стартап\",\"key\": \"questionnaireName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Дата и время отклика\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20011\": \"Новый\",\"20002\": \"В работе\",\"20004\": \"Пилотируется\",\"20009\": \"Отказ\",\"20003\": \"Пауза\",\"20007\": \"Завершен\",\"20013\": \"Отозван\"}}}]}");
        SCHEMAS_MAP.put("offer_search_corp_ru", "{\"clickable\": true,\"columns\": [{\"sysName\": \"pilot\",\"type\": \"string\",\"title\": \"Название запроса\",\"key\": \"offerName\"},{\"sysName\": \"startup\",\"type\": \"string\",\"title\": \"Стартап\",\"key\": \"questionnaireName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Дата и время предложения\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20002\": \"В работе\",\"20003\": \"Пауза\",\"20004\": \"Пилотируется\",\"20007\": \"Завершен\",\"20009\": \"Отказ\",\"20011\": \"Новый\",\"20013\": \"Отозван\"}}}]}");
        SCHEMAS_MAP.put("offer_search_startup_ru", "{\"clickable\": true,\"columns\": [{\"sysName\": \"company\",\"type\": \"img\",\"title\": \"Корпорация\",\"key\": \"questionnaireLogo\",\"refs\": {\"labelKey\": \"questionnaireName\"}},{\"sysName\": \"pilot\",\"type\": \"string\",\"title\": \"Название запроса\",\"key\": \"offerName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Дата и время предложения\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20002\": \"В работе\",\"20003\": \"Пауза\",\"20004\": \"Пилотируется\",\"20007\": \"Завершен\",\"20009\": \"Отказ\",\"20011\": \"Новый\",\"20013\": \"Отозван\"}}}]}");
        SCHEMAS_MAP.put("pilots_reply_ru", "{\"clickable\": true,\"columns\": [{\"sysName\": \"startup\",\"type\": \"string\",\"title\": \"Стартап\",\"key\": \"questionnaireName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Дата и время отклика\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20002\": \"В работе\",\"20003\": \"Пауза\",\"20004\": \"Пилотируется\",\"20007\": \"Завершен\",\"20009\": \"Отказ\",\"20011\": \"Новый\",\"20013\": \"Отозван\"}}}]}");
        SCHEMAS_MAP.put("pilots_archive_ru", "{\"itemIdKey\": \"pilotId\",\"clickable\": true,\"columns\": [{\"sysName\": \"description\",\"type\": \"stringMain\",\"title\": \"Название пилота\",\"key\": \"name\",\"refs\": {\"maxLength\": \"100\"}},{\"sysName\": \"view\",\"type\": \"string\",\"title\": \"Просмотры\",\"key\": \"pilot_view\"},{\"sysName\": \"reply\",\"type\": \"string\",\"title\": \"Отклики\",\"key\": \"pilot_reply\",\"refs\": {\"labelKey\": \"pilot_newReply\"}},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20001\": \"Черновик\",\"20002\": \"На рассмотрении\",\"20003\": \"На доработку\",\"20004\": \"Активный\",\"20005\": \"Архив\",\"20007\": \"Удачный пилот\",\"20008\": \"Предлагаемый кейс\",\"20009\": \"Отклонен\"}}}]}");
        SCHEMAS_MAP.put("pilots_active_ru", "{\"itemIdKey\": \"pilotId\",\"clickable\": true,\"columns\": [{\"sysName\": \"description\",\"type\": \"stringMain\",\"title\": \"Название пилота\",\"key\": \"name\",\"refs\": {\"maxLength\": \"100\"}},{\"sysName\": \"view\",\"type\": \"string\",\"title\": \"Просмотры\",\"key\": \"pilot_view\"},{\"sysName\": \"reply\",\"type\": \"string\",\"title\": \"Отклики\",\"key\": \"pilot_reply\",\"refs\": {\"labelKey\": \"pilot_newReply\"}},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20001\": \"Черновик\",\"20002\": \"На рассмотрении\",\"20003\": \"На доработку\",\"20004\": \"Активный\",\"20005\": \"Архив\",\"20007\": \"Удачный пилот\",\"20008\": \"Предлагаемый кейс\",\"20009\": \"Отклонен\"}}}]}");
        SCHEMAS_MAP.put("pilots_user_ru", "{\"itemIdKey\": \"pilotId\",\"clickable\": true,\"columns\": [{\"sysName\": \"company\",\"type\": \"img\",\"title\": \"Компания\",\"key\": \"questionnaire.logoFile\",\"refs\": {\"labelKey\": \"questionnaire.name\"}},{\"sysName\": \"description\",\"type\": \"string\",\"title\": \"Потребность\",\"key\": \"suggestCase\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"Статус\",\"key\": \"state\",\"refs\": {\"map\": {\"20011\": \"Новый\",\"20002\": \"В работе\",\"20004\": \"Пилотируется\",\"20009\": \"Отказ\",\"20003\": \"Пауза\",\"20007\": \"Завершен\",\"20013\": \"Отозван\"}}}]}");

        SCHEMAS_MAP.put("reply_search_en", "{\"clickable\": true,\"columns\": [{\"sysName\": \"pilot\",\"type\": \"string\",\"title\": \"Request name\",\"key\": \"pilotName\"},{\"sysName\": \"startup\",\"type\": \"string\",\"title\": \"Startup\",\"key\": \"questionnaireName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Date and time of response\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20011\": \"New\",\"20002\": \"In work\",\"20004\": \"Piloting\",\"20009\": \"Decline\",\"20003\": \"Pause\",\"20007\": \"Finished\",\"20013\": \"Revoked\"}}}]}");
        SCHEMAS_MAP.put("offer_search_corp_en", "{\"clickable\": true,\"columns\": [{\"sysName\": \"pilot\",\"type\": \"string\",\"title\": \"Request name\",\"key\": \"offerName\"},{\"sysName\": \"startup\",\"type\": \"string\",\"title\": \"Startup\",\"key\": \"questionnaireName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Date and time of offer\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20002\": \"In work\",\"20003\": \"Pause\",\"20004\": \"Piloting\",\"20007\": \"Finished\",\"20009\": \"Decline\",\"20011\": \"New\",\"20013\": \"Revoked\"}}}]}");
        SCHEMAS_MAP.put("offer_search_startup_en", "{\"clickable\": true,\"columns\": [{\"sysName\": \"company\",\"type\": \"img\",\"title\": \"Corporate\",\"key\": \"questionnaireLogo\",\"refs\": {\"labelKey\": \"questionnaireName\"}},{\"sysName\": \"pilot\",\"type\": \"string\",\"title\": \"Request name\",\"key\": \"offerName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Date and time of offer\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20002\": \"In work\",\"20003\": \"Pause\",\"20004\": \"Piloting\",\"20007\": \"Finished\",\"20009\": \"Decline\",\"20011\": \"New\",\"20013\": \"Revoked\"}}}]}");
        SCHEMAS_MAP.put("pilots_reply_en", "{\"clickable\": true,\"columns\": [{\"sysName\": \"startup\",\"type\": \"string\",\"title\": \"Startup\",\"key\": \"questionnaireName\"},{\"sysName\": \"view_date\",\"type\": \"date\",\"title\": \"Дата и время отклика\",\"key\": \"date\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20002\": \"In work\",\"20003\": \"Pause\",\"20004\": \"Piloting\",\"20007\": \"Finished\",\"20009\": \"Decline\",\"20011\": \"New\",\"20013\": \"Revoked\"}}}]}");
        SCHEMAS_MAP.put("pilots_archive_en", "{\"itemIdKey\": \"pilotId\",\"clickable\": true,\"columns\": [{\"sysName\": \"description\",\"type\": \"stringMain\",\"title\": \"Pilot name\",\"key\": \"name\",\"refs\": {\"maxLength\": \"100\"}},{\"sysName\": \"view\",\"type\": \"string\",\"title\": \"Views\",\"key\": \"pilot_view\"},{\"sysName\": \"reply\",\"type\": \"string\",\"title\": \"Replies\",\"key\": \"pilot_reply\",\"refs\": {\"labelKey\": \"pilot_newReply\"}},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20001\": \"Draft\",\"20002\": \"Under consideration\",\"20003\": \"For revision\",\"20004\": \"Active\",\"20005\": \"Archive\",\"20007\": \"Success pilot\",\"20008\": \"Suggest case\",\"20009\": \"Decline\"}}}]}");
        SCHEMAS_MAP.put("pilots_active_en", "{\"itemIdKey\": \"pilotId\",\"clickable\": true,\"columns\": [{\"sysName\": \"description\",\"type\": \"stringMain\",\"title\": \"Pilot name\",\"key\": \"name\",\"refs\": {\"maxLength\": \"100\"}},{\"sysName\": \"view\",\"type\": \"string\",\"title\": \"Views\",\"key\": \"pilot_view\"},{\"sysName\": \"reply\",\"type\": \"string\",\"title\": \"Replies\",\"key\": \"pilot_reply\",\"refs\": {\"labelKey\": \"pilot_newReply\"}},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20001\": \"Draft\",\"20002\": \"Under consideration\",\"20003\": \"For revision\",\"20004\": \"Active\",\"20005\": \"Archive\",\"20007\": \"Success pilot\",\"20008\": \"Suggest case\",\"20009\": \"Decline\"}}}]}");
        SCHEMAS_MAP.put("pilots_user_en", "{\"itemIdKey\": \"pilotId\",\"clickable\": true,\"columns\": [{\"sysName\": \"company\",\"type\": \"img\",\"title\": \"Company\",\"key\": \"questionnaire.logoFile\",\"refs\": {\"labelKey\": \"questionnaire.name\"}},{\"sysName\": \"description\",\"type\": \"string\",\"title\": \"Need\",\"key\": \"suggestCase\"},{\"sysName\": \"status\",\"type\": \"nameplate\",\"title\": \"State\",\"key\": \"state\",\"refs\": {\"map\": {\"20011\": \"New\",\"20002\": \"In work\",\"20004\": \"Piloting\",\"20009\": \"Decline\",\"20003\": \"Pause\",\"20007\": \"Finished\",\"20013\": \"Revoked\"}}}]}");
    }

    public static Map<String, Object> getSchema(String name, String locale){
        try {
            if (SCHEMAS_MAP.get(name + "_" + locale) != null)
                return mapper.readValue(SCHEMAS_MAP.get(name + "_" + locale), new TypeReference<Map<String, Object>>() {});
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public static String getGuideValue(Long code){
        if (code == null)
            return null;
        for(Map<String, Object> i : ListMethod.guides){
            Long gCode = Utils.castToLong(i.get("code"));
            if (code.equals(gCode))
                return Utils.castToString(i.get("name"));
        }
        return null;
    }

}
