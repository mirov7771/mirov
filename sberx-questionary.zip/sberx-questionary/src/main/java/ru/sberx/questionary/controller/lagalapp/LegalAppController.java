package ru.sberx.questionary.controller.lagalapp;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.controller.lagalapp.req.PostLegalAppReq;
import ru.sberx.questionary.service.legalapp.LegalAppService;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("${spring.application.name}/legal-app")
@RequiredArgsConstructor
public class LegalAppController {

    private final LegalAppService service;

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> post(@RequestHeader(value = "user-id") Long userId,
                                     @RequestHeader(value = "locale", required = false, defaultValue = "ru") String locale,
                                     @Valid @RequestBody PostLegalAppReq req) {
        req.setUserId(userId);
        req.setLocale(locale);
        service.post(req);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
