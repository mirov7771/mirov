package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class DisabledReq {

    private Long userId;
    private List<Long> questionnaireId;

}
