package ru.sberx.questionary.gate.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import ru.sberx.dto.guide.guide.req.SearchReq;
import ru.sberx.questionary.controller.dto.support.GuideDto;
import ru.sberx.questionary.controller.dto.support.GuideV2Res;
import ru.sberx.questionary.gate.service.impl.GuideServiceImpl.GuideValueInfoRes;

public interface GuideService {
    List<GuideDto> getGuidesByNames(List<String> names);
    List<Map<String, Object>> getGuideById(Long id);
    List<GuideV2Res> getGuidesByIds(List<Long> ids);
    List<GuideDto> getGuideByGuideId(Long guideId);
    void updateSearch(SearchReq req);
}
