package ru.sberx.questionary.gate.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Date;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Notice {
    private Long id;
    private Long userId;
    private Long sendUserId;
    private String subject;
    private String body;
    private Date created;
    private Date watched;
    private Long templateId;
    private String templateSysName;
    private String event;
    private Map<String, Object> params;
    private String deeplink;
}
