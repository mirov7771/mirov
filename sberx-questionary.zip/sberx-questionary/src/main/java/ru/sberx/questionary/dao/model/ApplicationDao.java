package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.questionary.controller.dto.support.ApplicationDto;
import ru.sberx.questionary.controller.dto.support.Syndicate;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "APPLICATION")
@Setter
@Getter
@NoArgsConstructor
public class ApplicationDao implements Serializable {

    private static final long serialVersionUID = 2983946879602781529L;

    @Id
    @Column(name = "APPLICATION_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long applicationId;

    @Column(name = "TYPE")
    private Integer type;
    @Column(name = "STATE")
    private Integer state;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Column(name = "LAST_NAME")
    private String lastName;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "POSITION")
    private String position;
    @Column(name = "ORG_FULL_NAME")
    private String orgFullName;
    @Column(name = "SITE")
    private String site;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "INVESTOR_TYPE")
    private Integer investorType;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "LOGIN")
    private String login;
    @Column(name = "UID")
    private String uid;
    @Column(name = "NOTIFICATION_DTTM")
    private Date notificationDttm;
    @OneToOne
    @JoinColumn(name = "QUESTIONNAIRE_ID", insertable = false, updatable = false)
    private Questionnaire questionnaire;
    @Column(name = "TARIFF")
    private String tariff;
    @Column(name = "UTM")
    private String utm;


    public ApplicationDao(ApplicationDto dto) {
        this.type = dto.getType();
        this.created = dto.getCreated() == null ? new Date() : dto.getCreated();
        this.modified = dto.getModified() == null ? new Date() : dto.getModified();
        this.modified = new Date();
        this.firstName = dto.getFirstName();
        this.lastName = dto.getLastName();
        this.phone = dto.getPhone();
        this.position = dto.getPosition();
        this.orgFullName = dto.getOrgFullName();
        this.site = dto.getSite();
        this.email = dto.getEmail();
        this.investorType = dto.getInvestorType();
        this.tariff = dto.getTariff();
        this.utm = dto.getUtm();
    }

    public ApplicationDao(Syndicate syndicate) {
        this.type = syndicate.getType();
        this.firstName = syndicate.getFirstName();
        this.lastName = syndicate.getLastName();
        this.phone = syndicate.getPhone();
        this.position = syndicate.getPosition();
        this.orgFullName = syndicate.getOrgFullName();
        this.site = syndicate.getSite();
        this.email = syndicate.getEmail();
        this.investorType = 11002;
        this.state = GuideService.CHECKING_STATE.intValue();
        this.created = new Date();
        this.modified = new Date();
    }

    public ApplicationDto toDto() {
        ApplicationDto dto = new ApplicationDto();
        dto.setApplicationId(this.applicationId);
        dto.setType(this.type);
        dto.setState(this.state);
        dto.setCreated(this.created);
        dto.setModified(this.modified);
        dto.setFirstName(this.firstName);
        dto.setLastName(this.lastName);
        dto.setPhone(this.phone);
        dto.setPosition(this.position);
        dto.setOrgFullName(this.orgFullName);
        dto.setSite(this.site);
        dto.setEmail(this.email);
        dto.setInvestorType(this.investorType);
        dto.setLogin(this.login);
        dto.setTariff(this.tariff);
        dto.setUtm(this.utm);
        return dto;
    }

}
