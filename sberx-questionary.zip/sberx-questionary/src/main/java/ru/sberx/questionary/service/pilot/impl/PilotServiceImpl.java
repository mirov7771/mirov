package ru.sberx.questionary.service.pilot.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.JoinTableBuilder;
import ru.sberx.questionary.controller.dto.support.GuideDto;
import ru.sberx.questionary.controller.pilot.req.PilotListReq;
import ru.sberx.questionary.controller.pilot.res.PilotListRes;
import ru.sberx.questionary.controller.dto.support.Multilang;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.service.pilot.PilotService;
import ru.sberx.questionary.util.GuideService;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static ru.sberx.utils.validator.ConditionValidator.nvl;
import static ru.sberx.utils.validator.ConditionValidator.preValidate;

@Component
@RequiredArgsConstructor
@Slf4j
public class PilotServiceImpl implements PilotService {

    private final PilotRepository pilotRepository;
    private final ResponseRepository responseRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final UserAuth userAuth;
    private final ReplyRepository replyRepository;
    private final ru.sberx.questionary.gate.service.GuideService guideService;
    private final JoinTableBuilder joinTableBuilder;
    private final ObjectFavoriteRepository objectFavoriteRepository;
    private final ObjectActionRepository objectActionRepository;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;
    private static final List<GuideDto> INDUSTRIES = new ArrayList<>();

    @Value("${application.redirect}")
    private String action;
    @Value("${application.default}")
    private Long defaultId;

    private static final String ACTION_PILOT_IS_HUB = "/pilot%s&schema=pilots_active&id=%d&favorite=false&view=false&name=&filters=1";

    @PostConstruct
    public void setIndustries() {
        INDUSTRIES.addAll(guideService.getGuidesByNames(List.of("Industry")));
    }

    @Override
    public PilotListRes pilotList(PilotListReq req) {
        PilotListRes res = new PilotListRes();
        if (CollectionUtils.isEmpty(req.getState())) {
            if (StringUtils.hasText(req.getSchema())
                    && req.getSchema().equalsIgnoreCase("pilots_active")
                    && StringUtils.hasText(req.getId())) {
                req.setState(List.of(GuideService.CONFIRMED_STATE,
                        GuideService.DRAFT_STATE,
                        GuideService.PROCESSING_STATE,
                        GuideService.TO_EDIT,
                        GuideService.SUGGEST_CASE_STATE,
                        GuideService.FINISHED,
                        GuideService.IN_PROGRESS_STATE));
            } else {
                req.setState(List.of(GuideService.CONFIRMED_STATE));
            }
        }
        if (StringUtils.hasText(req.getFilters())) {
            if ("user".equalsIgnoreCase(req.getFilters())) {
                req.setQUserId(req.getCurrentUserId());
            } else {
                res.setFilters(INDUSTRIES);
            }
        }

        if (req.getCurrentUserId() != null) {
            Questionnaire q = questionnaireRepository.findAllByUserId(req.getCurrentUserId());
            req.setType(q != null ? q.getType() : 2);
        }

        res.setTotalRowCount(pilotRepository.countPilots(req));
        res.setLimitCount(res.getTotalRowCount());

        if (req.getRowCount() != null) {
            if (req.getPageToken() == null)
                req.setPageToken(0);

            res.setNextPageToken(req.getPageToken() + 1);
            if (!req.getPageToken().equals(0))
                req.setPageToken((int) Math.multiplyFull(req.getPageToken(), req.getRowCount()));
        }

        if (!CollectionUtils.isEmpty(INDUSTRIES)
                && !CollectionUtils.isEmpty(INDUSTRIES.get(0).getValues())
                && StringUtils.hasText(req.getName())) {
            for (GuideDto.Value g : INDUSTRIES.get(0).getValues()) {
                if (StringUtils.hasText(g.getName()) && g.getName().toUpperCase().contains(req.getName().toUpperCase())) {
                    req.getIndustriesVal().add(Long.valueOf(g.getCode()));
                    break;
                }
            }
        }

        res.setList(pilotRepository.findPilots(req));

        if (!CollectionUtils.isEmpty(res.getList()) && req.getPilotsPerCompany() != null && !req.getPilotsPerCompany().equals(0))
            res.setList(res.getList().stream().filter(i -> i.getNum() <= req.getPilotsPerCompany()).collect(Collectors.toList()));

        res.setRowCount(!CollectionUtils.isEmpty(res.getList()) ? res.getList().size() : 0);
        if (req.getRowCount() != null && req.getRowCount().compareTo(res.getRowCount()) > 0)
            res.setNextPageToken(null);

        res.setSchema(GuideService.getSchema(req.getSchema(), req.getLocale()));
        if (req.getCurrentUserId() != null)
            res.setFavoriteCount(pilotRepository.countFavoritePilot(req.getCurrentUserId(), GuideService.CONFIRMED_STATE));

        if (StringUtils.hasText(req.getRole()) && "CorpLight".equalsIgnoreCase(req.getRole()))
            res.setMaxPilots(5);

        return res;
    }

    @Override
    public PilotDTO getPilotById(Long pilotId, Long userId) {
        ru.sberx.questionary.dao.model.Pilot pilot = pilotRepository.findByPilotIdAndIsDisabled(pilotId, false);
        preValidate(pilot, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        Optional<PilotLocalDao> pilotLocalDao = pilotLocalDaoRepository.findByPilotId(pilotId).stream().findAny();
        PilotDTO res = new PilotDTO(pilot, pilotLocalDao.orElse(null), false);
        res.setPilotId(pilot.getPilotId());
        res.setPilot_id(pilot.getPilotId());
        buildPilotRes(res, pilot.getPilotId(), userId, pilot.getQuestionnaireId());
        List<PilotLocalDao> pilotLocalList = pilotLocalDaoRepository.findByPilotId(pilot.getPilotId());
        if (!CollectionUtils.isEmpty(pilotLocalList)) {
            res.setResponse(pilotLocalList.stream()
                    .filter(pl -> !CollectionUtils.isEmpty(pl.getResponseList()))
                    .flatMap(pl -> pl.getResponseList().stream())
                    .map(ru.sberx.questionary.controller.dto.support.Response::new)
                    .collect(Collectors.toList()));
        }
        return res;
    }

    @Override
    public PilotDTO createPilot(PilotDTO req) {
        PilotDTO res = new PilotDTO();
        if (req.getName() == null
                && req.getSuggestCase() == null
                && req.getPilotId() != null
                && !CollectionUtils.isEmpty(req.getResponse())) {
            PilotLocalDao pilotLocal = pilotLocalDaoRepository.findByPilotIdAndLang(req.getPilotId(), req.getLang());
            responseRepository.saveAll(req.getResponse().stream().map(item -> {
                Response r = new Response();
                r.setResponseId(item.getResponseId());
                r.setPilot(pilotLocal);
                r.setQuestion(item.getQuestion());
                r.setQuestionDescription(item.getQuestionDescription());
                r.setResponseNote(item.getResponseNote());
                r.setIsDisabled(false);
                return r;
            }).collect(Collectors.toList()));
            res.setPilotId(req.getPilotId());
        } else {
            validReqParam(req.getName(), req.getSuggestCase(), "");
            if (req.getQuestionnaireId() == null && req.getSessionId() != null) {
                try {
                    Long userId = userAuth.getUserId(req.getSessionId());
                    List<Questionnaire> q = questionnaireRepository.findByUserId(userId);
                    if (q != null && q.size() > 0)
                        req.setQuestionnaireId(q.get(0).getQuestionnaireId());
                } catch (Exception e) {
                    log.error("error in getting userId ", e);
                }
            }

            preValidate(questionnaireRepository.findByQuestionnaireId(nvl(req.getQuestionnaireId(), defaultId)), SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            Pilot pilot;
            if (req.getPilotId() != null) {
                pilot = pilotRepository.findByPilotId(req.getPilotId());
                preValidate(pilot, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            } else if (req.getPilot_id() != null) {
                pilot = pilotRepository.findByPilotId(req.getPilot_id());
                preValidate(pilot, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            } else {
                pilot = new ru.sberx.questionary.dao.model.Pilot();
            }
            Pilot savedPilot = savePilot(pilot, req);
            PilotLocalDao pilotLocalDao = pilotLocalDaoRepository.findByPilotIdAndLang(savedPilot.getPilotId(), req.getLang());
            if (pilotLocalDao == null) {
                pilotLocalDao = new PilotLocalDao(savedPilot, req.getLang());
            } else {
                pilotLocalDao.setName(req.getName());
                pilotLocalDao.setSuggestCase(res.getSuggestCase());
                pilotLocalDao.setBusinessUnit(StringUtils.hasText(req.getBusinessUnit()) ? req.getBusinessUnit() : pilotLocalDao.getBusinessUnit());
                pilotLocalDao.setDemoFile(StringUtils.hasText(req.getDemoFile()) ? req.getDemoFile() : pilotLocalDao.getDemoFile());
            }
            pilotLocalDaoRepository.save(pilotLocalDao);
            saveResponse(req.getResponse(), pilotLocalDao, req.getLang());

            res.setPilotId(savedPilot.getPilotId());
            res.setPilot_id(savedPilot.getPilotId());
        }
        res.setAction(action.replace("{type}", "4"));
        if (Boolean.TRUE.equals(req.getIsHub()))
            res.setAction(String.format(ACTION_PILOT_IS_HUB, res.getAction(), req.getQuestionnaireId()));
        return res;
    }

    @Override
    public PilotDTO createPilotV2(PilotDTO req, Long userId) {
        PilotDTO res = new PilotDTO();
        if (!CollectionUtils.isEmpty(req.getMultilang())) {
            Long pilotId = req.getPilotId() != null ? req.getPilotId() : req.getPilot_id();
            if (req.getQuestionnaireId() == null) {
                Questionnaire questionnaire = questionnaireRepository.findAllByUserId(userId);
                if (questionnaire != null)
                    req.setQuestionnaireId(questionnaire.getQuestionnaireId());
            }
            Pilot pilot;
            if (pilotId != null) {
                pilot = pilotRepository.findByPilotId(req.getPilotId());
                preValidate(pilot, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            } else {
                pilot = new ru.sberx.questionary.dao.model.Pilot();
            }
            Pilot savedPilot = savePilot(pilot, req);
            req.getMultilang().forEach(multilang -> {
                Multilang.FieldDto field = Optional.of(multilang.getFields())
                        .orElseThrow(() -> new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS));
                validReqParam(field.getName(), field.getSuggestCase(), multilang.getLang());
                PilotLocalDao pilotLocal = pilotLocalDaoRepository.findByPilotIdAndLang(savedPilot.getPilotId(), multilang.getLang());
                if (pilotLocal == null)
                    pilotLocal = new PilotLocalDao(savedPilot.getPilotId(), multilang.getLang(), field.getName(), field.getSuggestCase(), field.getBusinessUnit(), field.getDemoFile());
                else {
                    pilotLocal.setName(field.getName());
                    pilotLocal.setSuggestCase(field.getSuggestCase());
                    pilotLocal.setBusinessUnit(StringUtils.hasText(field.getBusinessUnit()) ? field.getBusinessUnit() : pilotLocal.getBusinessUnit());
                    pilotLocal.setDemoFile(StringUtils.hasText(field.getDemoFile()) ? field.getDemoFile() : pilotLocal.getDemoFile());
                }
                PilotLocalDao savedPilotLocal = pilotLocalDaoRepository.save(pilotLocal);
                saveResponse(field.getResponse(), savedPilotLocal, multilang.getLang());
            });
        }
        res.setAction(action.replace("{type}", "4"));
        if (Boolean.TRUE.equals(req.getIsHub()))
            res.setAction(String.format(ACTION_PILOT_IS_HUB, res.getAction(), req.getQuestionnaireId()));
        return res;
    }

    @Override
    public PilotDTO getPilotByIdV2(Long pilotId, Long userId, String lang) {
        Pilot pilot = Optional.of(pilotRepository.findByPilotIdAndIsDisabled(pilotId, false))
                .orElseThrow(() -> new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND));
        List<PilotLocalDao> pilotLocalList = pilotLocalDaoRepository.findByPilotId(pilot.getPilotId());
        if (CollectionUtils.isEmpty(pilotLocalList))
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND, "multilang pilot not exists");
        PilotDTO res = new PilotDTO(pilot, pilotLocalList.stream().filter(pl -> lang.equals(pl.getLang())).findAny().orElse(null), false);
        res.setPilotId(pilot.getPilotId());
        res.setPilot_id(pilot.getPilotId());
        res.setMultilang(new ArrayList<>());
        pilotLocalList.forEach(pilotLocal ->
                res.getMultilang().add(
                        new Multilang(pilotLocal.getLang(), Multilang.FieldDto.builder()
                                .name(pilotLocal.getName())
                                .businessUnit(pilotLocal.getBusinessUnit())
                                .suggestCase(pilotLocal.getSuggestCase())
                                .demoFile(pilotLocal.getDemoFile())
                                .response(CollectionUtils.isEmpty(pilotLocal.getResponseList())
                                        ? null
                                        : pilotLocal.getResponseList().stream().map(ru.sberx.questionary.controller.dto.support.Response::new).collect(Collectors.toList()))
                                .build())
                )
        );
        buildPilotRes(res, pilot.getPilotId(), userId, pilot.getQuestionnaireId());
        return res;
    }

    private void buildPilotRes(PilotDTO res, Long pilotId, Long userId, Long questionnaireId) {
        if (questionnaireId != null) {
            Questionnaire q = questionnaireRepository.findByQuestionnaireIdAndIsDisabled(questionnaireId, false);
            if (q != null) {
                List<UserQuestionnaire> byId = joinTableBuilder.getUserQuestionnaire(q.getQuestionnaireId());
                res.setQuestionnaire(new ru.sberx.questionary.controller.dto.support.Questionnaire(q, true, null, false));
                res.setUserId(joinTableBuilder.build(q, byId));
            }
        }
        if (userId != null) {
            List<Questionnaire> qList = questionnaireRepository.findByUserId(userId);
            if (!CollectionUtils.isEmpty(qList)) {
                List<ObjectFavoriteDao> favorites = objectFavoriteRepository.findByQuestionnaireIdInAndObjectIdAndObjectTypeAndUserId(
                        qList.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList()),
                        pilotId,
                        "Pilot",
                        userId);
                res.getQuestionnaire().setFavorite(!CollectionUtils.isEmpty(favorites));
                res.setFavorite(!CollectionUtils.isEmpty(favorites));
            }

            if (objectActionRepository.findByObjectIdAndObjectTypeAndActionAndUserId(pilotId, "Pilot", "view", userId).isEmpty())
                objectActionRepository.save(new ObjectAction(pilotId, "Pilot", "view", userId));
            List<ObjectAction> actions = objectActionRepository.findByObjectIdInAndObjectTypeAndAction(List.of(res.getPilotId()), "Pilot", "view");
            res.setViewCount(!CollectionUtils.isEmpty(actions) ? actions.size() : 0);

            List<Reply> replies = replyRepository.findByTableIdInAndTableNameAndUserIdOrderByReplyId(List.of(res.getPilotId()), "Pilot", userId);
            if (!CollectionUtils.isEmpty(replies)) {
                res.setReplyId(replies.get(0).getReplyId());
                res.setReplyComment(replies.get(0).getComment());
                res.setReplyDate(replies.get(0).getDate());
                res.setReplyState(replies.get(0).getState());
                res.setReplyUserId(replies.get(0).getUserId());
            }

        }
    }

    private void saveResponse(List<ru.sberx.questionary.controller.dto.support.Response> response, PilotLocalDao pilotLocal, String lang) {
        if (!CollectionUtils.isEmpty(response))
            response.removeIf(this::emptyResponse);
        if (!CollectionUtils.isEmpty(response)) {
            responseRepository.deleteByPilotIdAndLang(pilotLocal.getPilotId(), lang);
            responseRepository.saveAll(
                    response.stream()
                            .map(item -> new Response(item.getQuestion(), item.getQuestionDescription(), false, item.getResponseNote(), pilotLocal))
                            .collect(Collectors.toList()));
        }
    }

    private Pilot savePilot(Pilot pilot, PilotDTO dto) {
        if (dto.getQuestionnaireId() != null)
            pilot.setQuestionnaireId(dto.getQuestionnaireId());
        if (dto.getName() != null)
            pilot.setName(dto.getName());
        if (dto.getSuggestCase() != null)
            pilot.setSuggestCase(dto.getSuggestCase());
        if (dto.getBusinessUnit() != null)
            pilot.setBusinessUnit(dto.getBusinessUnit());
        if (dto.getDemoFile() != null)
            pilot.setDemoFile(dto.getDemoFile());
        if (dto.getConditions() != null)
            pilot.setConditions(dto.getConditions());
        if (dto.getIndustry() != null)
            pilot.setIndustry(dto.getIndustry());
        if (dto.getTarget() != null)
            pilot.setTarget(dto.getTarget());
        if (dto.getRelevance() != null)
            pilot.setRelevance(dto.getRelevance());
        if (dto.getEffect() != null)
            pilot.setEffect(dto.getEffect());
        if (dto.getResources() != null)
            pilot.setResources(dto.getResources());
        if (dto.getDeadLine() != null)
            pilot.setDeadLine(dto.getDeadLine());
        if (dto.getExp() != null)
            pilot.setExp(dto.getExp());
        if (dto.getCompany() != null)
            pilot.setCompany(dto.getCompany());
        if (dto.getDecisionCompany() != null)
            pilot.setDecisionCompany(dto.getDecisionCompany());
        if (dto.getDecision() != null)
            pilot.setDecision(dto.getDecision());
        if (dto.getTargetOption() != null)
            pilot.setTargetOption(dto.getTargetOption());
        pilot.setState(GuideService.DRAFT_STATE);
        if (dto.getSite() != null)
            pilot.setSite(dto.getSite());
        if (dto.getCreatorId() != null)
            pilot.setCreatorId(dto.getCreatorId());

        pilot.setIsHub(nvl(dto.getIsHub(), nvl(pilot.getIsHub(), false)));
        pilot.setIsDisabled(false);
        pilot.setIsForeign(nvl(dto.getIsForeign(), nvl(pilot.getIsForeign(), false)));
        pilot.setIsBran(nvl(dto.getIsBran(), nvl(pilot.getIsBran(), false)));
        pilot.setIsPublished(nvl(dto.getIsPublished(), nvl(pilot.getIsPublished(), false)));
        pilot.setEcoSystem(nvl(dto.getEcoSystem(), nvl(pilot.getEcoSystem(), false)));
        pilot.setIsB2B(nvl(dto.getIsB2B(), nvl(pilot.getIsB2B(), false)));
        pilot.setIsB2C(nvl(dto.getIsB2C(), nvl(pilot.getIsB2C(), false)));
        pilot.setIsSuccess(nvl(dto.getIsSuccess(), nvl(pilot.getIsSuccess(), false)));
        pilot.setIsQuestionnaire(nvl(dto.getIsQuestionnaire(), nvl(pilot.getIsQuestionnaire(), false)));
        pilot.setSearch(nvl(dto.getSearch(), nvl(pilot.getSearch(), false)));
        pilot.setFile(nvl(dto.getFile(), nvl(pilot.getFile(), false)));
        pilot.setCreated(pilot.getCreated() == null ? new Date() : pilot.getCreated());
        pilot.setModified(new Date());
        return pilotRepository.save(pilot);
    }

    private boolean emptyResponse(ru.sberx.questionary.controller.dto.support.Response item) {
        return (item.getQuestion() == null || "".equals(item.getQuestion()));
    }

    private void validReqParam(String name, String suggestCase, String lang) {
        if (name == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required param: name");
        if (suggestCase == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required param: suggestCase");
        if (lang == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required param: lang");
    }

}
