package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import com.vladmihalcea.hibernate.type.array.StringArrayType;
import lombok.*;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "QUESTIONNAIRE")
@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@TypeDefs({
        @TypeDef(name = "string-array", typeClass = StringArrayType.class),
        @TypeDef(name = "long-array", typeClass = LongArrayType.class)
})
@ToString
public class Questionnaire implements Serializable {

    private static final long serialVersionUID = -2747155807109208980L;

    @Id
    @Column(name = "QUESTIONNAIREID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long questionnaireId;
    @Column(name = "UID")
    private UUID uuid;
    @Column(name = "NAME")
    private String name;
    @Column(name = "FULLNAME")
    private String fullName;
    @Column(name = "BIRTHDAY")
    private Date birthDay;
    @Column(name = "LOCATION")
    private String location;
    @Column(name = "LOGO_FILE")
    private String logoFile;
    @Column(name = "LEGAL_REGISTERED")
    private Boolean legalRegistered;
    @Column(name = "STATUS")
    private Integer status;
    @Column(name = "MENTORING")
    private Boolean mentoring;
    @Column(name = "TURNOVER")
    private String turnOver;
    @Column(name = "SITE")
    private String site;
    @Type(type = "long-array")
    @Column(name = "STADY")
    private long[] stady;
    @Column(name = "NOTE")
    private String note;
    @Type(type = "long-array")
    @Column(name = "INNOVATIONMETHOD")
    private long[] innovationMethod;
    @Type(type = "long-array")
    @Column(name = "INDUSTRY")
    private Long[] industry;
    @Column(name = "MAILNEWS")
    private Boolean mailNews;
    @Type(type = "long-array")
    @Column(name = "ROUND")
    private long[] round;
    @Column(name = "CLUB")
    private Boolean club;
    @Column(name = "REPRESENTATIVE")
    private Boolean representative;
    @Column(name = "TYPE")
    private Integer type;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "ISBRAN")
    private Boolean isBran;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "MODIFIED")
    private Date modified;
    @Type(type = "long-array")
    @Column(name = "GEOGRAPHY")
    private long[] geography;
    @Type(type = "string-array")
    @Column(name = "TAGS")
    private String[] tags;
    @Column(name = "PHONENUMBER")
    private String phoneNumber;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "OWNER")
    private Long owner;
    @Column(name = "INVITEFIO")
    private String inviteFio;
    @Column(name = "INVITEUNIT")
    private String inviteUnit;
    @Column(name = "INVITEUSER")
    private Long inviteUser;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "PARENTID")
    private Long parentId;
    @Column(name = "INVESTORTYPE")
    private Long investorType;
    @Column(name = "REGISTRATIONCOUNTRY")
    private Long registrationCountry;
    @Column(name = "SUCCESSFULLCASE")
    private Boolean successfullCase;
    @Column(name = "SCOUTING")
    private Boolean scouting;
    @Column(name = "STARTUPINVESTMENTYEARS")
    private Integer startupInvestmentYears;
    @Column(name = "LASTYEARINVESTMENTSCOUNT")
    private Integer lastYearInvestmentsCount;
    @Column(name = "OVERALLPILOTS")
    private Integer overallPilots;
    @Column(name = "OVERALLCONTRACTS")
    private Integer overallContracts;
    @Column(name = "COMMUNITYSTATE")
    private String communityState;
    @Column(name = "ALLDEALSNUMBER")
    private Integer allDealsNumber;
    @Column(name = "EXITDEALSNUMBER")
    private Integer exitDealsNumber;
    @Column(name = "ACTIVEDEALSNUMBER")
    private Integer activeDealsNumber;
    @Column(name = "ACCELERATOR")
    private Boolean accelerator;
    @Column(name = "LOCATIONCOUNTRY")
    private Long locationCountry;
    @Column(name = "COMMUNITY")
    private Boolean community;
    @Column(name = "SUCCESSPILOTS")
    private Boolean successPilots;
    @Column(name = "PILOT")
    private Boolean pilot;
    @Column(name = "SUCCESSPILOTSB2C")
    private Boolean successPilotsB2C;
    @Column(name = "ISNEW")
    private Boolean isNew;
    @Column(name = "PORTFOLIONOTE")
    private String portfolioNote;
    @Type(type = "long-array")
    @Column(name = "BUSINESSMODEL")
    private long[] businessModel;
    @Column(name = "FORLENDING")
    private Boolean forLending;
    @Column(name = "TRANSCRIPTION")
    private String transcription;
    @Type(type = "long-array")
    @Column(name = "ACCELERATORCODE")
    private long[] acceleratorCode;
    @Column(name = "PRIORITY")
    private Integer priority;
    @Column(name = "FULLNOTE")
    private String fullNote;
    @Type(type = "long-array")
    @Column(name = "TECHNOLOGY")
    private Long[] technology;
    @Column(name = "REVISION_DATE")
    private Date revisionDate;
    @Column(name = "INN")
    private String inn;
    @Column(name = "ACCELERATORSITE")
    private String acceleratorSite;
    @Column(name = "SEND_INVEST_NOTIFY")
    private Boolean sendInvestNotify;
    @Column(name = "SEND_INVEST_PLAN_NOTIFY")
    private Boolean sendInvestPlanNotify;
    @Column(name = "SBER500")
    private Boolean sber500;
    @Column(name = "RESPONSIBLE")
    private Long responsible;
    @Column(name = "RESPONSIBLELOGIN")
    private String responsibleLogin;
    @Column(name = "UPDATE_DATE_FOR_SORT")
    private Date updateDateForSort;
    @Column(name = "NOT_NEW")
    private Boolean notNew;
    @Column(name = "enableoffers")
    private Boolean enableOffers;
    @Column(name = "is_send_processing")
    private Boolean isSendProcessing;
    @Column(name = "IS_MARKETING")
    private String isMarketing;
    @Column(name = "IS_IMPORT")
    private Boolean isImport;
    @Column(name = "ACCELERATOR_STRING")
    private String acceleratorString;
    @Column(name = "LAST_ENTER")
    private Date lastEnter;
    @Type(type = "string-array")
    @Column(name = "LANGUAGES")
    private String[] languages;
    @Column(name = "MAIN_LANGUAGE")
    private String mainLanguage;
    @Column(name = "LABEL_NEW")
    private Date labelNew;
    @Column(name = "UTM")
    private String utm;

    public void cleanFields() {
         this.name = null;
         this.fullName = null;
         this.birthDay = null;
         this.location = null;
         this.logoFile = null;
         this.legalRegistered = false;
         this.status = null;
         this.mentoring = false;
         this.turnOver = null;
         this.site = null;
         this.stady = null;
         this.note = null;
         this.innovationMethod = null;
         this.industry = null;
         this.mailNews = false;
         this.round = null;
         this.club = false;
         this.representative = false;
         this.isBran = false;
         this.isDisabled = false;
         this.geography = null;
         this.tags = null;
         this.phoneNumber = null;
         this.email = null;
         this.owner = null;
         this.inviteFio = null;
         this.inviteUnit = null;
         this.inviteUser = null;
         this.comment = null;
         this.parentId = null;
         this.investorType = null;
         this.registrationCountry = null;
         this.successfullCase = null;
         this.scouting = null;
         this.startupInvestmentYears = null;
         this.lastYearInvestmentsCount = null;
         this.overallPilots = null;
         this.overallContracts = null;
         this.communityState = null;
         this.allDealsNumber = null;
         this.exitDealsNumber = null;
         this.activeDealsNumber = null;
         this.accelerator = false;
         this.locationCountry = null;
         this.community = false;
         this.successPilots = false;
         this.pilot = false;
         this.successPilotsB2C = false;
         this.portfolioNote = null;
         this.businessModel = null;
         this.forLending = false;
         this.transcription = null;
         this.acceleratorCode = null;
         this.priority = null;
         this.fullNote = null;
         this.technology = null;
         this.revisionDate = null;
         this.inn = null;
         this.acceleratorSite = null;
         this.sendInvestNotify = false;
         this.sendInvestPlanNotify = false;
         this.sber500 = false;
         this.responsible = null;
         this.responsibleLogin = null;
         this.updateDateForSort = null;
         this.notNew = null;
         this.enableOffers = null;
         this.isSendProcessing = false;
         this.isImport = false;
         this.acceleratorString = null;
         this.lastEnter = null;
         this.languages = null;
         this.mainLanguage = null;
    }
}
