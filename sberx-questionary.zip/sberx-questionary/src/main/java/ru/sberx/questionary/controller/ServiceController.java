package ru.sberx.questionary.controller;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.dto.questionary.questionary.questionary.req.PostUserQuestionnaireReq;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.dto.req.*;
import ru.sberx.questionary.controller.dto.support.*;
import ru.sberx.questionary.service.Service;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.UUID;

@RestController
@RequestMapping("sberx-questionary")
@RequiredArgsConstructor
public class ServiceController {

    private final Service service;
    private final String APPLICATION_JSON_VALUE = "application/json;charset=UTF-8";

    @GetMapping(value = "list/questionnaire", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> questionnaire(@RequestHeader("requestId") String requestId,
                                           @RequestHeader("client-id") Long clientId,
                                           QuestionnaireListReq req) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", String.valueOf(clientId));
        return ResponseBuilder.build(service.getParticipantList(clientId, req));
    }

    @GetMapping(value = "view-card", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> viewCard(@RequestHeader("requestId") String requestId,
                                      @RequestParam(value = "id", required = false) Long id,
                                      @RequestParam(value = "uuid", required = false) UUID uuid,
                                      @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.viewCard(id, uuid, sessionId));
    }


    @GetMapping(value = "type", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> type(@RequestHeader("requestId") String requestId,
                                  @RequestParam("userId") Long userId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getTypeByUserId(userId));
    }

    @GetMapping(value = "questionary", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getQuestionary(@RequestHeader("requestId") String requestId,
                                            @RequestHeader(value = "user-id", required = false) Long userId,
                                            @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                            @RequestParam(value = "uuid", required = false) String uuid,
                                            @RequestParam(value = "parentId", required = false) Long parentId,
                                            @RequestParam(value = "lang", defaultValue = "ru") String lang,
                                            @RequestParam(value = "isEdit", required = false) Boolean isEdit) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getQuestionaryById(questionnaireId, uuid, parentId, userId, lang, isEdit));
    }

    @PostMapping(value = "questionary", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> postQuestionary(@RequestHeader("requestId") String requestId,
                                             @RequestHeader(value = "user-id", required = false) Long userId,
                                             @Valid @RequestBody QuestionnaireReq req) {
        ThreadContext.put("requestId", requestId);
        req.notValid();
        req.setUserId(userId);
        return ResponseBuilder.build(service.createQuestionary(req));
    }

    @DeleteMapping(value = "questionary/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> deleteQuestionnaire(@RequestHeader("requestId") String requestId
            , @PathVariable("id") Long questionnaireId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.deleteQuestionnaire(questionnaireId));
    }

    @PutMapping(value = "/questionary/{id}/priority", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeQuestionnairePriority(@RequestHeader("requestId") String requestId,
                                                         @PathVariable("id") Long questionnaireId,
                                                         @Valid @RequestBody QuestionnairePriority req) {
        req.setQuestionnaireId(questionnaireId);
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.updateQuestionnairePriority(req));
    }

    @PutMapping(value = "/questionary/{id}/responsible", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeQuestionnaireResponsible(@RequestHeader("requestId") String requestId,
                                                            @PathVariable("id") Long questionnaireId,
                                                            @Valid @RequestBody QuestionnaireResponsible req) {
        req.setQuestionnaireId(questionnaireId);
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.updateQuestionnaireResponsible(req));
    }

    @PutMapping(value = "/questionary/{id}/offer")
    public ResponseEntity<?> updateQuestionnaireOffer(@RequestHeader("requestId") String requestId,
                                                      @RequestHeader(value = "role", required = false) String role,
                                                      @PathVariable("id") @NotBlank String questionnaireId,
                                                      @Valid @RequestBody OffersReq req) {
        ThreadContext.put("requestId", requestId);
        service.updateQuestionnaireOffer(questionnaireId, req, role);
        return ResponseBuilder.build(null);
    }

    @PutMapping(value = "/questionary/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateQuestionnaire(@RequestHeader("requestId") String requestId,
                                                 @RequestHeader(value = "role", required = false) String role,
                                                 @PathVariable("id") Long questionnaireId,
                                                 @Valid @RequestBody QuestionnaireUpdateReq req) {
        req.setQuestionnaireId(questionnaireId);
        ThreadContext.put("requestId", requestId);
        service.updateQuestionnaire(req, role);
        return ResponseBuilder.build(null);
    }

    @PostMapping(value = "draft", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> draft(@RequestHeader("requestId") String requestId,
                                   @Valid @RequestBody DraftReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createDraft(req));
    }

    @PostMapping(value = "verify", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> verify(@RequestHeader("requestId") String requestId,
                                    @Valid @RequestBody VerifyReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.verify(req));
    }



    @PostMapping(value = "feedback", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> postFeedback(@RequestHeader("requestId") String requestId,
                                          @Valid @RequestBody FeedBack req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createFeedBack(req));
    }

    @PostMapping(value = "disabled", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> disabled(@RequestHeader("requestId") String requestId,
                                      @RequestBody DisabledReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.disabled(req));
    }

    @PostMapping(value = "application", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> postApplication(@RequestHeader("requestId") String requestId,
                                             @Valid @RequestBody ApplicationDto dto) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createApplication(dto));
    }

    @GetMapping(value = "application", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getApplicationById(@RequestHeader("requestId") String requestId,
                                                @RequestParam(value = "id", required = false) Long id,
                                                @RequestParam(value = "email", required = false) String email) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getApplicationById(id, email));
    }

    @GetMapping(value = "application/{UID}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getApplicationByUid(@RequestHeader("requestId") String requestId,
                                                 @PathVariable("UID") String uid,
                                                 @RequestParam(value = "auth", required = false) Boolean auth) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getApplicationByUid(uid, auth));
    }

    @GetMapping(value = "list/application", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getApplicationList(@RequestHeader("requestId") String requestId,
                                                ApplicationListReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getApplicationList(req));
    }

    @GetMapping(value = "popup/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPopup(@RequestHeader("requestId") String requestId,
                                      @PathVariable("id") Long id) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getPopupStatus(id));
    }

    @GetMapping(value = "v2/popup/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPopupV2(@RequestHeader("requestId") String requestId,
                                        @RequestHeader("client-id") String clientId,
                                        @RequestHeader("user-id") Long userId,
                                        @RequestHeader("locale") String locale,
                                        @PathVariable("id") Long id) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", clientId);
        ThreadContext.put("user-id", String.valueOf(userId));
        return ResponseBuilder.build(service.getPopupStatusV2(id, userId, locale));
    }

    @GetMapping(value = "v2/popup", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPopupByUserId(@RequestHeader("requestId") String requestId,
                                              @RequestHeader("client-id") String clientId,
                                              @RequestHeader("user-id") Long userId,
                                              @RequestHeader("locale") String locale){
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", clientId);
        ThreadContext.put("user-id", String.valueOf(userId));
        return ResponseBuilder.build(service.getPopupStatusV2(null, userId, locale));
    }

    @GetMapping(value = "user/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserById(@RequestHeader("requestId") String requestId,
                                         @PathVariable("id") Long id,
                                         @RequestParam(name = "getQuestionnaireUserIdOnly", required = false)
                                             Boolean getQuestionnaireUserIdOnly) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getUserById(id, getQuestionnaireUserIdOnly));
    }

    @PostMapping(value = "round", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> round(@RequestHeader("requestId") String requestId,
                                   @RequestHeader(value = "user-id", required = false) Long userId,
                                   @Valid @RequestBody RoundReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createRound(req, userId));
    }

    @GetMapping(value = "round", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getRoundById(@RequestHeader("requestId") String requestId,
                                          @RequestHeader(value = "user-id", required = false) Long userId,
                                          @RequestParam(value = "roundId", required = false) Long roundId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getRoundById(roundId, userId));
    }

    @GetMapping(value = "list/round", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getRoundList(@RequestHeader("requestId") String requestId,
                                          @RequestHeader(value = "user-id", required = false) Long userId,
                                          @RequestHeader(value = "role", required = false) String role,
                                          @RequestHeader(value = "locale", required = false) String locale,
                                          RoundListReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getRoundList(req, userId, role, locale));
    }

    @PutMapping(value = "/round/{roundId}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeRound(@RequestHeader("requestId") String requestId,
                                         @PathVariable("roundId") Long roundId,
                                         @Valid @RequestBody RoundReq req) {
        ThreadContext.put("requestId", requestId);
        service.updateRound(req, roundId);
        return ResponseEntity.ok().build();
    }

    @PostMapping(value = "v2/round", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> roundV2(@RequestHeader("requestId") String requestId,
                                     @RequestHeader(value = "user-id", required = false) Long userId,
                                     @Valid @RequestBody RoundReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.createRoundV2(req, userId));
    }

    @GetMapping(value = "v2/round", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getRoundByIdV2(@RequestHeader("requestId") String requestId,
                                            @RequestHeader(value = "user-id", required = false) Long userId,
                                            @RequestParam(value = "roundId", required = false) Long roundId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getRoundByIdV2(roundId, userId));
    }

    @PutMapping(value = "/v2/round/{roundId}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeRoundV2(@RequestHeader("requestId") String requestId,
                                         @PathVariable("roundId") Long roundId,
                                         @Valid @RequestBody RoundReq req) {
        ThreadContext.put("requestId", requestId);
        service.updateRoundV2(req, roundId);
        return ResponseEntity.ok().build();
    }


    @PutMapping(value = "/add-favorite", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addFavorite(@RequestHeader("requestId") String requestId,
                                         @RequestHeader("user-id") Long userId,
                                         @RequestBody AddFavoriteReq req) {
        ThreadContext.put("requestId", requestId);
        service.addFavorite(req, userId);
        return ResponseEntity.ok().body(null);
    }

    @PostMapping(value = "community", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> postCommunity(@RequestHeader("requestId") String requestId,
                                           @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId,
                                           @RequestBody Community req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.postCommunity(req, sessionId));
    }

    @GetMapping(value = "community", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getCommunity(@RequestHeader("requestId") String requestId,
                                          @RequestHeader(value = "user-id", required = false) Long userId,
                                          @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId,
                                          @RequestParam(value = "id", required = false) Long id) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getCommunity(id, sessionId, userId));
    }

    @GetMapping(value = "community/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getCommunityList(@RequestHeader("requestId") String requestId,
                                              CommunityListReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getCommunityList(req));
    }

    @PutMapping(value = "/community/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> changeCommunity(@RequestHeader("requestId") String requestId,
                                             @PathVariable("id") Long id,
                                             @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId,
                                             @RequestBody Community req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.changeCommunity(req, id, sessionId));
    }

    @GetMapping(value = "type/{userid}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> typeByUserId(@RequestHeader("requestId") String requestId,
                                          @PathVariable("userid") Long userId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getOneTypeByUserId(userId));
    }

    @GetMapping(value = "type/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> typeList(@RequestHeader("requestId") String requestId,
                                      TypeListReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getTypeList(req));
    }

    @GetMapping(value = "/questionary/{id}/status-history", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getStatusHistory(@RequestHeader("requestId") String requestId,
                                              @PathVariable("id") Long questionaryId,
                                              StatusHistoryReq req) {
        ThreadContext.put("requestId", requestId);
        req.setQuestionnaireId(questionaryId);
        return ResponseBuilder.build(service.getStatusHistory(req));
    }

    @PostMapping(value = "syndicate", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveSyndicate(@RequestHeader("requestId") String requestId,
                                           @RequestBody Syndicate req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.saveSyndicate(req));
    }

    @GetMapping(value = "/syndicate/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> syndicateList(@RequestHeader("requestId") String requestId,
                                           SyndicateReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getSyndicateList(req));
    }

    @GetMapping(value = "syndicate", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getSyndicateQuestionnaire(@RequestHeader("requestId") String requestId,
                                                       @RequestParam(value = "id", required = false) Long id,
                                                       @RequestParam(value = "uid", required = false) String uid) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getSyndicateQuestionnaire(id, uid));
    }

    @GetMapping(value = "/list/questionnaire-guid", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getQuestionnaireGuidList(@RequestHeader("requestId") String requestId,
                                                      @RequestHeader("client-id") String clientId,
                                                      @RequestParam(value = "type") Integer type) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", clientId);
        return ResponseBuilder.build(service.getQuestionnaireGuidList(type));
    }

    @GetMapping(value = "scouting/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> scoutingList(@RequestHeader("requestId") String requestId,
                                          ScoutingListReq req) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.scoutingList(req));
    }

    @GetMapping(value = "scouting/{uid}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getScoutingById(@RequestHeader("requestId") String requestId,
                                             @PathVariable("uid") UUID uid) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getScoutingById(uid));
    }

    @PostMapping(value = "scouting", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveScouting(@RequestHeader("requestId") String requestId,
                                          @RequestHeader("user-id") Long userId,
                                          @RequestBody ScoutingDto req) {
        ThreadContext.put("requestId", requestId);
        req.setUserId(userId);
        return ResponseBuilder.build(service.saveScouting(req));
    }

    @GetMapping(value = "userlist/{externalId}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserList(@RequestHeader("requestId") String requestId,
                                         @PathVariable("externalId") Long externalId) {
        ThreadContext.put("requestId", requestId);
        return ResponseBuilder.build(service.getUserList(externalId));
    }

    @PostMapping(value = "userquestionnaire", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> saveUserQuestionnaire(@RequestHeader("requestId") String requestId,
                                                   @RequestBody PostUserQuestionnaireReq req) {
        ThreadContext.put("requestId", requestId);
        service.saveUserQuestionnaire(req);
        return ResponseBuilder.build(null);
    }
}
