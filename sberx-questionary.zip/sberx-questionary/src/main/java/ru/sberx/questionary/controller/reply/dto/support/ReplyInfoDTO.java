package ru.sberx.questionary.controller.reply.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.controller.dto.support.Project;
import ru.sberx.questionary.controller.dto.support.Questionnaire;
import ru.sberx.questionary.controller.dto.support.Response;

import java.util.Date;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ReplyInfoDTO {
    private Long replyId;
    private Long userId;
    private String note;
    private String fileUrl;
    @JsonProperty("fileURL")
    private String fileURLString;
    private Long state;
    @JsonFormat(timezone = "GMT+3")
    private Date date;
    private String tableId;
    private List<QuestionDTO> questions;
    private String cost;
    private String process;
    private Boolean isViewed;
    private String comment;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    private String offerName;
    private String offerDescription;
    private String tableName;
    private Boolean isPilotOffer;
    private Long questionnaireId;
    private Long pilotId;
    private ReplyInfoDTO reply;
    private List<CommentDTO> comments;
    private Questionnaire questionnaire;
    private Project project;
    private List<PilotDTO> b2bPilots;
    private List<Response> response;
}
