package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class Response {

    private Long responseId;
    private String question;
    private String questionDescription;
    private Boolean isDisabled;
    private String responseNote;

    public Response(ru.sberx.questionary.dao.model.Response response) {
        this.responseId = response.getResponseId();
        this.question = response.getQuestion();
        this.questionDescription = response.getQuestionDescription();
        this.responseNote = response.getResponseNote();
        this.isDisabled = Boolean.TRUE.equals(response.getIsDisabled());
    }
}
