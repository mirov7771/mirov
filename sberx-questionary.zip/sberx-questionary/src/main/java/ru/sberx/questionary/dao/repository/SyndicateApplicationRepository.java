package ru.sberx.questionary.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.SyndicateApplication;

import java.util.Optional;

@Repository
public interface SyndicateApplicationRepository extends CrudRepository<SyndicateApplication, Long> {

    Optional<SyndicateApplication> findByUid(String uid);

    Optional<SyndicateApplication> findByEmail(String email);
}
