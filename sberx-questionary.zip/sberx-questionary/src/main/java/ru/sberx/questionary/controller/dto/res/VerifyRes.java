package ru.sberx.questionary.controller.dto.res;

import lombok.Data;

@Data
public class VerifyRes {

    private Long fromState;
    private Long toState;

}
