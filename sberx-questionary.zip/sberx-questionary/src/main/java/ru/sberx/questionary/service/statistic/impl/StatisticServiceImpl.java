package ru.sberx.questionary.service.statistic.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.StatisticReq;
import ru.sberx.questionary.controller.dto.support.GuideV2Res;
import ru.sberx.questionary.controller.dto.support.Statistic;
import ru.sberx.questionary.dao.model.Reply;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.ReplyRepository;
import ru.sberx.questionary.gate.service.GuideService;
import ru.sberx.questionary.service.statistic.StatisticService;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class StatisticServiceImpl implements StatisticService {

    private final QuestionnaireRepository questionnaireRepository;
    private final ReplyRepository replyRepository;
    private final GuideService guideService;

    @Override
    public List<Statistic> getStatistic(StatisticReq req) {
        checkDates(req);
        return questionnaireRepository.getStatistic(req);
    }

    @Override
    public List<Statistic> getReplyStatisticByTableName(String role, String tableName) {
        List<Statistic> statisticList = new ArrayList<>();
        if (!StringUtils.hasText(tableName)) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        }
        if (!StringUtils.hasText(role) || !role.equals("Administrator")) {
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
        }
        List<Reply> replyList = replyRepository.findByTableName(tableName);
        if (replyList == null || replyList.isEmpty()) {
            return statisticList;
        }
        List<GuideV2Res> guides = guideService.getGuidesByIds(
                replyList.stream()
                .map(Reply::getState)
                .map(state -> {
                    if (state > 1000) {
                        return state - Math.floorMod(state, 1000);
                    }
                    return state;
                })
                .distinct()
                .collect(Collectors.toList()));

        Map<Long, String> stateNames = new HashMap<>();
        guides.stream().map(GuideV2Res::getValues).flatMap(Collection::stream)
                .forEach(value -> stateNames.put(value.getCode(), ru.sberx.questionary.util.GuideService.getStateV2(value.getCode())));

        Map<String, Integer> namedStatesStatistic = new HashMap<>();
        replyList.forEach(reply -> {
            if (reply != null) {
                String namedState = stateNames.get(reply.getState());
                if (namedState != null && !namedStatesStatistic.containsKey(namedState)) {
                    namedStatesStatistic.put(namedState, 1);
                } else {
                    if (namedState != null) {
                        namedStatesStatistic.replace(namedState, namedStatesStatistic.get(namedState) + 1);
                    }
                }
            }
        });
        namedStatesStatistic.forEach((stateName, count) -> statisticList.add(new Statistic(stateName, count)));
        return statisticList;
    }

    private void checkDates(StatisticReq req) {
        if (req.getDateTo() != null && req.getDateFrom() != null) {
            Date to = Date.from(Instant.ofEpochSecond(req.getDateTo()));
            Date from = Date.from(Instant.ofEpochSecond(req.getDateFrom()));
            if (from.after(to)) {
                throw new SberxException(SberxErrors.BAD_REQUEST, "Неправильный формат запроса (fromDateTime > toDateTime)");
            }
        }
    }
}
