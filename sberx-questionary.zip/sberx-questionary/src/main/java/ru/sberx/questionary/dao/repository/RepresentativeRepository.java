package ru.sberx.questionary.dao.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Representative;

@Repository
public interface RepresentativeRepository extends CrudRepository<Representative, Long> {

    List<Representative> findByQuestionnaireIdAndIsDisabled(Long questionnaireId, Boolean isDisabled);
    @Query(value = "select * from Representative where questionnaireId = :questionnaireId limit 1", nativeQuery = true)
    Representative findByQuestionnaireId(@Param("questionnaireId") Long questionnaireId);
    @Transactional
    @Modifying
    @Query("delete from Representative where questionnaireId = :questionnaireId")
    void deleteById(@Param("questionnaireId") Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Representative set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
    List<Representative> findByQuestionnaireIdIn(List<Long> questionnaireId);
}
