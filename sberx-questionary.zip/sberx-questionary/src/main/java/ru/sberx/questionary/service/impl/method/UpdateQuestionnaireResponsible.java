package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.support.QuestionnaireResponsible;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.StatusInfo;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.StatusInfoRepository;
import ru.sberx.questionary.util.GuideService;

import java.util.Date;

@Component
@RequiredArgsConstructor
public class UpdateQuestionnaireResponsible {

    private final QuestionnaireRepository questionnaireRepository;
    private final StatusInfoRepository statusInfoRepository;

    public QuestionnaireResponsible execute(QuestionnaireResponsible req) {
        Questionnaire questionnaire = questionnaireRepository.findById(req.getQuestionnaireId())
                .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
        StatusInfo statusInfo = new StatusInfo();
        statusInfo.setObjectId(questionnaire.getQuestionnaireId());
        statusInfo.setObjectType(GuideService.QUESTIONNAIRE);
        statusInfo.setComment("responsibleLogin");
        statusInfo.setFromState(questionnaire.getState());
        statusInfo.setToState(questionnaire.getState());
        statusInfo.setDate(new Date());
        statusInfo.setParentId(questionnaire.getParentId());
        statusInfoRepository.save(statusInfo);

        questionnaire.setResponsible(req.getResponsibleId());
        questionnaire.setResponsibleLogin(req.getResponsibleLogin());
        questionnaireRepository.save(questionnaire);

        QuestionnaireResponsible res = new QuestionnaireResponsible();
        res.setQuestionnaireId(questionnaire.getQuestionnaireId());
        res.setResponsibleLogin(questionnaire.getResponsibleLogin());
        return res;
    }
}
