package ru.sberx.questionary.service.impl.method;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class HashMethod {

    private static final Base64.Decoder decoder = Base64.getDecoder();
    private static final Base64.Encoder encoder = Base64.getEncoder();
    private final Cipher encodeCipher;
    private final Cipher decodeCipher;

    public HashMethod(@Value("${application.secret}") String secret)
            throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {
        final String algorithm = "AES";
        final SecretKey secretKey = new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), algorithm);
        log.debug("Initializing secret key: {}", secretKey.getEncoded());
        encodeCipher = Cipher.getInstance(algorithm);
        encodeCipher.init(Cipher.ENCRYPT_MODE, secretKey);
        decodeCipher = Cipher.getInstance(algorithm);
        decodeCipher.init(Cipher.DECRYPT_MODE, secretKey);
    }

    public String encodeLong(Long l) {
        byte[] encodedBytes = new byte[0];
        try {
            encodedBytes = encodeCipher.doFinal(l.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            log.error("Error while encrypting applicationId", e);
        }
        return encoder.encodeToString(encoder.encode(encodedBytes));
    }

    public Long decodeLong(String s) {
        byte[] decodedBytes = new byte[0];
        try {
            decodedBytes = decodeCipher.doFinal(decoder.decode(decoder.decode(s)));
        } catch (Exception e) {
            log.error("Error while decrypting applicationId", e);
        }
        return Long.parseLong(new String(decodedBytes));
    }

}
