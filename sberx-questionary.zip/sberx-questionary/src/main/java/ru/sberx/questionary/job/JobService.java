package ru.sberx.questionary.job;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.builder.RecommendBuilder;
import ru.sberx.questionary.dao.custom.dao.QuestionnaireDAO;
import ru.sberx.questionary.dao.custom.dao.RecommendDAO;
import ru.sberx.questionary.dao.custom.dao.ReplyDAO;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.PopUpStatus;
import ru.sberx.questionary.util.Utils;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

import static java.time.LocalDate.now;
import static ru.sberx.questionary.util.Utils.getDaysDiff;
import static ru.sberx.utils.validator.ConditionValidator.nvl;

@EnableAsync
@Component
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final QuestionnaireRepository questionnaireRepository;
    private final RoundRepository roundRepository;
    private final MidService midService;
    private final InvestmentRepository investmentRepository;
    private final StatusInfoRepository statusInfoRepository;
    private final ApplicationRepository applicationRepository;
    private final CommunityApplicationRepository communityApplicationRepository;
    private final UserAuth userAuth;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final PopupInfoRepository popupInfoRepository;
    private final RecommendNotificationRepository recommendNotificationRepository;
    private final RecommendBuilder recommendBuilder;

    @Value("${application.csi.days}")
    private Integer csiDays;
    @Value("${application.reply.days}")
    private Integer replyDays;

    @Scheduled(cron = "${application.cron}")
    public void setNewFlag(){
        log.info("started job at {}", new Date());
        //1. Находим подтвержденные анкеты стартапов отсортированные по дате изменения
        List<Questionnaire> list = questionnaireRepository
                .findByTypeAndStateOrderByModifiedDesc(0, GuideService.CONFIRMED_STATE);
        log.debug("found list for processing {}", list);

        //2. Обрабатываем лист с анкетами
        int i = 0;
        for(Questionnaire q : list){
            if (Boolean.TRUE.equals(q.getIsNew())){
                //3. У анкет с выставленным флагом isNew = true , ставим флаг в false
                log.debug("update questionnaire set isNew = false where questionnaireid = {}", q.getQuestionnaireId());
                q.setIsNew(false);
                questionnaireRepository.save(q);
            } else if (i < 6){
                //4. У первых 6 анкет с выставленным флагом isNew = false , ставим флаг в true
                log.debug("iter for update {}", i);
                log.debug("update questionnaire set isNew = true where questionnaireid = {}", q.getQuestionnaireId());
                q.setIsNew(true);
                questionnaireRepository.save(q);
                i++;
            }
        }
        log.info("end job at {}", new Date());
    }

    @Scheduled(cron = "${application.cron-inv-false}")
    public void checkDateForInvestmentFalse(){
        List<RoundDao> list = roundRepository.findAllByInvestmentFalse();
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        for(RoundDao r: list) {
            if (r.getPlanDate() != null) {
                int daysDiff = getDaysDiff(r.getPlanDate(), new Date());
                if (daysDiff == 5 || daysDiff== 14) {
                    Questionnaire q = questionnaireRepository.findByQuestionnaireId(r.getQuestionnaireId());
                    if (q != null && q.getEmail() != null)
                        midService.notify("RoundReminedPlan",
                                Map.of("planDate", formatter.format(r.getPlanDate()),
                                        "name", q.getName() == null ? (q.getFullName() == null ? "" : q.getFullName()): q.getName()),
                                q.getEmail(), userAuth.getUserIdByEmail2(q.getEmail()), "Завершение раунда", "/round/" + r.getRoundId(),
                                null, null);
                }
            }
        }
    }

    @Scheduled(cron = "${application.cron-inv-true}")
    public void checkDateForInvestmentTrue(){
        List<RoundDao> list = roundRepository.findAllByInvestmentTrue();
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        for(RoundDao r: list){
            if (r.getEndDate() != null && getDaysDiff(r.getEndDate(), new Date()) == 7) {
                Questionnaire q = questionnaireRepository.findByQuestionnaireId(r.getQuestionnaireId());
                if (q != null && q.getEmail() != null)
                    midService.notify("RoundRemined",
                            Map.of("endDate", formatter.format(r.getEndDate()),
                                    "name", q.getName() == null ? (q.getFullName() == null ? "" : q.getFullName()): q.getName()),
                            q.getEmail(), userAuth.getUserIdByEmail2(q.getEmail()), "Завершение раунда", "/round/" + r.getRoundId(),
                            null, null);
            }
        }
    }

    @Scheduled(cron = "${application.cron-inv-ended}")
    public void closeEndedRounds() {
        List<RoundDao> list = roundRepository.findEndedRounds();
        if (!CollectionUtils.isEmpty(list)) {
            list.forEach(i -> i.setState(20013));
            roundRepository.saveAll(list);
        }
    }

    @Scheduled(cron = "${application.cron-plan}")
    public void sendReminderMessageForPlanInvestment(){
        List<Questionnaire> questionnaireList = questionnaireRepository.findAllByStateAndTypeAndSendInvestPlanNotifyAndEmailNotNull(GuideService.CONFIRMED_STATE, 0, false);
        List<Investment> investmentList = investmentRepository.findAllByQuestionnaireIdInAndPlanInvestmentTrue(questionnaireList.stream().
                map(Questionnaire::getQuestionnaireId).collect(Collectors.toList()));
        List<StatusInfo> statusInfoList = statusInfoRepository.findAllByObjectIdInAndToState(investmentList.stream()
                .map(Investment::getQuestionnaireId).collect(Collectors.toList()), GuideService.CONFIRMED_STATE);
        for(StatusInfo s: statusInfoList){
            if (getDaysDiff(new Date(), s.getDate()) >= 3){
                Optional<RoundDao> optRoundDao = roundRepository.findById(s.getObjectId());
                for(Questionnaire q : questionnaireList) {
                    q.setSendInvestPlanNotify(true);
                    questionnaireRepository.save(q);
                    if (q.getQuestionnaireId().equals(s.getObjectId()) && q.getEmail() != null && optRoundDao.isEmpty())
                        midService.notify("NewPlanRound",
                                Map.of("name", q.getName() == null ? (q.getFullName() == null ? "" : q.getFullName()): q.getName()),
                                q.getEmail(), userAuth.getUserIdByEmail2(q.getEmail()), "Создание раунда", "/startups/" + q.getUuid(),
                                null, null);
                }
            }
        }
    }

    @Scheduled(cron = "${application.cron-expired-application}")
    public void deleteUidForExpiredApplication() {
        applicationRepository.updateExpiredApplications(Date.from(Instant.now().minus(5, ChronoUnit.DAYS)));
    }

    @Scheduled(cron = "${application.cron-community}")
    public void checkCommunity(){
        List<CommunityApplication> ca = communityApplicationRepository.findByState(GuideService.DENIED);
        ca.forEach(i -> {
            if (getDaysDiff(new Date(), i.getModified() == null ? i.getCreated() : i.getModified()) >= 92){
                i.setState(GuideService.DISABLED);
                communityApplicationRepository.save(i);
            }
        });
    }

    @Scheduled(cron = "${application.interval-cron}")
    public void notifyEditQuestionnaires(){
        List<Questionnaire> questionnaires = questionnaireRepository.findEditQuestionnaires();
        Set<Long> ids = new HashSet<>();
        if (!CollectionUtils.isEmpty(questionnaires)){
            List<UserQuestionnaire> users = userQuestionnaireRepository.findByQuestionnaireIdIn(questionnaires.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(users)){
                Map<String, Object> params = new HashMap<>();
                for(UserQuestionnaire u : users){
                    String email = userAuth.getEmailByUserId(u.getUserId());
                    if (StringUtils.hasText(email)){
                        questionnaires.forEach(i -> {
                            if (i.getQuestionnaireId().equals(u.getQuestionnaireId())){
                                String route = i.getType().equals(0) ? "/startups/"
                                        : (i.getType().equals(1) ? "/corporates/" : "/investors/") + i.getUuid();
                                params.put("comment", nvl(i.getComment(), ""));
                                params.put("name", nvl(i.getName(), i.getFullName()));
                                midService.notify("VERIFY_Q_20003", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, null, null);
                                ids.add(i.getQuestionnaireId());
                            }
                        });
                    }
                }
            }
        }
        if (!ids.isEmpty())
            questionnaireRepository.updateIsSendProcessing(ids);
    }

    @Scheduled(cron = "${application.cron-update-app}")
    public void updateQuestionnairePopUpInfo(){
        List<Questionnaire> questionnaireList = questionnaireRepository.findOldConfirmedQuestionnaire();
        if (!CollectionUtils.isEmpty(questionnaireList)){
            popupInfoRepository.saveAll(questionnaireList.stream().map(i -> {
                PopupInfoDao info = new PopupInfoDao();
                info.setQuestionnaireId(i.getQuestionnaireId());
                info.setWatched(false);
                info.setStatus(PopUpStatus.UPDATE_QUESTIONARY.getValue());
                info.setUserId(Utils.getUserId(i.getQuestionnaireId(), userQuestionnaireRepository));
                return info;
            }).collect(Collectors.toList()));
        }
    }

    @Scheduled(cron = "${application.cron-csi}")
    public void csiPopUpInfo() {
        List<Questionnaire> questionnaires = questionnaireRepository.findByModCurrentDateCreatedDate(csiDays);
        if (!CollectionUtils.isEmpty(questionnaires)) {
            popupInfoRepository.saveAll(questionnaires.stream().map(i -> {
                PopupInfoDao info = new PopupInfoDao();
                info.setQuestionnaireId(i.getQuestionnaireId());
                info.setStatus(PopUpStatus.CSI.getValue());
                info.setUserId(Utils.getUserId(i.getQuestionnaireId(), userQuestionnaireRepository));
                info.setWatched(false);
                return info;
            }).collect(Collectors.toList()));
        }
    }

    @Scheduled(cron = "${application.new-reply}")
    public void newReplyDays() {
        int dateOfWeek = now().getDayOfWeek().getValue();
        log.info("start newReplyDays {}", dateOfWeek);
        List<ReplyDAO> replies = questionnaireRepository.findCustomReplyInfo(replyDays);
        if (!CollectionUtils.isEmpty(replies)) {
            replies.forEach(i -> {
                if (StringUtils.hasText(i.getEmail()))
                    midService.notify("OldNewReply",
                            Map.of("name", nvl(i.getQName(), i.getQName())),
                            i.getEmail());
            });
        }
        log.info("end newReplyDays {}", replies.size());
    }

    @Scheduled(cron = "${application.send-recommend}")
    public void sendRecommendNotify() {
        List<QuestionnaireDAO> list = questionnaireRepository.findForNotify();
        if (!CollectionUtils.isEmpty(list)) {
            List<Long> qList = list.stream().map(QuestionnaireDAO::getQuestionnaireId).distinct().collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(qList)) {
                for(Long d : qList) {
                    recommendBuilder.build(d);
                }
            }
            List<RecommendNotificationDAO> notificationDAOS = new ArrayList<>();
            for(QuestionnaireDAO dao : list) {
                List<RecommendDAO> recommends = recommendBuilder.get(dao.getQuestionnaireId(), dao.getUserId());
                StringBuilder sb = null;
                if (!CollectionUtils.isEmpty(recommends)) {
                    int i = 0;
                    for(RecommendDAO r : recommends) {
                        i++;
                        sb = new StringBuilder("{")
                                .append(i).append(".<span><a href=\"https://sberunity.ru/main/startups/")
                                .append(r.getUid())
                                .append("\">")
                                .append(r.getName())
                                .append("</a></span><br>}\n");
                        RecommendNotificationDAO rnDao = new RecommendNotificationDAO();
                        rnDao.setQuestionnaireId(dao.getQuestionnaireId());
                        rnDao.setUserId(dao.getUserId());
                        rnDao.setNotificationDate(new Date());
                        rnDao.setNotificationQuestionnaireId(r.getQId());
                        notificationDAOS.add(rnDao);
                    }
                }
                if (sb != null) {
                    try {
                        String email = userAuth.getEmailByUserId(dao.getUserId());
                        if (StringUtils.hasText(email)) {
                            midService.notify("New_Recommend",
                                    Map.of("reccomend", sb.toString()),
                                    email);
                        }
                    } catch (Exception e) {
                        log.error("Error sending notification: ", e);
                    }
                }
            }
            if (!CollectionUtils.isEmpty(notificationDAOS))
                recommendNotificationRepository.saveAll(notificationDAOS);
        }
    }
}
