package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.Utils;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@Slf4j
public class Statistic {
    private Long id;
    private String uid;
    private String type;
    private String investorType;
    private String fullName;
    private String name;
    private Date created;
    private Date modified;
    private String state;
    private Long parenId;
    private String inn;
    private String birthday;
    private String site;
    private String registrationCountry;
    private String email;
    private String phoneNumber;
    private String contact;
    private String note;
    private List<String> interactionType;
    private List<String> businessModel;
    private String locationCountry;
    private String location;
    private List<String> industry;
    private List<String> technology;
    private String logo;
    private List<String> mvpCode;
    private String demoVideo;
    private String problem;
    private String auditory;
    private String present;
    private List<String> geography;
    private List<String> sales;
    private String turnover;
    private String competitor;
    private String upside;
    private Integer staff;
    private String roleNote;
    private Boolean successPilots;
    private String reference;
    private Boolean pilot;
    private String suggestCase;
    private Boolean experience;
    private String lastInvestment;
    private String coInvestment;
    private List<String> ecoRequirement;
    private Boolean firstTime;
    private String monthRevenue;
    private String quarterRevenue;
    private Integer clients;
    private Boolean sber500;
    private Integer amount;
    private Boolean isImport;
    private String irName;
    private String irNote;
    private String irBenefits;
    private String utm;
    private String metric;

    public Statistic(Long id,
                     String uid,
                     String type,
                     String investorType,
                     String fullName,
                     String name,
                     Date created,
                     Date modified,
                     Long state,
                     Long parenId,
                     String inn,
                     String birthday,
                     String site,
                     Long registrationCountry,
                     String email,
                     String phoneNumber,
                     String contact,
                     String note,
                     String interactionType,
                     String businessModel,
                     Long locationCountry,
                     String location,
                     String industry,
                     String technology,
                     String logo,
                     String mvpCode,
                     String demoVideo,
                     String problem,
                     String auditory,
                     String present,
                     String geography,
                     String sales,
                     String turnover,
                     String competitor,
                     String upside,
                     Integer staff,
                     String roleNote,
                     Boolean successPilots,
                     String reference,
                     Boolean pilot,
                     String suggestCase,
                     Boolean experience,
                     String lastInvestment,
                     String coInvestment,
                     String ecoRequirement,
                     Boolean firstTime,
                     String monthRevenue,
                     String quarterRevenue,
                     Integer clients,
                     Boolean sber500,
                     Boolean isImport,
                     String irName,
                     String irNote,
                     String irBenefits,
                     String utm,
                     String metric){
        this.id = id;
        this.uid = uid;
        this.name = name;
        this.fullName = fullName;
        this.type = type;
        this.investorType = investorType;
        this.modified = modified;
        this.created = created;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.state = GuideService.getState(state);
        this.suggestCase = suggestCase;
        this.registrationCountry = GuideService.getGuideValue(registrationCountry);
        this.industry = getList(industry);
        this.technology = getList(technology);
        this.parenId = parenId;
        this.inn = inn;
        this.birthday = birthday;
        this.site = site;
        this.contact = contact;
        this.note = note;
        this.interactionType = getList(interactionType);
        this.businessModel = getList(businessModel);
        this.locationCountry = GuideService.getGuideValue(locationCountry);
        this.location = location;
        this.logo = logo;
        this.mvpCode = getList(mvpCode);
        this.demoVideo = demoVideo;
        this.problem = problem;
        this.auditory = auditory;
        this.present = present;
        this.geography = getList(geography);
        this.sales = getList(sales);
        this.turnover = turnover;
        this.competitor = competitor;
        this.upside = upside;
        this.staff = staff;
        this.roleNote = prepareString(roleNote);
        this.successPilots = successPilots;
        this.reference = prepareString(reference);
        this.pilot = pilot;
        this.experience = experience;
        this.lastInvestment = lastInvestment;
        this.coInvestment = coInvestment;
        this.ecoRequirement = getList(ecoRequirement);
        this.firstTime = firstTime;
        this.monthRevenue = monthRevenue;
        this.quarterRevenue = quarterRevenue;
        this.clients = clients;
        this.sber500 = sber500;
        this.isImport = isImport;
        this.irName = irName;
        this.irNote = irNote;
        this.irBenefits = irBenefits;
        this.utm = utm;
        this.metric = metric;
    }

    public Statistic(String state, Integer amount) {
        this.state = state;
        this.amount = amount;
    }

    private List<String> getList(String value){
        if (!StringUtils.hasText(value))
            return null;
        value = value.replaceAll("\\{", "").replaceAll("\\}", "");
        if (!StringUtils.hasText(value))
            return null;
        value = value.replaceAll(",", " ");
        if (!StringUtils.hasText(value.trim()))
            return null;

        List<String> list = new ArrayList<>();
        for(String s : value.trim().split(" ")){
            if (StringUtils.hasText(s) && s.matches("[0-9]+")){
                list.add(GuideService.getGuideValue(Utils.castToLong(s)));
            }
        }
        List<String> res = list.stream().distinct().filter(Objects::nonNull).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(res))
            return null;
        return res;
    }

    private String prepareString(String val){
        if (StringUtils.hasText(val)){
            val = val.replace("(,);", "");
            val = val.replace("(,)", "");
            if (StringUtils.hasText(val))
                return val;
        }
        return null;
    }
}
