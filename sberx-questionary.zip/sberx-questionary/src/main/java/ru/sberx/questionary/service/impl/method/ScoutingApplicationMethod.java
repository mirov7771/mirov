package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.builder.QueryBuilder;
import ru.sberx.questionary.controller.dto.req.ScoutingListReq;
import ru.sberx.questionary.controller.dto.res.ScoutingListRes;
import ru.sberx.questionary.controller.dto.support.ScoutingDto;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.ScoutingApplication;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.ScoutingApplicationRepository;
import ru.sberx.questionary.gate.service.MidService;

import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class ScoutingApplicationMethod {

    private final ScoutingApplicationRepository scoutingApplicationRepository;
    private final QueryBuilder queryBuilder;
    private final MidService midService;
    private final QuestionnaireRepository questionnaireRepository;

    public ScoutingListRes list(ScoutingListReq req){
        ScoutingListRes res = new ScoutingListRes();
        req.setQuestionnaireId(getQId(req.getUserId()));
        List<ScoutingApplication> scoutingList = queryBuilder.getScoutingList(req);
        if (!CollectionUtils.isEmpty(scoutingList)){
            res.setTotalRowCount(scoutingList.size());
            if (req.getRowCount() != null && !ObjectUtils.isEmpty(scoutingList)) {
                int offset = req.getPageToken() != null ? req.getPageToken() : 0;
                int from = req.getRowCount() * offset;
                int to = from + req.getRowCount();
                if (to >= scoutingList.size()) {
                    res.setNextPageToken(null);
                    to = scoutingList.size();
                } else {
                    res.setNextPageToken(offset + 1);
                }
                scoutingList = scoutingList.subList(from, to);
            }
            res.setRowCount(scoutingList.size());
            res.setList(scoutingList.stream().map(ScoutingApplication::toDto).collect(Collectors.toList()));
        } else {
            res.setList(new ArrayList<>());
            res.setRowCount(0);
            res.setTotalRowCount(0);
        }
        return res;
    }

    public ScoutingDto id(UUID uid){
        Optional<ScoutingApplication> application = scoutingApplicationRepository.findById(uid);
        if (application.isEmpty())
            return new ScoutingDto();
        ScoutingDto scoutingDto = application.get().toDto();
        if (scoutingDto.getQuestionnaireId() != null){
            Questionnaire q = questionnaireRepository.findByQuestionnaireId(scoutingDto.getQuestionnaireId());
            if (q != null)
                scoutingDto.setParticipantName(StringUtils.hasText(q.getName()) ? q.getName() : q.getFullName());
        }
        return scoutingDto;
    }

    public ScoutingDto save(ScoutingDto req){
        ScoutingApplication dao = scoutingApplicationRepository.save(req.toDao(getQId(req.getUserId())));
        String participantName = null;
        if (req.getUserId() != null) {
            Questionnaire q = questionnaireRepository.findConfirmedByUserId(req.getUserId());
            if (q == null || q.getQuestionnaireId() == null)
                q = questionnaireRepository.findAllByUserId(req.getUserId());
            if (q != null && q.getQuestionnaireId() != null) {
                participantName = StringUtils.hasText(q.getName()) ? q.getName() : q.getFullName();
                dao.setQuestionnaireId(q.getQuestionnaireId());
            }
        }
        ScoutingDto res = new ScoutingDto();
        res.setUuid(dao.getUid().toString());
        if (StringUtils.hasText(req.getEmail())){
            try {
                Map<String, Object> params = new HashMap<>();
                if (StringUtils.hasText(participantName))
                    params.put("name", participantName);
                midService.notify("New_Scouting",
                        params,
                        "sberunity@sberbank.ru",
                        null,
                        null,
                        null,
                        null,
                        null);
            } catch (Exception e){
                e.printStackTrace();
            }
        }
        return res;
    }

    private Long getQId(Long userId){
        Long qId = null;
        if (userId != null){
            Questionnaire q = questionnaireRepository.findConfirmedByUserId(userId);
            if (q == null || q.getQuestionnaireId() == null)
                q = questionnaireRepository.findAllByUserId(userId);
            qId = q.getQuestionnaireId();
        }
        return qId;
    }

}
