package ru.sberx.questionary.service.metric.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.PostMetricReq;
import ru.sberx.questionary.controller.dto.support.GuideDto;
import ru.sberx.questionary.controller.metric.dto.req.GetMetricReq;
import ru.sberx.questionary.controller.metric.dto.res.GetMetricRes;
import ru.sberx.questionary.controller.metric.dto.support.MetricTypeDto;
import ru.sberx.questionary.dao.model.MetricDao;
import ru.sberx.questionary.dao.model.MetricSettings;
import ru.sberx.questionary.dao.model.MetricType;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.repository.MetricRepository;
import ru.sberx.questionary.dao.repository.MetricSettingsRepository;
import ru.sberx.questionary.dao.repository.MetricTypeRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.gate.service.GuideService;
import ru.sberx.questionary.service.metric.MetricService;
import ru.sberx.questionary.service.questionary.QuestionaryService;
import ru.sberx.questionary.util.Utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class MetricServiceImpl implements MetricService {

    private final MetricRepository metricRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final MetricSettingsRepository metricSettingsRepository;
    private final GuideService guideService;
    private final MetricTypeRepository metricTypeRepository;
    private final QuestionaryService questionaryService;

    private static final Long GUIDE_CURRENCY = 41000L;

    @Override
    public void post(PostMetricReq req) {
        Long questionnaireId = getQuestionnaireId(req);
        req.getItems().forEach(item -> {
            String value = item.getValue() != null ? item.getValue().replaceAll("[^\\d]", "") : "";
            Long val = StringUtils.hasText(value) ? Utils.castToLong(value) : null;
            if (val != null) {
                item.setDate(roundDate(item.getDate()));
                List<MetricDao> metricDaos = metricRepository.findByQuestionnaireIdAndDateAndTypeAndActive(questionnaireId, item.getDate(), req.getMetric(), true);
                if (!CollectionUtils.isEmpty(metricDaos))
                    metricDaos.forEach(metric -> metric.setActive(false));
                MetricDao newMetric = new MetricDao();
                newMetric.setQuestionnaireId(questionnaireId);
                newMetric.setValue(val);
                newMetric.setDate(item.getDate());
                newMetric.setCreatedttm(new Date());
                newMetric.setType(req.getMetric());
                newMetric.setActive(true);
                metricDaos.add(newMetric);
                metricRepository.saveAll(metricDaos);

            }
        });
        saveMetricSetting(questionnaireId, req);
        questionaryService.updateLabelNew(questionnaireId, true);
    }

    @Override
    public void put(PostMetricReq req) {
        Long questionnaireId = getQuestionnaireId(req);

        metricRepository.updateActiveByQuestionnaireAndTypeAndDateNotIn(
                questionnaireId, req.getMetric(), req.getItems().stream().map(i -> roundDate(i.getDate())).collect(Collectors.toList()));

        req.getItems().forEach(item -> {
            item.setDate(roundDate(item.getDate()));
            List<MetricDao> metricDao = metricRepository.findByQuestionnaireIdAndDateAndType(questionnaireId, item.getDate(), req.getMetric());
            boolean newValue = true;
            String value = item.getValue() != null ? item.getValue().replaceAll("[^\\d]", "") : "";
            Long val = StringUtils.hasText(value) ? Utils.castToLong(value) : null;
            if (!CollectionUtils.isEmpty(metricDao)) {
                if (val == null) {
                    metricDao.forEach(i -> i.setActive(false));
                    metricRepository.saveAll(metricDao);
                    newValue = false;
                } else {
                    newValue = metricDao.stream().filter(metric -> Boolean.TRUE.equals(metric.getActive())).noneMatch(i -> val.equals(i.getValue()));
                }
            }
            if (val != null && Boolean.TRUE.equals(newValue)) {
                metricDao.forEach(i -> i.setActive(false));
                MetricDao newMetric = new MetricDao();
                newMetric.setQuestionnaireId(questionnaireId);
                newMetric.setType(req.getMetric());
                newMetric.setValue(val);
                newMetric.setDate(item.getDate());
                newMetric.setActive(true);
                newMetric.setCreatedttm(new Date());
                metricDao.add(newMetric);
                metricRepository.saveAll(metricDao);
            }
        });
        saveMetricSetting(questionnaireId, req);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<GetMetricRes> get(GetMetricReq req) {
        List<GetMetricRes> res = new ArrayList<>();
        Questionnaire questionnaireSession = questionnaireRepository.findAllByUserId(req.getUserId());
        if (questionnaireSession == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);

        Long questionnaireId = null;
        if (StringUtils.hasText(req.getUuid())) {
            if (ru.sberx.questionary.util.GuideService.CORPORATE.equals(questionnaireSession.getType())
                    || ru.sberx.questionary.util.GuideService.INVESTOR.equals(questionnaireSession.getType())) {
                Questionnaire questionnaire = questionnaireRepository.findByUuid(UUID.fromString(req.getUuid()));
                questionnaireId = questionnaire != null ? questionnaire.getQuestionnaireId() : null;
            }
        } else {
            questionnaireId = questionnaireSession.getQuestionnaireId();
        }
        if (questionnaireId == null) {
            return res;
        }

        List<MetricDao> metricDaos;
        Date fromDate = null;
        Date toDate = null;
        try {
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:sss");
            fromDate = dateFormat.parse(req.getBeginDate().replace("T", " "));
            toDate = dateFormat.parse(req.getEndDate().replace("T", " "));
        } catch (ParseException e) {
            log.error("error parse date: {}", e.getMessage());
        }
        if (fromDate == null && toDate == null)
            throw new SberxException(SberxErrors.INTERNAL_ERROR, "Передан не верный формат даты");

        if (req.getMetricType() != null) {
            metricDaos = metricRepository.findByQuestionnaireIdAndTypeAndDateBetweenAndActiveTrueOrderByDateDesc(questionnaireId, req.getMetricType(), fromDate, toDate);
        } else {
            metricDaos = metricRepository.findByQuestionnaireIdAndDateBetweenAndActiveTrueOrderByDateDesc(questionnaireId, fromDate, toDate);
        }
        Map<Long, List<MetricDao>> metricsMap = metricDaos.stream().collect(Collectors.groupingBy(MetricDao::getType));
        List<MetricType> metricTypes = metricTypeRepository.findByTypeIdIn(metricsMap.keySet());
        List<GuideDto> guide = guideService.getGuideByGuideId(GUIDE_CURRENCY);
        Map<String, String> guideMap;
        if (!CollectionUtils.isEmpty(guide))
            guideMap = guide.get(0).getValues().stream().collect(Collectors.toMap(GuideDto.Value::getCode, GuideDto.Value::getName));
        else
            guideMap = new HashMap<>();

        Long finalQuestionnaireId = questionnaireId;
        metricTypes.forEach(metricType -> {
            GetMetricRes metricRes = new GetMetricRes();
            metricRes.setMetricType(metricType.getTypeId());
            metricRes.setMetricName(metricType.getName());
            if (Boolean.TRUE.equals(metricType.getMoney())) {
                MetricSettings setting = metricSettingsRepository.findByQuestionnaireIdAndTypeId(finalQuestionnaireId, metricType.getTypeId());
                if (setting != null) {
                    metricRes.setCurrency(setting.getCurrency());
                    String currency = guideMap.get(setting.getCurrency());
                    if (StringUtils.hasText(currency)) {
                        if (currency.contains(",")){
                            metricRes.setCurrencyName("Доход," + currency.split(",")[1]);
                        } else {
                            metricRes.setCurrencyName(currency);
                        }
                    }
                }
            }
            List<GetMetricRes.Value> values = metricsMap.get(metricType.getTypeId())
                    .stream()
                    .map(GetMetricRes.Value::new)
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(values))
                values.sort(Comparator.comparing(GetMetricRes.Value::getDate));
            metricRes.setValues(values);
            res.add(metricRes);
        });
        return res;
    }

    @Override
    public List<MetricTypeDto> list(Long userId, Boolean addDate, String uuid) {
        List<MetricTypeDto> res = new ArrayList<>();
        Questionnaire questionnaireSession = questionnaireRepository.findAllByUserId(userId);
        if (questionnaireSession == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);

        Long questionnaireId = null;
        if (StringUtils.hasText(uuid)) {
            if (ru.sberx.questionary.util.GuideService.CORPORATE.equals(questionnaireSession.getType()) || ru.sberx.questionary.util.GuideService.INVESTOR.equals(questionnaireSession.getType())) {
                Questionnaire questionnaire = questionnaireRepository.findByUuid(UUID.fromString(uuid));
                questionnaireId = questionnaire != null ? questionnaire.getQuestionnaireId() : null;
            }
        } else {
            questionnaireId = questionnaireSession.getQuestionnaireId();
        }

        if (questionnaireId != null) {
            List<MetricDao> metrics = metricRepository.findByQuestionnaireIdAndActive(questionnaireId, true);
            Set<Long> types = metrics.stream().map(MetricDao::getType).collect(Collectors.toSet());

            log.info("types {}", types);
            List<MetricType> metricTypes;
            if (Boolean.FALSE.equals(addDate))
                metricTypes = metricTypeRepository.findByTypeIdIn(types);
            else
                metricTypes = metricTypeRepository.findByTypeIdNotIn(types);
            log.info("metricTypes {}", types);
            res = metricTypes.stream().map(MetricType::toDto).collect(Collectors.toList());
        }
        return res;
    }

    @Override
    public void delete(Integer metric, Long userId) {
        Questionnaire questionnaireSession = questionnaireRepository.findAllByUserId(userId);
        if (questionnaireSession == null || questionnaireSession.getQuestionnaireId() == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        if (metric == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);

        Long questionnaireId = questionnaireSession.getQuestionnaireId();
        metricRepository.updateActive(questionnaireId, metric);
        metricSettingsRepository.deleteByQuestionnaireAndType(questionnaireId, metric);
    }

    @Override
    public List<MetricTypeDto> type() {
        return metricTypeRepository.findAll().stream().map(MetricType::toDto).collect(Collectors.toList());
    }

    private Long getQuestionnaireId(PostMetricReq req) {
        Long userId = req.getUserId();
        Questionnaire questionnaireSession = userId != null ? questionnaireRepository.findAllByUserId(userId) : null;
        Long questionnaireId = questionnaireSession != null ? questionnaireSession.getQuestionnaireId() : null;
        if (questionnaireId == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        return questionnaireId;
    }

    private void saveMetricSetting(Long questionnaireId, PostMetricReq req) {
        MetricSettings metricSetting = metricSettingsRepository.findByQuestionnaireIdAndTypeId(questionnaireId, req.getMetric());
        if (metricSetting == null && req.getCurrency() != null) {
            metricSetting = new MetricSettings();
            metricSetting.setQuestionnaireId(questionnaireId);
            metricSetting.setTypeId(req.getMetric());
            metricSetting.setCurrency(req.getCurrency().toString());
            metricSettingsRepository.save(metricSetting);
        }
    }

    private Date roundDate(Date date) {
        if (date != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.set(Calendar.HOUR_OF_DAY, 0);
            cal.set(Calendar.MINUTE, 0);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            return cal.getTime();
        }
        return null;
    }
}
