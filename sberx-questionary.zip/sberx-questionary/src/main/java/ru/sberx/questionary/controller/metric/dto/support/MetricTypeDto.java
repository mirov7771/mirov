package ru.sberx.questionary.controller.metric.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class MetricTypeDto {
    private Integer type;
    private String name;
    private String shortName;
    private String description;
    private Boolean money;
}
