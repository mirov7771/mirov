package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "PROJECT")
@Data
@TypeDefs(@TypeDef(name = "long-array", typeClass = LongArrayType.class))
public class Project implements Serializable {
    
    private static final long serialVersionUID = -436256988656974740L;

    @Id
    @Column(name = "PROJECTID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long projectId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "NOTE")
    private String note;
    @Type(type = "long-array")
    @Column(name = "INDUSTRY")
    private Long[] industry;
    @Type(type = "long-array")
    @Column(name = "INTERACTIONTYPE")
    private long[] interactionType;
    @Type(type = "long-array")
    @Column(name = "BUSINESSMODEL")
    private long[] businessModel;
    @Column(name = "PROBLEM")
    private String problem;
    @Column(name = "AUDITORY")
    private String auditory;
    @Column(name = "HAVEMVP")
    private Boolean haveMVP;
    @Type(type = "long-array")
    @Column(name = "GEOGRAPHY")
    private long[] geography;
    @Type(type = "long-array")
    @Column(name = "SALES")
    private long[] sales;
    @Column(name = "DEMOSITE")
    private String demoSite;
    @Column(name = "DEMOFILE")
    private String demoFile;
    @Column(name = "COMPETITOR")
    private String competitor;
    @Column(name = "UPSIDE")
    private String upSide;
    @Column(name = "DOWNSIDE")
    private String downSide;
    @Column(name = "STAFF")
    private Integer staff;
    @Column(name = "HIRINGSTAFF")
    private Integer hiringStaff;
    @Column(name = "EXPERIENCE")
    private String experience;
    @Column(name = "STADY")
    private Long stady;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "PARENTID")
    private Long parentId;
    @Column(name = "STAFFLOCATION")
    private String staffLocation;
    @Type(type = "long-array")
    @Column(name = "EXPANSION")
    private long[] expansion;
    @Column(name = "INDIRECTCOMPETITOR")
    private String indirectCompetitor;
    @Column(name = "DEMOVIDEO")
    private String demoVideo;
    @Column(name = "PITCHVIDEO")
    private String pitchVideo;
    @Column(name = "ADDNOTE")
    private String addNote;
    @Type(type = "long-array")
    @Column(name = "MVPCODE")
    private long[] mvpCode;
    @Type(type = "long-array")
    @Column(name = "TECHNOLOGY")
    private Long[] technology;

    public ru.sberx.questionary.controller.dto.support.Project toDto() {
        ru.sberx.questionary.controller.dto.support.Project dto = new ru.sberx.questionary.controller.dto.support.Project();
        dto.setName(this.name);
        dto.setNote(this.note);
        dto.setIndustry(this.industry);
        dto.setInteractionType(this.interactionType);
        dto.setBusinessModel(this.businessModel);
        dto.setProblem(this.problem);
        dto.setAuditory(this.auditory);
        dto.setHaveMVP(this.haveMVP);
        dto.setGeography(this.geography);
        dto.setSales(this.sales);
        dto.setDemoSite(this.demoSite);
        dto.setDemoFile(this.demoFile);
        dto.setCompetitor(this.competitor);
        dto.setUpSide(this.upSide);
        dto.setDownSide(this.downSide);
        dto.setStaff(this.staff);
        dto.setHiringStaff(this.hiringStaff);
        dto.setExperience(this.experience);
        dto.setStady(this.stady);
        dto.setIsDisabled(this.isDisabled);
        dto.setParentId(this.parentId);
        dto.setStaffLocation(this.staffLocation);
        dto.setExpansion(this.expansion);
        dto.setIndirectCompetitor(this.indirectCompetitor);
        dto.setDemoVideo(this.demoVideo);
        dto.setPitchVideo(this.pitchVideo);
        dto.setAddNote(this.addNote);
        dto.setMvpCode(this.mvpCode);
        dto.setTechnology(this.technology);
        dto.setProjectId(this.getProjectId());
        return dto;
    }
}
