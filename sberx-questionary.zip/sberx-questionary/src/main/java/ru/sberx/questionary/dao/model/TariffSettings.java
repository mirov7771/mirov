package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.IntArrayType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Arrays;

@Entity
@Table(name = "TARIFF_SETTINGS")
@Data
@TypeDef(name = "int-array", typeClass = IntArrayType.class)
public class TariffSettings implements Serializable {

    private static final long serialVersionUID = 741770785476985161L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "SYSNAME")
    private String sysName;
    @Column(name = "TYPE")
    private Integer type;
    @Type(type = "int-array")
    @Column(name = "SUBTYPE")
    private Integer[] subType;
    @Column(name = "NAME")
    private String name;
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "DURATION")
    private Integer duration;
    @Column(name = "MAX_USERS")
    private Integer maxUsers;

    public Boolean containsSubType(Integer subType) {
        return Arrays.asList(getSubType()).contains(subType);
    }
}
