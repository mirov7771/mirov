package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.questionary.controller.metric.dto.support.MetricTypeDto;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "METRIC_TYPE")
@Getter
@Setter
@NoArgsConstructor
public class MetricType implements Serializable {

    private static final long serialVersionUID = -7586766179909358428L;

    @Id
    @Column(name = "TYPE_ID")
    private Long typeId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "MONEY")
    private Boolean money;
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "SHORT_NAME")
    private String shortName;

    public MetricTypeDto toDto() {
        MetricTypeDto dto = new MetricTypeDto();
        dto.setType(this.typeId.intValue());
        dto.setName(this.name);
        dto.setMoney(this.money);
        dto.setDescription(this.description);
        dto.setShortName(this.shortName);
        return dto;
    }
}
