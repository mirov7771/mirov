package ru.sberx.questionary.dao.repository;

import org.springframework.data.domain.Example;
import org.springframework.data.repository.CrudRepository;
import ru.sberx.questionary.dao.model.RoundLocal;

import java.util.List;

public interface RoundLocalRepository extends CrudRepository<RoundLocal, Long> {
    List<RoundLocal> findAll(Example<RoundLocal> example);
}
