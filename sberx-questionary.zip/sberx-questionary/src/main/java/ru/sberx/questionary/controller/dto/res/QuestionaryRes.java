package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import ru.sberx.questionary.controller.dto.support.*;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.controller.reply.dto.support.ReplyInfoDTO;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class QuestionaryRes {
    private Long questionnaireId;
    private Questionnaire questionnaire;
    private Project project;
    private List<Worker> workers;
    private Investment investment;
    private List<PilotDTO> pilots;
    private List<Representative> representatives;
    private List<Contact> contacts;
    private List<FeedBack> feedbacks;
    private List<User> users;
    private List<Founder> founders;
    private List<CommunityUser> communityUsers;
    private List<InvestorClub> investorClubs;
    private User userQuestionnaire;
    private PilotDTO pilot;
    private Representative representative;
    private List<PilotDTO> successPilots;
    private List<PilotDTO> questionnairePilots;
    private List<PilotDTO> b2cPilots;
    private List<PilotDTO> b2bPilots;
    private List<PilotDTO> ecoPilots;
    private PilotDTO ecoPilot;
    private Boolean isChild;
    private Long userId;
    private SberFiveHundredDto sberFiveHundred;
    private List<QuestionnaireFunds> questionnaireFunds;
    private Boolean enableOffers;
    private Integer viewCount;
    private List<ReplyInfoDTO> replies;
    private ImportReplaceDTO importReplace;
    private List<ImportReplaceDTO.ImportReplaceItemsDTO> importItems;
}
