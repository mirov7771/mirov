package ru.sberx.questionary.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.support.*;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Data
public class QuestionnaireReq {

    private Long questionnaireId;
    @NotNull
    private Integer action;
    @NotNull
    private Questionnaire questionnaire;
    private Project project;
    private List<Worker> workers;
    private Investment investment;
    private List<PilotDTO> pilots;
    private List<PilotDTO> successPilots;
    private List<PilotDTO> questionnairePilots;
    private List<PilotDTO> b2cPilots;
    private List<PilotDTO> b2bPilots;
    private List<PilotDTO> ecoPilots;
    private Representative representative;
    private List<Representative> representatives;
    private List<Contact> contacts;
    private List<Founder> founders;
    private List<CommunityUser> communityUsers;
    private List<InvestorClub> investorClubs;
    private Long userId;
    private User userQuestionnaire;
    private PilotDTO pilot;
    private PilotDTO ecoPilot;
    private String sessionId;
    private String acceleratorSite;
    private SberFiveHundredDto sberFiveHundred;
    private UserConsent userConsent;
    private List<QuestionnaireFunds> questionnaireFunds;
    private Boolean confirmed;
    private ImportReplaceDTO importReplace;
    private List<ImportReplaceDTO.ImportReplaceItemsDTO> importItems;
    private String lang = "ru";

    @JsonIgnore
    public void notValid(){
        if (questionnaire == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Раздел questionnaire");
        if (project != null && project.getName() == null) {
            project.setName("-");
        }
        if (contacts != null && contacts.size() > 0) {
            if (contacts.stream().anyMatch(contact -> (contact.getName() == null && contact.getValue() == null)))
                contacts = null;
            else
                contacts.forEach(i -> {
                    if (i.getType() == null)
                        i.setType(21003L);
                });
        }
        if (userQuestionnaire != null && userQuestionnaire.getUserId() == null)
            userQuestionnaire.setUserId(0L);
        if (pilot != null){
            if (pilots == null || pilots.size() <= 0) {
                pilots = new ArrayList<>();
            }
            pilots.add(pilot);
        }
        if (representative != null){
            if (representatives == null || representatives.size() <= 0) {
                representatives = new ArrayList<>();
            }
            representatives.add(representative);
        }
        if (Boolean.TRUE.equals(questionnaire.getSuccessPilots()))
            addPilotList(b2bPilots, "b2b");
        addPilotList(b2cPilots, "b2c");
        addPilotList(successPilots, "success");
        addPilotList(questionnairePilots, "questionnaire");
        addPilotList(ecoPilots, "eco");
        if (ecoPilot != null) {
            addPilotList(List.of(ecoPilot), "eco");
        }
    }

    @JsonIgnore
    private void addPilotList(List<PilotDTO> list, String type){
        if (list != null && list.size() > 0) {
            list.forEach(item -> {
                if ("b2b".equals(type)) {
                    item.setIsB2B(true);
                    item.setIsSuccess(true);
                }
                if ("b2c".equals(type))
                    item.setIsB2C(true);
                if ("success".equals(type))
                    item.setIsSuccess(true);
                if ("questionnaire".equals(type))
                    item.setIsQuestionnaire(true);
                if ("eco".equals(type))
                    item.setEcoSystem(true);
            });
            if (pilots == null || pilots.size() <= 0) {
                pilots = new ArrayList<>();
            }
            pilots.addAll(list);
        }
    }

    @JsonIgnore
    public boolean isSber500(){
        return this.sberFiveHundred != null
                && this.sberFiveHundred.getClients() != null
                && StringUtils.hasText(this.sberFiveHundred.getMonthRevenue())
                && StringUtils.hasText(this.sberFiveHundred.getQuarterRevenue());
    }

}
