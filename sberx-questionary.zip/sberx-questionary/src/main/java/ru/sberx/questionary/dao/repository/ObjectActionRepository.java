package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.ObjectAction;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface ObjectActionRepository extends CrudRepository<ObjectAction, Long> {
    Optional<ObjectAction> findByObjectIdAndObjectTypeAndActionAndUserId(Long objectId, String objectType, String action, Long userId);
    List<ObjectAction> findByObjectIdInAndObjectTypeAndActionAndUserId(List<Long> objectId, String objectType, String action, Long userId);
    List<ObjectAction> findByObjectIdInAndObjectTypeAndAction(List<Long> objectId, String objectType, String action);
    @Transactional
    @Modifying
    @Query(value = "delete from object_action where object_id = :objectId and object_type = :objectType", nativeQuery = true)
    void deleteByObjectIdAndObjectType(@Param("objectId") Long objectId, @Param("objectType") String objectType);
}
