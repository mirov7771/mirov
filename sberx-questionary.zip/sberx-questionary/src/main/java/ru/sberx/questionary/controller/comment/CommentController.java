package ru.sberx.questionary.controller.comment;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;
import ru.sberx.questionary.service.comment.CommentService;

@RestController
@RequestMapping("${spring.application.name}/comment")
@RequiredArgsConstructor
public class CommentController {

    private final CommentService service;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestHeader("role") String role,
                                 CommentDTO req) {
        req.setRole(role);
        return ResponseBuilder.build(service.get(req));
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestHeader("user-id") Long userId,
                                  @RequestHeader("role") String role,
                                  @RequestHeader("login") String login,
                                  @RequestBody CommentDTO req) {
        req.setUserId(userId);
        req.setRole(role);
        req.setLogin(login);
        return ResponseBuilder.build(service.post(req));
    }

    @PutMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateComment(@RequestHeader("user-id") Long userId,
                                           @PathVariable("id") Long id,
                                           @RequestBody CommentDTO req) {
        req.setUserId(userId);
        req.setCommentId(id);
        service.put(req);
        return ResponseBuilder.build(null);
    }

    @DeleteMapping(value = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> deleteComment(@PathVariable("id") Long id,
                                           @RequestHeader("user-Id") Long userId){
        service.delete(id, userId);
        return ResponseBuilder.build(null);
    }
}
