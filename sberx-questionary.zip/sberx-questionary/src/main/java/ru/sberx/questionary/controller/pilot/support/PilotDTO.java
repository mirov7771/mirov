package ru.sberx.questionary.controller.pilot.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.primitives.Longs;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.controller.dto.support.Multilang;
import ru.sberx.questionary.controller.dto.support.Questionnaire;
import ru.sberx.questionary.controller.dto.support.Response;
import ru.sberx.questionary.dao.model.PilotLocalDao;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.MultiDateDeserializer;
import ru.sberx.utils.validator.ConditionValidator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class PilotDTO {

    private Long questionnaireId;
    private Long pilotId;
    @JsonProperty("pilotid")
    private Long pilot_id;
    private Boolean pilot;
    private String suggestCase;
    private Boolean experience;
    private String businessUnit;
    private String reference;
    private String department;
    private String conditions;
    private Boolean isDisabled;
    private Boolean file;
    private String name;
    private Long state;
    private Boolean isBran;
    private Long target;
    private Integer relevance;
    private Long effect;
    private Long resources;
    private Boolean search;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    @JsonProperty("deadline")
    private Date deadLine;
    private Long exp;
    private String company;
    private String cCompany;
    private String decision;
    private Boolean isForeign;
    private String decisionCompany;
    private Boolean isHub;
    private long[] industry;
    private List<Response> response;
    private String targetOption;
    private Questionnaire questionnaire;
    private String stateName;
    private Boolean isPublished;
    private Long creatorId;
    private List<Long> userId;
    private String action;
    private String replyStatus = "3";
    private Boolean ecoSystem;
    private Boolean isB2B;
    private Boolean isB2C;
    private Boolean isSuccess;
    private Boolean isQuestionnaire;
    private String sessionId;
    private String site;
    private String demoFile;
    private Boolean favorite;
    private Date created;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    private UUID companyUid;
    private Boolean view;
    @JsonProperty("pilot_view")
    private Integer pilotView = 0;
    @JsonProperty("pilot_reply")
    private Integer pilotReply = 0;
    @JsonProperty("pilot_newReply")
    private Integer pilotNewReply = 0;
    private Integer viewCount;
    private Long replyState;
    private String replyComment;
    private Long replyId;
    private Date replyDate;
    private Long replyUserId;
    private String clickMethod;
    private String clickAction;
    @JsonIgnore
    private int num;
    private String lang = "ru";
    private List<Multilang> multilang;

    public PilotDTO(ru.sberx.questionary.dao.model.Pilot dbPilot, PilotLocalDao pilotLocal, boolean changeLogo){
        this.questionnaireId = dbPilot.getQuestionnaireId();
        this.pilotId = dbPilot.getPilotId();
        this.pilot_id = dbPilot.getPilotId();
        this.experience = dbPilot.getExperience();
        this.name = pilotLocal != null ? pilotLocal.getName() : dbPilot.getName();
        this.businessUnit = pilotLocal != null ? pilotLocal.getBusinessUnit() : dbPilot.getBusinessUnit();
        this.suggestCase = pilotLocal != null ? pilotLocal.getSuggestCase() : dbPilot.getSuggestCase();
        this.conditions = dbPilot.getConditions();
        this.file = dbPilot.getFile();
        this.industry = dbPilot.getIndustry();
        this.target = dbPilot.getTarget();
        this.relevance = dbPilot.getRelevance();
        this.effect = dbPilot.getEffect();
        this.resources = dbPilot.getResources();
        this.search = dbPilot.getSearch();
        this.deadLine = dbPilot.getDeadLine();
        this.exp = dbPilot.getExp();
        this.company = dbPilot.getCompany();
        this.decisionCompany = dbPilot.getDecisionCompany();
        this.isHub = dbPilot.getIsHub();
        this.reference = dbPilot.getReference();
        this.department = dbPilot.getDepartment();
        this.isDisabled = dbPilot.getIsDisabled();
        this.state = dbPilot.getState();
        this.isBran = dbPilot.getIsBran();
        this.decision = dbPilot.getDecision();
        this.isForeign = dbPilot.getIsForeign();
        this.targetOption = dbPilot.getTargetOption();
        this.isPublished = dbPilot.getIsPublished();
        this.creatorId = dbPilot.getCreatorId();
        this.state = dbPilot.getState();
        if (dbPilot.getState() != null){
            this.stateName = GuideService.getState(dbPilot.getState());
        }
        this.replyStatus = "3";
        this.pilot = nvl(dbPilot.getPilot(), false);
        this.ecoSystem = nvl(dbPilot.getEcoSystem(), false);
        this.isB2B = nvl(dbPilot.getIsB2B(), false);
        this.isB2C = nvl(dbPilot.getIsB2C(), false);
        this.isSuccess = nvl(dbPilot.getIsSuccess(), false);
        this.isQuestionnaire = nvl(dbPilot.getIsQuestionnaire(), false);
        this.site = dbPilot.getSite();
        if (changeLogo)
            this.demoFile = ConditionValidator.getLogo(pilotLocal != null ? pilotLocal.getDemoFile() : dbPilot.getDemoFile());
        else
            this.demoFile = pilotLocal != null ? pilotLocal.getDemoFile() : dbPilot.getDemoFile();

        this.modified = dbPilot.getModified();
        this.created = dbPilot.getCreated();
        this.lang = null;
    }

    public PilotDTO(Long questionnaireId,
                    Long pilotId,
                    Boolean experience,
                    String name,
                    String conditions,
                    String businessUnit,
                    String suggestCase,
                    Boolean file,
                    Long target,
                    Integer relevance,
                    Long effect,
                    Long resources,
                    Boolean search,
                    Date deadLine,
                    Long exp,
                    String company,
                    String decisionCompany,
                    Boolean isHub,
                    String reference,
                    String department,
                    Boolean isDisabled,
                    Long state,
                    Boolean isBran,
                    String decision,
                    Boolean isForeign,
                    String targetOption,
                    Boolean isPublished,
                    Long creatorId,
                    Boolean pilot,
                    Boolean ecoSystem,
                    Boolean isB2B,
                    Boolean isB2C,
                    Boolean isSuccess,
                    Boolean isQuestionnaire,
                    String site,
                    String demoFile,
                    Date modified,
                    Date created,
                    String qName,
                    String qFullName,
                    String qNote,
                    Date qModified,
                    String qPhoneNumber,
                    String qEmail,
                    String qLogoFile,
                    Boolean qForLending,
                    Date qRevisionDate,
                    Date qUpdateDateForSort,
                    String uid,
                    Boolean enableOffers,
                    Integer pilotView,
                    Integer pilotReply,
                    Integer pilotNewReply,
                    String role,
                    Long userId,
                    Boolean view,
                    Boolean favorite,
                    Boolean offerPilot,
                    Integer num,
                    Integer qCount,
                    Integer qPilotsPerCompany,
                    String industry,
                    String lang) {
        this.questionnaireId = questionnaireId;
        this.pilotId = pilotId;
        this.pilot_id = pilotId;
        this.pilot = pilot;
        this.suggestCase = suggestCase;
        this.experience = experience;
        this.businessUnit = businessUnit;
        this.reference = reference;
        this.department = department;
        this.conditions = conditions;
        this.isDisabled = isDisabled;
        this.file = file;
        this.name = name;
        this.state = state;
        this.stateName = GuideService.getState(state);
        this.isBran = isBran;
        this.target = target;
        this.relevance = relevance;
        this.effect = effect;
        this.resources = resources;
        this.search = search;
        this.deadLine = deadLine;
        this.exp = exp;
        this.company = company;
        this.decision = decision;
        this.isForeign = isForeign;
        this.decisionCompany = decisionCompany;
        this.isHub = isHub;
        this.targetOption = targetOption;
        this.isPublished = isPublished;
        this.creatorId = creatorId;
        this.ecoSystem = ecoSystem;
        this.isB2B = isB2B;
        this.isB2C = isB2C;
        this.isSuccess = isSuccess;
        this.isQuestionnaire = isQuestionnaire;
        this.site = site;
        this.demoFile = ConditionValidator.getLogo(demoFile);
        this.created = created;
        this.modified = modified;
        if (qModified != null){
            this.questionnaire = new Questionnaire();
            this.questionnaire.setName(qName);
            this.questionnaire.setFullName(qFullName);
            this.questionnaire.setNote(qNote);
            this.questionnaire.setPhoneNumber(qPhoneNumber);
            this.questionnaire.setEmail(qEmail);
            this.questionnaire.setLogoFile(ConditionValidator.getLogo(qLogoFile));
            this.questionnaire.setForLending(qForLending);
            this.questionnaire.setRevisionDate(qRevisionDate);
            this.questionnaire.setUpdateDateForSort(qUpdateDateForSort);
            this.questionnaire.setUuid(uid);
            this.questionnaire.setEnableOffers(enableOffers);
            this.questionnaire.setQuestionnaireId(questionnaireId);
            this.questionnaire.setOfferPilot(offerPilot);
            this.questionnaire.setShowMore(qPilotsPerCompany != null && qCount != null && qCount > qPilotsPerCompany);

            if (!Boolean.TRUE.equals(offerPilot) && Boolean.TRUE.equals(enableOffers)){
                this.questionnaire.setEnableOffers(false);
            }
        }
        if (StringUtils.hasText(role)) {
            this.clickMethod = "GET";
            this.clickAction = "/view?type=4&name=pilot_" + role + "&action=1&id=" + this.pilotId;
        }

        if (Boolean.TRUE.equals(enableOffers)){
            this.questionnaire.setButtons(List.of(new Questionnaire.Button(
                    100010,
                    Boolean.TRUE.equals(offerPilot) ? "Предложить пилот" : "Вы уже предложили пилот",
                    Boolean.FALSE.equals(offerPilot),
                    Boolean.TRUE.equals(offerPilot) ? "/view?type=7&name=offer_Client&action=2" : null,
                    Boolean.TRUE.equals(offerPilot) ? "GET" : null
            )));
        }
        this.pilotView = pilotView;
        this.pilotReply = pilotReply;
        this.pilotNewReply = pilotNewReply;
        this.userId = List.of(userId);
        this.view = view;
        this.favorite = favorite;
        this.num = nvl(num, 0);
        this.industry = getList(industry);
        this.lang = lang;
    }

    private long[] getList(String value){
        if (StringUtils.hasText(value)) {
            value = value.replace("{", "").replace("}", "");
            if (StringUtils.hasText(value) && !value.equals("")){
                String[] split = value.split(",");
                if (split.length > 0) {
                    List<Long> ret = new ArrayList<>();
                    for(String s : split){
                        ret.add(Long.valueOf(s));
                    }
                    if (!CollectionUtils.isEmpty(ret))
                        return Longs.toArray(ret);
                }
            }
        }
        return null;
    }
}
