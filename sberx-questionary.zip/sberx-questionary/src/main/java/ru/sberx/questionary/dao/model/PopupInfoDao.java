package ru.sberx.questionary.dao.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "POPUP_INFO")
@Getter
@Setter
public class PopupInfoDao implements Serializable {

    private static final long serialVersionUID = -6186734378983636251L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "WATCHED")
    private Boolean watched;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "USER_ID")
    private Long userId;

}
