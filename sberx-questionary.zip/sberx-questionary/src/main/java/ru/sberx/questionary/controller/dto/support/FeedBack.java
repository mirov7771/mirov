package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.Feedback;

import javax.validation.constraints.NotNull;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class FeedBack {

    private Long feedbackId;
    private Long userId;
    private String userFio;
    private Long unitId;
    private Long userQuestionnaireId;
    private Long interactionState;
    private String comment;
    private Integer score;
    private Date createDate;
    private Date date;
    private Integer needScore;
    private String needComment;
    private Integer caseScore;
    private String caseComment;
    private Integer kpiScore;
    private String kpiComment;
    private Boolean isBran;
    private Date dateEnd;
    private Date pilotStart;
    private Date pilotEnd;
    private Date dateContract;
    @NotNull
    private Long questionnaireId;
    private String unitName;

    public FeedBack(Feedback f) {
        this.feedbackId = f.getFeedbackId();
        this.userId = f.getUserId();
        this.userFio = f.getUserFio();
        this.unitId = f.getUnitId();
        this.userQuestionnaireId = f.getUserQuestionnaireId();
        this.interactionState = f.getInteractionState();
        this.comment = f.getComment();
        this.score = f.getScore();
        this.createDate = f.getCreateDate();
        this.date = f.getDate();
        this.needScore = f.getNeedScore();
        this.needComment = f.getNeedComment();
        this.caseScore = f.getCaseScore();
        this.caseComment = f.getCaseComment();
        this.kpiScore = f.getKpiScore();
        this.kpiComment = f.getKpiComment();
        this.isBran = Boolean.TRUE.equals(f.getIsBran());
        this.questionnaireId = f.getQuestionnaireId();
        this.dateEnd = f.getDateEnd();
        this.pilotStart = f.getPilotStart();
        this.pilotEnd = f.getPilotEnd();
        this.dateContract = f.getDateContract();
        this.unitName = f.getUnitName();
    }
}
