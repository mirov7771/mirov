package ru.sberx.questionary.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.data.util.Pair;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;

import java.util.Date;
import java.util.List;

@Slf4j
public class Utils {

    public static <T> Pair<List<T>, Integer> pagination(List<T> collection, int rowCount, Integer pageToken) {
        int offset = pageToken != null ? pageToken : 0;
        int from = rowCount * offset;
        int to = from + rowCount;
        int nextPageToken;
        if (to >= collection.size()) {
            nextPageToken = -1;
            to = collection.size();
        } else {
            nextPageToken = offset + 1;
        }
        log.debug("Limiting list, getting sublist from {} to {}", from, to);
        return Pair.of(collection.subList(from, to), nextPageToken);
    }

    public static Long castToLong(Object val){
        if (val == null)
            return null;
        if (val instanceof Long)
            return (Long) val;
        if (val instanceof Integer)
            return ((Integer) val).longValue();
        if (val instanceof String)
            return Long.valueOf((String) val);
        return null;
    }

    public static String castToString(Object val){
        if (val == null)
            return null;
        if (val instanceof String)
            return (String) val;
        if (val instanceof Long)
            return Long.toString((Long) val);
        if (val instanceof Integer)
            return Integer.toString((Integer) val);
        return null;
    }

    public static int getDaysDiff(Date date1, Date date2){
        long milliseconds = date1.getTime() - date2.getTime();
        return  (int) (milliseconds / (24 * 60 * 60 * 1000));
    }

    public static Long getUserId(Long questionnaireId, UserQuestionnaireRepository userQuestionnaireRepository) {
        UserQuestionnaire user = userQuestionnaireRepository.findFirstByQuestionnaireId(questionnaireId);
        if (user != null)
            return user.getUserId();
        return null;
    }
}
