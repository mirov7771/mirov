package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Worker {

    private Long workerId;
    private String role;
    private Integer age;
    private String note;
    private Float percentage;
    @NotNull
    private String fio;
    private Boolean isDisabled;
    private Long parentId;
    private Boolean isFounder;
    private String facebook;

}
