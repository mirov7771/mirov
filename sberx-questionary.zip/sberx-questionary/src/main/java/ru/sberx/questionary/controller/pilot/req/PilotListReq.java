package ru.sberx.questionary.controller.pilot.req;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Data
public class PilotListReq {
    private List<Long> pilotId;
    private Long questionnaireId;
    private Integer rowCount;
    private String name;
    private List<Long> state;
    private String responseNote;
    private String filteredBy;
    private Integer pilotsPerCompany;
    private String sortBy;
    private String orderBy;
    private List<Long> userId;
    private String sessionId;
    private Boolean favorite;
    private Long qId;
    private Long qUserId;
    private List<Long> industry;
    private Boolean view;
    private String role;
    private Integer pageToken;
    @JsonIgnore
    private Long currentUserId;
    @JsonIgnore
    private Integer totalCount;
    private String filters;
    private String locale;
    private String schema;
    private Integer myReply;
    private String id;
    private Integer type;

    @JsonIgnore
    public List<Long> getIndustriesVal(){
        if (CollectionUtils.isEmpty(this.industry))
            this.industry = new ArrayList<>();
        return this.industry;
    }
}
