package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "METRIC")
@Data
@NoArgsConstructor
public class MetricDao implements Serializable {

    private static final long serialVersionUID = 4737620368037758428L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "VALUE")
    private Long value;
    @Column(name = "TYPE")
    private Long type;
    @Column(name = "CREATEDTTM")
    private Date createdttm;
    @Column(name = "ACTIVE")
    private Boolean active;
}
