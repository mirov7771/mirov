package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorRes {

    private Integer code;
    private String message;
    private String details;

    public ErrorRes(Integer code, String message, String details)
    {
        this.code = code;
        this.message = message;
        this.details = details;
    }
}
