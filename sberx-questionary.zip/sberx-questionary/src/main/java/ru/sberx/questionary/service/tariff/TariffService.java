package ru.sberx.questionary.service.tariff;

import ru.sberx.questionary.controller.dto.res.DefaultRes;
import ru.sberx.questionary.controller.tariff.dto.req.CheckTariffReq;
import ru.sberx.questionary.controller.tariff.dto.req.PostTariffReq;
import ru.sberx.questionary.controller.tariff.dto.support.TariffDto;

import java.util.List;

public interface TariffService {
    void check(CheckTariffReq req);
    TariffDto get(Long userId, String role, Long questionnaireId, String questionnaireUuid, Boolean back);
    DefaultRes post(PostTariffReq req);
    List<?> list(Long questionnaireId, String questionnaireUuid);
    String tariffName(String sysName);
    void createTariffChildQuestionnaire(Long questionnaireId);
    void deleteByQuestionnaireId(Long questionnaireId);
}
