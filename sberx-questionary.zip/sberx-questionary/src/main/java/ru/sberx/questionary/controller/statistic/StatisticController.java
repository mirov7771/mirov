package ru.sberx.questionary.controller.statistic;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.dto.req.StatisticReq;
import ru.sberx.questionary.service.statistic.StatisticService;

@RestController
@RequestMapping("${spring.application.name}/statistic")
@RequiredArgsConstructor
public class StatisticController {

    private final StatisticService service;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getStatistic(StatisticReq req) {
        return ResponseBuilder.build(service.getStatistic(req));
    }

    @GetMapping(value = "reply", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getReplyStatistic(@RequestHeader("client-id") String clientId,
                                               @RequestHeader("requestId") String requestId,
                                               @RequestHeader("role") String role) {
        ThreadContext.put("requestId", requestId);
        ThreadContext.put("client-id", String.valueOf(clientId));
        return ResponseBuilder.build(service.getReplyStatisticByTableName(role, "Pilot"));
    }
}
