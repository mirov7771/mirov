package ru.sberx.questionary.controller.dto.support;

import lombok.Data;

import java.util.List;

@Data
public class GuideV2Res {
    private String name;
    private String sysname;
    private List<ReferenceRes> values;
}
