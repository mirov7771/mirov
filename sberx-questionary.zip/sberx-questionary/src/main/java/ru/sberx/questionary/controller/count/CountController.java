package ru.sberx.questionary.controller.count;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.service.count.CountService;

@RestController
@RequestMapping("${spring.application.name}/count")
@RequiredArgsConstructor
public class CountController {

    private final CountService countService;

    @GetMapping(value = "{type}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> count(@PathVariable("type") Integer type){
        return ResponseBuilder.build(countService.count(type));
    }

}
