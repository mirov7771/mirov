package ru.sberx.questionary.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.ScoutingApplication;

import java.util.UUID;

@Repository
public interface ScoutingApplicationRepository extends CrudRepository<ScoutingApplication, UUID> {

}
