package ru.sberx.questionary.gate.service.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.JsonObject;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sberx.questionary.controller.dto.res.GetUserRes;
import ru.sberx.questionary.controller.dto.support.UserConsent;
import ru.sberx.questionary.gate.client.RestGate;
import ru.sberx.questionary.gate.service.UserAuth;

import java.util.*;

@Service
@RequiredArgsConstructor
public class UserAuthImpl implements UserAuth {

    private final RestGate restGate;

    @Value("${application.user.auth}")
    private String userAuthUrl;
    @Value("${application.user.checksession}")
    private String userAuthCheckSession;
    @Value("${application.user.changerole}")
    private String userAuthChangeRole;
    @Value("${application.user.info}")
    private String userAuthInfo;
    @Value("${application.user.restore.password}")
    private String restorePasswordMethod;
    @Value("${application.user.delete.session}")
    private String deleteSessionMethod;
    @Value("${application.user.consent}")
    private String userAuthSaveConsent;
    @Value("${application.user.list}")
    private String userList;
    @Value("${application.user.consentsign}")
    private String userAuthConsentSign;

    @Async("threadPoolTaskExecutor")
    @Override
    public void changeRole(Long userId, String newRole, Integer userRole) {
        SessionInfo sessionInfo = getSessionInfo(null, userId, null);
        if (sessionInfo != null
                && sessionInfo.getUserId() != null) {
            JsonObject json = new JsonObject();
            json.addProperty("userId", sessionInfo.getUserId());
            json.addProperty("role", newRole);
            json.addProperty("userRole", userRole);
            restGate.call(String.class
                    , userAuthUrl
                    , userAuthChangeRole
                    , json.toString()
                    , HttpMethod.POST
                    , getHeaders()
                    , MediaType.APPLICATION_JSON);
        }
    }

    @Override
    public Long getUserId(String sessionId) {
        SessionInfo sessionInfo = getSessionInfo(sessionId, null, null);
        if (sessionInfo != null
                && sessionInfo.getExternalId() != null
                && sessionInfo.getRole() != null
                && (sessionInfo.getRole().contains("Client") ||
                sessionInfo.getRole().contains("Invest") ||
                sessionInfo.getRole().contains("Corp")))
        {
            return sessionInfo.getExternalId();
        }
        return null;
    }

    @Override
    public Long getUserId2(String sessionId) {
        if (sessionId != null) {
            SessionInfo sessionInfo = getSessionInfo(sessionId, null, null);
            if (sessionInfo != null
                    && sessionInfo.getUserId() != null) {
                return sessionInfo.getUserId();
            }
        }
        return null;
    }

    @Override
    public Long getUserIdByEmail(String email) {
        SessionInfo sessionInfo = getSessionInfo(null, null, email);
        if (sessionInfo != null
                && sessionInfo.getExternalId() != null) {
            return sessionInfo.getExternalId();
        }
        return null;
    }

    @Override
    public Long getUserIdByEmail2(String email) {
        SessionInfo sessionInfo = getSessionInfo(null, null, email);
        if (sessionInfo != null
                && sessionInfo.getUserId() != null) {
            return sessionInfo.getUserId();
        }
        return null;
    }

    @Override
    public String restorePassword(String email, String action) {
        String status = null;
        JsonObject json = new JsonObject();
        json.addProperty("email", email);
        json.addProperty("action", action);
        SessionInfo info = restGate.call(SessionInfo.class,
                userAuthUrl,
                restorePasswordMethod,
                json.toString(),
                HttpMethod.POST,
                getHeaders(),
                MediaType.APPLICATION_JSON);
        if (info != null)
            status = info.getStatus();
        return status;
    }

    @Override
    public String getEmailByUserId(Long userId) {
        SessionInfo sessionInfo = getSessionInfo(null, userId, null);
        if (sessionInfo != null
                && sessionInfo.getExternalId() != null) {
            return sessionInfo.getLogin();
        }
        return null;
    }

    @Override
    public Long getUserByExternalId(Long userId) {
        SessionInfo sessionInfo = getSessionInfo(null, userId, null);
        if (sessionInfo != null
                && sessionInfo.getExternalId() != null) {
            return sessionInfo.getUserId();
        }
        return null;
    }

    @Override
    public void deleteUserSessions(Long userId) {
        restGate.call(Void.class
                , userAuthUrl
                , deleteSessionMethod.replace("{userId}", userId.toString())
                , null
                , HttpMethod.DELETE
                , getHeaders()
                , null);
    }

    @Override
    public GetUserRes getUserInfo(Long externalId, Long userId) {
        UriComponents method = UriComponentsBuilder
                .fromUriString(userAuthInfo)
                .queryParamIfPresent("externalId", Optional.ofNullable(externalId))
                .queryParamIfPresent("userId", Optional.ofNullable(userId))
                .build();
        return restGate.call(GetUserRes.class
                , userAuthUrl
                , method.toUriString()
                , null
                , HttpMethod.GET
                , getHeaders()
                , null);
    }

    @Override
    public String getUserRole(String sessionId) {
        SessionInfo sessionInfo = getSessionInfo(sessionId, null, null);
        if (sessionInfo != null && StringUtils.hasText(sessionInfo.getRole())) {
            return sessionInfo.getRole();
        }
        return null;
    }

    private SessionInfo getSessionInfo(String sessionId,
                                       Long externalId,
                                       String email) {
        String method = null;
        if (sessionId != null)
            method = userAuthCheckSession + "/" + sessionId;
        else if (externalId != null)
            method = userAuthInfo + "?externalId=" + externalId;
        else if (email != null)
            method = userAuthInfo + "?email=" + email;
        if (method != null)
            return restGate.call(SessionInfo.class
                    , userAuthUrl
                    , method
                    , null
                    , HttpMethod.GET
                    , getHeaders()
                    , MediaType.APPLICATION_JSON);
        return null;
    }

    public static Map<String, String> getHeaders() {
        return Map.of("requestId", ThreadContext.get("requestId") == null ? UUID.randomUUID().toString() : ThreadContext.get("requestId"));
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    private static class SessionInfo {
        private Long userId;
        private Long externalId;
        private String status;
        private String login;
        private String role;
    }

    @Override
    public void saveConsent(UserConsent userConsent, Long userId) {
        JsonObject json = new JsonObject();
        json.addProperty("userId", userId);
        json.addProperty("sber500PrivacyPolicy", Boolean.TRUE.equals(userConsent.getSber500PrivacyPolicy()));
        json.addProperty("sber500Consent", Boolean.TRUE.equals(userConsent.getSber500Consent()));
        json.addProperty("sber500PersonalDataConsent", Boolean.TRUE.equals(userConsent.getSber500PersonalDataConsent()));
        json.addProperty("sber500TermOfUse", Boolean.TRUE.equals(userConsent.getSber500TermOfUse()));
        json.addProperty("mailingConsent", Boolean.TRUE.equals(userConsent.getMailingConsent()));
        restGate.call(SessionInfo.class,
                userAuthUrl,
                userAuthSaveConsent,
                json.toString(),
                HttpMethod.POST,
                getHeaders(),
                MediaType.APPLICATION_JSON);

    }

    public UserList getUserList(Integer userRole) {
        UriComponentsBuilder method = UriComponentsBuilder
                .fromUriString(userList)
                .queryParam("userRole", userRole);

        return restGate.call(UserList.class,
                userAuthUrl,
                method.toUriString(),
                null,
                HttpMethod.GET,
                getHeaders(),
                MediaType.APPLICATION_JSON);
    }

    @Override
    public ConsentSignDttm getConsentSignDttm(Long userId) {
        UriComponents method = UriComponentsBuilder
                .newInstance()
                .path(userAuthConsentSign)
                .buildAndExpand(userId);

        return restGate.call(ConsentSignDttm.class,
                userAuthUrl,
                method.toUriString(),
                null,
                HttpMethod.GET,
                getHeaders(),
                MediaType.APPLICATION_JSON);
    }

    @Data
    public static class UserList {
        private List<GetUserRes> list;
    }

    @Data
    public static class ConsentSignDttm {
        private Date termsOfUse;
        private Date privacyPolicy;
        private Date sber500PrivacyPolicy;
        private Date sber500Consent;
        private Date sber500TermOfUse;
        private Date sber500PersonalDataConsent;
        private Date mailingConsent;
    }
}
