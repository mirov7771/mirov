package ru.sberx.questionary.gate.service.impl;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sberx.questionary.gate.client.RestGate;
import ru.sberx.questionary.gate.service.OnBoardingService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OnBoardingServiceImpl implements OnBoardingService {

    public static final String STARTUPS = "startups";

    private final RestGate restGate;

    @Value("${application.onboarding.url}")
    private String onBoardingUrl;
    @Value("${application.onboarding.onboarding}")
    private String getOnBoardingMethod;

    @Override
    public OnBoardingElements getOnBoarding(String sysName) {
        UriComponents method = UriComponentsBuilder
                .fromUriString(getOnBoardingMethod)
                .queryParam("sysName", Optional.ofNullable(sysName))
                .build();

        return restGate.call(OnBoardingElements.class,
                onBoardingUrl,
                method.toUriString(),
                null,
                HttpMethod.GET,
                getHeaders(),
                MediaType.APPLICATION_JSON);
    }

    public static Map<String, String> getHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("requestId", ThreadContext.get("requestId"));
        headers.put("client-id", ThreadContext.get("client-id"));
        headers.put("user-id", ThreadContext.get("user-id"));
        return headers;
    }

    @Data
    public static class OnBoardingElements {
        private Integer quantity;
        private Integer position;
        private String sysName;
        private List<OnBoarding> items;

        @Data
        public static class OnBoarding {
            private String sysName;
            private String target;
            private String content;
            private Integer role;
            private Integer position;
            private Integer number;
        }
    }
}
