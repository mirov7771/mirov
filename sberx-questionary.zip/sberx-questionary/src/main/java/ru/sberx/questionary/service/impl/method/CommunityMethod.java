package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.QueryBuilder;
import ru.sberx.questionary.controller.dto.req.CommunityListReq;
import ru.sberx.questionary.controller.dto.res.CommunityListRes;
import ru.sberx.questionary.controller.dto.support.Community;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.util.GuideService;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static ru.sberx.questionary.util.GuideService.PROCESSING_STATE;
import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@Slf4j
@RequiredArgsConstructor
public class CommunityMethod {

    private final UserAuth userAuth;
    private final QuestionnaireRepository questionnaireRepository;
    private final CommunityApplicationRepository communityApplicationRepository;
    private final QueryBuilder queryBuilder;
    private final RepresentativeRepository representativeRepository;
    private final InvestmentRepository investmentRepository;
    private final ProjectRepository projectRepository;

    public Community postCommunity(Community req, String sessionId) {
        Community res = new Community();
        CommunityApplication communityApplication = new CommunityApplication();
        communityApplication.setPreAuth(true);
        if (sessionId != null) {
            Long externalId = userAuth.getUserId(sessionId);
            if (externalId == null) {
                throw new SberxException(SberxErrors.INVALID_SESSION);
            }
            Optional<Questionnaire> optQuestionnaire = Optional.ofNullable(questionnaireRepository.findConfirmedByUserId(externalId));
            if (optQuestionnaire.isEmpty()) {
                optQuestionnaire = Optional.ofNullable(questionnaireRepository.findAllByUserId(externalId));
                if (optQuestionnaire.isEmpty())
                    throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            }
            Long qId = optQuestionnaire.get().getQuestionnaireId();
            Optional<CommunityApplication> opt = communityApplicationRepository.findByQuestionnaireId(qId);
            if (opt.isPresent()) {
                communityApplication = opt.get();
                communityApplication.setQuestionnaireId(optQuestionnaire.get().getQuestionnaireId());
                communityApplication.setPreAuth(false);
            } else {
                communityApplication.setQuestionnaireId(optQuestionnaire.get().getQuestionnaireId());
            }
        }
        communityApplication.setState(PROCESSING_STATE);
        communityApplication.setModified(new Date());
        communityApplication.setCreated(new Date());
        communityApplication.setType(req.getType());
        communityApplication.setName(nvl(req.getName(), communityApplication.getName()));
        communityApplication.setSite(nvl(req.getSite(), communityApplication.getSite()));
        communityApplication.setPosition(nvl(req.getPosition(), communityApplication.getPosition()));
        communityApplication.setPhoneNumber(nvl(req.getPhoneNumber(), communityApplication.getPhoneNumber()));
        communityApplication.setExpectation(nvl(req.getExpectation(), communityApplication.getExpectation()));
        communityApplication.setUseful(nvl(req.getUseful(), communityApplication.getUseful()));
        communityApplication.setIndustry(nvl(req.getIndustry(), communityApplication.getIndustry()));
        communityApplication.setTechnology(nvl(req.getTechnology(), communityApplication.getTechnology()));
        communityApplication.setGeography(nvl(req.getGeography(), communityApplication.getGeography()));
        communityApplication.setRound(nvl(req.getRound(), communityApplication.getRound()));
        communityApplication.setVentureProjectsCount(nvl(req.getVentureProjectsCount(), communityApplication.getVentureProjectsCount()));
        communityApplication.setFacebook(nvl(req.getFacebook(), communityApplication.getFacebook()));
        communityApplication.setComment(nvl(req.getComment(), communityApplication.getComment()));
        communityApplication.setEmail(nvl(req.getEmail(), communityApplication.getEmail()));
        communityApplication.setExpert(nvl(req.getExpert(), communityApplication.getExpert()));
        communityApplication.setFio(nvl(req.getFio(), communityApplication.getFio()));
        communityApplication.setTelegram(nvl(req.getTelegram(), communityApplication.getTelegram()));
        communityApplicationRepository.save(communityApplication);
        res.setId(communityApplication.getId());
        return res;
    }

    public Community getCommunity(Long id, String sessionId, Long userId) {
        if (id == null && sessionId == null && userId == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);

        if (id != null) {
            Optional<CommunityApplication> optCommunityApplication = communityApplicationRepository.findById(id);
            if (optCommunityApplication.isPresent()) {
                Community community = optCommunityApplication.get().toCommunityDto();
                Questionnaire questionnaire = new Questionnaire();
                if (Objects.nonNull(community.getQuestionnaireId())) {
                    Optional<Questionnaire> optQuestionnaire = questionnaireRepository.findById(community.getQuestionnaireId());
                    if (optQuestionnaire.isPresent()) {
                        questionnaire = optQuestionnaire.get();
                    }
                }
                return getCommunityWithState(questionnaire, community);
            } else {
                throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            }
        } else {
            Long externalId = userId;
            if (StringUtils.hasText(sessionId))
                externalId = userAuth.getUserId(sessionId);
            if (externalId == null)
                throw new SberxException(SberxErrors.INVALID_SESSION);

            Optional<Questionnaire> optQuestionnaire = Optional.ofNullable(questionnaireRepository.findConfirmedByUserId(externalId));
            if (optQuestionnaire.isEmpty())
                optQuestionnaire = Optional.ofNullable(questionnaireRepository.findAllByUserId(externalId));
            if (optQuestionnaire.isPresent()) {
                Questionnaire q = optQuestionnaire.get();
                Long qId = q.getQuestionnaireId();
                String site = q.getSite();
                String inviteFio = q.getInviteFio();
                Optional<CommunityApplication> opt = communityApplicationRepository.findByQuestionnaireId(qId);
                if (opt.isPresent()) {
                    return getCommunityWithState(optQuestionnaire.get(), opt.get().toCommunityDto());
                } else {
                    Community community = new Community();
                    community.setPhoneNumber(optQuestionnaire.get().getPhoneNumber());
                    community.setEmail(optQuestionnaire.get().getEmail());
                    community.setName(optQuestionnaire.get().getName());
                    if (q.getGeography() != null && q.getGeography().length > 0)
                        community.setGeography(q.getGeography()[0]);
                    if (q.getStady() != null && q.getStady().length > 0)
                        community.setRound(q.getStady());
                    if (q.getIndustry() != null && q.getIndustry().length > 0)
                        community.setIndustry(q.getIndustry());
                    community.setFio(inviteFio);

                    Representative representative = representativeRepository.findByQuestionnaireId(qId);
                    if (representative != null) {
                        community.setFacebook(representative.getFacebook());
                        if (!StringUtils.hasText(community.getPhoneNumber()))
                            community.setPhoneNumber(representative.getPhone());
                    }

                    if (optQuestionnaire.get().getType().equals(2)) {
                        Investment investment = investmentRepository.findByQuestionnaireId(qId);
                        if (investment != null) {
                            if (investment.getGeography() != null && investment.getGeography().length > 0)
                                community.setGeography(investment.getGeography()[0]);
                            community.setIndustry(investment.getIndustry());
                        }
                    }

                    Project project = projectRepository.findByQuestionnaireIdAndIsDisabled(qId, false);
                    if (project != null && community.getRound() == null) {
                        long[] s = {qId};
                        community.setRound(s);
                    }
                    community.setSite(site);
                    return getCommunityWithState(q, community);
                }
            } else {
                throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            }
        }
    }

    public CommunityListRes getCommunityList(CommunityListReq req) {
        CommunityListRes res = new CommunityListRes();
        List<CommunityApplication> list = queryBuilder.getCommunityList(req);
        res.setTotalRowCount(list.size());
        if (req.getRowCount() != null && !ObjectUtils.isEmpty(list)) {
            int offset = req.getPageToken() != null ? req.getPageToken() : 0;
            int from = req.getRowCount() * offset;
            int to = from + req.getRowCount();
            if (to >= list.size()) {
                res.setNextPageToken(null);
                to = list.size();
            } else {
                res.setNextPageToken(offset + 1);
            }
            log.debug("Limiting list, getting sublist from {} to {}", from, to);
            list = list.subList(from, to);
        }
        res.setRowCount(list.size());
        res.setList(list.stream().map(CommunityApplication::toCommunityDto).collect(Collectors.toList()));
        return res;
    }

    public Community changeCommunity(Community req, Long id, String sessionId) {
        Community community = new Community();
        CommunityApplication communityApplication = communityApplicationRepository.findById(id)
                .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
        if (sessionId != null) {
            Long externalId = userAuth.getUserId(sessionId);
            if (externalId == null) {
                throw new SberxException(SberxErrors.INVALID_SESSION);
            }
            Optional<Questionnaire> optQuestionnaire = Optional.ofNullable(questionnaireRepository.findConfirmedByUserId(externalId));
            if (optQuestionnaire.isEmpty()) {
                throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            }
            if (!Objects.equals(communityApplication.getQuestionnaireId(), optQuestionnaire.get().getQuestionnaireId())) {
                throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
            }
        }
        if (req.getState() != null)
            communityApplication.setState(req.getState());
        communityApplication.setModified(new Date());
        if (req.getType() != null)
            communityApplication.setType(req.getType());
        if (req.getName() != null)
            communityApplication.setName(req.getName());
        if (req.getSite() != null)
            communityApplication.setSite(req.getSite());
        if (req.getPosition() != null)
            communityApplication.setPosition(req.getPosition());
        if (req.getPhoneNumber() != null)
            communityApplication.setPhoneNumber(req.getPhoneNumber());
        if (req.getExpectation() != null)
            communityApplication.setExpectation(req.getExpectation());
        if (req.getUseful() != null)
            communityApplication.setUseful(req.getUseful());
        if (req.getIndustry() != null)
            communityApplication.setIndustry(req.getIndustry());
        if (req.getTechnology() != null)
            communityApplication.setTechnology(req.getTechnology());
        if (req.getGeography() != null)
            communityApplication.setGeography(req.getGeography());
        if (req.getRound() != null)
            communityApplication.setRound(req.getRound());
        if (req.getVentureProjectsCount() != null)
            communityApplication.setVentureProjectsCount(req.getVentureProjectsCount());
        if (req.getFacebook() != null)
            communityApplication.setFacebook(req.getFacebook());
        if (req.getComment() != null)
            communityApplication.setComment(req.getComment());
        if (req.getEmail() != null)
            communityApplication.setEmail(req.getEmail());
        if (req.getExpert() != null)
            communityApplication.setExpert(req.getExpert());
        if (req.getFio() != null)
            communityApplication.setFio(req.getFio());
        communityApplicationRepository.save(communityApplication);
        community.setId(id);
        return community;
    }

    public boolean isValidParams(Community req, Integer type) {
        if (type.equals(0)) {
            return StringUtils.hasText(req.getName())
                    && StringUtils.hasText(req.getSite())
                    && StringUtils.hasText(req.getFio())
                    && StringUtils.hasText(req.getPosition())
                    && StringUtils.hasText(req.getExpectation())
                    && StringUtils.hasText(req.getUseful())
                    && StringUtils.hasText(req.getPhoneNumber());
        }
        if (type.equals(2)) {
            return StringUtils.hasText(req.getName())
                    && StringUtils.hasText(req.getSite())
                    && StringUtils.hasText(req.getPosition())
                    && StringUtils.hasText(req.getFio())
                    && StringUtils.hasText(req.getEmail())
                    && StringUtils.hasText(req.getPhoneNumber())
                    && req.getIndustry() != null
                    && req.getIndustry().length > 0
                    && req.getGeography() != null
                    && req.getRound() != null
                    && req.getRound().length > 0;
        }
        return false;
    }

    private Community getCommunityWithState(Questionnaire questionnaire, Community community) {
        community.setQuestionnaireState(questionnaire.getState());
        community.setQuestionnaireStateName(GuideService.getState(questionnaire.getState()));
        return community;
    }
}
