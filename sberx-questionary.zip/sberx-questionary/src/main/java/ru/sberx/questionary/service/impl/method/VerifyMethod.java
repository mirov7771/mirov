package ru.sberx.questionary.service.impl.method;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.guide.guide.req.SearchReq;
import ru.sberx.questionary.config.PropertiesConfig;
import ru.sberx.questionary.controller.dto.req.VerifyReq;
import ru.sberx.questionary.controller.dto.res.DefaultRes;
import ru.sberx.questionary.controller.dto.res.VerifyRes;
import ru.sberx.questionary.controller.tariff.dto.req.CheckTariffReq;
import ru.sberx.questionary.controller.tariff.dto.req.PostTariffReq;
import ru.sberx.questionary.controller.tariff.dto.support.TariffDto;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.service.questionary.QuestionaryService;
import ru.sberx.questionary.service.tariff.TariffService;
import ru.sberx.questionary.util.PopUpStatus;
import ru.sberx.questionary.util.Utils;
import ru.sberx.utils.validator.ConditionValidator;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static ru.sberx.questionary.util.GuideService.*;

@Component
@RequiredArgsConstructor
@Slf4j
public class VerifyMethod {

    private static final Set<Long> possibleApplicationStates = Set
            .of(CHECKING_STATE, IN_PROGRESS_STATE, CONFIRMED_STATE, DENIED);
    private final ApplicationRepository applicationRepository;
    private final FeedbackRepository feedbackRepository;
    private final PilotRepository pilotRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final RepresentativeRepository representativeRepository;
    private final ProjectRepository projectRepository;
    private final InvestmentRepository investmentRepository;
    private final WorkerRepository workerRepository;
    private final ContactRepository contactRepository;
    private final FounderRepository founderRepository;
    private final CommunityUserRepository communityUserRepository;
    private final InvestmentClubRepository investmentClubRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final StatusInfoRepository statusInfoRepository;
    private final PopupInfoRepository popupInfoRepository;
    private final RoundRepository roundRepository;
    private final CommunityApplicationRepository communityApplicationRepository;
    private final UserAuth userAuth;
    private final DeleteQuestionnaireMethod deleteQuestionnaireMethod;
    private final MidService midService;
    private final PropertiesConfig propertiesConfig;
    private final SberFiveHundredRepository sberFiveHundredRepository;
    private final SyndicateApplicationRepository syndicateApplicationRepository;
    private final QuestionnaireFundsRepository questionnaireFundsRepository;
    private final ScoutingApplicationRepository scoutingApplicationRepository;
    private final ReplyRepository replyRepository;
    private final ImportReplaceDAORepository importReplaceDAORepository;
    private final ru.sberx.questionary.gate.service.GuideService guideService;
    private final TariffService tariffService;
    private final QuestionnaireLocaleDaoRepository questionnaireLocaleDaoRepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final InvestmentLocaleDaoRepository investmentLocaleDaoRepository;
    private final ImportReplaceLangDaoRepository importReplaceLangDaoRepository;
    private final QuestionaryService questionaryService;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;
    @Value("${application.mid.notify.link}")
    private String link;
    @Value("${application.bad-domains}")
    private Set<String> badDomains;
    @Value("${application.verify.update_date_for_sort}")
    private Long updateDateForSort;


    public VerifyRes execute(VerifyReq req) {
        VerifyRes res = new VerifyRes();
        if (QUESTIONNAIRE.equalsIgnoreCase(req.getTableName())) {
            if (Boolean.TRUE.equals(req.getChangeRoleCheck()) && req.getNewType() == null)
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS,
                        "If changeRoleCheck is true, newType must not be null.");
            verifyQuestionnaire(req, res);
        } else if (PILOT.equalsIgnoreCase(req.getTableName())) {
            verifyPilot(req, res);
        } else if (APPLICATION.equalsIgnoreCase(req.getTableName())) {
            verifyApplication(req, res);
        } else if (ROUND.equalsIgnoreCase(req.getTableName())) {
            verifyRound(req, res);
        } else if (COMMUNITY.equalsIgnoreCase(req.getTableName())) {
            verifyCommunity(req, res);
        } else if (SYNDICATE_APPLICATION.equalsIgnoreCase(req.getTableName())) {
            verifySyndicateApplication(req, res);
        } else if (REPLY.equalsIgnoreCase(req.getTableName())) {
            verifyReply(req, res);
        } else if (SCOUTING_APPLICATION.equalsIgnoreCase(req.getTableName())) {
            verifyScouting(req, res);
        }
        return res;
    }

    private void verifyScouting(VerifyReq req, VerifyRes res) {
        ScoutingApplication scouting = scoutingApplicationRepository.findById(UUID.fromString(req.getTableId())).orElseThrow(()
                -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Scouting не найден"));
        Long userId = userAuth.getUserId2(req.getSessionId());
        StatusInfo statusInfo = new StatusInfo();
        statusInfo.setObjectType(req.getTableName());
        statusInfo.setFromState(scouting.getState());
        statusInfo.setToState(req.getState());
        statusInfo.setComment(req.getComment());
        statusInfo.setUserId(userId);
        statusInfo.setDate(new Date());
        statusInfo.setUid(scouting.getUid().toString());
        statusInfoRepository.save(statusInfo);
        res.setFromState(scouting.getState());
        scouting.setState(req.getState());
        if (StringUtils.hasText(req.getComment()))
            scouting.setAdminComment(req.getComment());
        scoutingApplicationRepository.save(scouting);
        res.setToState(req.getState());
    }

    private void verifyCommunity(VerifyReq req, VerifyRes res) {
        CommunityApplication communityApplication = communityApplicationRepository.findById(
                        Long.valueOf(req.getTableId()))
                .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Community не найден"));
        Long userId = userAuth.getUserId2(req.getSessionId());
        StatusInfo statusInfo = new StatusInfo();
        statusInfo.setObjectId(Long.valueOf(req.getTableId()));
        statusInfo.setObjectType(req.getTableName());
        statusInfo.setFromState(communityApplication.getState());
        statusInfo.setToState(req.getState());
        statusInfo.setComment(req.getComment());
        statusInfo.setUserId(userId);
        statusInfo.setDate(new Date());
        statusInfoRepository.save(statusInfo);
        res.setFromState(communityApplication.getState());
        communityApplication.setState(req.getState());
        communityApplicationRepository.save(communityApplication);
        res.setToState(req.getState());
        if (StringUtils.hasText(communityApplication.getEmail())) {
            Questionnaire q = questionnaireRepository.findByQuestionnaireId(communityApplication.getQuestionnaireId());
            UserQuestionnaire uq = userQuestionnaireRepository.findFirstByQuestionnaireId(communityApplication.getQuestionnaireId());
            req.setEmail(communityApplication.getEmail());
            sendNotifyCommunity(req, uq != null ? uq.getUserId() : null, q != null ? q.getType() : null);
        }
    }

    private void sendNotifyCommunity(VerifyReq req, Long userId, Integer type) {
        Map<String, Object> params = new HashMap<>();
        if (CONFIRMED_STATE.equals(req.getState())) {
            midService.notify("communityApproved",
                    params,
                    req.getEmail(),
                    userAuth.getUserIdByEmail2(req.getEmail()),
                    "Статус анкеты сообщества",
                    null,
                    userId,
                    type);
        } else if (DENIED.equals(req.getState())) {
            params.put("comment", req.getComment());
            midService.notify("communityRejected",
                    params,
                    req.getEmail(),
                    userAuth.getUserIdByEmail2(req.getEmail()),
                    "Статус анкеты сообщества",
                    null,
                    userId,
                    type);
        }
    }

    private void verifySyndicateApplication(VerifyReq req, VerifyRes res) {
        SyndicateApplication syndicateApplication = syndicateApplicationRepository.findById(Long.valueOf(req.getTableId()))
                .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Syndicate Application не найден"));
        Long userId = userAuth.getUserId2(req.getSessionId());
        StatusInfo statusInfo = new StatusInfo();
        statusInfo.setObjectId(Long.valueOf(req.getTableId()));
        statusInfo.setObjectType(req.getTableName());
        statusInfo.setFromState(syndicateApplication.getState());
        statusInfo.setToState(req.getState());
        statusInfo.setComment(req.getComment());
        statusInfo.setUserId(userId);
        statusInfo.setDate(new Date());
        statusInfoRepository.save(statusInfo);
        res.setFromState(syndicateApplication.getState());
        syndicateApplication.setState(req.getState());
        syndicateApplicationRepository.save(syndicateApplication);
        res.setToState(req.getState());
    }

    private String getQName(String name, String fullName) {
        return (name != null && !"-".equals(name)) ? name :
                ((fullName != null && !"-".equals(fullName)) ? fullName : "");
    }

    public void verifyQuestionnaire(VerifyReq req, VerifyRes res) {
        Long tableId = null;
        Long parentId = null;
        Date updateDateForSortOld = null;
        Boolean changedRole = false;
        Questionnaire q = findQuestionnaireByIdOrUuid(req.getTableId());
        if (q != null) {
            tableId = q.getQuestionnaireId();
            parentId = q.getParentId();
        }

        if (q == null || q.getState() == null) {
            throw new SberxException(SberxErrors.BAD_REQUEST);
        }
        validateState(q.getState(), req.getState());

        if (CONFIRMED_STATE.equals(req.getState())) {
            updateDateForSortOld = q.getUpdateDateForSort();
            setUpdateDateForSort(q);
            updateImportReplaceSearch(q);

            PostTariffReq tariffReq = new PostTariffReq();
            tariffReq.setQuestionnaireId(q.getQuestionnaireId());
            tariffReq.setRole(userAuth.getUserRole(req.getSessionId()));
            DefaultRes postRes = tariffService.post(tariffReq);
            changedRole = postRes.getIsChangedRole();
        }

        String name = getQName(q.getName(), q.getFullName());
        String route = q.getType().equals(0) ? "/startups/"
                : (q.getType().equals(1) ? "/corporates/" : "/investors/") + q.getUuid();
        if (SHORT_STATE.equals(q.getState())) {
            String status = null;
            Representative representative = representativeRepository
                    .findByQuestionnaireId(tableId);
            String email;
            if (representative != null &&
                    representative.getEmail() != null &&
                    !"".equals(representative.getEmail())) {
                email = q.getEmail();
            } else {
                UserQuestionnaire user = findUserByQuestionnaireId(tableId);
                if (user != null && user.getEmail() != null && !"".equals(user.getEmail())) {
                    email = user.getEmail();
                } else {
                    email = q.getEmail();
                }
            }
            if (email != null && !"".equals(email)) {
                Long userId = userAuth.getUserIdByEmail(email);
                status = userAuth.restorePassword(email,
                        userId == null ? "registration" : "restore");
            }
            if (status == null) {
                throw new SberxException(SberxErrors.STATE_NOT_FOUND, "В акнете не заполнен email клиента");
            }
        }
        res.setFromState(q.getState());
        long state = q.getState();
        q.setState(req.getState());
        q.setComment(req.getComment());
        q.setModified(new Date());
        if (TO_EDIT.equals(req.getState())) {
            q.setRevisionDate(new Date());
        }
        questionnaireRepository.save(q);
        res.setToState(q.getState());
        if (CONFIRMED_STATE.equals(req.getState())) {
            if (q.getParentId() != null) { // если анкета дочерняя
                updateStatusInfo(req, state, "Изменения согласованы администратором", q.getParentId(), q.getQuestionnaireId());
                updateStatusInfo(req, 20004L, "Обновлена основная анкета", null, q.getParentId());
                questionaryService.updateLabelNew(q.getQuestionnaireId(), true);
            } else {
                updateStatusInfo(req, res.getFromState(), req.getComment(), null, q.getQuestionnaireId());
                questionaryService.updateLabelNew(q.getQuestionnaireId(), false);
            }

            UpdatedMainQuestionnaire updatedMainQuestionnaire = updateMainQuestionnaire(q);
            Long finalQuestionnaireId = updatedMainQuestionnaire.getMainQuestionnaireId();
            changedRole = Boolean.TRUE.equals(updatedMainQuestionnaire.getChangedRole()) || Boolean.TRUE.equals(changedRole);

            List<UserQuestionnaire> users = userQuestionnaireRepository.findByQuestionnaireId(
                    finalQuestionnaireId);
            if (!CollectionUtils.isEmpty(users) && !Boolean.TRUE.equals(changedRole)) {
                for (UserQuestionnaire uq : users) {
                    userAuth.changeRole(uq.getUserId(), "SuperClient", q.getType());
                }
            }
            updatePopupInfoRepository(finalQuestionnaireId, updateDateForSortOld, PopUpStatus.getProcessingStatus(q.getType()).getValue(), q.getType());
            UserQuestionnaire uq = findUserByQuestionnaireId(finalQuestionnaireId);
            if (uq != null) {
                String email = userAuth.getEmailByUserId(uq.getUserId());
                Map<String, Object> params = new HashMap<>();
                params.put("name", name);
                midService.notify("VERIFY_Q_2004", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, uq.getUserId(), q.getType());
            }
        } else if (TO_EDIT.equals(req.getState())) {
            UserQuestionnaire uq = findUserByQuestionnaireId(parentId != null ? parentId : tableId);
            if (uq != null) {
                String email = userAuth.getEmailByUserId(uq.getUserId());
                String sysName;
                Map<String, Object> params = new HashMap<>(Map.of("comment", req.getComment()));
                params.put("name", name);
                if (Boolean.TRUE.equals(req.getChangeRoleCheck())) {
                    Long questionnaireId = uq.getQuestionnaireId();
                    if (StringUtils.hasText(req.getNewTariff())) {
                        CheckTariffReq checkTariffReq = new CheckTariffReq();
                        checkTariffReq.setSysname(req.getNewTariff());
                        checkTariffReq.setType(req.getNewType());
                        if (req.getNewInvestorType() != null)
                            checkTariffReq.setInvestorType(req.getNewInvestorType());
                        tariffService.check(checkTariffReq);
                        if (!questionnaireId.equals(tableId))
                            deleteQuestionnaireMethod.deleteByQuestionnaireId(tableId);
                        Questionnaire oq = questionnaireRepository.findByQuestionnaireId(questionnaireId);
                        oq.setType(req.getNewType());
                        oq.setState(req.getState());
                        if (req.getNewInvestorType() != null)
                            oq.setInvestorType(req.getNewInvestorType().longValue());
                        else
                            oq.setInvestorType(null);
                        questionnaireRepository.save(oq);
                        PostTariffReq postTariffReq = new PostTariffReq();
                        postTariffReq.setQuestionnaireId(oq.getQuestionnaireId());
                        postTariffReq.setQuestionnaireUuid(oq.getUuid().toString());
                        postTariffReq.setSysname(req.getNewTariff());
                        postTariffReq.setUserId(uq.getUserId());
                        postTariffReq.setRole("Administrator");
                        tariffService.post(postTariffReq);
                    } else {
                        userAuth.deleteUserSessions(uq.getUserId());
                        deleteQuestionnaireMethod.deleteByQuestionnaireId(questionnaireId);
                        if (!questionnaireId.equals(tableId))
                            deleteQuestionnaireMethod.deleteByQuestionnaireId(tableId);
                    }
                    userAuth.changeRole(uq.getUserId(), "Client", req.getNewType());
                    sysName = "changeRole";
                    params.put("text", newTypeVal(req.getNewType()));
                    if (req.getNewType() != null)
                        params.put("role", req.getNewType().equals(1) ? "корпорация" : (req.getNewType().equals(2) ? "инвестор" : "стартап"));
                    else
                        params.put("role", "стартап");
                } else {
                    sysName = "VERIFY_Q_20003";
                }
                midService.notify(sysName,
                        params,
                        email,
                        userAuth.getUserIdByEmail2(email),
                        "Статус заявки",
                        route,
                        uq.getUserId(),
                        q.getType());
            }
        } else if (PROCESSING_STATE.equals(req.getState())) {
            updatePopupInfoRepository(tableId, PopUpStatus.getProcessingStatus(q.getType()).getValue());
        } else if (DENIED.equals(req.getState()) || TO_DELETION.equals(req.getState())) {
            UserQuestionnaire uq = findUserByQuestionnaireId(tableId);
            Long userId = null;
            if (uq != null) {
                userId = uq.getUserId();
                String email = userAuth.getEmailByUserId(uq.getUserId());
                Map<String, Object> params = new HashMap<>();
                params.put("comment", req.getComment());
                params.put("name", name);
                midService.notify("VERIFY_Q_2009",
                        params,
                        email,
                        userAuth.getUserIdByEmail2(email),
                        "Статус заявки",
                        route,
                        userId,
                        q.getType());
            }
            if (parentId == null) {
                List<RoundDao> rounds = roundRepository.findByQuestionnaireId(tableId);
                if (!CollectionUtils.isEmpty(rounds)) {
                    rounds.forEach(i -> i.setState(20013));
                    roundRepository.saveAll(rounds);
                }
                if (userId != null) {
                    List<Reply> replies = replyRepository.findByUserId(userId);
                    if (!CollectionUtils.isEmpty(replies)) {
                        replies.forEach(i -> i.setState(20013L));
                        replyRepository.saveAll(replies);
                    }
                }
            }
        }

        //STARTUPHUB-3831 [UNITY] Удалять дочернюю анкету если отклоняешь родительскую
        if (CONFIRMED_STATE.equals(res.getFromState())) {
            if (tableId == null) {
                throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
            }
            List<Questionnaire> childs = questionnaireRepository.findAllByParentIds(Set.of(tableId));
            if (!CollectionUtils.isEmpty(childs)) {
                childs.forEach(i -> deleteQuestionnaireMethod.deleteByQuestionnaireId(i.getQuestionnaireId()));
            }
        }

        if (!CONFIRMED_STATE.equals(req.getState()))
            updateStatusInfo(req, res.getFromState(), req.getComment(), q.getParentId(), q.getQuestionnaireId());
    }

    private Questionnaire findQuestionnaireByIdOrUuid(String tableId) {
        Questionnaire q;
        long questionnaireId;
        try {
            questionnaireId = Long.parseLong(tableId);
            q = questionnaireRepository.findByQuestionnaireId(questionnaireId);
        } catch (NumberFormatException e) {
            try {
                q = questionnaireRepository.findByUuid(UUID.fromString(tableId));
            } catch (IllegalArgumentException ex) {
                throw new SberxException(SberxErrors.BAD_REQUEST);
            }
            if (q == null) {
                throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            }
        }
        if (q == null) {
            q = questionnaireRepository.findByUuid(
                    UUID.nameUUIDFromBytes(tableId.getBytes(StandardCharsets.UTF_8)));
        }
        ConditionValidator.preValidate(q, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        return q;
    }

    private void updateImportReplaceSearch(Questionnaire q) {
        if (q == null || q.getQuestionnaireId() == null) {
            return;
        }
        ImportReplaceDAO importReplaceDAO = importReplaceDAORepository
                .findByQuestionnaireId(q.getQuestionnaireId());
        if (importReplaceDAO != null && importReplaceDAO.getName() != null
                && importReplaceDAO.getName().length != 0) {
            SearchReq searchReq = new SearchReq();
            searchReq.setName(importReplaceDAO.getName());
            searchReq.setAdmin(true);
            CompletableFuture.runAsync(() -> guideService.updateSearch(searchReq));
        }
    }

    private void updatePopupInfoRepository(Long questionnaireId, String newStatus) {
        popupInfoRepository.updatePopupByQuestionnaireIdWhereWatchedIsFalse(questionnaireId);
        PopupInfoDao newPopup = new PopupInfoDao();
        newPopup.setQuestionnaireId(questionnaireId);
        newPopup.setStatus(newStatus);
        newPopup.setWatched(false);
        Long usrId = Utils.getUserId(questionnaireId, userQuestionnaireRepository);
        newPopup.setUserId(usrId);
        popupInfoRepository.save(newPopup);
    }

    private void updatePopupInfoRepository(Long questionnaireId, Date updateDateForSort, String status, Integer type) {
        popupInfoRepository.updatePopupByQuestionnaireIdWhereWatchedIsFalseAndStatus(questionnaireId, status);
        PopupInfoDao newPopup = new PopupInfoDao();
        newPopup.setQuestionnaireId(questionnaireId);
        String newStatus = PopUpStatus.getActiveStatus(type).getValue();
        if (updateDateForSort != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            cal.add(Calendar.HOUR, -1);
            if (updateDateForSort.before(cal.getTime()) || updateDateForSort.equals(cal.getTime()))
                newStatus = PopUpStatus.ACTIVE_NOT_UP_SORT.getValue();
            else
                newStatus = PopUpStatus.ACTIVE_UP_SORT.getValue();
        }
        newPopup.setStatus(newStatus);
        newPopup.setWatched(false);
        Long usrId = Utils.getUserId(questionnaireId, userQuestionnaireRepository);
        newPopup.setUserId(usrId);
        popupInfoRepository.save(newPopup);
    }

    private UserQuestionnaire findUserByQuestionnaireId(Long id) {
        List<UserQuestionnaire> users = userQuestionnaireRepository.findByQuestionnaireId(id);
        if (!ObjectUtils.isEmpty(users)) {
            return users.get(0);
        }
        return null;
    }

    public void verifyPilot(VerifyReq req, VerifyRes res) {
        Long tableId = Long.valueOf(req.getTableId());
        Pilot p = pilotRepository.findByPilotId(tableId);
        ConditionValidator.preValidate(p, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        //STARTUPHUB-5189[Back] Доработки сервисов, для ограничения возможного максимального числа пилотов
        if (CONFIRMED_STATE.equals(req.getState())) {
            TariffDto tariffDto = null;
            try {
                tariffDto = tariffService.get(null, "Administrator", p.getQuestionnaireId(), null, true);
            } catch (Exception e) {
                log.error("Error getting tariff ", e);
            }
            if (tariffDto != null && "CorpLight".equalsIgnoreCase(tariffDto.getSysname())) {
                List<Pilot> hubPilots = pilotRepository.findHubPilots(p.getQuestionnaireId());
                if (!CollectionUtils.isEmpty(hubPilots) && hubPilots.size() >= 5)
                    throw new SberxException(SberxErrors.MAX_PILOTS);
            }
        }

        res.setFromState(p.getState());
        p.setState(req.getState());
        p.setModified(new Date());
        pilotRepository.save(p);
        updateStatusInfo(req, res.getFromState(), req.getComment(), null, tableId);
        res.setToState(p.getState());
        questionnaireRepository.findByQuestionnaireId(tableId);
    }

    public void verifyApplication(VerifyReq req, VerifyRes res) {
        if (DENIED.equals(req.getState()) && ObjectUtils.isEmpty(req.getComment())) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS,
                    "required: comment");
        }
        if ((DENIED.equals(req.getState()) || CONFIRMED_STATE.equals(req.getState())) && ObjectUtils
                .isEmpty(req.getEmail())) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS,
                    "required: email");
        }
        Long tableId = Long.valueOf(req.getTableId());
        ApplicationDao applicationDao = applicationRepository.findById(tableId)
                .orElseThrow(() -> new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND));

        if (applicationDao.getType() == null) {
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND, "У данной анкеты нет типа");
        }
        if (!possibleApplicationStates.contains(req.getState())) {
            throw new SberxException(SberxErrors.STATE_NOT_FOUND);
        }

        if (StringUtils.hasText(req.getNewTariff())) {
            CheckTariffReq checkTariffReq = new CheckTariffReq();
            checkTariffReq.setSysname(req.getNewTariff());
            if (Boolean.TRUE.equals(req.getChangeRoleCheck())
                    && req.getNewType() != null) {
                checkTariffReq.setType(req.getNewType());
                if (req.getNewInvestorType() != null)
                    checkTariffReq.setInvestorType(req.getNewInvestorType());
            } else {
                if (applicationDao.getInvestorType() != null)
                    checkTariffReq.setInvestorType(applicationDao.getInvestorType());
                checkTariffReq.setType(applicationDao.getType());
            }
            tariffService.check(checkTariffReq);
            if (Boolean.TRUE.equals(req.getChangeRoleCheck())
                    && req.getNewType() != null) {
                applicationDao.setType(req.getNewType());
                if (req.getNewInvestorType() != null)
                    applicationDao.setInvestorType(req.getNewInvestorType());
                applicationDao.setTariff(req.getNewTariff());
                applicationRepository.save(applicationDao);
            }
        }
        if (CONFIRMED_STATE.equals(req.getState())) {
            if (!isBusinessAngel(applicationDao) && req.getEmail() != null) {
                for (String s : badDomains) {
                    if (req.getEmail().toUpperCase().endsWith("@" + s.toUpperCase())) {
                        throw new SberxException(SberxErrors.WRONG_INPUT_EMAIL);
                    }
                }
            }

            Long userId = userAuth.getUserIdByEmail(req.getEmail());
            if (applicationDao.getState().equals(CONFIRMED_STATE.intValue())
                    && !req.getEmail().equals(applicationDao.getEmail())
                    && userId != null) {
                throw new SberxException(SberxErrors.USER_EXISTS);
            } else if (userId != null) {
                throw new SberxException(SberxErrors.USER_EXISTS);
            }

            if (applicationDao.getEmail() == null && !req.getEmail().equals(applicationDao.getEmail())) {
                applicationDao.setEmail(req.getEmail());
            }
            if (!StringUtils.hasText(applicationDao.getLogin())) {
                applicationDao.setLogin(req.getEmail());
            } else {
                if (userAuth.getUserIdByEmail(applicationDao.getLogin()) != null) {
                    throw new SberxException(SberxErrors.USER_ALREADY_CREATED);
                }
            }
            applicationDao.setUid(UUID.randomUUID().toString());
            applicationDao.setNotificationDttm(Date.from(Instant.now()));
            Map<String, Object> params = new HashMap<>();
            params.put("type", applicationDao.getType());
            params.put("link",
                    link.replace("{applicationId}", applicationDao.getUid())
                            .replace("{type}", applicationDao.getType().toString()));
            params.put("text", newTypeVal(applicationDao.getType()));
            params.put("email", req.getEmail());
            Questionnaire q = questionnaireRepository.findByQuestionnaireId(applicationDao.getQuestionnaireId());
            UserQuestionnaire uq = userQuestionnaireRepository.findFirstByQuestionnaireId(applicationDao.getQuestionnaireId());
            midService.notify("ApplicationApproved",
                    params,
                    req.getEmail(),
                    userAuth.getUserIdByEmail2(req.getEmail()),
                    "Статус заявки",
                    null,
                    uq != null ? uq.getUserId() : null,
                    q != null ? q.getType() : null);
        } else if (DENIED.equals(req.getState())) {
            Map<String, Object> params = new HashMap<>();
            params.put("type", applicationDao.getType());
            params.put("comment", req.getComment());
            params.put("text", newTypeVal(applicationDao.getType()));
            params.put("name", applicationDao.getOrgFullName());
            Questionnaire q = questionnaireRepository.findByQuestionnaireId(applicationDao.getQuestionnaireId());
            UserQuestionnaire uq = userQuestionnaireRepository.findFirstByQuestionnaireId(applicationDao.getQuestionnaireId());
            midService.notify("ApplicationRejected",
                    params,
                    req.getEmail(),
                    userAuth.getUserIdByEmail2(req.getEmail()),
                    "Статус заявки",
                    null,
                    uq != null ? uq.getUserId() : null,
                    q != null ? q.getType() : null);
        }
        res.setFromState(Long.valueOf(applicationDao.getState()));
        res.setToState(req.getState());
        applicationDao.setState(req.getState().intValue());
        applicationDao.setModified(new Date());
        if (req.getComment() != null) {
            applicationDao.setComment(req.getComment());
        }
        applicationRepository.save(applicationDao);
        updateStatusInfo(req, res.getFromState(), req.getComment(), null, tableId);
    }

    private void verifyRound(VerifyReq req, VerifyRes res) {
        Long tableId = Long.valueOf(req.getTableId());
        RoundDao roundDao = roundRepository.findById(tableId)
                .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Раунд не найден"));
        Optional<Questionnaire> questionnaire = questionnaireRepository.findById(roundDao.getQuestionnaireId());
        if (questionnaire.isEmpty())
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Анкета для данного раунда не найдена");
        String email = questionnaire.get().getEmail();
        Integer type = questionnaire.get().getType();
        UserQuestionnaire uq = userQuestionnaireRepository.findFirstByQuestionnaireId(questionnaire.get().getQuestionnaireId());
        Long userId = uq != null ? uq.getUserId() : null;
        Map<String, Object> params = new HashMap<>();
        params.put("name", getQName(questionnaire.get().getName(), questionnaire.get().getFullName()));
        String route = "/round/" + tableId;
        if (CONFIRMED_STATE.equals(req.getState())) {
            midService.notify("RoundApproved", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, userId, type);
        } else if (DENIED.equals(req.getState())) {
            params.put("comment", req.getComment());
            midService.notify("RoundRejected", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, userId, type);
        } else if (ARCHIVE.equals(req.getState())) {
            midService.notify("RoundExpired", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, userId, type);
        } else if (REMOVED.equals(req.getState()) && !TO_DELETION.equals(questionnaire.get().getState())) {
            String role = userAuth.getUserRole(req.getSessionId());
            if ("Administrator".equalsIgnoreCase(role)) {
                params.put("comment", req.getComment());
                midService.notify("RoundRemoved", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, userId, type);
            } else if ("SuperClient".equalsIgnoreCase(role)) {
                req.setComment("Снято с публикации по инициативе пользователя");
            }
        } else if (CHECKING_STATE.equals(req.getState()) && !REMOVED.equals(roundDao.getState().longValue())) {
            midService.notify("RoundCreated", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, userId, type);
        } else if (TO_EDIT.equals(req.getState())) {
            params.put("comment", req.getComment());
            midService.notify("RoundReview", params, email, userAuth.getUserIdByEmail2(email), "Статус заявки", route, userId, type);
        }
        res.setFromState(roundDao.getState().longValue());
        roundDao.setState(req.getState().intValue());
        roundRepository.save(roundDao);
        updateStatusInfo(req, res.getFromState(), req.getComment(), null, tableId);
        res.setToState(req.getState());
    }

    private void verifyReply(VerifyReq req, VerifyRes res) {
        Long tableId = Long.valueOf(req.getTableId());
        Reply reply = replyRepository.findByReplyId(tableId);
        if (reply == null)
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Заявка на пилот не найдена");

        updateStatusInfo(req, reply.getState(), req.getComment(), null, reply.getReplyId());

        Long questionnaireId;
        String pilotName;
        String route;
        if (Boolean.TRUE.equals(reply.getIsPilotOffer())) {
            questionnaireId = reply.getTableId();
            pilotName = reply.getOfferName();
            route = "/reply/" + tableId;
        } else {
            Pilot pilot = pilotRepository.findById(reply.getTableId()).orElseThrow(
                    () -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Пилот не найден"));
            questionnaireId = pilot.getQuestionnaireId();
            pilotName = pilot.getName();
            route = "/pilots/" + pilot.getPilotId() + "/reply/" + tableId;
        }

        Questionnaire corporate = questionnaireRepository.findByQuestionnaireId(questionnaireId);
        if (corporate == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);

        List<UserQuestionnaire> uqList = userQuestionnaireRepository.findByUserId(reply.getUserId());
        if (CollectionUtils.isEmpty(uqList))
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Пользователь для этой анкеты найден");

        UserQuestionnaire userQuestionnaire = uqList.get(0);
        Questionnaire startup = questionnaireRepository.findByQuestionnaireId(userQuestionnaire.getQuestionnaireId());
        if (startup == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);

        reply.setComment(req.getComment());

        String templateSysName = null;
        String corpTemplateSysName = null;
        if (PROCESSING_STATE.equals(req.getState())) {
            if (CHECKING_STATE.equals(reply.getState()))
                templateSysName = "REPLY_20002";
        } else if (CONFIRMED_STATE.equals(req.getState())) {
            if (CHECKING_STATE.equals(reply.getState()) || PROCESSING_STATE.equals(reply.getState()) || TO_EDIT.equals(reply.getState()))
                templateSysName = "REPLY_20004";
        } else if (DENIED.equals(req.getState())) {
            if (CHECKING_STATE.equals(reply.getState()) || PROCESSING_STATE.equals(reply.getState()) || TO_EDIT.equals(reply.getState()))
                templateSysName = "REPLY_20009";
        } else if (TO_EDIT.equals(req.getState())) {
            if (CHECKING_STATE.equals(reply.getState()) || PROCESSING_STATE.equals(reply.getState()))
                templateSysName = "REPLY_20003";
        } else if (REMOVED.equals(req.getState()) && !TO_DELETION.equals(startup.getState())) {
            if (Boolean.TRUE.equals(reply.getIsViewed()))
                if (Boolean.TRUE.equals(reply.getIsPilotOffer()))
                    corpTemplateSysName = "OFFER_20013";
                else
                    corpTemplateSysName = "REPLY_20013";
        } else if (CHECKING_STATE.equals(req.getState()) && REMOVED.equals(reply.getState())) {
            reply.setIsViewed(false);
        }
        if (templateSysName != null) {
            Map<String, Object> params = new HashMap<>();
            params.put("pilot_name", pilotName);
            params.put("corporate_name", corporate.getName());
            params.put("text", "<br /><br />Ниже вы можете ознакомиться с комментарием:<br />");
            params.put("comment", req.getComment());
            midService.notify(templateSysName,
                    params,
                    startup.getEmail(),
                    userAuth.getUserIdByEmail2(startup.getEmail()), "Статус отклика",
                    route,
                    userQuestionnaire.getUserId(),
                    startup.getType());
        }

        if (corpTemplateSysName != null) {
            String email = corporate.getEmail();
            Map<String, Object> params = new HashMap<>();
            params.put("pilot_name", pilotName);
            params.put("startup_name", startup.getName());

            if (!StringUtils.hasText(email)) {
                Representative representative = representativeRepository.findByQuestionnaireId(corporate.getQuestionnaireId());
                if (representative != null)
                    email = representative.getEmail();
            }

            if (StringUtils.hasText(email))
                midService.notify(corpTemplateSysName,
                        params,
                        email,
                        userAuth.getUserIdByEmail2(corporate.getEmail()), "Статус отклика",
                        route,
                        userQuestionnaire.getUserId(),
                        corporate.getType());
        }
        res.setFromState(reply.getState());
        res.setToState(req.getState());
        reply.setState(req.getState());
        replyRepository.save(reply);
    }

    private boolean isBusinessAngel(ApplicationDao applicationDao) {
        return Integer.valueOf(2).equals(applicationDao.getType()) && Integer.valueOf(11002)
                .equals(applicationDao.getInvestorType());
    }

    public void updateStatusInfo(VerifyReq req, long fromState, String comment, Long parentId, Long objectId) {
        Long userId = userAuth.getUserId2(req.getSessionId());

        StatusInfo statusInfo = new StatusInfo();
        statusInfo.setObjectId(objectId);
        statusInfo.setObjectType(req.getTableName());
        statusInfo.setFromState(fromState);
        statusInfo.setToState(req.getState());
        statusInfo.setComment(comment == null ? req.getComment() : comment);
        statusInfo.setUserId(userId);
        statusInfo.setDate(new Date());
        statusInfo.setParentId(parentId);
        statusInfoRepository.save(statusInfo);
    }

    private void validateState(Long fromState, Long toState) {
        for (Map.Entry<Long, Set<Long>> e : propertiesConfig.getStates().entrySet()) {
            if (fromState.equals(e.getKey()) && !e.getValue().contains(toState)) {
                throw new SberxException(SberxErrors.TRANSITION_STATE_NOT_AVAILABLE,
                        String.format("Переход из состояния %s в состояние %s не доступно",
                                fromState, toState));
            }
        }
    }

    private UpdatedMainQuestionnaire updateMainQuestionnaire(Questionnaire childQuestionnaire) {
        Long childQuestionnaireId = childQuestionnaire.getQuestionnaireId();
        if (childQuestionnaire.getParentId() == null)
            return new UpdatedMainQuestionnaire(childQuestionnaireId, false);
        Questionnaire mainQuestionnaire = questionnaireRepository.findByQuestionnaireId(
                childQuestionnaire.getParentId());
        if (mainQuestionnaire == null)
            return new UpdatedMainQuestionnaire(childQuestionnaireId, false);

        Long mainQuestionnaireId = mainQuestionnaire.getQuestionnaireId();
        Questionnaire updatedMainQuestionnaire = childQuestionnaire.toBuilder()
                .questionnaireId(mainQuestionnaireId)
                .parentId(null)
                .build();
        questionnaireRepository.save(updatedMainQuestionnaire);
        questionnaireRepository.deleteByQuestionnaireId(childQuestionnaireId);

        List<QuestionnaireLocaleDao> questionnaireLocaleList = questionnaireLocaleDaoRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(questionnaireLocaleList)) {
            questionnaireLocaleDaoRepository.deleteByQuestionnaireIdAndLangIn(mainQuestionnaireId,
                    questionnaireLocaleList.stream().map(QuestionnaireLocaleDao::getLang).collect(Collectors.toList()));
            questionnaireLocaleDaoRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<ApplicationDao> apps = applicationRepository.findByQuestionnaireId(
                childQuestionnaireId);
        if (!CollectionUtils.isEmpty(apps)) {
            applicationRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            applicationRepository.updateMainQuestionnaire(mainQuestionnaireId,
                    childQuestionnaireId);
        }

        List<CommunityUser> comms = communityUserRepository.findByQuestionnaireId(
                childQuestionnaireId);
        if (!CollectionUtils.isEmpty(comms)) {
            communityUserRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            communityUserRepository.updateMainQuestionnaire(mainQuestionnaireId,
                    childQuestionnaireId);
        }

        List<Contact> contacts = contactRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(contacts)) {
            contactRepository.deleteByQuestionnaireIdAndLangIn(mainQuestionnaireId,
                    contacts.stream().map(Contact::getLang).collect(Collectors.toList()));
            contactRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<Feedback> feedbacks = feedbackRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(feedbacks)) {
            feedbackRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            feedbackRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<Founder> founders = founderRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(founders)) {
            founderRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            founderRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<InvestmentClub> invs = investmentClubRepository.findByQuestionnaireId(
                childQuestionnaireId);
        if (!CollectionUtils.isEmpty(invs)) {
            investmentClubRepository.deleteById(mainQuestionnaireId);
            investmentClubRepository.updateMainQuestionnaire(mainQuestionnaireId,
                    childQuestionnaireId);
        }

        List<Pilot> pilots = pilotRepository.findByQuestionnaireIdIn(List.of(childQuestionnaireId));
        if (!CollectionUtils.isEmpty(pilots)) {
            List<PilotLocalDao> newPilotLocalList = pilotLocalDaoRepository.findByPilotIdIn(pilots.stream().map(Pilot::getPilotId).collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(newPilotLocalList))
                pilotLocalDaoRepository.deleteByQuestionnaireIdAndLang(mainQuestionnaire.getQuestionnaireId(), newPilotLocalList.stream().map(PilotLocalDao::getLang).collect(Collectors.toList()));
            pilotRepository.deleteByQuestionnaireIdAndNotExistsLocal(mainQuestionnaireId);
            pilotRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<Project> projects = projectRepository.findByQuestionnaireIdIn(
                List.of(childQuestionnaireId));
        if (!CollectionUtils.isEmpty(projects)) {
            List<ProjectLocaleDao> newProjectLocaleList = projectLocaleDaoRepository.findByProjectIdIn(projects.stream().map(Project::getProjectId).collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(newProjectLocaleList))
                projectLocaleDaoRepository.deleteByQuestionnaireIdAndLang(mainQuestionnaire.getQuestionnaireId(), newProjectLocaleList.stream().map(ProjectLocaleDao::getLang).collect(Collectors.toList()));
            projectLocaleDaoRepository.updateProjectId(mainQuestionnaireId, projects.get(0).getProjectId());
            projectRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            projectRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        Representative rep = representativeRepository.findByQuestionnaireId(childQuestionnaireId);
        if (rep != null) {
            representativeRepository.deleteById(mainQuestionnaireId);
            representativeRepository.updateMainQuestionnaire(mainQuestionnaireId,
                    childQuestionnaireId);
        }

        List<UserQuestionnaire> usrs = userQuestionnaireRepository.findByQuestionnaireId(
                childQuestionnaireId);
        if (!CollectionUtils.isEmpty(usrs)) {
            userQuestionnaireRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            userQuestionnaireRepository.updateMainQuestionnaire(mainQuestionnaireId,
                    childQuestionnaireId);
        }

        List<Worker> workers = workerRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(workers)) {
            workerRepository.deleteByQuestionnaireIdAndLangIn(mainQuestionnaireId, workers.stream().map(Worker::getLang).collect(Collectors.toList()));
            workerRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        Investment investment = investmentRepository.findByQuestionnaireId(childQuestionnaireId);
        if (investment != null) {
            investmentRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            investmentRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<InvestmentLocaleDao> investmentLocaleList = investmentLocaleDaoRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(investmentLocaleList)) {
            investmentLocaleDaoRepository.deleteByQuestionnaireIdAndLangIn(mainQuestionnaireId,
                    investmentLocaleList.stream().map(InvestmentLocaleDao::getLang).collect(Collectors.toList()));
            investmentLocaleDaoRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        SberFiveHundred sberFiveHundred = sberFiveHundredRepository.findByQuestionnaireId(childQuestionnaireId);
        if (sberFiveHundred != null) {
            sberFiveHundredRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            sberFiveHundredRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        ImportReplaceDAO importReplaceDAO = importReplaceDAORepository.findByQuestionnaireId(childQuestionnaireId);
        if (importReplaceDAO != null) {
            importReplaceDAORepository.deleteByQuestionnaireId(mainQuestionnaireId);
            importReplaceDAORepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<ImportReplaceLangDao> importReplaceLangList = importReplaceLangDaoRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(importReplaceLangList)) {
            importReplaceLangDaoRepository.deleteByQuestionnaireIdAndLangIn(mainQuestionnaireId,
                    importReplaceLangList.stream().map(ImportReplaceLangDao::getLang).collect(Collectors.toList()));
            importReplaceLangDaoRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }

        List<QuestionnaireFunds> questionnaireFunds = questionnaireFundsRepository.findByQuestionnaireId(childQuestionnaireId);
        if (!CollectionUtils.isEmpty(questionnaireFunds)) {
            questionnaireFundsRepository.deleteByQuestionnaireId(mainQuestionnaireId);
            questionnaireFundsRepository.updateMainQuestionnaire(mainQuestionnaireId, childQuestionnaireId);
        }
        TariffDto childTariff = tariffService.get(null, ADMINISTRATOR_ROLE, childQuestionnaireId, null, true);
        TariffDto mainTariff = tariffService.get(null, ADMINISTRATOR_ROLE, mainQuestionnaireId, null, true);
        Boolean changedRole = false;
        if (childTariff != null && StringUtils.hasText(childTariff.getSysname())
                && mainTariff != null && !childTariff.getSysname().equals(mainTariff.getSysname())) {
            PostTariffReq tariffReq = new PostTariffReq();
            tariffReq.setQuestionnaireId(mainQuestionnaireId);
            tariffReq.setSysname(childTariff.getSysname());
            tariffReq.setRole(ADMINISTRATOR_ROLE);
            DefaultRes defaultRes = tariffService.post(tariffReq);
            changedRole = defaultRes.getIsChangedRole();
            tariffService.deleteByQuestionnaireId(childQuestionnaireId);
        }
        return new UpdatedMainQuestionnaire(mainQuestionnaireId, changedRole);
    }

    private String newTypeVal(Integer type) {
        Integer tp = type != null ? type : 0;
        return tp.equals(1) ? "корпорации" : (tp.equals(2) ? "инвестора" : "стартапа");
    }

    private void setUpdateDateForSort(Questionnaire questionnaire) {
        Date date = questionnaire.getUpdateDateForSort() == null ? (questionnaire.getModified() == null ? questionnaire.getCreated() : questionnaire.getModified()) : questionnaire.getUpdateDateForSort();
        ZonedDateTime dateDb = ZonedDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        ZonedDateTime nowDate = ZonedDateTime.now();
        if (Duration.between(dateDb, nowDate).toDays() > this.updateDateForSort) {
            questionnaire.setUpdateDateForSort(Date.from(nowDate.toInstant()));
        }
        if (questionnaire.getUpdateDateForSort() == null)
            questionnaire.setUpdateDateForSort(Date.from(nowDate.toInstant()));
    }

    @Data
    @AllArgsConstructor
    public static class UpdatedMainQuestionnaire {
        private Long mainQuestionnaireId;
        private Boolean changedRole;
    }
}
