package ru.sberx.questionary.controller.dto.res;

import lombok.Data;

@Data
public class DeleteQuestionnaireRes {
    private String fullName;
    private Long userId;
}
