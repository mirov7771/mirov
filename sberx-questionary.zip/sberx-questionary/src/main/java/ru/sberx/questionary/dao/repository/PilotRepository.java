package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.custom.CustomRepository;
import ru.sberx.questionary.dao.model.Pilot;

import javax.transaction.Transactional;
import java.util.List;
import java.util.UUID;

@Repository
public interface PilotRepository extends CrudRepository<Pilot, Long>, CustomRepository {
    List<Pilot> findByQuestionnaireIdAndIsDisabled(Long questionnaireId, Boolean isDisabled);
    List<Pilot> findByQuestionnaireIdIn(List<Long> questionnaireIds);

    Pilot findByPilotIdAndIsDisabled(Long pilotId, Boolean isDisabled);

    Pilot findByPilotId(Long pilotId);

    List<Pilot> findByQuestionnaireIdAndIsB2C(Long questionnaireId, Boolean isB2C);

    List<Pilot> findByQuestionnaireIdAndIsB2B(Long questionnaireId, Boolean isB2B);

    List<Pilot> findByQuestionnaireIdAndIsSuccess(Long questionnaireId, Boolean isSuccess);

    List<Pilot> findByQuestionnaireIdInAndIsSuccess(List<Long> questionnaireIds, Boolean isSuccess);

    List<Pilot> findByQuestionnaireIdAndIsQuestionnaire(Long questionnaireId, Boolean isQuestionnaire);

    List<Pilot> findByQuestionnaireIdAndEcoSystem(Long questionnaireId, Boolean ecoSystem);

    @Modifying
    @Transactional
    @Query("update Pilot set referenceState = 20001 where companyUid = :companyUid")
    void updateByCompanyUid(UUID companyUid);

    @Query(value = "select distinct on (questionnaireid) * from pilot"
            + " where questionnaireid in :questionnaireIds and isdisabled = false and ecosystem = true", nativeQuery = true)
    List<Pilot> findByQuestionnaireIdAndIsDisabledAndEcoSystem(List<Long> questionnaireIds);

    @Query(value = "delete from pilot p " +
            "where p.QUESTIONNAIREID = :questionnaireId " +
            " and (p.ISQUESTIONNAIRE = true " +
            "or p.ISSUCCESS = true " +
            "or p.ISB2C = true " +
            "or p.ISB2B = true " +
            "or p.ECOSYSTEM = true)",
            nativeQuery = true)
    @Modifying
    @Transactional
    void deletePilotsByQuestionnaireId(@Param("questionnaireId") Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Pilot set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    @Query(value = "delete from pilot p where p.QUESTIONNAIREID = :questionnaireId and p.ishub != true", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(@Param("questionnaireId") Long questionnaireId);

    @Query(value = "select p.* from user_questionnaire uq inner join pilot p on p.questionnaireid = uq.questionnaireid and p.state = 20004 where userid = :userId limit 1000", nativeQuery = true)
    List<Pilot> findByUserId(@Param("userId") Long userId);

    @Query(value = "select p.* from pilot p where p.questionnaireid = :id and p.state = 20004 limit 1000", nativeQuery = true)
    List<Pilot> findByQuestionnaireId(@Param("id") Long id);

    @Query(value = "select p.* from pilot p where p.questionnaireid = :id and p.state = 20004 and p.ishub = true limit 5", nativeQuery = true)
    List<Pilot> findHubPilots(@Param("id") Long id);

    @Query(value = "delete from pilot p where p.questionnaireid = :questionnaireId and (select 1 from pilot_local pl where pl.pilotid = p.pilotid) is null ", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndNotExistsLocal(Long questionnaireId);
}
