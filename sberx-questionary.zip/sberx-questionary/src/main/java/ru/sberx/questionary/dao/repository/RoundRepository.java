package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.RoundDao;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface RoundRepository extends CrudRepository<RoundDao, Long> {

    Optional<RoundDao> findByRoundId(Long id);
    List<RoundDao> findAllByInvestmentFalse();
    List<RoundDao> findAllByInvestmentTrue();
    List<RoundDao> findByQuestionnaireId(Long questionnaireId);
    List<RoundDao> findByQuestionnaireIdAndState(Long questionnaireId, Integer state);
    @Query(value = "select * from round r where end_date < current_date and state != 20013", nativeQuery = true)
    List<RoundDao> findEndedRounds();

    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);
}
