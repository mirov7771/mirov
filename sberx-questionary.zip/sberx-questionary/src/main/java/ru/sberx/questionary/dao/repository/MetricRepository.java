package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.MetricDao;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

@Repository
public interface MetricRepository extends CrudRepository<MetricDao, Long> {
    List<MetricDao> findByQuestionnaireIdAndActive(Long questionnaireId, Boolean active);
    List<MetricDao> findByQuestionnaireIdAndDateBetweenAndActiveTrueOrderByDateDesc(Long questionnaireId, Date beginDate, Date endDate);
    List<MetricDao> findByQuestionnaireIdAndTypeAndDateBetweenAndActiveTrueOrderByDateDesc(Long questionnaireId, Long type, Date beginDate, Date endDate);
    List<MetricDao> findByQuestionnaireIdAndDateAndType(Long questionnaireId, Date date, Long type);
    List<MetricDao> findByQuestionnaireIdAndDateAndTypeAndActive(Long questionnaireId, Date date, Long type, Boolean active);

    @Modifying
    @Transactional
    @Query(value = "update metric set active = false where questionnaireid = :questionnaireId and type = :metric", nativeQuery = true)
    void updateActive(Long questionnaireId, Integer metric);

    @Modifying
    @Transactional
    @Query(value = "update metric set active = false where questionnaireid = :questionnaireId and type = :type and date not in :date", nativeQuery = true)
    void updateActiveByQuestionnaireAndTypeAndDateNotIn(Long questionnaireId, Long type, List<Date> date);
}
