package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.pkey.ProjectLangPKey;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "PROJECT_LOCAL")
@IdClass(ProjectLangPKey.class)
@Data
@NoArgsConstructor
public class ProjectLocaleDao implements Serializable {

    private static final long serialVersionUID = 1382553269252271004L;

    @Id
    @Column(name = "PROJECTID")
    private Long projectId;
    @Id
    @Column(name = "LANG")
    private String lang;
    @Column(name = "NOTE")
    private String note;
    @Column(name = "DEMOVIDEO")
    private String demoVideo;
    @Column(name = "PROBLEM")
    private String problem;
    @Column(name = "AUDITORY")
    private String auditory;
    @Column(name = "COMPETITOR")
    private String competitor;
    @Column(name = "UPSIDE")
    private String upSide;
}
