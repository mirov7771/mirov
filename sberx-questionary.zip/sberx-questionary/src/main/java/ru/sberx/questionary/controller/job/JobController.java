package ru.sberx.questionary.controller.job;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.questionary.job.JobService;

@RestController
@RequestMapping("${spring.application.name}/job")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;

    @GetMapping("end/rounds")
    public void closeEndedRounds() {
        jobService.closeEndedRounds();
    }

    @GetMapping("new/reply")
    public void newReply() {
        jobService.newReplyDays();
    }

    @GetMapping("recommend")
    public void recommend() {
        jobService.sendRecommendNotify();
    }

}
