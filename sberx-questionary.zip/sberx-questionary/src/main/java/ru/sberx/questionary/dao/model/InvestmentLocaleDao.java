package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.pkey.QuestionnaireLangPKey;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "INVESTMENT_LOCAL")
@IdClass(QuestionnaireLangPKey.class)
@Data
@NoArgsConstructor
public class InvestmentLocaleDao implements Serializable {

    private static final long serialVersionUID = 4590402737975744953L;

    @Id
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Id
    @Column(name = "LANG")
    private String lang;
    @Column(name = "BUSINESSPLAN")
    private String businessPlan;
    @Column(name = "INVESTMENT")
    private Boolean investment;
    @Column(name = "LASTINVESTMENT")
    private String lastInvestment;
    @Column(name = "COINVESTMENT")
    private String coInvestment;
}
