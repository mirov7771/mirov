package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "WORKER")
@Data
public class Worker implements Serializable {

    private static final long serialVersionUID = 172834369646656016L;

    @Id
    @Column(name = "WORKERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long workerId;
    @Column(name = "ROLE")
    private String role;
    @Column(name = "AGE")
    private Integer age;
    @Column(name = "NOTE")
    private String note;
    @Column(name = "PERCENTAGE")
    private Float percentage;
    @Column(name = "FIO")
    private String fio;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "PARENTID")
    private Long parentId;
    @Column(name = "ISFOUNDER")
    private Boolean isFounder;
    @Column(name = "FACEBOOK")
    private String facebook;
    @Column(name = "LANG")
    private String lang;

    public ru.sberx.questionary.controller.dto.support.Worker toDto() {
        ru.sberx.questionary.controller.dto.support.Worker worker = new ru.sberx.questionary.controller.dto.support.Worker();
        worker.setWorkerId(this.workerId);
        worker.setRole(this.role);
        worker.setAge(this.age);
        worker.setNote(this.note);
        worker.setPercentage(this.percentage);
        worker.setFio(this.fio);
        worker.setIsFounder(this.isFounder);
        worker.setFacebook(this.facebook);
        return worker;
    }
}
