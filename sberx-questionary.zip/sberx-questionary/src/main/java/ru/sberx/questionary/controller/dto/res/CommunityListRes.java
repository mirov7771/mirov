package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.controller.dto.support.Community;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CommunityListRes {
    private List<Community> list;
    private Integer rowCount;
    private Integer totalRowCount;
    private Integer nextPageToken;
}
