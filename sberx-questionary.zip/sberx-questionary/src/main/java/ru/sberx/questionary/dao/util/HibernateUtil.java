package ru.sberx.questionary.dao.util;

import org.hibernate.SessionFactory;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

@Component
public class HibernateUtil {

    @PersistenceUnit
    private EntityManagerFactory entityManagerFactory;

    public SessionFactory getHibernateSession(){
        return entityManagerFactory.unwrap(SessionFactory.class);
    }
}
