package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Contact {

    private Long contactId;
    @NotNull
    private Long type;
    @NotNull
    private String name;
    @NotNull
    private String value;
    private Boolean isDisabled;
    private Long parentId;
    private String lang;

}
