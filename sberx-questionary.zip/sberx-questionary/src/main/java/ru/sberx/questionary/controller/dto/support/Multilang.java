package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Multilang {

    private String lang;
    private FieldDto fields;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class FieldDto {
        private String name;
        private String suggestCase;
        private String businessUnit;
        private String demoFile;
        private List<Response> response;

        private String otherDescription;
        private String startupName;
        private String result;
        private String leadName;
        private String roundInfo;
        private String inviteFio;
        private String phone;
        private String email;
        private String presentation;
        private String logoFile;
    }
}

