package ru.sberx.questionary.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.RecommendCoefficient;

import javax.annotation.Nonnull;
import java.util.List;

@Repository
public interface RecommendCoefficientRepository extends CrudRepository<RecommendCoefficient, String> {
    @Override
    @Nonnull
    List<RecommendCoefficient> findAll();
}
