package ru.sberx.questionary.controller.dto.req;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class RoundListReq {
    private Long questionnaireId;
    private Boolean investment;
    private Integer rowCount;
    private Integer pageToken;
    private List<Long> state;
    private String name;
    private Boolean admin;
    private String sessionId;
    private Boolean favorite;
    private Long qId;
    private String sortBy;
    private String orderBy;

    public RoundListReq(List<Long> state, Boolean investment){
        this.state = state;
        this.investment = investment;
    }
}
