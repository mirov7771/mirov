package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Response;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ResponseRepository extends CrudRepository<Response, String> {

    @Transactional
    @Modifying
    @Query(value = "delete from response where pilotid = :pilotId and lang = :lang", nativeQuery = true)
    void deleteByPilotIdAndLang(Long pilotId, String lang);
}
