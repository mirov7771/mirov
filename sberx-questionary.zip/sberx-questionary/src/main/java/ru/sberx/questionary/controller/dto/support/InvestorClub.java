package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.InvestmentClub;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class InvestorClub {

    private Long investmentClubId;
    private Long questionnaireId;
    private Long userId;
    private String name;
    private String role;

    public InvestorClub(InvestmentClub club){
        this.investmentClubId = club.getInvestmentClubId();
        this.questionnaireId = club.getQuestionnaireId();
        this.userId = club.getUserId();
        this.name = club.getName();
        this.role = club.getRole();
    }

}
