package ru.sberx.questionary.controller.dto.res;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class QuestionnaireGuidListRes {
    private List<QuestionnaireUIDRes> list;
}
