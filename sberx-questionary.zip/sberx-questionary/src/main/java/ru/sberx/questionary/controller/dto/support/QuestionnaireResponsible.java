package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class QuestionnaireResponsible {

    private Long questionnaireId;
    private Long responsibleId;
    private String responsibleLogin;
}
