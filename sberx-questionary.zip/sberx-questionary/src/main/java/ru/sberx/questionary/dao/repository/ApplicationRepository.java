package ru.sberx.questionary.dao.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.ApplicationDao;

@Repository
public interface ApplicationRepository extends JpaRepository<ApplicationDao, Long> {
    @Modifying
    @Transactional
    @Query("delete from QuestionnaireLocaleDao where questionnaireId = :questionnaireId")
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update ApplicationDao set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
    List<ApplicationDao> findByQuestionnaireId(Long questionnaireId);

    Optional<ApplicationDao> findByUid(String uid);

    @Modifying
    @Transactional
    @Query("update ApplicationDao set uid = null, notificationDttm = null where notificationDttm < :expiredDate")
    void updateExpiredApplications(Date expiredDate);

    Optional<ApplicationDao> findByEmail(String email);
    Optional<ApplicationDao> findByLogin(String login);

}
