package ru.sberx.questionary.dao.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ROUND_LOCAL")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoundLocal implements Serializable {

    private static final long serialVersionUID = 8044624001631017090L;

    @EmbeddedId
    private RoundLocalCompositeKey roundIdLang;

    @Column(name = "INVESTMENT_PURPOSE")
    private String investmentPurpose;

    @Column(name = "OTHER_DESCRIPTION")
    private String otherDescription;

    @Column(name = "RESULT")
    private String result;

    @Column(name = "LEAD_NAME")
    private String leadName;

    @Column(name = "ROUND_INFO")
    private String roundInfo;

    @Column(name = "PRESENTATION")
    private String presentation;

    @Column(name = "INVITE_FIO")
    private String inviteFio;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "PHONE")
    private String phone;

    @Embeddable
    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public static class RoundLocalCompositeKey implements Serializable {
        @Column(name = "ROUND_ID")
        private Long roundId;

        @Column(name = "LANG")
        private String lang;
    }
}
