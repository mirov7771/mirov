package ru.sberx.questionary.controller.reply.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class ReplyListReq {
    private List<Long> id;
    private Long userId;
    private String name;
    private String schema;
    private String locale;
    private String sortBy;
    private String orderBy;
    private Boolean isPilotOffer;
    private Boolean view;
    private Integer rowCount;
    private Integer pageToken;
    private String role;
    private List<Long> state;
    private Integer type;
}
