package ru.sberx.questionary.controller.comment.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CommentGetRes {
    private List<CommentDTO> comments;
}
