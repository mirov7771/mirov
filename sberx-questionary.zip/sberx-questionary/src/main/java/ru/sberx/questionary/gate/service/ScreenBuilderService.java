package ru.sberx.questionary.gate.service;

import ru.sberx.questionary.gate.dto.GetPopupRes;

import java.util.List;

public interface ScreenBuilderService {

    List<GetPopupRes> getPopup(List<String> status, String locale);
}
