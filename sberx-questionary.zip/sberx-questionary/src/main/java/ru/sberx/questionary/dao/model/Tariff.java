package ru.sberx.questionary.dao.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "TARIFF")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Tariff implements Serializable {

    private static final long serialVersionUID = 6737587513597016845L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "QUESTIONNAIRE_UUID")
    private String questionnaireUuid;
    @Column(name = "SYSNAME")
    private String sysName;
    @Column(name = "STATE")
    private String state;
    @Column(name = "CREATE_DTTM")
    private Date createDttm;
    @Column(name = "END_DTTM")
    private Date endDttm;
    @Column(name = "REQUESTED_USERID")
    private Long requestedUserId;
    @Column(name = "VALIDATED_USERID")
    private Long validatedUserId;
    @Column(name = "PARENT_ID")
    private Long parentId;

    public Tariff(Long questionnaireId, String questionnaireUuid, String sysName, String state, Date createDttm, Date endDttm, Long requestedUserId, Long validatedUserId, Long parentId) {
        this.questionnaireId = questionnaireId;
        this.questionnaireUuid = questionnaireUuid;
        this.sysName = sysName;
        this.state = state;
        this.createDttm = createDttm;
        this.endDttm = endDttm;
        this.requestedUserId = requestedUserId;
        this.validatedUserId = validatedUserId;
        this.parentId = parentId;
    }
}
