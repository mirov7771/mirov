package ru.sberx.questionary.controller.dto.req;

import lombok.Data;
import ru.sberx.questionary.controller.dto.support.ImportReplaceDTO;
import ru.sberx.questionary.controller.dto.support.Questionnaire;

import java.util.List;

@Data
public class QuestionnaireUpdateReq {
    private Long questionnaireId;
    private String isMarketing;
    private ImportReplaceDTO importReplace;
    private List<ImportReplaceDTO.ImportReplaceItemsDTO> importItems;
    private Questionnaire questionnaire;
}
