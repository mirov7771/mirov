package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.UserQuestionnaire;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface UserQuestionnaireRepository extends CrudRepository<UserQuestionnaire, String> {

    List<UserQuestionnaire> findByQuestionnaireIdIn(List<Long> questionnaireIds);
    List<UserQuestionnaire> findByQuestionnaireId(Long questionnaireId);
    List<UserQuestionnaire> findByUserId(Long userId);
    UserQuestionnaire findFirstByQuestionnaireId(Long questionnaireId);
    UserQuestionnaire findFirstByUserId(Long userId);
    UserQuestionnaire findFirstByUserIdOrEmail(Long userId, String email);

    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update UserQuestionnaire set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    @Modifying
    @Transactional
    @Query(value = "update QUESTIONNAIRE set LAST_ENTER = current_timestamp where QUESTIONNAIREID in (:ids)", nativeQuery = true)
    void updateLastEnter(List<Long> ids);
}
