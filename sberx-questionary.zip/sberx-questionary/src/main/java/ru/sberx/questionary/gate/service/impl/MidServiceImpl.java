package ru.sberx.questionary.gate.service.impl;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import ru.sberx.questionary.gate.client.RestGate;
import ru.sberx.questionary.gate.dto.Notice;
import ru.sberx.questionary.gate.service.MidService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class MidServiceImpl implements MidService {

    private final RestGate restGate;
    @Value("${application.mid.url}")
    private String midUrl;
    @Value("${application.mid.notify}")
    private String notifyPath;

    @Override
    public void notify(String sysName,
                       Map<String, Object> params,
                       String receiver,
                       Long userId,
                       String event,
                       String deeplink,
                       Long toUserId,
                       Integer type) {
        JsonObject json = new JsonObject();
        Gson gson = new Gson();
        json.addProperty("receiver", receiver);
        callNotify(sysName, params, json, gson, toUserId, type);

        //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
        try {
            if (userId != null) {
                Notice noticeReq = new Notice();
                noticeReq.setTemplateSysName(sysName);
                noticeReq.setParams(params);
                noticeReq.setUserId(userId);
                noticeReq.setEvent(event);
                noticeReq.setDeeplink(deeplink);
                notice(noticeReq);
            }
        } catch (Exception e) {
            log.error("Notice error ", e);
        }
    }

    @Override
    public void notify(String sysName, Map<String, Object> params, String receiver) {
        JsonObject json = new JsonObject();
        Gson gson = new Gson();
        json.addProperty("receiver", gson.toJson(receiver));
        callNotify(sysName, params, json, gson, null, null);
    }

    private void callNotify(String sysName, Map<String, Object> params, JsonObject json, Gson gson, Long userId, Integer type) {
        json.addProperty("sysName", sysName);
        json.addProperty("type", "EMAIL");
        json.add("params", gson.toJsonTree(params));
        Map<String, String> headers = new HashMap<>();
        headers.put("requestId", ThreadContext.get("requestId"));
        headers.put("client-id", ThreadContext.get("requestId"));
        if (userId != null)
            headers.put("user-id", String.valueOf(userId));
        if (type != null)
            headers.put("type-id", String.valueOf(type));
        try {
            restGate.call(Void.class,
                    midUrl,
                    notifyPath,
                    json.toString(),
                    HttpMethod.POST,
                    headers,
                    MediaType.APPLICATION_JSON
            );
        } catch (Exception e) {
            log.error("Notify error: ", e);
        }
    }

    @Override
    public Notice notice(Notice req) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("requestId", String.valueOf(req.getSendUserId()));
        headers.set("client-id", String.valueOf(req.getSendUserId()));
        if (req.getSendUserId() != null)
            headers.set("send-user-id", String.valueOf(req.getSendUserId()));
        if (req.getUserId() != null)
            headers.set("user-id", String.valueOf(req.getUserId()));
        return restGate.call(new ParameterizedTypeReference<Notice>() {},
                midUrl,
                "/notice",
                null,
                req,
                HttpMethod.POST,
                headers,
                MediaType.APPLICATION_JSON);
    }

}
