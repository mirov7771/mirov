package ru.sberx.questionary.dao.model;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Table(name = "object_action")
@Entity
@Getter
@Setter
@NoArgsConstructor
public class ObjectAction implements Serializable {

    private static final long serialVersionUID = -5447025813925534881L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @Column(name = "object_id")
    private Long objectId;
    @Column(name = "object_type")
    private String objectType;
    @Column(name = "action")
    private String action;
    @Column(name = "user_id")
    private Long userId;
    @Column(name = "CREATED")
    private Date created;

    public ObjectAction(Long objectId, String objectType, String action, Long userId) {
        this.objectId = objectId;
        this.objectType = objectType;
        this.action = action;
        this.userId = userId;
        this.created = new Date();
    }
}
