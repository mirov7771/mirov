package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.MetricSettings;

import javax.transaction.Transactional;

@Repository
public interface MetricSettingsRepository extends CrudRepository<MetricSettings, Long> {
    MetricSettings findByQuestionnaireIdAndTypeId(Long questionnaireId, Long typeId);

    @Transactional
    @Modifying
    @Query(value = "delete from metric_settings where questionnaire_id = :questionnaireId and type_id = :metric", nativeQuery = true)
    void deleteByQuestionnaireAndType(Long questionnaireId, Integer metric);
}
