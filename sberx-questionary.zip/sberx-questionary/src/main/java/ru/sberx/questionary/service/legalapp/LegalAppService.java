package ru.sberx.questionary.service.legalapp;

import ru.sberx.questionary.controller.lagalapp.req.PostLegalAppReq;

public interface LegalAppService {
    void post(PostLegalAppReq req);
}
