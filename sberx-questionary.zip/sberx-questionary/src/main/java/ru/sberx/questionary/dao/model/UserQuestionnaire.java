package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "USER_QUESTIONNAIRE")
@Data
public class UserQuestionnaire implements Serializable {

    private static final long serialVersionUID = 1652979364892707488L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "SBERBUSINESSID")
    private String sberBusinessId;
    @Column(name = "ISBRAN")
    private Boolean isBran;
    @Column(name = "SBERFH")
    private Boolean sberFh;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "PHONENUMBER")
    private String phoneNumber;
    @Column(name = "NAME")
    private String name;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "LAST_NAME")
    private String lastName;
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Column(name = "POSITION")
    private String position;

}
