package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

@Data
public class AddFavoriteReq {
    private Long id;
    private Boolean favorite;
    private String sessionId;
    private String objectType;
}
