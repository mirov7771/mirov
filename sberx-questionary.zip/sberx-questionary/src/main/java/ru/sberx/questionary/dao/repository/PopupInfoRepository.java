package ru.sberx.questionary.dao.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.PopupInfoDao;

@Repository
public interface PopupInfoRepository extends CrudRepository<PopupInfoDao, Long> {
    List<PopupInfoDao> findByQuestionnaireIdAndWatched(Long questionnaireId, Boolean watched);
    List<PopupInfoDao> findByQuestionnaireIdAndStatus(Long questionnaireId, String status);
    List<PopupInfoDao> findByQuestionnaireIdAndStatusAndUserId(Long questionnaireId, String status, Long userId);

    @Transactional
    @Modifying
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update PopupInfoDao set watched = true where questionnaireId = :questionnaireId and watched = false")
    void updatePopupByQuestionnaireIdWhereWatchedIsFalse(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update PopupInfoDao set watched = true where questionnaireId = :questionnaireId and watched = false and status = :status")
    void updatePopupByQuestionnaireIdWhereWatchedIsFalseAndStatus(Long questionnaireId, String status);
}
