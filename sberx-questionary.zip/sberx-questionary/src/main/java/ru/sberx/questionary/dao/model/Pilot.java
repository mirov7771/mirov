package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import com.vladmihalcea.hibernate.type.array.StringArrayType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "PILOT")
@Data
@TypeDefs({
        @TypeDef(name = "string-array", typeClass = StringArrayType.class),
        @TypeDef(name = "long-array", typeClass = LongArrayType.class)
})
public class Pilot implements Serializable {

    private static final long serialVersionUID = -6541146556582047015L;

    @Id
    @Column(name = "PILOTID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pilotId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "PILOT")
    private Boolean pilot;
    @Column(name = "SUGGESTCASE")
    private String suggestCase;
    @Column(name = "EXPERIENCE")
    private Boolean experience;
    @Column(name = "BUSINESSUNIT")
    private String businessUnit;
    @Column(name = "REFERENCE")
    private String reference;
    @Column(name = "DEPARTMENT")
    private String department;
    @Column(name = "CONDITIONS")
    private String conditions;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "NAME")
    private String name;
    @Column(name = "FILE")
    private Boolean file;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "ISBRAN")
    private Boolean isBran;
    @Column(name = "TARGET")
    private Long target;
    @Column(name = "RELEVANCE")
    private Integer relevance;
    @Column(name = "EFFECT")
    private Long effect;
    @Column(name = "RESOURCES")
    private Long resources;
    @Column(name = "SEARCH")
    private Boolean search;
    @Column(name = "DEADLINE")
    private Date deadLine;
    @Column(name = "EXP")
    private Long exp;
    @Column(name = "COMPANY")
    private String company;
    @Column(name = "DECISION")
    private String decision;
    @Column(name = "ISFOREIGN")
    private Boolean isForeign;
    @Column(name = "DECISION_COMPANY")
    private String decisionCompany;
    @Column(name = "ISHUB")
    private Boolean isHub;
    @Type(type = "long-array")
    @Column(name = "INDUSTRY")
    private long[] industry;
    @Column(name = "TARGETOPTION")
    private String targetOption;
    @Column(name = "ISPUBLISHED")
    private Boolean isPublished;
    @Column(name = "CREATORID")
    private Long creatorId;
    @Column(name = "ECOSYSTEM")
    private Boolean ecoSystem;
    @Column(name = "ISB2B")
    private Boolean isB2B;
    @Column(name = "ISB2C")
    private Boolean isB2C;
    @Column(name = "ISSUCCESS")
    private Boolean isSuccess;
    @Column(name = "ISQUESTIONNAIRE")
    private Boolean isQuestionnaire;
    @Column(name = "SITE")
    private String site;
    @Column(name = "DEMOFILE")
    private String demoFile;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "COMPANY_UID")
    private UUID companyUid;
    @Column(name = "REFERENCE_STATE")
    private Long referenceState;

    public PilotDTO toDto() {
        PilotDTO pilot = new PilotDTO();
        pilot.setPilotId(this.pilotId);
        pilot.setPilot(this.pilot);
        pilot.setQuestionnaireId(this.questionnaireId);
        pilot.setExperience(this.experience);
        pilot.setName(this.name);
        pilot.setConditions(this.conditions);
        pilot.setBusinessUnit(this.businessUnit);
        pilot.setSuggestCase(this.suggestCase);
        pilot.setFile(this.file);
        pilot.setIndustry(this.industry);
        pilot.setTarget(this.target);
        pilot.setRelevance(this.relevance);
        pilot.setEffect(this.effect);
        pilot.setResources(this.resources);
        pilot.setSearch(this.search);
        pilot.setDeadLine(this.deadLine);
        pilot.setExp(this.exp);
        pilot.setCompany(this.company);
        pilot.setDecisionCompany(this.decisionCompany);
        pilot.setIsHub(this.isHub);
        pilot.setReference(this.reference);
        pilot.setDepartment(this.department);
        pilot.setIsDisabled(this.isDisabled);
        pilot.setState(this.state);
        pilot.setIsBran(this.isBran);
        pilot.setDecision(this.decision);
        pilot.setIsForeign(this.isForeign);
        pilot.setTargetOption(this.targetOption);
        pilot.setIsPublished(this.isPublished);
        pilot.setCreatorId(this.creatorId);
        pilot.setState(this.state);
        pilot.setPilot(this.pilot);
        pilot.setEcoSystem(this.ecoSystem);
        pilot.setIsB2B(this.isB2B);
        pilot.setIsB2C(this.isB2C);
        pilot.setIsSuccess(this.isSuccess);
        pilot.setIsQuestionnaire(this.isQuestionnaire);
        pilot.setSite(this.site);
        pilot.setDemoFile(this.demoFile);
        if (this.getState() != null) {
            pilot.setStateName(GuideService.getState(this.getState()));
        }
        pilot.setReplyStatus("3");
        return pilot;
    }

}
