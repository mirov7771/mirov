package ru.sberx.questionary.dao.model.pkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class PilotLangPKey implements Serializable {

    private static final long serialVersionUID = 1974156791329016104L;

    private Long pilotId;
    private String lang;
}
