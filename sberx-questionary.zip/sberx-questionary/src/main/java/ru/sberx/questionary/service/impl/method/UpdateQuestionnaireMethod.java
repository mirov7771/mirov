package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.guide.guide.req.SearchReq;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.QuestionnaireUpdateReq;
import ru.sberx.questionary.controller.dto.support.ImportReplaceDTO;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.util.GuideService;

import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Component
@RequiredArgsConstructor
public class UpdateQuestionnaireMethod {

    private final ru.sberx.questionary.gate.service.GuideService guideService;
    private final QuestionnaireRepository questionnaireRepository;
    private final ImportReplaceDAORepository importReplaceDAORepository;
    private final ProjectRepository projectRepository;
    private final InvestmentRepository investmentRepository;
    private final PilotRepository pilotRepository;
    private final WorkerRepository workerRepository;
    private final ContactRepository contactRepository;
    private final SberFiveHundredRepository sberFiveHundredRepository;
    private final RepresentativeRepository representativeRepository;
    private final InvestmentClubRepository investmentClubRepository;
    private final QuestionnaireFundsRepository questionnaireFundsRepository;

    public void execute(QuestionnaireUpdateReq req, String role) {
        if (role != null && role.equalsIgnoreCase("Administrator")) {
            updateImportReplaceName(req);
            return;
        }
        if (req.getIsMarketing() != null) {
            questionnaireRepository.updateMarketing(req.getQuestionnaireId(), req.getIsMarketing());
        } else if (req.getQuestionnaire() != null && req.getQuestionnaire().getIsImport() != null){
            Questionnaire questionnaire = questionnaireRepository.findByParentId(req.getQuestionnaireId());
            Long id = req.getQuestionnaireId();
            if (questionnaire != null && questionnaire.getQuestionnaireId() != null){
                id = questionnaire.getQuestionnaireId();
            } else {
                questionnaire = questionnaireRepository.findByQuestionnaireId(req.getQuestionnaireId());
                if (questionnaire != null && GuideService.CONFIRMED_STATE.equals(questionnaire.getState())) {
                    Questionnaire child = questionnaire.toBuilder()
                            .uuid(UUID.randomUUID())
                            .questionnaireId(null)
                            .parentId(req.getQuestionnaireId())
                            .state(GuideService.PROCESSING_STATE)
                            .created(new Date())
                            .modified(new Date())
                            .build();
                    questionnaireRepository.save(child);
                    Long finalId = child.getQuestionnaireId();
                    id = finalId;
                    CompletableFuture.runAsync(() -> createChild(req.getQuestionnaireId(), finalId));
                }
            }
            questionnaireRepository.updateImport(id, Boolean.TRUE.equals(req.getQuestionnaire().getIsImport()));
            if (Boolean.TRUE.equals(req.getQuestionnaire().getIsImport()) && req.getImportReplace() != null){
                ImportReplaceDAO dao = importReplaceDAORepository.findByQuestionnaireId(id);
                if (dao == null || dao.getQuestionnaireId() == null)
                    dao = new ImportReplaceDAO();
                dao.setQuestionnaireId(id);
                dao.setNote(req.getImportReplace().getNote());
                dao.setBenefits(req.getImportReplace().getBenefits());
                if (!CollectionUtils.isEmpty(req.getImportItems())){
                    dao.setName(req.getImportItems().stream().map(ImportReplaceDTO.ImportReplaceItemsDTO::getName).toArray(String[]::new));
                } else if (!CollectionUtils.isEmpty(req.getImportReplace().getName())){
                    dao.setName(req.getImportReplace().getName().toArray(String[]::new));
                }
                importReplaceDAORepository.save(dao);
            } else {
                importReplaceDAORepository.deleteByQuestionnaireId(id);
            }
        }
    }

    private void createChild(Long oldId, Long newId){
        List<Project> projects = projectRepository.findByQuestionnaireIdIn(List.of(oldId));
        List<Investment> investments = investmentRepository.findByQuestionnaireIdIn(List.of(oldId));
        List<Pilot> pilots = pilotRepository.findByQuestionnaireIdIn(List.of(oldId));
        List<Worker> workers = workerRepository.findByQuestionnaireIdIn(List.of(oldId));
        List<Contact> contacts = contactRepository.findByQuestionnaireId(oldId);
        SberFiveHundred sberFiveHundred = sberFiveHundredRepository.findByQuestionnaireId(oldId);
        List<Representative> representatives = representativeRepository.findByQuestionnaireIdIn(List.of(oldId));
        List<InvestmentClub> clubs = investmentClubRepository.findByQuestionnaireId(oldId);
        List<QuestionnaireFunds> funds = questionnaireFundsRepository.findByQuestionnaireId(oldId);
        ImportReplaceDAO importReplaceDAO = importReplaceDAORepository.findByQuestionnaireId(oldId);

        if (importReplaceDAO != null){
            importReplaceDAO.setQuestionnaireId(newId);
            importReplaceDAORepository.save(importReplaceDAO);
        }

        if (sberFiveHundred != null){
            sberFiveHundred.setQuestionnaireId(newId);
            sberFiveHundredRepository.save(sberFiveHundred);
        }
        if (!CollectionUtils.isEmpty(projects)){
            projects.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setProjectId(null);
            });
            projectRepository.saveAll(projects);
        }

        if (!CollectionUtils.isEmpty(investments)){
            investments.forEach(i -> i.setQuestionnaireId(newId));
            investmentRepository.saveAll(investments);
        }

        if (!CollectionUtils.isEmpty(pilots)){
            pilots.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setPilotId(null);
            });
            pilotRepository.saveAll(pilots);
        }

        if (!CollectionUtils.isEmpty(workers)){
            workers.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setWorkerId(null);
            });
            workerRepository.saveAll(workers);
        }

        if (!CollectionUtils.isEmpty(contacts)){
            contacts.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setContactId(null);
            });
            contactRepository.saveAll(contacts);
        }

        if (!CollectionUtils.isEmpty(clubs)){
            clubs.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setInvestmentClubId(null);
            });
            investmentClubRepository.saveAll(clubs);
        }

        if (!CollectionUtils.isEmpty(representatives)){
            representatives.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setRepresentativeId(null);
            });
            representativeRepository.saveAll(representatives);
        }

        if (!CollectionUtils.isEmpty(funds)){
            funds.forEach(i -> {
                i.setQuestionnaireId(newId);
                i.setFundId(null);
            });
            questionnaireFundsRepository.saveAll(funds);
        }
    }

    void updateImportReplaceName(QuestionnaireUpdateReq req) {
        if (req.getQuestionnaireId() == null) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        }
        ImportReplaceDAO dao = importReplaceDAORepository.findByQuestionnaireId(req.getQuestionnaireId());
        if (dao == null) {
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        }
        if (req.getImportReplace() != null && req.getImportReplace().getName() != null) {
            dao.setName(req.getImportReplace().getName().toArray(new String[0]));
            importReplaceDAORepository.save(dao);
        } else {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        }
    }
}
