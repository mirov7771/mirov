package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.QueryBuilder;
import ru.sberx.questionary.controller.dto.req.ApplicationListReq;
import ru.sberx.questionary.controller.dto.res.ApplicationListRes;
import ru.sberx.questionary.controller.dto.support.ApplicationDto;
import ru.sberx.questionary.controller.tariff.dto.req.CheckTariffReq;
import ru.sberx.questionary.dao.model.ApplicationDao;
import ru.sberx.questionary.dao.repository.ApplicationRepository;
import ru.sberx.questionary.service.tariff.TariffService;
import ru.sberx.questionary.util.GuideService;

import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.questionary.util.GuideService.CONFIRMED_STATE;

@Component
@Slf4j
@RequiredArgsConstructor
public class ApplicationMethod {

    @Value("${application.click-action.application}")
    private String clickAction;
    @Value("${application.click-action.names.1}")
    private String nameForType1;
    @Value("${application.click-action.names.2}")
    private String nameForType2;
    @Value("${application.bad-domains}")
    private Set<String> badDomains;

    private final ApplicationRepository applicationRepository;
    private final QueryBuilder queryBuilder;
    private final TariffService tariffService;

    public ApplicationDto createApplication(ApplicationDto application) {
        tariffService.check(new CheckTariffReq(application.getTariff(), application.getType(), application.getInvestorType()));
        ApplicationDao newApplication = new ApplicationDao(application);
// Убираю по задаче STARTUPHUB-3885 [UNITY] Не отображается ошибка о корпоративном емейле на преданкетах корпорации и инвестора
//        if (!isBusinessAngel(newApplication) && newApplication.getEmail() != null) {
//            for (String s : badDomains) {
//                if (newApplication.getEmail().toUpperCase().endsWith("@"+s.toUpperCase()))
//                    throw new SberException(1032, 406, "Введите почту на корпоративном домене", null);
//            }
//        }
        newApplication.setState(GuideService.CHECKING_STATE.intValue());
        log.info("Saving new application: {}", newApplication);
        newApplication = applicationRepository.save(newApplication);
        log.info("New application saved with id: {}", newApplication.getApplicationId());
        ApplicationDto id = new ApplicationDto();
        id.setApplicationId(newApplication.getApplicationId());
        return id;
    }

    private boolean isBusinessAngel(ApplicationDao applicationDao) {
        return Integer.valueOf(2).equals(applicationDao.getType()) && Integer.valueOf(11002).equals(applicationDao.getInvestorType());
    }

    public ApplicationDto getApplicationById(Long id, String email) {
        log.info("Selecting application with id {}, email or login{}", id, email);
        Optional<ApplicationDao> applicationDao;
        if (StringUtils.hasText(email)) {
            applicationDao = applicationRepository.findByLogin(email);
            if (applicationDao.isEmpty())
                applicationDao = applicationRepository.findByEmail(email);
        } else if (id != null)
            applicationDao = applicationRepository.findById(id);
        else
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        return applicationDao.map(a -> {
            log.info("Found application: {}", a);
            return getAppDto(a);
        }).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Заявка не найдена"));
    }

    public ApplicationDto getApplicationByUid(String uid, Boolean auth) {
        log.info("Selecting application with uid {}", uid);
        ApplicationDao applicationDao = applicationRepository.findByUid(uid).orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND, "Заявка не найдена"));
        log.info("Found application: {}", applicationDao);
        if (!Boolean.TRUE.equals(auth) && !CONFIRMED_STATE.equals(applicationDao.getState().longValue()))
            throw new SberxException(SberxErrors.PROHIBITED_INFORMATION);

        //Обновляем application, чтобы активные заявки не попадали в выборку джоба
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.YEAR, 50);
        applicationDao.setNotificationDttm(cal.getTime());
        applicationRepository.save(applicationDao);

        return getAppDto(applicationDao);
    }

    public ApplicationListRes getApplicationList(ApplicationListReq req) {
        log.info("Selecting applications with params: {}", req);
        List<ApplicationDao> applicationDaos = queryBuilder.getApplicationList(req);
        ApplicationListRes res = new ApplicationListRes();
        res.setTotalRowCount(applicationDaos.size());
        if (req.getRowCount() != null && !ObjectUtils.isEmpty(applicationDaos)) {
            int offset = req.getPageToken() != null ? req.getPageToken() : 0;
            int from = req.getRowCount() * offset;
            int to = from + req.getRowCount();
            if (to >= applicationDaos.size()) {
                res.setNextPageToken(null);
                to = applicationDaos.size();
            } else {
                res.setNextPageToken(offset + 1);
            }
            log.debug("Limiting list, getting sublist from {} to {}", from, to);
            applicationDaos = applicationDaos.subList(from, to);
        }
        res.setRowCount(applicationDaos.size());
        List<ApplicationDto> applications = applicationDaos.stream().map(
                dao -> {
                    ApplicationDto dto = new ApplicationDto();
                    dto.setApplicationId(dao.getApplicationId());
                    dto.setType(dao.getType());
                    dto.setState(dao.getState());
                    dto.setModified(dao.getModified());
                    dto.setCreated(dao.getCreated());
                    dto.setOrgFullName(dao.getOrgFullName());
                    dto.setClickMethod("GET");
                    String name = "";
                    if (Integer.valueOf(1).equals(dao.getType())) {
                        name = nameForType1;
                    } else if (Integer.valueOf(2).equals(dao.getType())) {
                        name = nameForType2;
                    }
                    dto.setClickAction(
                            clickAction
                                .replace("{applicationId}", String.valueOf(dao.getApplicationId()))
                                .replace("{name}", name)
                    );
                    dto.setUtm(dao.getUtm());
                    return dto;
                })
                .collect(
                        Collectors.toList());
        if (req.getSortBy() == null) {
            if (Boolean.TRUE.equals(req.getAdmin())) {
                applications.sort((a1, a2) -> a2.getCreated().compareTo(a1.getCreated()));
            } else {
                applications.sort((a1, a2) -> {
                    if (a2.getModified() != null && a1.getModified() != null) {
                        return a2.getModified().compareTo(a1.getModified());
                    } else if (a2.getModified() != null) {
                        return a2.getModified().compareTo(a1.getCreated());
                    } else if (a1.getModified() != null) {
                        return a2.getCreated().compareTo(a1.getModified());
                    }
                    return 0;
                });
            }
        }
        res.setList(applications);
        log.debug("Found applications: {}", res);
        log.info("Applications returned");
        return res;
    }

    private ApplicationDto getAppDto(ApplicationDao dao){
        ApplicationDto applicationDto = dao.toDto();
        if (StringUtils.hasText(applicationDto.getTariff())){
            applicationDto.setTariffName(tariffService.tariffName(applicationDto.getTariff()));
        }
        return applicationDto;
    }
}
