package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.util.MultiDateDeserializer;
import ru.sberx.utils.validator.ConditionValidator;

import javax.validation.constraints.NotNull;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Questionnaire {

    private String name;
    @NotNull
    private String fullName;
    @JsonDeserialize(using = MultiDateDeserializer.class)
    private Date birthDay;
    private String location;
    private String logoFile;
    private Boolean legalRegistered;
    private Boolean mentoring;
    private String turnover;
    private String site;
    private String note;
    private long[] innovationMethod;
    private Long[] industry;
    private Boolean mailNews;
    private long[] stady;
    private Boolean club;
    private Boolean representative;
    @NotNull
    private Integer type;
    private String typeName;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    @JsonFormat(timezone = "GMT+3")
    private Date created;
    private Boolean isBran;
    private Boolean isDisabled;
    private long[] round;
    private long[] geography;
    private String[] tags;
    private String phoneNumber;
    private String email;
    private Long owner;
    private String inviteFio;
    private String inviteUnit;
    private Long inviteUser;
    private Long questionnaireId;
    private String comment;
    private Long parentId;
    private Long state;
    private String stateName;
    private Integer staff;
    private long[] interactionType;
    private long[] model;
    private Boolean isNew;
    private Long investorType;
    private Long registrationCountry;
    private List<Long> userId;
    private Boolean successfullCase;
    private Boolean scouting;
    private Integer startupInvestmentYears;
    private Integer lastYearInvestmentsCount;
    private Integer overallPilots;
    private Integer overallContracts;
    private String communityState;
    private Integer allDealsNumber;
    private Integer exitDealsNumber;
    private Integer activeDealsNumber;
    private Integer birthYear;
    private Boolean accelerator;
    private Long locationCountry;
    private Boolean community;
    private Boolean successPilots;
    private Boolean pilot;
    private Boolean successPilotsB2C;
    private Long stateCode;
    private long[] sales;
    private long[] salesValue;
    private String portfolioNote;
    private long[] businessModel;
    private Boolean forLending;
    private String transcription;
    private long[] acceleratorCode;
    private Integer priority;
    private String typeLabel;
    private String userMail;
    private String userPhone;
    private String fullNote;
    private Long[] technology;
    @JsonProperty("project_technology")
    private Long[] projectTechnology;
    @JsonProperty("investment_technology")
    private Long[] investmentTechnology;
    @JsonProperty("project_geography")
    private long[] projectGeography;
    @JsonProperty("investment_geography")
    private long[] investmentGeography;
    @JsonProperty("investment_industry")
    private Long[] investmentIndustry;
    @JsonFormat(timezone = "GMT+3")
    private Date revisionDate;
    private String inn;
    private String acceleratorSite;

    private List<Contact> contacts;
    private Boolean ecoSystem;
    private Boolean investment;
    private Project project;
    private List<PilotDTO> successPilotsList;
    private Boolean showMore;
    private Boolean sber500;
    private SberFiveHundredDto sberFiveHundred;
    private Investment qInvestment;
    private PilotDTO ecosystemPilot;
    @JsonProperty("worker")
    private List<Worker> workers;
    private Integer favorites;
    private Boolean favorite;
    private String uuid;
    private Long responsible;
    private String responsibleLogin;
    @JsonFormat(timezone = "GMT+3")
    private Date updateDateForSort;
    private Integer investorSort;
    private Boolean view;
    private Boolean mailingConsent;
    private Boolean enableOffers;
    private Boolean offerPilot;
    private List<Button> buttons;
    private Boolean isImport;

    private List<String> importReplaceName;
    private String businessPlan;
    private String acceleratorString;
    private Date lastEnter;
    private String[] languages;
    private String mainLanguage;
    @JsonProperty("label_new")
    private Boolean labelNew;

    public Questionnaire(ru.sberx.questionary.dao.model.Questionnaire q,
                         Boolean fullNote,
                         Boolean showMore,
                         boolean changeLogo)
    {
        this.name = (q.getName() == null || "".equals(q.getName()) ? q.getFullName() : q.getName());
        this.fullName = q.getFullName();
        if (Boolean.TRUE.equals(fullNote)) {
            this.note = q.getNote();
        } else {
            this.note =
                (q.getNote() != null && q.getNote().length() > 130) ? q.getNote().substring(0, 130)
                    + "..." : q.getNote();
        }
        this.questionnaireId = q.getQuestionnaireId();
        this.modified = q.getModified();
        this.phoneNumber = q.getPhoneNumber();
        this.email = q.getEmail();
        if (changeLogo)
            this.logoFile = ConditionValidator.getLogo(q.getLogoFile());
        else
            this.logoFile = q.getLogoFile();
        this.businessModel = q.getBusinessModel();
        this.forLending = q.getForLending();
        this.revisionDate = q.getRevisionDate();
        if (showMore != null)
            this.showMore = showMore;

        this.updateDateForSort = q.getUpdateDateForSort();
        this.uuid = q.getUuid().toString();
        this.enableOffers = q.getEnableOffers();
    }

    public Boolean existLang(String lang) {
        return languages != null && languages.length > 0 && Arrays.asList(languages).contains(lang);
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Button {
        private Integer code;
        private String text;
        private Boolean isDisabled;
        private String clickAction;
        private String clickMethod;
    }
}
