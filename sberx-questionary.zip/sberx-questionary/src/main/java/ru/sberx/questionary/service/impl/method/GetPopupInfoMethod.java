package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.controller.dto.res.PopupStatusRes;
import ru.sberx.questionary.dao.model.PopupInfoDao;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.repository.CommunityApplicationRepository;
import ru.sberx.questionary.dao.repository.PopupInfoRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;
import ru.sberx.questionary.gate.dto.GetPopupRes;
import ru.sberx.questionary.gate.service.OnBoardingService;
import ru.sberx.questionary.gate.service.ScreenBuilderService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.gate.service.impl.OnBoardingServiceImpl;
import ru.sberx.questionary.gate.service.impl.UserAuthImpl;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.PopUpStatus;
import ru.sberx.questionary.util.Utils;

import javax.transaction.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class GetPopupInfoMethod {

    private final PopupInfoRepository popupInfoRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final UserAuth userAuth;
    private final CommunityApplicationRepository communityApplicationRepository;
    private final OnBoardingService onBoardingService;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final ScreenBuilderService screenBuilderService;

    @Value("${application.sber500:false}")
    private Boolean sber500;

    @Transactional
    public PopupStatusRes execute(Long questionnaireId) {
        PopupStatusRes res = new PopupStatusRes();
        List<PopupInfoDao> popups = popupInfoRepository.findByQuestionnaireIdAndWatched(questionnaireId, false);
        if (popups.isEmpty())
            return res;
        Questionnaire q = questionnaireRepository.findByQuestionnaireId(questionnaireId);
        Optional<PopupInfoDao> lastPopup = popups.stream().max(Comparator.comparingLong(PopupInfoDao::getId));
        res.setStatus(lastPopup.map(PopupInfoDao::getStatus).orElse(null));
        if (!(popups.size() == 1 && PopUpStatus.getProcessingStatus(q.getType()).getValue().equals(popups.get(0).getStatus())))
            popupInfoRepository.updatePopupByQuestionnaireIdWhereWatchedIsFalse(questionnaireId);
        return res;
    }

    @Transactional
    public List<GetPopupRes> executeV2(Long questionnaireId, Long userId, String locale) {
        List<GetPopupRes> res = new ArrayList<>();
        Questionnaire questionnaire;
        if (questionnaireId == null) {
            questionnaire = questionnaireRepository.findConfirmedByUserId(userId);
            if (questionnaire == null)
                questionnaire = questionnaireRepository.findAllByUserId(userId);
        } else {
            questionnaire = questionnaireRepository.findByQuestionnaireId(questionnaireId);
        }
        if (questionnaire != null) {
            if (Boolean.TRUE.equals(sber500) && questionnaire.getType() != null && questionnaire.getType().equals(0)) {
                if (!Boolean.TRUE.equals(questionnaire.getSber500())
                        && CollectionUtils.isEmpty(popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.SBER_500.getValue(), userId))) {
                    PopupInfoDao dao = new PopupInfoDao();
                    dao.setStatus(PopUpStatus.SBER_500.getValue());
                    dao.setQuestionnaireId(questionnaireId);
                    dao.setWatched(false);
                    dao.setUserId(userId);
                    popupInfoRepository.save(dao);
                }
            }

            if (questionnaire.getType().equals(0)
                    && !Boolean.TRUE.equals(questionnaire.getIsImport())
                    && CollectionUtils.isEmpty(popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.IMPORT.getValue(), userId))) {
                PopupInfoDao dao = new PopupInfoDao();
                dao.setStatus(PopUpStatus.IMPORT.getValue());
                dao.setQuestionnaireId(questionnaireId);
                dao.setWatched(questionnaire.getIsImport() != null);
                dao.setDate(new Date());
                dao.setUserId(userId);
                popupInfoRepository.save(dao);
            }
            UserAuthImpl.ConsentSignDttm consentSignDttm = userAuth.getConsentSignDttm(userId);
            if (consentSignDttm.getMailingConsent() == null
                    && CollectionUtils.isEmpty(popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.MAILING_CONSENT.getValue(), userId))) {
                PopupInfoDao dao = new PopupInfoDao();
                dao.setStatus(PopUpStatus.MAILING_CONSENT.getValue());
                dao.setQuestionnaireId(questionnaireId);
                dao.setWatched(false);
                dao.setDate(new Date());
                dao.setUserId(userId);
                popupInfoRepository.save(dao);
            }
            if (questionnaire.getType().equals(0)
                    && CollectionUtils.isEmpty(popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.COMMUNITY.getValue(), userId))
                    && CollectionUtils.isEmpty(communityApplicationRepository.findByQuestionnaireIdAndType(questionnaireId, 0))) {
                OnBoardingServiceImpl.OnBoardingElements onBoarding = onBoardingService.getOnBoarding(OnBoardingServiceImpl.STARTUPS);
                if (onBoarding == null || CollectionUtils.isEmpty(onBoarding.getItems())) {
                    PopupInfoDao dao = new PopupInfoDao();
                    dao.setStatus(PopUpStatus.COMMUNITY.getValue());
                    dao.setQuestionnaireId(questionnaireId);
                    dao.setWatched(false);
                    dao.setDate(new Date());
                    dao.setUserId(userId);
                    popupInfoRepository.save(dao);
                }
            }
            if (questionnaire.getType().equals(1)
                    && GuideService.CONFIRMED_STATE.equals(questionnaire.getState())
                    && CollectionUtils.isEmpty(popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.CORPORATE_IMPORT.getValue(), userId))) {
                PopupInfoDao dao = new PopupInfoDao();
                dao.setStatus(PopUpStatus.CORPORATE_IMPORT.getValue());
                dao.setQuestionnaireId(questionnaireId);
                dao.setWatched(false);
                dao.setDate(new Date());
                dao.setUserId(userId);
                popupInfoRepository.save(dao);
            }

            if (questionnaire.getType().equals(0)
                    && !Boolean.TRUE.equals(questionnaire.getIsImport())) {
                List<PopupInfoDao> importPopups = popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.IMPORT.getValue(), userId);
                if (CollectionUtils.isEmpty(popupInfoRepository.findByQuestionnaireIdAndStatusAndUserId(questionnaireId, PopUpStatus.STARTUP_IMPORT_REMINE.getValue(), userId))) {
                    boolean needRemind = (CollectionUtils.isEmpty(importPopups)
                            || (!CollectionUtils.isEmpty(importPopups)
                            && importPopups.stream().anyMatch(i -> (i.getDate() == null || Utils.getDaysDiff(new Date(), i.getDate()) >= 7))));
                    if (Boolean.TRUE.equals(needRemind)) {
                        PopupInfoDao dao = new PopupInfoDao();
                        dao.setStatus(PopUpStatus.STARTUP_IMPORT_REMINE.getValue());
                        dao.setQuestionnaireId(questionnaireId);
                        dao.setWatched(false);
                        dao.setDate(new Date());
                        dao.setUserId(userId);
                        popupInfoRepository.save(dao);
                    }
                }
            }

            List<PopupInfoDao> popups = popupInfoRepository.findByQuestionnaireIdAndWatched(questionnaireId, false);

            if (popups.isEmpty()) {
                return res;
            } else if (popups.stream().allMatch(popup -> PopUpStatus.COMMUNITY.getValue().equals(popup.getStatus()))) {
                List<GetPopupRes> popup = screenBuilderService.getPopup(List.of(PopUpStatus.COMMUNITY.getValue()), locale);
                if (!CollectionUtils.isEmpty(popup))
                    res.add(popup.get(0));
                popupInfoRepository.updatePopupByQuestionnaireIdWhereWatchedIsFalse(questionnaireId);
            } else {
                List<GetPopupRes> popupRes = screenBuilderService.getPopup(popups.stream().map(PopupInfoDao::getStatus).collect(Collectors.toList()), locale);
                for (GetPopupRes popup : popupRes) {
                    String status = popup.getStatus();
                    if (PopUpStatus.COMMUNITY.getValue().equals(status))
                        continue;
                    PopupStatusRes popupDto = popup.getSettings();
                    popupDto.setClickAction(replaceFieldParam(popupDto.getClickAction(), questionnaireId));
                    popupDto.setViewAction(replaceFieldParam(popupDto.getViewAction(), questionnaireId));
                    res.add(popup);
                    if (!PopUpStatus.PROCESSING.getValue().equalsIgnoreCase(status) && !PopUpStatus.PROCESSING_STARTUP.getValue().equalsIgnoreCase(status)
                            && !PopUpStatus.PROCESSING_CORPORATE.getValue().equalsIgnoreCase(status) && !PopUpStatus.PROCESSING_INVESTOR.getValue().equalsIgnoreCase(status))
                        popupInfoRepository.updatePopupByQuestionnaireIdWhereWatchedIsFalseAndStatus(questionnaireId, status);
                }
            }
        }
        if (!CollectionUtils.isEmpty(res))
            swapList(res);
        return res;
    }

    private void swapList(List<GetPopupRes> list) {
        GetPopupRes item = null;
        for (GetPopupRes i : list) {
            if (PopUpStatus.CORPORATE_IMPORT.getValue().equalsIgnoreCase(i.getStatus())) {
                item = i;
            } else if (PopUpStatus.IMPORT.getValue().equalsIgnoreCase(i.getStatus())) {
                item = i;
            }
            if (item != null)
                break;
        }
        if (item != null) {
            list.remove(item);
            list.add(0, item);
        }
    }

    private String replaceFieldParam(String field, Long questionnaireId) {
        if (StringUtils.hasText(field) && field.contains("%questionnaireId%")) {
            Questionnaire parent = questionnaireRepository.findByParentId(questionnaireId);
            return field.replace("%questionnaireId%",
                    String.valueOf((parent != null && parent.getQuestionnaireId() != null) ? parent.getQuestionnaireId() : questionnaireId));
        }
        return field;
    }
}
