package ru.sberx.questionary.controller.dto.req;

import lombok.Data;
import ru.sberx.questionary.controller.dto.support.Multilang;

import java.util.Date;
import java.util.List;

@Data
public class RoundReq {
    private Long questionnaireId;
    private Integer state;
    private Date modified;
    private Date created;
    private Boolean investment;
    private Long roundType;
    private String investmentPurpose;
    private Long sumInvestment;
    private Integer percent;
    private Long preMoney;
    private Long postMoney;
    private String result;
    private Boolean leadCheck;
    private String leadName;
    private Long lastInvestment;
    private Long futureInvestment;
    private Long geography;
    private Integer transactionType;
    private String roundInfo;
    private Date endDate;
    private Date planDate;
    private String presentation;
    private Long roundId;
    private Integer marketingPercent;
    private Integer softwarePercent;
    private Integer teamPercent;
    private Integer extensionPercent;
    private String otherDescription;
    private Integer otherPercent;
    private String inviteFio;
    private String email;
    private String phone;
    private List<Multilang> multilang;
    private Boolean v2;
}
