package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Table(name = "recommend_notification")
@Entity
@Getter
@Setter
public class RecommendNotificationDAO implements Serializable {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "questionnaire_id")
    private Long questionnaireId;
    @Column(name = "user_id")
    private Long userId;
    @Column(name = "notification_date")
    private Date notificationDate;
    @Column(name = "notification_questionnaire_id")
    private Long notificationQuestionnaireId;

}
