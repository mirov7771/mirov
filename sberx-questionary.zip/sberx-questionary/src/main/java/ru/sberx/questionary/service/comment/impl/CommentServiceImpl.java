package ru.sberx.questionary.service.comment.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.comment.dto.res.CommentGetRes;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;
import ru.sberx.questionary.dao.model.TableComment;
import ru.sberx.questionary.dao.repository.TableCommentRepository;
import ru.sberx.questionary.service.comment.CommentService;

import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CommentServiceImpl implements CommentService {

    private final TableCommentRepository tableCommentRepository;

    @Override
    public CommentGetRes get(CommentDTO req) {
        CommentGetRes res = new CommentGetRes();
        res.setComments(tableCommentRepository
                .findTableCommentByTableIdAndTableNameOrderByDateAsc(req.getTableId(), req.getTableName())
                .stream().map(comment -> {
                    CommentDTO commentDTO = new CommentDTO();
                    commentDTO.setCommentId(comment.getId());
                    commentDTO.setComment(comment.getBody());
                    commentDTO.setDate(comment.getDate());
                    commentDTO.setEdited(comment.getEdited());
                    if (req.getRole() != null &&
                            (req.getRole().equals("Administrator") || req.getRole().equals("SberbankEmployee"))) {
                        commentDTO.setLogin(comment.getLogin());
                    }
                    return commentDTO;
                }).collect(Collectors.toList()));
        return res;
    }

    @Override
    public CommentDTO post(CommentDTO req) {
        if (req.getUserId() == null || !StringUtils.hasText(req.getRole()) ||
                !StringUtils.hasText(req.getLogin()) || req.getTableId() == null ||
                !StringUtils.hasText(req.getTableName()) || !StringUtils.hasText(req.getComment())) {
            throw new SberxException(SberxErrors.BAD_REQUEST);
        }
        if (req.getTableName() != null && (
                        req.getTableName().equals("Reply") ||
                        req.getTableName().equals("Application") ||
                        req.getTableName().equals("Questionary"))) {
            CommentDTO res = new CommentDTO();
            res.setCommentId(tableCommentRepository.save(new TableComment(req)).getId());
            return res;
        }
        throw new SberxException(SberxErrors.BAD_REQUEST);
    }

    @Override
    public void put(CommentDTO req) {
        if (req.getCommentId() == null) {
            throw new SberxException(SberxErrors.BAD_REQUEST);
        }
        Optional<TableComment> t = tableCommentRepository.findById(req.getCommentId());
        if (t.isEmpty())
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        TableComment tableComment = t.get();
        if (tableComment.getUserId() == null || !tableComment.getUserId().equals(req.getUserId()))
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);

        tableComment.setBody(req.getComment());
        tableComment.setEdited(true);
        tableCommentRepository.save(tableComment);
    }

    @Override
    public void delete(Long id, Long userId) {
        if (id == null || userId == null) {
            throw new SberxException(SberxErrors.BAD_REQUEST);
        }
        Optional<TableComment> t = tableCommentRepository.findById(id);
        if (t.isEmpty()) {
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        }
        TableComment comment = t.get();
        if (comment.getUserId() != null && comment.getUserId().equals(userId)) {
            tableCommentRepository.deleteByCommentId(id);
        } else {
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
        }
    }
}
