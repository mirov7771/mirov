package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ImportReplaceDTO {
    private Long questionnaireId;
    private String note;
    private String benefits;
    private List<String> name;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class ImportReplaceItemsDTO {
        private String name;
    }
}
