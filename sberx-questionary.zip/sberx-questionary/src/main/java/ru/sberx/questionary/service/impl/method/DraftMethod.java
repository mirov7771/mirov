package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.DraftReq;
import ru.sberx.questionary.controller.dto.res.TypeRes;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.model.Worker;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;
import ru.sberx.questionary.dao.repository.WorkerRepository;
import ru.sberx.questionary.util.GuideService;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import static ru.sberx.questionary.util.GuideService.DRAFT_STATE;
import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
public class DraftMethod {

    private final QuestionnaireRepository questionnaireRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final WorkerRepository workerRepository;

    public TypeRes execute(DraftReq req){
        List<Questionnaire> list = questionnaireRepository.findByUserId(req.getUserId());
        if (list.stream().anyMatch(item -> DRAFT_STATE.equals(item.getState())))
            throw new SberxException(SberxErrors.QUESTIONNAIRE_EXIST);
        TypeRes res = new TypeRes();

        Questionnaire q = new Questionnaire();
        q.setType(req.getType() == null ? 0 : req.getType());
        q.setFullName(nvl(req.getOrgName(), " "));
        q.setCreated(new Date());
        q.setModified(new Date());
        q.setState(DRAFT_STATE);
        q.setLegalRegistered(false);
        q.setIsBran(false);
        q.setClub(false);
        q.setIsDisabled(false);
        q.setMailNews(false);
        q.setRepresentative(false);
        q.setMentoring(false);
        q.setSendInvestNotify(false);
        q.setSendInvestPlanNotify(false);
        q.setUuid(UUID.randomUUID());
        q.setSber500(false);
        q.setUtm(req.getUtm());
        Questionnaire newQ = questionnaireRepository.save(q);

        UserQuestionnaire u = new UserQuestionnaire();
        u.setEmail(req.getEmail());
        u.setUserId(req.getUserId());
        u.setSberBusinessId(req.getSbid());
        u.setQuestionnaireId(newQ.getQuestionnaireId());
        u.setIsBran(false);
        u.setIsDisabled(false);
        u.setSberFh(false);
        u.setName(req.getName());
        u.setPhoneNumber(req.getPhoneNumber());
        userQuestionnaireRepository.save(u);

        Worker w = new Worker();
        w.setQuestionnaireId(newQ.getQuestionnaireId());
        w.setFio(req.getName());
        w.setRole(req.getPosition());
        w.setIsDisabled(false);
        workerRepository.save(w);

        res.setQuestionnaireId(newQ.getQuestionnaireId());
        res.setType(newQ.getType());
        res.setState(newQ.getState());
        res.setStateName(GuideService.getState(newQ.getState()));
        res.setUid(newQ.getUuid().toString());
        return res;
    }

}
