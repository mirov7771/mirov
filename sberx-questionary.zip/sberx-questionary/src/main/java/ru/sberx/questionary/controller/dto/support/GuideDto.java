package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
public class GuideDto {

    private List<Value> values;
    private String name;
    private String sysname;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @AllArgsConstructor
    public static class Value {
        private String name;
        private String code;
        private Long count;
    }


}
