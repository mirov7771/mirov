package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Table(name = "IMPORT_REPLACE")
@Entity
@Getter
@Setter
@TypeDefs({
        @TypeDef(name = "string-array", typeClass = StringArrayType.class)
})
public class ImportReplaceDAO implements Serializable {

    private static final long serialVersionUID = -5745844433199330527L;

    @Id
    @Column(name = "questionnaire_id")
    private Long questionnaireId;
    @Type(type = "string-array")
    @Column(name = "name")
    private String[] name;
    @Column(name = "note")
    private String note;
    @Column(name = "benefits")
    private String benefits;
}
