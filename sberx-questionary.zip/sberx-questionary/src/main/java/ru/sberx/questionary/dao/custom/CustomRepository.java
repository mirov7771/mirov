package ru.sberx.questionary.dao.custom;

import ru.sberx.questionary.controller.pilot.req.PilotListReq;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.controller.reply.dto.req.ReplyListReq;
import ru.sberx.questionary.controller.reply.dto.support.ReplyDTO;
import ru.sberx.questionary.dao.custom.dao.QuestionnaireDAO;
import ru.sberx.questionary.dao.custom.dao.RecommendDAO;
import ru.sberx.questionary.dao.custom.dao.ReplyDAO;

import java.util.List;

public interface CustomRepository {
    List<QuestionnaireDAO> findByQId(Long questionnaireId);
    List<QuestionnaireDAO> findFavoritesById(Long questionnaireId);
    List<QuestionnaireDAO> findAllQ();
    List<ReplyDTO> findReply(ReplyListReq req);
    Integer countReply(ReplyListReq req);
    Integer countNewReply(List<Long> ids, String schema);
    Integer countFavoritePilot(Long questionnaireId, Long state);
    Integer countApp(Integer type);
    List<PilotDTO> findPilots(PilotListReq req);
    Integer countPilots(PilotListReq req);
    List<RecommendDAO> findRecommendForNotify(Long userId, Long qId);
}
