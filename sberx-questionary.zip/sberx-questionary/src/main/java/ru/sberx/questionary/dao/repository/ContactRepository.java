package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Contact;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ContactRepository extends CrudRepository<Contact, String> {

    List<Contact> findByQuestionnaireIdAndIsDisabled(Long questionnaireId, Boolean isDisabled);

    List<Contact> findByQuestionnaireIdAndIsDisabledAndLang(Long questionnaireId, Boolean isDisabled, String lang);

    List<Contact> findByQuestionnaireIdInAndIsDisabledAndLang(List<Long> questionnaireId, Boolean isDisabled, String lang);

    @Transactional
    @Modifying
    @Query("delete from Contact where questionnaireId = :questionnaireId")
    void deleteById(@Param("questionnaireId") Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Contact set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    List<Contact> findByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndLang(Long questionnaireId, String lang);

    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndLangIn(Long questionnaireId, List<String> lang);
}
