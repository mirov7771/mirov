package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "METRIC_SETTINGS")
@Getter
@Setter
@NoArgsConstructor
public class MetricSettings implements Serializable {

    private static final long serialVersionUID = -3912773794041758790L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "TYPE_ID")
    private Long typeId;
    @Column(name = "CURRENCY")
    private String currency;

}
