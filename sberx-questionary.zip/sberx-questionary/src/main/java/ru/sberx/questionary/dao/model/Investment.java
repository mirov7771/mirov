package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.LongArrayType;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "INVESTMENT")
@Getter
@Setter
@TypeDefs(@TypeDef(name = "long-array", typeClass = LongArrayType.class))
public class Investment implements Serializable {

    private static final long serialVersionUID = -8603430049439216943L;

    @Id
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "INVESTMENT")
    private Boolean investment;
    @Column(name = "EXPERIENCE")
    private String experience;
    @Type(type = "long-array")
    @Column(name = "ROUND")
    private long[] round;
    @Column(name = "SUMINVESTMENT")
    private String sumInvestment;
    @Column(name = "LASTINVESTMENT")
    private String lastInvestment;
    @Column(name = "COINVESTMENT")
    private String coInvestment;
    @Column(name = "TURNOVER")
    private String turnover;
    @Column(name = "BUSINESSPLAN")
    private String businessPlan;
    @Type(type = "long-array")
    @Column(name = "INDUSTRY")
    private Long[] industry;
    @Type(type = "long-array")
    @Column(name = "GEOGRAPHY")
    private long[] geography;
    @Column(name = "NOTE")
    private String note;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "PARENTID")
    private Long parentId;
    @Type(type = "long-array")
    @Column(name = "TECHNOLOGY")
    private Long[] technology;
    @Column(name = "PLAN_INVESTMENT")
    private Boolean planInvestment;

    public ru.sberx.questionary.controller.dto.support.Investment toDto(){
        ru.sberx.questionary.controller.dto.support.Investment res = new ru.sberx.questionary.controller.dto.support.Investment();
        res.setInvestment(this.investment);
        res.setCoInvestment(this.coInvestment);
        res.setBusinessPlan(this.businessPlan);
        res.setRound(this.round);
        res.setExperience(this.experience);
        res.setTurnover(this.turnover);
        res.setLastInvestment(this.lastInvestment);
        res.setGeography(this.geography);
        res.setIndustry(this.industry);
        res.setNote(this.note);
        res.setTechnology(this.technology);
        res.setPlanInvestment(this.getPlanInvestment());
        return res;
    }

}
