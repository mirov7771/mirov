package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class DraftReq {

    @NotNull
    private Long userId;
    private String sbid;
    private String email;
    private String name;
    private String orgName;
    private String phoneNumber;
    private String position;
    private Integer type;
    private String utm;

}
