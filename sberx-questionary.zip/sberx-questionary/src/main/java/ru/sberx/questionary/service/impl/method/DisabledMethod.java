package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.DisabledReq;
import ru.sberx.questionary.controller.dto.support.Disabled;
import ru.sberx.questionary.dao.model.Pilot;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.repository.PilotRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DisabledMethod {

    private final QuestionnaireRepository questionnaireRepository;
    private final PilotRepository pilotRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;

    public List<Disabled> execute(DisabledReq req){
        if (req.getUserId() == null && (req.getQuestionnaireId() == null || req.getQuestionnaireId().size() == 0)){
            if (req.getUserId() == null && (req.getQuestionnaireId() == null || req.getQuestionnaireId().size() == 0))
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "required: userId, questionnaireId");
            else if (req.getUserId() == null)
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "required: userId");
            else if (req.getQuestionnaireId() == null || req.getQuestionnaireId().size() == 0)
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "required: questionnaireId");
        }
        List<Disabled> res = new ArrayList<>();
        List<Questionnaire> qlist;
        if (req.getQuestionnaireId() != null && req.getQuestionnaireId().size() > 0) {
            qlist = questionnaireRepository.findByQuestionnaireIdIn(req.getQuestionnaireId());
        } else {
            qlist = questionnaireRepository.findByUserIdAll(req.getUserId());
        }
        if (qlist != null && qlist.size() > 0) {
            List<Long> ids = new ArrayList<>();
            for(Questionnaire qitem : qlist) {
                qitem.setIsDisabled(!Boolean.TRUE.equals(qitem.getIsDisabled()));
                ids.add(qitem.getQuestionnaireId());
                questionnaireRepository.save(qitem);
                Disabled d = new Disabled();
                d.setIsDisabled(qitem.getIsDisabled());
                d.setUserId(req.getUserId());
                d.setQuestionnaireId(qitem.getQuestionnaireId());
                res.add(d);
            }
            List<Pilot> plist = pilotRepository.findByQuestionnaireIdIn(ids);
            for (Pilot pitem : plist) {
                pitem.setIsDisabled(!Boolean.TRUE.equals(pitem.getIsDisabled()));
                pilotRepository.save(pitem);
            }
            List<UserQuestionnaire> ulist = userQuestionnaireRepository.findByQuestionnaireIdIn(ids);
            for(UserQuestionnaire uitem : ulist) {
                uitem.setIsDisabled(!Boolean.TRUE.equals(uitem.getIsDisabled()));
                userQuestionnaireRepository.save(uitem);
            }
        }
        return res;
    }

}
