package ru.sberx.questionary.dao.custom.impl;

import org.hibernate.query.Query;
import org.springframework.util.CollectionUtils;
import ru.sberx.questionary.controller.dto.req.StatisticReq;
import ru.sberx.questionary.controller.dto.res.TypeRes;
import ru.sberx.questionary.controller.dto.support.Statistic;
import ru.sberx.questionary.dao.custom.ListResultTransformer;
import ru.sberx.questionary.dao.custom.QuestionnaireCustomRepository;
import ru.sberx.questionary.dao.custom.dao.QuestionnaireDAO;
import ru.sberx.questionary.dao.custom.dao.ReplyDAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import java.math.BigInteger;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import static java.time.LocalDate.now;

public class QuestionnaireCustomRepositoryImpl implements QuestionnaireCustomRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Override
    public List<Statistic> getStatistic(StatisticReq req) {
        String sql = "select q.questionnaireid , \n" +
                "   cast(ql.uuid as varchar) as uid,\n" +
                "   case when q.type = 1 then 'Корпорация' when q.type = 2 then 'Инвестор' else  'Стартап' end as type,      \n" +
                "   case when q.investortype = 11001 then 'Венчурный фонд' when q.investortype = 11002 then 'Бизнес-ангел' when q.investortype = 11004 then 'Family Office' end as investorType, \n" +
                "   ql.fullname,\n" +
                "   ql.name,      \n" +
                "   q.created,\n" +
                "   q.modified,\n" +
                "   q.state,\n" +
                "   q.parentid,\n" +
                "   ql.inn,\n" +
                "   cast(extract (year from ql.birthday) as varchar) as birthday,\n" +
                "   ql.site,\n" +
                "   ql.registrationcountry,       \n" +
                "   ql.email,\n" +
                "   ql.phonenumber,\n" +
                "(select string_agg(c2.\"name\",';') from contact c2 where c2.questionnaireid = ql.questionnaireid and c2.lang = ql.lang group by c2.questionnaireid ) as DopContact,\n" +
                "pl.note,\n" +
                "cast(p.interactiontype as varchar) as interactiontype,\n" +
                "cast(q.businessmodel as varchar) as businessmodel ,\n" +
                "q.locationcountry,\n" +
                "q.location,   \n" +
                "case when p.industry is not null then cast(p.industry as varchar) else cast(i.industry as varchar) end as _industry,\n" +
                "case when p.technology is not null then cast(p.technology as varchar) else cast(i.technology as varchar) end as _technology,\n" +
                "case when length(q.logo_file)>0 and position('sberx-gateway' in q.logo_file)>0 then concat('https://bran.sber.ru',split_part(q.logo_file, '|', 1)) when length(q.logo_file)>0 then concat('https://bran.sber.ru/sberx-gateway',split_part(q.logo_file, '|', 1)) else '' end as logo, \n" +
                "cast(p.mvpcode as varchar) as mvpcode,\n" +
                "pl.demovideo,\n" +
                "pl.problem ,\n" +
                "pl.auditory ,\n" +
                "case when length(il.businessplan)>0 and position('sberx-gateway' in il.businessplan)>0 then concat('https://bran.sber.ru',split_part(il.businessplan , '|', 1))\n" +
                "   when length(il.businessplan)>0 then concat('https://bran.sber.ru/sberx-gateway',split_part(il.businessplan , '|', 1))\n" +
                "   else '' end as present, \n" +
                "cast(p.geography as varchar) as geography,\n" +
                "cast(p.sales as varchar) as sales,\n" +
                "i.turnover ,\n" +
                "pl.competitor ,\n" +
                "pl.upside ,\n" +
                "p.staff ,\n" +
                "(select string_agg(concat('(',w.\"role\",',',w.note,')'),';') from worker w where w.questionnaireid = q.questionnaireid and w.lang = ql.lang group by w.questionnaireid) as _note,\n" +
                "q.successpilots ,\n" +
                "(select string_agg(concat('(',p2.reference ,',',p2.suggestcase,')'),';') \n" +
                "  from pilot p2 where p2.questionnaireid = q.questionnaireid and p2.lang = ql.lang and p2.isb2b = true \n" +
                "  group by p2.questionnaireid) as _reference,\n" +
                "q.pilot ,\n" +
                "(select p3.suggestcase from pilot p3 where p3.questionnaireid = q.questionnaireid and p3.ecosystem = true and p3.lang = ql.lang limit 1) as _suggestcase,\n" +
                "(select p4.experience from pilot p4 where p4.questionnaireid = q.questionnaireid and p4.ecosystem = true and p4.lang = ql.lang limit 1) as _experience,\n" +
                "il.lastinvestment ,\n" +
                "il.coinvestment ,\n" +
                "cast(sfh.eco_requirement as varchar) as eco_requirement,\n" +
                "sfh.first_time ,\n" +
                "sfh.month_revenue ,\n" +
                "sfh.quarter_revenue ,\n" +
                "sfh.clients, \n" +
                "q.sber500, \n" +
                "q.is_import as is_import, \n" +
                "cast(ir.name as varchar) as ir_name,\n" +
                "irl.note as ir_note,\n" +
                "irl.benefits as ir_benefits,\n" +
                "q.utm as q_utm, \n" +
                "case when (select 1 from metric m where m.questionnaireid = q.questionnaireid limit 1) is not null then 'Да' else 'Нет' end as _metric\n" +
                "from questionnaire q \n" +
                "inner join questionnaire_local ql on q.questionnaireid = ql.questionnaireid and (ql.lang like 'ru' or ql.lang not like 'ru' and ql.lang = 'en')\n" +
                "left outer join project p on q.questionnaireid = p.questionnaireid \n" +
                "left outer join project_local pl on p.projectid = pl.projectid and pl.lang = ql.lang \n" +
                "left outer join investment i on q.questionnaireid = i.questionnaireid \n" +
                "left outer join investment_local il on il.questionnaireid = ql.questionnaireid and il.lang = ql.lang \n" +
                "left outer join sber_five_hundred sfh on q.questionnaireid = sfh.questionnaire_id \n" +
                "left outer join import_replace ir on ir.questionnaire_id = q.questionnaireid  \n" +
                "left outer join import_replace_lang irl on irl.questionnaireid = ql.questionnaireid and irl.lang = ql.lang \n" +
                "where q.isdisabled = false  \n" +
                "                 and ql.name not like '%каукуаку%'  \n" +
                "                 and ql.name not like '%артнер%'  \n" +
                "                 and ql.fullname not like '%артнер%'  \n" +
                "                 and ql.fullname not like '%211212%'";

        if (!CollectionUtils.isEmpty(req.getType()))
            sql += " and q.type in :types ";
        if (req.getDateFrom() != null)
            sql += " and q.created >= :from ";
        if (req.getDateTo() != null)
            sql += " and q.created <= :to ";

        sql += " order by q.created";

        Query<Statistic> query = entityManager.createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new Statistic(
                                ((BigInteger) tuple[0]).longValue(),//Long id,
                                tuple[1] != null ? (String) tuple[1] : null,   //String uid,
                                tuple[2] != null ? (String) tuple[2] : null,   //String type,
                                tuple[3] != null ? (String) tuple[3] : null,   //String investorType,
                                tuple[4] != null ? (String) tuple[4] : null,   //String fullName,
                                tuple[5] != null ? (String) tuple[5] : null,   //String name,
                                tuple[6] != null ? (Date) tuple[6] : null,   //Date created,
                                tuple[7] != null ? (Date) tuple[7] : null,   //Date modified,
                                tuple[8] != null ? ((BigInteger) tuple[8]).longValue() : null,   //Long state,
                                tuple[9] != null ? ((BigInteger) tuple[9]).longValue() : null,   //Long parenId,
                                tuple[10] != null ? (String) tuple[10] : null,   //String inn,
                                tuple[11] != null ? (String) tuple[11] : null,   //String birthday,
                                tuple[12] != null ? (String) tuple[12] : null,   //String site,
                                tuple[13] != null ? ((BigInteger) tuple[13]).longValue() : null,   //Long registrationCountry,
                                tuple[14] != null ? (String) tuple[14] : null,   //String email,
                                tuple[15] != null ? (String) tuple[15] : null,   //String phoneNumber,
                                tuple[16] != null ? (String) tuple[16] : null,   //String contact,
                                tuple[17] != null ? (String) tuple[17] : null,   //String note,
                                tuple[18] != null ? (String) tuple[18] : null,   //String interactionType,
                                tuple[19] != null ? (String) tuple[19] : null,   //String businessModel,
                                tuple[20] != null ? ((BigInteger) tuple[20]).longValue() : null,   //Long locationCountry,
                                tuple[21] != null ? (String) tuple[21] : null,   //String location,
                                tuple[22] != null ? (String) tuple[22] : null,   //String industry,
                                tuple[23] != null ? (String) tuple[23] : null,   //String technology,
                                tuple[24] != null ? (String) tuple[24] : null,   //String logo,
                                tuple[25] != null ? (String) tuple[25] : null,   //String mvpCode,
                                tuple[26] != null ? (String) tuple[26] : null,   //String demoVideo,
                                tuple[27] != null ? (String) tuple[27] : null,   //String problem,
                                tuple[28] != null ? (String) tuple[28] : null,   //String auditory,
                                tuple[29] != null ? (String) tuple[29] : null,   //String present,
                                tuple[30] != null ? (String) tuple[30] : null,   //String geography,
                                tuple[31] != null ? (String) tuple[31] : null,   //String sales,
                                tuple[32] != null ? (String) tuple[32] : null,   //String turnover,
                                tuple[33] != null ? (String) tuple[33] : null,   //String competitor,
                                tuple[34] != null ? (String) tuple[34] : null,   //String upside,
                                tuple[35] != null ? ((BigInteger) tuple[35]).intValue() : null,  //Integer staff,
                                tuple[36] != null ? (String) tuple[36] : null,  //String roleNote,
                                tuple[37] != null && Boolean.TRUE.equals(tuple[37]),  //String successPilots,
                                tuple[38] != null ? (String) tuple[38] : null,  //String reference,
                                tuple[39] != null && Boolean.TRUE.equals(tuple[39]),   //Boolean pilot,
                                tuple[40] != null ? (String) tuple[40] : null,  //String suggestCase,
                                tuple[41] != null && Boolean.TRUE.equals(tuple[41]),  //String experience,
                                tuple[42] != null ? (String) tuple[42] : null,  //String lastInvestment,
                                tuple[43] != null ? (String) tuple[43] : null,  //String coInvestment,
                                tuple[44] != null ? (String) tuple[44] : null,  //String ecoRequirement,
                                tuple[45] != null && Boolean.TRUE.equals(tuple[45]),//Boolean firstTime,
                                tuple[46] != null ? (String) tuple[46] : null,  //String monthRevenue,
                                tuple[47] != null ? (String) tuple[47] : null,  //String quarterRevenue,
                                tuple[48] != null ? (Integer) tuple[48] : null,//Integer clients
                                tuple[49] != null && Boolean.TRUE.equals(tuple[49]),//Boolean sber500,
                                tuple[50] != null && Boolean.TRUE.equals(tuple[50]),//Boolean isImport,
                                tuple[51] != null ? (String) tuple[51] : null,  //String irName,
                                tuple[52] != null ? (String) tuple[52] : null,  //String irNote,
                                tuple[53] != null ? (String) tuple[53] : null,  //String irBenefits,
                                tuple[54] != null ? (String) tuple[54] : null,  //String utm,
                                tuple[55] != null ? (String) tuple[55] : null  //String metric,
                        ));

        if (sql.contains(":types"))
            query.setParameter("types", req.getType());
        if (sql.contains(":from"))
            query.setParameter("from", Date.from(Instant.ofEpochSecond(req.getDateFrom())), TemporalType.TIMESTAMP);
        if (sql.contains(":to"))
            query.setParameter("to", Date.from(Instant.ofEpochSecond(req.getDateTo())), TemporalType.TIMESTAMP);

        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ReplyDAO> findCustomReplyInfo(Integer days) {
        int dateOfWeek = now().getDayOfWeek().getValue();
        String sql = "select email, \n" +
                "name as qName, \n" +
                "mindate.questionnaireid \n" +
                "from \n" +
                "(select q.email, \n" +
                "q.name, \n" +
                "min(r.date) as rDate, \n" +
                "q.questionnaireid from reply r \n" +
                "join pilot p on p.pilotid = r.tableid \n" +
                "join questionnaire q on p.questionnaireid = q.questionnaireid \n" +
                "join user_questionnaire uq on uq.userid = r.userid \n" +
                "join questionnaire q2 on uq.questionnaireid = q2.questionnaireid \n" +
                "where \n" +
                "r.state = 20011 \n" +
                "and tablename = 'Pilot' \n" +
                "and q.state ='20004' \n" +
                "group by q.questionnaireid, \n" +
                "q.email, q.name) as mindate \n" +
                "where (mod(current_date - date(mindate.rDate), :days) = 0) \n" +
                "and current_date != date(mindate.rDate) \n" +
                "except \n" +
                "select q.email, q.name, q.questionnaireid from reply r2 join pilot p on r2.tableid = p.pilotid \n" +
                "join questionnaire q on q.questionnaireid = p.questionnaireid";
        if (dateOfWeek == 1)
            sql = "select email, \n" +
                "name as qName, \n" +
                "mindate.questionnaireid \n" +
                "from \n" +
                "(select q.email, \n" +
                "q.name, \n" +
                "min(r.date) as rDate, \n" +
                "q.questionnaireid from reply r \n" +
                "join pilot p on p.pilotid = r.tableid \n" +
                "join questionnaire q on p.questionnaireid = q.questionnaireid \n" +
                "join user_questionnaire uq on uq.userid = r.userid \n" +
                "join questionnaire q2 on uq.questionnaireid = q2.questionnaireid \n" +
                "where \n" +
                "r.state = 20011 \n" +
                "and tablename = 'Pilot' \n" +
                "and q.state ='20004' \n" +
                "group by q.questionnaireid, \n" +
                "q.email, q.name) as mindate \n" +
                "where (mod(current_date - date(mindate.rDate), :days) = 0 \n" +
                "or mod(current_date - date(mindate.rDate), :days) > :days-2) \n" +
                "and current_date != date(mindate.rDate) \n" +
                "except \n" +
                "select q.email, q.name, q.questionnaireid from reply r2 join pilot p on r2.tableid = p.pilotid \n" +
                "join questionnaire q on q.questionnaireid = p.questionnaireid";
        Query<ReplyDAO> query = entityManager
                .createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new ReplyDAO(
                                tuple[0] != null ? ((String) tuple[0]) : null,
                                tuple[1] != null ? ((String) tuple[1]) : null,
                                tuple[2] != null ? ((BigInteger) tuple[2]).longValue() : null
                        ));
        query.setParameter("days", days);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<TypeRes> findTypeList() {
        String sql = "select q.questionnaireid as QuestionnaireId\n" +
                ",cast(q.uid as varchar) as QuestionnaireUUID\n" +
                ",q.type as Type\n" +
                ",case when q.state = 20004 then 'active' else 'not_active' end as statename\n" +
                ",case when q.investortype = 11001 then 'Венчурный фонд' when q.investortype = 11002 then 'Бизнес-ангел' when q.investortype = 11004 then 'Family Office' end as InvestorType\n" +
                ",uq.userid as userid\n" +
                "from user_questionnaire uq \n" +
                "inner join questionnaire q \n" +
                "on q.questionnaireid = uq.questionnaireid \n";
        Query<TypeRes> query = entityManager.createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer) (tuple, aliases) -> new TypeRes(
                        tuple[0] != null ? ((BigInteger) tuple[0]).longValue() : null,
                        tuple[1] != null ? ((String) tuple[1]) : null,
                        tuple[2] != null ? ((Short) tuple[2]).intValue() : null,
                        tuple[3] != null ? ((String) tuple[3]) : null,
                        tuple[4] != null ? ((String) tuple[4]) : null,
                        tuple[5] != null ? ((BigInteger) tuple[5]).longValue() : null
                ));
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<QuestionnaireDAO> findForNotify() {
        String sql = "select q.questionnaireid as id, uq.userid as userid\n" +
                "  from questionnaire q \n" +
                "inner join user_questionnaire uq\n" +
                "on uq.questionnaireid = q.questionnaireid\n" +
                " where type in (1, 2)\n" +
                "   and state  = 20004\n" +
                "   and last_enter is not null\n" +
                "   and last_enter < current_date - 14   \n" +
                "   and not exists (select 1 from recommend_notification r where r.questionnaire_id = q.questionnaireid and r.user_id = uq.userid and notification_date >= current_date - 14)";
        Query<QuestionnaireDAO> query = entityManager.createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer) (tuple, aliases) -> new QuestionnaireDAO(
                        tuple[0] != null ? ((BigInteger) tuple[0]).longValue() : null,
                        tuple[1] != null ? ((BigInteger) tuple[1]).longValue() : null
                ));
        return query.getResultList();
    }
}
