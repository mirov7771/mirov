package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.IntArrayType;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import ru.sberx.questionary.controller.dto.support.SberFiveHundredDto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "SBER_FIVE_HUNDRED")
@Data
@NoArgsConstructor
@TypeDefs({
        @TypeDef(name = "int-array", typeClass = IntArrayType.class)
})
public class SberFiveHundred implements Serializable {

    private static final long serialVersionUID = 8078183742076671761L;

    @Id
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "FIRST_TIME")
    private Boolean firstTime;
    @Column(name = "MOTIVATION")
    private String motivation;
    @Column(name = "MONTH_REVENUE")
    private String monthRevenue;
    @Column(name = "QUARTER_REVENUE")
    private String quarterRevenue;
    @Column(name = "CLIENTS")
    private Integer clients;
    @Type(type = "int-array")
    @Column(name = "ECO_REQUIREMENT")
    private Integer[] ecoRequirement;

    public SberFiveHundredDto toDto(){
        SberFiveHundredDto dto = new SberFiveHundredDto();
        dto.setQuestionnaireId(this.questionnaireId);
        dto.setFirstTime(this.firstTime);
        dto.setMotivation(this.motivation);
        dto.setMonthRevenue(this.monthRevenue);
        dto.setQuarterRevenue(this.quarterRevenue);
        dto.setClients(this.clients);
        dto.setEcoRequirement(this.ecoRequirement);
        return dto;
    }


}
