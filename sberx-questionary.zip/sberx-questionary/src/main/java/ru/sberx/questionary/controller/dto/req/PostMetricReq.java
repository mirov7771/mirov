package ru.sberx.questionary.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.List;

@Data
public class PostMetricReq {

    private Long userId;
    @NotNull
    private Long metric;
    private Integer currency;
    @NotNull
    private List<@Valid Items> items;

    @Data
    public static class Items {
        @JsonFormat(timezone = "GMT+3")
        @NotNull
        private Date date;
        private String value;
    }
}
