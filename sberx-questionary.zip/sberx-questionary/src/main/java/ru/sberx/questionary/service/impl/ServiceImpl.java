package ru.sberx.questionary.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.dto.questionary.questionary.questionary.req.PostUserQuestionnaireReq;
import ru.sberx.dto.questionary.questionary.questionary.res.GetUserListRes;
import ru.sberx.questionary.controller.dto.req.*;
import ru.sberx.questionary.controller.dto.res.*;
import ru.sberx.questionary.controller.dto.support.*;
import ru.sberx.questionary.gate.dto.GetPopupRes;
import ru.sberx.questionary.service.Service;
import ru.sberx.questionary.service.impl.method.*;

import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceImpl implements Service {

    private final ListMethod listMethod;
    private final TypeMethod typeMethod;
    private final GetQuestionaryMethod getQuestionaryMethod;
    private final CreateQuestionaryMethod createQuestionaryMethod;
    private final DeleteQuestionnaireMethod deleteQuestionnaireMethod;
    private final UpdateQuestionnairePriority updateQuestionnairePriority;
    private final UpdateQuestionnaireResponsible updateQuestionnaireResponsible;
    private final UpdateQuestionnaireMethod updateQuestionnaireMethod;
    private final DraftMethod draftMethod;
    private final VerifyMethod verifyMethod;
    private final CreateFeedBackMethod createFeedBackMethod;
    private final GetPopupInfoMethod getPopupInfoMethod;
    private final DisabledMethod disabledMethod;
    private final ApplicationMethod applicationMethod;
    private final ViewCardMethod viewCardMethod;
    private final GetUserMethod getUserMethod;
    private final RoundMethod roundMethod;
    private final CommunityMethod communityMethod;
    private final StatusHistoryMethod statusHistoryMethod;
    private final SyndicateMethod syndicateMethod;
    private final UpdateQuestionnaireOfferMethod updateQuestionnaireOfferMethod;
    private final ScoutingApplicationMethod scoutingApplicationMethod;

    @Override
    public List<?> getParticipantList(Long clientId, QuestionnaireListReq req) {
        req.setClientId(clientId);
        return listMethod.getParticipantList(req);
    }

    @Override
    public List<TypeRes> getTypeByUserId(Long userId) {
        return typeMethod.execute(userId);
    }

    @Override
    public QuestionaryRes getQuestionaryById(Long questionnaireId, String uid, Long parentId, Long userId, String lang, Boolean isEdit) {
        return getQuestionaryMethod.execute(questionnaireId, uid, parentId, userId, lang, isEdit);
    }

    @Override
    public TypeRes createQuestionary(QuestionnaireReq req) {
        return createQuestionaryMethod.execute(req);
    }

    @Override
    public DeleteQuestionnaireRes deleteQuestionnaire(Long questionnaireId) {
        return deleteQuestionnaireMethod.execute(questionnaireId);
    }

    @Override
    public QuestionnairePriority updateQuestionnairePriority(QuestionnairePriority req) {
        return updateQuestionnairePriority.execute(req);
    }

    @Override
    public QuestionnaireResponsible updateQuestionnaireResponsible(QuestionnaireResponsible req) {
        return updateQuestionnaireResponsible.execute(req);
    }

    @Override
    public void updateQuestionnaireOffer(String questionnaireId, OffersReq req, String role) {
        updateQuestionnaireOfferMethod.execute(questionnaireId, req, role);
    }

    @Override
    public void updateQuestionnaire(QuestionnaireUpdateReq req, String role) {
        updateQuestionnaireMethod.execute(req, role);
    }

    @Override
    public TypeRes createDraft(DraftReq req) {
        return draftMethod.execute(req);
    }

    @Override
    public VerifyRes verify(VerifyReq req) {
        return verifyMethod.execute(req);
    }

    @Override
    public FeedBackRes createFeedBack(FeedBack req) {
        return createFeedBackMethod.execute(req);
    }

    @Override
    public List<Disabled> disabled(DisabledReq req) {
        return disabledMethod.execute(req);
    }

    @Override
    public ApplicationDto createApplication(ApplicationDto application) {
        return applicationMethod.createApplication(application);
    }

    @Override
    public ApplicationDto getApplicationById(Long id, String email) {
        return applicationMethod.getApplicationById(id, email);
    }

    @Override
    public ApplicationDto getApplicationByUid(String uid, Boolean auth) {
        return applicationMethod.getApplicationByUid(uid, auth);
    }

    @Override
    public ApplicationListRes getApplicationList(ApplicationListReq req) {
        return applicationMethod.getApplicationList(req);
    }

    @Override
    public PopupStatusRes getPopupStatus(Long questionnaireId) {
        return getPopupInfoMethod.execute(questionnaireId);
    }

    @Override
    public List<GetPopupRes> getPopupStatusV2(Long questionnaireId, Long userId, String locale) {
        return getPopupInfoMethod.executeV2(questionnaireId, userId, locale);
    }

    @Override
    public ViewCardRes viewCard(Long id, UUID uuid, String sessionId) {
        return viewCardMethod.viewCard(id, uuid, sessionId);
    }

    @Override
    public List<GetUserRes> getUserById(Long id, Boolean getQuestionnaireUserIdOnly) {
        return getUserMethod.execute(id, getQuestionnaireUserIdOnly);
    }

    @Override
    public RoundDto createRound(RoundReq req, Long userId) {
        return roundMethod.createRound(req, userId);
    }

    @Override
    public RoundDto createRoundV2(RoundReq req, Long userId) {
        return roundMethod.createRoundV2(req, userId);
    }

    @Override
    public RoundDto getRoundByIdV2(Long roundId, Long userId) {
        return roundMethod.getRoundByIdV2(roundId, userId);
    }

    @Override
    public RoundDto getRoundById(Long roundId, Long userId) {
        RoundDto res = roundMethod.getRoundById(roundId, userId);
        //поле было нужно только для работы v2:
        res.setQuestionnaireMainLanguage(null);
        return res;
    }

    @Override
    public void addFavorite(AddFavoriteReq req, Long userId) {
        roundMethod.addFavorite(req, userId);
    }

    @Override
    public Community postCommunity(Community req, String sessionId) {
        return communityMethod.postCommunity(req, sessionId);
    }

    @Override
    public Community getCommunity(Long id, String sessionId, Long userId) {
        return communityMethod.getCommunity(id, sessionId, userId);
    }

    @Override
    public CommunityListRes getCommunityList(CommunityListReq req) {
        return communityMethod.getCommunityList(req);
    }

    @Override
    public Community changeCommunity(Community req, Long id, String sessionId) {
        return communityMethod.changeCommunity(req, id, sessionId);
    }

    @Override
    public RoundListRes getRoundList(RoundListReq req, Long userId, String role, String locale) {
        return roundMethod.getRoundList(req, userId, role, locale);
    }

    @Override
    public void updateRoundV2(RoundReq req, Long roundId) {
        roundMethod.updateRoundV2(req, roundId);
    }

    @Override
    public void updateRound(RoundReq req, Long roundId) {
        roundMethod.updateRound(req, roundId);
    }

    @Override
    public TypeRes getOneTypeByUserId(Long userId) {
        return typeMethod.executeByUserId(userId);
    }

    @Override
    public List<TypeRes> getTypeList(TypeListReq req) {
        return typeMethod.getList(req);
    }

    @Override
    public StatusInfoListRes getStatusHistory(StatusHistoryReq req) {
        return statusHistoryMethod.getStatusHistory(req);
    }

    @Override
    public Syndicate saveSyndicate(Syndicate req) {
        return syndicateMethod.saveSyndicate(req);
    }

    @Override
    public SyndicateRes getSyndicateList(SyndicateReq req) {
        return syndicateMethod.getSyndicateList(req);
    }

    @Override
    public Syndicate getSyndicateQuestionnaire(Long id, String uid) {
        return syndicateMethod.getSyndicateQuestionnaire(id, uid);
    }

    @Override
    public QuestionnaireGuidListRes getQuestionnaireGuidList(Integer type) {
        return getQuestionaryMethod.getQuestionnaireGuidList(type);
    }

    @Override
    public ScoutingListRes scoutingList(ScoutingListReq req) {
        return scoutingApplicationMethod.list(req);
    }

    @Override
    public ScoutingDto getScoutingById(UUID uid) {
        return scoutingApplicationMethod.id(uid);
    }

    @Override
    public ScoutingDto saveScouting(ScoutingDto req) {
        return scoutingApplicationMethod.save(req);
    }

    @Override
    public GetUserListRes getUserList(Long externalId) {
        return getUserMethod.getUserList(externalId);
    }

    @Override
    public void saveUserQuestionnaire(PostUserQuestionnaireReq req) {
        getUserMethod.saveUserQuestionnaire(req);
    }
}
