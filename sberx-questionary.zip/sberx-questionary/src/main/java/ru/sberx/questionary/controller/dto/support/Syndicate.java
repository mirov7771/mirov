package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Syndicate {
    private Integer type;
    private String firstName;
    private String lastName;
    private String phone;
    private String position;
    private String orgFullName;
    private String site;
    private String email;
    private Long investorType;
    private Long questionnaireId;
    private String comment;
    private String ventureExperience;
    private Boolean isUnity;
    private String telegramLink;
    private Long sumInvestment;
    @NotNull
    private Long id;
    @JsonFormat(timezone = "GMT+3")
    private Date created;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    private Long state;
    private String stateName;
    private Boolean isIMoscow;
    private Boolean consent;
    private Boolean iMoscowConsent;
    private Boolean syndicateConsent;
}
