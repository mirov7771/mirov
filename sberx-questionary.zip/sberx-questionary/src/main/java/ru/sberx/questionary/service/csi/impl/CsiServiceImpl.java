package ru.sberx.questionary.service.csi.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.sberx.questionary.controller.csi.dto.req.PostCsiReq;
import ru.sberx.questionary.controller.csi.dto.res.CsiListRes;
import ru.sberx.questionary.dao.model.CsiDao;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.repository.CsiRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.service.csi.CsiService;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CsiServiceImpl implements CsiService {

    private final CsiRepository csiRepository;
    private final QuestionnaireRepository questionnaireRepository;

    @Override
    public CsiListRes list() {
        CsiListRes res = new CsiListRes();
        List<CsiDao> list = csiRepository.findAll();
        if (!CollectionUtils.isEmpty(list))
            res.setValues(list.stream().map(CsiDao::toDto).collect(Collectors.toList()));
        return res;
    }

    @Override
    public void post(PostCsiReq req) {
        Questionnaire questionnaire = questionnaireRepository.findAllByUserId(req.getUserId());
        if (questionnaire != null && validValue(req.getValue())) {
            CsiDao dao = new CsiDao();
            dao.setQuestionnaireId(questionnaire.getQuestionnaireId());
            dao.setUserId(req.getUserId());
            dao.setValue(req.getValue());
            dao.setCreated(new Date());
            csiRepository.save(dao);
        }
    }

    private boolean validValue(Integer value) {
        if (value == null)
            return false;
        return value.equals(5)
                || value.equals(4)
                || value.equals(3)
                || value.equals(2)
                || value.equals(1);
    }
}
