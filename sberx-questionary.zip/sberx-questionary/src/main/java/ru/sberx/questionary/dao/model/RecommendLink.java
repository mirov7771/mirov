package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

@Table(name = "recommend_link")
@Entity
@Getter
@Setter
@NoArgsConstructor
public class RecommendLink implements Serializable {

    private static final long serialVersionUID = 665173681483074005L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "questionnaire_id")
    private Long questionnaireId;
    @Column(name = "recommend_questionnaire_id")
    private Long recommendQuestionnaireId;
    @Column(name = "cache_time")
    private Date cacheTime;
    @Column(name = "recommend_date")
    private Date recommendDate;

    public RecommendLink(Long questionnaireId, Long recommendQuestionnaireId, Date date) {
        this.questionnaireId = questionnaireId;
        this.recommendQuestionnaireId = recommendQuestionnaireId;
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MINUTE, 60);
        this.cacheTime = cal.getTime();
        this.recommendDate = date;
    }
}
