package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

@Data
public class FeedBackListReq {
    private Long questionnaireId;
    private Integer rowCount;
}
