package ru.sberx.questionary.controller.tariff.dto.req;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
public class CheckTariffReq {

    private Long userId;
    private String role;
    @NotBlank
    private String sysname;
    @NotNull
    private Integer type;
    private Integer investorType;

    public CheckTariffReq(String sysname, Integer type, Integer investorType) {
        this.sysname = sysname;
        this.type = type;
        this.investorType = investorType;
    }
}
