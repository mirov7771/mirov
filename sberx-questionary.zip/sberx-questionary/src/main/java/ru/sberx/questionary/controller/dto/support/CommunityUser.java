package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class CommunityUser {

    private Long communityUserId;
    private Long questionnaireId;
    private Long userId;
    private String ambition;
    private String expectation;
    private Long state;

    public CommunityUser(ru.sberx.questionary.dao.model.CommunityUser c) {
        this.communityUserId = c.getCommunityUserId();
        this.questionnaireId = c.getQuestionnaireId();
        this.userId = c.getUserId();
        this.ambition = c.getAmbition();
        this.expectation = c.getExpectation();
        this.state = c.getState();
    }
}
