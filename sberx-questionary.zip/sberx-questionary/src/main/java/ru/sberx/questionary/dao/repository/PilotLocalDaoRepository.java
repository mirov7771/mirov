package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.PilotLocalDao;
import ru.sberx.questionary.dao.model.pkey.PilotLangPKey;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface PilotLocalDaoRepository extends CrudRepository<PilotLocalDao, PilotLangPKey> {
    PilotLocalDao findByPilotIdAndLang(Long pilotId, String lang);

    List<PilotLocalDao> findByPilotId(Long pilotId);

    List<PilotLocalDao> findByPilotIdIn(List<Long> pilotId);

    @Modifying
    @Transactional
    @Query(value = "delete from pilot_local pl where pl.pilotid in (select p.pilotid from pilot p where p.questionnaireId = :questionnaireId) and pl.lang in :lang", nativeQuery = true)
    void deleteByQuestionnaireIdAndLang(Long questionnaireId, List<String> lang);

    @Query("select distinct pl from PilotLocalDao pl join Pilot p on pl.pilotId = p.pilotId join Response r on pl = r.pilot where p.questionnaireId in :id and pl.lang = :lang")
    List<PilotLocalDao> findByQuestionnaireIdInAndLang(List<Long> id, String lang);

    @Modifying
    @Transactional
    @Query(value = "delete from pilot_local pl where pl.pilotid in (select p.pilotid from pilot p where p.questionnaireId = :questionnaireId and p.ishub != true)", nativeQuery = true)
    void deleteByQuestionnaireId(Long questionnaireId);

    @Query(value = "delete from pilot_local pl where pl.pilotid in (select p.pilotid from pilot p where p.questionnaireId = :questionnaireId " +
            " and (p.ISQUESTIONNAIRE = true " +
            "or p.ISSUCCESS = true " +
            "or p.ISB2C = true " +
            "or p.ISB2B = true " +
            "or p.ECOSYSTEM = true))",
            nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndPilot(Long questionnaireId);
}
