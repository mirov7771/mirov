package ru.sberx.questionary.dao.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.pkey.PilotLangPKey;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "PILOT_LOCAL")
@IdClass(PilotLangPKey.class)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PilotLocalDao implements Serializable {

    private static final long serialVersionUID = 2507271100430146822L;

    @Id
    @Column(name = "PILOTID")
    private Long pilotId;
    @Id
    @Column(name = "LANG")
    private String lang;
    @Column(name = "NAME")
    private String name;
    @Column(name = "SUGGESTCASE")
    private String suggestCase;
    @Column(name = "BUSINESSUNIT")
    private String businessUnit;
    @Column(name = "DEMOFILE")
    private String demoFile;
    @OneToMany(mappedBy = "pilot", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Response> responseList;

    public PilotLocalDao(Long pilotId, String lang, String name, String suggestCase, String businessUnit, String demoFile) {
        this.pilotId = pilotId;
        this.lang = lang;
        this.name = name;
        this.suggestCase = suggestCase;
        this.businessUnit = businessUnit;
        this.demoFile = demoFile;
    }

    public PilotLocalDao(Pilot pilot, String lang) {
        this.pilotId = pilot.getPilotId();
        this.lang = lang;
        this.name = pilot.getName();
        this.suggestCase = pilot.getSuggestCase();
        this.businessUnit = pilot.getBusinessUnit();
        this.demoFile = pilot.getDemoFile();
    }
}
