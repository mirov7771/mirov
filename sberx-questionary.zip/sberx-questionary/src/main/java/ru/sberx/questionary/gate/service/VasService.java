package ru.sberx.questionary.gate.service;

import ru.sberx.questionary.gate.dto.GetCompanyListRes;

public interface VasService {
    GetCompanyListRes getCompanyList();
}
