package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.DtoBuilder;
import ru.sberx.questionary.controller.dto.res.QuestionaryRes;
import ru.sberx.questionary.controller.dto.res.QuestionnaireGuidListRes;
import ru.sberx.questionary.controller.dto.res.QuestionnaireUIDRes;
import ru.sberx.questionary.controller.dto.support.ImportReplaceDTO;
import ru.sberx.questionary.controller.reply.dto.support.ReplyInfoDTO;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.utils.validator.ConditionValidator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import static ru.sberx.questionary.util.GuideService.LANG_RU;
import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
public class GetQuestionaryMethod {

    private final QuestionnaireRepository questionnaireRepository;
    private final ContactRepository contactRepository;
    private final ProjectRepository projectRepository;
    private final WorkerRepository workerRepository;
    private final RepresentativeRepository representativeRepository;
    private final PilotRepository pilotRepository;
    private final DtoBuilder dtoBuilder;
    private final FeedbackRepository feedbackRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final InvestmentRepository investmentRepository;
    private final FounderRepository founderRepository;
    private final CommunityUserRepository communityUserRepository;
    private final InvestmentClubRepository investmentClubRepository;
    private final SberFiveHundredRepository sberFiveHundredRepository;
    private final ObjectFavoriteRepository objectFavoriteRepository;
    private final QuestionnaireFundsRepository questionnaireFundsRepository;
    private final ObjectActionRepository objectActionRepository;
    private final ReplyRepository replyRepository;
    private final ImportReplaceDAORepository importReplaceDAORepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final ApplicationRepository questionnaireLocaleDaoRepository;
    private final ApplicationRepository investmentLocaleDaoRepository;
    private final ApplicationRepository importReplaceLangDaoRepository;
    private final StatusInfoRepository statusInfoRepository;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;

    public QuestionaryRes execute(Long questionnaireId, String uid, Long parentId, Long userId, String lang, Boolean isEdit) {
        QuestionaryRes res = new QuestionaryRes();
        Questionnaire questionnaire;
        if (questionnaireId == null && parentId == null && uid == null) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        } else if (questionnaireId != null) {
            questionnaire = questionnaireRepository.findByQuestionnaireId(questionnaireId);
            ConditionValidator.preValidate(questionnaire, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            if (questionnaireRepository.findByParentId(questionnaireId) != null)
                res.setIsChild(true);
        } else if (uid != null) {
            questionnaire = questionnaireRepository.findByUuid(UUID.fromString(uid));
            ConditionValidator.preValidate(questionnaire, SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            if (questionnaireRepository.findByParentId(questionnaire.getQuestionnaireId()) != null)
                res.setIsChild(true);
        } else {
            questionnaire = questionnaireRepository.findByParentId(parentId);
            if (questionnaire == null || questionnaire.getQuestionnaireId() == null)
                return null;
        }
        Long id = questionnaire.getQuestionnaireId();
        if (questionnaire.getUuid() == null) {
            questionnaire.setUuid(UUID.randomUUID());
            questionnaireRepository.save(questionnaire);
        }
        if (Boolean.TRUE.equals(isEdit) && StringUtils.hasText(lang)
                && StringUtils.hasText(questionnaire.getMainLanguage())
                && !questionnaire.getMainLanguage().equals(lang)) {
            if (CollectionUtils.isEmpty(statusInfoRepository.findAllByObjectIdAndObjectTypeAndToState(questionnaireId, "Questionnaire", GuideService.CONFIRMED_STATE)))
                cleaning(questionnaire, lang);
        }
        lang = nvl(lang, LANG_RU);
        res.setQuestionnaireId(id);
        res.setQuestionnaire(dtoBuilder.createQuestionnaire(questionnaire, lang));

        List<Contact> contactList = contactRepository.findByQuestionnaireIdAndIsDisabledAndLang(id, false, lang);
        if (CollectionUtils.isEmpty(contactList) && !LANG_RU.equals(lang))
            contactList = contactRepository.findByQuestionnaireIdAndIsDisabledAndLang(id, false, LANG_RU);
        if (CollectionUtils.isEmpty(contactList)) {
            res.setContacts(dtoBuilder.createContactList(contactList));
        }

        Investment investment = investmentRepository.findByQuestionnaireId(id);
        if (investment != null) {
            res.setInvestment(dtoBuilder.createInvestment(investment, lang));
        }
        List<PilotLocalDao> pilotLocalList = pilotLocalDaoRepository.findByQuestionnaireIdInAndLang(List.of(id), lang);
        Map<Long, PilotLocalDao> pilotLocaleDaoMap = CollectionUtils.isEmpty(pilotLocalList)
                ? new HashMap<>()
                : pilotLocalList.stream().collect(Collectors.toMap(PilotLocalDao::getPilotId, Function.identity()));

        List<Pilot> pilotList = pilotRepository.findByQuestionnaireIdAndIsDisabled(id, false);
        if (!CollectionUtils.isEmpty(pilotList)) {
            res.setPilots(dtoBuilder.createPilotList(pilotList, pilotLocaleDaoMap));
            res.setPilot(dtoBuilder.createPilot(pilotList, pilotLocaleDaoMap));
        }

        List<Pilot> b2cPilots = pilotRepository.findByQuestionnaireIdAndIsB2C(id, true);
        if (!CollectionUtils.isEmpty(b2cPilots)) {
            res.setB2cPilots(dtoBuilder.createPilotList(b2cPilots, pilotLocaleDaoMap));
        }

        List<Pilot> b2bPilots = pilotRepository.findByQuestionnaireIdAndIsB2B(id, true);
        if (!CollectionUtils.isEmpty(b2bPilots)) {
            res.setB2bPilots(dtoBuilder.createPilotList(b2bPilots, pilotLocaleDaoMap));
        }

        List<Pilot> successPilots = pilotRepository.findByQuestionnaireIdAndIsSuccess(id, true);
        if (!CollectionUtils.isEmpty(successPilots)) {
            res.setSuccessPilots(dtoBuilder.createPilotList(successPilots, pilotLocaleDaoMap));
        }

        List<Pilot> questionnairePilots = pilotRepository.findByQuestionnaireIdAndIsQuestionnaire(id, true);
        if (!CollectionUtils.isEmpty(questionnairePilots)) {
            res.setQuestionnairePilots(dtoBuilder.createPilotList(questionnairePilots, pilotLocaleDaoMap));
        }

        List<Pilot> ecoPilots = pilotRepository.findByQuestionnaireIdAndEcoSystem(id, true);
        if (!CollectionUtils.isEmpty(ecoPilots)) {
            res.setEcoPilots(dtoBuilder.createPilotList(ecoPilots, pilotLocaleDaoMap));
            res.setEcoPilot(dtoBuilder.createPilot(ecoPilots, pilotLocaleDaoMap));
        }

        Project project = projectRepository.findByQuestionnaireIdAndIsDisabled(id, false);
        if (project != null) {
            res.setProject(dtoBuilder.createProject(project, lang));
        }

        List<Representative> representativeList = representativeRepository.findByQuestionnaireIdAndIsDisabled(id, false);
        if (!CollectionUtils.isEmpty(representativeList)) {
            res.setRepresentatives(dtoBuilder.createRepresentativeList(representativeList));
            res.setRepresentative(dtoBuilder.createRepresentative(representativeList));
        }

        List<Worker> workerList = workerRepository.findByQuestionnaireIdAndIsDisabledAndLang(id, false, lang);
        if (CollectionUtils.isEmpty(workerList) && !LANG_RU.equals(lang))
            workerList = workerRepository.findByQuestionnaireIdAndIsDisabledAndLang(id, false, LANG_RU);
        if (!CollectionUtils.isEmpty(workerList)) {
            res.setWorkers(dtoBuilder.createWorkerList(workerList));
        }

        List<Feedback> feedbacks = feedbackRepository.findByQuestionnaireId(id);
        if (!CollectionUtils.isEmpty(feedbacks)) {
            res.setFeedbacks(dtoBuilder.createFeedBackList(feedbacks));
        }

        List<UserQuestionnaire> users = userQuestionnaireRepository.findByQuestionnaireId(id);
        if (!CollectionUtils.isEmpty(users)) {
            res.setUserId(users.get(0).getUserId());
            res.setUsers(dtoBuilder.createUsers(users));
        }

        List<Founder> founders = founderRepository.findByQuestionnaireId(id);
        if (!CollectionUtils.isEmpty(founders)) {
            res.setFounders(dtoBuilder.createFounders(founders));
        }

        List<CommunityUser> communityUsers = communityUserRepository.findByQuestionnaireId(id);
        if (!CollectionUtils.isEmpty(communityUsers)) {
            res.setCommunityUsers(dtoBuilder.createCommunityUsers(communityUsers));
        }

        List<InvestmentClub> investmentClubs = investmentClubRepository.findByQuestionnaireId(id);
        if (!CollectionUtils.isEmpty(investmentClubs)) {
            res.setInvestorClubs(dtoBuilder.createInvestorClubs(investmentClubs));
        }

        SberFiveHundred sberFiveHundred = sberFiveHundredRepository.findByQuestionnaireId(id);
        if (sberFiveHundred != null) {
            res.setSberFiveHundred(sberFiveHundred.toDto());
        }
        List<QuestionnaireFunds> questionnaireFunds = questionnaireFundsRepository.findByQuestionnaireId(id);
        if (questionnaireFunds != null) {
            res.setQuestionnaireFunds(dtoBuilder.createQuestionnaireFunds(questionnaireFunds));
        }

        ImportReplaceDAO importReplaceDAO = importReplaceDAORepository.findByQuestionnaireId(id);
        if (importReplaceDAO != null
                && importReplaceDAO.getQuestionnaireId() != null) {
            if (Boolean.TRUE.equals(questionnaire.getIsImport())) {
                ImportReplaceDTO importReplaceDTO = dtoBuilder.createImportReplace(importReplaceDAO, lang);
                if (!CollectionUtils.isEmpty(importReplaceDTO.getName())) {
                    res.setImportItems(importReplaceDTO.getName().stream().map(i -> {
                        ImportReplaceDTO.ImportReplaceItemsDTO dto = new ImportReplaceDTO.ImportReplaceItemsDTO();
                        dto.setName(i);
                        return dto;
                    }).collect(Collectors.toList()));
                }
                res.setImportReplace(importReplaceDTO);
            } else {
                importReplaceDAORepository.deleteByQuestionnaireId(id);
            }
        }

        if (userId != null && res.getQuestionnaire() != null) {
            List<Questionnaire> qList = questionnaireRepository.findByUserId(userId);
            if (!CollectionUtils.isEmpty(qList)) {
                List<ObjectFavoriteDao> favorites = objectFavoriteRepository.findByQuestionnaireIdInAndObjectIdAndObjectTypeAndUserId(
                        qList.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList()),
                        res.getQuestionnaireId(),
                        "Questionnaire",
                        userId);
                res.getQuestionnaire().setFavorite(!CollectionUtils.isEmpty(favorites));
            }
            if (objectActionRepository.findByObjectIdAndObjectTypeAndActionAndUserId(res.getQuestionnaireId(), "Questionnaire", "view", userId).isEmpty())
                objectActionRepository.save(new ObjectAction(res.getQuestionnaireId(), "Questionnaire", "view", userId));

            List<ObjectAction> actions = objectActionRepository.findByObjectIdInAndObjectTypeAndAction(List.of(res.getQuestionnaireId()), "Questionnaire", "view");
            res.setViewCount(!CollectionUtils.isEmpty(actions) ? actions.size() : 0);
        }
        res.setEnableOffers(questionnaire.getEnableOffers());

        if (questionnaire.getType().equals(1)) {
            List<Reply> replies = replyRepository.findByTableIdAndTableName(questionnaire.getQuestionnaireId(), "Questionnaire");
            if (!CollectionUtils.isEmpty(replies)) {
                res.setReplies(replies.stream().map(
                        r -> {
                            ReplyInfoDTO dto = new ReplyInfoDTO();
                            dto.setReplyId(r.getReplyId());
                            dto.setState(r.getState());
                            dto.setUserId(r.getUserId());
                            return dto;
                        }
                ).collect(Collectors.toList()));
            }
        }
        return res;
    }

    private void cleaning(Questionnaire questionnaire, String lang) {
        Long id = questionnaire.getQuestionnaireId();
        Project projectDel = projectRepository.findByQuestionnaireIdAndIsDisabled(id, false);
        questionnaire.cleanFields();
        questionnaire.setMainLanguage(lang);
        questionnaire.setLanguages(new String[]{lang});
        questionnaireRepository.save(questionnaire);
        if (projectDel != null)
            projectLocaleDaoRepository.deleteByProjectId(projectDel.getProjectId());
        investmentLocaleDaoRepository.deleteByQuestionnaireId(id);
        questionnaireLocaleDaoRepository.deleteByQuestionnaireId(id);
        pilotLocalDaoRepository.deleteByQuestionnaireId(id);
        pilotRepository.deleteByQuestionnaireId(id);
        workerRepository.deleteById(id);
        importReplaceLangDaoRepository.deleteByQuestionnaireId(id);
        representativeRepository.deleteById(id);
        contactRepository.deleteById(id);
        questionnaireFundsRepository.deleteByQuestionnaireId(id);
        projectRepository.deleteByQuestionnaireId(id);
        investmentClubRepository.deleteById(id);
        investmentRepository.deleteByQuestionnaireId(id);
        sberFiveHundredRepository.deleteByQuestionnaireId(id);
        importReplaceDAORepository.deleteByQuestionnaireId(id);
    }

    public QuestionaryRes execute(Long userId) {
        Questionnaire questionnaire = questionnaireRepository.findConfirmedByUserId(userId);
        if (questionnaire == null || questionnaire.getQuestionnaireId() == null)
            questionnaire = questionnaireRepository.findAllByUserId(userId);
        if (questionnaire == null || questionnaire.getQuestionnaireId() == null)
            return null;
        return execute(questionnaire.getQuestionnaireId(), null, null, null, null, null);
    }

    public QuestionnaireGuidListRes getQuestionnaireGuidList(Integer type) {
        return QuestionnaireGuidListRes.builder()
                .list(questionnaireRepository.getAllByStateAndType(type).stream().map(q -> {
                    QuestionnaireUIDRes uidRes = new QuestionnaireUIDRes();
                    uidRes.setUid(q.getUuid());
                    uidRes.setName(q.getName());
                    return uidRes;
                }).collect(Collectors.toList())).build();
    }

}
