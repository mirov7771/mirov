package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.QueryBuilder;
import ru.sberx.questionary.controller.dto.req.SyndicateReq;
import ru.sberx.questionary.controller.dto.res.GetUserRes;
import ru.sberx.questionary.controller.dto.res.SyndicateRes;
import ru.sberx.questionary.controller.dto.support.Syndicate;
import ru.sberx.questionary.dao.model.ApplicationDao;
import ru.sberx.questionary.dao.model.SyndicateApplication;
import ru.sberx.questionary.dao.repository.ApplicationRepository;
import ru.sberx.questionary.dao.repository.SyndicateApplicationRepository;
import ru.sberx.questionary.gate.dto.Notice;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.gate.service.impl.UserAuthImpl;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.Utils;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class SyndicateMethod {

    private final QueryBuilder queryBuilder;
    private final SyndicateApplicationRepository syndicateApplicationRepository;
    private final ApplicationRepository applicationRepository;
    private final UserAuth userAuth;
    private final MidService midService;

    public SyndicateRes getSyndicateList(SyndicateReq req) {
        SyndicateRes res = new SyndicateRes();
        List<SyndicateApplication> list = queryBuilder.getSyndicateList(req);
        if (req.getRowCount() != null && !list.isEmpty()){
            res.setRowCount(req.getRowCount());
            res.setTotalRowCount(list.size());
            Pair<List<SyndicateApplication>, Integer> shortenList = Utils.pagination(list, req.getRowCount(), req.getPageToken());
            res.setList(shortenList.getFirst().stream().map(SyndicateApplication::toDto).collect(Collectors.toList()));
            res.setTotalPageCount((int) Math.ceil(res.getTotalRowCount()/res.getRowCount().floatValue()));
            res.setNextPageToken(shortenList.getSecond() > 0? shortenList.getSecond(): null);
        } else {
            if (list.isEmpty()) {
                res.setList(null);
            } else
                res.setList(list.stream().map(SyndicateApplication::toDto).collect(Collectors.toList()));
        }
        return res;
    }

    public Syndicate saveSyndicate(Syndicate req) {
        SyndicateApplication syndicateApp = new SyndicateApplication();
        if (syndicateApplicationRepository.findByEmail(req.getEmail()).isPresent())
            throw new SberxException(SberxErrors.SYNDICATE_APPLICATION_EXISTS);
        syndicateApp.setQuestionnaireId(req.getQuestionnaireId());
        syndicateApp.setState(GuideService.PROCESSING_STATE);
        syndicateApp.setModified(new Date());
        syndicateApp.setCreated(new Date());
        req.setType(req.getType() == null ? 2 : req.getType());
        syndicateApp.setType(req.getType());
        syndicateApp.setFirstName(req.getFirstName());
        syndicateApp.setLastName(req.getLastName());
        syndicateApp.setSite(req.getSite());
        syndicateApp.setPosition(req.getPosition());
        syndicateApp.setPhone(req.getPhone());
        syndicateApp.setOrgFullName(req.getOrgFullName());
        syndicateApp.setVentureExperience(req.getVentureExperience());
        syndicateApp.setTelegramLink(req.getTelegramLink());
        syndicateApp.setSumInvestment(req.getSumInvestment());
        syndicateApp.setEmail(req.getEmail());
        syndicateApp.setUid(UUID.randomUUID().toString());
        syndicateApp.setComment(req.getComment());
        syndicateApp.setIsUnity(Boolean.TRUE.equals(req.getIsUnity()));
        syndicateApp.setIsIMoscow(Boolean.TRUE.equals(req.getIsIMoscow()));
        if (Boolean.TRUE.equals(req.getConsent()))
            syndicateApp.setConsent(new Date());
        if (Boolean.TRUE.equals(req.getIMoscowConsent()))
            syndicateApp.setIMoscowConsent(new Date());
        if (Boolean.TRUE.equals(req.getSyndicateConsent()))
            syndicateApp.setSyndicateConsent(new Date());
        syndicateApplicationRepository.save(syndicateApp);
        if (Boolean.TRUE.equals(req.getIsUnity())) {
            applicationRepository.save(new ApplicationDao(req));
        }
        Syndicate res = new Syndicate();
        res.setId(syndicateApp.getId());

        UserAuthImpl.UserList userList = userAuth.getUserList(4);
        List<GetUserRes> users = userList.getList();
        if (!CollectionUtils.isEmpty(users)) {
            List<String> logins = users.stream()
                    .filter(user -> Boolean.TRUE.equals(user.getEnters()))
                    .map(GetUserRes::getLogin)
                    .collect(Collectors.toList());
            logins.forEach(i -> midService.notify("newSyndicateApplication", new HashMap<>(), i));

            //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
            try {
                users.forEach(i -> {
                    Long uid = i.getExternalId() != null ? i.getExternalId() : i.getUserId();
                    if (uid != null) {
                        Notice noticeReq = new Notice();
                        noticeReq.setUserId(uid);
                        noticeReq.setTemplateSysName("newSyndicateApplication");
                        noticeReq.setEvent("Заявка синдиката");
                        noticeReq.setParams(new HashMap<>());
                        midService.notice(noticeReq);
                    }
                });
            } catch (Exception e){
                log.error("Notice error ", e);
            }
        }
        return res;
    }

    public Syndicate getSyndicateQuestionnaire(Long id, String uid) {
        if (id == null && uid == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "required: id || uid");
        Optional<SyndicateApplication> syndicateApplicationOptional;
        if (uid != null)
            syndicateApplicationOptional = syndicateApplicationRepository.findByUid(uid);
        else
            syndicateApplicationOptional = syndicateApplicationRepository.findById(id);
        if (syndicateApplicationOptional.isPresent())
            return syndicateApplicationOptional.get().toDto();
        else
            return new Syndicate();
    }
}
