package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.questionary.controller.dto.res.FeedBackRes;
import ru.sberx.questionary.controller.dto.support.FeedBack;
import ru.sberx.questionary.dao.model.Feedback;
import ru.sberx.questionary.dao.repository.FeedbackRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.utils.validator.ConditionValidator;

@Component
@RequiredArgsConstructor
public class CreateFeedBackMethod {

    private final FeedbackRepository feedbackRepository;
    private final QuestionnaireRepository questionnaireRepository;

    public FeedBackRes execute(FeedBack req){
        ConditionValidator.preValidate(
                questionnaireRepository.findByQuestionnaireId(req.getQuestionnaireId()),
                SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        Feedback f = feedbackRepository.save(new Feedback(req));
        FeedBackRes res = new FeedBackRes();
        res.setFeedbackId(f.getFeedbackId());
        res.setQuestionnaireId(f.getQuestionnaireId());
        return res;
    }

}
