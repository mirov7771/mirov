package ru.sberx.questionary.builder;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.CacheMode;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.controller.dto.req.*;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.model.CommunityApplication_;
import ru.sberx.questionary.dao.model.Investment_;
import ru.sberx.questionary.dao.model.Project_;
import ru.sberx.questionary.dao.model.Questionnaire_;
import ru.sberx.questionary.dao.model.RoundDao_;
import ru.sberx.questionary.dao.model.RoundFavorite_;
import ru.sberx.questionary.dao.model.SyndicateApplication_;
import ru.sberx.questionary.dao.util.HibernateUtil;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.criteria.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class QueryBuilder {

    private final HibernateUtil hibernateUtil;

    @Value("${db.max.row.count:1000}")
    private int maxRowCount;

    private static final DateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");

    public List<Questionnaire> getListByCriterias(QuestionnaireListReq req) {
        int max = req.getRowCount() != null ? req.getRowCount() : maxRowCount;
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            session.setCacheMode(CacheMode.GET);
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<Questionnaire> cr = cb.createQuery(Questionnaire.class);
            Root<Questionnaire> root = cr.from(Questionnaire.class);
            cr.select(root);

            List<Predicate> predicates = new ArrayList<>();

            predicates.add(cb.equal(root.get(Questionnaire_.TYPE), req.getType()));
            if (!Boolean.TRUE.equals(req.getIsBran()))
                predicates.add(cb.equal(root.get(Questionnaire_.IS_BRAN), false));
            if (req.getIsDisabled() != null)
                predicates.add(cb.equal(root.get(Questionnaire_.IS_DISABLED), req.getIsDisabled()));
            else
                predicates.add(cb.equal(root.get(Questionnaire_.IS_DISABLED), false));
            if (req.getState() != null && req.getState().size() > 0)
                predicates.add(root.get(Questionnaire_.STATE).in(req.getState()));
            else
                predicates.add(cb.equal(root.get(Questionnaire_.STATE), GuideService.CONFIRMED_STATE));
            if (req.getCommunityState() != null)
                predicates.add(cb.equal(root.get(Questionnaire_.COMMUNITY_STATE), req.getCommunityState()));
            if (req.getName() != null) {
                String[] names = req.getName().split(" ");
                Subquery<QuestionnaireLocaleDao> subQuery = cr.subquery(QuestionnaireLocaleDao.class);
                Root<QuestionnaireLocaleDao> qlRoot = subQuery.from(QuestionnaireLocaleDao.class);
                List<Predicate> qlPredicates = new ArrayList<>();
                qlPredicates.add(cb.equal(qlRoot.get(QuestionnaireLocaleDao_.QUESTIONNAIRE_ID), root.get(Questionnaire_.QUESTIONNAIRE_ID)));
                Predicate pr = null;
                for (String n : names) {
                    pr = cb.or(cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.NAME)), "%" + n.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.FULL_NAME)), "%" + n.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.INVITE_FIO)), "%" + n.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.EMAIL)), "%" + n.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.INN)), "%" + n.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.NOTE)), "%" + n.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(QuestionnaireLocaleDao_.FULL_NOTE)), "%" + n.toUpperCase() + "%"));
                }
                qlPredicates.add(pr);
                Predicate[] qlPrs = new Predicate[qlPredicates.size()];
                subQuery.select(qlRoot)
                        .where(qlPredicates.toArray(qlPrs));
                predicates.add(cb.exists(subQuery));
            }
            if (Boolean.TRUE.equals(req.getSite()))
                predicates.add(cb.isNotNull(root.get(Questionnaire_.SITE)));
            if (req.getLocation() != null)
                predicates.add(cb.like(root.get(Questionnaire_.LOCATION), "%" + req.getLocation() + "%"));
            if (req.getInvestorType() != null && req.getInvestorType().size() > 0)
                predicates.add(root.get(Questionnaire_.INVESTOR_TYPE).in(req.getInvestorType()));
            if (req.getRegistrationCountry() != null && req.getRegistrationCountry().size() > 0)
                predicates.add(root.get(Questionnaire_.LOCATION).in(req.getLocation()));
            if (req.getLocationCountry() != null && req.getLocationCountry().size() > 0)
                predicates.add(root.get(Questionnaire_.LOCATION_COUNTRY).in(req.getLocationCountry()));

            if (req.getIndustry() != null && req.getType() != null && GuideService.INVESTOR.equals(req.getType())) {
                if (req.getInvestmentIndustry() == null)
                    req.setInvestmentIndustry(new ArrayList<>());
                req.getInvestmentIndustry().addAll(req.getIndustry());
                req.setIndustry(null);
            }
            if (req.getInnovationMethod() != null && req.getInnovationMethod().size() > 0)
                prepareArrayQuery(predicates, root, cb, req.getInnovationMethod(), Questionnaire_.INNOVATION_METHOD);
            if (req.getStady() != null && req.getStady().size() > 0 && req.getType() != null) {
                if (GuideService.CORPORATE.equals(req.getType()))
                    prepareArrayQuery(predicates, root, cb, req.getStady(), Questionnaire_.STADY);
                else if (GuideService.STARTUP.equals(req.getType())) {
                    if (req.getMvpCode() == null)
                        req.setMvpCode(new ArrayList<>());
                    req.getMvpCode().addAll(req.getStady());
                }
            }
            if (req.getBusinessModel() != null && req.getBusinessModel().size() > 0)
                prepareArrayQuery(predicates, root, cb, req.getBusinessModel(), Questionnaire_.BUSINESS_MODEL);
            if (req.getTechnology() != null && req.getTechnology().size() > 0 && req.getType() != null) {
                if (GuideService.INVESTOR.equals(req.getType())) {
                    if (req.getInvestmentTechnology() == null)
                        req.setInvestmentTechnology(new ArrayList<>());
                    req.getInvestmentTechnology().addAll(req.getTechnology());
                } else {
                    if (req.getProjectTechnology() == null)
                        req.setProjectTechnology(new ArrayList<>());
                    req.getProjectTechnology().addAll(req.getTechnology());
                }
                req.setTechnology(null);
            }

            if (req.getGeography() != null && req.getGeography().size() > 0 && req.getType() != null) {
                if (GuideService.INVESTOR.equals(req.getType())) {
                    if (req.getInvestmentGeography() == null)
                        req.setInvestmentGeography(new ArrayList<>());
                    req.getInvestmentGeography().addAll(req.getGeography());
                } else {
                    if (req.getProjectGeography() == null)
                        req.setProjectGeography(new ArrayList<>());
                    req.getProjectGeography().addAll(req.getGeography());
                }
                req.setGeography(null);
            }

            if ((Boolean.TRUE.equals(req.getInvestment()))
                    || (req.getInvestmentTechnology() != null && req.getInvestmentTechnology().size() > 0)
                    || (req.getInvestmentGeography() != null && req.getInvestmentGeography().size() > 0)
                    || (req.getInvestmentIndustry() != null && req.getInvestmentIndustry().size() > 0)
                    || (req.getRound() != null && req.getRound().size() > 0)) {
                Subquery<Investment> subQuery = cr.subquery(Investment.class);
                Root<Investment> invRoot = subQuery.from(Investment.class);
                List<Predicate> invPredicates = new ArrayList<>();
                invPredicates.add(cb.equal(invRoot.get(Investment_.QUESTIONNAIRE_ID), root.get(Questionnaire_.QUESTIONNAIRE_ID)));
                if ((Boolean.TRUE.equals(req.getInvestment())))
                    invPredicates.add(cb.equal(invRoot.get(Investment_.INVESTMENT), true));
                if (req.getInvestmentTechnology() != null && req.getInvestmentTechnology().size() > 0)
                    prepareArrayQuery(invPredicates, invRoot, cb, req.getInvestmentTechnology(), Investment_.TECHNOLOGY);
                if (req.getInvestmentGeography() != null && req.getInvestmentGeography().size() > 0)
                    prepareArrayQuery(invPredicates, invRoot, cb, req.getInvestmentGeography(), Investment_.GEOGRAPHY);
                if (req.getInvestmentIndustry() != null && req.getInvestmentIndustry().size() > 0)
                    prepareArrayQuery(invPredicates, invRoot, cb, req.getInvestmentIndustry(), Investment_.INDUSTRY);
                if (req.getRound() != null && req.getRound().size() > 0)
                    prepareArrayQuery(invPredicates, invRoot, cb, req.getRound(), Investment_.ROUND);
                Predicate[] invPrs = new Predicate[invPredicates.size()];
                subQuery.select(invRoot)
                        .where(invPredicates.toArray(invPrs));
                predicates.add(cb.exists(subQuery));
            }

            if ((req.getMvpCode() != null && req.getMvpCode().size() > 0)
                    || (req.getProjectTechnology() != null && req.getProjectTechnology().size() > 0)
                    || (req.getProjectGeography() != null && req.getProjectGeography().size() > 0)
                    || (req.getInteractionType() != null && req.getInteractionType().size() > 0)
                    || (req.getStaff() != null && req.getStaff().size() > 0)
                    || (req.getIndustry() != null && req.getIndustry().size() > 0)
                    || req.getSales() != null) {
                Subquery<Project> subProject = cr.subquery(Project.class);
                Root<Project> projectRoot = subProject.from(Project.class);
                List<Predicate> projectPredicates = new ArrayList<>();
                projectPredicates.add(cb.equal(projectRoot.get(Project_.QUESTIONNAIRE_ID), root.get(Questionnaire_.QUESTIONNAIRE_ID)));
                if (req.getMvpCode() != null && req.getMvpCode().size() > 0)
                    prepareArrayQuery(projectPredicates, projectRoot, cb, req.getMvpCode(), Project_.MVP_CODE);
                if (req.getProjectTechnology() != null && req.getProjectTechnology().size() > 0)
                    prepareArrayQuery(projectPredicates, projectRoot, cb, req.getProjectTechnology(), Project_.TECHNOLOGY);
                if (req.getProjectGeography() != null && req.getProjectGeography().size() > 0)
                    prepareArrayQuery(projectPredicates, projectRoot, cb, req.getProjectGeography(), Project_.GEOGRAPHY);
                if (req.getInteractionType() != null && req.getInteractionType().size() > 0)
                    prepareArrayQuery(projectPredicates, projectRoot, cb, req.getInteractionType(), Project_.INTERACTION_TYPE);
                if (req.getStaff() != null && req.getStaff().size() > 0) {
                    List<GuideService.Staff> staffList = req.getStaff()
                            .stream()
                            .map(GuideService.Staff::getStaff)
                            .collect(Collectors.toList());
                    if (staffList.size() > 0) {
                        List<Integer> vals = staffList.stream().map(GuideService.Staff::getMinValue).collect(Collectors.toList());
                        vals.addAll(staffList.stream().map(GuideService.Staff::getMaxValue).collect(Collectors.toList()));
                        if (vals.size() > 0) {
                            Integer minValue = vals.stream().mapToInt(v -> v).min().orElse(0);
                            Integer maxValue = vals.stream().mapToInt(v -> v).max().orElse(0);
                            projectPredicates.add(cb.between(projectRoot.get(Project_.STAFF), minValue, maxValue));
                        }
                    }
                }
                if (req.getIndustry() != null && req.getIndustry().size() > 0)
                    prepareArrayQuery(projectPredicates, projectRoot, cb, req.getIndustry(), Project_.INDUSTRY);
                if (req.getSales() != null) {
                    prepareArrayQuery(projectPredicates, projectRoot, cb,
                            Boolean.TRUE.equals(req.getSales()) ? List.of(5002L, 5003L, 5004L) : List.of(5001L),
                            Project_.SALES);
                }
                Predicate[] projectPrs = new Predicate[projectPredicates.size()];
                subProject.select(projectRoot)
                        .where(projectPredicates.toArray(projectPrs));
                predicates.add(cb.exists(subProject));
            }

            if (Boolean.TRUE.equals(req.getForLending()))
                predicates.add(cb.equal(root.get(Questionnaire_.FOR_LENDING), true));

            if (Boolean.TRUE.equals(req.getIsImport()))
                predicates.add(cb.equal(root.get(Questionnaire_.IS_IMPORT), true));

            if (Boolean.TRUE.equals(req.getSber500()))
                predicates.add(cb.equal(root.get(Questionnaire_.SBER500), true));

            try {
                if (req.getFromDateTime() != null) {
                    Date toDate = req.getToDateTime() == null ? new Date() : dateTimeFormat.parse(req.getToDateTime().replace(" ", "+"));
                    predicates.add(cb.between(root.get(Questionnaire_.MODIFIED), dateTimeFormat.parse(req.getFromDateTime().replace(" ", "+")), toDate));
                }
            } catch (ParseException e) {
                log.error("Error while parsing date", e);
            }

            if (Boolean.TRUE.equals(req.getFavorite()) && req.getQId() != null) {
                Subquery<ObjectFavoriteDao> subFav = cr.subquery(ObjectFavoriteDao.class);
                Root<ObjectFavoriteDao> fRoot = subFav.from(ObjectFavoriteDao.class);
                List<Predicate> fPredicates = new ArrayList<>();
                fPredicates.add(cb.equal(fRoot.get(ObjectFavoriteDao_.OBJECT_ID), root.get(Questionnaire_.QUESTIONNAIRE_ID)));
                fPredicates.add(cb.equal(fRoot.get(ObjectFavoriteDao_.QUESTIONNAIRE_ID), req.getQId()));
                fPredicates.add(cb.equal(fRoot.get(ObjectFavoriteDao_.OBJECT_TYPE), "Questionnaire"));
                fPredicates.add(cb.equal(fRoot.get(ObjectFavoriteDao_.USER_ID), req.getQUserId()));

                if (StringUtils.hasText(req.getRole()) && req.getRole().toLowerCase().contains("demo")){
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(new Date());
                    cal.add(Calendar.DATE, -30);
                    fPredicates.add(cb.greaterThan(fRoot.get(ObjectFavoriteDao_.MODIFIED), cal.getTime()));
                }

                Predicate[] fPrs = new Predicate[fPredicates.size()];
                subFav.select(fRoot)
                        .where(fPredicates.toArray(fPrs));
                predicates.add(cb.exists(subFav));
            }

            if (Boolean.TRUE.equals(req.getRecommend())) {
                Subquery<RecommendLink> rlFav = cr.subquery(RecommendLink.class);
                Root<RecommendLink> rlRoot = rlFav.from(RecommendLink.class);
                List<Predicate> rlPredicates = new ArrayList<>();
                rlPredicates.add(cb.equal(rlRoot.get(RecommendLink_.RECOMMEND_QUESTIONNAIRE_ID), root.get(Questionnaire_.QUESTIONNAIRE_ID)));
                rlPredicates.add(cb.equal(rlRoot.get(ObjectFavoriteDao_.QUESTIONNAIRE_ID), req.getQId()));
                Predicate[] fPrs = new Predicate[rlPredicates.size()];
                rlFav.select(rlRoot)
                        .where(rlPredicates.toArray(fPrs));
                predicates.add(cb.exists(rlFav));
            }

            if (Boolean.TRUE.equals(req.getView()) && req.getQUserId() != null) {
                Subquery<ObjectAction> subAction = cr.subquery(ObjectAction.class);
                Root<ObjectAction> aRoot = subAction.from(ObjectAction.class);
                List<Predicate> aPredicates = new ArrayList<>();
                aPredicates.add(cb.equal(aRoot.get(ObjectAction_.OBJECT_ID), root.get(Questionnaire_.QUESTIONNAIRE_ID)));
                aPredicates.add(cb.equal(aRoot.get(ObjectAction_.USER_ID), req.getQUserId()));
                aPredicates.add(cb.equal(aRoot.get(ObjectAction_.OBJECT_TYPE), "Questionnaire"));
                aPredicates.add(cb.equal(aRoot.get(ObjectAction_.ACTION), "view"));

                if (StringUtils.hasText(req.getRole()) && req.getRole().toLowerCase().contains("demo")){
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(new Date());
                    cal.add(Calendar.DATE, -30);
                    aPredicates.add(cb.greaterThan(aRoot.get(ObjectAction_.CREATED), cal.getTime()));
                }

                Predicate[] aPrs = new Predicate[aPredicates.size()];
                subAction.select(aRoot)
                        .where(aPredicates.toArray(aPrs));
                predicates.add(cb.exists(subAction));
            }

            if (req.getResponsible() != null) {
                predicates.add(cb.equal(root.get(Questionnaire_.RESPONSIBLE), req.getResponsible()));
            }

            if (Boolean.TRUE.equals(req.getMain())) {
                predicates.add(cb.isNull(root.get(Questionnaire_.PARENT_ID)));
            }
            if (Boolean.FALSE.equals(req.getMain())) {
                predicates.add(cb.isNotNull(root.get(Questionnaire_.PARENT_ID)));
            }

            if (req.getEnableOffers() != null) {
                predicates.add(cb.equal(root.get(Questionnaire_.ENABLE_OFFERS), req.getEnableOffers()));
            }

            if (req.getStartBirthDate() != null) {
                int endDate = req.getEndBirthDate() != null ? req.getEndBirthDate() : LocalDateTime.now().getYear();
                Calendar cal = Calendar.getInstance();
                cal.set(req.getStartBirthDate(), Calendar.JANUARY, 1);
                Date startBDate = cal.getTime();
                cal.set(endDate, Calendar.DECEMBER, 31);
                Date endBDate = cal.getTime();
                predicates.add(cb.between(root.get(Questionnaire_.BIRTH_DAY), startBDate, endBDate));
            }

            Predicate[] prs = new Predicate[predicates.size()];
            cr.where(predicates.toArray(prs));
            if (req.getSortBy() != null) {
                if ("DESC".equalsIgnoreCase(req.getOrderBy())) {
                    cr.orderBy(cb.desc(root.get(req.getSortBy())));
                } else {
                    cr.orderBy(cb.asc(root.get(req.getSortBy())));
                }
            } else if (req.getType() != 0) {
                cr.orderBy(cb.desc(Boolean.TRUE.equals(req.getForLending()) ? root.get("priority") : root.get("modified")));
            } else {
                cr.orderBy(cb.desc(root.get(Questionnaire_.UPDATE_DATE_FOR_SORT)));
            }
            Query<Questionnaire> query = session.createQuery(cr).setMaxResults(max);
            return query.getResultList();
        }
    }

    public List<ApplicationDao> getApplicationList(ApplicationListReq req) {
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<ApplicationDao> cr = cb.createQuery(ApplicationDao.class);
            Root<ApplicationDao> root = cr.from(ApplicationDao.class);
            List<Predicate> predicates = new ArrayList<>();
            if (req.getType() != null) {
                predicates.add(cb.equal(root.get(ApplicationDao_.TYPE), req.getType()));
            }
            if (!ObjectUtils.isEmpty(req.getState())) {
                List<Long> states = req.getState();
                if (states.size() == 1) {
                    Long state = states.get(0);
                    predicates.add(cb.equal(root.get(ApplicationDao_.STATE), state));
                } else {
                    predicates.add(root.get(ApplicationDao_.STATE).in(states));
                }
            }
            if (req.getName() != null) {
                String[] names = req.getName().split(" ");
                Predicate pr = null;
                for (String name: names) {
                    pr = cb.or(cb.like(cb.upper(root.get(ApplicationDao_.FIRST_NAME)), "%" + name.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(ApplicationDao_.LAST_NAME)), "%" + name.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(ApplicationDao_.EMAIL)), "%" + name.toUpperCase() + "%"));
                    pr = cb.or(pr, cb.like(cb.upper(root.get(ApplicationDao_.ORG_FULL_NAME)), "%" + name.toUpperCase() + "%"));
                }
                predicates.add(pr);
            }
            if (req.getSortBy() != null){
                if (req.getSortBy().equalsIgnoreCase("name"))
                    req.setSortBy(ApplicationDao_.ORG_FULL_NAME);
                if ("DESC".equalsIgnoreCase(req.getOrderBy())){
                    cr.orderBy(cb.desc(root.get(req.getSortBy())));
                } else {
                    cr.orderBy(cb.asc(root.get(req.getSortBy())));
                }
            } else {
                cr.orderBy(cb.desc(root.get(ApplicationDao_.CREATED)));
            }
            cr.where(predicates.toArray(new Predicate[0]));
            Query<ApplicationDao> query = session.createQuery(cr);
            return query.getResultList();
        }
    }

    public List<RoundDao> getRoundList(RoundListReq req, Long userId){
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<RoundDao> cr = cb.createQuery(RoundDao.class);
            Root<RoundDao> root = cr.from(RoundDao.class);
            List<Predicate> predicates = new ArrayList<>();
            if (req.getQuestionnaireId() != null)
                predicates.add(cb.equal(root.get(RoundDao_.QUESTIONNAIRE_ID), req.getQuestionnaireId()));
            if (req.getInvestment() != null)
                predicates.add(cb.equal(root.get(RoundDao_.INVESTMENT), req.getInvestment()));
            if (req.getState() != null && req.getState().size() > 0)
                prepareArrayQuery(predicates, root, cb, req.getState(), RoundDao_.STATE);
            if (req.getName() != null){
                Subquery<Questionnaire> subQuery = cr.subquery(Questionnaire.class);
                Root<Questionnaire> qRoot = subQuery.from(Questionnaire.class);
                List<Predicate> qPredicates = new ArrayList<>();
                qPredicates.add(cb.equal(qRoot.get(Questionnaire_.QUESTIONNAIRE_ID), root.get(RoundDao_.QUESTIONNAIRE_ID)));
                qPredicates.add(cb.like(cb.upper(qRoot.get(Questionnaire_.NAME)), "%" + req.getName().toUpperCase()+ "%"));
                Predicate[] invPrs = new Predicate[qPredicates.size()];
                subQuery.select(qRoot)
                        .where(qPredicates.toArray(invPrs));
                predicates.add(cb.exists(subQuery));
            }
            if (Boolean.TRUE.equals(req.getFavorite()) && req.getQId() != null && userId != null){
                Subquery<RoundFavorite> subFav = cr.subquery(RoundFavorite.class);
                Root<RoundFavorite> fRoot = subFav.from(RoundFavorite.class);
                List<Predicate> fPredicates = new ArrayList<>();
                fPredicates.add(cb.equal(fRoot.get(RoundFavorite_.ROUND_ID), root.get(RoundDao_.ROUND_ID)));
                fPredicates.add(cb.equal(fRoot.get(RoundFavorite_.QUESTIONNAIRE_ID), req.getQId()));
                fPredicates.add(cb.equal(fRoot.get(RoundFavorite_.USER_ID), userId));
                Predicate[] fPrs = new Predicate[fPredicates.size()];
                subFav.select(fRoot)
                        .where(fPredicates.toArray(fPrs));
                predicates.add(Boolean.TRUE.equals(req.getFavorite()) ? cb.exists(subFav) : cb.not(cb.exists(subFav)));
            }
            if (req.getSortBy() != null){
                if (req.getSortBy().equals("startupName") || req.getSortBy().equals("name")){
                    if ("DESC".equalsIgnoreCase(req.getOrderBy())){
                        cr.orderBy(cb.desc(root.join(RoundDao_.QUESTIONNAIRE).get(Questionnaire_.NAME)));
                    } else {
                        cr.orderBy(cb.asc(root.join(RoundDao_.QUESTIONNAIRE).get(Questionnaire_.NAME)));
                    }
                } else {
                    if ("DESC".equalsIgnoreCase(req.getOrderBy())){
                        cr.orderBy(cb.desc(root.get(req.getSortBy())));
                    } else {
                        cr.orderBy(cb.asc(root.get(req.getSortBy())));
                    }
                }
            } else {
                cr.orderBy(cb.desc(root.get(RoundDao_.MODIFIED)));
            }
            cr.where(predicates.toArray(new Predicate[0]));
            Query<RoundDao> query = session.createQuery(cr);
            return query.getResultList();
        }
    }

    public List<CommunityApplication> getCommunityList(CommunityListReq req){
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<CommunityApplication> cr = cb.createQuery(CommunityApplication.class);
            Root<CommunityApplication> root = cr.from(CommunityApplication.class);
            List<Predicate> predicates = new ArrayList<>();
            if (req.getQuestionnaireId() != null)
                predicates.add(cb.equal(root.get(CommunityApplication_.QUESTIONNAIRE_ID), req.getQuestionnaireId()));
            if (req.getName() != null)
                predicates.add(cb.like(cb.upper(root.get(CommunityApplication_.NAME)), "%" + req.getName().toUpperCase() + "%"));
            if (req.getState() != null && req.getState().size() > 0)
                prepareArrayQuery(predicates, root, cb, req.getState(), CommunityApplication_.STATE);
            if (req.getType() != null){
                predicates.add(root.get(CommunityApplication_.TYPE).in(
                        req.getType().equals(0)
                                ? List.of(0L)
                                : (req.getType().equals(1)
                                        ? List.of(4L)
                                        : List.of(1L, 2L, 3L))));
            }
            if (req.getPreauth() != null){
                predicates.add(cb.equal(root.get(CommunityApplication_.PRE_AUTH), req.getPreauth()));
            }
            if (req.getSortBy() != null){
                if ("DESC".equalsIgnoreCase(req.getOrderBy())){
                    cr.orderBy(cb.desc(root.get(req.getSortBy())));
                } else {
                    cr.orderBy(cb.asc(root.get(req.getSortBy())));
                }
            } else {
                cr.orderBy(cb.desc(root.get(CommunityApplication_.MODIFIED)));
            }
            cr.where(predicates.toArray(new Predicate[0]));
            Query<CommunityApplication> query = session.createQuery(cr);
            return query.getResultList();
        }
    }

    public List<SyndicateApplication> getSyndicateList(SyndicateReq req){
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<SyndicateApplication> cr = cb.createQuery(SyndicateApplication.class);
            Root<SyndicateApplication> root = cr.from(SyndicateApplication.class);
            List<Predicate> predicates = new ArrayList<>();
            if (!CollectionUtils.isEmpty(req.getState())){
                predicates.add((root.get(SyndicateApplication_.STATE).in(req.getState())));
            }
            if (req.getName() != null){
                Predicate pr;
                pr = cb.or(cb.like(cb.upper(root.get(SyndicateApplication_.FIRST_NAME)), "%" + req.getName().toUpperCase() + "%"));
                pr = cb.or(pr, cb.like(cb.upper(root.get(SyndicateApplication_.LAST_NAME)), "%" + req.getName().toUpperCase() + "%"));
                pr = cb.or(pr, cb.like(cb.upper(root.get(SyndicateApplication_.ORG_FULL_NAME)), "%" + req.getName().toUpperCase() + "%"));
                pr = cb.or(pr, cb.like(cb.upper(root.get(SyndicateApplication_.EMAIL)), "%" + req.getName().toUpperCase() + "%"));
                predicates.add(pr);
            }
            if (req.getDateFrom() != null) {
                predicates.add(cb.greaterThan(root.get(SyndicateApplication_.CREATED),
                        Date.from(Instant.ofEpochSecond(req.getDateFrom()))));
            }
            if (req.getDateTo() != null) {
                predicates.add(cb.lessThanOrEqualTo(root.get(SyndicateApplication_.CREATED),
                        Date.from(Instant.ofEpochSecond(req.getDateTo()))));
            }
            cr.where(predicates.toArray(new Predicate[0]));
            cr.orderBy(cb.desc(root.get(SyndicateApplication_.MODIFIED)));
            Query<SyndicateApplication> query = session.createQuery(cr);
            return query.getResultList();
        }
    }

    public List<ScoutingApplication> getScoutingList(ScoutingListReq req){
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<ScoutingApplication> cr = cb.createQuery(ScoutingApplication.class);
            Root<ScoutingApplication> root = cr.from(ScoutingApplication.class);
            List<Predicate> predicates = new ArrayList<>();
            if (!CollectionUtils.isEmpty(req.getState()))
                predicates.add(root.get(ScoutingApplication_.STATE).in(req.getState()));
            if (StringUtils.hasText(req.getName()))
                predicates.add(cb.like(cb.upper(root.get(ScoutingApplication_.NAME)), "%" + req.getName().toUpperCase() + "%"));
            if (req.getQuestionnaireId() != null)
                predicates.add(cb.equal(root.get(ScoutingApplication_.QUESTIONNAIRE_ID), req.getQuestionnaireId()));
            cr.where(predicates.toArray(new Predicate[]{}));
            cr.orderBy(cb.desc(root.get(ScoutingApplication_.MODIFIED)));
            Query<ScoutingApplication> query = session.createQuery(cr);
            return query.getResultList();
        }
    }

    private void prepareArrayQuery(List<Predicate> predicates,
                                   Root<?> root, CriteriaBuilder cb,
                                   List<Long> list, String key)
    {
        Expression<String> s = root.get(key).as(String.class);
        Predicate pr = null;
        for (Long i : list) {
            if (pr == null) {
                pr = cb.or(cb.like(s, "%" + i + "%"));
            } else {
                pr = cb.or(pr, cb.like(s, "%" + i + "%"));
            }
        }
        predicates.add(pr);
    }

}
