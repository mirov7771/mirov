package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.custom.QuestionnaireCustomRepository;
import ru.sberx.questionary.dao.model.Questionnaire;

import javax.transaction.Transactional;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Repository
public interface QuestionnaireRepository extends CrudRepository<Questionnaire, Long>, QuestionnaireCustomRepository {
    @Query(value = "select q.* from user_questionnaire u inner join questionnaire q on u.questionnaireid = q.questionnaireid where u.userid = :userId and q.isdisabled = false order by q.created desc", nativeQuery = true)
    List<Questionnaire> findByUserId(@Param("userId") Long userId);
    @Query(value = "select q.* from user_questionnaire u inner join questionnaire q on u.questionnaireid = q.questionnaireid where u.userid = :userId order by q.created desc", nativeQuery = true)
    List<Questionnaire> findByUserIdAll(@Param("userId") Long userId);
    Questionnaire findByQuestionnaireId(Long questionnaireId);
    Questionnaire findByUuid(UUID uid);
    Questionnaire findByQuestionnaireIdAndIsDisabled(Long questionnaireId, Boolean isDisabled);
    List<Questionnaire> findByQuestionnaireIdIn(Collection<Long> questionnaireIds);
    Questionnaire findByQuestionnaireIdAndType(Long questionnaireId, Integer type);
    List<Questionnaire> findByTypeAndStateOrderByModifiedDesc(Integer type, Long state);
    Optional<Questionnaire> findByPriority(Integer priority);
    @Query(value = "select * from questionnaire q where parentid = :parentId order by modified limit 1", nativeQuery = true)
    Questionnaire findByParentId(@Param("parentId") Long parentId);
    @Modifying
    @Transactional
    @Query("update Questionnaire set priority = priority - 1 where priority is not null and priority <= :priority")
    void updatePriorities(Integer priority);
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);
    @Query(value = "select q.* from user_questionnaire u inner join questionnaire q on u.questionnaireid = q.questionnaireid where u.userid = :userId and q.isdisabled = false and q.state = 20004 limit 1", nativeQuery = true)
    Questionnaire findConfirmedByUserId(@Param("userId") Long userId);
    @Query(value = "select q.* from user_questionnaire u inner join questionnaire q on u.questionnaireid = q.questionnaireid where u.userid = :userId and q.isdisabled = false order by created limit 1", nativeQuery = true)
    Questionnaire findAllByUserId(@Param("userId") Long userId);
    List<Questionnaire> findAllByStateAndTypeAndSendInvestPlanNotifyAndEmailNotNull(Long state, Integer type, Boolean sendInvestPlanNotify);
    @Query(value = "select * from questionnaire q where parentid in :parentId", nativeQuery = true)
    List<Questionnaire> findAllByParentIds(@Param("parentId") Set<Long> parentId);
    //STARTUPHUB-4074 [БЭК] Обходчик анкет на доработке
    @Query(value = "select *" +
            "  from questionnaire q" +
            " where q.state = 20003\n" +
            "   and exists (select 1 " +
            "     from status_info si " +
            "    where si.object_id = q.questionnaireid" +
            "      and si.object_type = 'Questionnaire'" +
            "      and si.date <  current_date - 14" +
            "      and si.date >=  current_date - 16)" +
            "   and not exists (select 1 " +
            "     from status_info si2 " +
            "    where si2.object_id = q.questionnaireid" +
            "      and si2.object_type = 'Questionnaire'" +
            "      and si2.date >=  current_date - 14)" +
            "      and is_send_processing != true", nativeQuery = true)
    List<Questionnaire> findEditQuestionnaires();
    @Modifying
    @Transactional
    @Query(value = "update QUESTIONNAIRE set NOT_NEW = true where QUESTIONNAIREID = :questionnaireId or PARENTID = :questionnaireId", nativeQuery = true)
    void updateNotNewFlag(@Param("questionnaireId") Long questionnaireId);
    @Query(value = "select q.* from questionnaire q where q.type = :type and q.isdisabled = false and q.state = 20004", nativeQuery = true)
    List<Questionnaire> getAllByStateAndType(@Param("type") Integer type);
    @Modifying
    @Transactional
    @Query(value = "update QUESTIONNAIRE set is_send_processing = true where QUESTIONNAIREID in :questionnaireId", nativeQuery = true)
    void updateIsSendProcessing(@Param("questionnaireId") Set<Long> questionnaireId);
    @Modifying
    @Transactional
    @Query(value = "update QUESTIONNAIRE set IS_MARKETING = :flag where QUESTIONNAIREID = :id", nativeQuery = true)
    void updateMarketing(@Param("id") Long id, @Param("flag") String flag);
    @Query(value = "select * from questionnaire q where type = 0 and state = 20004 and modified <= current_date - 60", nativeQuery = true)
    List<Questionnaire> findOldConfirmedQuestionnaire();
    @Query(value = "update QUESTIONNAIRE set IS_IMPORT = :flag where QUESTIONNAIREID = :id", nativeQuery = true)
    @Modifying
    @Transactional
    void updateImport(@Param("id") Long id, @Param("flag") Boolean flag);
    @Query(value = "select q.* from user_questionnaire u inner join questionnaire q on u.questionnaireid = q.questionnaireid where u.userid in :userId", nativeQuery = true)
    List<Questionnaire> findByUserIdIn(@Param("userId")List<Long> userId);
    @Query(value = "select * from questionnaire q where mod(current_date - date(q.created), :days) = 0 and current_date != date(q.created)", nativeQuery = true)
    List<Questionnaire> findByModCurrentDateCreatedDate(@Param("days") Integer days);
}
