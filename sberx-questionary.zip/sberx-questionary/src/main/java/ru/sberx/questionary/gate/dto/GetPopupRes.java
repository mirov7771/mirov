package ru.sberx.questionary.gate.dto;

import lombok.Data;
import ru.sberx.questionary.controller.dto.res.PopupStatusRes;

@Data
public class GetPopupRes {

    private String status;
    private PopupStatusRes settings;
}
