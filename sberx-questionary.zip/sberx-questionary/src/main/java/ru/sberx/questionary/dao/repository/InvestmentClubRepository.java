package ru.sberx.questionary.dao.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.InvestmentClub;

@Repository
public interface InvestmentClubRepository extends CrudRepository<InvestmentClub, Long> {

    List<InvestmentClub> findByQuestionnaireId(Long questionnaireId);
    @Transactional
    @Modifying
    @Query("delete from InvestmentClub where questionnaireId = :questionnaireId")
    void deleteById(@Param("questionnaireId") Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update InvestmentClub set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

}
