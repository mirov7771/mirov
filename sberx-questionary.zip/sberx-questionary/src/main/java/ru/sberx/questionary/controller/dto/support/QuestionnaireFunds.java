package ru.sberx.questionary.controller.dto.support;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class QuestionnaireFunds {

    private Long fundId;
    private Long questionnaireId;
    private String budget;
    private String avgInvestment;

    public QuestionnaireFunds(ru.sberx.questionary.dao.model.QuestionnaireFunds questionnaireFunds) {
        this.fundId = questionnaireFunds.getFundId();
        this.questionnaireId = questionnaireFunds.getQuestionnaireId();
        this.budget = questionnaireFunds.getBudget();
        this.avgInvestment = questionnaireFunds.getAvgInvestment();
    }

}
