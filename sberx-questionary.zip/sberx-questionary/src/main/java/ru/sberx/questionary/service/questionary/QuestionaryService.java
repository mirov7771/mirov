package ru.sberx.questionary.service.questionary;

import ru.sberx.questionary.controller.dto.res.DefaultRes;

public interface QuestionaryService {
    DefaultRes lastEnter(Long userId);
    void updateLabelNew(Long questionnaireId, Boolean needPopup);
}
