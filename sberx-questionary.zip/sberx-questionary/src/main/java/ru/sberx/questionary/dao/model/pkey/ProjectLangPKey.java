package ru.sberx.questionary.dao.model.pkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class ProjectLangPKey implements Serializable {

    private static final long serialVersionUID = -7523712205975293295L;

    private Long projectId;
    private String lang;
}
