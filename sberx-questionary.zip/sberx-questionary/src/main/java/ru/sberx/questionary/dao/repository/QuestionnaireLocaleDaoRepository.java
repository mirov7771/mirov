package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.QuestionnaireLocaleDao;
import ru.sberx.questionary.dao.model.pkey.QuestionnaireLangPKey;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface QuestionnaireLocaleDaoRepository extends CrudRepository<QuestionnaireLocaleDao, QuestionnaireLangPKey> {
    QuestionnaireLocaleDao findByQuestionnaireIdAndLang(Long questionnaireId, String lang);

    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    List<QuestionnaireLocaleDao> findByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndLangIn(Long mainQuestionnaireId, List<String> lang);

    @Modifying
    @Transactional
    @Query("update QuestionnaireLocaleDao set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    List<QuestionnaireLocaleDao> findByQuestionnaireIdInAndLang(List<Long> questionnaireIds, String lang);

    @Query(value = "select ql.* from questionnaire_local ql " +
            "inner join questionnaire q on ql.questionnaireid = q.questionnaireid " +
            "inner join user_questionnaire u on u.questionnaireid = q.questionnaireid " +
            "where u.userid = :userId and q.isdisabled = false and q.state = 20004 and ql.lang = :lang limit 1", nativeQuery = true)
    QuestionnaireLocaleDao findByUserIdAndLang(Long userId, String lang);

    List<QuestionnaireLocaleDao> findByQuestionnaireIdIn(List<Long> ids);
}
