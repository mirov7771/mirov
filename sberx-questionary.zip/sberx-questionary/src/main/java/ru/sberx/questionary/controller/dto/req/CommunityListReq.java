package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class CommunityListReq {
    private Long questionnaireId;
    private List<Long> state;
    private String name;
    private Integer rowCount;
    private Integer pageToken;
    private Integer type;
    private Boolean preauth;
    private String sortBy;
    private String orderBy;
}
