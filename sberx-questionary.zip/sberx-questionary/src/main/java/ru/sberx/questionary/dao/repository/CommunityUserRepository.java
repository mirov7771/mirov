package ru.sberx.questionary.dao.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.CommunityUser;

@Repository
public interface CommunityUserRepository extends CrudRepository<CommunityUser, Long> {
    List<CommunityUser> findByQuestionnaireId(Long questionnaireId);
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update CommunityUser set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
}
