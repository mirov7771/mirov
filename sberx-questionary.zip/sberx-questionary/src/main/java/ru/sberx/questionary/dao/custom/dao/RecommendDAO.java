package ru.sberx.questionary.dao.custom.dao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.UUID;

@NoArgsConstructor
@AllArgsConstructor
@Getter @Setter
public class RecommendDAO {
    private Long userId;
    private String name;
    private UUID uid;
    private Long qId;
}
