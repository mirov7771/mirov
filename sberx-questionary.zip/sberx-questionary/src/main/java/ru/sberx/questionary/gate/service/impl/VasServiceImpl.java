package ru.sberx.questionary.gate.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import ru.sberx.questionary.gate.client.RestGate;
import ru.sberx.questionary.gate.dto.GetCompanyListRes;
import ru.sberx.questionary.gate.service.VasService;

import static ru.sberx.questionary.gate.service.impl.OnBoardingServiceImpl.getHeaders;

@Component
@RequiredArgsConstructor
@Slf4j
public class VasServiceImpl implements VasService {

    private final RestGate restGate;

    @Value("${application.vas.url}")
    private String url;
    @Value("${application.vas.company-list}")
    private String listMethod;

    @Override
    public GetCompanyListRes getCompanyList() {
        try {
            UriComponents method = UriComponentsBuilder
                    .fromUriString(listMethod)
                    .queryParam("isImport", "true")
                    .build();

            return restGate.call(GetCompanyListRes.class,
                    url,
                    method.toUriString(),
                    null,
                    HttpMethod.GET,
                    getHeaders(),
                    MediaType.APPLICATION_JSON);
        } catch (Exception e){
            log.error("Error getting company list: ", e);
            return null;
        }
    }
}
