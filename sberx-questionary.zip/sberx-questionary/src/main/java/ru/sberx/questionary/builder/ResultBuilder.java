package ru.sberx.questionary.builder;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.questionary.controller.dto.req.QuestionnaireListReq;
import ru.sberx.questionary.dao.model.Questionnaire;

import java.util.*;

@Component
@RequiredArgsConstructor
public class ResultBuilder {

    private final QueryBuilder queryBuilder;

    public List<Questionnaire> getQuestionnaireListByCriteria(QuestionnaireListReq req){
        return queryBuilder.getListByCriterias(req);
    }

}
