package ru.sberx.questionary.dao.custom.impl;

import org.hibernate.query.Query;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.controller.pilot.req.PilotListReq;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.controller.reply.dto.req.ReplyListReq;
import ru.sberx.questionary.controller.reply.dto.support.ReplyDTO;
import ru.sberx.questionary.dao.custom.CustomRepository;
import ru.sberx.questionary.dao.custom.ListResultTransformer;
import ru.sberx.questionary.dao.custom.dao.QuestionnaireDAO;
import ru.sberx.questionary.dao.custom.dao.RecommendDAO;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.utils.validator.ConditionValidator;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class CustomRepositoryImpl implements CustomRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Override
    public List<QuestionnaireDAO> findByQId(Long questionnaireId) {
        Query<QuestionnaireDAO> query = entityManager.createNativeQuery("select distinct q.questionnaireid as main_questionnaireid," +
                        "unnest(i.round) as main_round," +
                        "unnest(case when q.type = 1 then p.industry else i.industry end) as main_industry," +
                        "unnest(case when q.type = 1 then p.technology else i.technology end) as main_technology," +
                        "unnest(case when q.type = 1 then p.geography else i.geography end) as main_geography, \n" +
                        "q.type as main_type, \n" +
                        "(select max(recommend_date) from recommend_link r where r.recommend_questionnaire_id = q.questionnaireid and r.questionnaire_id=:questionnaireId) as recommend_date \n" +
                        "from questionnaire q \n" +
                        "inner join investment i \n" +
                        "on i.questionnaireid = q.questionnaireid \n" +
                        "left join project p \n" +
                        "on p.questionnaireid = q.questionnaireid \n" +
                        "where q.questionnaireid = :questionnaireId")
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new QuestionnaireDAO(
                                ((BigInteger) tuple[0]).longValue(),
                                tuple[1] != null ? ((BigInteger) tuple[1]).longValue() : null,
                                tuple[2] != null ? ((BigInteger) tuple[2]).longValue() : null,
                                tuple[3] != null ? ((BigInteger) tuple[3]).longValue() : null,
                                tuple[4] != null ? ((BigInteger) tuple[4]).longValue() : null,
                                tuple[5] != null ? ((Short) tuple[5]).intValue() : null,
                                tuple[6] != null ? ((Date) tuple[6]) : null
                        ));
        query.setParameter("questionnaireId", questionnaireId);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<QuestionnaireDAO> findFavoritesById(Long questionnaireId) {
        Query<QuestionnaireDAO> query = entityManager.createNativeQuery("select distinct f.object_id,unnest(p.mvpcode) as child_round," +
                        "unnest(p.industry) as child_industry, " +
                        "unnest(p.technology) as child_technology, " +
                        "unnest(p.geography) as child_geography, \n" +
                        "q.type as main_type \n" +
                        "from object_favorite f \n" +
                        "inner join project p \n" +
                        "on p.questionnaireid = f.object_id \n" +
                        "inner join questionnaire q \n" +
                        "on q.questionnaireid = f.object_id \n" +
                        "and q.type = 0 \n" +
                        "and q.state = 20004 \n" +
                        "where f.questionnaire_id = :questionnaireId")
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new QuestionnaireDAO(
                                ((BigInteger) tuple[0]).longValue(),
                                tuple[1] != null ? ((BigInteger) tuple[1]).longValue() : null,
                                tuple[2] != null ? ((BigInteger) tuple[2]).longValue() : null,
                                tuple[3] != null ? ((BigInteger) tuple[3]).longValue() : null,
                                tuple[4] != null ? ((BigInteger) tuple[4]).longValue() : null,
                                tuple[5] != null ? ((Short) tuple[5]).intValue() : null,
                                null
                        ));
        query.setParameter("questionnaireId", questionnaireId);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<QuestionnaireDAO> findAllQ() {
        return entityManager.createNativeQuery("select q.questionnaireid, " +
                        "cast(p.mvpcode as varchar) as mvpcode, " +
                        "cast(p.industry as varchar) as industry, " +
                        "cast(p.technology as varchar) as technology, " +
                        "cast(p.geography as varchar) as geography \n" +
                        "from questionnaire q \n" +
                        "inner join project p \n" +
                        "on p.questionnaireid = q.questionnaireid  \n" +
                        "where q.type = 0 \n" +
                        "and q.state = 20004")
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new QuestionnaireDAO(
                                ((BigInteger) tuple[0]).longValue(),
                                ((String) tuple[1]),
                                ((String) tuple[2]),
                                ((String) tuple[3]),
                                ((String) tuple[4])
                        )).getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ReplyDTO> findReply(ReplyListReq req) {
        Query<ReplyDTO> query = "reply_report_mode".equalsIgnoreCase(req.getSchema())
                ? getReplyReportQuery()
                : getReplyQuery(req);
        if (query == null)
            return new ArrayList<>();
        return query.getResultList();
    }

    @Override
    public Integer countReply(ReplyListReq req) {
        Integer rowCount = req.getRowCount();
        req.setRowCount(null);
        Query<ReplyDTO> query = getReplyQuery(req);
        req.setRowCount(rowCount);
        if (query == null)
            return 0;
        return (int) query.stream().count();
    }

    @Override
    public Integer countNewReply(List<Long> ids, String schema) {
        ReplyListReq req = new ReplyListReq();
        req.setLocale("ru");
        req.setId(ids);
        req.setSchema(schema);
        req.setState(List.of(GuideService.CHECKING_STATE));
        req.setView(true);
        Query<ReplyDTO> query = getReplyQuery(req);
        if (query == null)
            return 0;
        return (int) query.stream().count();
    }

    @SuppressWarnings("unchecked")
    private Query<ReplyDTO> getReplyQuery(ReplyListReq req){
        String sql;
        if (!req.getSchema().contains("offer")){
            sql = "select r.replyid as id, \n" +
                    "q.name as q_name, \n" +
                    "q.logo_file as q_logo, \n" +
                    "r.state as r_state, \n" +
                    "q.phonenumber as q_phone,\n" +
                    "q.email as q_email,\n" +
                    "r.date as r_date,\n" +
                    "p.name as p_name,\n" +
                    "p.pilotid as p_id,\n" +
                    "r.isviewed as viewed,\n" +
                    "r.offername as offername ,\n" +
                    "r.offerdescription as offerdescription, \n" +
                    "null as c_name, \n" +
                    "null as c_logo \n" +
                    "from reply r \n" +
                    "inner join pilot p \n" +
                    "on r.tableid = p.pilotid \n" +
                    "inner join user_questionnaire uq \n" +
                    "on uq.userid = r.userid \n" +
                    "inner join questionnaire q \n" +
                    "on q.questionnaireid = uq.questionnaireid \n" +
                    "where tablename = 'Pilot' \n" +
                    "and r.tableid in :ids ";
        } else {
            sql = "select r.replyid as id, \n" +
                    "q.name as q_name, \n" +
                    "q.logo_file as q_logo, \n" +
                    "r.state as r_state, \n" +
                    "q.phonenumber as q_phone, \n" +
                    "q.email as q_email, \n" +
                    "r.date as r_date, \n" +
                    "null as p_name, \n" +
                    "null as p_id, \n" +
                    "r.isviewed as viewed,\n" +
                    "r.offername as offername , \n" +
                    "r.offerdescription as offerdescription, \n" +
                    "q2.name as c_name, \n" +
                    "q2.logo_file as c_logo \n" +
                    "from reply r \n" +
                    "inner join user_questionnaire uq \n" +
                    "on uq.userid = r.userid \n" +
                    "inner join questionnaire q \n" +
                    "on q.questionnaireid = uq.questionnaireid \n" +
                    "inner join questionnaire q2 \n" +
                    "on q2.questionnaireid = r.tableid \n" +
                    "where tablename = 'Questionnaire'";
            if (!CollectionUtils.isEmpty(req.getId()))
                sql += " and r.tableid in :ids ";
            if (req.getUserId() != null)
                sql += " and r.userid = :userid ";
        }

        if (!StringUtils.hasText(sql))
            return null;


        if (!CollectionUtils.isEmpty(req.getState()))
            sql += " and r.state in :states ";
        if (StringUtils.hasText(req.getName())) {
            req.setName("%" + req.getName().toLowerCase() + "%");
            sql += " and lower(q.name) like :name ";
        }
        if (Boolean.TRUE.equals(req.getView()))
            sql += " and isviewed = false ";

        sql += " order by r.date ";

        if (StringUtils.hasText(req.getOrderBy()))
            sql += req.getOrderBy();

        Query<ReplyDTO> query = entityManager
                .createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new ReplyDTO(
                                ((BigInteger) tuple[0]).longValue(),
                                ((String) tuple[1]),
                                ((String) tuple[2]),
                                tuple[3] != null ? ((BigInteger) tuple[3]).longValue() : null,
                                ((String) tuple[4]),
                                ((String) tuple[5]),
                                ((Date) tuple[6]),
                                ((String) tuple[7]),
                                tuple[8] != null ? ((BigInteger) tuple[8]).longValue() : null,
                                tuple[9] != null && Boolean.TRUE.equals(tuple[9]),
                                ((String) tuple[10]),
                                ((String) tuple[11]),
                                req.getSchema().contains("offer") ? "/view?type=7&name=offer_" + req.getRole() + "&action=1&id=" : "/view?type=7&name=reply_" + req.getRole() + "&action=1&id=",
                                req.getType(),
                                ((String) tuple[12]),
                                ((String) tuple[13])
                        ));
        if (sql.contains(":ids"))
            query.setParameter("ids", req.getId());
        if (sql.contains(":userid"))
            query.setParameter("userid", req.getUserId());
        if (sql.contains(":states"))
            query.setParameter("states", req.getState());
        if (sql.contains(":name"))
            query.setParameter("name", req.getName());
        if (req.getRowCount() != null) {
            query.setFirstResult(req.getPageToken());
            query.setMaxResults(req.getRowCount());
        }
        return query;
    }

    @SuppressWarnings("unchecked")
    private Query<ReplyDTO> getReplyReportQuery() {
        String sql = "select \n" +
                "r.replyid as r_reply_id, \n" +
                "q.fullname as q_full_name, \n" +
                "r.state as r_state, \n" +
                "q.email as q_email, \n" +
                "r.date as r_date, \n" +
                "p.name as p_name, \n" +
                "cast(q.uid as varchar) as q_UID, \n" +
                "cast(q2.uid as varchar) as q_UID_corp, \n" +
                "r.note as r_note, \n" +
                "q.site as q_site, \n" +
                "r.fileurl as r_file_url, \n" +
                "q2.fullname as q2_full_name \n" +
                "from reply r \n" +
                "left join user_questionnaire uq on uq.userid = r.userid \n" +
                "left join questionnaire q on uq.questionnaireid = q.questionnaireid \n" +
                "left join pilot p on p.pilotid = r.tableid \n" +
                "left join questionnaire q2 on q2.questionnaireid = p.questionnaireid \n" +
                "where r.tablename = 'Pilot'";

        return entityManager.createNativeQuery(sql).unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new ReplyDTO(
                                ((BigInteger) tuple[0]).longValue(),
                                tuple[1] != null ? ((String) tuple[1]) : null,
                                tuple[2] != null ? ((BigInteger) tuple[2]).longValue() : null,
                                tuple[3] != null ? ((String) tuple[3]) : null,
                                ((Date) tuple[4]),
                                tuple[5] != null ? ((String) tuple[5]) : null,
                                tuple[6] != null ? ((String) tuple[6]) : null,
                                tuple[7] != null ? ((String) tuple[7]) : null,
                                tuple[8] != null ? ((String) tuple[8]) : null,
                                tuple[9] != null ? ((String) tuple[9]) : null,
                                tuple[10] != null ? ((String) tuple[10]) : null,
                                tuple[11] != null ? ((String) tuple[11]) : null
                        ));
    }

    @SuppressWarnings("unchecked")
    @Override
    public Integer countFavoritePilot(Long userId, Long state) {
        Query<BigInteger> query = entityManager.createNativeQuery("select count(distinct o.object_id)\n" +
                        "from object_favorite o \n" +
                        "inner join pilot p on o.object_id = p.pilotid\n" +
                        "inner join user_questionnaire u on u.questionnaireid = o.questionnaire_id\n" +
                        "and u.userid = :userid \n" +
                        "where o.object_type = :pilot\n" +
                        "and p.state = :state\n" +
                        "and o.user_id = :userid")
                .unwrap(Query.class);
        query.setParameter("pilot", GuideService.PILOT);
        query.setParameter("userid", userId);
        query.setParameter("state", state);

        return query.getSingleResult().intValue();
    }

    @SuppressWarnings("unchecked")
    @Override
    public Integer countApp(Integer type) {
        String sql = null;

        if (type.equals(0)){
            sql = "select count(*) from questionnaire q where state = 20004 and type = 0";
        } else if (type.equals(1)){
            sql = "select count(*) from questionnaire q where state = 20004 and type = 1";
        } else if (type.equals(2)){
            sql = "select count(*) from questionnaire q where state = 20004 and type = 2";
        } else if (type.equals(3)){
            sql = "select count(*) from pilot p where state = 20004 and ishub = true";
        } else if (type.equals(4)){
            sql = "select count(*) from round";
        } else if (type.equals(5)){
            sql = "select count(*) from reply";
        } else if (type.equals(6)){
            sql = "select count(*) from questionnaire q where state = 20004 and type = 0 and is_import = true";
        }

        if (!StringUtils.hasText(sql))
            return 0;
        Query<BigInteger> query = entityManager.createNativeQuery(sql).unwrap(Query.class);
        return query.getSingleResult().intValue();
    }

    @Override
    public List<PilotDTO> findPilots(PilotListReq req) {
        Query<PilotDTO> query = getPilotQuery(req);
        return query.getResultList();
    }

    @Override
    public Integer countPilots(PilotListReq req) {
        Integer rowCount = req.getRowCount();
        req.setRowCount(null);
        Query<PilotDTO> query = getPilotQuery(req);
        req.setRowCount(rowCount);
        return (int) query.stream().count();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<RecommendDAO> findRecommendForNotify(Long userId, Long qId) {
        String sql = "select :userId as userId,\n" +
                "q.name as name,\n" +
                "q.uid as uid\n," +
                "q.questionnaireid as questionnaireid\n" +
                "  from recommend_link rl \n" +
                "inner join questionnaire q \n" +
                "on q.questionnaireid = rl.recommend_questionnaire_id\n" +
                "where not exists (select 1 from recommend_notification rn where rl.recommend_questionnaire_id = rn.notification_questionnaire_id and rn.user_id = :userId)\n" +
                "and not exists (select 1 from object_action oa where oa.action = 'view' and oa.object_type = 'Questionnaire' and oa.user_id = :userId and oa.object_id = rl.recommend_questionnaire_id)\n" +
                "and rl.questionnaire_id = :qId \n" +
                "order by rl.recommend_date desc";
        Query<RecommendDAO> query = entityManager.createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer) (tuple, aliases) -> new RecommendDAO(
                        tuple[0] != null ? ((BigInteger) tuple[0]).longValue() : null,
                        tuple[1] != null ? ((String) tuple[1]) : null,
                        tuple[2] != null ? ((UUID) tuple[2]) : null,
                        tuple[3] != null ? ((BigInteger) tuple[3]).longValue() : null
                ));
        query.setParameter("userId", userId);
        query.setParameter("qId", qId);
        query.setMaxResults(5);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    private Query<PilotDTO> getPilotQuery(PilotListReq req){
        String sql = "select p.questionnaireid as questionnaireid ,\n" +
                "       p.pilotid as pilotid ,\n" +
                "       p.experience as experience ,\n" +
                "       pl.name as name,\n" +
                "       p.conditions as Conditions,\n" +
                "       pl.businessUnit as BusinessUnit,\n" +
                "       pl.suggestCase as SuggestCase,\n" +
                "       p.file as File,\n" +
                "       p.target as Target,\n" +
                "       p.relevance as Relevance,\n" +
                "       p.effect as Effect,\n" +
                "       p.resources as Resources,\n" +
                "       p.search as Search,\n" +
                "       p.deadLine as DeadLine,\n" +
                "       p.exp as Exp,\n" +
                "       p.company as Company,\n" +
                "       p.decision_company as DecisionCompany,\n" +
                "       p.isHub as IsHub,\n" +
                "       p.reference as Reference,\n" +
                "       p.department as Department,\n" +
                "       p.isDisabled as IsDisabled,\n" +
                "       case when " + req.getQUserId() + " is not null then (" +
                " select r2.state from reply r2 where r2.tableid = p.pilotid and r2.tablename = 'Pilot' and r2.userid ="  + req.getQUserId() +
                " limit 1) else p.state end as State,\n" +
                "       p.isBran as IsBran,\n" +
                "       p.decision as Decision,\n" +
                "       p.isForeign as IsForeign,\n" +
                "       p.targetOption as TargetOption,\n" +
                "       p.isPublished as IsPublished,\n" +
                "       p.creatorId as CreatorId,\n" +
                "       p.pilot as pilot ,\n" +
                "       p.ecoSystem as ecoSystem ,\n" +
                "       p.isB2B as isB2B ,\n" +
                "       p.isB2C as isB2C ,\n" +
                "       p.isSuccess as isSuccess ,\n" +
                "       p.isQuestionnaire as isQuestionnaire ,\n" +
                "       p.site as Site,\n" +
                "       pl.demofile as demofile ,\t\n" +
                "       case when q.name = 'Сбер' then current_date + 100 else p.modified end as pModified ,\n" +
                "       p.created as Created,\n" +
                "       q.name as qName,\n" +
                "       q.fullname as qFullName,\n" +
                "       q.note as qNote,\n" +
                "       q.modified as qModified,\n" +
                "       q.phonenumber as qPhoneNumber,\n" +
                "       q.email as qEmail,\n" +
                "       q.logo_file as qLogoFile,\n" +
                "       q.forlending as qForLending,\n" +
                "       q.revision_date as qrevision_date,\n" +
                "       q.UPDATE_DATE_FOR_SORT as qupdateDateForSort,\n" +
                "       cast(q.UID as varchar) as quuid,\n" +
                "       q.enableoffers as qenableOffers, \n" +
                "       (select count(*) from object_action oa where p.pilotid = oa.object_id and oa.object_type = 'Pilot') as pilot_view, \n" +
                "       (select count(*) from reply r where p.pilotid = r.tableid and r.tablename = 'Pilot') as pilot_reply, \n" +
                "       (select count(*) from reply r where p.pilotid = r.tableid and r.tablename = 'Pilot' and r.state = 20011 and r.isviewed = false) as pilot_newreply, \n " +
                "       uq.userid as userid, \n" +
                "       (select 1 from object_action oa where p.pilotid = oa.object_id and oa.object_type = 'Pilot' and oa.user_id = :userid limit 1) as isview, \n" +
                "       (select 1 from object_favorite of2, user_questionnaire uq2 where p.pilotid = of2.object_id and of2.object_type = 'Pilot' and of2.questionnaire_id = uq2.questionnaireid and uq2.userid = :userid and of2.user_id = :userid limit 1) as favorite, \n" +
                "       (select 1 from reply r3 where r3.tableid = p.questionnaireid and r3.tablename = 'Questionnaire' and r3.state != 20009 and r3.userid = :userid limit 1) as offerPilot, \n" +
                "       row_number() over (partition by p.questionnaireid) as num, \n" +
                "       case when :nums > 0 then (select count(*) \n" +
                "          from pilot pp \n" +
                "         where pp.questionnaireid = p.questionnaireid \n" +
                "           and pp.ishub = true\n" +
                "           and pp.isdisabled = false \n" +
                "           and pp.name is not null\n" +
                "           and pp.name != ''\n" +
                "           and pp.suggestcase is not null \n" +
                "           and pp.suggestcase != ''\n" +
                "           and pp.ecosystem != true \n" +
                "           and pp.isb2b != true \n" +
                "           and pp.isb2c != true \n" +
                "           and pp.issuccess != true \n" +
                "           and pp.isquestionnaire != true \n" +
                "           and pp.ishub = true\n" +
                "           and pp.questionnaireid is not null \n" +
                "           and pp.state in (20004)) \n" +
                "           else 0 end as q_count, \n" +
                "       cast(p.industry as varchar) as ind, \n" +
                "       pl.lang as lang, \n" +
                "       case when pl.lang like :locale then 1 else 2 end as mainSort \n" +
                "  from pilot p " +
                "inner join pilot_local pl on p.pilotid = pl.pilotid and (pl.lang = :locale or (select pl2.pilotid from pilot_local pl2 where pl2.pilotid = p.pilotid and pl2.lang = :locale) is null)\n" +
                "inner join questionnaire q \n" +
                "on p.questionnaireid = q.questionnaireid \n" +
                "inner join user_questionnaire uq \n" +
                "on uq.questionnaireid = q.questionnaireid \n" +
                "where p.isdisabled = false \n" +
                "  and p.name is not null\n" +
                "  and p.name != ''\n" +
                "  and p.suggestcase is not null \n" +
                "  and p.suggestcase != ''\n" +
                "  and p.ecosystem != true\n" +
                "  and p.isb2b != true \n" +
                "  and p.isb2c != true\n" +
                "  and p.issuccess != true\n" +
                "  and p.isquestionnaire != true\n" +
                "  and p.ishub = true\n" +
                "  and p.questionnaireid is not null\n";

        if (!CollectionUtils.isEmpty(req.getPilotId())){
            sql += " and p.pilotid in :pilotids ";
        }

        if (!CollectionUtils.isEmpty(req.getState())){
            sql += " and p.state in :states ";
        }

        if (req.getId() != null){
            if (req.getId().matches("[0-9]+")) {
                sql += " and p.questionnaireid = :questionnaireid ";
            } else {
                sql += " and q.uid = :uid ";
            }
        }

        if (!CollectionUtils.isEmpty(req.getUserId())){
            sql += " and uq.userid in :userids ";
        }

        if (StringUtils.hasText(req.getName())){
            sql += " and (upper(pl.name) like :name \n" +
                    "  or upper(pl.suggestcase) like :name \n" +
                    "  or upper(pl.businessunit) like :name \n" +
                    "  or upper(p.reference) like :name \n" +
                    "  or upper(p.department) like :name \n" +
                    "  or upper(p.conditions) like :name \n" +
                    "  or upper(p.company) like :name\n" +
                    "  or upper(p.decision) like :name \n" +
                    "  or upper(p.decision_company) like :name \n" +
                    "  or upper(p.targetoption) like :name \n" +
                    "  or upper(p.site) like :name ) ";
        }

        if (!CollectionUtils.isEmpty(req.getIndustry())){
            StringBuilder sb = new StringBuilder(" and (");
            for(int i = 0; i < req.getIndustry().size(); i++){
                if (i > 0) {
                    sb.append(" or ");
                }
                sb.append(" cast(p.industry as varchar) like '%").append(req.getIndustry().get(i)).append("%' ");
            }
            sb.append(") ");
            sql += sb.toString();
        }

        if (Boolean.TRUE.equals(req.getView()) && req.getCurrentUserId() != null)
            sql += " and exists (select 1 from object_action oa3 where p.pilotid = oa3.object_id and oa3.object_type = 'Pilot' and oa3.user_id = :userid) ";


        if (Boolean.TRUE.equals(req.getFavorite()) && req.getCurrentUserId() != null) {
            boolean demoRole = StringUtils.hasText(req.getRole()) && req.getRole().toLowerCase().contains("demo");
            if (Boolean.TRUE.equals(demoRole))
                sql += " and exists (select 1 from object_favorite of3, user_questionnaire uq3 where p.pilotid = of3.object_id and of3.object_type = 'Pilot' and of3.questionnaire_id = uq3.questionnaireid and uq3.userid = :userid and of3.user_id = userid and of3.modified > current_date - 30) ";
            else
                sql += " and exists (select 1 from object_favorite of3, user_questionnaire uq3 where p.pilotid = of3.object_id and of3.object_type = 'Pilot' and of3.questionnaire_id = uq3.questionnaireid and uq3.userid = :userid and of3.user_id = userid) ";
        }


        if (req.getQUserId() != null)
            sql += " and exists (select 1 from reply r2 where r2.tableid = p.pilotid and r2.tablename = 'Pilot' and r2.userid = :quserid) ";

        String sortLang = GuideService.ADMINISTRATOR_ROLE.equals(req.getRole()) ? "" : " mainSort asc, ";
        if (StringUtils.hasText(req.getSortBy())) {
            sql += " order by " + sortLang + " p." + req.getSortBy();
            if ("DESC".equalsIgnoreCase(req.getOrderBy())){
                sql += " desc";
            }
        } else {
            sql += " order by" + sortLang + " pModified desc";
        }

        Query<PilotDTO> query = entityManager
                .createNativeQuery(sql)
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new PilotDTO(
                                ((BigInteger) tuple[0]).longValue(),//Long questionnaireId,
                                ((BigInteger) tuple[1]).longValue(),//Long pilotId,
                                tuple[2] != null && Boolean.TRUE.equals(tuple[2]),//Boolean experience,
                                ((String) tuple[3]),//String name,
                                ((String) tuple[4]),//String conditions,
                                ((String) tuple[5]),//String businessUnit,
                                ((String) tuple[6]),//String suggestCase,
                                tuple[7] != null && Boolean.TRUE.equals(tuple[7]),//Boolean file,
                                tuple[8] != null ? ((BigInteger) tuple[8]).longValue() : null,//Long target,
                                tuple[9] != null ? ((BigInteger) tuple[9]).intValue() : null,//Integer relevance,
                                tuple[10] != null ? ((BigInteger) tuple[10]).longValue() : null,//Long effect,
                                tuple[11] != null ? ((BigInteger) tuple[11]).longValue() : null,//Long resources,
                                tuple[12] != null && Boolean.TRUE.equals(tuple[12]),//Boolean search,
                                tuple[13] != null ? ((Date) tuple[13]) : null,//Date deadLine,
                                tuple[14] != null ? ((BigInteger) tuple[14]).longValue() : null,//Long exp,
                                ((String) tuple[15]),//String company,
                                ((String) tuple[16]),//String decisionCompany,
                                tuple[17] != null && Boolean.TRUE.equals(tuple[17]),//Boolean isHub,
                                ((String) tuple[18]),//String reference,
                                ((String) tuple[19]),//String department,
                                tuple[20] != null && Boolean.TRUE.equals(tuple[20]),//Boolean isDisabled,
                                ((BigInteger) tuple[21]).longValue(),//Long state,
                                tuple[22] != null && Boolean.TRUE.equals(tuple[22]),//Boolean isBran,
                                ((String) tuple[23]),//String decision,
                                tuple[24] != null && Boolean.TRUE.equals(tuple[24]),//Boolean isForeign,
                                ((String) tuple[25]),//String targetOption,
                                tuple[26] != null && Boolean.TRUE.equals(tuple[26]),//Boolean isPublished,
                                tuple[27] != null ? ((BigInteger) tuple[27]).longValue() : null,//Long creatorId,
                                tuple[28] != null && Boolean.TRUE.equals(tuple[28]),//Boolean pilot,
                                tuple[29] != null && Boolean.TRUE.equals(tuple[29]),//Boolean ecoSystem,
                                tuple[30] != null && Boolean.TRUE.equals(tuple[30]),//Boolean isB2B,
                                tuple[31] != null && Boolean.TRUE.equals(tuple[31]),//Boolean isB2C,
                                tuple[32] != null && Boolean.TRUE.equals(tuple[32]),//Boolean isSuccess,
                                tuple[33] != null && Boolean.TRUE.equals(tuple[33]),//Boolean isQuestionnaire,
                                ((String) tuple[34]),//String site,
                                ((String) tuple[35]),//String demoFile,
                                ((Date) tuple[36]),//Date modified,
                                ((Date) tuple[37]),//Date created,
                                ((String) tuple[38]),//String qName,
                                ((String) tuple[39]),//String qFullName,
                                ((String) tuple[40]),//String qNote,
                                ((Date) tuple[41]),//Date qModified,
                                ((String) tuple[42]),//String qPhoneNumber,
                                ((String) tuple[43]),//String qEmail,
                                ((String) tuple[44]),//String qLogoFile,
                                tuple[45] != null && Boolean.TRUE.equals(tuple[45]),//Boolean qForLending,
                                tuple[46] != null ? ((Date) tuple[46]) : null,//Date qRevisionDate,
                                tuple[47] != null ? ((Date) tuple[47]) : null,//Date qUpdateDateForSort,
                                ((String) tuple[48]),//String uid,
                                req.getType() != null && req.getType().equals(0) && tuple[49] != null && Boolean.TRUE.equals(tuple[49]),//Boolean enableOffers
                                tuple[50] != null ? ((BigInteger) tuple[50]).intValue() : null,//Integer pilotView,
                                tuple[51] != null ? ((BigInteger) tuple[51]).intValue() : null,//Integer pilotReply,
                                tuple[52] != null ? ((BigInteger) tuple[52]).intValue() : null,//Integer pilotNewReply,
                                req.getRole(),//String role,
                                tuple[53] != null ? ((BigInteger) tuple[53]).longValue() : null,//Long userId,
                                tuple[54] != null,//Boolean view
                                tuple[55] != null,//Boolean favorite,
                                tuple[56] == null,//Boolean offerPilot
                                tuple[57] != null ? ((BigInteger) tuple[57]).intValue() : null,
                                tuple[58] != null ? ((BigInteger) tuple[58]).intValue() : null,
                                req.getPilotsPerCompany(),
                                tuple[59] != null ? (String) tuple[59] : null,
                                ((String) tuple[60])//String lang,
                        ));

        if (sql.contains(":pilotids"))
            query.setParameter("pilotids", req.getPilotId());

        if (sql.contains(":states"))
            query.setParameter("states", req.getState());

        if (sql.contains(":questionnaireid"))
            query.setParameter("questionnaireid", Long.valueOf(req.getId()));

        if (sql.contains(":uid"))
            query.setParameter("uid", UUID.fromString(req.getId()));

        if (sql.contains(":userids"))
            query.setParameter("userids", req.getUserId());

        if (sql.contains(":name"))
            query.setParameter("name", "%" + req.getName().toUpperCase() + "%");

        if (sql.contains(":industries"))
            query.setParameter("industries", req.getIndustry().toArray());

        if (sql.contains(":quserid"))
            query.setParameter("quserid", req.getQUserId());

        query.setParameter("userid", ConditionValidator.nvl(req.getCurrentUserId(), 0));
        query.setParameter("nums", ConditionValidator.nvl(req.getPilotsPerCompany(), 0));
        query.setParameter("locale", req.getLocale());

        if (req.getRowCount() != null) {
            query.setFirstResult(req.getPageToken());
            query.setMaxResults(req.getRowCount());
        }

        return query;
    }
}
