package ru.sberx.questionary.service.count.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.sberx.questionary.controller.count.dto.CountRes;
import ru.sberx.questionary.dao.repository.ReplyRepository;
import ru.sberx.questionary.gate.dto.GetCompanyListRes;
import ru.sberx.questionary.gate.service.VasService;
import ru.sberx.questionary.service.count.CountService;

@Service
@RequiredArgsConstructor
public class CountServiceImpl implements CountService {

    private final ReplyRepository replyRepository;
    private final VasService vasService;

    @Override
    public CountRes count(Integer type) {
        Integer count = replyRepository.countApp(type);
        if (type.equals(6)){
            GetCompanyListRes companyList = vasService.getCompanyList();
            if (companyList != null && companyList.getTotalRowCount() != null)
                count += companyList.getTotalRowCount();
        }
        return new CountRes(count);
    }
}
