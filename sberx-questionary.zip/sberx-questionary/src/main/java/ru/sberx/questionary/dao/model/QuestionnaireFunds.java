package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "QUESTIONNAIRE_FUNDS")
@Getter
@Setter
public class QuestionnaireFunds implements Serializable {

    private static final long serialVersionUID = -2747155807109208980L;

    @Id
    @Column(name = "FUNDID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long fundId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "BUDGET")
    private String budget;
    @Column(name = "AVGINVESTMENT")
    private String avgInvestment;

}
