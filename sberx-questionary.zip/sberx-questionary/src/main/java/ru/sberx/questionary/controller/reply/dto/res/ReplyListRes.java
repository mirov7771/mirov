package ru.sberx.questionary.controller.reply.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.controller.reply.dto.support.ReplyDTO;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ReplyListRes {
    private List<ReplyDTO> list;
    private Integer nextPageToken;
    private Integer totalRowCount;
    private Integer rowCount;
    private Integer favoriteCount;
    private Integer limitCount;
    private Integer newReply;
    private Map<String, Object> schema;
    private List<Button> buttons;

    @Data
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Button {
        private Long code;
        private String text;
        private String description;
        private String format;
        private Boolean value;
        private String clickAction;
        private String clickMethod;
    }
}
