package ru.sberx.questionary.controller.dto.support;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class RoundDto {

    private Long roundId;
    private Long questionnaireId;
    private String startupName;
    private String startupNameFullName;
    private Integer state;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    @JsonFormat(timezone = "GMT+3")
    private Date created;
    private Boolean investment;
    private Long roundType;
    private String investmentPurpose;
    private Long sumInvestment;
    private Integer percent;
    private Long preMoney;
    private Long postMoney;
    private String result;
    private Boolean leadCheck;
    private String leadName;
    private Long lastInvestment;
    private Long futureInvestment;
    private Long geography;
    private Integer transactionType;
    private String roundInfo;
    @JsonFormat(timezone = "GMT+3")
    private Date endDate;
    private String presentation;
    private String logoFile;
    private Boolean favorite;
    private Integer marketingPercent;
    private Integer softwarePercent;
    private Integer teamPercent;
    private Integer extensionPercent;
    private String otherDescription;
    private Integer otherPercent;
    private String inviteFio;
    private String email;
    private String phone;
    @JsonFormat(timezone = "GMT+3")
    private Date planDate;
    private String roundTypeName;
    private String clickAction;
    private String stateName;
    private Long viewCount;
    private String mainLanguage;
    private String questionnaireMainLanguage;
    private List<LanguagesDTO> languages;
    private List<Multilang> multilang;
}

