package ru.sberx.questionary.controller.dto.res;

import lombok.Data;
import ru.sberx.questionary.controller.dto.support.StatusInfoDto;

import java.util.List;

@Data
public class StatusInfoListRes {

    private List<StatusInfoDto> items;
}
