package ru.sberx.questionary.controller.dto.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class QuestionnaireListReq {
    private Boolean isBran;
    private Boolean isDisabled;
    private Integer type;
    private List<Long> state;
    private String name;
    private Integer rowCount;
    private Boolean site;
    private List<Long> industry;
    private String location;
    private List<Long> investorType;
    private List<Long> innovationMethod;
    private List<Long> stady;
    private List<Long> geography;
    private List<Long> registrationCountry;
    private String communityState;
    private Boolean investment;
    private Boolean preauthorize;
    private List<Long> businessModel;
    private Boolean forLending;
    private Boolean admin;
    private Boolean prioritySort;
    private List<Long> mvpCode;
    private List<Long> technology;
    @JsonProperty("project_technology")
    private List<Long> projectTechnology;
    @JsonProperty("investment_technology")
    private List<Long> investmentTechnology;
    @JsonProperty("project_geography")
    private List<Long> projectGeography;
    @JsonProperty("investment_geography")
    private List<Long> investmentGeography;
    @JsonProperty("investment_industry")
    private List<Long> investmentIndustry;
    private List<Long> locationCountry;
    private List<Long> interactionType;
    private List<Long> round;
    private List<Long> staff;
    private String fromDateTime;
    private String toDateTime;
    private Long clientId;
    private String filteredBy;
    private Boolean sber500;
    private String sortBy;
    private String orderBy;
    private String sessionId;
    private Boolean favorite;
    private Long qId;
    private Long qUserId;
    private Long responsible;
    private Boolean main;
    private String search;
    private Boolean view;
    private Boolean enableOffers;
    private Boolean recommend;
    private Boolean isImport;
    private List<String> replaceName;
    private String role;
    private Boolean sales;
    private Integer startBirthDate;
    private Integer endBirthDate;
    private String lang = "ru";
}
