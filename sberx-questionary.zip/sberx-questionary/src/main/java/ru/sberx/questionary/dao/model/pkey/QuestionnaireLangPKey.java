package ru.sberx.questionary.dao.model.pkey;

import lombok.Data;

import java.io.Serializable;

@Data
public class QuestionnaireLangPKey implements Serializable {

    private static final long serialVersionUID = -3676233888759882785L;

    private Long questionnaireId;
    private String lang;
}
