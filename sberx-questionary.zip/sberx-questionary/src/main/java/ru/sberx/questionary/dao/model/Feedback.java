package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.controller.dto.support.FeedBack;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "FEEDBACK")
@Data
@NoArgsConstructor
public class Feedback implements Serializable {

    private static final long serialVersionUID = 6391397809929220242L;

    @Id
    @Column(name = "FEEDBACKID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feedbackId;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "USERFIO")
    private String userFio;
    @Column(name = "UNITID")
    private Long unitId;
    @Column(name = "USERQUESTIONNAIREID")
    private Long userQuestionnaireId;
    @Column(name = "INTERACTIONSTATE")
    private Long interactionState;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "SCORE")
    private Integer score;
    @Column(name = "CREATEDATE")
    private Date createDate;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "NEEDSCORE")
    private Integer needScore;
    @Column(name = "NEEDCOMMENT")
    private String needComment;
    @Column(name = "CASESCORE")
    private Integer caseScore;
    @Column(name = "CASECOMMENT")
    private String caseComment;
    @Column(name = "KPISCORE")
    private Integer kpiScore;
    @Column(name = "KPICOMMENT")
    private String kpiComment;
    @Column(name = "ISBRAN")
    private Boolean isBran;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "DATEEND")
    private Date dateEnd;
    @Column(name = "PILOTSTART")
    private Date pilotStart;
    @Column(name = "PILOTEND")
    private Date pilotEnd;
    @Column(name = "DATECONTRACT")
    private Date dateContract;
    @Column(name = "UNITNAME")
    private String unitName;

    public Feedback(FeedBack f) {
        this.userId = f.getUserId() == null ? 0L : f.getUserId();
        this.userFio = f.getUserFio();
        this.unitId = f.getUnitId();
        this.userQuestionnaireId = f.getUserQuestionnaireId();
        this.interactionState = f.getInteractionState();
        this.comment = f.getComment();
        this.score = f.getScore();
        this.createDate = new Date();
        this.date = f.getDate();
        this.needScore = f.getNeedScore();
        this.needComment = f.getNeedComment();
        this.caseScore = f.getCaseScore();
        this.caseComment = f.getCaseComment();
        this.kpiScore = f.getKpiScore();
        this.kpiComment = f.getKpiComment();
        this.isBran = f.getIsBran();
        this.questionnaireId = f.getQuestionnaireId();
        this.dateEnd = f.getDateEnd();
        this.pilotStart = f.getPilotStart();
        this.pilotEnd = f.getPilotEnd();
        this.dateContract = f.getDateContract();
        this.unitName = f.getUnitName();
    }
}
