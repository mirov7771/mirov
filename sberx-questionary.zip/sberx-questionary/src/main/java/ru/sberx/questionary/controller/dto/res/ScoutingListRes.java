package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.controller.dto.support.ScoutingDto;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ScoutingListRes {
    private List<ScoutingDto> list;
    private Integer rowCount;
    private Integer totalRowCount;
    private Integer nextPageToken;
}
