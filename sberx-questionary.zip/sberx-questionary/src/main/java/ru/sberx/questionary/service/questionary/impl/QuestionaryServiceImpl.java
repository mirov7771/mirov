package ru.sberx.questionary.service.questionary.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.sberx.questionary.controller.dto.res.DefaultRes;
import ru.sberx.questionary.dao.model.PopupInfoDao;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.repository.PopupInfoRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;
import ru.sberx.questionary.service.questionary.QuestionaryService;
import ru.sberx.questionary.util.PopUpStatus;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuestionaryServiceImpl implements QuestionaryService {

    private final QuestionnaireRepository questionnaireRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final PopupInfoRepository popupInfoRepository;


    @Value("${application.label.days:21}")
    private Integer labelNewDays;

    @Override
    public DefaultRes lastEnter(Long userId) {
        DefaultRes res = new DefaultRes();
        List<UserQuestionnaire> userQuestionnaires = userQuestionnaireRepository.findByUserId(userId);
        if (!CollectionUtils.isEmpty(userQuestionnaires)) {
            userQuestionnaireRepository.updateLastEnter(userQuestionnaires.stream().map(UserQuestionnaire::getQuestionnaireId).collect(Collectors.toList()));
        }
        res.setMessage("OK");
        return res;
    }

    @Override
    public void updateLabelNew(Long questionnaireId, Boolean needPopup) {
        Questionnaire questionnaire = questionnaireRepository.findByQuestionnaireId(questionnaireId);
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DATE, labelNewDays);
        questionnaire.setLabelNew(c.getTime());
        questionnaireRepository.save(questionnaire);

        if (Boolean.TRUE.equals(needPopup)) {
            List<Long> userIds = userQuestionnaireRepository.findByQuestionnaireId(questionnaireId)
                    .stream()
                    .map(UserQuestionnaire::getUserId)
                    .collect(Collectors.toList());

            List<PopupInfoDao> popups = popupInfoRepository.findByQuestionnaireIdAndStatus(questionnaireId, PopUpStatus.CONGRATULATE.getValue());
            if (!CollectionUtils.isEmpty(popups))
                userIds.removeAll(popups.stream().map(PopupInfoDao::getUserId).collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(userIds))
                popupInfoRepository.saveAll(
                        userIds.stream()
                                .map(uId -> {
                                    PopupInfoDao dao = new PopupInfoDao();
                                    dao.setQuestionnaireId(questionnaireId);
                                    dao.setUserId(uId);
                                    dao.setStatus(PopUpStatus.CONGRATULATE.getValue());
                                    dao.setWatched(false);
                                    dao.setDate(new Date());
                                    return dao;
                                })
                                .collect(Collectors.toList())
                );
        }
    }
}
