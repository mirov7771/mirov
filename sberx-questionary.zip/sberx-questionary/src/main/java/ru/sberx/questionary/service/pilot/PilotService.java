package ru.sberx.questionary.service.pilot;

import ru.sberx.questionary.controller.pilot.req.PilotListReq;
import ru.sberx.questionary.controller.pilot.res.PilotListRes;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;

public interface PilotService {
    PilotListRes pilotList(PilotListReq req);

    PilotDTO getPilotById(Long pilotId, Long userId);

    PilotDTO createPilot(PilotDTO req);

    PilotDTO createPilotV2(PilotDTO req, Long userId);

    PilotDTO getPilotByIdV2(Long pilotId, Long userId, String lang);
}
