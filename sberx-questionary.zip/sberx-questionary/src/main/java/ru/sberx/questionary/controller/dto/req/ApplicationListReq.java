package ru.sberx.questionary.controller.dto.req;

import java.util.List;
import lombok.Data;

@Data
public class ApplicationListReq {
    private Integer type;
    private Integer rowCount;
    private Integer pageToken;
    private List<Long> state;
    private String name;
    private Boolean admin;
    private String sortBy;
    private String orderBy;
}
