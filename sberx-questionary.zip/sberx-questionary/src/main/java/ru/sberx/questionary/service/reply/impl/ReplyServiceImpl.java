package ru.sberx.questionary.service.reply.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;
import ru.sberx.questionary.controller.dto.res.QuestionaryRes;
import ru.sberx.questionary.controller.reply.dto.req.ReplyListReq;
import ru.sberx.questionary.controller.reply.dto.res.ReplyListRes;
import ru.sberx.questionary.controller.reply.dto.support.QuestionDTO;
import ru.sberx.questionary.controller.reply.dto.support.ReplyInfoDTO;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.service.impl.method.GetQuestionaryMethod;
import ru.sberx.questionary.service.reply.ReplyService;
import ru.sberx.questionary.util.GuideService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReplyServiceImpl implements ReplyService {

    private final ReplyRepository replyRepository;
    private final QuestionLinkRepository questionLinkRepository;
    private final PilotRepository pilotRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final TableCommentRepository tableCommentRepository;
    private final GetQuestionaryMethod questionaryMethod;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;

    @Override
    public ReplyListRes list(ReplyListReq req) {
        ReplyListRes res = new ReplyListRes();
        req.setView(Boolean.TRUE.equals(req.getView()) ? req.getView() : null);
        Questionnaire q = null;
        List<Pilot> pilots = null;
        Long userId = req.getUserId();
        if (req.getUserId() != null)
            q = questionnaireRepository.findAllByUserId(userId);
        if (q != null && q.getType() != null)
            req.setType(q.getType());

        if (!"reply_report_mode".equalsIgnoreCase(req.getSchema())) {
            if (CollectionUtils.isEmpty(req.getId())) {
                if (req.getSchema().contains("offer")) {
                    if (q == null || q.getType() == null) {
                        res.setList(new ArrayList<>());
                        return res;
                    }
                    if (q.getType().equals(1)) {
                        req.setId(List.of(q.getQuestionnaireId()));
                        req.setUserId(null);
                    }
                    req.setIsPilotOffer(true);

                    if (req.getSchema().equalsIgnoreCase("offer_search"))
                        req.setSchema(req.getSchema() + "_" + (q.getType().equals(1) ? "corp" : "startup"));
                } else {
                    pilots = pilotRepository.findByUserId(userId);
                    if (CollectionUtils.isEmpty(pilots)) {
                        res.setList(new ArrayList<>());
                        if (q != null && q.getType().equals(1) && q.getQuestionnaireId() != null)
                            res.setButtons(List.of(getButtonCheckBoxOffer(req.getLocale(), q.getEnableOffers(), q.getQuestionnaireId())));
                        return res;
                    }
                    req.setId(pilots.stream().map(Pilot::getPilotId).collect(Collectors.toList()));
                }
            }

            res.setTotalRowCount(replyRepository.countReply(req));
            res.setLimitCount(res.getTotalRowCount());
            if (req.getRowCount() == null) {
                req.setRowCount(10000);
                req.setPageToken(0);
            } else {
                if (req.getPageToken() == null)
                    req.setPageToken(0);

                res.setNextPageToken(req.getPageToken() + 1);
                if (!req.getPageToken().equals(0))
                    req.setPageToken((int) Math.multiplyFull(req.getPageToken(), req.getRowCount()));
            }

            if (!StringUtils.hasText(req.getOrderBy()))
                req.setOrderBy("desc");

            if (!req.getSchema().contains("offer"))
                req.setUserId(null);
        }

        res.setList(replyRepository.findReply(req));
        res.setRowCount(!CollectionUtils.isEmpty(res.getList()) ? res.getList().size() : 0);
        if (!"reply_report_mode".equalsIgnoreCase(req.getSchema())) {
            if (req.getRowCount().compareTo(res.getRowCount()) > 0)
                res.setNextPageToken(null);
            res.setSchema(GuideService.getSchema(req.getSchema(), req.getLocale()));

            if (q != null && q.getType().equals(1) && q.getQuestionnaireId() != null) {
                if (CollectionUtils.isEmpty(pilots))
                    pilots = pilotRepository.findByUserId(userId);
                int replyCount = 0;
                if (!CollectionUtils.isEmpty(pilots))
                    replyCount = replyRepository.countNewReply(pilots.stream().map(Pilot::getPilotId).collect(Collectors.toList()), "pilot");
                replyCount += nvl(replyRepository.countNewReply(List.of(q.getQuestionnaireId()), "offer"), 0);
                res.setNewReply(replyCount);
                res.setButtons(List.of(getButtonCheckBoxOffer(req.getLocale(), q.getEnableOffers(), q.getQuestionnaireId())));
            }
        }
        return res;
    }

    @Override
    public ReplyInfoDTO post(ReplyInfoDTO req) {
        ReplyInfoDTO request;
        if (req.getReply() != null)
            request = req.getReply();
        else
            request = req;

        if (!request.getTableId().matches("[0-9]+")) {
            Questionnaire q = questionnaireRepository.findByUuid(UUID.fromString(request.getTableId()));
            if (q != null && q.getQuestionnaireId() != null) {
                req.setTableId(String.valueOf(q.getQuestionnaireId()));
                request.setTableId(String.valueOf(q.getQuestionnaireId()));
            }
        }

        if (req.getUserId() != null && request.getUserId() == null)
            request.setUserId(req.getUserId());

        request.setState(20011L);

        ReplyInfoDTO res = new ReplyInfoDTO();
        Reply rep = replyRepository.save(new Reply(request));
        Long replyId = rep.getReplyId();
        if (!CollectionUtils.isEmpty(request.getQuestions())) {
            questionLinkRepository.saveAll(request.getQuestions().stream().map(item -> {
                        QuestionLink q = new QuestionLink();
                        q.setResponseId(item.getResponseId());
                        q.setReplyId(replyId);
                        q.setResponseNote(item.getResponseNote());
                        q.setQuestion(item.getQuestion());
                        return q;
                    }
            ).collect(Collectors.toList()));
        }
        res.setReplyId(rep.getReplyId());
        return res;
    }

    @Override
    public ReplyInfoDTO put(ReplyInfoDTO req) {
        Reply reply = replyRepository.findByReplyId(req.getReplyId());
        if (reply == null)
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);

        reply.patch(req);
        replyRepository.save(reply);
        ReplyInfoDTO res = new ReplyInfoDTO();
        res.setReplyId(reply.getReplyId());
        return res;
    }

    @Override
    public ReplyInfoDTO get(Long id, Integer type) {
        Reply reply = replyRepository.findByReplyId(id);
        if (reply == null)
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        ReplyInfoDTO info = new ReplyInfoDTO();
        info.setReplyId(reply.getReplyId());
        info.setState(reply.getState());
        info.setDate(reply.getDate());
        info.setNote(reply.getNote());
        info.setFileUrl(reply.getFileUrl());
        info.setFileURLString(reply.getFileUrl());
        info.setUserId(reply.getUserId());
        info.setTableId(String.valueOf(reply.getTableId()));
        info.setProcess(reply.getProcess());
        info.setCost(reply.getCost());
        info.setComment(reply.getComment());
        info.setModified(reply.getModified());
        info.setTableName(reply.getTableName());
        info.setOfferDescription(reply.getOfferDescription());
        info.setOfferName(reply.getOfferName());
        info.setIsPilotOffer(reply.getIsPilotOffer());
        info.setIsViewed(reply.getIsViewed());
        if (Boolean.TRUE.equals(reply.getIsPilotOffer()))
            info.setQuestionnaireId(reply.getTableId());

        if (reply.getQuestionLinkList() != null && reply.getQuestionLinkList().size() > 0)
            info.setQuestions(reply.getQuestionLinkList().stream().map(
                    item -> {
                        QuestionDTO q = new QuestionDTO();
                        q.setQuestion(item.getQuestion());
                        q.setResponseNote(item.getResponseNote());
                        q.setResponseId(item.getResponseId());
                        return q;
                    }
            ).collect(Collectors.toList()));
        if (!Boolean.TRUE.equals(reply.getIsViewed())) {
            reply.setIsViewed(true);
            replyRepository.save(reply);
        }

        List<TableComment> comments = tableCommentRepository.findTableCommentByTableIdAndTableNameOrderByDateAsc(info.getReplyId(), "Reply");
        if (!CollectionUtils.isEmpty(comments)) {
            info.setComments(comments.stream().map(i -> {
                CommentDTO dto = new CommentDTO();
                dto.setCommentId(i.getId());
                dto.setUserId(i.getUserId());
                dto.setDate(i.getDate());
                dto.setTableName(i.getTableName());
                dto.setRole(i.getRole());
                dto.setEdited(i.getEdited());
                dto.setUserId(i.getUserId());
                dto.setComment(i.getBody());
                return dto;
            }).collect(Collectors.toList()));
        }

        QuestionaryRes questionary;
        if (info.getUserId() != null && ((type != null && !type.equals(0)) || "Pilot".equalsIgnoreCase(info.getTableName()))) {
            questionary = questionaryMethod.execute(info.getUserId());
        } else {
            questionary = questionaryMethod.execute(Long.valueOf(info.getTableId()), null, null, null, null, null);
        }
        if (info.getTableName().equalsIgnoreCase("Pilot")) {
            Pilot pilot = pilotRepository.findByPilotId(Long.valueOf(info.getTableId()));
            if (pilot != null) {
                List<PilotLocalDao> pilotLocals = pilotLocalDaoRepository.findByPilotId(pilot.getPilotId());
                if (!CollectionUtils.isEmpty(pilotLocals))
                    info.setResponse(pilotLocals.stream()
                            .filter(pl -> !CollectionUtils.isEmpty(pl.getResponseList()))
                            .flatMap(pl -> pl.getResponseList().stream())
                            .map(ru.sberx.questionary.controller.dto.support.Response::new)
                            .collect(Collectors.toList()));
            }

        }
        if (questionary != null) {
            info.setQuestionnaire(questionary.getQuestionnaire());
            info.setProject(questionary.getProject());
            info.setB2bPilots(questionary.getB2bPilots());
        }

        return info;
    }

    private ReplyListRes.Button getButtonCheckBoxOffer(String locale, Boolean enableOffers, Long questionnaireId) {
        return new ReplyListRes.Button(
                100011L,
                "ru".equalsIgnoreCase(locale) ? "Получать предложения от стартапов" : "Get offers from startups",
                "ru".equalsIgnoreCase(locale) ? "Эта функция позволит вам собирать новые идеи и предложения о пилотировании от самих стартапов. " +
                        "Если отключить функцию, стартапы будут только откликаться на опубликованные вами запросы и " +
                        "не смогут подать свою идею на рассмотрение"
                        : "This feature will allow you to collect new ideas and pilot proposals from the startups themselves." + "If you disable the feature," +
                        " startups will only respond to requests you post and will not be able to submit their idea for consideration",
                "check-box",
                Boolean.TRUE.equals(enableOffers),
                "/questionary/" + questionnaireId + "/offer",
                "PUT"
        );
    }
}
