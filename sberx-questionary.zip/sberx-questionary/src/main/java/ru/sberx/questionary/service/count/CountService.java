package ru.sberx.questionary.service.count;

import ru.sberx.questionary.controller.count.dto.CountRes;

public interface CountService {
    CountRes count(Integer type);
}
