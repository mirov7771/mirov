package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.controller.csi.dto.support.CsiDto;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "CSI")
@Data
@NoArgsConstructor
public class CsiDao implements Serializable {

    private static final long serialVersionUID = -6503610183580419131L;

    @Id
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "VALUE")
    private Integer value;
    @Column(name = "CREATEDTTM")
    private Date created;

    public CsiDto toDto() {
        CsiDto dto = new CsiDto();
        dto.setQuestionnaireId(this.questionnaireId);
        dto.setUserId(this.userId);
        dto.setValue(this.value);
        dto.setDate(this.created);
        return dto;
    }
}
