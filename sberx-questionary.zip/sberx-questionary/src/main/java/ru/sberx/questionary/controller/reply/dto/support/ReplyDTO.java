package ru.sberx.questionary.controller.reply.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.util.GuideService;

import java.util.Date;

import static ru.sberx.utils.validator.ConditionValidator.getLogo;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ReplyDTO {
    private Long replyId;
    private String questionnaireName;
    private String questionnaireLogo;
    private Long state;
    private String stateName;
    private String eMail;
    private String phone;
    @JsonFormat(timezone = "GMT+3")
    private Date date;
    private String name;
    private String pilotName;
    private Boolean view;
    private Long pilotId;
    private String offerName;
    private String offerDescription;

    private String startupUID;
    private String corporateUID;
    private String startupSite;
    private String fileUrl;
    private String corporateFullName;

    private final String clickMethod = "GET";
    private String clickAction;

    public ReplyDTO(Long replyId,
                    String questionnaireName,
                    Long state,
                    String eMail,
                    Date date,
                    String offerName,
                    String startupUID,
                    String corporateUID,
                    String offerDescription,
                    String startupSite,
                    String fileUrl,
                    String corporateFullName) {
        this.replyId = replyId;
        this.questionnaireName = questionnaireName;
        this.state = state;
        this.eMail = eMail;
        this.date = date;
        this.offerName = offerName;
        this.startupUID = startupUID;
        this.corporateUID = corporateUID;
        this.offerDescription = offerDescription;
        this.startupSite = startupSite;
        this.fileUrl = fileUrl;
        this.corporateFullName = corporateFullName;
    }

    public ReplyDTO(Long replyId,
                    String questionnaireName,
                    String questionnaireLogo,
                    Long state,
                    String phone,
                    String eMail,
                    Date date,
                    String name,
                    Long pilotId,
                    Boolean view,
                    String offerName,
                    String offerDescription,
                    String clickAction,
                    Integer type,
                    String corporateName,
                    String corporateLogo) {
        this.replyId = replyId;
        if (type != null && !type.equals(0)) {
            this.questionnaireName = questionnaireName;
            this.questionnaireLogo = getLogo(questionnaireLogo);
        } else {
            this.questionnaireName = corporateName;
            this.questionnaireLogo = getLogo(corporateLogo);
        }
        this.state = state;
        if (this.state != null)
            this.stateName = GuideService.getState(this.state);
        this.eMail = eMail;
        this.phone = phone;
        this.date = date;
        this.name = name;
        this.pilotName = name;
        this.view = view;
        this.pilotId = pilotId;
        this.offerName = offerName;
        this.offerDescription = offerDescription;
        this.clickAction = clickAction + this.replyId;
    }
}
