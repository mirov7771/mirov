package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.pkey.QuestionnaireLangPKey;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "QUESTIONNAIRE_LOCAL")
@IdClass(QuestionnaireLangPKey.class)
@Data
@NoArgsConstructor
public class QuestionnaireLocaleDao implements Serializable {

    private static final long serialVersionUID = 3960588761202875526L;

    @Id
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Id
    @Column(name = "LANG")
    private String lang;
    @Column(name = "UUID")
    private UUID uuid;
    @Column(name = "FULLNAME")
    private String fullName;
    @Column(name = "INN")
    private String inn;
    @Column(name = "BIRTHDAY")
    private Date birthDay;
    @Column(name = "NAME")
    private String name;
    @Column(name = "REGISTRATIONCOUNTRY")
    private Long registrationCountry;
    @Column(name = "SITE")
    private String site;
    @Column(name = "INVITEFIO")
    private String inviteFio;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "PHONENUMBER")
    private String phoneNumber;
    @Column(name = "LOGO_FILE")
    private String logoFile;
    @Column(name = "ACCELERATOR_STRING")
    private String acceleratorString;
    @Column(name = "FULLNOTE")
    private String fullNote;
    @Column(name = "NOTE")
    private String note;
}
