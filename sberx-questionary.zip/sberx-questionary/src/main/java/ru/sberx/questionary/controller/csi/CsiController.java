package ru.sberx.questionary.controller.csi;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.csi.dto.req.PostCsiReq;
import ru.sberx.questionary.service.csi.CsiService;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("${spring.application.name}/csi")
@RequiredArgsConstructor
public class CsiController {

    private final CsiService service;

    @GetMapping(value = "list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> list() {
        return ResponseBuilder.build(service.list());
    }

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestHeader(value = "user-id") Long userId,
                                  @RequestBody PostCsiReq req) {
        req.setUserId(userId);
        service.post(req);
        return ResponseEntity.ok().body(null);
    }
}
