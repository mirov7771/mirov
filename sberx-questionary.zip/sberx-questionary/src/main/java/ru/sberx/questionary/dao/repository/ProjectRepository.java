package ru.sberx.questionary.dao.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Project;

@Repository
public interface ProjectRepository extends CrudRepository<Project, Long> {

    @Query(value = "select * from Project where questionnaireId = :questionnaireId and isDisabled = :isDisabled limit 1", nativeQuery = true)
    Project findByQuestionnaireIdAndIsDisabled(@Param("questionnaireId") Long questionnaireId, Boolean isDisabled);
    List<Project> findByQuestionnaireIdIn(List<Long> questionnaireIds);
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Project set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
}
