package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "recommend_coefficient")
@Getter
@Setter
public class RecommendCoefficient implements Serializable {

    private static final long serialVersionUID = -1817045924951118979L;

    @Id
    @Column(name = "coef_type")
    private String coefType;
    @Column(name = "coef_value")
    private Float coefValue;

    public String getRealCoefType(){
        return this.coefType.replace("_1", "").replace("_2", "");
    }

}
