package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class DefaultRes {
    private String message;
    private Boolean isChangedRole;
}
