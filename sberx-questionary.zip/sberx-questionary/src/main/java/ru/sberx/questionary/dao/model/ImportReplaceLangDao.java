package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.pkey.QuestionnaireLangPKey;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "IMPORT_REPLACE_LANG")
@IdClass(QuestionnaireLangPKey.class)
@Data
@NoArgsConstructor
public class ImportReplaceLangDao implements Serializable {

    private static final long serialVersionUID = -7037059436710280508L;

    @Id
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Id
    @Column(name = "LANG")
    private String lang;
    @Column(name = "NOTE")
    private String note;
    @Column(name = "BENEFITS")
    private String benefits;
}
