package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "RESPONSE")
@Getter
@Setter
@NoArgsConstructor
public class Response implements Serializable {

    private static final long serialVersionUID = 4925083325777632928L;

    @Id
    @Column(name = "RESPONSEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long responseId;
    @Column(name = "QUESTION")
    private String question;
    @Column(name = "QUESTION_DESCRIPRION")
    private String questionDescription;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "RESPONSE_NOTE")
    private String responseNote;
    @ManyToOne
    @JoinColumns({
            @JoinColumn(name = "PILOTID", referencedColumnName = "PILOTID"),
            @JoinColumn(name = "LANG", referencedColumnName = "LANG")
    })
    private PilotLocalDao pilot;

    public Response(String question, String questionDescription, Boolean isDisabled, String responseNote, PilotLocalDao pilot) {
        this.question = question;
        this.questionDescription = questionDescription;
        this.isDisabled = isDisabled;
        this.responseNote = responseNote;
        this.pilot = pilot;
    }
}
