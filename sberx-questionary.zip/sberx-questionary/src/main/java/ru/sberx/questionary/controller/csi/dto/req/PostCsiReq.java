package ru.sberx.questionary.controller.csi.dto.req;

import lombok.Data;

@Data
public class PostCsiReq {
    private Integer value;
    private Long userId;
}
