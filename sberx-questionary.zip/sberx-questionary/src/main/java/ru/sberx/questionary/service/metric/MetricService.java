package ru.sberx.questionary.service.metric;

import ru.sberx.questionary.controller.dto.req.PostMetricReq;
import ru.sberx.questionary.controller.metric.dto.req.GetMetricReq;
import ru.sberx.questionary.controller.metric.dto.res.GetMetricRes;
import ru.sberx.questionary.controller.metric.dto.support.MetricTypeDto;

import java.util.List;

public interface MetricService {
    void post(PostMetricReq req);
    void put(PostMetricReq req);
    List<GetMetricRes> get(GetMetricReq req);
    List<MetricTypeDto> list(Long userId, Boolean addDate, String uuid);
    void delete(Integer metric, Long userId);
    List<MetricTypeDto> type();
}
