package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "CONTACT")
@Data
public class Contact implements Serializable {

    private static final long serialVersionUID = 8165062260657064816L;

    @Id
    @Column(name = "CONTACTID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long contactId;
    @Column(name = "TYPE")
    private Long type;
    @Column(name = "NAME")
    private String name;
    @Column(name = "VALUE")
    private String value;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "PARENTID")
    private Long parentId;
    @Column(name = "LANG")
    private String lang;

}
