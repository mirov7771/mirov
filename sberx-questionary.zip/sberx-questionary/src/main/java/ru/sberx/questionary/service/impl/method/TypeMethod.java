package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.TypeListReq;
import ru.sberx.questionary.controller.dto.res.TypeRes;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.util.GuideService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
public class TypeMethod {

    private final QuestionnaireRepository questionnaireRepository;
    private final PilotRepository pilotRepository;
    private final ReplyRepository replyRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final RoundRepository roundRepository;
    private final CommunityUserRepository communityUserRepository;

    public List<TypeRes> execute(Long userId) {
        List<TypeRes> res = new ArrayList<>();
        List<Questionnaire> questionnaire = questionnaireRepository.findByUserIdAll(userId);
        if (questionnaire != null && questionnaire.size() > 0) {
            res = questionnaire.stream().map(item -> {
                TypeRes r = new TypeRes();
                r.setState(item.getState());
                r.setType(item.getType());
                r.setLogoPath(item.getLogoFile());
                r.setQuestionnaireId(item.getQuestionnaireId());
                r.setModified(item.getModified() == null ? item.getCreated() : item.getModified());
                r.setPhoneNumber(item.getPhoneNumber());
                r.setEmail(item.getEmail());
                r.setName(item.getName());
                r.setIsDisabled(item.getIsDisabled());
                r.setSber500(item.getSber500());
                r.setIsImport(item.getIsImport());
                r.setLastEnter(item.getLastEnter());
                r.setParentId(item.getParentId());
                if (item.getUuid() != null)
                    r.setUid(item.getUuid().toString());
                if (r.getType().equals(2) && item.getInvestorType() != null)
                    r.setInvestorType(GuideService.getInvestorType(item.getInvestorType()));
                //TODO передалать полсе хф от 29.10.2021
                if (r.getQuestionnaireId().equals(136L)
                        || r.getQuestionnaireId().equals(176L)
                        || r.getQuestionnaireId().equals(235L)
                        || r.getQuestionnaireId().equals(1049L)
                        || r.getQuestionnaireId().equals(6851L)) {
                    r.setStateName("Активный");
                    r.setStateSysName("active");
                    r.setState(GuideService.CONFIRMED_STATE);
                } else {
                    r.setStateName(GuideService.getState(item.getState()));
                    r.setStateSysName(GuideService.getStateSysName(item.getState()));
                }

                if (r.getType().equals(1)) {
                    int replyCount = 0;
                    List<Pilot> pilots = pilotRepository.findByQuestionnaireId(r.getQuestionnaireId());
                    if (!CollectionUtils.isEmpty(pilots))
                        replyCount = replyRepository.countNewReply(pilots.stream().map(Pilot::getPilotId).collect(Collectors.toList()), "pilot");
                    replyCount += nvl(replyRepository.countNewReply(List.of(r.getQuestionnaireId()), "offer"), 0);
                    r.setNewReply(replyCount);
                }

                return r;
            }).collect(Collectors.toList());
        }
        return res;
    }

    public TypeRes executeByUserId(Long userId) {
        Questionnaire questionnaire = questionnaireRepository.findAllByUserId(userId);
        Long qId = questionnaire != null ? questionnaire.getQuestionnaireId() : null;
        if (qId != null) {
            TypeRes res = buildType(questionnaire);
            Questionnaire child = questionnaireRepository.findByParentId(qId);
            List<Reply> replies = replyRepository.findByTableId(qId);
            List<RoundDao> rounds = roundRepository.findByQuestionnaireId(qId);
            List<CommunityUser> communities = communityUserRepository.findByQuestionnaireId(qId);
            if (child != null) {
                Long childQId = child.getQuestionnaireId();
                res.setChildId(childQId);
            }
            if (!CollectionUtils.isEmpty(replies))
                res.setReplyIds(replies.stream().map(Reply::getReplyId).collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(rounds))
                res.setRoundIds(rounds.stream().map(RoundDao::getRoundId).collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(communities))
                res.setCommunityIds(communities.stream().map(CommunityUser::getQuestionnaireId).collect(Collectors.toList()));
            return res;
        }
        throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
    }

    public List<TypeRes> getList(TypeListReq req) {
        List<TypeRes> res = new ArrayList<>();
        if (!CollectionUtils.isEmpty(req.getUserId())) {
            List<Questionnaire> questionnaires = questionnaireRepository.findByUserIdIn(req.getUserId());
            if (!CollectionUtils.isEmpty(questionnaires)) {
                List<UserQuestionnaire> userQuestionnaires = userQuestionnaireRepository.findByQuestionnaireIdIn(
                        questionnaires.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList()));
                Map<Long, Long> idsMap = userQuestionnaires
                        .stream()
                        .collect(Collectors.
                                toMap(UserQuestionnaire::getQuestionnaireId, UserQuestionnaire::getUserId, (v1, v2) -> v1));
                res = questionnaires.stream()
                        .map(q -> {
                            TypeRes type = buildType(q);
                            type.setUserId(idsMap.get(q.getQuestionnaireId()));
                            return type;
                        }).collect(Collectors.toList());
            }
        } else {
            List<TypeRes> list = questionnaireRepository.findTypeList();
            res.addAll(list);
        }
        return res;
    }

    private TypeRes buildType(Questionnaire q) {
        TypeRes type = new TypeRes();
        type.setType(q.getType());
        type.setQuestionnaireId(q.getQuestionnaireId());
        type.setState(q.getState());
        type.setLogoPath(q.getLogoFile());
        type.setInviteFio(q.getInviteFio());
        type.setPhone(q.getPhoneNumber());
        type.setPhoneNumber(q.getPhoneNumber());
        type.setEmail(q.getEmail());
        type.setName(q.getName());
        type.setFullName(q.getFullName());
        type.setIsDisabled(q.getIsDisabled());
        type.setModified(nvl(q.getModified(), q.getCreated()));
        type.setQuestionnaireUUID(q.getUuid());
        if (q.getUuid() != null)
            type.setUid(q.getUuid().toString());
        if (q.getState() != null)
            type.setStateName(GuideService.getStateSysName(q.getState()));
        if (q.getInvestorType() != null)
            type.setInvestorType(GuideService.getInvestorType(q.getInvestorType()));
        return type;
    }
}
