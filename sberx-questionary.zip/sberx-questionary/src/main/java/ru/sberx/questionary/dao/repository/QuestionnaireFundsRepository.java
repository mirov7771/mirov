package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.QuestionnaireFunds;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface QuestionnaireFundsRepository extends CrudRepository<QuestionnaireFunds, Long> {

    List<QuestionnaireFunds> findByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update QuestionnaireFunds set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

}
