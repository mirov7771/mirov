package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.sberx.questionary.dao.model.UserQuestionnaire;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class User {

    private Long userId;
    private String email;
    private String phoneNumber;
    private String name;
    private String lastName;
    private String firstName;
    private String position;

    public User(UserQuestionnaire u){
        this.userId = u.getUserId();
        this.email = u.getEmail();
        this.phoneNumber = u.getPhoneNumber();
        this.name = u.getName();
        this.lastName = u.getLastName();
        this.firstName = u.getFirstName();
        this.position = u.getPosition();
    }

}
