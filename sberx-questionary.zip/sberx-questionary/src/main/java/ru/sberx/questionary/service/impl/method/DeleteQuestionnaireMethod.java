package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.questionary.controller.dto.res.DeleteQuestionnaireRes;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.repository.*;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DeleteQuestionnaireMethod {

    private final ApplicationRepository applicationRepository;
    private final CommunityUserRepository communityUserRepository;
    private final ContactRepository contactRepository;
    private final FeedbackRepository feedbackRepository;
    private final FounderRepository founderRepository;
    private final InvestmentClubRepository investmentClubRepository;
    private final InvestmentRepository investmentRepository;
    private final PilotRepository pilotRepository;
    private final PopupInfoRepository popupInfoRepository;
    private final ProjectRepository projectRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final RepresentativeRepository representativeRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final WorkerRepository workerRepository;
    private final SberFiveHundredRepository sberFiveHundredRepository;
    private final RoundRepository roundRepository;
    private final QuestionnaireFundsRepository questionnaireFundsRepository;
    private final ReplyRepository replyRepository;
    private final ObjectFavoriteRepository objectFavoriteRepository;
    private final ObjectActionRepository objectActionRepository;
    private final ImportReplaceDAORepository importReplaceDAORepository;
    private final TariffRepository tariffRepository;
    private final QuestionnaireLocaleDaoRepository questionnaireLocaleDaoRepository;
    private final InvestmentLocaleDaoRepository investmentLocaleDaoRepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;
    private final ImportReplaceLangDaoRepository importReplaceLangDaoRepository;

    public DeleteQuestionnaireRes execute(Long questionnaireId) {
        DeleteQuestionnaireRes res = new DeleteQuestionnaireRes();
        List<UserQuestionnaire> uq = userQuestionnaireRepository.findByQuestionnaireId(questionnaireId);
        if (uq.size() == 1) {
            Long userId = uq.get(0).getUserId();
            res.setUserId(userId);
            if (userId != null) {
                List<UserQuestionnaire> usersQuestionnaires = userQuestionnaireRepository.findByUserId(userId);
                for (UserQuestionnaire usersQuestionnaire : usersQuestionnaires) {
                    Long qId = usersQuestionnaire.getQuestionnaireId();
                    Questionnaire q = questionnaireRepository.findByQuestionnaireId(qId);
                    if (q != null && (Long.valueOf(20004L).equals(q.getState()) || usersQuestionnaires.size() == 1)) {
                        res.setFullName(q.getFullName());
                    }
                    deleteByQuestionnaireId(qId);
                }
            }
        } else {
            deleteByQuestionnaireId(questionnaireId);
            return null;
        }
        return res;
    }

    public void deleteByQuestionnaireId(Long questionnaireId) {
        roundRepository.deleteByQuestionnaireId(questionnaireId);
        questionnaireLocaleDaoRepository.deleteByQuestionnaireId(questionnaireId);
        questionnaireRepository.deleteByQuestionnaireId(questionnaireId);
        applicationRepository.deleteByQuestionnaireId(questionnaireId);
        communityUserRepository.deleteByQuestionnaireId(questionnaireId);
        contactRepository.deleteById(questionnaireId);
        feedbackRepository.deleteByQuestionnaireId(questionnaireId);
        founderRepository.deleteByQuestionnaireId(questionnaireId);
        investmentClubRepository.deleteById(questionnaireId);
        investmentLocaleDaoRepository.deleteByQuestionnaireId(questionnaireId);
        investmentRepository.deleteByQuestionnaireId(questionnaireId);
        pilotLocalDaoRepository.deleteByQuestionnaireId(questionnaireId);
        pilotRepository.deleteByQuestionnaireId(questionnaireId);
        popupInfoRepository.deleteByQuestionnaireId(questionnaireId);
        projectLocaleDaoRepository.deleteByQuestionnaireId(questionnaireId);
        projectRepository.deleteByQuestionnaireId(questionnaireId);
        representativeRepository.deleteById(questionnaireId);
        importReplaceLangDaoRepository.deleteByQuestionnaireId(questionnaireId);
        importReplaceDAORepository.deleteByQuestionnaireId(questionnaireId);
        userQuestionnaireRepository.deleteByQuestionnaireId(questionnaireId);
        workerRepository.deleteById(questionnaireId);
        sberFiveHundredRepository.deleteByQuestionnaireId(questionnaireId);
        questionnaireFundsRepository.deleteByQuestionnaireId(questionnaireId);
        replyRepository.deleteByTableId(questionnaireId);
        objectFavoriteRepository.deleteByObjectIdOrQuestionnaireId(questionnaireId, questionnaireId, "Questionnaire");
        objectActionRepository.deleteByObjectIdAndObjectType(questionnaireId, "Questionnaire");
        tariffRepository.deleteByQuestionnaireId(questionnaireId);
    }

}
