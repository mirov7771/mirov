package ru.sberx.questionary.dao.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import ru.sberx.questionary.controller.dto.support.StatusInfoDto;
import ru.sberx.questionary.util.GuideService;

@Entity
@Table(name = "STATUS_INFO")
@Getter
@Setter
public class StatusInfo implements Serializable {

    private static final long serialVersionUID = 8430285669871810063L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "OBJECT_ID")
    private Long objectId;
    @Column(name = "OBJECT_TYPE")
    private String objectType;
    @Column(name = "FROM_STATE")
    private Long fromState;
    @Column(name = "TO_STATE")
    private Long toState;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "PARENT_ID")
    private Long parentId;
    @Column(name = "UID")
    private String uid;

    public StatusInfoDto toDto() {
        StatusInfoDto res = new StatusInfoDto();
        res.setFromState(this.fromState);
        res.setToState(this.toState);
        res.setFromStateName(GuideService.getState(this.fromState));
        res.setToStateName(GuideService.getState(this.toState));
        res.setUserId(this.userId);
        res.setDate(this.date);
        res.setComment(this.comment);
        res.setChild(this.parentId != null);
        res.setUid(this.uid);
        return res;
    }

}
