package ru.sberx.questionary.gate.service.impl;

import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.gate.client.RestGate;
import ru.sberx.questionary.gate.dto.GetPopupRes;
import ru.sberx.questionary.gate.service.ScreenBuilderService;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class ScreenBuilderServiceImpl implements ScreenBuilderService {

    @Value("${application.screenbuilder.url}")
    private String url;
    @Value("${application.screenbuilder.popup}")
    private String getPopupMethod;

    private final RestGate restGate;

    @Override
    public List<GetPopupRes> getPopup(List<String> status, String locale) {
        Map<String, Object> params = Collections
                .singletonMap("status", StringUtils.collectionToCommaDelimitedString(status));
        HttpHeaders headers = new HttpHeaders();
        headers.set("requestId", ThreadContext.get("requestId"));
        headers.set("locale", locale);
        return restGate.call(new ParameterizedTypeReference<List<GetPopupRes>>() {},
                url,
                getPopupMethod,
                params,
                null,
                HttpMethod.GET,
                headers,
                MediaType.APPLICATION_JSON);
    }
}
