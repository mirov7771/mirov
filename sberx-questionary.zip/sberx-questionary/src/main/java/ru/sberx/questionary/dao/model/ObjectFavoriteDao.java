package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "OBJECT_FAVORITE")
@Setter
@Getter
@NoArgsConstructor
public class ObjectFavoriteDao implements Serializable {

    private static final long serialVersionUID = 6354054890512827351L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "OBJECT_ID")
    private Long objectId;
    @Column(name = "OBJECT_TYPE")
    private String objectType;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "MODIFIED")
    private Date modified;
}
