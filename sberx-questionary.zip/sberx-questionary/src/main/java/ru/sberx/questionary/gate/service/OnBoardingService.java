package ru.sberx.questionary.gate.service;

import ru.sberx.questionary.gate.service.impl.OnBoardingServiceImpl;

public interface OnBoardingService {
    OnBoardingServiceImpl.OnBoardingElements getOnBoarding(String sysName);
}
