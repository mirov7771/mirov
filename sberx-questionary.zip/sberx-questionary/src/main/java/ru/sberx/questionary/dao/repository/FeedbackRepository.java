package ru.sberx.questionary.dao.repository;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Feedback;

@Repository
public interface FeedbackRepository extends CrudRepository<Feedback, Long> {

    List<Feedback> findByQuestionnaireId(Long questionnaireId);
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Feedback set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
}
