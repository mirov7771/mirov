package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.controller.dto.support.Syndicate;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SyndicateRes {
    private List<Syndicate> list;
    private Integer rowCount;
    private Integer totalRowCount;
    private Integer nextPageToken;
    private Integer totalPageCount;

}
