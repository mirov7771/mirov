package ru.sberx.questionary.controller.pilot;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.pilot.req.PilotListReq;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.service.pilot.PilotService;

import javax.validation.Valid;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class PilotController {

    private final PilotService service;

    @GetMapping(value = "pilot/list", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> pilotsList(@RequestHeader(value = "user-id", required = false) Long userId,
                                        @RequestHeader(value = "role", required = false) String role,
                                        @RequestHeader(value = "locale", defaultValue = "ru") String locale,
                                        PilotListReq req) {
        req.setRole(role);
        req.setCurrentUserId(userId);
        req.setLocale(locale);
        return ResponseBuilder.build(service.pilotList(req));
    }

    @GetMapping(value = "pilot/{pilotId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPilot(@RequestHeader(value = "user-id", required = false) Long userId,
                                      @PathVariable("pilotId") Long pilotId) {
        return ResponseBuilder.build(service.getPilotById(pilotId, userId));
    }

    @PostMapping(value = "pilot", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> postPilot(@Valid @RequestBody PilotDTO req) {
        return ResponseBuilder.build(service.createPilot(req));
    }

    @PostMapping(value = "v2/pilot", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> postPilotV2(@RequestHeader(value = "user-id", required = false) Long userId,
                                         @Valid @RequestBody PilotDTO req) {
        return ResponseBuilder.build(service.createPilotV2(req, userId));
    }

    @GetMapping(value = "v2/pilot/{pilotId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getPilotV2(@RequestHeader(value = "user-id", required = false) Long userId,
                                        @PathVariable("pilotId") Long pilotId,
                                        @RequestParam(value = "lang", defaultValue = "ru") String lang) {
        return ResponseBuilder.build(service.getPilotByIdV2(pilotId, userId, lang));
    }
}
