package ru.sberx.questionary.dao.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "LEGAL_APPLICATION")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LegalApplication implements Serializable {

    private static final long serialVersionUID = 6496332713742508781L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "IPSERVICE")
    private Long ipService;
    @Column(name = "PROBLEM")
    private String problem;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "STATE")
    private Long state;
}
