package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Worker;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface WorkerRepository extends CrudRepository<Worker, String> {
    List<Worker> findByQuestionnaireIdAndIsDisabled(Long questionnaireId, Boolean isDisabled);

    List<Worker> findByQuestionnaireIdAndIsDisabledAndLang(Long questionnaireId, Boolean isDisabled, String lang);

    @Transactional
    @Modifying
    @Query("delete from Worker where questionnaireId = :questionnaireId")
    void deleteById(@Param("questionnaireId") Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Worker set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    List<Worker> findByQuestionnaireId(Long questionnaireId);

    List<Worker> findByQuestionnaireIdIn(List<Long> questionnaireId);

    List<Worker> findByQuestionnaireIdInAndLang(List<Long> questionnaireId, String lang);

    @Transactional
    @Modifying
    void deleteByQuestionnaireIdAndLang(Long questionnaireId, String lang);

    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndLangIn(Long questionnaireId, List<String> lang);
}
