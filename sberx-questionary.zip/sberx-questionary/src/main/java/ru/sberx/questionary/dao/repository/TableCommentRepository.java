package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.sberx.questionary.dao.model.TableComment;

import javax.transaction.Transactional;
import java.util.List;

public interface TableCommentRepository extends CrudRepository<TableComment, Long> {
    List<TableComment> findTableCommentByTableIdAndTableNameOrderByDateAsc(Long tableId, String tableName);
    @Transactional
    @Modifying
    @Query(value = "delete from TABLE_COMMENT where id = :id", nativeQuery = true)
    void deleteByCommentId(@Param("id") Long id);
}
