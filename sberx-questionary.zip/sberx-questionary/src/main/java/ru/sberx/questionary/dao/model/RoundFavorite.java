package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "round_favorite")
@Data
@NoArgsConstructor
public class RoundFavorite implements Serializable {

    private static final long serialVersionUID = -680707763785539390L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "ROUND_ID")
    private Long roundId;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "MODIFIED")
    private Date modified;

    public RoundFavorite(Long qId, Long rId, Long userId){
        this.questionnaireId = qId;
        this.roundId = rId;
        this.userId = userId;
        this.modified = new Date();
    }
}
