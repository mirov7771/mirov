package ru.sberx.questionary.controller.dto.res;

import lombok.Data;

@Data
public class FeedBackRes {
    private Long feedbackId;
    private Long questionnaireId;
}
