package ru.sberx.questionary.dao.custom;

import ru.sberx.questionary.controller.dto.req.StatisticReq;
import ru.sberx.questionary.controller.dto.res.TypeRes;
import ru.sberx.questionary.controller.dto.support.Statistic;
import ru.sberx.questionary.dao.custom.dao.QuestionnaireDAO;
import ru.sberx.questionary.dao.custom.dao.ReplyDAO;

import java.util.List;

public interface QuestionnaireCustomRepository {
    List<Statistic> getStatistic(StatisticReq req);
    List<ReplyDAO> findCustomReplyInfo(Integer days);
    List<TypeRes> findTypeList();
    List<QuestionnaireDAO> findForNotify();
}
