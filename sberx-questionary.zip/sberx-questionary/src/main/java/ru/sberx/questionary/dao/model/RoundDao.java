package ru.sberx.questionary.dao.model;

import com.vladmihalcea.hibernate.type.array.StringArrayType;
import lombok.*;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import ru.sberx.questionary.controller.dto.support.RoundDto;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "ROUND")
@Data
@TypeDef(name = "string-array", typeClass = StringArrayType.class)
public class RoundDao implements Serializable {

    private static final long serialVersionUID = -680707763785539390L;

    @Id
    @Column(name = "ROUND_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roundId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "STATE")
    private Integer state;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "INVESTMENT")
    private Boolean investment;
    @Column(name = "ROUND_TYPE")
    private Long roundType;
    @Column(name = "INVESTMENT_PURPOSE")
    private String investmentPurpose;
    @Column(name = "SUM_INVESTMENT")
    private Long sumInvestment;
    @Column(name = "PERCENT")
    private Integer percent;
    @Column(name = "PRE_MONEY")
    private Long preMoney;
    @Column(name = "POST_MONEY")
    private Long postMoney;
    @Column(name = "RESULT")
    private String result;
    @Column(name = "LEAD_CHECK")
    private Boolean leadCheck;
    @Column(name = "LEAD_NAME")
    private String leadName;
    @Column(name = "LAST_INVESTMENT")
    private Long lastInvestment;
    @Column(name = "FUTURE_INVESTMENT")
    private Long futureInvestment;
    @Column(name = "GEOGRAPHY")
    private Long geography;
    @Column(name = "TRANSACTION_TYPE")
    private Integer transactionType;
    @Column(name = "ROUND_INFO")
    private String roundInfo;
    @Column(name = "END_DATE")
    private Date endDate;
    @Column(name = "PLAN_DATE")
    private Date planDate;
    @Column(name = "PRESENTATION")
    private String presentation;
    @Column(name = "FAVORITE")
    private Boolean favorite;
    @Column(name = "MARKETING_PERCENT")
    private Integer marketingPercent;
    @Column(name = "SOFTWARE_PERCENT")
    private Integer softwarePercent;
    @Column(name = "TEAM_PERCENT")
    private Integer teamPercent;
    @Column(name = "EXTENSION_PERCENT")
    private Integer extensionPercent;
    @Column(name = "OTHER_DESCRIPTION")
    private String otherDescription;
    @Column(name = "OTHER_PERCENT")
    private Integer otherPercent;
    @Column(name = "INVITE_FIO")
    private String inviteFio;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "VIEW_COUNT")
    private Long viewCount;
    @ManyToOne
    @JoinColumn(name = "QUESTIONNAIREID", insertable = false, updatable = false)
    private Questionnaire questionnaire;
    @Column(name = "MAIN_LANGUAGE")
    private String mainLanguage;
    @Type(type = "string-array")
    @Column(name = "LANGUAGES")
    private String[] languages;

    public RoundDto toDto() {
        RoundDto dto = new RoundDto();
        dto.setState(this.state);
        dto.setCreated(this.created);
        dto.setModified(this.modified);
        dto.setInvestment(this.investment);
        dto.setRoundType(this.roundType);
        dto.setInvestmentPurpose(this.investmentPurpose);
        dto.setSumInvestment(this.sumInvestment);
        dto.setPercent(this.percent);
        dto.setPreMoney(this.preMoney);
        dto.setPostMoney(this.postMoney);
        dto.setResult(this.result);
        dto.setLeadCheck(this.leadCheck);
        dto.setLeadName(this.leadName);
        dto.setLastInvestment(this.lastInvestment);
        dto.setGeography(this.geography);
        dto.setTransactionType(this.transactionType);
        dto.setRoundInfo(this.roundInfo);
        dto.setEndDate(this.endDate);
        dto.setPresentation(this.presentation);
        dto.setMarketingPercent(this.marketingPercent);
        dto.setSoftwarePercent(this.softwarePercent);
        dto.setTeamPercent(this.teamPercent);
        dto.setExtensionPercent(this.extensionPercent);
        dto.setOtherDescription(this.otherDescription);
        dto.setOtherPercent(this.otherPercent);
        dto.setSumInvestment(this.sumInvestment);
        dto.setFutureInvestment(this.futureInvestment);
        dto.setPlanDate(this.planDate);
        dto.setPresentation(this.presentation);
        dto.setInviteFio(this.inviteFio);
        dto.setEmail(this.email);
        dto.setPhone(this.phone);
        dto.setRoundTypeName(GuideService.getRoundTypeName(this.roundType));
        dto.setRoundId(this.roundId);
        dto.setQuestionnaireId(this.questionnaireId);
        return dto;
    }

    public RoundDto toDtoList(){
        RoundDto dto = new RoundDto();
        dto.setRoundId(this.roundId);
        dto.setState(this.state);
        dto.setRoundType(this.roundType);
        dto.setSumInvestment(this.sumInvestment);
        dto.setModified(this.modified);
        dto.setCreated(this.created);
        dto.setClickAction("view?type=10&id=" + this.roundId + "&action=1");
        if (this.state != null)
            dto.setStateName(GuideService.getState(this.state.longValue()));
        dto.setRoundTypeName(GuideService.getRoundTypeName(this.roundType));
        dto.setQuestionnaireId(this.questionnaireId);
        dto.setInvestment(Boolean.TRUE.equals(this.investment));
        dto.setViewCount(this.viewCount);
        return dto;
    }

    public RoundDto toDtoWithViewCount(Integer type) {
        RoundDto dto = toDto();
        if (type == null || type.equals(0))
            dto.setViewCount(this.getViewCount());
        return dto;
    }

}

