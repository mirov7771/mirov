package ru.sberx.questionary.gate.service;

import ru.sberx.questionary.controller.dto.res.GetUserRes;
import ru.sberx.questionary.controller.dto.support.UserConsent;
import ru.sberx.questionary.gate.service.impl.UserAuthImpl;

public interface UserAuth {

    void changeRole(Long userId, String newRole, Integer userRole);
    Long getUserId(String sessionId);
    Long getUserId2(String sessionId);
    Long getUserIdByEmail(String email);
    Long getUserIdByEmail2(String email);
    String restorePassword(String email, String action);
    String getEmailByUserId(Long userId);
    Long getUserByExternalId(Long userId);
    void deleteUserSessions(Long userId);
    GetUserRes getUserInfo(Long externalId, Long userId);
    String getUserRole(String sessionId);
    void saveConsent(UserConsent userConsent, Long userId);
    UserAuthImpl.UserList getUserList(Integer userRole);
    UserAuthImpl.ConsentSignDttm getConsentSignDttm(Long userId);
}
