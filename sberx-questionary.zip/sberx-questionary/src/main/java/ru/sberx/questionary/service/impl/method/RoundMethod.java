package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.QueryBuilder;
import ru.sberx.questionary.controller.dto.req.AddFavoriteReq;
import ru.sberx.questionary.controller.dto.req.RoundListReq;
import ru.sberx.questionary.controller.dto.req.RoundReq;
import ru.sberx.questionary.controller.dto.req.VerifyReq;
import ru.sberx.questionary.controller.dto.res.RoundListRes;
import ru.sberx.questionary.controller.dto.support.LanguagesDTO;
import ru.sberx.questionary.controller.dto.support.Multilang;
import ru.sberx.questionary.controller.dto.support.RoundDto;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.util.GuideService;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
public class RoundMethod {

    private final MidService midService;
    private final UserAuth userAuth;
    private final RoundRepository roundRepository;
    private final RoundLocalRepository roundLocalRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final QuestionnaireLocaleDaoRepository questionnaireLocaleRepository;
    private final VerifyMethod verifyMethod;
    private final QueryBuilder queryBuilder;
    private final RoundFavoriteRepository roundFavoriteRepository;
    private final ObjectFavoriteRepository objectFavoriteRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final ObjectActionRepository objectActionRepository;

    public RoundDto getRoundByIdV2(Long roundId, Long userId) {
        RoundDto res = getRoundById(roundId, userId);
        if (res != null
                && (res.getRoundId() != null || res.getStartupName() != null)) {
            setDTOMultilangFields(res);
            eraseLegacyRoundDtoFields(res);
        }
        return res;
    }

    public RoundDto getRoundById(Long roundId, Long userId) {
        Questionnaire q = null;
        RoundDto roundDto = null;
        Long qId = null;
        if (userId != null) {
            q = questionnaireRepository.findConfirmedByUserId(userId);
            qId = q != null ? q.getQuestionnaireId() : null;
        }

        if (roundId == null && userId != null){
            roundDto = new RoundDto();
            if (q != null) {
                roundDto.setStartupName(q.getName());
                roundDto.setStartupNameFullName(q.getFullName());
                roundDto.setLogoFile(q.getLogoFile());
                roundDto.setInviteFio(q.getInviteFio());
                roundDto.setEmail(q.getEmail());
                roundDto.setPhone(q.getPhoneNumber());
            }
        } else if (roundId != null) {
            Optional<RoundDao> roundDao = roundRepository.findById(roundId);
            if (roundDao.isEmpty())
                throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
            RoundDao dao = roundDao.get();
            Long roundQId = dao.getQuestionnaireId();
            Long roundDbId = dao.getRoundId();
            Integer type = q != null ? q.getType() : null;
            if (q != null
                    && q.getType() != null
                    && !q.getType().equals(2)
                    && !roundQId.equals(q.getQuestionnaireId()))
                return new RoundDto();

            if (userId != null && q != null && q.getType() != null && !q.getType().equals(0)) {
                Long viewCount = nvl(dao.getViewCount(), 0L) + 1;
                dao.setViewCount(viewCount);
                roundRepository.save(dao);
                if (objectActionRepository.findByObjectIdAndObjectTypeAndActionAndUserId(roundDbId, "Round", "view", userId).isEmpty())
                    objectActionRepository.save(new ObjectAction(roundDbId, "Round", "view", userId));
            }

            roundDto = roundDao.get().toDtoWithViewCount(type);

            q = questionnaireRepository.findByQuestionnaireId(roundQId);
            if (q != null) {
                roundDto.setStartupName(q.getName());
                roundDto.setLogoFile(q.getLogoFile());
                roundDto.setStartupNameFullName(q.getFullName());
                roundDto.setQuestionnaireMainLanguage(q.getMainLanguage());
            }
        }
        if (qId != null && roundDto != null && roundDto.getRoundId() != null)
            roundDto.setFavorite(getFavoriteByQId(qId, roundDto.getRoundId(), userId));

        return roundDto;
    }

    private void updateOldList(){
        List<RoundDao> processList = queryBuilder.getRoundList(new RoundListReq(List.of(GuideService.CONFIRMED_STATE, GuideService.CHECKING_STATE), false), null);
        if (!CollectionUtils.isEmpty(processList)){
            for(RoundDao r : processList){
                Date endDate = r.getEndDate() == null ? r.getPlanDate() : r.getEndDate();
                if (endDate != null && endDate.before(new Date())) {
                    VerifyReq verifyReq = new VerifyReq();
                    verifyReq.setTableId(String.valueOf(r.getRoundId()));
                    verifyReq.setTableName("Round");
                    verifyReq.setState(GuideService.ARCHIVE);
                    verifyMethod.execute(verifyReq);
                }
            }
        }
    }

    public RoundListRes getRoundList(RoundListReq req, Long userId, String role, String locale) {
        //STARTUPHUB-5250 [Back] Правка в сервис /list/round
        if (StringUtils.hasText(role) && "InvestDemo".equalsIgnoreCase(role)){
            if (!Boolean.TRUE.equals(req.getInvestment()))
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
            req.setRowCount(9);
            req.setPageToken(0);
        }

        //Проверяем просроченные раунды
        CompletableFuture.runAsync(this::updateOldList);

        RoundListRes res = new RoundListRes();
        Long qid = null;
        if (userId != null && !"Administrator".equalsIgnoreCase(role)) {
            Questionnaire q = questionnaireRepository.findAllByUserId(userId);
            qid = q != null ? q.getQuestionnaireId() : null;
        }
        if (req.getFavorite() != null){
            if (qid == null)
                req.setFavorite(null);
            else
                req.setQId(qid);
        }
        if (qid != null && req.getQuestionnaireId() == null){
            Questionnaire q = questionnaireRepository.findByQuestionnaireId(qid);
            if (q == null)
                throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
            if (q.getType() != null) {
                if (q.getType().equals(0))
                    req.setQuestionnaireId(q.getQuestionnaireId());
                else if (q.getType().equals(2) && (req.getState() == null || req.getState().size() == 0))
                    req.setState(List.of(GuideService.CONFIRMED_STATE));
            }
        }
        List<RoundDao> list = queryBuilder.getRoundList(req, userId);

        RoundListReq favoriteReq = new RoundListReq();

        if (list != null && list.size() > 0) {
            if (qid != null){
                favoriteReq.setFavorite(true);
                favoriteReq.setQId(qid);
                favoriteReq.setInvestment(req.getInvestment());
                favoriteReq.setState(req.getState());
                List<RoundDao> roundList = queryBuilder.getRoundList(favoriteReq, userId);
                res.setFavoriteCount(CollectionUtils.isEmpty(roundList) ? 0 : roundList.size());
            } else {
                res.setFavoriteCount(0);
            }
            res.setTotalRowCount(list.size());

            if (req.getRowCount() != null && !ObjectUtils.isEmpty(list)) {
                int offset = req.getPageToken() != null ? req.getPageToken() : 0;
                int from = req.getRowCount() * offset;
                int to = from + req.getRowCount();
                if (to >= list.size()) {
                    res.setNextPageToken(null);
                    to = list.size();
                } else {
                    res.setNextPageToken(offset + 1);
                }
                list = list.subList(from, to);
            }
            res.setRowCount(list.size());

            List<RoundDto> listDto = new ArrayList<>();
            RoundDto tempDtoList;
            for(RoundDao r : list) {
                tempDtoList = r.toDtoList();
                Questionnaire q = questionnaireRepository.findByQuestionnaireId(r.getQuestionnaireId());
                tempDtoList.setStartupName(q.getName());
                tempDtoList.setLogoFile(q.getLogoFile());
                if (userId != null && qid != null)
                    tempDtoList.setFavorite(getFavoriteByQId(qid, r.getRoundId(), userId));
                listDto.add(tempDtoList);
                setDTOLocalFields(r, tempDtoList, q, locale);
            }
            if (req.getSortBy() != null && req.getSortBy().equals("roundType")){
                listDto.sort(Comparator.comparing(RoundDto::getRoundTypeName));
                if ("DESC".equalsIgnoreCase(req.getOrderBy())){
                    Collections.reverse(listDto);
                }
            }
            res.setList(listDto);
        }
        if (res.getList() == null || res.getList().size() == 0)
            res.setList(new ArrayList<>());
        return res;
    }

    public void updateRoundV2(RoundReq req, Long roundId){
        eraseLegacyRoundReqFields(req);
        updateRound(req, roundId);
        updateRoundLocals(req, roundId);
    }

    public void updateRound(RoundReq req, Long roundId){
        Optional<RoundDao> round = roundRepository.findById(roundId);
        if (round.isEmpty()){
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        }
        RoundDao roundDao = round.get();
        if (req.getInvestment() != null){
            roundDao.setInvestment(req.getInvestment());
        }
        if (req.getRoundType() != null){
            roundDao.setRoundType(req.getRoundType());
        }
        if (req.getMarketingPercent() != null){
            roundDao.setMarketingPercent(req.getMarketingPercent());
        }
        if (req.getSoftwarePercent() != null){
            roundDao.setSoftwarePercent(req.getSoftwarePercent());
        }
        if (req.getTeamPercent() != null){
            roundDao.setTeamPercent(req.getTeamPercent());
        }
        if (req.getExtensionPercent() != null){
            roundDao.setExtensionPercent(req.getExtensionPercent());
        }
        if (req.getOtherDescription() != null){
            roundDao.setOtherDescription(req.getOtherDescription());
        }
        if (req.getOtherPercent() != null){
            roundDao.setOtherPercent(req.getOtherPercent());
        }
        if (req.getResult() != null){
            roundDao.setResult(req.getResult());
        }
        if (req.getSumInvestment() != null){
            roundDao.setSumInvestment(req.getSumInvestment());
        }
        if (req.getPercent() != null){
            roundDao.setPercent(req.getPercent());
        }
        if (req.getPreMoney() != null){
            roundDao.setPreMoney(req.getPreMoney());
        }
        if (req.getPostMoney() != null){
            roundDao.setPostMoney(req.getPostMoney());
        }
        if (req.getLeadCheck() != null){
            roundDao.setLeadCheck(req.getLeadCheck());
        }
        if (req.getLeadName() != null){
            roundDao.setLeadName(req.getLeadName());
        }
        if (req.getLastInvestment() != null){
            roundDao.setLastInvestment(req.getLastInvestment());
        }
        if (req.getFutureInvestment() != null){
            roundDao.setFutureInvestment(req.getFutureInvestment());
        }
        if (req.getGeography() != null){
            roundDao.setGeography(req.getGeography());
        }
        if (req.getTransactionType() != null){
            roundDao.setTransactionType(req.getTransactionType());
        }
        if (req.getRoundInfo() != null){
            roundDao.setRoundInfo(req.getRoundInfo());
        }
        if (req.getEndDate() != null){
            roundDao.setEndDate(req.getEndDate());
        }
        if (req.getPlanDate() != null){
            roundDao.setPlanDate(req.getPlanDate());
        }
        if (req.getPresentation() != null){
            roundDao.setPresentation(req.getPresentation());
        }
        if (req.getInviteFio() != null){
            roundDao.setInviteFio(req.getInviteFio());
        }
        if (req.getEmail() != null){
            roundDao.setEmail(req.getEmail());
        }
        if (req.getPhone() != null){
            roundDao.setPhone(req.getPhone());
        }
        roundDao.setModified(new Date());
        roundRepository.save(round.get());
        VerifyReq verifyReq = new VerifyReq();
        verifyReq.setTableId(String.valueOf(roundId));
        verifyReq.setTableName("Round");
        verifyReq.setState(20011L);
        verifyReq.setComment("Пользователь внес изменения");
        verifyMethod.execute(verifyReq);
    }

    public void addFavorite(AddFavoriteReq req, Long userId) {
        Questionnaire questionnaire = questionnaireRepository.findAllByUserId(userId);
        if (questionnaire == null)
            throw new SberxException(SberxErrors.USER_NOT_FOUND);
        Long qid = questionnaire.getQuestionnaireId();
        if (req.getObjectType().equals("Round")) {
            Optional<RoundDao> roundDaoOptional = roundRepository.findByRoundId(req.getId());
            if (roundDaoOptional.isEmpty())
                throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
            RoundDao roundDao = roundDaoOptional.get();
            if (req.getFavorite() != null) {
                if (qid != null) {
                    if (Boolean.TRUE.equals(req.getFavorite())) {
                        roundFavoriteRepository.save(new RoundFavorite(qid, roundDao.getRoundId(), userId));
                    } else {
                        roundFavoriteRepository.deleteByUserIdAndRoundId(userId, roundDao.getRoundId());
                    }
                }
            }
            roundRepository.save(roundDao);
        } else {
            if (Boolean.TRUE.equals(req.getFavorite())) {
                ObjectFavoriteDao objectFavorite = new ObjectFavoriteDao();
                objectFavorite.setObjectId(req.getId());
                objectFavorite.setObjectType(req.getObjectType());
                objectFavorite.setQuestionnaireId(questionnaire.getQuestionnaireId());
                objectFavorite.setUserId(userId);
                objectFavorite.setModified(new Date());
                objectFavoriteRepository.save(objectFavorite);
            } else {
                objectFavoriteRepository.deleteByObjectIdAndUserId(req.getId(),
                        userId,
                        req.getObjectType());
            }
        }
    }

    public RoundDto createRoundV2(RoundReq req, Long userId) {
        verifyRoundMultilangReq(req);
        req.setV2(true);
        RoundDto dto = createRound(req, userId);
        if (dto != null && dto.getRoundId() != null) {
            createRoundLocals(req, dto);
        }
        return dto;
    }

    public RoundDto createRound(RoundReq req, Long userId) {
        RoundDto res = new RoundDto();
        RoundDao round;
        Long questionnaireId = req.getQuestionnaireId();
        if (req.getRoundId() != null){
            Optional<RoundDao> roundOpt = roundRepository.findById(req.getRoundId());
            round = roundOpt.orElseGet(RoundDao::new);
        } else {
            round = new RoundDao();
        }
        if (questionnaireId == null && userId != null){
            Questionnaire q = questionnaireRepository.findConfirmedByUserId(userId);
            if (q == null || q.getQuestionnaireId() == null)
                q = questionnaireRepository.findAllByUserId(userId);
            if (q != null && q.getType() != null && q.getType().equals(0))
                questionnaireId = q.getQuestionnaireId();
            else
                throw new SberxException(SberxErrors.ACCESS_FORBIDDEN);
        }
        if (!roundRepository.findByQuestionnaireIdAndState(questionnaireId, GuideService.CHECKING_STATE.intValue()).isEmpty()){
            throw new SberxException(SberxErrors.USER_EXISTS, "Активный раунд уже существует");
        }
        round.setQuestionnaireId(questionnaireId);
        round.setState(GuideService.CHECKING_STATE.intValue());
        round.setModified(req.getModified() == null ? new Date() : req.getModified());
        round.setCreated(req.getCreated() == null ? new Date() : req.getCreated());
        round.setInvestment(req.getInvestment());
        round.setRoundType(req.getRoundType());
        round.setInvestmentPurpose(req.getInvestmentPurpose());
        round.setSumInvestment(req.getSumInvestment());
        round.setPercent(req.getPercent());
        round.setPreMoney(req.getPreMoney());
        round.setPostMoney(req.getPostMoney());
        round.setResult(req.getResult());
        round.setLeadCheck(req.getLeadCheck());
        round.setLeadName(req.getLeadName());
        round.setLastInvestment(req.getLastInvestment());
        round.setFutureInvestment(req.getFutureInvestment());
        round.setGeography(req.getGeography());
        round.setTransactionType(req.getTransactionType());
        round.setRoundInfo(req.getRoundInfo());
        round.setEndDate(req.getEndDate());
        round.setPlanDate(req.getPlanDate());
        round.setPresentation(req.getPresentation());
        round.setMarketingPercent(req.getMarketingPercent());
        round.setSoftwarePercent(req.getSoftwarePercent());
        round.setTeamPercent(req.getTeamPercent());
        round.setExtensionPercent(req.getExtensionPercent());
        round.setOtherDescription(req.getOtherDescription());
        round.setOtherPercent(req.getOtherPercent());
        round.setInviteFio(req.getInviteFio());
        round.setEmail(req.getEmail());
        round.setPhone(req.getPhone());
        round.setViewCount(0L);
        if (Boolean.TRUE.equals(req.getV2())) {
            round.setLanguages(new String[]{"ru","en"});
        }
        roundRepository.save(round);
        res.setRoundId(round.getRoundId());
        Questionnaire q = questionnaireRepository.findByQuestionnaireId(questionnaireId);
        UserQuestionnaire uq = userQuestionnaireRepository.findFirstByQuestionnaireId(questionnaireId);

        midService.notify("RoundCreated",
                Map.of("name", q != null ? q.getName() : ""),
                req.getEmail(),
                userAuth.getUserByExternalId(userId),
                "Создание раунда инвестиций",
                "/investment/" + round.getRoundId(),
                uq != null ? uq.getUserId() : null,
                q != null ? q.getType() : null);
        return res;
    }

    private void eraseLegacyRoundDtoFields(RoundDto res) {
        res.setStartupName(null);
        res.setOtherDescription(null);
        res.setResult(null);
        res.setLeadName(null);
        res.setRoundInfo(null);
        res.setPresentation(null);
        res.setLogoFile(null);
        res.setInviteFio(null);
        res.setEmail(null);
        res.setPhone(null);

        res.setQuestionnaireMainLanguage(null);
    }

    private void eraseLegacyRoundReqFields(RoundReq req) {
        req.setOtherDescription(null);
        req.setLeadName(null);
        req.setRoundInfo(null);
        req.setPresentation(null);
        req.setInviteFio(null);
        req.setEmail(null);
        req.setPhone(null);
    }

    private void createRoundLocals(RoundReq req, RoundDto dto) {
        for(Multilang multilang : req.getMultilang()) {
            RoundLocal roundLocal = new RoundLocal(
                    new RoundLocal.RoundLocalCompositeKey(
                            dto.getRoundId(),
                            multilang.getLang()),
                    null,
                    multilang.getFields().getOtherDescription(),
                    multilang.getFields().getResult(),
                    multilang.getFields().getLeadName(),
                    multilang.getFields().getRoundInfo(),
                    multilang.getFields().getPresentation(),
                    multilang.getFields().getInviteFio(),
                    multilang.getFields().getEmail(),
                    multilang.getFields().getPhone());
            roundLocalRepository.save(roundLocal);
        }
    }

    private void updateRoundLocals(RoundReq req, Long roundId) {
        if (roundId == null || req == null || req.getMultilang() == null || req.getMultilang().isEmpty()) {
            return;
        }
        RoundLocal roundLocalExample = new RoundLocal();
        roundLocalExample.setRoundIdLang(
                new RoundLocal.RoundLocalCompositeKey(
                        roundId, null)
        );
        Set<String> languages = roundLocalRepository
                .findAll(
                        Example.of(roundLocalExample)
                )
                .stream()
                .map(
                        roundLocal -> roundLocal.getRoundIdLang().getLang()).collect(Collectors.toSet()
                );
        for (Multilang multilang : req.getMultilang()) {
            if (StringUtils.hasText(multilang.getLang()) && multilang.getFields() != null) {
                if (languages.contains(multilang.getLang())) {
                    updateRoundLocalDao(multilang, roundId);
                } else {
                    createRoundLocalDao(multilang, roundId);
                }
            }
        }
    }

    private void updateRoundLocalDao(Multilang multilang, Long roundId) {
        RoundLocal roundLocalExample = new RoundLocal();
        roundLocalExample.setRoundIdLang(
                new RoundLocal.RoundLocalCompositeKey(
                        roundId, multilang.getLang())
        );
        List<RoundLocal> roundLocals = roundLocalRepository.findAll(Example.of(roundLocalExample));
        if (roundLocals.size() > 1) {
            throw new SberxException(SberxErrors.INTERNAL_ERROR);
        }
        RoundLocal dao = roundLocals.get(0);
        if (multilang.getFields().getOtherDescription() != null) {
            dao.setOtherDescription(multilang.getFields().getOtherDescription());
        }
        if (multilang.getFields().getResult() != null) {
            dao.setResult(multilang.getFields().getResult());
        }
        if (multilang.getFields().getLeadName() != null) {
            dao.setLeadName(multilang.getFields().getLeadName());
        }
        if (multilang.getFields().getRoundInfo() != null) {
            dao.setRoundInfo(multilang.getFields().getRoundInfo());
        }
        if (multilang.getFields().getPresentation() != null) {
            dao.setPresentation(multilang.getFields().getPresentation());
        }
        if (multilang.getFields().getInviteFio() != null) {
            dao.setInviteFio(multilang.getFields().getInviteFio());
        }
        if (multilang.getFields().getEmail() != null) {
            dao.setEmail(multilang.getFields().getEmail());
        }
        if (multilang.getFields().getPhone() != null) {
            dao.setPhone(multilang.getFields().getPhone());
        }
        roundLocalRepository.save(dao);
    }

    private void createRoundLocalDao(Multilang multilang, Long roundId) {
        RoundLocal dao = new RoundLocal(
                new RoundLocal.RoundLocalCompositeKey(
                        roundId,
                        multilang.getLang()
                ),
                null,
                multilang.getFields().getOtherDescription(),
                multilang.getFields().getResult(),
                multilang.getFields().getLeadName(),
                multilang.getFields().getRoundInfo(),
                multilang.getFields().getPresentation(),
                multilang.getFields().getInviteFio(),
                multilang.getFields().getEmail(),
                multilang.getFields().getPhone()
        );
        roundLocalRepository.save(dao);
    }

    private void verifyRoundMultilangReq(RoundReq req) {
        if (req == null || req.getMultilang() == null) {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        }
        for (Multilang multilang : req.getMultilang()) {
            if (!StringUtils.hasText(multilang.getLang())) {
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
            }
            if (multilang.getFields() == null) {
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
            }
            if (
                     !StringUtils.hasText(multilang.getFields().getInviteFio())
                    || multilang.getFields().getPhone() == null
                    || !StringUtils.hasText(multilang.getFields().getEmail())
            ) {
                throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
            }
        }
    }

    private Boolean getFavoriteByQId(Long qid, Long rid, Long userId){
        if (qid != null) {
            RoundFavorite rf = roundFavoriteRepository.findByQuestionnaireIdAndRoundId(qid, rid, userId);
            return rf != null && rf.getRoundId() != null;
        }
        return false;
    }

    private void setDTOMultilangFields(RoundDto dto) {
        List<QuestionnaireLocaleDao> questionnaireLocalList = questionnaireLocaleRepository
                .findByQuestionnaireId(dto.getQuestionnaireId());

        RoundLocal roundLocalExample = new RoundLocal();
        roundLocalExample.setRoundIdLang(
                new RoundLocal.RoundLocalCompositeKey(
                        dto.getRoundId(), null));
        List<RoundLocal> roundLocalList = roundLocalRepository.findAll(Example.of(roundLocalExample));

        if (roundLocalList == null || roundLocalList.isEmpty()) {
            dto.setMultilang(
                    getDefaultMultilangList(questionnaireLocalList, dto)
            );
        } else {
            dto.setMultilang(
                    getMultilangList(roundLocalList, questionnaireLocalList, dto)
            );
        }
    }

    private List<Multilang> getDefaultMultilangList(List<QuestionnaireLocaleDao> questionnaireLocalList, RoundDto dto) {
        List<Multilang> multilangList = new ArrayList<>();
        Multilang multilang = new Multilang();
        if (StringUtils.hasText(dto.getQuestionnaireMainLanguage())) {
            multilang.setLang(dto.getQuestionnaireMainLanguage());
        }
        Multilang.FieldDto fieldDto = new Multilang.FieldDto();
        fieldDto.setOtherDescription(dto.getOtherDescription());
        fieldDto.setStartupName(setLocalStartupNameOrDefaultName(
                questionnaireLocalList, dto, dto.getQuestionnaireMainLanguage()
        ));
        fieldDto.setResult(dto.getResult());
        fieldDto.setLeadName(dto.getLeadName());
        fieldDto.setRoundInfo(dto.getRoundInfo());
        fieldDto.setInviteFio(dto.getInviteFio());
        fieldDto.setPhone(dto.getPhone());
        fieldDto.setEmail(dto.getEmail());
        fieldDto.setPresentation(dto.getPresentation());
        fieldDto.setLogoFile(setLocalLogoFileOrDefaultLogoFile(
                questionnaireLocalList, dto, dto.getQuestionnaireMainLanguage()
        ));
        multilang.setFields(fieldDto);

        multilangList.add(multilang);
        return multilangList;
    }

    private List<Multilang> getMultilangList(
            List<RoundLocal> roundLocalList, List<QuestionnaireLocaleDao> questionnaireLocalList, RoundDto dto) {
        List<Multilang> multilangList = new ArrayList<>();
        if (roundLocalList == null || roundLocalList.isEmpty()) {
            return multilangList;
        }
        roundLocalList.forEach(roundLocal -> multilangList.add(
                new Multilang(
                        roundLocal.getRoundIdLang().getLang(), Multilang.FieldDto.builder()
                        .otherDescription(roundLocal.getOtherDescription())
                        .startupName(setLocalStartupNameOrDefaultName(
                                questionnaireLocalList, dto, roundLocal.getRoundIdLang().getLang())
                        )
                        .result(roundLocal.getResult())
                        .leadName(roundLocal.getLeadName())
                        .roundInfo(roundLocal.getRoundInfo())
                        .inviteFio(roundLocal.getInviteFio())
                        .phone(roundLocal.getPhone())
                        .email(roundLocal.getEmail())
                        .presentation(roundLocal.getPresentation())
                        .logoFile(setLocalLogoFileOrDefaultLogoFile(
                                questionnaireLocalList, dto, roundLocal.getRoundIdLang().getLang())
                        )
                        .build()
                )
        ));
        return multilangList;
    }

    private String setLocalStartupNameOrDefaultName(
            List<QuestionnaireLocaleDao> questionnaireLocalList, RoundDto dto, String lang) {
        Map<String, String> startupLangAndNamesSet = questionnaireLocalList
                .stream().collect(Collectors.toMap(
                        QuestionnaireLocaleDao::getLang, QuestionnaireLocaleDao::getName));
        return startupLangAndNamesSet.getOrDefault(lang, dto.getStartupName());
    }

    private String setLocalLogoFileOrDefaultLogoFile(
            List<QuestionnaireLocaleDao> questionnaireLocalList, RoundDto dto, String lang) {
        Map<String, String> logoFilesAndNamesSet = questionnaireLocalList
                .stream().collect(Collectors.toMap(
                        QuestionnaireLocaleDao::getLang, QuestionnaireLocaleDao::getLogoFile));
        return logoFilesAndNamesSet.getOrDefault(lang, dto.getLogoFile());
    }

    private void setDTOLocalFields(RoundDao dao, RoundDto dto, Questionnaire questionnaire, String lang) {
        if (questionnaire != null && questionnaire.getQuestionnaireId() != null && lang != null) {
            QuestionnaireLocaleDao questionnaireLocale = questionnaireLocaleRepository
                    .findByQuestionnaireIdAndLang(questionnaire.getQuestionnaireId(), lang);
            if (questionnaireLocale != null) {
                dto.setStartupName(questionnaireLocale.getName());
                dto.setLogoFile(questionnaireLocale.getLogoFile());
            }
        }
        List<LanguagesDTO> languages = new ArrayList<>();
        if (dao.getLanguages() == null || dao.getLanguages().length == 0) {
            dto.setLanguages(languages);
            return;
        }
        RoundLocal roundLocalExample = new RoundLocal();
        roundLocalExample.setRoundIdLang(
                new RoundLocal.RoundLocalCompositeKey(
                        dao.getRoundId(), null));
        List<RoundLocal> roundLocalList = roundLocalRepository.findAll(Example.of(roundLocalExample));
        if (roundLocalList == null || roundLocalList.isEmpty()) {
            for (String language : dao.getLanguages()) {
                languages.add(new LanguagesDTO(language, false));
            }
            dto.setLanguages(languages);
            return;
        }
        Set<String> roundLocalLangSet = roundLocalList.stream()
                .map(roundLocal -> roundLocal.getRoundIdLang().getLang()).collect(Collectors.toSet());
        for (String language : dao.getLanguages()) {
            if (roundLocalLangSet.contains(language)) {
                languages.add(new LanguagesDTO(language, true));
            } else {
                languages.add(new LanguagesDTO(language, false));
            }
        }
        dto.setLanguages(languages);
    }
}
