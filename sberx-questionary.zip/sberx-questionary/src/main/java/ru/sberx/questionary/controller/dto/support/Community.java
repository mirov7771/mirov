package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.Date;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Community {
    private Long state;
    private Integer type;
    private String name;
    private String site;
    private String position;
    private String phoneNumber;
    private String expectation;
    private String useful;
    private Long[] industry;
    private Long[] technology;
    private Long geography;
    private long[] round;
    private Long ventureProjectsCount;
    private String facebook;
    private String comment;
    private Long id;
    private Long questionnaireId;
    private String stateName;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    @JsonFormat(timezone = "GMT+3")
    private Date created;
    private String typeName;
    private Boolean preauth;
    private String email;
    private String expert;
    private String fio;
    private String telegram;
    private Long questionnaireState;
    private String questionnaireStateName;
}
