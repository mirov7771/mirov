package ru.sberx.questionary.controller.dto.support;

import lombok.Data;

@Data
public class UserConsent {
    private Boolean sber500PrivacyPolicy;
    private Boolean sber500Consent;
    private Boolean sber500PersonalDataConsent;
    private Boolean sber500TermOfUse;
    private Boolean mailingConsent;
}
