package ru.sberx.questionary.service.impl.method;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.builder.DtoBuilder;
import ru.sberx.questionary.builder.RecommendBuilder;
import ru.sberx.questionary.builder.ResultBuilder;
import ru.sberx.questionary.controller.dto.req.QuestionnaireListReq;
import ru.sberx.questionary.controller.dto.res.GetUserRes;
import ru.sberx.questionary.controller.dto.support.Questionnaire;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.util.GuideService;
import ru.sberx.questionary.util.Utils;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
@Slf4j
public class ListMethod {

    private final ResultBuilder resultBuilder;
    private final DtoBuilder dtoBuilder;
    private final UserAuth userAuth;
    private final QuestionnaireRepository questionnaireRepository;
    private final ru.sberx.questionary.gate.service.GuideService guideService;
    private final RecommendBuilder recommendBuilder;

    private static final List<Map<String, Object>> industries = new ArrayList<>();
    private static final List<Map<String, Object>> qIndustries = new ArrayList<>();
    public static List<Map<String, Object>> guides = new ArrayList<>();

    @SuppressWarnings("unchecked")
    @PostConstruct
    void setIndustries() {
        try {
            if (CollectionUtils.isEmpty(industries)) {
                List<Map<String, Object>> guide = guideService.getGuideById(3000L);
                if (!CollectionUtils.isEmpty(guide)
                        && guide.get(0).get("values") != null
                        && guide.get(0).get("values") instanceof List) {
                    industries.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
                    guides.addAll(industries);
                }
            }

            if (CollectionUtils.isEmpty(qIndustries)) {
                List<Map<String, Object>> guide = guideService.getGuideById(22000L);
                if (!CollectionUtils.isEmpty(guide)
                        && guide.get(0).get("values") != null
                        && guide.get(0).get("values") instanceof List) {
                    qIndustries.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
                    guides.addAll(qIndustries);
                }
            }


            List<Map<String, Object>> guide = guideService.getGuideById(13000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }


            guide = guideService.getGuideById(2000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }

            guide = guideService.getGuideById(8000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }

            guide = guideService.getGuideById(24000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }

            guide = guideService.getGuideById(27000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }

            guide = guideService.getGuideById(5000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }

            guide = guideService.getGuideById(38000L);
            if (!CollectionUtils.isEmpty(guide)
                    && guide.get(0).get("values") != null
                    && guide.get(0).get("values") instanceof List) {
                guides.addAll((List<Map<String, Object>>) guide.get(0).get("values"));
            }

        } catch (Exception e) {
            log.error("Error: ", e);
        }

    }

    public List<Questionnaire> getParticipantList(QuestionnaireListReq req) {
        if (req.getType() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Missing parameter: type");
        UserQuestionary u = getQId(req.getSessionId(), null);
        if (u != null) {
            if (u.getQuestionaryId() != null)
                req.setQId(u.getQuestionaryId());
            if (u.getUserId() != null)
                req.setQUserId(u.getUserId());
            if (req.getRecommend() != null)
                CompletableFuture.runAsync(() -> recommendBuilder.build(u.getQuestionaryId()));
        }

        List<ru.sberx.questionary.dao.model.Questionnaire> list = resultBuilder
                .getQuestionnaireListByCriteria(req);

        List<Questionnaire> listRes = dtoBuilder
                .createListRes(list,
                        req.getPreauthorize(),
                        req.getForLending(),
                        req.getType(),
                        req.getClientId(),
                        req.getSortBy() != null,
                        req.getQId(),
                        req.getFilteredBy(),
                        req.getQUserId(),
                        req.getIsImport(),
                        req.getLang(),
                        req.getAdmin());
        Integer type = req.getType();

        if (Boolean.TRUE.equals(req.getAdmin())) {
            listRes.forEach(q -> {
                if (type.equals(0)) {
                    q.setTypeLabel("Стартап");
                } else if (type.equals(1)) {
                    q.setTypeLabel("Корпорация");
                } else if (type.equals(2)) {
                    if (Long.valueOf(11001L).equals(q.getInvestorType())) {
                        q.setTypeLabel("Венчурный фонд");
                    } else if (Long.valueOf(11002L).equals(q.getInvestorType())) {
                        q.setTypeLabel("Бизнес-ангел");
                    } else if (Long.valueOf(11003L).equals(q.getInvestorType())) {
                        q.setTypeLabel("Институт развития");
                    } else if (Long.valueOf(11004L).equals(q.getInvestorType())) {
                        q.setTypeLabel("Family Office");
                    } else if (q.getInvestorType() == null) {
                        q.setTypeLabel("Инвестор");
                    }
                }
                q.setUserMail(q.getEmail());
                q.setUserPhone(q.getPhoneNumber());
            });
        }
        if (req.getSortBy() == null) {
            if (!Boolean.TRUE.equals(needSort(req.getState()))) {
                if (req.getFilteredBy() != null && !"".equals(req.getFilteredBy())) {
                    listRes.sort((q1, q2) -> "createDateDesc".equalsIgnoreCase(req.getFilteredBy())
                            ? q2.getCreated().compareTo(q1.getCreated())
                            : q1.getCreated().compareTo(q2.getCreated()));
                } else if (Boolean.TRUE.equals(req.getPrioritySort())) {
                    listRes.sort((q1, q2) -> {
                        if (q1.getPriority() == null && q2.getPriority() == null) {
                            return q2.getCreated().compareTo(q1.getCreated());
                        } else if (q1.getPriority() == null) {
                            return 1;
                        } else if (q2.getPriority() == null) {
                            return -1;
                        } else {
                            return q2.getPriority() - q1.getPriority();
                        }
                    });
                } else if (!Boolean.TRUE.equals(req.getForLending())) {
                    listRes.sort((q1, q2) -> {
                        Date dt2 = q2.getModified() == null ? q2.getCreated() : q2.getModified();
                        Date dt1 = q1.getModified() == null ? q1.getCreated() : q1.getModified();
                        if (dt2 != null && dt1 != null) {
                            return dt2.compareTo(dt1);
                        } else if (dt2 != null) {
                            return 1;
                        } else if (dt1 != null) {
                            return -1;
                        }
                        return 0;
                    });
                }
            } else if (type.equals(2)) {
                if (!CollectionUtils.isEmpty(listRes)) {
                    listRes.sort(Comparator.comparing(Questionnaire::getInvestorSort).thenComparing(Questionnaire::getQuestionnaireId));
                }
            } else {
                if (!CollectionUtils.isEmpty(listRes)) {
                    if (req.getType() != 0 || Objects.isNull(req.getSessionId())) {
                        listRes.sort(Comparator.comparing(Questionnaire::getModified));
                    } else {
                        List<Questionnaire> newListRes = listRes
                                .stream()
                                .filter(i -> i.getUpdateDateForSort() != null)
                                .sorted(Comparator.comparing(Questionnaire::getUpdateDateForSort))
                                .collect(Collectors.toList());
                        List<Questionnaire> newListRes2 = listRes
                                .stream()
                                .filter(i -> i.getUpdateDateForSort() == null)
                                .sorted(Comparator.comparing(e -> e.getModified() == null ? e.getCreated() : e.getModified()))
                                .collect(Collectors.toList());
                        listRes.clear();
                        listRes.addAll(newListRes2);
                        listRes.addAll(newListRes);
                    }
                    Collections.reverse(listRes);
                    for (int i = 0; i < listRes.size(); i++) {
                        listRes.get(i).setIsNew(i < 6);
                    }
                }
            }
        }

        if (!CollectionUtils.isEmpty(listRes) && (type.equals(1) || type.equals(2)))
            swapList(listRes, type.equals(1) ? "Сбер" : "Fort Ross Ventures");

        List<Questionnaire> filteredList = new ArrayList<>();
        if (StringUtils.hasText(req.getSearch())) {
            //1)отбираем все по name
            for (Questionnaire q : listRes) {
                if (StringUtils.hasText(q.getName()) && q.getName().toUpperCase().contains(req.getSearch().toUpperCase()))
                    filteredList.add(q);
            }

            //2)отбираем все по fullName
            for (Questionnaire q : listRes) {
                if (!filteredList.contains(q)
                        && StringUtils.hasText(q.getFullName())
                        && q.getFullName().toUpperCase().contains(req.getSearch().toUpperCase()))
                    filteredList.add(q);
            }

            if (Boolean.TRUE.equals(req.getIsImport())) {
                for (Questionnaire q : listRes) {
                    if (!filteredList.contains(q)
                            && !CollectionUtils.isEmpty(q.getImportReplaceName())
                            && q.getImportReplaceName().stream().anyMatch(i -> i.toUpperCase().contains(req.getSearch().toUpperCase())))
                        filteredList.add(q);
                }

                for (Questionnaire q : listRes) {
                    if (!filteredList.contains(q)
                            && q.getProject() != null
                            && StringUtils.hasText(q.getProject().getCompetitor())
                            && q.getProject().getCompetitor().toUpperCase().contains(req.getSearch().toUpperCase()))
                        filteredList.add(q);
                }

            } else {

                //3)отбираем все по note и fullNote
                for (Questionnaire q : listRes) {
                    if (!filteredList.contains(q)) {
                        if (StringUtils.hasText(q.getNote())
                                && q.getNote().toUpperCase().contains(req.getSearch().toUpperCase()))
                            filteredList.add(q);
                        else if (StringUtils.hasText(q.getFullNote())
                                && q.getFullNote().toUpperCase().contains(req.getSearch().toUpperCase()))
                            filteredList.add(q);
                    }
                }

                //4)отбираем все по project.problem
                if (req.getType().equals(0)) {
                    for (Questionnaire q : listRes) {
                        if (!filteredList.contains(q)
                                && q.getProject() != null
                                && StringUtils.hasText(q.getProject().getProblem())
                                && q.getProject().getProblem().toUpperCase().contains(req.getSearch().toUpperCase()))
                            filteredList.add(q);
                    }
                }

                //5)отбираем все по industry
                if (req.getType().equals(1)) {
                    if (!CollectionUtils.isEmpty(qIndustries)) {
                        for (Questionnaire q : listRes) {
                            if (!filteredList.contains(q)
                                    && q.getIndustry() != null
                                    && q.getIndustry().length > 0) {
                                for (Map<String, Object> g : qIndustries) {
                                    Long code = Utils.castToLong(g.get("code"));
                                    String name = Utils.castToString(g.get("name"));
                                    List<Long> inds = Arrays.asList(q.getIndustry());
                                    if (inds.contains(code) && name.toUpperCase().contains(req.getSearch().toUpperCase()))
                                        filteredList.add(q);
                                }
                            }
                        }
                    }
                }


                //6)отбираем все по project.auditory
                if (req.getType().equals(0)) {
                    for (Questionnaire q : listRes) {
                        if (!filteredList.contains(q)
                                && q.getProject() != null
                                && StringUtils.hasText(q.getProject().getAuditory())
                                && q.getProject().getAuditory().toUpperCase().contains(req.getSearch().toUpperCase()))
                            filteredList.add(q);
                    }
                }

                //7)отбираем все по invite_fio
                for (Questionnaire q : listRes) {
                    if (!filteredList.contains(q)
                            && StringUtils.hasText(q.getInviteFio())
                            && q.getInviteFio().toUpperCase().contains(req.getSearch().toUpperCase()))
                        filteredList.add(q);
                }

                //8)отбираем все по inn
                for (Questionnaire q : listRes) {
                    if (!filteredList.contains(q)
                            && StringUtils.hasText(q.getInn())
                            && q.getInn().toUpperCase().contains(req.getSearch().toUpperCase()))
                        filteredList.add(q);
                }

                //9)отбираем все по email
                for (Questionnaire q : listRes) {
                    if (!filteredList.contains(q)
                            && StringUtils.hasText(q.getEmail())
                            && q.getEmail().toUpperCase().contains(req.getSearch().toUpperCase()))
                        filteredList.add(q);
                }
            }
            return filteredList;
        }
        if (!CollectionUtils.isEmpty(req.getReplaceName())) {
            for (Questionnaire q : listRes) {
                if (!CollectionUtils.isEmpty(q.getImportReplaceName())
                        && q.getImportReplaceName().stream()
                        .anyMatch(name -> req.getReplaceName().stream().anyMatch(reqName -> name.toUpperCase().contains(reqName.toUpperCase()))))
                    filteredList.add(q);
            }
            return filteredList;
        }
        if (!CollectionUtils.isEmpty(listRes) && !Boolean.TRUE.equals(req.getAdmin()))
            return listRes.stream()
                    .collect(Collectors.partitioningBy(q -> !Boolean.TRUE.equals(q.existLang(req.getLang()))))
                    .values()
                    .stream()
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        return listRes;
    }

    private void swapList(List<ru.sberx.questionary.controller.dto.support.Questionnaire> list, String name) {
        ru.sberx.questionary.controller.dto.support.Questionnaire item = null;
        for (ru.sberx.questionary.controller.dto.support.Questionnaire i : list) {
            if (i.getName() != null && i.getName().equals(name)) {
                item = i;
                break;
            }
        }
        if (item != null) {
            list.remove(item);
            list.add(0, item);
        }
    }

    private Boolean needSort(List<Long> state) {
        return state != null && state.size() == 1 && state.get(0).equals(GuideService.CONFIRMED_STATE);
    }

    private UserQuestionary getQId(String sessionId, Long currentUserId) {
        Long userId = null;
        if (StringUtils.hasText(sessionId)) {
            userId = userAuth.getUserId(sessionId);
        } else if (currentUserId != null) {
            GetUserRes userInfo = userAuth.getUserInfo(currentUserId, null);
            userId = userInfo.getExternalId();
        }
        if (userId != null) {
            UserQuestionary u = new UserQuestionary();
            u.setUserId(userId);
            ru.sberx.questionary.dao.model.Questionnaire questionnaire = questionnaireRepository.findAllByUserId(userId);
            if (questionnaire != null)
                u.setQuestionaryId(questionnaire.getQuestionnaireId());
            return u;
        }
        return null;
    }

    @Data
    private static class UserQuestionary {
        private Long userId;
        private Long questionaryId;
    }
}
