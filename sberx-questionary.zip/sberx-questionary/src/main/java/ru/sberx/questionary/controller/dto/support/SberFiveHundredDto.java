package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SberFiveHundredDto {

    private Long questionnaireId;
    @JsonProperty("firsttime")
    private Boolean firstTime;
    private String motivation;
    @JsonProperty("monthrevenue")
    private String monthRevenue;
    @JsonProperty("quarterrevenue")
    private String quarterRevenue;
    private Integer clients;
    @JsonProperty("ecorequirement")
    private Integer[] ecoRequirement;

}
