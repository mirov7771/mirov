package ru.sberx.questionary.controller.questionary;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.service.questionary.QuestionaryService;

@RestController
@RequestMapping("${spring.application.name}/questionary")
@RequiredArgsConstructor
public class QuestionaryController {

    private final QuestionaryService service;

    @PutMapping(value = "/lastenter", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> lastEnter(@RequestHeader("user-id") Long userId){
        return ResponseBuilder.build(service.lastEnter(userId));
    }

}
