package ru.sberx.questionary.service.statistic;

import ru.sberx.questionary.controller.dto.req.StatisticReq;
import ru.sberx.questionary.controller.dto.support.Statistic;

import java.util.List;

public interface StatisticService {
    List<Statistic> getStatistic(StatisticReq req);
    List<Statistic> getReplyStatisticByTableName(String role, String tableName);
}
