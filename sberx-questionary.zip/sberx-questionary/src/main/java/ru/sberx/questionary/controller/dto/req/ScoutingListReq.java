package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class ScoutingListReq {
    private String name;
    private List<Long> state;
    private Integer rowCount;
    private Integer pageToken;
    private Long userId;
    private Long questionnaireId;
}
