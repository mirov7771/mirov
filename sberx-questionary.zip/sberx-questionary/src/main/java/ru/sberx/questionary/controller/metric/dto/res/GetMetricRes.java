package ru.sberx.questionary.controller.metric.dto.res;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.dao.model.MetricDao;

import java.util.Date;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GetMetricRes {

    private Long metricType;
    private String metricName;
    private String currency;
    private String currencyName;
    private List<Value> values;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class Value {
        @JsonFormat(timezone = "GMT+3")
        private Date date;
        private Long value;

        public Value(MetricDao metricDao) {
            this.date = metricDao.getDate();
            this.value = metricDao.getValue();
        }
    }
}
