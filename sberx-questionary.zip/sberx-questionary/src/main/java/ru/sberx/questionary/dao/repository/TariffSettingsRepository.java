package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.TariffSettings;

import java.util.List;

@Repository
public interface TariffSettingsRepository extends CrudRepository<TariffSettings, Long> {

    @NonNull
    @Override
    List<TariffSettings> findAll();

    List<TariffSettings> findBySysNameAndType(String sysName, Integer type);

    TariffSettings findFirstBySysName(String sysName);

    @Query(value = "select * from tariff_settings ts where ts.sysname = :sysName and ts.type = :type and :subType = any(ts.subtype)", nativeQuery = true)
    List<TariffSettings> findBySysNameAndTypeAndSubTypeContains(String sysName, Integer type, Integer subType);

    List<TariffSettings> findByType(Integer type);

    @Query(value = "select * from tariff_settings ts where ts.type = :type and :subType = any(ts.subtype)", nativeQuery = true)
    List<TariffSettings>  findByTypeAndSubType(Integer type, Integer subType);
}
