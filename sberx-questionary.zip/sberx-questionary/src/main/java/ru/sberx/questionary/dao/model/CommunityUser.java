package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "COMMUNITYUSER")
@Data
public class CommunityUser implements Serializable {

    private static final long serialVersionUID = 2444690820052474465L;

    @Id
    @Column(name = "COMMUNITYUSERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long communityUserId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "AMBITION")
    private String ambition;
    @Column(name = "EXPECTATION")
    private String expectation;
    @Column(name = "STATE")
    private Long state;

}
