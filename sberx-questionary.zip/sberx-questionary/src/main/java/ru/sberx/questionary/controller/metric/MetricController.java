package ru.sberx.questionary.controller.metric;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.dto.req.PostMetricReq;
import ru.sberx.questionary.controller.metric.dto.req.GetMetricReq;
import ru.sberx.questionary.service.metric.MetricService;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("${spring.application.name}/metric")
@RequiredArgsConstructor
public class MetricController {

    private final MetricService service;

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestHeader(value = "user-id") Long userId,
                                  @Valid @RequestBody PostMetricReq req) {
        req.setUserId(userId);
        service.post(req);
        return ResponseEntity.ok().body(null);
    }

    @PutMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> put(@RequestHeader(value = "user-id") Long userId,
                                 @Valid @RequestBody PostMetricReq req) {
        req.setUserId(userId);
        service.put(req);
        return ResponseEntity.ok().body(null);
    }

    @GetMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestHeader(value = "user-id") Long userId,
                                 GetMetricReq req) {
        req.setUserId(userId);
        return ResponseBuilder.build(service.get(req));
    }

    @GetMapping(value = "list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> list(@RequestHeader(value = "user-id") Long userId,
                                  @RequestParam(value = "addData", required = false) Boolean addData,
                                  @RequestParam(value = "uuid", required = false) String uuid) {
        return ResponseBuilder.build(service.list(userId, addData, uuid));
    }

    @DeleteMapping(value = "{metric}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> delete(@RequestHeader(value = "user-id") Long userId,
                                    @PathVariable("metric") Integer metric) {
        service.delete(metric, userId);
        return ResponseEntity.ok().body(null);
    }

    @GetMapping(value = "type", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> type(){
        return ResponseBuilder.build(service.type());
    }
}
