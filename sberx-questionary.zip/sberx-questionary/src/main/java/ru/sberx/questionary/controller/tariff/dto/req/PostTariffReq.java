package ru.sberx.questionary.controller.tariff.dto.req;

import lombok.Data;

@Data
public class PostTariffReq {

    private Long userId;
    private String role;
    private Long id;
    private String sysname;
    private Long questionnaireId;
    private String questionnaireUuid;
}
