package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

import java.util.List;

@Data
public class TypeListReq {
    private List<Long> userId;
}
