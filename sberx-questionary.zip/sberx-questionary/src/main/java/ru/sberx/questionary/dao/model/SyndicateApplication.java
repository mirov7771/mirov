package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.questionary.controller.dto.support.Syndicate;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "SYNDICATE_APPLICATION")
@Getter
@Setter
public class SyndicateApplication implements Serializable {

    private static final long serialVersionUID = 8430285669871810063L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "TYPE")
    private Integer type;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Column(name = "LAST_NAME")
    private String lastName;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "POSITION")
    private String position;
    @Column(name = "ORG_FULL_NAME")
    private String orgFullName;
    @Column(name = "SITE")
    private String site;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "INVESTOR_TYPE")
    private Long investorType;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "UID")
    private String uid;
    @Column(name = "VENTURE_EXPERIENCE")
    private String ventureExperience;
    @Column(name = "IS_UNITY")
    private Boolean isUnity;
    @Column(name = "TELEGRAM_LINK")
    private String telegramLink;
    @Column(name = "SUM_INVESTMENT")
    private Long sumInvestment;
    @Column(name = "IS_IMOSCOW")
    private Boolean isIMoscow;
    @Column(name = "CONSENT")
    private Date consent;
    @Column(name = "IMOSCOWCONSENT")
    private Date iMoscowConsent;
    @Column(name = "SYNDICATECONSENT")
    private Date syndicateConsent;

    public Syndicate toDto(){
        Syndicate dto = new Syndicate();
        dto.setType(this.type);
        dto.setFirstName(this.firstName);
        dto.setLastName(this.lastName);
        dto.setPhone(this.phone);
        dto.setPosition(this.position);
        dto.setOrgFullName(this.orgFullName);
        dto.setSite(this.site);
        dto.setEmail(this.email);
        dto.setInvestorType(this.investorType);
        dto.setQuestionnaireId(this.questionnaireId);
        dto.setComment(this.comment);
        dto.setVentureExperience(this.ventureExperience);
        dto.setIsUnity(this.isUnity);
        dto.setTelegramLink(this.telegramLink);
        dto.setSumInvestment(this.sumInvestment);
        dto.setId(this.id);
        dto.setCreated(this.created);
        dto.setModified(this.modified);
        dto.setState(this.state);
        dto.setStateName(GuideService.getState(this.state));
        dto.setIsIMoscow(this.isIMoscow);
        return dto;
    }

}
