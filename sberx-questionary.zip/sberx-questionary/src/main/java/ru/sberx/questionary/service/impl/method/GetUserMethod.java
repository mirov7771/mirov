package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.questionary.questionary.req.PostUserQuestionnaireReq;
import ru.sberx.dto.questionary.questionary.questionary.res.GetUserListRes;
import ru.sberx.questionary.controller.dto.res.GetUserRes;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;
import ru.sberx.questionary.gate.service.UserAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class GetUserMethod {

    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final UserAuth userAuth;

    public List<GetUserRes> execute(Long id, Boolean getQuestionnaireUserIdOnly){
        List<GetUserRes> res = new ArrayList<>();
        List<UserQuestionnaire> user = userQuestionnaireRepository.findByQuestionnaireId(id);
        if (Boolean.TRUE.equals(getQuestionnaireUserIdOnly) && user != null && !user.isEmpty()) {
            return user.stream().map(i -> new GetUserRes(i.getUserId())).collect(Collectors.toList());
        }
        if (user != null && !user.isEmpty()){
            res = user.stream()
                    .map(i -> userAuth.getUserInfo(i.getUserId(), null))
                    .collect(Collectors.toList());
        }
        return res;
    }

    public GetUserListRes getUserList(Long externalId) {
        GetUserListRes res = new GetUserListRes();
        UserQuestionnaire questionnaire = userQuestionnaireRepository.findFirstByUserId(externalId);
        if (Objects.nonNull(questionnaire)) {
            res.setQuestionnaireId(questionnaire.getQuestionnaireId());
            List<UserQuestionnaire> user = userQuestionnaireRepository.findByQuestionnaireId(questionnaire.getQuestionnaireId());
            List<Long> externalIds = new ArrayList<>();
            user.forEach(q -> externalIds.add(q.getUserId()));
            res.setExternalId(externalIds);
            res.setUserCount(Integer.toUnsignedLong(externalIds.size()));
        }
        return res;
    }

    public void saveUserQuestionnaire(PostUserQuestionnaireReq req) {
        UserQuestionnaire questionnaire = userQuestionnaireRepository.findFirstByUserIdOrEmail(req.getUserId(),req.getLogin());
        if (Objects.nonNull(questionnaire)) throw new SberxException(SberxErrors.USER_EXISTS);
        UserQuestionnaire questionnaireForUser = userQuestionnaireRepository.findFirstByQuestionnaireId(req.getQuestionnaireId());
        if (Objects.isNull(questionnaireForUser)) throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        UserQuestionnaire newUserQuestionnaire = new UserQuestionnaire();
        newUserQuestionnaire.setUserId(req.getUserId());
        newUserQuestionnaire.setQuestionnaireId(req.getQuestionnaireId());
        newUserQuestionnaire.setEmail(req.getLogin());
        newUserQuestionnaire.setSberBusinessId("NO_SBB_ID");
        newUserQuestionnaire.setIsBran(questionnaireForUser.getIsBran());
        newUserQuestionnaire.setSberFh(questionnaireForUser.getSberFh());
        newUserQuestionnaire.setIsDisabled(questionnaireForUser.getIsDisabled());
        userQuestionnaireRepository.save(newUserQuestionnaire);
    }
}
