package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.custom.CustomRepository;
import ru.sberx.questionary.dao.model.Reply;

import javax.annotation.Nonnull;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ReplyRepository extends CrudRepository<Reply, Long>, CustomRepository {
    List<Reply> findByTableIdInAndTableNameAndUserIdOrderByReplyId(List<Long> tableIds, String tableName, Long userId);
    List<Reply> findByTableIdAndTableName(Long tableId, String tableName);
    List<Reply> findByTableName(String tableName);
    List<Reply> findByTableId(Long tableId);
    @Nonnull
    List<Reply> findAll();
    Reply findByReplyId(Long replyId);
    @Transactional
    @Modifying
    @Query(value = "delete from REPLY where tableid = :id and TABLENAME = 'Questionnaire'", nativeQuery = true)
    void deleteByTableId(@Param("id") Long id);
    List<Reply> findByUserId(Long userId);
}
