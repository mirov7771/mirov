package ru.sberx.questionary.controller.dto.res;

import java.util.List;
import lombok.Data;
import ru.sberx.questionary.controller.dto.support.ApplicationDto;

@Data
public class ApplicationListRes {
    private List<ApplicationDto> list;
    private Integer rowCount;
    private Integer totalRowCount;
    private Integer nextPageToken;
}
