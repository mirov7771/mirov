package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.sberx.questionary.dao.model.CommunityApplication;

import java.util.List;
import java.util.Optional;

public interface CommunityApplicationRepository extends CrudRepository<CommunityApplication, Long> {
    @Query(value = "select * from community_application where questionnaireid = :questionnaireId limit 1", nativeQuery = true)
    Optional<CommunityApplication> findByQuestionnaireId(@Param("questionnaireId") Long questionnaireId);
    List<CommunityApplication> findByState(Long state);
    List<CommunityApplication> findByQuestionnaireIdAndType(Long questionnaireId, Integer type);
}
