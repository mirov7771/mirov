package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.res.ViewCardRes;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;

import java.util.Optional;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class ViewCardMethod {
    private final QuestionnaireRepository questionnaireRepository;
    @Value("${application.action.url}")
    private String url;

    public ViewCardRes viewCard(Long reqId, UUID uuid, String sessionId) {
        Optional<Questionnaire> questionnaireOptional;
        if (reqId != null) {
            questionnaireOptional = questionnaireRepository.findById(reqId);
        } else if (uuid != null) {
            questionnaireOptional = Optional.ofNullable(questionnaireRepository.findByUuid(uuid));
        } else {
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "id || uuid");
        }
        ViewCardRes res = new ViewCardRes();
        if (questionnaireOptional.isEmpty())
            throw new SberxException(SberxErrors.WRONG_STATUS);
        Questionnaire questionnaire = questionnaireOptional.get();
        Long id = questionnaire.getQuestionnaireId();
        String uid = questionnaire.getUuid().toString();
        if (!questionnaire.getState().equals(20004L)) {
            throw new SberxException(SberxErrors.WRONG_STATUS);
        }
        if (sessionId == null) {
            if (StringUtils.hasText(uid)) {
                String uidUrl = url.replace("id={questionnaireid}", "uuid=" + uid);
                res.setAction(uidUrl.replace("{type}", questionnaire.getType().toString())
                        .replace("{name}", (questionnaire.getType().equals(0)
                                ? "startup"
                                : (questionnaire.getType().equals(1)
                                ? "corporate"
                                : "investor"))
                                + "_blur"));
            } else {
                res.setAction(url.replace("{type}", questionnaire.getType().toString())
                        .replace("{name}", (questionnaire.getType().equals(0)
                                ? "startup"
                                : (questionnaire.getType().equals(1)
                                ? "corporate"
                                : "investor"))
                                + "_blur")
                        .replace("{questionnaireid}", id.toString()));
            }
        } else {
            if (StringUtils.hasText(uid)) {
                String uidUrl = url.replace("id={questionnaireid}", "uuid=" + uid);
                res.setAction(uidUrl.replace("{type}", questionnaire.getType().toString())
                        .replace("&name={name}", ""));
            } else {
                res.setAction(url.replace("{type}", questionnaire.getType().toString())
                        .replace("{questionnaireid}", id.toString())
                        .replace("&name={name}", ""));
            }
        }
        return res;
    }
}
