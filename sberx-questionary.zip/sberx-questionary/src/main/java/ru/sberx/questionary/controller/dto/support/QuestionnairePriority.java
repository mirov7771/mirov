package ru.sberx.questionary.controller.dto.support;

import lombok.Data;

@Data
public class QuestionnairePriority {
    private Integer priority;
    private Long questionnaireId;
}
