package ru.sberx.questionary.service.comment;

import ru.sberx.questionary.controller.comment.dto.res.CommentGetRes;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;

public interface CommentService {
    CommentGetRes get(CommentDTO req);
    CommentDTO post(CommentDTO req);
    void put(CommentDTO req);
    void delete(Long id, Long userId);
}
