package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.InvestmentLocaleDao;
import ru.sberx.questionary.dao.model.pkey.QuestionnaireLangPKey;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface InvestmentLocaleDaoRepository extends CrudRepository<InvestmentLocaleDao, QuestionnaireLangPKey> {
    InvestmentLocaleDao findByQuestionnaireIdAndLang(Long questionnaireId, String lang);

    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    List<InvestmentLocaleDao> findByQuestionnaireId(Long questionnaireId);

    List<InvestmentLocaleDao> findByQuestionnaireIdInAndLang(List<Long> questionnaireId, String lang);

    @Modifying
    @Transactional
    void deleteByQuestionnaireIdAndLangIn(Long questionnaireId, List<String> lang);

    @Modifying
    @Transactional
    @Query("update InvestmentLocaleDao set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
}
