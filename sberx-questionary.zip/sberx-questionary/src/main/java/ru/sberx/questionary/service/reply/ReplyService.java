package ru.sberx.questionary.service.reply;

import ru.sberx.questionary.controller.reply.dto.req.ReplyListReq;
import ru.sberx.questionary.controller.reply.dto.res.ReplyListRes;
import ru.sberx.questionary.controller.reply.dto.support.ReplyInfoDTO;

public interface ReplyService {

    ReplyListRes list(ReplyListReq req);
    ReplyInfoDTO post(ReplyInfoDTO req);
    ReplyInfoDTO put(ReplyInfoDTO req);
    ReplyInfoDTO get(Long id, Integer type);

}
