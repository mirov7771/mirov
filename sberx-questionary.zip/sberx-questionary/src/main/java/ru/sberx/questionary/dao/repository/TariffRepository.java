package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Tariff;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface TariffRepository extends CrudRepository<Tariff, Long> {

    List<Tariff> findByQuestionnaireIdAndState(Long questionnaireId, String state);

    List<Tariff> findByQuestionnaireUuidAndState(String questionnaireUuid, String active);

    List<Tariff> findByQuestionnaireId(Long questionnaireId);

    List<Tariff> findByQuestionnaireIdAndStateAndSysName(Long questionnaireId, String state, String sysName);

    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);
}
