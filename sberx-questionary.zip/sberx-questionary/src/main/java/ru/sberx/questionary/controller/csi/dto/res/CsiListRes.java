package ru.sberx.questionary.controller.csi.dto.res;

import lombok.Data;
import ru.sberx.questionary.controller.csi.dto.support.CsiDto;

import java.util.List;

@Data
public class CsiListRes {
    private List<CsiDto> values;
}
