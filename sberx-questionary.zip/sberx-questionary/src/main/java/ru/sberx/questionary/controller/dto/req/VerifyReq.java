package ru.sberx.questionary.controller.dto.req;

import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
public class VerifyReq {
    @NotNull
    private String tableId;
    @NotNull
    private String tableName;
    private Long userId;
    @NotNull
    private Long state;
    private String comment;
    private String sessionId;
    private String email;
    private Boolean changeRoleCheck;
    private Integer newType;
    private Integer newInvestorType;
    private String newTariff;
}
