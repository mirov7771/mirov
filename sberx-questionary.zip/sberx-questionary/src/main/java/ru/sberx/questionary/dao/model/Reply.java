package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.controller.reply.dto.support.ReplyInfoDTO;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Entity
@Table(name = "REPLY")
@Getter
@Setter
@NoArgsConstructor
public class Reply implements Serializable {

    private static final long serialVersionUID = 5169442507704211835L;

    @Id
    @Column(name = "REPLYID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long replyId;
    @Column(name = "TABLEID")
    private Long tableId;
    @Column(name = "TABLENAME")
    private String tableName;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "NOTE")
    private String note;
    @Column(name = "FILEURL")
    private String fileUrl;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "DATE")
    private Date date;
    @OneToMany(mappedBy = "replyId", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<QuestionLink> questionLinkList;
    @Column(name = "COST")
    private String cost;
    @Column(name = "PROCESS")
    private String process;
    @Column(name = "ISVIEWED")
    private Boolean isViewed;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "ISPILOTOFFER")
    private Boolean isPilotOffer;
    @Column(name = "OFFERNAME")
    private String offerName;
    @Column(name = "OFFERDESCRIPTION")
    private String offerDescription;

    public Reply(ReplyInfoDTO req){
        if (req.getTableId() == null)
            this.tableId = req.getPilotId();
        else {
            this.tableId = Long.valueOf(req.getTableId());
        }
        this.tableName = req.getTableName();
        this.userId = req.getUserId();
        this.note = req.getNote();
        if (StringUtils.hasText(req.getFileURLString()))
            this.fileUrl = req.getFileURLString();
        else
            this.fileUrl = req.getFileUrl();
        this.state = req.getState();
        this.date = new Date();
        this.cost = req.getCost();
        this.process = req.getProcess();
        this.isViewed = false;
        this.comment = req.getComment();
        this.modified = new Date();
        if (Boolean.TRUE.equals(req.getIsPilotOffer())){
            this.isPilotOffer = req.getIsPilotOffer();
            this.offerName = req.getOfferName();
            this.offerDescription = req.getOfferDescription();
        } else {
            this.isPilotOffer = false;
        }
    }

    public void patch(ReplyInfoDTO req) {
        this.userId = nvl(req.getUserId(), this.userId);
        this.note = nvl(req.getNote(), this.note);
        if (StringUtils.hasText(req.getFileURLString()))
            this.fileUrl = nvl(req.getFileURLString(), this.fileUrl);
        else
            this.fileUrl = nvl(req.getFileUrl(), this.fileUrl);
        this.state = nvl(req.getState(), this.state);
        this.cost = nvl(req.getCost(), this.cost);
        this.process = nvl(req.getProcess(), this.process);
        this.comment = nvl(req.getComment(), this.comment);
        this.modified = new Date();
    }

}
