package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class Founder {
    private Long founderId;
    private Long questionnaireId;
    private String fio;

    public Founder(ru.sberx.questionary.dao.model.Founder f) {
        this.founderId = f.getFounderId();
        this.questionnaireId = f.getQuestionnaireId();
        this.fio = f.getFio();
    }
}
