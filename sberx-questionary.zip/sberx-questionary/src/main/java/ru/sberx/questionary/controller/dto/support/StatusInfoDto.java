package ru.sberx.questionary.controller.dto.support;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class StatusInfoDto {
    private Long fromState;
    private Long toState;
    private String fromStateName;
    private String toStateName;
    @JsonFormat(timezone = "GMT+3")
    private Date date;
    private Long userId;
    private String comment;
    private String userLogin;
    private Boolean child;
    private String uid;
}
