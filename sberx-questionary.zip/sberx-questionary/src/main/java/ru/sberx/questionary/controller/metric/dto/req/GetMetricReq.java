package ru.sberx.questionary.controller.metric.dto.req;

import lombok.Data;

@Data
public class GetMetricReq {

    private String beginDate;
    private String endDate;
    private Long metricType;
    private String uuid;
    private Long userId;
}
