package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class GetUserRes {

    public GetUserRes(Long userId) {
        this.userId = userId;
    }

    private Long userId;
    private String login;
    private Boolean enters;
    private Long externalId;
}
