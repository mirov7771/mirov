package ru.sberx.questionary.controller.comment.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CommentDTO {
    private Long commentId;
    private String comment;
    @JsonFormat(timezone = "GMT+3")
    private Date date;
    private Boolean edited;
    private Long tableId;
    private String tableName;
    private String role;
    private Long userId;
    private String login;
}
