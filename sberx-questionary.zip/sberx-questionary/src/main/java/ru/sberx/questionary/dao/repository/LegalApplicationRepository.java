package ru.sberx.questionary.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.LegalApplication;

@Repository
public interface LegalApplicationRepository extends CrudRepository<LegalApplication, Long> {
}
