package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.req.OffersReq;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;

@Component
@RequiredArgsConstructor
public class UpdateQuestionnaireOfferMethod {

    private final QuestionnaireRepository questionnaireRepository;

    public void execute(String questionnaireId, OffersReq req, String role) {
        long id;
        if (StringUtils.hasText(role) && "CorpLight".equalsIgnoreCase(role) && Boolean.TRUE.equals(req.getEnableOffers()))
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_FOR_ROLE);
        try {
            id = Long.parseLong(questionnaireId);
        } catch (Exception e) {
            throw new SberxException(SberxErrors.BAD_REQUEST, e.getMessage());
        }
        Questionnaire questionnaire = questionnaireRepository.findByQuestionnaireIdAndType(id, 1);
        if (questionnaire == null) {
            throw new SberxException(SberxErrors.OBJECT_NOT_FOUND);
        }
        questionnaire.setEnableOffers(req.getEnableOffers());
        questionnaireRepository.save(questionnaire);
    }
}
