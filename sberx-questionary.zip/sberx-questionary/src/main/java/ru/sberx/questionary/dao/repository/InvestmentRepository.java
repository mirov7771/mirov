package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.Investment;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface InvestmentRepository extends CrudRepository<Investment, String> {

    @Query(value = "select * from Investment where questionnaireId = :questionnaireId limit 1", nativeQuery = true)
    Investment findByQuestionnaireId(@Param("questionnaireId") Long questionnaireId);
    List<Investment> findByQuestionnaireIdIn(List<Long> questionnaireId);
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update Investment set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    List<Investment> findAllByQuestionnaireIdInAndPlanInvestmentTrue(List<Long> idList);

}
