package ru.sberx.questionary.dao.repository;

import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.StatusInfo;

@Repository
public interface StatusInfoRepository extends CrudRepository<StatusInfo, Long> {
    List<StatusInfo> findAllByObjectIdInAndToState(List<Long> idList, Long toState);
    @Query("from StatusInfo where objectId = :id and upper(objectType)  = upper(:type)")
    List<StatusInfo> findAllByObjectIdAndObjectType(Long id, String type, Sort sort);
    @Query("from StatusInfo where (objectId = :id or parentId = :id) and upper(objectType) = upper(:type)")
    List<StatusInfo> findAllByObjectIdOrParentIdAndObjectType(Long id, String type, Sort sort);
    @Query("from StatusInfo where objectId = :id and upper(objectType)  = upper(:type) and toState = :toState")
    List<StatusInfo> findAllByObjectIdAndObjectTypeAndToState(Long id, String type, Long toState);
}
