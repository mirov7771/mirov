package ru.sberx.questionary.service.tariff.impl;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.res.DefaultRes;
import ru.sberx.questionary.controller.tariff.dto.req.CheckTariffReq;
import ru.sberx.questionary.controller.tariff.dto.req.PostTariffReq;
import ru.sberx.questionary.controller.tariff.dto.support.TariffDto;
import ru.sberx.questionary.controller.tariff.dto.support.TariffTypeDto;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.Tariff;
import ru.sberx.questionary.dao.model.TariffSettings;
import ru.sberx.questionary.dao.model.UserQuestionnaire;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.TariffRepository;
import ru.sberx.questionary.dao.repository.TariffSettingsRepository;
import ru.sberx.questionary.dao.repository.UserQuestionnaireRepository;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.gate.service.UserAuth;
import ru.sberx.questionary.service.tariff.TariffService;
import ru.sberx.questionary.util.GuideService;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ru.sberx.questionary.util.TariffStatus.*;

@Service
@RequiredArgsConstructor
public class TariffServiceImpl implements TariffService {

    private final TariffRepository tariffRepository;
    private final TariffSettingsRepository tariffSettingsRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final MidService midService;
    private final UserAuth userAuth;

    @Override
    public void check(CheckTariffReq req) {
        List<TariffSettings> settings;
        if (req.getInvestorType() == null)
            settings = tariffSettingsRepository.findBySysNameAndType(req.getSysname(), req.getType());
        else
            settings = tariffSettingsRepository.findBySysNameAndTypeAndSubTypeContains(req.getSysname(), req.getType(), req.getInvestorType());
        if (CollectionUtils.isEmpty(settings))
            throw new SberxException(SberxErrors.ERROR_TARIFF_SELECTION);
    }

    @Override
    public TariffDto get(Long userId, String role, Long questionnaireId, String questionnaireUuid, Boolean back) {
        List<Tariff> tariffs;
        if (questionnaireId == null && !StringUtils.hasText(questionnaireUuid)) {
            Questionnaire questionnaire = questionnaireRepository.findAllByUserId(userId);
            if (questionnaire == null)
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            tariffs = tariffRepository.findByQuestionnaireIdAndState(questionnaire.getQuestionnaireId(), ACTIVE.getValue());
        } else {
            checkAdmin(role);
            tariffs = questionnaireId != null
                    ? tariffRepository.findByQuestionnaireIdAndState(questionnaireId, ACTIVE.getValue())
                    : tariffRepository.findByQuestionnaireUuidAndState(questionnaireUuid, ACTIVE.getValue());
            if (CollectionUtils.isEmpty(tariffs) && Boolean.TRUE.equals(back))
                tariffs = questionnaireId != null
                        ? tariffRepository.findByQuestionnaireIdAndState(questionnaireId, INITIAL.getValue())
                        : tariffRepository.findByQuestionnaireUuidAndState(questionnaireUuid, INITIAL.getValue());
        }
        if (CollectionUtils.isEmpty(tariffs)) {
            if (Boolean.TRUE.equals(back))
                return null;
            throw new SberxException(SberxErrors.MISSING_TARIFF);
        } else if (tariffs.size() > 1) {
            if (Boolean.TRUE.equals(back))
                return null;
            throw new SberxException(SberxErrors.FOUND_SEVERAL_TARIFF);
        }
        TariffSettings settings = tariffSettingsRepository.findFirstBySysName(tariffs.get(0).getSysName());
        return settings != null ? new TariffDto(settings.getSysName(), settings.getName(), settings.getMaxUsers()) : null;
    }

    @Override
    public DefaultRes post(PostTariffReq req) {
        Questionnaire questionnaire = null;
        DefaultRes res = new DefaultRes();
        res.setMessage("Заявка на смену тарифа отправлена");
        if (req.getId() == null && req.getQuestionnaireId() == null
                && !StringUtils.hasText(req.getSysname()) && !StringUtils.hasText(req.getQuestionnaireUuid()))
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        if (StringUtils.hasText(req.getSysname()) &&
                req.getQuestionnaireId() == null && req.getId() == null && !StringUtils.hasText(req.getQuestionnaireUuid())) {
            questionnaire = questionnaireRepository.findAllByUserId(req.getUserId());
            TariffSettings setting = tariffSettingsRepository.findFirstBySysName(req.getSysname());
            validateTariff(questionnaire, setting);

            List<Tariff> tariffs = tariffRepository.findByQuestionnaireId(questionnaire.getQuestionnaireId());
            if (CollectionUtils.isEmpty(tariffs)) {
                tariffRepository.save(new Tariff(
                        questionnaire.getQuestionnaireId(),
                        questionnaire.getUuid().toString(),
                        req.getSysname(),
                        !StringUtils.hasText(req.getRole()) ? ACTIVE.getValue() : INITIAL.getValue(),
                        new Date(),
                        null,
                        req.getUserId(),
                        null,
                        null
                ));
                return res;
            }
            if (tariffs.stream().anyMatch(tariff -> INITIAL.getValue().equals(tariff.getState()) || DRAFT.getValue().equals(tariff.getState())))
                throw new SberxException(SberxErrors.ERROR_CHANGE_TARIFF_EXIST);

            Optional<Tariff> tariffOptional = tariffs.stream().filter(tariff -> ACTIVE.getValue().equals(tariff.getState())).findFirst();
            tariffRepository.save(new Tariff(
                    questionnaire.getQuestionnaireId(),
                    questionnaire.getUuid().toString(),
                    req.getSysname(),
                    DRAFT.getValue(),
                    new Date(),
                    null,
                    req.getUserId(),
                    null,
                    tariffOptional.map(Tariff::getId).orElse(null)
            ));
            Map<String, Object> params = new HashMap<>();
            params.put("theme", String.format("%s Запрос смены тарифа", questionnaire.getName()));
            params.put("text", String.format("Стартап %s запрашивает смену тарифа на %s", questionnaire.getName(), setting.getName()));
            midService.notify("blank", params, "sberunity@sberbank.ru", null, null, null, null, null);
        } else if (req.getId() != null) {
            checkAdmin(req.getRole());
            Tariff currentTariff = tariffRepository.findById(req.getId())
                    .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
            if (!DRAFT.getValue().equals(currentTariff.getState()))
                throw new SberxException(SberxErrors.ERROR_CHANGE_TARIFF_STATUS);

            Tariff oldTariff = tariffRepository.findById(currentTariff.getParentId())
                    .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
            oldTariff.setState(ARCHIVE.getValue());
            tariffRepository.save(oldTariff);

            currentTariff.setState(ACTIVE.getValue());
            currentTariff.setValidatedUserId(req.getUserId());
            tariffRepository.save(currentTariff);

            changeRole(currentTariff);
        } else if (!StringUtils.hasText(req.getSysname()) && (req.getQuestionnaireId() != null || StringUtils.hasText(req.getQuestionnaireUuid()))) {
            checkAdmin(req.getRole());
            List<Tariff> tariffs = req.getQuestionnaireId() != null
                    ? tariffRepository.findByQuestionnaireIdAndState(req.getQuestionnaireId(), INITIAL.getValue())
                    : tariffRepository.findByQuestionnaireUuidAndState(req.getQuestionnaireUuid(), INITIAL.getValue());
            if (CollectionUtils.isEmpty(tariffs))
                return res;
            Tariff currentTariff = tariffs.get(0);
            currentTariff.setValidatedUserId(req.getUserId());
            currentTariff.setState(ACTIVE.getValue());
            tariffRepository.save(currentTariff);
            changeRole(currentTariff);
            res.setIsChangedRole(true);
        } else if (StringUtils.hasText(req.getSysname()) && (req.getQuestionnaireId() != null || StringUtils.hasText(req.getQuestionnaireUuid()))) {
            checkAdmin(req.getRole());
            questionnaire = req.getQuestionnaireId() != null
                    ? questionnaireRepository.findByQuestionnaireId(req.getQuestionnaireId())
                    : questionnaireRepository.findByUuid(UUID.fromString(req.getQuestionnaireUuid()));
            TariffSettings setting = tariffSettingsRepository.findFirstBySysName(req.getSysname());
            validateTariff(questionnaire, setting);

            List<Tariff> tariffs = tariffRepository.findByQuestionnaireId(questionnaire.getQuestionnaireId());

            if (tariffs.stream().allMatch(tariff -> INITIAL.getValue().equals(tariff.getState()))
                    || (CollectionUtils.isEmpty(tariffs)
                    && (GuideService.PROCESSING_STATE.equals(questionnaire.getState())
                    || GuideService.IN_PROGRESS_STATE.equals(questionnaire.getState())
                    || GuideService.TO_EDIT.equals(questionnaire.getState()))
                    && questionnaire.getParentId() == null)) {
                // при первичной проверке анкеты (в состоянии 20002("на проверу"), 20012("в работе") или 20003("на доработку")
                // с тарифом со статусом initial, или без тарифа) админ меняет тариф перед согласованием анкеты
                Tariff newTariff = CollectionUtils.isEmpty(tariffs) ? new Tariff() : tariffs.get(0);
                newTariff.setSysName(req.getSysname());
                newTariff.setCreateDttm(new Date());
                newTariff.setState(INITIAL.getValue());
                newTariff.setRequestedUserId(req.getUserId());
                newTariff.setValidatedUserId(req.getUserId());
                newTariff.setQuestionnaireId(questionnaire.getQuestionnaireId());
                newTariff.setQuestionnaireUuid(questionnaire.getUuid().toString());
                tariffRepository.save(newTariff);
                res.setMessage("Администратор изменил тариф");
                return res;
            }
            Optional<Tariff> tariffOptional = tariffs.stream().filter(tariff -> ACTIVE.getValue().equals(tariff.getState())).findFirst();
            Long parentId = null;
            if (tariffOptional.isPresent()) {
                Tariff oldTariff = tariffOptional.get();
                parentId = oldTariff.getId();
                oldTariff.setState(ARCHIVE.getValue());
                tariffRepository.save(oldTariff);
            }
            String stateTariff = GuideService.TO_EDIT.equals(questionnaire.getState()) ? INITIAL.getValue() : ACTIVE.getValue();
            Tariff currentTariff = new Tariff(
                    questionnaire.getQuestionnaireId(),
                    questionnaire.getUuid().toString(),
                    req.getSysname(),
                    stateTariff,
                    new Date(),
                    null,
                    req.getUserId(),
                    req.getUserId(),
                    parentId
            );
            tariffRepository.save(currentTariff);
            if (questionnaire.getParentId() == null && !GuideService.TO_EDIT.equals(questionnaire.getState()))
                changeRole(currentTariff);
            createTariffChildQuestionnaire(questionnaire.getQuestionnaireId());
            res.setIsChangedRole(true);
        }
        if (questionnaire != null && questionnaire.getQuestionnaireId() != null && questionnaire.getType().equals(1)) {
            if (CollectionUtils.isEmpty(
                    tariffRepository.findByQuestionnaireIdAndStateAndSysName(questionnaire.getQuestionnaireId(), ACTIVE.getValue(), "CorpLight"))
            ) {
                questionnaire.setEnableOffers(false);
                questionnaireRepository.save(questionnaire);
            }
        }
        return res;
    }

    @Override
    public List<TariffTypeDto> list(Long questionnaireId, String questionnaireUuid) {
        Map<Integer, Map<Integer, List<SettingDto>>> resMap = new HashMap<>();
        Set<String> activeTariff = new HashSet<>();
        List<TariffSettings> settings = new ArrayList<>();
        if (questionnaireId == null && !StringUtils.hasText(questionnaireUuid)) {
            settings = tariffSettingsRepository.findAll();
        } else {
            List<Tariff> tariffs;
            Questionnaire questionnaire;
            if (questionnaireId != null) {
                tariffs = tariffRepository.findByQuestionnaireIdAndState(questionnaireId, ACTIVE.getValue());
                questionnaire = questionnaireRepository.findByQuestionnaireId(questionnaireId);
            } else {
                tariffs = tariffRepository.findByQuestionnaireUuidAndState(questionnaireUuid, ACTIVE.getValue());
                questionnaire = questionnaireRepository.findByUuid(UUID.fromString(questionnaireUuid));
            }
            activeTariff.addAll(tariffs.stream().map(Tariff::getSysName).collect(Collectors.toSet()));
            if (questionnaire != null) {
                if (questionnaire.getInvestorType() == null)
                    settings = tariffSettingsRepository.findByType(questionnaire.getType());
                else
                    settings = tariffSettingsRepository.findByTypeAndSubType(questionnaire.getType(), questionnaire.getInvestorType().intValue());
            }
        }
        if (!CollectionUtils.isEmpty(settings)) {
            settings.stream()
                    .filter(tariff -> !"SuperClient".equalsIgnoreCase(tariff.getSysName()))
                    .flatMap(s -> {
                        if (s.getSubType() != null && s.getSubType().length > 0)
                            return Arrays.stream(s.getSubType()).map(t -> new SettingDto(s, t, null));
                        return Stream.of(new SettingDto(s, null, null));
                    }).forEach(s -> {
                        Map<Integer, List<SettingDto>> subTypeMap = resMap.get(s.getType());
                        if (subTypeMap == null)
                            subTypeMap = new HashMap<>();
                        List<SettingDto> settingDtos = subTypeMap.get(s.getSubType());
                        if (settingDtos == null)
                            settingDtos = new ArrayList<>();
                        settingDtos.add(s);
                        subTypeMap.put(s.getSubType(), settingDtos);
                        resMap.put(s.getType(), subTypeMap);
                    });
        } else {
            return new ArrayList<>();
        }
        return resMap.entrySet().stream()
                .map(entry -> {
                    TariffTypeDto t = new TariffTypeDto();
                    t.setType(entry.getKey());
                    List<TariffTypeDto.SubTypeTariff> subTypeTariffs = new ArrayList<>();
                    entry.getValue().forEach((subType, settingDtoList) -> {
                        List<TariffTypeDto.SubTypeTariff.InfoTariff> infoTariffs = settingDtoList.stream()
                                .map(s -> new TariffTypeDto.SubTypeTariff.InfoTariff(s.getSysname(), s.getName(), activeTariff.contains(s.getSysname())))
                                .collect(Collectors.toList());
                        subTypeTariffs.add(new TariffTypeDto.SubTypeTariff(subType, infoTariffs));
                    });
                    t.setSubTypes(subTypeTariffs);
                    return t;
                }).collect(Collectors.toList());
    }

    @Override
    public String tariffName(String sysName) {
        TariffSettings settings = tariffSettingsRepository.findFirstBySysName(sysName);
        if (settings != null)
            return settings.getName();
        return null;
    }

    @Override
    public void createTariffChildQuestionnaire(Long questionnaireId) {
        Questionnaire childQuestionnaire = questionnaireRepository.findByParentId(questionnaireId);
        if (childQuestionnaire != null) {
            List<Tariff> parentTariff = tariffRepository.findByQuestionnaireIdAndState(questionnaireId, ACTIVE.getValue());
            if (!CollectionUtils.isEmpty(parentTariff)) {
                Tariff activeTariff = parentTariff.get(0);
                tariffRepository.save(
                        Tariff.builder()
                                .sysName(activeTariff.getSysName())
                                .state(activeTariff.getState())
                                .questionnaireId(childQuestionnaire.getQuestionnaireId())
                                .questionnaireUuid(childQuestionnaire.getUuid().toString())
                                .createDttm(activeTariff.getCreateDttm())
                                .build()
                );
            }
        }
    }

    @Override
    public void deleteByQuestionnaireId(Long questionnaireId) {
        tariffRepository.deleteByQuestionnaireId(questionnaireId);
    }

    private void validateTariff(Questionnaire questionnaire, TariffSettings setting) {
        if (setting == null)
            throw new SberxException(SberxErrors.TARIFF_NOT_EXISTS);
        List<Integer> tariffSubTypes = new ArrayList<>();
        if (setting.getSubType() != null && setting.getSubType().length > 0)
            tariffSubTypes = Arrays.asList(setting.getSubType());
        if (questionnaire == null || !setting.getType().equals(questionnaire.getType())
                || (questionnaire.getInvestorType() != null && !tariffSubTypes.contains(questionnaire.getInvestorType().intValue())))
            throw new SberxException(SberxErrors.ERROR_TARIFF_SELECTION);
    }

    private void checkAdmin(String role) {
        if (!"Administrator".equals(role) && !"SberbankEmployee".equals(role))
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
    }

    private void changeRole(Tariff tariff) {
        List<UserQuestionnaire> userQuestionnaires = userQuestionnaireRepository.findByQuestionnaireId(tariff.getQuestionnaireId());
        if (!CollectionUtils.isEmpty(userQuestionnaires)) {
            Questionnaire questionnaire = questionnaireRepository.findByQuestionnaireId(tariff.getQuestionnaireId());
            userQuestionnaires.forEach(uq -> userAuth.changeRole(uq.getUserId(), tariff.getSysName(), questionnaire.getType()));
        }
    }

    @Data
    public static class SettingDto {
        private Integer type;
        private Integer subType;
        private String sysname;
        private String name;
        private Boolean active;

        public SettingDto(TariffSettings settings, Integer subType, Boolean active) {
            this.type = settings.getType();
            this.sysname = settings.getSysName();
            this.name = settings.getName();
            this.subType = subType;
            this.active = active;
        }
    }
}
