package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.questionary.controller.comment.dto.support.CommentDTO;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "TABLE_COMMENT")
@Getter
@Setter
@NoArgsConstructor
public class TableComment implements Serializable {

    private static final long serialVersionUID = 5044244877832158099L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "TABLE_ID")
    private Long tableId;
    @Column(name = "TABLE_NAME")
    private String tableName;
    @Column(name = "BODY")
    private String body;
    @Column(name = "DATE")
    private Date date;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "ROLE")
    private String role;
    @Column(name = "EDITED")
    private Boolean edited;
    @Column(name = "LOGIN")
    private String login;

    public TableComment(CommentDTO req) {
        this.tableId = req.getTableId();
        this.tableName = req.getTableName();
        this.body = req.getComment();
        this.date = new Date();
        this.userId = req.getUserId();
        this.role = req.getRole();
        this.edited = false;
        this.login = req.getLogin();
    }
}
