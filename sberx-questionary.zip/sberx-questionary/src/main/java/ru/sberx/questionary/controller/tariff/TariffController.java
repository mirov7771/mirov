package ru.sberx.questionary.controller.tariff;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.questionary.builder.ResponseBuilder;
import ru.sberx.questionary.controller.tariff.dto.req.CheckTariffReq;
import ru.sberx.questionary.controller.tariff.dto.req.PostTariffReq;
import ru.sberx.questionary.service.tariff.TariffService;

import javax.validation.Valid;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("${spring.application.name}/tariff")
@RequiredArgsConstructor
public class TariffController {

    private final TariffService service;

    @PostMapping(value = "check", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> check(@RequestHeader(value = "role") String role,
                                   @RequestHeader(value = "user-id") Long userId,
                                   @Valid @RequestBody CheckTariffReq req) {
        req.setRole(role);
        req.setUserId(userId);
        service.check(req);
        return ResponseEntity.ok().body(null);
    }

    @GetMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> get(@RequestHeader(value = "role") String role,
                                 @RequestHeader(value = "user-id") Long userId,
                                 @RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                 @RequestParam(value = "questionnaireUuid", required = false) String questionnaireUuid,
                                 @RequestParam(value = "back", required = false) Boolean back) {

        return ResponseBuilder.build(service.get(userId, role, questionnaireId, questionnaireUuid, back));
    }

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> post(@RequestHeader(value = "role", required = false) String role,
                                  @RequestHeader(value = "user-id") Long userId,
                                  @RequestBody PostTariffReq req) {
        req.setRole(role);
        req.setUserId(userId);
        return ResponseBuilder.build(service.post(req));
    }

    @GetMapping(value = "list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> list(@RequestParam(value = "questionnaireId", required = false) Long questionnaireId,
                                  @RequestParam(value = "questionnaireUuid", required = false) String questionnaireUuid) {
        return ResponseBuilder.build(service.list(questionnaireId, questionnaireUuid));
    }
}
