package ru.sberx.questionary.service.impl.method;

import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import ru.sberx.questionary.controller.dto.req.StatusHistoryReq;
import ru.sberx.questionary.controller.dto.res.StatusInfoListRes;
import ru.sberx.questionary.controller.dto.support.StatusInfoDto;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.StatusInfo;
import ru.sberx.questionary.dao.model.StatusInfo_;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;
import ru.sberx.questionary.dao.repository.StatusInfoRepository;
import ru.sberx.questionary.gate.service.UserAuth;

@Component
@Slf4j
@RequiredArgsConstructor
public class StatusHistoryMethod {

    private final StatusInfoRepository statusInfoRepository;
    private final QuestionnaireRepository questionnaireRepository;
    private final UserAuth userAuth;

    public StatusInfoListRes getStatusHistory(StatusHistoryReq req) {
        StatusInfoListRes res = new StatusInfoListRes();
        Sort sortByDate;
        if ("EARLIER".equalsIgnoreCase(req.getDirection())) {
            sortByDate = Sort.by(Sort.Direction.ASC, StatusInfo_.DATE);
        } else {
            sortByDate = Sort.by(Sort.Direction.DESC, StatusInfo_.DATE);
        }

        List<StatusInfo> statusInfoList;
        if (Boolean.TRUE.equals(req.getChild())) {
            Questionnaire questionnaire = questionnaireRepository.findByQuestionnaireId(req.getQuestionnaireId());
            if (questionnaire == null) {
                return res;
            }
            Long questionnaireId = questionnaire.getParentId() == null ? questionnaire.getQuestionnaireId() : questionnaire.getParentId();
            statusInfoList = statusInfoRepository.findAllByObjectIdOrParentIdAndObjectType(questionnaireId, getTypeName(req.getType()), sortByDate);
        } else {
            statusInfoList = statusInfoRepository.findAllByObjectIdAndObjectType(req.getQuestionnaireId(), getTypeName(req.getType()), sortByDate);
        }
        List<StatusInfoDto> dtoList = statusInfoList
                .stream()
                .map(StatusInfo::toDto)
                .peek(dto -> {
                    if (dto.getUserId() != null)
                        dto.setUserLogin(userAuth.getUserInfo(null, dto.getUserId()).getLogin());
                })
                .collect(Collectors.toList());

        res.setItems(dtoList);
        return res;
    }

    private String getTypeName(Integer type){
        if (type.equals(0) || type.equals(1) || type.equals(2)){
            return "Questionnaire";
        } else if (type.equals(4)) {
            return "Pilot";
        } else if (type.equals(9)) {
            return "Application";
        } else if (type.equals(10)) {
            return "Round";
        } else if (type.equals(11)) {
            return "Community_application";
        } else if (type.equals(12)) {
            return "Syndicate_application";
        }
        return "";
    }
}
