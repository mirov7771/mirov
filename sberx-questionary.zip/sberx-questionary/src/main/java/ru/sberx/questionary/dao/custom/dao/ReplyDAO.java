package ru.sberx.questionary.dao.custom.dao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter @Setter
public class ReplyDAO {
    private String email;
    private String qName;
    private Long questionnaireId;
}
