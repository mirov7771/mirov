package ru.sberx.questionary.service.csi;

import ru.sberx.questionary.controller.csi.dto.req.PostCsiReq;
import ru.sberx.questionary.controller.csi.dto.res.CsiListRes;

public interface CsiService {
    CsiListRes list();
    void post(PostCsiReq req);
}
