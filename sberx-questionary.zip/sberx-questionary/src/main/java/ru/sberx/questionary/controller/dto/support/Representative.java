package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Representative {

    private Long representativeId;
    @NotNull
    private String fio;
    private String phone;
    private String email;
    private String role;
    private Boolean isDisabled;
    private Long parentId;
    private String facebook;
    private String lastName;
    private String firstName;
    private String position;

}
