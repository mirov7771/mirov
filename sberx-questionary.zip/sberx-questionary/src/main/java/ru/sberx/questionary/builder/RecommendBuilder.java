package ru.sberx.questionary.builder;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.questionary.dao.custom.dao.QuestionnaireDAO;
import ru.sberx.questionary.dao.custom.dao.RecommendDAO;
import ru.sberx.questionary.dao.model.RecommendCoefficient;
import ru.sberx.questionary.dao.model.RecommendLink;
import ru.sberx.questionary.dao.repository.RecommendCoefficientRepository;
import ru.sberx.questionary.dao.repository.RecommendLinkRepository;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
@Slf4j
public class RecommendBuilder {

    private final RecommendLinkRepository recommendLinkRepository;
    private final RecommendCoefficientRepository recommendCoefficientRepository;
    private static final List<RecommendCoefficient> COEFFICIENTS = new ArrayList<>();

    @PostConstruct
    public void getCoefficients(){
        if (CollectionUtils.isEmpty(COEFFICIENTS))
            COEFFICIENTS.addAll(recommendCoefficientRepository.findAll());
    }

    public void build(Long id) {
        if (CollectionUtils.isEmpty(COEFFICIENTS))
            COEFFICIENTS.addAll(recommendCoefficientRepository.findAll());

        if (CollectionUtils.isEmpty(COEFFICIENTS))
            return;

        List<RecommendLink> links = recommendLinkRepository.findByQuestionnaireId(id);
        if (CollectionUtils.isEmpty(links) || links.stream().anyMatch(i -> i.getCacheTime().before(new Date()))){
            //1. Находим основную анкету
            List<QuestionnaireDAO> mainDao = recommendLinkRepository.findByQId(id);

            if (links.stream().anyMatch(i -> i.getCacheTime().before(new Date())))
                recommendLinkRepository.deleteByQuestionnaireId(id);

            log.info("mainDao {}", mainDao);
            if (CollectionUtils.isEmpty(mainDao))
                return;

            List<RecommendCoefficient> coefficients = COEFFICIENTS.stream().filter(i -> (mainDao.get(0).getType().equals(1) && i.getCoefType().contains("_1"))
                    || (mainDao.get(0).getType().equals(2) && i.getCoefType().contains("_2"))).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(coefficients))
                return;
            Map<String, Float> coeffMap = coefficients.stream()
                    .collect(Collectors.toMap(RecommendCoefficient::getRealCoefType, RecommendCoefficient::getCoefValue));

            //2. Находим избранные анкеты
            List<QuestionnaireDAO> favorites = recommendLinkRepository.findFavoritesById(id);
            log.info("favorites {}", favorites);

            //3. Считаем веса
            int favSz = !CollectionUtils.isEmpty(favorites) ? favorites.size() : 0;
            Map<Long, FieldValue> valueMap = new HashMap<>();
            long indSz = mainDao.stream().filter(i -> i.getIndustry() != null).count();
            long rndSz = mainDao.stream().filter(i -> i.getRound() != null).count();
            long tchSz = mainDao.stream().filter(i -> i.getTechnology() != null).count();
            long geoSz = mainDao.stream().filter(i -> i.getGeography() != null).count();
            for(QuestionnaireDAO q : mainDao){
                if (q.getIndustry() != null)
                    valueMap.put(q.getIndustry(), new FieldValue(nvl(coeffMap.get("industry"), 0F), favSz, indSz));
                if (q.getRound() != null)
                    valueMap.put(q.getRound(), new FieldValue(nvl(coeffMap.get("round"), 0F), favSz, rndSz));
                if (q.getTechnology() != null)
                    valueMap.put(q.getTechnology(), new FieldValue(nvl(coeffMap.get("technology"), 0F), favSz, tchSz));
                if (q.getGeography() != null)
                    valueMap.put(q.getGeography(), new FieldValue(nvl(coeffMap.get("geography"), 0F), favSz, geoSz));
            }

            if (favSz > 0){
                for(QuestionnaireDAO f : favorites){
                    if (valueMap.get(f.getIndustry()) != null){
                        valueMap.get(f.getIndustry()).setFavValueSz(favorites.stream().filter(i -> i.getIndustry() != null && i.getIndustry().equals(f.getIndustry())).count());
                    }
                    if (valueMap.get(f.getRound()) != null){
                        valueMap.get(f.getRound()).setFavValueSz(favorites.stream().filter(i -> i.getRound() != null && i.getRound().equals(f.getRound())).count());
                    }
                    if (valueMap.get(f.getTechnology()) != null){
                        valueMap.get(f.getTechnology()).setFavValueSz(favorites.stream().filter(i -> i.getTechnology() != null && i.getTechnology().equals(f.getTechnology())).count());
                    }
                    if (valueMap.get(f.getGeography()) != null){
                        valueMap.get(f.getGeography()).setFavValueSz(favorites.stream().filter(i -> i.getGeography() != null && i.getGeography().equals(f.getGeography())).count());
                    }

                    if (f.getIndustry() != null && valueMap.get(f.getIndustry()) == null){
                        valueMap.put(f.getIndustry(), new FieldValue(0F, favSz, indSz));
                    }
                    if (f.getRound() != null && valueMap.get(f.getRound()) == null){
                        valueMap.put(f.getRound(), new FieldValue(0F, favSz, rndSz));
                    }
                    if (f.getTechnology() != null && valueMap.get(f.getTechnology()) == null){
                        valueMap.put(f.getTechnology(), new FieldValue(0F, favSz, tchSz));
                    }
                    if (f.getGeography() != null && valueMap.get(f.getGeography()) == null){
                        valueMap.put(f.getGeography(), new FieldValue(0F, favSz, geoSz));
                    }
                }
            }

            if (valueMap.isEmpty())
                return;

            for(Map.Entry<Long, FieldValue> entry : valueMap.entrySet()){
                float i = entry.getValue().getFavSz() > 0 ? ((float) entry.getValue().getFavValueSz()) / ((float) entry.getValue().getFavSz()) : 1;
                float v = nvl(entry.getValue().getCoefValue(), 0F) + i;
                entry.getValue().setValue(v/entry.getValue().getSz());
            }

            log.info("valueMap {}", valueMap);
            //4. Находим все стартапы
            List<QuestionnaireDAO> all = recommendLinkRepository.findAllQ();
            if (CollectionUtils.isEmpty(all))
                return;

            all = all.stream().filter(i -> !CollectionUtils.isEmpty(i.getIndustryLst())
                            || !CollectionUtils.isEmpty(i.getGeographyLst())
                            || !CollectionUtils.isEmpty(i.getRoundLst())
                            || !CollectionUtils.isEmpty(i.getTechnologyLst()))
                    .collect(Collectors.toList());
            all.forEach(i -> setValue(i, valueMap));
            all = all.stream().filter(i ->
                    !Float.valueOf(i.getGeographyValue()).equals(0F)
                            || !Float.valueOf(i.getRoundValue()).equals(0F)
                            || !Float.valueOf(i.getIndustryValue()).equals(0F)
                            || !Float.valueOf(i.getTechnologyValue()).equals(0F))
                    .collect(Collectors.toList());
            //5. Фильтруем стартапы с учетом весов
            all.forEach(i -> i.setFinalValue(i.getGeographyValue() + i.getRoundValue() + i.getIndustryValue() + i.getTechnologyValue()));
            all.sort(Comparator.comparing(QuestionnaireDAO::getFinalValue).reversed());
            all = all.stream().limit(100).collect(Collectors.toList());
            log.info("all {}", all);

            //6. Сохраняем стартапы в таблицу recommend_link
            if (!CollectionUtils.isEmpty(all)) {
                recommendLinkRepository.saveAll(all.stream().map(i -> new RecommendLink(id, i.getQuestionnaireId(), nvl(i.getRecommendDate(), new Date()))).collect(Collectors.toList()));
            }
        }
    }

    public List<RecommendDAO> get(Long id, Long userId){
        return recommendLinkRepository.findRecommendForNotify(userId, id);
    }

    private void setValue(QuestionnaireDAO i, Map<Long, FieldValue> valueMap){
        i.setIndustryValue(getValue(i.getIndustryLst(), valueMap));
        i.setRoundValue(getValue(i.getRoundLst(), valueMap));
        i.setTechnologyValue(getValue(i.getTechnologyLst(), valueMap));
        i.setGeographyValue(getValue(i.getGeographyLst(), valueMap));
    }

    private float getValue(List<Long> list, Map<Long, FieldValue> valueMap){
        float f = 0;
        if (!CollectionUtils.isEmpty(list)){
            for(Long l : list){
                if (valueMap.get(l) != null)
                    f += valueMap.get(l).getValue();
            }
        }
        return f;
    }

    @Data
    private static class FieldValue {
        private Float coefValue;
        private long favValueSz;
        private int favSz;
        private long sz;
        private float value;

        public FieldValue(Float coefValue, int favSz, long sz) {
            this.coefValue = coefValue;
            this.favSz = favSz;
            this.sz = sz;
        }
    }

}
