package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "REPRESENTATIVE")
@Data
public class Representative  implements Serializable {

    private static final long serialVersionUID = -4319512991336206974L;

    @Id
    @Column(name = "REPRESENTATIVEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long representativeId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "FIO")
    private String fio;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "ROLE")
    private String role;
    @Column(name = "ISDISABLED")
    private Boolean isDisabled;
    @Column(name = "PARENTID")
    private Long parentId;
    @Column(name = "FACEBOOK")
    private String facebook;
    @Column(name = "LAST_NAME")
    private String lastName;
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Column(name = "POSITION")
    private String position;

}
