package ru.sberx.questionary.builder;

import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;
import ru.sberx.questionary.controller.dto.req.QuestionnaireReq;
import ru.sberx.questionary.controller.dto.support.ImportReplaceDTO;
import ru.sberx.questionary.dao.model.*;

import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.questionary.util.GuideService.*;
import static ru.sberx.utils.validator.ConditionValidator.*;

@Getter
@Setter
public class DaoBuilder {

    private Questionnaire questionnaire;
    private Project project;
    private Investment investment;
    private List<Worker> workers;
    private List<Pilot> pilots;
    private List<Representative> representatives;
    private List<Contact> contacts;
    private Long id;
    private SberFiveHundred sberFiveHundred;
    private ImportReplaceDAO importReplaceDAO;
    private QuestionnaireLocaleDao questionnaireLocaleDao;
    private ProjectLocaleDao projectLocaleDao;
    private InvestmentLocaleDao investmentLocaleDao;
    private ImportReplaceLangDao importReplaceLangDao;

    public void mainBuild(QuestionnaireReq req) {
        ru.sberx.questionary.controller.dto.support.Questionnaire reqQuestionnaire = req.getQuestionnaire();
        if (reqQuestionnaire != null) {
            questionnaire.setMainLanguage(nvl(questionnaire.getMainLanguage(), req.getLang()));
            if (questionnaire.getLanguages() != null && questionnaire.getLanguages().length > 0) {
                Set<String> languages = new HashSet<>(Arrays.asList(questionnaire.getLanguages()));
                languages.add(req.getLang());
                questionnaire.setLanguages(languages.toArray(new String[0]));
            } else {
                questionnaire.setLanguages(new String[] {req.getLang()});
            }
            questionnaire.setClub(nvlBoolean(reqQuestionnaire.getClub(), questionnaire.getClub()));
            questionnaire.setCreated(nvl(questionnaire.getCreated(), new Date()));
            questionnaire.setIndustry(nvl(reqQuestionnaire.getIndustry(), questionnaire.getIndustry()));
            questionnaire.setIsBran(nvlBoolean(reqQuestionnaire.getIsBran(), questionnaire.getIsBran()));
            questionnaire.setInnovationMethod(nvl(reqQuestionnaire.getInnovationMethod(), questionnaire.getInnovationMethod()));
            questionnaire.setIsDisabled(nvlBoolean(reqQuestionnaire.getIsDisabled(), questionnaire.getIsDisabled()));
            questionnaire.setLegalRegistered(nvlBoolean(reqQuestionnaire.getLegalRegistered(), questionnaire.getLegalRegistered()));
            questionnaire.setLocation(nvl(reqQuestionnaire.getLocation(), questionnaire.getLocation()));
            questionnaire.setMailNews(nvlBoolean(reqQuestionnaire.getMailNews(), questionnaire.getMailNews()));
            questionnaire.setMentoring(nvlBoolean(reqQuestionnaire.getMentoring(), questionnaire.getMentoring()));
            questionnaire.setModified(new Date());
            questionnaire.setRepresentative(nvlBoolean(reqQuestionnaire.getRepresentative(), questionnaire.getRepresentative()));
            questionnaire.setRound(nvl(reqQuestionnaire.getRound(), questionnaire.getRound()));
            if ((questionnaire.getState() != null && !questionnaire.getState().equals(DRAFT_STATE))){
                if (req.getAction().equals(0))
                    questionnaire.setState(SHORT_STATE);
                else
                    questionnaire.setState((TO_EDIT.equals(questionnaire.getState()) || IN_PROGRESS_STATE.equals(questionnaire.getState())) ? PROCESSING_STATE : questionnaire.getState());
            } else {
                if (req.getAction().equals(0))
                    questionnaire.setState(SHORT_STATE);
                else if (req.getAction().equals(1))
                    questionnaire.setState(DRAFT_STATE);
                else
                    questionnaire.setState(PROCESSING_STATE);
            }
            questionnaire.setStady(nvl(reqQuestionnaire.getStady(), questionnaire.getStady()));
            questionnaire.setTurnOver(nvl(reqQuestionnaire.getTurnover(), questionnaire.getTurnOver()));
            questionnaire.setType(nvl(nvl(reqQuestionnaire.getType(), questionnaire.getType()), 0));
            questionnaire.setTags(nvl(reqQuestionnaire.getTags(), questionnaire.getTags()));
            questionnaire.setOwner(nvl(reqQuestionnaire.getOwner(), questionnaire.getOwner()));
            questionnaire.setInviteUnit(nvl(reqQuestionnaire.getInviteUnit(), questionnaire.getInviteUnit()));
            questionnaire.setInviteUser(nvl(reqQuestionnaire.getInviteUser(), questionnaire.getInviteUser()));
            questionnaire.setComment(nvl(reqQuestionnaire.getComment(), questionnaire.getComment()));
            questionnaire.setParentId(nvl(reqQuestionnaire.getParentId(), questionnaire.getParentId()));
            questionnaire.setInvestorType(nvl(reqQuestionnaire.getInvestorType(), questionnaire.getInvestorType()));
            questionnaire.setSuccessfullCase(nvl(reqQuestionnaire.getSuccessfullCase(), questionnaire.getSuccessfullCase()));
            questionnaire.setScouting(nvl(reqQuestionnaire.getScouting(), questionnaire.getScouting()));
            questionnaire.setStartupInvestmentYears(nvl(reqQuestionnaire.getStartupInvestmentYears(), questionnaire.getStartupInvestmentYears()));
            questionnaire.setOverallContracts(nvl(reqQuestionnaire.getOverallContracts(), questionnaire.getOverallContracts()));
            questionnaire.setOverallPilots(nvl(reqQuestionnaire.getOverallPilots(), questionnaire.getOverallPilots()));
            questionnaire.setLastYearInvestmentsCount(nvl(reqQuestionnaire.getLastYearInvestmentsCount(), questionnaire.getLastYearInvestmentsCount()));
            questionnaire.setCommunityState(nvl(reqQuestionnaire.getCommunityState(), questionnaire.getCommunityState()));
            questionnaire.setAllDealsNumber(nvl(reqQuestionnaire.getAllDealsNumber(), questionnaire.getAllDealsNumber()));
            questionnaire.setExitDealsNumber(nvl(reqQuestionnaire.getExitDealsNumber(), questionnaire.getExitDealsNumber()));
            questionnaire.setActiveDealsNumber(nvl(reqQuestionnaire.getActiveDealsNumber(), questionnaire.getActiveDealsNumber()));
            questionnaire.setAccelerator(nvlBoolean(reqQuestionnaire.getAccelerator(), questionnaire.getAccelerator()));
            if (reqQuestionnaire.getBirthYear() != null){
                Calendar cal = Calendar.getInstance();
                cal.set(reqQuestionnaire.getBirthYear(), Calendar.FEBRUARY, 1, 0, 0);
                questionnaire.setBirthDay(cal.getTime());
            }
            questionnaire.setLocationCountry(nvl(reqQuestionnaire.getLocationCountry(), questionnaire.getLocationCountry()));
            questionnaire.setCommunity(nvlBoolean(reqQuestionnaire.getCommunity(), questionnaire.getCommunity()));
            questionnaire.setSuccessPilots(nvlBoolean(reqQuestionnaire.getSuccessPilots(), questionnaire.getSuccessPilots()));
            questionnaire.setPilot(nvlBoolean(reqQuestionnaire.getPilot(), questionnaire.getPilot()));
            questionnaire.setSuccessPilotsB2C(nvlBoolean(reqQuestionnaire.getSuccessPilotsB2C(), questionnaire.getSuccessPilotsB2C()));
            questionnaire.setPortfolioNote(nvl(reqQuestionnaire.getPortfolioNote(), questionnaire.getPortfolioNote()));
            questionnaire.setBusinessModel(nvl(reqQuestionnaire.getBusinessModel(), questionnaire.getBusinessModel()));
            questionnaire.setForLending(nvlBoolean(reqQuestionnaire.getForLending(), questionnaire.getForLending()));
            questionnaire.setTranscription(nvl(reqQuestionnaire.getTranscription(), questionnaire.getTranscription()));
            questionnaire.setAcceleratorCode(nvl(reqQuestionnaire.getAcceleratorCode(), questionnaire.getAcceleratorCode()));
            questionnaire.setPriority(nvl(reqQuestionnaire.getPriority(), questionnaire.getPriority()));
            questionnaire.setTechnology(nvl(reqQuestionnaire.getTechnology(), questionnaire.getTechnology()));
            questionnaire.setAcceleratorSite(nvl(reqQuestionnaire.getAcceleratorSite(), questionnaire.getAcceleratorSite()));
            questionnaire.setSendInvestNotify(false);
            questionnaire.setSendInvestPlanNotify(false);
            questionnaire.setSber500(nvlBoolean(reqQuestionnaire.getSber500(), questionnaire.getSber500()));
            questionnaire.setUuid(nvl(questionnaire.getUuid(), UUID.randomUUID()));
            questionnaire.setResponsible(nvl(questionnaire.getResponsible(), questionnaire.getResponsible()));
            questionnaire.setResponsibleLogin(nvl(reqQuestionnaire.getResponsibleLogin(), questionnaire.getResponsibleLogin()));
            if (questionnaire.getType().equals(CORPORATE))
                questionnaire.setEnableOffers(true);
            questionnaire.setIsMarketing((req.getUserConsent() != null && Boolean.TRUE.equals(req.getUserConsent().getMailingConsent())) ? "ДА" : "НЕТ");
            questionnaire.setIsImport(nvlBoolean(reqQuestionnaire.getIsImport(), questionnaire.getIsImport()));
            questionnaire.setLastEnter(new Date());
        }
    }

    public void build(QuestionnaireReq req) {
        ru.sberx.questionary.controller.dto.support.Questionnaire reqQuestionnaire = req.getQuestionnaire();
        if (reqQuestionnaire != null) {
            questionnaireLocaleDao.setQuestionnaireId(id);
            questionnaireLocaleDao.setUuid(questionnaire.getUuid());
            questionnaireLocaleDao.setLang(req.getLang());
            questionnaireLocaleDao.setEmail(nvl(reqQuestionnaire.getEmail(), questionnaireLocaleDao.getEmail()));
            if (questionnaireLocaleDao.getEmail() != null)
                questionnaireLocaleDao.setEmail(questionnaireLocaleDao.getEmail().replaceAll(" ", ""));
            questionnaireLocaleDao.setInn(nvl(reqQuestionnaire.getInn(), questionnaireLocaleDao.getInn()));
            questionnaireLocaleDao.setFullName(nvl(reqQuestionnaire.getFullName(), questionnaireLocaleDao.getFullName()));
            questionnaireLocaleDao.setBirthDay(nvl(reqQuestionnaire.getBirthDay(), questionnaireLocaleDao.getBirthDay()));
            questionnaireLocaleDao.setName(nvl(reqQuestionnaire.getName(), questionnaireLocaleDao.getName()));
            questionnaireLocaleDao.setRegistrationCountry(nvl(reqQuestionnaire.getRegistrationCountry(), questionnaireLocaleDao.getRegistrationCountry()));
            questionnaireLocaleDao.setSite(nvl(reqQuestionnaire.getSite(), questionnaireLocaleDao.getSite()));
            questionnaireLocaleDao.setPhoneNumber(nvl(reqQuestionnaire.getPhoneNumber(), questionnaireLocaleDao.getPhoneNumber()));
            questionnaireLocaleDao.setInviteFio(nvl(reqQuestionnaire.getInviteFio(), questionnaireLocaleDao.getInviteFio()));
            questionnaireLocaleDao.setLogoFile(nvl(reqQuestionnaire.getLogoFile(), questionnaireLocaleDao.getLogoFile()));
            questionnaireLocaleDao.setAcceleratorString(reqQuestionnaire.getAcceleratorString());
            questionnaireLocaleDao.setFullNote(nvl(reqQuestionnaire.getFullNote(), questionnaireLocaleDao.getFullNote()));
            questionnaireLocaleDao.setNote(nvl(reqQuestionnaire.getNote(), questionnaireLocaleDao.getNote()));
        }
        ru.sberx.questionary.controller.dto.support.Investment reqInvestment = req.getInvestment();
        if (reqInvestment != null){
            investment.setInvestment(nvlBoolean(reqInvestment.getInvestment(), investment.getInvestment()));
            investment.setExperience(nvl(reqInvestment.getExperience(), investment.getExperience()));
            investment.setIndustry(nvl(reqInvestment.getIndustry(), investment.getIndustry()));
            investment.setGeography(nvl(reqInvestment.getGeography(), investment.getGeography()));
            investment.setNote(nvl(reqInvestment.getNote(), investment.getNote()));
            investment.setRound(nvl(reqInvestment.getRound(), investment.getRound()));
            investment.setIsDisabled(nvlBoolean(reqInvestment.getIsDisabled(), investment.getIsDisabled()));
            investment.setSumInvestment(nvl(reqInvestment.getSumInvestment(), investment.getSumInvestment()));
            investment.setTurnover(nvl(reqInvestment.getTurnover(), investment.getTurnover()));
            investment.setQuestionnaireId(id);
            investment.setParentId(nvl(reqInvestment.getParentId(), investment.getParentId()));
            investment.setTechnology(nvl(reqInvestment.getTechnology(), investment.getTechnology()));
            investment.setPlanInvestment(nvlBoolean(reqInvestment.getPlanInvestment(), investment.getPlanInvestment()));

            investmentLocaleDao.setQuestionnaireId(id);
            investmentLocaleDao.setLang(req.getLang());
            investmentLocaleDao.setBusinessPlan(nvl(reqInvestment.getBusinessPlan(), investmentLocaleDao.getBusinessPlan()));
            investmentLocaleDao.setInvestment(nvlBoolean(reqInvestment.getInvestment(), investmentLocaleDao.getInvestment()));
            investmentLocaleDao.setLastInvestment(reqInvestment.getLastInvestment());
            investmentLocaleDao.setCoInvestment(reqInvestment.getCoInvestment());
        }

        ru.sberx.questionary.controller.dto.support.Project reqProject = req.getProject();
        if (reqProject != null){
            project.setBusinessModel(nvl(reqProject.getBusinessModel(), project.getBusinessModel()));
            project.setIndustry(nvl(reqProject.getIndustry(), project.getIndustry()));
            project.setName(nvl(reqProject.getName(), project.getName()));
            project.setDemoFile(nvl(reqProject.getDemoFile(), project.getDemoFile()));
            project.setDownSide(nvl(reqProject.getDownSide(), project.getDownSide()));
            project.setExperience(nvl(reqProject.getExperience(), project.getExperience()));
            project.setDemoSite(nvl(reqProject.getDemoSite(), project.getDemoSite()));
            project.setGeography(nvl(reqProject.getGeography(), project.getGeography()));
            project.setHaveMVP(nvlBoolean(reqProject.getHaveMVP(), project.getHaveMVP()));
            project.setHiringStaff(nvl(reqProject.getHiringStaff(), project.getHiringStaff()));
            project.setInteractionType(nvl(reqProject.getInteractionType(), project.getInteractionType()));
            project.setIsDisabled(nvlBoolean(reqProject.getIsDisabled(), project.getIsDisabled()));
            project.setSales(nvl(reqProject.getSales(), project.getSales()));
            project.setStady(nvl(reqProject.getStady(), project.getStady()));
            project.setStaff(nvl(reqProject.getStaff(), project.getStaff()));
            project.setQuestionnaireId(id);
            project.setParentId(nvl(reqProject.getParentId(), project.getParentId()));
            project.setStaffLocation(nvl(reqProject.getStaffLocation(), project.getStaffLocation()));
            project.setExpansion(nvl(reqProject.getExpansion(), project.getExpansion()));
            project.setIndirectCompetitor(nvl(reqProject.getIndirectCompetitor(), project.getIndirectCompetitor()));
            project.setPitchVideo(nvl(reqProject.getPitchVideo(), project.getPitchVideo()));
            project.setAddNote(nvl(reqProject.getAddNote(), project.getAddNote()));
            project.setMvpCode(nvl(reqProject.getMvpCode(), project.getMvpCode()));
            project.setTechnology(nvl(reqProject.getTechnology(), project.getTechnology()));

            projectLocaleDao.setLang(req.getLang());
            projectLocaleDao.setNote(nvl(reqProject.getNote(), projectLocaleDao.getNote()));
            projectLocaleDao.setDemoVideo(nvl(reqProject.getDemoVideo(), projectLocaleDao.getDemoVideo()));
            projectLocaleDao.setProblem(nvl(reqProject.getProblem(), projectLocaleDao.getProblem()));
            projectLocaleDao.setAuditory(nvl(reqProject.getAuditory(), projectLocaleDao.getAuditory()));
            projectLocaleDao.setCompetitor(nvl(reqProject.getCompetitor(), projectLocaleDao.getCompetitor()));
            projectLocaleDao.setUpSide(nvl(reqProject.getUpSide(), projectLocaleDao.getUpSide()));
        }

        ru.sberx.questionary.controller.dto.support.SberFiveHundredDto reqSberFiveHundredDto = req.getSberFiveHundred();
        if (reqSberFiveHundredDto != null){
            sberFiveHundred.setQuestionnaireId(nvl(reqSberFiveHundredDto.getQuestionnaireId(), sberFiveHundred.getQuestionnaireId()));
            sberFiveHundred.setFirstTime(nvlBoolean(reqSberFiveHundredDto.getFirstTime(), sberFiveHundred.getFirstTime()));
            sberFiveHundred.setMotivation(nvl(reqSberFiveHundredDto.getMotivation(), sberFiveHundred.getMotivation()));
            sberFiveHundred.setMonthRevenue(nvl(reqSberFiveHundredDto.getMonthRevenue(), sberFiveHundred.getMonthRevenue()));
            sberFiveHundred.setQuarterRevenue(nvl(reqSberFiveHundredDto.getQuarterRevenue(), sberFiveHundred.getQuarterRevenue()));
            sberFiveHundred.setClients(nvl(reqSberFiveHundredDto.getClients(), sberFiveHundred.getClients()));
            sberFiveHundred.setEcoRequirement(nvl(reqSberFiveHundredDto.getEcoRequirement(), sberFiveHundred.getEcoRequirement()));
        }

        if (req.getImportReplace() != null){
            importReplaceDAO.setQuestionnaireId(nvl(req.getImportReplace().getQuestionnaireId(), importReplaceDAO.getQuestionnaireId()));
            importReplaceDAO.setBenefits(nvl(req.getImportReplace().getBenefits(), importReplaceDAO.getBenefits()));
            importReplaceDAO.setNote(nvl(req.getImportReplace().getNote(), importReplaceDAO.getNote()));
            if (!CollectionUtils.isEmpty(req.getImportItems())){
                importReplaceDAO.setName(req.getImportItems().stream().map(ImportReplaceDTO.ImportReplaceItemsDTO::getName).toArray(String[]::new));
            } else if (!CollectionUtils.isEmpty(req.getImportReplace().getName())){
                importReplaceDAO.setName(req.getImportReplace().getName().toArray(String[]::new));
            } else {
                importReplaceDAO.setName(importReplaceDAO.getName());
            }
            importReplaceLangDao.setQuestionnaireId(id);
            importReplaceLangDao.setLang(req.getLang());
            importReplaceLangDao.setNote(nvl(req.getImportReplace().getNote(), importReplaceLangDao.getNote()));
            importReplaceLangDao.setBenefits(nvl(req.getImportReplace().getBenefits(), importReplaceLangDao.getBenefits()));
        }

        List<ru.sberx.questionary.controller.dto.support.Worker> reqWorkers = req.getWorkers();
        if (!isEmptyList(reqWorkers)){
            workers = reqWorkers.stream().map(item -> {
                Worker w = new Worker();
                w.setQuestionnaireId(id);
                w.setIsDisabled(nvl(item.getIsDisabled(), false));
                w.setFio(nvl(item.getFio(), "-"));
                w.setNote(item.getNote());
                w.setRole(item.getRole());
                w.setAge(item.getAge());
                w.setPercentage(item.getPercentage());
                w.setParentId(item.getParentId());
                w.setFacebook(item.getFacebook());
                w.setIsFounder(item.getIsFounder());
                w.setLang(req.getLang());
                return w;
            }).collect(Collectors.toList());
        }

        List<ru.sberx.questionary.controller.dto.support.Representative> reqRepresentatives = req.getRepresentatives();
        if (!isEmptyList(reqRepresentatives)){
            representatives = reqRepresentatives.stream().map(item -> {
                Representative r = new Representative();
                r.setQuestionnaireId(id);
                r.setIsDisabled(nvl(item.getIsDisabled(), false));
                r.setEmail(item.getEmail());
                r.setFio(item.getFio());
                r.setPhone(item.getPhone());
                r.setRole(item.getRole());
                r.setParentId(item.getParentId());
                r.setFacebook(item.getFacebook());
                r.setLastName(item.getLastName());
                r.setFirstName(item.getFirstName());
                r.setPosition(item.getPosition());
                if (r.getFio() == null
                        && r.getLastName() != null
                        && r.getFirstName() != null){
                    r.setFio(r.getFirstName() + " " + r.getLastName());
                }
                return r;
            }).collect(Collectors.toList());
        }

        List<ru.sberx.questionary.controller.dto.support.Contact> reqContacts = req.getContacts();
        if (!isEmptyList(reqContacts)){
            contacts = reqContacts.stream().map(item -> {
                Contact c = new Contact();
                c.setQuestionnaireId(id);
                c.setName(item.getName());
                c.setType(item.getType());
                c.setValue(item.getValue());
                c.setIsDisabled(nvl(item.getIsDisabled(), false));
                c.setParentId(item.getParentId());
                c.setLang(req.getLang());
                return c;
            }).collect(Collectors.toList());
        }
    }

    public boolean isSber500(){
        return this.sberFiveHundred != null && (
                this.sberFiveHundred.getFirstTime() != null
                        || this.sberFiveHundred.getClients() != null
                        || this.sberFiveHundred.getMotivation() != null
                        || this.sberFiveHundred.getMonthRevenue() != null
                        || this.sberFiveHundred.getQuarterRevenue() != null
                        || this.sberFiveHundred.getEcoRequirement() != null
                );
    }

}
