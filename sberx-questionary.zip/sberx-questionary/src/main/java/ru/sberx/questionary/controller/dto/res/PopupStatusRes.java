package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@NoArgsConstructor
public class PopupStatusRes {
    private String status;
    private String title;
    private String subtitle;
    private String description;
    private String img;
    private List<ButtonDto> buttons;
    private String viewAction;
    private String clickAction;
    private String clickMethod;
    private String badge;
    private List<Option> options;
    private String mobImageUrl;
    private String imageUrl;
    private String confirmButtonName;
    private String cancelButtonName;
    private String unsubscribe;
    private String body;
    private String linkLabel;

    public PopupStatusRes(String status) {
        this.status = status;
    }

    @JsonInclude(Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    @NoArgsConstructor
    public static class Option {
        private String code;
        private String text;
        private List<ButtonDto> buttons;

        public Option(String code,
                      String text,
                      List<ButtonDto> buttons) {
            this.code = code;
            this.text = text;
            this.buttons = buttons;
        }
    }

    @JsonInclude(Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    @NoArgsConstructor
    public static class ButtonDto {
        private String type;
        private String text;
        private String linkTo;
        private String description;
        private String clickAction;
        private String code;

        public ButtonDto(String type, String text) {
            this.type = type;
            this.text = text;
        }

        public ButtonDto(String type, String text, String linkTo) {
            this.type = type;
            this.text = text;
            this.linkTo = linkTo;
        }

        public ButtonDto(String type, String text, String clickAction, String linkTo) {
            this.type = type;
            this.text = text;
            this.clickAction = clickAction;
            this.linkTo = linkTo;
        }

        public ButtonDto(Integer code, String description) {
            this.code = code.toString();
            this.text = code.toString();
            this.description = description;
        }
    }
}
