package ru.sberx.questionary.service.impl.method;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.dto.support.QuestionnairePriority;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.repository.QuestionnaireRepository;

@Component
@RequiredArgsConstructor
public class UpdateQuestionnairePriority {

    private final QuestionnaireRepository questionnaireRepository;

    public QuestionnairePriority execute(QuestionnairePriority req) {
        Questionnaire questionnaire = questionnaireRepository.findById(req.getQuestionnaireId())
                .orElseThrow(() -> new SberxException(SberxErrors.OBJECT_NOT_FOUND));
        if (questionnaireRepository.findByPriority(req.getPriority()).isPresent()) {
            questionnaireRepository.updatePriorities(req.getPriority());
        }
        questionnaire.setPriority(req.getPriority());
        questionnaireRepository.save(questionnaire);
        QuestionnairePriority res = new QuestionnairePriority();
        res.setQuestionnaireId(questionnaire.getQuestionnaireId());
        res.setPriority(questionnaire.getPriority());
        return res;
    }
}
