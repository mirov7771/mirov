package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "QUESTION_LINK")
@Getter
@Setter
public class QuestionLink implements Serializable {

    private static final long serialVersionUID = -837550372378338275L;

    @Id
    @Column(name = "QUESTIONID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long questionId;
    @Column(name = "REPLYID")
    private Long replyId;
    @Column(name = "RESPONSEID")
    private Long responseId;
    @Column(name = "RESPONSENOTE")
    private String responseNote;
    @Column(name = "QUESTION")
    private String question;

}
