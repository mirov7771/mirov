package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.ProjectLocaleDao;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.pkey.ProjectLangPKey;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ProjectLocaleDaoRepository extends CrudRepository<ProjectLocaleDao, ProjectLangPKey> {
    ProjectLocaleDao findByProjectIdAndLang(Long projectId, String lang);
    List<ProjectLocaleDao> findByProjectIdInAndLang(List<Long> projectId, String lang);

    @Modifying
    @Transactional
    void deleteByProjectId(Long projectId);

    List<ProjectLocaleDao> findByProjectIdIn(List<Long> ids);

    @Modifying
    @Transactional
    @Query("update ProjectLocaleDao set projectId = :newProjectId where projectId in (select p.projectId from Project p where p.questionnaireId = :questionnaireId)")
    void updateProjectId(Long questionnaireId, Long newProjectId);

    @Query("select pld from ProjectLocaleDao pld join Project p on pld.projectId = p.projectId where p.questionnaireId = :questionnaireId")
    List<ProjectLocaleDao> findByQuestionnaireId(Long questionnaireId);
    @Query(value = "select pl.* from project_local pl join project p on pl.projectid = p.projectid where p.questionnaireid = :questionnaireId and pl.lang = :lang limit 1", nativeQuery = true)
    ProjectLocaleDao findByQuestionnaireIdAndLang(Long questionnaireId, String lang);

    @Modifying
    @Transactional
    @Query(value = "delete from project_local pl where pl.projectid in (select p.projectid from project p where p.questionnaireId = :questionnaireId) and pl.lang in :lang", nativeQuery = true)
    void deleteByQuestionnaireIdAndLang(Long questionnaireId, List<String> lang);

    @Modifying
    @Transactional
    @Query(value = "delete from project_local pl where pl.projectid in (select p.projectid from project p where p.questionnaireId = :questionnaireId)", nativeQuery = true)
    void deleteByQuestionnaireId(Long questionnaireId);
}
