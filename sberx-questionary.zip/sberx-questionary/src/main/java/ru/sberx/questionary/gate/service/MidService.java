package ru.sberx.questionary.gate.service;

import ru.sberx.questionary.gate.dto.Notice;

import java.util.List;
import java.util.Map;

public interface MidService {
    void notify(String sysName, Map<String, Object> params, String receiver, Long userId, String event, String deeplink, Long toUserId, Integer type);
    void notify(String sysName, Map<String, Object> params, String receiver);
    Notice notice(Notice req);
}
