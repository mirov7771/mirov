package ru.sberx.questionary.dao.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "INVESTMENTCLUB")
@Data
public class InvestmentClub implements Serializable {

    private static final long serialVersionUID = 1583040596838052075L;

    @Id
    @Column(name = "INVESTMENTCLUBID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long investmentClubId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "ROLE")
    private String role;

}
