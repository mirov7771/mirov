package ru.sberx.questionary.dao.custom.dao;

import lombok.*;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@NoArgsConstructor
@Getter @Setter
@ToString
public class QuestionnaireDAO {
    private Long questionnaireId;
    private Long round;
    private Long industry;
    private Long technology;
    private Long geography;
    private List<Long> roundLst;
    private List<Long> industryLst;
    private List<Long> technologyLst;
    private List<Long> geographyLst;
    private float roundValue;
    private float industryValue;
    private float technologyValue;
    private float geographyValue;
    private float finalValue;
    private Integer type;
    private Date recommendDate;
    private Long userId;

    public QuestionnaireDAO(Long questionnaireId, Long userId) {
        this.questionnaireId = questionnaireId;
        this.userId = userId;
    }

    public QuestionnaireDAO(Long questionnaireId, Long round, Long industry, Long technology, Long geography, Integer type, Date recommendDate) {
        this.questionnaireId = questionnaireId;
        if (round != null) {
            if (round.equals(6001L))
                this.round = 27003L;
            else if (round.equals(6002L) || round.equals(6006L))
                this.round = 27004L;
            else if (round.equals(6003L))
                this.round = 27005L;
            else if (round.equals(6004L) || round.equals(6005L))
                this.round = 27006L;
        }
        this.industry = industry;
        this.technology = technology;
        this.geography = geography;
        this.type = type;
        this.recommendDate = recommendDate;
    }

    public QuestionnaireDAO(Long questionnaireId, String roundStr, String industryStr, String technologyStr, String geographyStr) {
        this.questionnaireId = questionnaireId;
        this.roundLst = getList(roundStr);
        this.industryLst = getList(industryStr);
        this.technologyLst = getList(technologyStr);
        this.geographyLst = getList(geographyStr);
    }

    private List<Long> getList(String value){
        if (StringUtils.hasText(value)) {
            value = value.replace("{", "").replace("}", "");
            if (StringUtils.hasText(value) && !value.equals("")){
                String[] split = value.split(",");
                if (split.length > 0) {
                    List<Long> ret = new ArrayList<>();
                    for(String s : split){
                        ret.add(Long.valueOf(s));
                    }
                    if (!CollectionUtils.isEmpty(ret))
                        return ret;
                }
            }
        }
        return null;
    }
}
