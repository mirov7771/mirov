package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.ImportReplaceDAO;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ImportReplaceDAORepository extends CrudRepository<ImportReplaceDAO, Long> {
    ImportReplaceDAO findByQuestionnaireId(Long questionnaireId);
    List<ImportReplaceDAO> findByQuestionnaireIdIn(List<Long> questionnaireIds);

    @Query(value = "delete from IMPORT_REPLACE where QUESTIONNAIRE_ID = :questionnaireId", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update ImportReplaceDAO set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);
}
