package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Project {

    @NotNull
    private String name;
    private String note;
    private Long[] industry;
    private long[] interactionType;
    private long[] businessModel;
    private String problem;
    private String auditory;
    private Boolean haveMVP;
    private long[] geography;
    private long[] sales;
    private String demoSite;
    private String demoFile;
    private String competitor;
    private String upSide;
    private String downSide;
    private Integer staff;
    private Integer hiringStaff;
    private String experience;
    private Long stady;
    private Boolean isDisabled;
    private Long parentId;
    private String staffLocation;
    private long[] expansion;
    private String indirectCompetitor;
    private String demoVideo;
    private String pitchVideo;
    private String addNote;
    private long[] mvpCode;
    private Long[] technology;
    private Long projectId;

}
