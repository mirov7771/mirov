package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.sberx.questionary.dao.model.RoundFavorite;

import javax.transaction.Transactional;

public interface RoundFavoriteRepository extends CrudRepository<RoundFavorite, Long> {
    @Query(value = "select * from round_favorite where QUESTIONNAIRE_ID = :questionnaireId and ROUND_ID = :roundId and USER_ID = :userId limit 1", nativeQuery = true)
    RoundFavorite findByQuestionnaireIdAndRoundId(@Param("questionnaireId") Long questionnaireId, @Param("roundId") Long roundId, @Param("userId") Long userId);
    @Transactional
    @Modifying
    @Query(value = "delete from round_favorite where USER_ID = :userId and ROUND_ID = :roundId", nativeQuery = true)
    void deleteByUserIdAndRoundId(@Param("userId") Long userId, @Param("roundId") Long roundId);
}
