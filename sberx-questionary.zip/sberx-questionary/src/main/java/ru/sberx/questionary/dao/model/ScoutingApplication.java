package ru.sberx.questionary.dao.model;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.questionary.controller.dto.support.ScoutingDto;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "SCOUTING_APPLICATION")
@Getter
@Setter
public class ScoutingApplication implements Serializable {

    private static final long serialVersionUID = -6293809577194684592L;

    @Id
    @Column(name = "UID")
    private UUID uid;
    @Column(name = "NAME")
    private String name;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "ADMIN_COMMENT")
    private String adminComment;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "QUESTIONNAIRE_ID")
    private Long questionnaireId;

    public ScoutingDto toDto() {
        ScoutingDto dto = new ScoutingDto();
        dto.setUuid(this.uid.toString());
        dto.setName(this.name);
        dto.setEmail(this.email);
        dto.setPhone(this.phone);
        dto.setComment(this.comment);
        dto.setAdminComment(this.adminComment);
        dto.setState(this.state);
        dto.setStateName(GuideService.getState(this.state));
        dto.setCreated(this.created);
        dto.setModified(this.modified);
        dto.setQuestionnaireId(this.questionnaireId);
        return dto;
    }
}
