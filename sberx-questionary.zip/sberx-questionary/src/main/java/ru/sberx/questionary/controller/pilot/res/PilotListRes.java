package ru.sberx.questionary.controller.pilot.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import ru.sberx.questionary.controller.dto.support.GuideDto;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PilotListRes {
    private List<PilotDTO> list;
    private Integer rowCount;
    private Integer totalRowCount;
    private Integer nextPageToken;
    private Integer favoriteCount;
    private Integer limitCount;
    private List<GuideDto> filters;
    private Map<String, Object> schema;
    private Integer maxPilots;
}
