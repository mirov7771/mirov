package ru.sberx.questionary.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.dao.model.ScoutingApplication;

import java.util.Date;
import java.util.UUID;

import static ru.sberx.utils.validator.ConditionValidator.nvl;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ScoutingDto {
    private String uuid;
    private String name;
    private String phone;
    private String email;
    private String comment;
    private String adminComment;
    private Long state;
    private String stateName;
    @JsonFormat(timezone = "GMT+3")
    private Date modified;
    @JsonFormat(timezone = "GMT+3")
    private Date created;
    private Long userId;
    private Long questionnaireId;
    private String participantName;

    public ScoutingApplication toDao(Long questionnaireId){
        ScoutingApplication dao = new ScoutingApplication();
        if (StringUtils.hasText(this.uuid)) {
            dao.setUid(UUID.fromString(this.uuid));
        } else {
            dao.setUid(UUID.randomUUID());
            dao.setCreated(new Date());
        }
        if (StringUtils.hasText(this.name))
            dao.setName(this.name);
        if (StringUtils.hasText(this.phone))
            dao.setPhone(this.phone);
        if (StringUtils.hasText(this.email))
            dao.setEmail(this.email);
        if (StringUtils.hasText(this.comment))
            dao.setComment(this.comment);
        if (StringUtils.hasText(this.adminComment))
            dao.setAdminComment(this.adminComment);
        dao.setState(nvl(this.state, 20002L));
        dao.setModified(new Date());
        dao.setQuestionnaireId(questionnaireId);
        return dao;
    }
}
