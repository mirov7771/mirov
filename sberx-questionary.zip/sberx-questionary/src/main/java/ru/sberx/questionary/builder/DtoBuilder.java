package ru.sberx.questionary.builder;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.questionary.controller.dto.support.CommunityUser;
import ru.sberx.questionary.controller.dto.support.Contact;
import ru.sberx.questionary.controller.dto.support.Founder;
import ru.sberx.questionary.controller.dto.support.Investment;
import ru.sberx.questionary.controller.dto.support.Project;
import ru.sberx.questionary.controller.dto.support.Representative;
import ru.sberx.questionary.controller.dto.support.Response;
import ru.sberx.questionary.controller.dto.support.Worker;
import ru.sberx.questionary.controller.dto.support.*;
import ru.sberx.questionary.controller.pilot.support.PilotDTO;
import ru.sberx.questionary.dao.model.Questionnaire;
import ru.sberx.questionary.dao.model.QuestionnaireFunds;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.util.GuideService;

import java.util.*;
import java.util.stream.Collectors;

import static ru.sberx.questionary.util.GuideService.LANG_RU;
import static ru.sberx.utils.validator.ConditionValidator.nvl;

@Component
@RequiredArgsConstructor
public class DtoBuilder {

    private final JoinTableBuilder joinTableBuilder;
    private final ContactRepository contactRepository;
    private final PilotRepository pilotRepository;
    private final SberFiveHundredRepository sberFiveHundredRepository;
    private final WorkerRepository workerRepository;
    private final ObjectFavoriteRepository objectFavoriteRepository;
    private final ObjectActionRepository objectActionRepository;
    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final ImportReplaceDAORepository importReplaceDAORepository;
    private final InvestmentLocaleDaoRepository investmentLocaleDaoRepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final ImportReplaceLangDaoRepository importReplaceLangDaoRepository;

    public List<ru.sberx.questionary.controller.dto.support.Questionnaire> createListRes(List<Questionnaire> list,
                                                                                         Boolean preAuth,
                                                                                         Boolean forLending,
                                                                                         Integer type,
                                                                                         Long clientId,
                                                                                         Boolean sortBy,
                                                                                         Long externalId,
                                                                                         String filteredBy,
                                                                                         Long userId,
                                                                                         Boolean isImport,
                                                                                         String lang,
                                                                                         Boolean isAdmin) {
        List<ru.sberx.questionary.controller.dto.support.Questionnaire> resList = new ArrayList<>();
        int i = 0;
        if (!CollectionUtils.isEmpty(list)) {
            List<ru.sberx.questionary.dao.model.Contact> contacts = null;
            List<ru.sberx.questionary.dao.model.Pilot> pilots = null;
            List<ru.sberx.questionary.dao.model.Pilot> successPilots = null;
            List<ru.sberx.questionary.dao.model.SberFiveHundred> sberFiveHundredList = null;
            List<ru.sberx.questionary.dao.model.Worker> workers = null;
            List<UserQuestionnaire> userQuestionnaires = null;
            List<Long> ids = list.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList());
            List<ru.sberx.questionary.dao.model.ObjectFavoriteDao> objectFavorites = objectFavoriteRepository.findAllByObjectIdInAndObjectTypeAndUserId(ids, "Questionnaire", userId);
            List<ImportReplaceDAO> importReplaceDAOS = null;
            Map<Long, QuestionnaireLocaleDao> questionnaireLocaleMap;
            Map<Long, ProjectLocaleDao> projectLocaleMap;
            Map<Long, InvestmentLocaleDao> investmentLocaleMap;
            Map<Long, PilotLocalDao> pilotLocalMap;

            questionnaireLocaleMap = joinTableBuilder.getQuestionnaireLocaleMap(ids, lang, isAdmin);
            pilotLocalMap = joinTableBuilder.getPilotLocaleMap(ids, lang);
            if (type.equals(0))
                importReplaceDAOS = importReplaceDAORepository.findByQuestionnaireIdIn(ids);

            List<ObjectAction> objectActions = null;
            if (userId != null)
                objectActions = objectActionRepository.findByObjectIdInAndObjectTypeAndActionAndUserId(ids, "Questionnaire", "view", userId);
            if (clientId != 111260 && clientId != 8385) {
                contacts = contactRepository.findByQuestionnaireIdInAndIsDisabledAndLang(ids, false, lang);
                pilots = pilotRepository.findByQuestionnaireIdAndIsDisabledAndEcoSystem(ids);
                successPilots = pilotRepository.findByQuestionnaireIdInAndIsSuccess(ids, true);
                sberFiveHundredList = sberFiveHundredRepository.findByQuestionnaireIdIn(ids);
                workers = workerRepository.findByQuestionnaireIdInAndLang(ids, lang);
                userQuestionnaires = userQuestionnaireRepository.findByQuestionnaireIdIn(ids);
            }
            List<UserQuestionnaire> userIds = joinTableBuilder.getUserQuestionnaire(list);

            List<ru.sberx.questionary.dao.model.Project> project = joinTableBuilder.getProject(list);
            projectLocaleMap = joinTableBuilder.getProjectLocaleMap(project, lang);

            List<ru.sberx.questionary.dao.model.Investment> investment = joinTableBuilder.getInvestment(list);
            investmentLocaleMap = joinTableBuilder.getInvestmentLocaleMap(investment, lang);

            for (Questionnaire item : list) {
                ru.sberx.questionary.controller.dto.support.Questionnaire res = new ru.sberx.questionary.controller.dto.support.Questionnaire();
                res.setQuestionnaireId(item.getQuestionnaireId());
                QuestionnaireLocaleDao questionnaireLocale = questionnaireLocaleMap.get(item.getQuestionnaireId());

                if (questionnaireLocale != null) {
                    res.setUuid(String.valueOf(questionnaireLocale.getUuid()));
                    if (!Boolean.TRUE.equals(forLending)) {
                        res.setName(questionnaireLocale.getName() == null ? questionnaireLocale.getFullName() : questionnaireLocale.getName());
                        res.setFullName(questionnaireLocale.getFullName());
                    }
                    res.setLogoFile(questionnaireLocale.getLogoFile());
                    res.setNote(nvl(questionnaireLocale.getNote(), GuideService.INVESTOR.equals(item.getType()) ? questionnaireLocale.getFullName() : ""));
                }
                if (i < 6 && !Boolean.TRUE.equals(preAuth))
                    res.setIsNew(true);
                if (Boolean.TRUE.equals(preAuth))
                    res.setIsNew(item.getIsNew());
                if (res.getIsNew() == null || !Boolean.TRUE.equals(res.getIsNew()))
                    res.setIsNew(false);
                if (clientId != 111260 && clientId != 8385) {
                    if (questionnaireLocale != null) {
                        res.setName(questionnaireLocale.getName());
                        res.setFullName(questionnaireLocale.getFullName());
                        res.setPhoneNumber(questionnaireLocale.getPhoneNumber());
                        res.setEmail(questionnaireLocale.getEmail());
                        res.setInviteFio(questionnaireLocale.getInviteFio());
                        res.setSite(questionnaireLocale.getSite());
                        res.setRegistrationCountry(questionnaireLocale.getRegistrationCountry());
                        res.setBirthDay(questionnaireLocale.getBirthDay());
                        res.setFullNote(questionnaireLocale.getFullNote());
                        res.setInn(questionnaireLocale.getInn());
                        res.setAcceleratorString(questionnaireLocale.getAcceleratorString());
                    }
                    res.setLocation(item.getLocation());
                    res.setParentId(item.getParentId());
                    res.setPilot(Boolean.TRUE.equals(item.getPilot()));

                    if (!CollectionUtils.isEmpty(userQuestionnaires)) {
                        for (UserQuestionnaire u : userQuestionnaires) {
                            if (u.getUserId() != null && u.getQuestionnaireId().equals(item.getQuestionnaireId())) {
                                res.setMailingConsent(StringUtils.hasText(item.getIsMarketing()) && "ДА".equalsIgnoreCase(item.getIsMarketing()));
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(pilots)) {
                        for (ru.sberx.questionary.dao.model.Pilot p : pilots) {
                            if (p.getQuestionnaireId() != null && item.getQuestionnaireId().equals(p.getQuestionnaireId())) {
                                res.setEcoSystem(true);
                                res.setEcosystemPilot(new PilotDTO(p, pilotLocalMap.get(p.getPilotId()), true));
                                break;
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(contacts)) {
                        res.setContacts(new ArrayList<>());
                        for (ru.sberx.questionary.dao.model.Contact c : contacts) {
                            if (c.getQuestionnaireId() != null && item.getQuestionnaireId().equals(c.getQuestionnaireId())) {
                                Contact cc = new Contact();
                                cc.setContactId(c.getContactId());
                                cc.setType(c.getType());
                                cc.setName(c.getName());
                                cc.setValue(c.getValue());
                                res.getContacts().add(cc);
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(successPilots)) {
                        res.setSuccessPilotsList(new ArrayList<>());
                        res.setSuccessPilots(Boolean.TRUE.equals(item.getSuccessPilots()));
                        for (ru.sberx.questionary.dao.model.Pilot p : successPilots) {
                            if (p.getQuestionnaireId() != null && item.getQuestionnaireId().equals(p.getQuestionnaireId())) {
                                PilotDTO pp = new PilotDTO();
                                PilotLocalDao ppl = pilotLocalMap.get(p.getPilotId());
                                pp.setPilotId(p.getPilotId());
                                pp.setQuestionnaireId(p.getQuestionnaireId());
                                pp.setReference(p.getReference());
                                pp.setSuggestCase(ppl != null ? ppl.getSuggestCase() : p.getSuggestCase());
                                pp.setIsB2B(Boolean.TRUE.equals(p.getIsB2B()));
                                pp.setEcoSystem(Boolean.TRUE.equals(p.getEcoSystem()));
                                pp.setExperience(Boolean.TRUE.equals(p.getExperience()));
                                res.getSuccessPilotsList().add(pp);
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(sberFiveHundredList)) {
                        for (SberFiveHundred sfh : sberFiveHundredList) {
                            if (sfh.getQuestionnaireId() != null && item.getQuestionnaireId().equals(sfh.getQuestionnaireId())) {
                                res.setSberFiveHundred(sfh.toDto());
                            }
                        }
                    }

                    if (!CollectionUtils.isEmpty(workers)) {
                        res.setWorkers(new ArrayList<>());
                        for (ru.sberx.questionary.dao.model.Worker w : workers) {
                            if (w.getQuestionnaireId() != null && item.getQuestionnaireId().equals(w.getQuestionnaireId())) {
                                res.getWorkers().add(w.toDto());
                            }
                        }
                    }
                }
                res.setIndustry(item.getIndustry());
                res.setStady(item.getStady());
                res.setRound(item.getRound());
                res.setGeography(item.getGeography());
                res.setTags(item.getTags());
                res.setCreated(item.getCreated());
                res.setModified(item.getModified());
                res.setState(item.getState());
                res.setStateName(GuideService.getState(item.getState()));
                res.setUserId(joinTableBuilder.build(item, userIds));
                res.setStateCode(item.getState());
                res.setBusinessModel(item.getBusinessModel());
                res.setForLending(item.getForLending());
                res.setInvestorType(item.getInvestorType());
                res.setInnovationMethod(item.getInnovationMethod());
                res.setAcceleratorCode(item.getAcceleratorCode());
                res.setPriority(item.getPriority());
                res.setTechnology(item.getTechnology());
                res.setRevisionDate(item.getRevisionDate());
                res.setSber500(Boolean.TRUE.equals(item.getSber500()));
                res.setType(item.getType());
                res.setLastEnter(item.getLastEnter());
                if (!CollectionUtils.isEmpty(objectFavorites)) {
                    int n = 0;
                    for (ru.sberx.questionary.dao.model.ObjectFavoriteDao objectFavorite : objectFavorites) {
                        if (objectFavorite.getObjectId() != null && item.getQuestionnaireId().equals(objectFavorite.getObjectId())) {
                            n++;
                            if (objectFavorite.getQuestionnaireId().equals(externalId))
                                res.setFavorite(true);
                        }
                    }
                    res.setFavorite(Boolean.TRUE.equals(res.getFavorite()));
                    res.setFavorites(n);
                }

                if (!CollectionUtils.isEmpty(objectActions))
                    res.setView(objectActions.stream().anyMatch(action -> action.getObjectId().equals(item.getQuestionnaireId())));

                List<ru.sberx.questionary.dao.model.Project> plist = joinTableBuilder.build(project, item.getQuestionnaireId(), projectLocaleMap);
                if (!CollectionUtils.isEmpty(plist)) {
                    ru.sberx.questionary.dao.model.Project project1 = plist.get(0);
                    if (res.getGeography() == null && project1.getGeography() != null)
                        res.setGeography(project1.getGeography());
                    res.setModel(project1.getBusinessModel());
                    res.setStaff(project1.getStaff());
                    res.setInteractionType(project1.getInteractionType());
                    res.setSales(project1.getSales());
                    res.setSalesValue(project1.getSales());
                    if (res.getIndustry() == null || res.getIndustry().length == 0)
                        res.setIndustry(project1.getIndustry());
                    if (project1.getNote() != null && !"".equals(project1.getNote())) {
                        res.setNote(project1.getNote().length() > 90 ? project1.getNote().substring(0, 90) + "..." : project1.getNote());
                    }
                    if (res.getTechnology() == null || res.getTechnology().length == 0)
                        res.setTechnology(project1.getTechnology());
                    res.setProjectGeography(project1.getGeography());
                    res.setProjectTechnology(project1.getTechnology());

                    res.setProject(project1.toDto());

                    if (item.getType() != null
                            && item.getType().equals(0)
                            && project1.getMvpCode() != null
                            && project1.getMvpCode().length > 0) {
                        res.setStady(project1.getMvpCode());
                    }
                }
                ru.sberx.questionary.dao.model.Investment investment1 = joinTableBuilder.buildInvest(investment, item.getQuestionnaireId(), investmentLocaleMap);
                if (investment1 != null) {
                    if (investment1.getRound() != null && res.getRound() == null)
                        res.setRound(investment1.getRound());
                    if (investment1.getIndustry() != null && res.getIndustry() == null)
                        res.setIndustry(investment1.getIndustry());
                    if (investment1.getGeography() != null && res.getGeography() == null)
                        res.setGeography(investment1.getGeography());
                    if (res.getTechnology() == null || res.getTechnology().length == 0)
                        res.setTechnology(investment1.getTechnology());
                    res.setInvestmentGeography(investment1.getGeography());
                    res.setInvestmentTechnology(investment1.getTechnology());
                    res.setInvestmentIndustry(investment1.getIndustry());
                    res.setInvestment(investment1.getInvestment());

                    res.setQInvestment(investment1.toDto());
                    res.setBusinessPlan(investment1.getBusinessPlan());
                }
                res.setLocationCountry(item.getLocationCountry());
                res.setResponsible(item.getResponsible());
                res.setResponsibleLogin(item.getResponsibleLogin());
                res.setUpdateDateForSort(item.getUpdateDateForSort());
                res.setEnableOffers(item.getEnableOffers());
                res.setLanguages(item.getLanguages());
                res.setMainLanguage(item.getMainLanguage());
                res.setLabelNew(item.getLabelNew() != null ? Boolean.TRUE.equals(item.getLabelNew().after(new Date())) : null);
                if (item.getInvestorType() != null) {
                    if (item.getInvestorType().equals(11001L)) {
                        res.setInvestorSort(0);
                    } else if (item.getInvestorType().equals(11004L)) {
                        res.setInvestorSort(1);
                    } else if (item.getInvestorType().equals(11002L)) {
                        res.setInvestorSort(3);
                    } else {
                        res.setInvestorSort(4);
                    }
                } else {
                    res.setInvestorSort(4);
                }

                if (Boolean.TRUE.equals(isImport) && !CollectionUtils.isEmpty(importReplaceDAOS)) {
                    importReplaceDAOS.forEach(e -> {
                        if (e.getName() != null && e.getQuestionnaireId().equals(res.getQuestionnaireId()))
                            res.setImportReplaceName(Arrays.asList(e.getName()));
                    });
                }
                resList.add(res);
                i++;
            }
        }
        if (!Boolean.TRUE.equals(forLending) && !Boolean.TRUE.equals(sortBy)) {

            if (filteredBy == null && type.equals(2)) {
                Collections.shuffle(resList);
            } else {
                resList = resList
                        .stream()
                        .sorted(Comparator.comparing(q -> Boolean.TRUE.equals(q.getIsNew()) ? (-1) * q.getCreated().getTime() : q.getCreated().getTime()))
                        .collect(Collectors.toList());
            }
            if (type.equals(2))
                resList = resList.stream().sorted(
                        Comparator.comparing(q -> {
                            if (q.getInvestorType() != null) {
                                if (q.getInvestorType().equals(11001L)) {
                                    return 0;
                                } else if (q.getInvestorType().equals(11004L)) {
                                    return 1;
                                } else if (q.getInvestorType().equals(11002L)) {
                                    return 2;
                                } else {
                                    return 3;
                                }
                            } else {
                                return 4;
                            }
                        })
                ).collect(Collectors.toList());
        }
        return resList;
    }

    public ru.sberx.questionary.controller.dto.support.Questionnaire createQuestionnaire(Questionnaire questionnaire, String lang) {
        List<UserQuestionnaire> userQuestionnaires = joinTableBuilder.getUserQuestionnaire(questionnaire.getQuestionnaireId());
        QuestionnaireLocaleDao questionnaireLocale = joinTableBuilder.getQuestionnaireLocale(questionnaire.getQuestionnaireId(), lang);
        if (questionnaireLocale == null)
            questionnaireLocale = new QuestionnaireLocaleDao();
        return new ru.sberx.questionary.controller.dto.support.Questionnaire(
                questionnaireLocale.getName(),
                questionnaireLocale.getFullName(),
                questionnaireLocale.getBirthDay(),
                questionnaire.getLocation(),
                questionnaireLocale.getLogoFile(),
                nvl(questionnaire.getLegalRegistered(), false),
                nvl(questionnaire.getMentoring(), false),
                questionnaire.getTurnOver(),
                questionnaireLocale.getSite(),
                questionnaireLocale.getNote(),
                questionnaire.getInnovationMethod(),
                questionnaire.getIndustry(),
                nvl(questionnaire.getMailNews(), false),
                questionnaire.getStady(),
                nvl(questionnaire.getClub(), false),
                nvl(questionnaire.getRepresentative(), false),
                questionnaire.getType(),
                GuideService.getTypeName(questionnaire.getType()),
                questionnaire.getModified(),
                questionnaire.getCreated(),
                nvl(questionnaire.getIsBran(), false),
                nvl(questionnaire.getIsDisabled(), false),
                questionnaire.getRound(),
                questionnaire.getGeography(),
                questionnaire.getTags(),
                questionnaireLocale.getPhoneNumber(),
                questionnaireLocale.getEmail(),
                questionnaire.getOwner(),
                questionnaireLocale.getInviteFio(),
                questionnaire.getInviteUnit(),
                questionnaire.getInviteUser(),
                questionnaire.getQuestionnaireId(),
                questionnaire.getComment(),
                questionnaire.getParentId(),
                questionnaire.getState(),
                GuideService.getState(questionnaire.getState()),
                null,
                null,
                null,
                null,
                questionnaire.getInvestorType(),
                questionnaireLocale.getRegistrationCountry(),
                joinTableBuilder.build(questionnaire, userQuestionnaires),
                nvl(questionnaire.getSuccessfullCase(), false),
                nvl(questionnaire.getScouting(), false),
                questionnaire.getStartupInvestmentYears(),
                questionnaire.getLastYearInvestmentsCount(),
                questionnaire.getOverallPilots(),
                questionnaire.getOverallContracts(),
                questionnaire.getCommunityState(),
                questionnaire.getAllDealsNumber(),
                questionnaire.getExitDealsNumber(),
                questionnaire.getActiveDealsNumber(),
                getYearFromDate(questionnaire.getBirthDay()),
                nvl(questionnaire.getAccelerator(), false),
                questionnaire.getLocationCountry(),
                nvl(questionnaire.getCommunity(), false),
                nvl(questionnaire.getSuccessPilots(), false),
                nvl(questionnaire.getPilot(), false),
                nvl(questionnaire.getSuccessPilotsB2C(), false),
                questionnaire.getState(),
                null,
                null,
                questionnaire.getPortfolioNote(),
                questionnaire.getBusinessModel(),
                nvl(questionnaire.getForLending(), false),
                questionnaire.getTranscription(),
                questionnaire.getAcceleratorCode(),
                questionnaire.getPriority(),
                null,
                questionnaire.getEmail(),
                questionnaire.getPhoneNumber(),
                questionnaireLocale.getFullNote(),
                questionnaire.getTechnology(),
                null,
                null,
                null,
                null,
                null,
                questionnaire.getRevisionDate(),
                questionnaireLocale.getInn(),
                questionnaire.getAcceleratorSite(),
                null,
                null,
                null,
                null,
                null,
                null,
                questionnaire.getSber500(),
                null,
                null,
                null,
                null,
                null,
                null,
                questionnaireLocale.getUuid() != null ? String.valueOf(questionnaireLocale.getUuid()) : String.valueOf(questionnaire.getUuid()),
                questionnaire.getResponsible(),
                questionnaire.getResponsibleLogin(),
                questionnaire.getUpdateDateForSort(),
                null,
                null,
                null,
                questionnaire.getEnableOffers(),
                null,
                null,
                questionnaire.getIsImport(),
                null,
                null,
                questionnaireLocale.getAcceleratorString(),
                questionnaire.getLastEnter(),
                questionnaire.getLanguages(),
                questionnaire.getMainLanguage(),
                questionnaire.getLabelNew() != null ? Boolean.TRUE.equals(questionnaire.getLabelNew().after(new Date())) : null
        );
    }

    private Integer getYearFromDate(Date birthDay) {
        if (birthDay != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(birthDay);
            return cal.get(Calendar.YEAR);
        }
        return null;
    }

    public Project createProject(ru.sberx.questionary.dao.model.Project item, String lang) {
        ProjectLocaleDao projectLocale = projectLocaleDaoRepository.findByProjectIdAndLang(item.getProjectId(), lang);
        if (projectLocale == null && !LANG_RU.equals(lang))
            projectLocale = projectLocaleDaoRepository.findByProjectIdAndLang(item.getProjectId(), LANG_RU);
        if (projectLocale == null)
            projectLocale = new ProjectLocaleDao();
        return new Project(
                item.getName(),
                projectLocale.getNote(),
                item.getIndustry(),
                item.getInteractionType(),
                item.getBusinessModel(),
                projectLocale.getProblem(),
                projectLocale.getAuditory(),
                nvl(item.getHaveMVP(), false),
                item.getGeography(),
                item.getSales(),
                item.getDemoSite(),
                item.getDemoFile(),
                projectLocale.getCompetitor(),
                projectLocale.getUpSide(),
                item.getDownSide(),
                item.getStaff(),
                item.getHiringStaff(),
                item.getExperience(),
                item.getStady(),
                nvl(item.getIsDisabled(), false),
                item.getParentId(),
                item.getStaffLocation(),
                item.getExpansion(),
                item.getIndirectCompetitor(),
                projectLocale.getDemoVideo(),
                item.getPitchVideo(),
                item.getAddNote(),
                item.getMvpCode(),
                item.getTechnology(),
                item.getProjectId()
        );
    }

    public List<Worker> createWorkerList(List<ru.sberx.questionary.dao.model.Worker> workerList) {
        return workerList.stream().map(item -> {
            Worker w = new Worker();
            w.setNote(item.getNote());
            w.setAge(item.getAge());
            w.setFio(item.getFio());
            w.setPercentage(item.getPercentage());
            w.setWorkerId(item.getWorkerId());
            w.setRole(item.getRole());
            w.setParentId(item.getParentId());
            w.setIsFounder(nvl(item.getIsFounder(), false));
            w.setFacebook(item.getFacebook());
            return w;
        }).collect(Collectors.toList());
    }

    public Investment createInvestment(ru.sberx.questionary.dao.model.Investment investment, String lang) {
        InvestmentLocaleDao investmentLocaleDao = investmentLocaleDaoRepository.findByQuestionnaireIdAndLang(investment.getQuestionnaireId(), lang);
        if (investmentLocaleDao == null && !LANG_RU.equals(lang))
            investmentLocaleDao = investmentLocaleDaoRepository.findByQuestionnaireIdAndLang(investment.getQuestionnaireId(), LANG_RU);
        if (investmentLocaleDao == null)
            investmentLocaleDao = new InvestmentLocaleDao();
        return new Investment(
                nvl(investmentLocaleDao.getInvestment(), false),
                investment.getExperience(),
                investment.getRound(),
                investment.getSumInvestment(),
                investmentLocaleDao.getLastInvestment(),
                investmentLocaleDao.getCoInvestment(),
                investment.getTurnover(),
                investmentLocaleDao.getBusinessPlan(),
                investment.getIndustry(),
                investment.getGeography(),
                investment.getNote(),
                nvl(investment.getIsDisabled(), false),
                investment.getParentId(),
                investment.getTechnology(),
                investment.getPlanInvestment()
        );
    }

    public List<PilotDTO> createPilotList(List<ru.sberx.questionary.dao.model.Pilot> pilotList, Map<Long, PilotLocalDao> localMap) {
        return pilotList.stream().map(item -> {
            PilotDTO p = new PilotDTO();
            PilotLocalDao pl = localMap.get(item.getPilotId());
            p.setPilotId(item.getPilotId());
            p.setPilot_id(item.getPilotId());
            p.setPilot(nvl(item.getPilot(), false));
            p.setBusinessUnit(pl != null ? pl.getBusinessUnit() : item.getBusinessUnit());
            p.setSuggestCase(pl != null ? pl.getSuggestCase() : item.getSuggestCase());
            p.setName(pl != null ? pl.getName() : item.getName());
            p.setConditions(item.getConditions());
            p.setDepartment(item.getDepartment());
            p.setExperience(nvl(item.getExperience(), false));
            p.setReference(item.getReference());
            p.setFile(nvl(item.getFile(), false));
            p.setState(item.getState());
            p.setIsBran(nvl(item.getIsBran(), false));
            p.setTarget(item.getTarget());
            p.setRelevance(item.getRelevance());
            p.setEffect(item.getEffect());
            p.setResources(item.getResources());
            p.setSearch(nvl(item.getSearch(), false));
            p.setDeadLine(item.getDeadLine());
            p.setExp(item.getExp());
            p.setCompany(item.getCompany());
            p.setDecision(item.getDecision());
            p.setIsForeign(nvl(item.getIsForeign(), false));
            p.setDecisionCompany(item.getDecisionCompany());
            p.setIsHub(nvl(item.getIsHub(), false));
            p.setCreatorId(item.getCreatorId());
            p.setEcoSystem(nvl(item.getEcoSystem(), false));
            p.setIsSuccess(nvl(item.getIsSuccess(), false));
            p.setIsB2C(nvl(item.getIsB2C(), false));
            p.setIsB2B(nvl(item.getIsB2B(), false));
            p.setIsQuestionnaire(nvl(item.getIsQuestionnaire(), false));
            if (pl != null && !CollectionUtils.isEmpty(pl.getResponseList())) {
                p.setResponse(pl.getResponseList().stream().map(Response::new).collect(Collectors.toList()));
            }
            p.setSite(item.getSite());
            return p;
        }).collect(Collectors.toList());
    }

    public PilotDTO createPilot(List<ru.sberx.questionary.dao.model.Pilot> pilotList, Map<Long, PilotLocalDao> localMap) {
        ru.sberx.questionary.dao.model.Pilot p = null;
        for (ru.sberx.questionary.dao.model.Pilot i : pilotList) {
            if (GuideService.SUGGEST_CASE_STATE.equals(i.getState())
                    && Boolean.TRUE.equals(i.getEcoSystem())) {
                p = i;
                break;
            }
        }
        if (p == null)
            p = pilotList.get(0);
        return new PilotDTO(p, localMap.get(p.getPilotId()), true);
    }

    public List<Representative> createRepresentativeList(List<ru.sberx.questionary.dao.model.Representative> representativeList) {
        return representativeList.stream().map(item -> {
            Representative r = new Representative();
            r.setFio(item.getFio());
            r.setRole(item.getRole());
            r.setEmail(item.getEmail());
            r.setPhone(item.getPhone());
            r.setParentId(item.getParentId());
            r.setFacebook(item.getFacebook());
            r.setLastName(item.getLastName());
            r.setFirstName(item.getFirstName());
            r.setPosition(item.getPosition());
            return r;
        }).collect(Collectors.toList());
    }

    public Representative createRepresentative(List<ru.sberx.questionary.dao.model.Representative> representativeList) {
        Representative r = new Representative();
        r.setFio(representativeList.get(0).getFio());
        r.setRole(representativeList.get(0).getRole());
        r.setEmail(representativeList.get(0).getEmail());
        r.setPhone(representativeList.get(0).getPhone());
        r.setParentId(representativeList.get(0).getParentId());
        r.setFacebook(representativeList.get(0).getFacebook());
        r.setFirstName(representativeList.get(0).getFirstName());
        r.setLastName(representativeList.get(0).getLastName());
        r.setPosition(representativeList.get(0).getPosition());
        return r;
    }

    public List<Contact> createContactList(List<ru.sberx.questionary.dao.model.Contact> contacts) {
        return contacts.stream().map(item -> {
            Contact c = new Contact();
            c.setContactId(item.getContactId());
            c.setType(item.getType());
            c.setName(item.getName());
            c.setValue(item.getValue());
            c.setParentId(item.getParentId());
            c.setLang(item.getLang());
            return c;
        }).collect(Collectors.toList());
    }

    public List<FeedBack> createFeedBackList(List<Feedback> feedbacks) {
        return feedbacks.stream().map(FeedBack::new).collect(Collectors.toList());
    }

    public List<User> createUsers(List<UserQuestionnaire> users) {
        return users.stream().map(User::new).collect(Collectors.toList());
    }

    public List<Founder> createFounders(List<ru.sberx.questionary.dao.model.Founder> founders) {
        return founders.stream().map(Founder::new).collect(Collectors.toList());
    }

    public List<CommunityUser> createCommunityUsers(List<ru.sberx.questionary.dao.model.CommunityUser> communityUsers) {
        return communityUsers.stream().map(CommunityUser::new).collect(Collectors.toList());
    }

    public List<InvestorClub> createInvestorClubs(List<InvestmentClub> investmentClubs) {
        return investmentClubs.stream().map(InvestorClub::new).collect(Collectors.toList());
    }

    public List<ru.sberx.questionary.controller.dto.support.QuestionnaireFunds> createQuestionnaireFunds(List<QuestionnaireFunds> questionnaireFunds) {
        return questionnaireFunds.stream().map(ru.sberx.questionary.controller.dto.support.QuestionnaireFunds::new).collect(Collectors.toList());
    }

    public ImportReplaceDTO createImportReplace(ImportReplaceDAO importReplaceDAO, String lang) {
        ImportReplaceDTO importReplaceDTO = new ImportReplaceDTO();
        ImportReplaceLangDao importReplaceLang = importReplaceLangDaoRepository.findByQuestionnaireIdAndLang(importReplaceDAO.getQuestionnaireId(), lang);
        if (importReplaceLang == null && !LANG_RU.equals(lang))
            importReplaceLang = importReplaceLangDaoRepository.findByQuestionnaireIdAndLang(importReplaceDAO.getQuestionnaireId(), LANG_RU);
        importReplaceDTO.setNote(importReplaceLang != null ? importReplaceLang.getNote() : importReplaceDAO.getNote());
        importReplaceDTO.setBenefits(importReplaceLang != null ? importReplaceLang.getBenefits() : importReplaceDAO.getBenefits());
        importReplaceDTO.setQuestionnaireId(importReplaceDAO.getQuestionnaireId());
        if (importReplaceDAO.getName() != null)
            importReplaceDTO.setName(Arrays.asList(importReplaceDAO.getName()));
        return importReplaceDTO;
    }
}
