package ru.sberx.questionary.controller.tariff.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class TariffTypeDto {

    private Integer type;
    private List<SubTypeTariff> subTypes;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    @NoArgsConstructor
    public static class SubTypeTariff {
        private Integer subType;
        private List<InfoTariff> info;

        public SubTypeTariff(Integer subType, List<InfoTariff> info) {
            this.subType = subType;
            this.info = info;
        }

        @JsonInclude(JsonInclude.Include.NON_NULL)
        @Data
        @NoArgsConstructor
        public static class InfoTariff {
            private String sysname;
            private String name;
            private Boolean active;

            public InfoTariff(String sysname, String name, Boolean active) {
                this.sysname = sysname;
                this.name = name;
                this.active = active;
            }
        }
    }
}
