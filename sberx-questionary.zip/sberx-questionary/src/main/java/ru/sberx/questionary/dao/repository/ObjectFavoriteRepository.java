package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.ObjectFavoriteDao;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface ObjectFavoriteRepository extends CrudRepository<ObjectFavoriteDao, Long> {
    List<ObjectFavoriteDao> findAllByObjectIdInAndObjectTypeAndUserId(List<Long> ids, String objectType, Long userId);
    List<ObjectFavoriteDao> findByQuestionnaireIdInAndObjectIdAndObjectTypeAndUserId(List<Long> questionnaireId, Long objectId, String objectType, Long userId);
    @Query(value = "delete from OBJECT_FAVORITE " +
            "where OBJECT_ID = :objectId " +
            "and USER_ID = :userId " +
            "and OBJECT_TYPE = :objectType", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByObjectIdAndUserId(@Param("objectId") Long objectId, @Param("userId") Long userId, @Param("objectType") String objectType);
    @Query(value = "delete from OBJECT_FAVORITE " +
            "where (OBJECT_ID = :objectId " +
            "or QUESTIONNAIRE_ID = :questionnaireId )" +
            "and OBJECT_TYPE = :objectType", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByObjectIdOrQuestionnaireId(@Param("objectId") Long objectId, @Param("questionnaireId") Long questionnaireId, @Param("objectType") String objectType);
}
