package ru.sberx.questionary.controller.dto.req;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class OffersReq {
    @NotNull
    private Boolean enableOffers;
}
