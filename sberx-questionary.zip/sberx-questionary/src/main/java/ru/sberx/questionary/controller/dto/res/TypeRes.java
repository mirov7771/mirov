package ru.sberx.questionary.controller.dto.res;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class TypeRes {

    private Integer type;
    private Long questionnaireId;
    private Long state;
    private String stateName;
    private String logoPath;
    private String phoneNumber;
    private String email;
    private Date modified;
    private String action;
    private String name;
    private String fullName;
    private Boolean isDisabled;
    private String stateSysName;
    private String investorType;
    private Boolean sber500;
    private String uid;
    private Integer newReply;
    private String inviteFio;
    private String phone;
    private Long userId;
    private Boolean isImport;
    private Long childId;
    private List<Long> replyIds;
    private List<Long> roundIds;
    private List<Long> communityIds;
    private UUID questionnaireUUID;
    private Date lastEnter;
    private Long parentId;

    public TypeRes(Long questionnaireId, String questionnaireUUID, Integer type, String stateName, String investorType, Long userId) {
        this.type = type;
        this.questionnaireId = questionnaireId;
        this.stateName = stateName;
        this.investorType = investorType;
        if (questionnaireUUID != null)
            this.questionnaireUUID = UUID.fromString(questionnaireUUID);
        this.userId = userId;
    }
}
