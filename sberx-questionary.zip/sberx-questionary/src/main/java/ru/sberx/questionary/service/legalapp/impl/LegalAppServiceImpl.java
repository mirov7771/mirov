package ru.sberx.questionary.service.legalapp.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.questionary.controller.lagalapp.req.PostLegalAppReq;
import ru.sberx.questionary.dao.model.LegalApplication;
import ru.sberx.questionary.dao.model.ProjectLocaleDao;
import ru.sberx.questionary.dao.model.QuestionnaireLocaleDao;
import ru.sberx.questionary.dao.repository.LegalApplicationRepository;
import ru.sberx.questionary.dao.repository.ProjectLocaleDaoRepository;
import ru.sberx.questionary.dao.repository.QuestionnaireLocaleDaoRepository;
import ru.sberx.questionary.gate.service.MidService;
import ru.sberx.questionary.service.legalapp.LegalAppService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Service
@RequiredArgsConstructor
public class LegalAppServiceImpl implements LegalAppService {

    private final LegalApplicationRepository legalApplicationRepository;
    private final QuestionnaireLocaleDaoRepository questionnaireLocaleDaoRepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final MidService midService;

    @Value("${application.receivers.legal-application}")
    private final List<String> receivers;

    @Override
    public void post(PostLegalAppReq req) {
        QuestionnaireLocaleDao questionnaireLocale = questionnaireLocaleDaoRepository.findByUserIdAndLang(req.getUserId(), req.getLocale());
        if (questionnaireLocale == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);
        ProjectLocaleDao projectLocale = projectLocaleDaoRepository.findByQuestionnaireIdAndLang(questionnaireLocale.getQuestionnaireId(), req.getLocale());
        Map<String, Object> params = new HashMap<>();
        params.put("service", req.getLawServiceValue());
        params.put("startup", questionnaireLocale.getName());
        params.put("note", projectLocale != null ? projectLocale.getNote() : "");
        params.put("site", questionnaireLocale.getSite());
        params.put("inn", questionnaireLocale.getInn());
        params.put("name", req.getName());
        params.put("email", req.getEmail());
        params.put("phone", req.getPhoneNumber());
        params.put("comment", req.getProblem());
        CompletableFuture.runAsync(() -> receivers.forEach(receiver -> midService.notify("NEW_LOW_APPLICATION", params, receiver)));

        legalApplicationRepository.save(LegalApplication.builder()
                .userId(req.getUserId())
                .name(req.getName())
                .phoneNumber(req.getPhoneNumber())
                .email(req.getEmail())
                .ipService(req.getLawService())
                .problem(req.getProblem())
                .questionnaireId(questionnaireLocale.getQuestionnaireId())
                .state(20002L)
                .build());
    }
}
