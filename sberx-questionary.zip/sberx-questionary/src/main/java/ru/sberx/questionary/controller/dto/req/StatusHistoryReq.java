package ru.sberx.questionary.controller.dto.req;

import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
public class StatusHistoryReq {

    private Long questionnaireId;
    private Integer type;
    private String direction;
    private Boolean child;

}
