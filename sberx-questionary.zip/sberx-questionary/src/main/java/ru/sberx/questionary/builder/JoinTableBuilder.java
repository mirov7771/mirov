package ru.sberx.questionary.builder;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.questionary.dao.model.*;
import ru.sberx.questionary.dao.repository.*;
import ru.sberx.questionary.util.GuideService;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class JoinTableBuilder {

    private final UserQuestionnaireRepository userQuestionnaireRepository;
    private final ProjectRepository projectRepository;
    private final InvestmentRepository investmentRepository;
    private final QuestionnaireLocaleDaoRepository questionnaireLocaleDaoRepository;
    private final ProjectLocaleDaoRepository projectLocaleDaoRepository;
    private final InvestmentLocaleDaoRepository investmentLocaleDaoRepository;
    private final PilotLocalDaoRepository pilotLocalDaoRepository;

    public List<UserQuestionnaire> getUserQuestionnaire(List<Questionnaire> list) {
        return userQuestionnaireRepository.findByQuestionnaireIdIn(
                list.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList())
        );
    }

    public List<UserQuestionnaire> getUserQuestionnaire(Long questionnaireId) {
        return userQuestionnaireRepository.findByQuestionnaireId(
                questionnaireId
        );
    }

    public List<Project> getProject(List<Questionnaire> list) {
        return projectRepository.findByQuestionnaireIdIn(
                list.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList())
        );
    }

    public List<Investment> getInvestment(List<Questionnaire> list) {
        return investmentRepository.findByQuestionnaireIdIn(
                list.stream().map(Questionnaire::getQuestionnaireId).collect(Collectors.toList())
        );
    }

    public QuestionnaireLocaleDao getQuestionnaireLocale(Long questionnaireId, String lang) {
        QuestionnaireLocaleDao questionnaireLocaleDao = questionnaireLocaleDaoRepository.findByQuestionnaireIdAndLang(questionnaireId, lang);
        if (questionnaireLocaleDao == null && !GuideService.LANG_RU.equals(lang))
            questionnaireLocaleDao = questionnaireLocaleDaoRepository.findByQuestionnaireIdAndLang(questionnaireId, GuideService.LANG_RU);
        return questionnaireLocaleDao;
    }

    public List<Long> build(Questionnaire questionnaire, List<UserQuestionnaire> user) {
        List<Long> ids = new ArrayList<>();
        if (!CollectionUtils.isEmpty(user)) {
            for (UserQuestionnaire item : user) {
                if (questionnaire.getQuestionnaireId().equals(item.getQuestionnaireId())) {
                    ids.add(item.getUserId());
                }
            }
        }
        return !ids.isEmpty() ? ids : null;
    }

    public List<Project> build(List<Project> projectList, Long questionnaireId, Map<Long, ProjectLocaleDao> projectLocaleMap) {
        List<Project> builtList = new ArrayList<>();
        for (Project project : projectList) {
            if (questionnaireId.equals(project.getQuestionnaireId())) {
                ProjectLocaleDao projectLocale = projectLocaleMap.get(project.getProjectId());
                if (projectLocale != null) {
                    project.setAuditory(projectLocale.getAuditory());
                    project.setCompetitor(projectLocale.getCompetitor());
                    project.setNote(projectLocale.getNote());
                    project.setDemoVideo(projectLocale.getDemoVideo());
                    project.setProblem(projectLocale.getProblem());
                    project.setUpSide(projectLocale.getUpSide());
                }
                builtList.add(project);
            }
        }
        return !builtList.isEmpty() ? builtList : null;
    }

    public Investment buildInvest(List<Investment> investmentList, Long questionnaireId, Map<Long, InvestmentLocaleDao> investmentLocaleMap) {
        for (Investment investment : investmentList) {
            if (questionnaireId.equals(investment.getQuestionnaireId())) {
                InvestmentLocaleDao investmentLocale = investmentLocaleMap.get(questionnaireId);
                if (investmentLocale != null) {
                    investment.setInvestment(Boolean.TRUE.equals(investmentLocale.getInvestment()));
                    investment.setBusinessPlan(investmentLocale.getBusinessPlan());
                    investment.setCoInvestment(investmentLocale.getCoInvestment());
                    investment.setLastInvestment(investmentLocale.getLastInvestment());
                }
                return investment;
            }
        }
        return null;
    }

    public Map<Long, QuestionnaireLocaleDao> getQuestionnaireLocaleMap(List<Long> ids, String lang, Boolean isAdmin) {
        Map<Long, QuestionnaireLocaleDao> questionnaireLocaleMap;
        List<QuestionnaireLocaleDao> questionnaireLocaleDaos = Boolean.TRUE.equals(isAdmin)
                ? questionnaireLocaleDaoRepository.findByQuestionnaireIdIn(ids)
                : questionnaireLocaleDaoRepository.findByQuestionnaireIdInAndLang(ids, lang);
        if (!CollectionUtils.isEmpty(questionnaireLocaleDaos))
            questionnaireLocaleMap = questionnaireLocaleDaos.stream().collect(Collectors.toMap(QuestionnaireLocaleDao::getQuestionnaireId, Function.identity(), (q1, q2) -> {
                if (GuideService.LANG_RU.equals(q1.getLang()))
                    return q1;
                return q2;
            }));
        else
            questionnaireLocaleMap = new HashMap<>();

        List<Long> idsEmpty = ids.stream().filter(id -> !questionnaireLocaleMap.containsKey(id)).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(idsEmpty)) {
            List<QuestionnaireLocaleDao> questionnaireLocaleRu = questionnaireLocaleDaoRepository.findByQuestionnaireIdInAndLang(idsEmpty, GuideService.LANG_RU);
            if (!CollectionUtils.isEmpty(questionnaireLocaleRu))
                questionnaireLocaleMap.putAll(questionnaireLocaleRu.stream().collect(Collectors.toMap(QuestionnaireLocaleDao::getQuestionnaireId, Function.identity())));
        }
        return questionnaireLocaleMap;
    }

    public Map<Long, ProjectLocaleDao> getProjectLocaleMap(List<Project> projects, String lang) {
        if (CollectionUtils.isEmpty(projects))
            return new HashMap<>();
        Map<Long, ProjectLocaleDao> projectLocaleMap;
        List<Long> ids = projects.stream().map(Project::getProjectId).collect(Collectors.toList());
        List<ProjectLocaleDao> projectLocaleDaos = projectLocaleDaoRepository.findByProjectIdInAndLang(ids, lang);
        projectLocaleMap = !CollectionUtils.isEmpty(projectLocaleDaos)
                ? projectLocaleDaos.stream().collect(Collectors.toMap(ProjectLocaleDao::getProjectId, Function.identity()))
                : new HashMap<>();
        List<Long> idsEmpty = ids.stream().filter(id -> !projectLocaleMap.containsKey(id)).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(idsEmpty)) {
            projectLocaleDaos = projectLocaleDaoRepository.findByProjectIdInAndLang(idsEmpty, GuideService.LANG_RU);
            if (!CollectionUtils.isEmpty(projectLocaleDaos))
                projectLocaleMap.putAll(projectLocaleDaos.stream().collect(Collectors.toMap(ProjectLocaleDao::getProjectId, Function.identity())));
        }
        return projectLocaleMap;
    }

    public Map<Long, InvestmentLocaleDao> getInvestmentLocaleMap(List<Investment> investments, String lang) {
        if (CollectionUtils.isEmpty(investments))
            return new HashMap<>();
        Map<Long, InvestmentLocaleDao> investmentLocaleMap;
        List<Long> ids = investments.stream().map(Investment::getQuestionnaireId).collect(Collectors.toList());
        List<InvestmentLocaleDao> investmentLocaleDaos = investmentLocaleDaoRepository.findByQuestionnaireIdInAndLang(ids, lang);
        investmentLocaleMap = !CollectionUtils.isEmpty(investmentLocaleDaos)
                ? investmentLocaleDaos.stream().collect(Collectors.toMap(InvestmentLocaleDao::getQuestionnaireId, Function.identity()))
                : new HashMap<>();
        List<Long> idsEmpty = ids.stream().filter(id -> !investmentLocaleMap.containsKey(id)).collect(Collectors.toList());
        if (!CollectionUtils.isEmpty(idsEmpty)) {
            investmentLocaleDaos = investmentLocaleDaoRepository.findByQuestionnaireIdInAndLang(idsEmpty, GuideService.LANG_RU);
            if (!CollectionUtils.isEmpty(investmentLocaleDaos))
                investmentLocaleMap.putAll(investmentLocaleDaos.stream().collect(Collectors.toMap(InvestmentLocaleDao::getQuestionnaireId, Function.identity())));
        }
        return investmentLocaleMap;
    }

    public Map<Long, PilotLocalDao> getPilotLocaleMap(List<Long> questionnaireIds, String lang) {
        if (CollectionUtils.isEmpty(questionnaireIds))
            return new HashMap<>();
        List<PilotLocalDao> pilotLocalDaos = pilotLocalDaoRepository.findByQuestionnaireIdInAndLang(questionnaireIds, lang);
        if (CollectionUtils.isEmpty(pilotLocalDaos))
            return new HashMap<>();
        return pilotLocalDaos.stream().collect(Collectors.toMap(PilotLocalDao::getPilotId, Function.identity()));
    }
}
