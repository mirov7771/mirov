package ru.sberx.questionary.util;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PopUpStatus {
    PROCESSING("processing"),
    PROCESSING_STARTUP("processing_startup"),
    PROCESSING_CORPORATE("processing_corporate"),
    PROCESSING_INVESTOR("processing_investor"),
    ACTIVE("active"),
    ACTIVE_STARTUP("active_startup"),
    ACTIVE_CORPORATE("active_corporate"),
    ACTIVE_INVESTOR("active_investor"),
    ACTIVE_NOT_UP_SORT("active_not_up_sort"),
    ACTIVE_UP_SORT("active_up_sort"),
    SBER_500("sber500"),
    MAILING_CONSENT("mailingConsent"),
    IMPORT("import"),
    UPDATE_QUESTIONARY("update_questionnaire"),
    COMMUNITY("community"),
    CORPORATE_IMPORT("corporate_import"),
    CSI("csi"),
    STARTUP_IMPORT_REMINE("startup_import_remine"),
    CONGRATULATE("congratulate");

    private final String value;
    public static PopUpStatus getActiveStatus(Integer type) {
        if (Integer.valueOf(0).equals(type))
            return ACTIVE_STARTUP;
        if (Integer.valueOf(1).equals(type))
            return ACTIVE_CORPORATE;
        if (Integer.valueOf(2).equals(type))
            return ACTIVE_INVESTOR;
        return ACTIVE;
    }

    public static PopUpStatus getProcessingStatus(Integer type) {
        if (Integer.valueOf(0).equals(type))
            return PROCESSING_STARTUP;
        if (Integer.valueOf(1).equals(type))
            return PROCESSING_CORPORATE;
        if (Integer.valueOf(2).equals(type))
            return PROCESSING_INVESTOR;
        return PROCESSING;
    }
}
