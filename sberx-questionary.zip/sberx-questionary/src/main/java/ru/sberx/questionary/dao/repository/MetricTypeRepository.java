package ru.sberx.questionary.dao.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.MetricType;

import java.util.Collection;
import java.util.List;

@Repository
public interface MetricTypeRepository extends CrudRepository<MetricType, Long> {
    List<MetricType> findByTypeIdNotIn(Collection<Long> typeIds);
    List<MetricType> findByTypeIdIn(Collection<Long> typeIds);
    @NonNull
    @Override
    List<MetricType> findAll();
}
