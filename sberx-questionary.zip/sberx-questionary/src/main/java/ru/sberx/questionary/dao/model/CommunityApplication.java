package ru.sberx.questionary.dao.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import ru.sberx.questionary.controller.dto.support.Community;
import ru.sberx.questionary.util.GuideService;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "COMMUNITY_APPLICATION")
@Data
@NoArgsConstructor
public class CommunityApplication implements Serializable {

    private static final long serialVersionUID = 8284081545911975266L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "STATE")
    private Long state;
    @Column(name = "MODIFIED")
    private Date modified;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "TYPE")
    private Integer type;
    @Column(name = "NAME")
    private String name;
    @Column(name = "SITE")
    private String site;
    @Column(name = "POSITION")
    private String position;
    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;
    @Column(name = "EXPECTATION")
    private String expectation;
    @Column(name = "USEFUL")
    private String useful;
    @Type(type = "long-array")
    @Column(name = "INDUSTRY")
    private Long[] industry;
    @Type(type = "long-array")
    @Column(name = "TECHNOLOGY")
    private Long[] technology;
    @Column(name = "GEOGRAPHY")
    private Long geography;
    @Type(type = "long-array")
    @Column(name = "ROUND")
    private long[] round;
    @Column(name = "VENTURE_PROJECTS_COUNT")
    private Long ventureProjectsCount;
    @Column(name = "FACEBOOK")
    private String facebook;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "EXPERT")
    private String expert;
    @Column(name = "FIO")
    private String fio;
    @Column(name = "PREAUTH")
    private Boolean preAuth;
    @Column(name = "TELEGRAM")
    private String telegram;

    public Community toCommunityDto(){
        Community community = new Community();
        community.setId(this.id);
        community.setQuestionnaireId(this.questionnaireId);
        community.setState(this.state);
        community.setStateName(GuideService.getStateSysName(this.id));
        community.setModified(this.modified);
        community.setCreated(this.created);
        community.setType(this.type);
        community.setTypeName(GuideService.getTypeNameComApp(this.type));
        community.setName(this.name);
        community.setSite(this.site);
        community.setPosition(this.position);
        community.setPhoneNumber(this.phoneNumber);
        community.setExpectation(this.expectation);
        community.setUseful(this.useful);
        community.setIndustry(this.industry);
        community.setTechnology(this.technology);
        community.setGeography(this.geography);
        community.setRound(this.round);
        community.setVentureProjectsCount(this.ventureProjectsCount);
        community.setFacebook(this.facebook);
        community.setComment(this.comment);
        community.setEmail(this.email);
        community.setExpert(this.expert);
        community.setFio(this.fio);
        community.setPreauth(this.preAuth);
        community.setStateName(GuideService.getState(this.state));
        community.setTelegram(this.telegram);
        return community;
    }
}
