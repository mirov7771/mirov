package ru.sberx.questionary.service;

import ru.sberx.dto.questionary.questionary.questionary.req.PostUserQuestionnaireReq;
import ru.sberx.dto.questionary.questionary.questionary.res.GetUserListRes;
import ru.sberx.questionary.controller.dto.req.*;
import ru.sberx.questionary.controller.dto.res.*;
import ru.sberx.questionary.controller.dto.support.*;
import ru.sberx.questionary.gate.dto.GetPopupRes;

import java.util.List;
import java.util.UUID;

public interface Service {
    List<?> getParticipantList(Long clientId, QuestionnaireListReq req);
    List<TypeRes> getTypeByUserId(Long userId);
    QuestionaryRes getQuestionaryById(Long questionnaireId, String uid, Long parentId, Long userId, String lang, Boolean isEdit);
    TypeRes createQuestionary(QuestionnaireReq req);
    DeleteQuestionnaireRes deleteQuestionnaire(Long questionnaireId);
    QuestionnairePriority updateQuestionnairePriority(QuestionnairePriority req);
    QuestionnaireResponsible updateQuestionnaireResponsible(QuestionnaireResponsible req);
    void updateQuestionnaireOffer(String questionnaireId, OffersReq req, String role);
    void updateQuestionnaire(QuestionnaireUpdateReq req, String role);
    TypeRes createDraft(DraftReq req);
    VerifyRes verify(VerifyReq req);
    FeedBackRes createFeedBack(FeedBack req);
    List<Disabled> disabled(DisabledReq req);
    ApplicationDto createApplication(ApplicationDto application);
    ApplicationDto getApplicationById(Long id, String email);
    ApplicationDto getApplicationByUid(String uid, Boolean auth);
    ApplicationListRes getApplicationList(ApplicationListReq req);
    PopupStatusRes getPopupStatus(Long questionnaireId);
    List<GetPopupRes> getPopupStatusV2(Long questionnaireId, Long userId, String locale);
    ViewCardRes viewCard(Long id, UUID uuid, String sessionId);
    List<GetUserRes> getUserById(Long id, Boolean getQuestionnaireUserIdOnly);
    RoundDto createRound(RoundReq req, Long userId);
    RoundDto createRoundV2(RoundReq req, Long userId);
    RoundDto getRoundByIdV2(Long roundId, Long userId);
    RoundDto getRoundById(Long roundId, Long userId);
    RoundListRes getRoundList(RoundListReq req, Long userId, String role, String locale);
    void updateRoundV2(RoundReq req, Long roundId);
    void updateRound(RoundReq req, Long roundId);
    void addFavorite(AddFavoriteReq req, Long userId);
    Community postCommunity(Community req, String sessionId);
    Community getCommunity(Long id, String sessionId, Long userId);
    CommunityListRes getCommunityList(CommunityListReq req);
    Community changeCommunity(Community req, Long id, String sessionId);
    TypeRes getOneTypeByUserId(Long userId);
    List<TypeRes> getTypeList(TypeListReq req);
    StatusInfoListRes getStatusHistory(StatusHistoryReq req);
    Syndicate saveSyndicate(Syndicate req);
    SyndicateRes getSyndicateList(SyndicateReq req);
    Syndicate getSyndicateQuestionnaire(Long id, String uid);
    QuestionnaireGuidListRes getQuestionnaireGuidList(Integer type);
    ScoutingListRes scoutingList(ScoutingListReq req);
    ScoutingDto getScoutingById(UUID uid);
    ScoutingDto saveScouting(ScoutingDto req);
    GetUserListRes getUserList(Long externalId);
    void saveUserQuestionnaire(PostUserQuestionnaireReq req);
}
