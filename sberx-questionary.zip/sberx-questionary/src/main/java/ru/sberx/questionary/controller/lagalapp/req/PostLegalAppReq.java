package ru.sberx.questionary.controller.lagalapp.req;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class PostLegalAppReq {

    private Long userId;
    private String locale;
    @NotNull
    private String name;
    @NotNull
    private String phoneNumber;
    @NotNull
    private String email;
    private Long lawService;
    private String lawServiceValue;
    private String problem;
}
