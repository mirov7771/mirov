package ru.sberx.questionary.gate.service.impl;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.dto.guide.guide.req.SearchReq;
import ru.sberx.questionary.controller.dto.support.GuideDto;
import ru.sberx.questionary.controller.dto.support.GuideV2Res;
import ru.sberx.questionary.gate.client.RestGate;
import ru.sberx.questionary.gate.service.GuideService;

@Component
@RequiredArgsConstructor
public class GuideServiceImpl implements GuideService {

    @Value("${application.guide.url}")
    private String url;

    private final RestGate restGate;

    @Override
    public List<GuideDto> getGuidesByNames(List<String> names) {
        Map<String, Object> params = Map.of("name", names);
        return restGate.call(new ParameterizedTypeReference<List<GuideDto>>() {},
                url,
                "/v2/guide",
                params,
                null,
                HttpMethod.GET,
                setHeaders(),
                MediaType.APPLICATION_JSON);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Map<String, Object>> getGuideById(Long id) {
        Map<String, String> headers = new HashMap<>();
        headers.put("requestId", ThreadContext.get("requestId"));
        headers.put("client-id", ThreadContext.get("requestId"));
        return restGate.call(List.class,
                url,
                "/v2/guide?guideId=" + id,
                null,
                HttpMethod.GET,
                headers,
                MediaType.APPLICATION_JSON);
    }

    @Override
    public List<GuideV2Res> getGuidesByIds(List<Long> ids) {
        Map<String, Object> params = Collections
                .singletonMap("guideId", StringUtils.collectionToCommaDelimitedString(ids));
        return restGate.call(new ParameterizedTypeReference<List<GuideV2Res>>() {},
                url,
                "/v2/guide",
                params,
                null,
                HttpMethod.GET,
                setHeaders(),
                MediaType.APPLICATION_JSON);
    }

    @Override
    public List<GuideDto> getGuideByGuideId(Long guideId) {
        Map<String, Object> params = Map.of("guideId", guideId);
        return restGate.call(new ParameterizedTypeReference<List<GuideDto>>() {},
                url,
                "/v2/guide",
                params,
                null,
                HttpMethod.GET,
                setHeaders(),
                MediaType.APPLICATION_JSON);
    }

    @Override
    public void updateSearch(SearchReq req) {
        restGate.call(new ParameterizedTypeReference<Void>() {},
                url,
                "/search",
                null,
                req,
                HttpMethod.PUT,
                setHeaders(),
                MediaType.APPLICATION_JSON);
    }

    private HttpHeaders setHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("requestId", ThreadContext.get("requestId"));
        httpHeaders.set("client-id", ThreadContext.get("client-id"));
        return httpHeaders;
    }

    @Data
    @JsonInclude(Include.NON_NULL)
    public static class GuideValueInfoRes {
        private Long id;
        private Long code;
        private Long guideId;
        private String name;
        private String sysName;
        private String extra;
        private Boolean isDisabled;
        private String logoFile;
        private String icon;
        private Long rang;
    }
}
