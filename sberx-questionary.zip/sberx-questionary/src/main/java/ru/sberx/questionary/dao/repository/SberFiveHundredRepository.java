package ru.sberx.questionary.dao.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.questionary.dao.model.SberFiveHundred;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface SberFiveHundredRepository extends CrudRepository<SberFiveHundred, Long> {

    SberFiveHundred findByQuestionnaireId(Long questionnaireId);

    @Query(value = "delete from SBER_FIVE_HUNDRED where QUESTIONNAIRE_ID = :questionnaireId", nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByQuestionnaireId(Long questionnaireId);

    @Modifying
    @Transactional
    @Query("update SberFiveHundred set questionnaireId = :mainQuestionnaireId where questionnaireId = :childQuestionnaireId")
    void updateMainQuestionnaire(Long mainQuestionnaireId, Long childQuestionnaireId);

    List<SberFiveHundred> findByQuestionnaireIdIn(List<Long> questionnaireId);
}
