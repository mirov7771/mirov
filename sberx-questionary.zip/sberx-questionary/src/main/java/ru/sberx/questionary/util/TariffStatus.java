package ru.sberx.questionary.util;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum TariffStatus {

    INITIAL("initial"),
    DRAFT("draft"),
    ACTIVE("active"),
    ARCHIVE("archive");

    private final String value;
}
