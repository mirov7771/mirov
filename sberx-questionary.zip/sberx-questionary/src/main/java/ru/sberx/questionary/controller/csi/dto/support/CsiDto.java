package ru.sberx.questionary.controller.csi.dto.support;

import lombok.Data;

import java.util.Date;

@Data
public class CsiDto {
    private Long userId;
    private Long questionnaireId;
    private Integer value;
    private Date date;
}
