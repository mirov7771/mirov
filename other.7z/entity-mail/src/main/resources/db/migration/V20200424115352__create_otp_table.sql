CREATE TABLE IF NOT EXISTS T_OTP
(
    otp_id        text PRIMARY KEY,                  -- Идентификатор ОТП
    session       varchar(250)             NOT NULL, -- Пользовательская сессия
    otp_value     varchar(6),                        -- Значение из ОТП
    hash          varchar(128)             NOT NULL, -- Хэш
    date_creation timestamp with time zone NOT NULL, -- Дата создания ОТП
    sign_date     timestamp with time zone,          -- Дата подписания ОТП
    user_id       text                               -- Идентификатор подписавшего пользователя
)
;
