ALTER TABLE T_MESSAGE
    ADD COLUMN IF NOT EXISTS date_time timestamp with time zone NULL;
;
ALTER TABLE T_MESSAGE
    ADD COLUMN IF NOT EXISTS organization_id numeric(38);
;

COMMENT ON COLUMN T_MESSAGE.date_time
    IS 'Дата + время создания документа'
;
COMMENT ON COLUMN T_MESSAGE.organization_id
    IS 'Ид организации'
;
