ALTER TABLE T_FILE
    ALTER COLUMN original_file_name TYPE varchar(255)
;
ALTER TABLE T_FILE
    ALTER COLUMN file_name TYPE varchar(255)
;
ALTER TABLE T_FILE
    ALTER COLUMN type TYPE varchar(100)
;