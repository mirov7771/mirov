CREATE TABLE IF NOT EXISTS T_MESSAGE
(
    id             uuid        NOT NULL DEFAULT uuid_generate_v4(), -- Идентификатор записи
    account_number varchar(20) NOT NULL,                            -- Номер счёта
    topic          varchar(30) NULL,                                -- Тип обращения
    state          varchar(30) NULL,                                -- Текущее состояние
    message        text        NOT NULL                             -- Комментарий
)
;

COMMENT ON TABLE T_MESSAGE
    IS 'Сообщения'
;

COMMENT ON COLUMN T_MESSAGE.id
    IS 'Идентификатор записи'
;

COMMENT ON COLUMN T_MESSAGE.account_number
    IS 'Номер счёта'
;

COMMENT ON COLUMN T_MESSAGE.topic
    IS 'Тип обращения'
;

COMMENT ON COLUMN T_MESSAGE.state
    IS 'Текущее состояние'
;

COMMENT ON COLUMN T_MESSAGE.message
    IS 'Комментарий'
;

ALTER TABLE T_OTP
    ADD COLUMN IF NOT EXISTS message_id uuid NULL
;

COMMENT ON COLUMN T_OTP.message_id
    IS 'Идентификатор сообщения'
;

CREATE TABLE IF NOT EXISTS T_FILE
(
    id                 uuid         NOT NULL DEFAULT uuid_generate_v4(), -- Идентификатор записи
    original_file_name varchar(30)  NOT NULL,                            -- Оригинальное имя файла
    file_name          varchar(30)  NOT NULL,                            -- Имя файла
    size               numeric(20)  NOT NULL,                            -- Размер binary-представления файла в байтах
    type               varchar(30)  NOT NULL,                            -- mime-тип файла
    url                varchar(100) NOT NULL,                            -- url файла на dfs
    message_id         uuid         NULL                                 -- Идентификатор сообщения
)
;

COMMENT ON TABLE T_FILE
    IS 'Файлы'
;

COMMENT ON COLUMN T_FILE.id
    IS 'Идентификатор записи'
;

COMMENT ON COLUMN T_FILE.original_file_name
    IS 'Оригинальное имя файла'
;

COMMENT ON COLUMN T_FILE.file_name
    IS 'Имя файла'
;

COMMENT ON COLUMN T_FILE.size
    IS 'Размер binary-представления файла в байтах'
;

COMMENT ON COLUMN T_FILE.type
    IS 'mime-тип файла'
;

COMMENT ON COLUMN T_FILE.url
    IS 'url файла на dfs'
;

COMMENT ON COLUMN T_FILE.message_id
    IS 'Идентификатор сообщения'
;

CREATE TABLE IF NOT EXISTS T_MESSAGE_FILE
(
    message_id uuid        NOT NULL, -- Идентификатор сообщения
    file_id    numeric(38) NOT NULL  -- Идентификатор файла
)
;

COMMENT ON TABLE T_MESSAGE_FILE
    IS 'Связь сообщений и файлов'
;

COMMENT ON COLUMN T_MESSAGE_FILE.message_id
    IS 'Идентификатор сообщения'
;

COMMENT ON COLUMN T_MESSAGE_FILE.file_id
    IS 'Идентификатор файла'
;