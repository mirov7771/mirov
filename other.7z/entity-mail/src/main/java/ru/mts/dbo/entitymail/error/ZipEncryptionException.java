package ru.mts.dbo.entitymail.error;


import static ru.mts.dbo.entitymail.error.FailureType.ZIP_ENCRYPTION_ERROR;

public class ZipEncryptionException extends DBOException {
    public ZipEncryptionException(FailureType type, String message) {
        super(type, message);
    }

    public ZipEncryptionException(String message) {
        this(ZIP_ENCRYPTION_ERROR, message);
    }

    public ZipEncryptionException() {
        this(ZIP_ENCRYPTION_ERROR.getMessage());
    }
}
