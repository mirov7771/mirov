package ru.mts.dbo.entitymail.controller.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.entitymail.controller.dto.list.ListResponse__1_0;
import ru.mts.dbo.entitymail.controller.dto.presign.PresignRequest__1_0;
import ru.mts.dbo.entitymail.controller.dto.presign.PresignResponse__1_0;
import ru.mts.dbo.entitymail.controller.dto.save.SaveRequest__1_0;
import ru.mts.dbo.entitymail.controller.dto.save.SaveResponse__1_0;
import ru.mts.dbo.entitymail.controller.provider.ListProvider;
import ru.mts.dbo.entitymail.controller.provider.MessageProvider;
import ru.mts.dbo.entitymail.controller.provider.SaveProvider;
import ru.mts.dbo.entitymail.error.CommonInvalidFrontendRequestException;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.util.UUID;

import static org.springframework.util.StringUtils.isEmpty;
import static ru.mts.dbo.entitymail.controller.RestCommons.getResponse;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("message")
@Tag(name = "message", description = "Контроллер для работы с сообщениями")
public class MessageController {

    private final ListProvider listProvider;
    private final SaveProvider saveProvider;
    private final MessageProvider messageProvider;

    private static boolean isUUID(String uuid) {
        try {
            //noinspection ConstantConditions
            return UUID.fromString(uuid) != null;
        } catch (Throwable throwable) {
            return false;
        }
    }

    @PostMapping("1.0/{clientSystemId}/presign")
    @Operation(summary = "Запрос одноразового пароля перед отправкой сообщения v1.0", tags = "1.0")
    public PresignResponse__1_0 presign__1_0(
            @Parameter(
                    description = "Тип клиента (системы, приславшей запрос)",
                    example = "edbo-mobile-ios",
                    required = true
            )
            @PathVariable("clientSystemId") String clientSystemId,
            @Valid @RequestBody PresignRequest__1_0 request
    ) {
        return messageProvider.presign(request);
    }

    @PostMapping(value = "1.0/{clientSystemId}/save", consumes =  "multipart/form-data")
    @Operation(summary = "Запрос на создание сообщения v1.0", tags = "1.0")
    public ResponseEntity<SaveResponse__1_0> save__1_0(
            @Parameter(
                    description = "Тип клиента (системы, приславшей запрос)",
                    example = "edbo-mobile-ios",
                    required = true
            )
            @PathVariable("clientSystemId") String clientSystemId,
            @Valid @ModelAttribute SaveRequest__1_0 request) {

        if (!request.isValid()) {
            throw new CommonInvalidFrontendRequestException();
        }

        return getResponse(saveProvider.save(request));
    }

    @GetMapping("1.0/{clientSystemId}/list")
    @Operation(summary = "Запрос перечня документов 'письмо в банк' v1.0", tags = "1.0")
    public ListResponse__1_0 list__1_0(
            @Parameter(
                    description = "Тип клиента (системы, приславшей запрос)",
                    example = "edbo-mobile-ios",
                    required = true
            )
            @PathVariable("clientSystemId") String clientSystemId,

            @Valid
            @NotNull
            @Parameter(
                    description = "Идинтификатор организации",
                    example = "124",
                    required = true
            )
            @RequestParam BigInteger organizationId,

            @Parameter(
                    description = "Фильтр выборки - ид-р требуемого документа",
                    example = "6be91728-e0ad-4e38-aec1-1b3573ca5422"
            )
            @RequestParam(required = false) String messageId,

            @Parameter(
                    description = "Кол-во документов для выборки, по умолчанию = 10",
                    example = "13"
            )
            @RequestParam(defaultValue = "10", required = false) Integer limit
    ) {
        if (organizationId == null) {
            throw new CommonInvalidFrontendRequestException();
        }

        if (!isEmpty(messageId) && !isUUID(messageId)) {
            throw new CommonInvalidFrontendRequestException();
        }

        return listProvider.list(organizationId, messageId, limit);
    }
}
