package ru.mts.dbo.entitymail.error;

public class EntityNotFoundException extends DBOException {
    public EntityNotFoundException() {
        super(FailureType.ENTITY_NOT_FOUND);
    }
}
