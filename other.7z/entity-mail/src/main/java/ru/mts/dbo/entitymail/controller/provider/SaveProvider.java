package ru.mts.dbo.entitymail.controller.provider;

import com.ibm.icu.text.Transliterator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveInputStream;
import org.apache.tika.Tika;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import ru.mts.dbo.entitymail.connector.kafka.AccountInfoKafkaConnector;
import ru.mts.dbo.entitymail.connector.otp.OtpConnector;
import ru.mts.dbo.entitymail.controller.dto.save.SaveRequest__1_0;
import ru.mts.dbo.entitymail.controller.dto.save.SaveResponse__1_0;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoRequest;
import ru.mts.dbo.entitymail.error.*;
import ru.mts.dbo.entitymail.model.DbFile;
import ru.mts.dbo.entitymail.model.DbMessage;
import ru.mts.dbo.entitymail.model.MimeType;
import ru.mts.dbo.entitymail.model.State;
import ru.mts.dbo.entitymail.service.MessageService;
import ru.mts.dbo.entitymail.service.OtpService;
import ru.mts.dbo.entitymail.service.SendService;
import ru.mts.dbo.entitymail.service.StorageService;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.StringJoiner;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.time.temporal.ChronoUnit.SECONDS;


@Slf4j
@Component
@RequiredArgsConstructor
public class SaveProvider {

    private final OtpService otpService;
    private final StorageService storageService;
    private final SendService sendService;
    private final OtpConnector otpConnector;
    private final MessageService messageService;
    private final AccountInfoKafkaConnector accountInfoKafkaConnector;

    private static final int MAX_SIZE_FILES_30_MB = 31457280;
    private static final int MAX_SIZE_FILE_10_MB = 10485760;

    public SaveResponse__1_0 save(SaveRequest__1_0 request) {
        final var accountNumber = request.getAccountNumber();

        final var otp = otpService.getOtp(request.getOtpId());

        if (otp.isEmpty()) {
            throw new EntityNotFoundException();
        }

        final var response = accountInfoKafkaConnector.getData(new AccountInfoRequest().setAccountNumber(accountNumber));

        if (response.getErrorCode() != 0 || response.getErrorMessage() != null) {
            throw new GenericDBOException(response.getErrorCode(), response.getErrorMessage());
        }

        final var attachment = !CollectionUtils.isEmpty(request.getAttachments());

        final var timestamp = otp.get().getDateCreation().truncatedTo(SECONDS);
        otpConnector.validatePassword(attachment ? request.hash(response.getOrganizationId()) : null, request.getOtpId(), timestamp, request.getPwd());

        if (attachment) {
            checkCountAttachment(request.getAttachments());
        }

        var dbMessage = saveMessage(request, response.getOrganizationId());

        List<DbFile> files = Collections.emptyList();

        if (attachment) {
            files = getFiles(request.getAttachments(), dbMessage);
            checkSizeFiles(files, dbMessage);

            files = addInnForName(files, response.getInn());

            try {
                files = storageService.addFiles(files, dbMessage.getId());
            } catch (IOException e) {
                log.error("File storage save error", e);
                messageService.save(dbMessage.setState(State.ERROR_SEND));
                storageService.removeFiles(files);
                throw new StorageIOException();
            }
            dbMessage = messageService.save(dbMessage.setFiles(files));
        }

        String branchId = response.getBranchId();
        try {
            sendService.sendEmail(dbMessage.getTopic(), dbMessage.getMessage(), files, branchId);
        } catch (Exception e) {
            log.error("Generation email message error", e);
            messageService.save(dbMessage.setState(State.ERROR_SEND));
            storageService.removeFiles(files);
            throw new DboResourceAccessException("Generation email message error");
        }

        messageService.save(dbMessage.setState(State.SENT));
        return new SaveResponse__1_0().setId(dbMessage.getId());
    }

    public DbMessage saveMessage(SaveRequest__1_0 request, BigInteger organizationId) {
        var dbMessage = new DbMessage().setMessage(request.getMessage())
                .setAccountNumber(request.getAccountNumber())
                .setOrganizationId(organizationId)
                .setTopic(request.getTopicId())
                .setState(State.DRAFT);
        return messageService.save(dbMessage);
    }

    private List<DbFile> getFiles(List<MultipartFile> attachments, DbMessage message) {
        AtomicInteger count = new AtomicInteger();

        return attachments.stream()
                .map(attachment -> {
                    byte[] file;
                    try {
                        file = attachment.getBytes();
                    } catch (IOException e) {
                        log.error("IO error", e);
                        messageService.save(message.setState(State.ERROR_SEND));
                        throw new CommonInvalidFrontendRequestException();
                    }
                    checkMimeType(file, attachment.getOriginalFilename(), message);
                    count.getAndIncrement();
                    return new DbFile().setMessage(message)
                            .setOriginalFileName(attachment.getOriginalFilename())
                            .setFileName(renameFile(attachment.getOriginalFilename(), count.toString(), attachment.getContentType()))
                            .setSize(attachment.getSize())
                            .setType(attachment.getContentType())
                            .setData(file);
                }).collect(Collectors.toList());
    }

    private void checkMimeType(byte[] file, String name, DbMessage message) {
        try {
            var mime = new Tika().detect(new ByteArrayInputStream(file), name);

            if (Stream.of(MimeType.values()).noneMatch(e -> e.getMimeType().equals(mime))) {
                throw new MimeTypeInvalidException();
            }
            if (mime.equals(MimeType.ZIP.getMimeType())) {
                checkZipFile(file, message);
            }
        } catch (IOException e) {
            log.error("File Validation Error", e);
            throw new MimeTypeInvalidException();
        }
    }

    private void checkSizeFiles(List<DbFile> files, DbMessage message) {
        Integer sizeInKbSum = files.stream()
                .mapToInt(attachment -> checkSizeFile(attachment.getData()))
                .sum();
        if (sizeInKbSum > MAX_SIZE_FILES_30_MB) {
            messageService.save(message.setState(State.ERROR_SEND));
            throw new SizeFileInvalidException();
        }
    }

    private Integer checkSizeFile(byte[] file) {
        Integer sizeByte = file.length;

        if (sizeByte > MAX_SIZE_FILE_10_MB || sizeByte == 0) {
            throw new SizeFileInvalidException();
        }
        return sizeByte;
    }

    private void checkCountAttachment(List<MultipartFile> attachments) {
        if (attachments.size() > 30) {
            throw new SizeFileInvalidException();
        }
    }

    private void checkZipFile(byte[] zipFile, DbMessage message) throws IOException {
        InputStream is = new ByteArrayInputStream(zipFile);
        ZipArchiveInputStream zis = new ZipArchiveInputStream(is);
        ZipArchiveEntry zipArchiveEntry = zis.getNextZipEntry();
        if (zipArchiveEntry == null) {
            messageService.save(message.setState(State.ERROR_SEND));
            throw new SizeFileInvalidException();
        }
        if (zipArchiveEntry.getGeneralPurposeBit().usesEncryption()) {
            messageService.save(message.setState(State.ERROR_SEND));
            throw new ZipEncryptionException();
        }
    }

    private String renameFile(String name, String num, String mime) {
        final var CYRILLIC_TO_LATIN = "Russian-Latin/BGN";
        Transliterator toLatinTrans = Transliterator.getInstance(CYRILLIC_TO_LATIN);
        String pattern = "[~@#%^&\\\\|/?:,.`{}\"'<>]";

        return new StringJoiner("_")
                .add(num)
                .add(toLatinTrans.transliterate(removeType(name))
                        .replaceAll("_+", "_")
                        .replaceAll("\\s+", "_")
                        .replaceAll(pattern, "_"))
                .toString() + getFileType(mime);
    }

    private List<DbFile> addInnForName(List<DbFile> files, String inn) {
        return files.stream().map(file ->
                file.setFileName(inn + "_" + file.getFileName()))
                .collect(Collectors.toList());
    }

    private String removeType(String name) {
        String[] nameArray = name.split("\\.");
        if (nameArray.length == 1) {
            return nameArray[0];
        }
        nameArray[nameArray.length - 1] = "";
        return String.join("", nameArray);
    }

    private String getFileType(String type) {
        return Arrays.stream(MimeType.values()).filter(value -> value.getMimeType().equals(type)).findFirst()
                .map(mimeType -> "." + mimeType.getDescription()).orElse("");
    }
}
