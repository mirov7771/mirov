package ru.mts.dbo.entitymail.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.User;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;

import static java.util.Optional.ofNullable;
import static ru.mts.dbo.entitymail.controller.RestCommons.BEARER_PART_NAME;
import static ru.mts.dbo.entitymail.controller.RestCommons.TOKEN_HEADER_NAME;

@Slf4j
@RequiredArgsConstructor
public class TokenFilter extends OncePerRequestFilter {
    private final ObjectMapper objectMapper;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        ofNullable(request.getHeader(TOKEN_HEADER_NAME))
                .map(header -> header.substring(BEARER_PART_NAME.length()))
                .map(String::strip)
                .filter(StringUtils::isNotEmpty)
                .map(token -> {
                    try {
                        final var publicTokenPart = token.substring(token.lastIndexOf('.') + 1);
                        return Base64.getUrlDecoder().decode(publicTokenPart);
                    } catch (Exception e) {
                        log.error("{} in request {}", e.getLocalizedMessage(), Context.getRequestId());
                        return null;
                    }
                })
                .map(String::new)
                .ifPresentOrElse(
                        token -> {
                            try {
                                Context.setUserData(objectMapper.readValue(token, User.class));
                                MDC.put("X-Session", Context.getSessionId());
                                MDC.put("X-Token", objectMapper.writeValueAsString(Context.getUserData()));
                            } catch (IOException e) {
                                log.error("Cannot read token model from token {}", token);
                            }
                        },
                        () -> log.error("No token found in request {}", Context.getRequestId())
                );

        filterChain.doFilter(request, response);
    }
}
