package ru.mts.dbo.entitymail.dto.kafka.base;

import lombok.Data;

@Data
public class BaseResponse {

    private int errorCode;

    private String errorMessage;
}
