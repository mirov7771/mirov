package ru.mts.dbo.entitymail.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.mts.dbo.entitymail.model.DbOtp;

public interface OtpRepository extends JpaRepository<DbOtp, String> {
}
