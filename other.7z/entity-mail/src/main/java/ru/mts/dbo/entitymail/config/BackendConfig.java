package ru.mts.dbo.entitymail.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.entitymail.backend.bank.service.MqRestApi;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import java.nio.charset.Charset;
import java.util.stream.IntStream;

import static java.nio.charset.StandardCharsets.UTF_8;

@Slf4j
@Configuration
public class BackendConfig {

    @Bean
    public MqRestApi mqRestApi() {
        return new MqRestApi(mqRestTemplate());
    }

    @Bean
    public RestTemplate mqRestTemplate() {
        final var factory = new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory());
        final var restTemplate = new RestTemplate(factory);
        final var messageConverters = restTemplate.getMessageConverters();
        final int index = IntStream.range(0, messageConverters.size()).boxed()
                .filter(i -> messageConverters.get(i) instanceof StringHttpMessageConverter)
                .findFirst().orElseThrow(IllegalStateException::new);
        messageConverters.set(index, new StringHttpMessageConverter(UTF_8));

        restTemplate.getInterceptors().add((request, body, execution) -> {
            if (log.isTraceEnabled()) {
                log.trace("RestTemplate request {} with body: {}", request.getMethodValue() + " " + request.getURI(), new String(body, Charset.defaultCharset()));
            } else if (log.isDebugEnabled()) {
                log.debug("RestTemplate request {}", request.getMethodValue() + " " + request.getURI());
            }
            final var response = execution.execute(request, body);
            if (log.isTraceEnabled()) {
                log.trace("RestTemplate response {} with body: {}", response.getStatusCode(), StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()));
            } else if (log.isDebugEnabled()) {
                log.debug("RestTemplate response {}", response.getStatusCode());
            }
            return response;
        });

        return restTemplate;
    }

    @Bean
    public DatatypeFactory xmlDataTypeFactory() throws DatatypeConfigurationException {
        return DatatypeFactory.newInstance();
    }

}
