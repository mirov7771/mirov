package ru.mts.dbo.entitymail.backend.bank.error;

import lombok.Data;
import ru.mts.dbo.entitymail.error.FailureType;

@Data
public class BackendRejectionException extends RequestProcessingException {
    private final String statusCode;
    private final String severity;
    private final String statusDesc;

    public BackendRejectionException(String statusCode, String severity, String statusDesc) {
        super(FailureType.BACKEND_REJECTION);
        this.statusCode = statusCode;
        this.severity = severity;
        this.statusDesc = statusDesc;
    }

    @Override
    public String getClientMessage() {
        return this.statusDesc;
    }

    @Override
    public String getMessage() {
        return String.format("StatusCode=%s, Severity=%s, StatusDesc=%s", statusCode, severity, statusDesc);
    }
}
