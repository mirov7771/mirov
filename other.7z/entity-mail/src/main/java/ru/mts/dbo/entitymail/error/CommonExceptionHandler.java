package ru.mts.dbo.entitymail.error;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import ru.mts.dbo.entitymail.controller.dto.base.BaseResponse;

import javax.persistence.EntityNotFoundException;

import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.joining;
import static ru.mts.dbo.entitymail.Context.getRequestId;
import static ru.mts.dbo.entitymail.controller.RestCommons.getErrorResponse;
import static ru.mts.dbo.entitymail.controller.RestCommons.getResponse;
import static ru.mts.dbo.entitymail.controller.dto.base.BaseResponse.error;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CommonExceptionHandler {

    @SneakyThrows
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<BaseResponse> handleValidationException(MethodArgumentNotValidException ex) {
        final var errorMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(joining(", "));
        log.error(errorMessage, ex);
        return getResponse(error(FailureType.INVALID_FRONTEND_REQUEST.getCode(), errorMessage));
    }

    @SneakyThrows
    @ExceptionHandler({BindException.class})
    public ResponseEntity<BaseResponse> handleValidationBindException(BindException ex) {
        final var errorMessage = ex.getBindingResult().getFieldErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(joining(", "));
        log.error(errorMessage, ex);
        return getResponse(error(FailureType.INVALID_FRONTEND_REQUEST.getCode(), errorMessage));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<BaseResponse> handleInvalidRequestException(HttpMessageNotReadableException ex) {
        log.error("Invalid JSON in request " + getRequestId(), ex);

        return getErrorResponse(FailureType.INVALID_FRONTEND_REQUEST.getCode(), "Unreadable JSON (ノಠ益ಠ)ノ彡┻━┻");
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<BaseResponse> handleMissingHeaderException(MissingRequestHeaderException ex) {
        log.error("Missing header in request " + getRequestId(), ex);

        return getErrorResponse(FailureType.INVALID_FRONTEND_REQUEST.getCode(),
                "Missing required HTTP header: " + ex.getHeaderName());
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<BaseResponse> handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException ex) {
        final String errorMessage = ex.getMessage() + " (request " + getRequestId() + ")";
        log.error(errorMessage, ex);

        return getErrorResponse(FailureType.UNEXPECTED_ERROR.getCode(), errorMessage);
    }

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity<BaseResponse> handleEntityNotFoundException(EntityNotFoundException ex) {
        final var errorMessage = ofNullable(ex.getLocalizedMessage()).orElse("Сущность не найдена")
                + " (request " + getRequestId() + ")";
        log.error(errorMessage, ex);

        return getErrorResponse(FailureType.ENTITY_NOT_FOUND.getCode(), FailureType.ENTITY_NOT_FOUND.getMessage());
    }

    @SneakyThrows
    @ExceptionHandler(DBOException.class)
    public ResponseEntity<BaseResponse> handleDBOException(DBOException ex) {
        log.error(ex.getLogMessage(), ex);
        return getErrorResponse(ex.getType().getCode(), ex.getClientMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<BaseResponse> handleUnexpectedErrorException(Exception ex) {
        final String logMessage = "Internal error in request " + getRequestId() + ", contact service administrator: " + ex.getMessage();
        log.error(logMessage, ex);

        final var responseMessage = "Unexpected error in request " + getRequestId() + "; contact service administrator";
        return getErrorResponse(FailureType.UNEXPECTED_ERROR.getCode(), responseMessage);
    }
}
