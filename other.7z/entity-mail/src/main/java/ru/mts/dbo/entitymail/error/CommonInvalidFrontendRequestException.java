package ru.mts.dbo.entitymail.error;


import static ru.mts.dbo.entitymail.error.FailureType.INVALID_FRONTEND_REQUEST;

public class CommonInvalidFrontendRequestException extends DBOException {
    public CommonInvalidFrontendRequestException(FailureType type, String message) {
        super(type, message);
    }

    public CommonInvalidFrontendRequestException(String message) {
        this(INVALID_FRONTEND_REQUEST, message);
    }

    public CommonInvalidFrontendRequestException() {
        this(INVALID_FRONTEND_REQUEST.getMessage());
    }
}
