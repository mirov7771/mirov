package ru.mts.dbo.entitymail.error;

import java.util.Arrays;

public class GenericDBOException extends DBOException {
    public GenericDBOException(int errorCode, String message) {
        super(findFailureType(errorCode), message);
    }

    private static FailureType findFailureType(int errorCode) {
        return Arrays.stream(FailureType.values())
                .filter(failure -> failure.getCode() == errorCode)
                .findFirst()
                .orElse(FailureType.UNEXPECTED_ERROR);
    }
}
