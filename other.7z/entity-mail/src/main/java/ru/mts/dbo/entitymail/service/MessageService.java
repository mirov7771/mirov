package ru.mts.dbo.entitymail.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.mts.dbo.entitymail.model.DbMessage;
import ru.mts.dbo.entitymail.repo.MessageRepository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.springframework.data.domain.PageRequest.of;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class MessageService {
    private final MessageRepository messageRepository;

    public DbMessage save(final DbMessage message) {
        return messageRepository.save(message);
    }

    public Optional<DbMessage> findMessage(UUID id) {
        return messageRepository.findById(id);
    }

    public List<DbMessage> getDbMessageForOrganizationId(BigInteger organizationId, Integer limit) {
        return messageRepository.findDbMessageByOrganizationIdOrderByDateTimeDesc(organizationId, of(0, limit));
    }
}
