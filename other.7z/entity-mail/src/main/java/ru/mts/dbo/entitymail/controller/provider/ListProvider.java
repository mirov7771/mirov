package ru.mts.dbo.entitymail.controller.provider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.mts.dbo.entitymail.controller.dto.list.ListResponse__1_0;
import ru.mts.dbo.entitymail.error.EntityNotFoundException;
import ru.mts.dbo.entitymail.service.MessageService;
import ru.mts.dbo.entitymail.utils.SecurityUtils;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


@Slf4j
@Component
@RequiredArgsConstructor
public class ListProvider {

    private final MessageService messageService;

    public ListResponse__1_0 list(BigInteger organizationId, String messageId, Integer limit) {
        SecurityUtils.checkContextOrganizationId(organizationId);

        if (StringUtils.isNotEmpty(messageId)) {
            final var id = UUID.fromString(messageId);
            final var message = messageService.findMessage(id)
                    .filter(msg -> msg.getOrganizationId().equals(organizationId))
                    .orElseThrow(EntityNotFoundException::new);

            final var responseMessage = new ListResponse__1_0.Message()
                    .setMessageId(id)
                    .setMessage(message.getMessage())
                    .setSubject(message.getTopic().getTitle())
                    .setDatetime(message.getDateTime())
                    .setAttach(message.getFiles() != null ? message.getFiles().size() : null);
            return new ListResponse__1_0().setMessageList(List.of(responseMessage));
        }

        final var messages = messageService.getDbMessageForOrganizationId(organizationId, limit);
        return new ListResponse__1_0(messages.stream()
                .map(message ->
                        new ListResponse__1_0.Message()
                                .setMessageId(message.getId())
                                .setMessage(message.getMessage())
                                .setSubject(message.getTopic().getTitle())
                                .setDatetime(message.getDateTime())
                                .setAttach(message.getFiles() != null ? message.getFiles().size() : null)
                )
                .collect(Collectors.toList()));
    }
}
