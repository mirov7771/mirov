package ru.mts.dbo.entitymail.backend.bank.error;

import ru.mts.dbo.entitymail.error.FailureType;

import java.util.concurrent.TimeUnit;

public class MqRestTimeoutException extends RequestProcessingException {
    public MqRestTimeoutException(long timeoutMs) {
        super(
                FailureType.BACKEND_TIMEOUT,
                String.format("Backend has not responded in %d seconds", TimeUnit.MILLISECONDS.toSeconds(timeoutMs))
        );
    }
}
