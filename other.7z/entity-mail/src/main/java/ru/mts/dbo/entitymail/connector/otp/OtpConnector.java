package ru.mts.dbo.entitymail.connector.otp;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.error.SignInvalidPasswordException;

import java.time.ZonedDateTime;
import java.util.UUID;

import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_FORM_URLENCODED;
import static ru.mts.dbo.entitymail.controller.RestCommons.REQUEST_ID_HTTP_HEADER;

@Slf4j
@Component
@RequiredArgsConstructor
public class OtpConnector {
    private final RestTemplate restTemplate;
    private final OtpProperties otpProperties;

    public PreSignResultDto sendOtp(String messageHash, ZonedDateTime timestamp) {
        log.debug("Отправка ОТП для сообщения за дату {}", timestamp);
        final var headers = new HttpHeaders();
        headers.setContentType(APPLICATION_FORM_URLENCODED);
        headers.set(REQUEST_ID_HTTP_HEADER, Context.getRequestId());

        final var request = new LinkedMultiValueMap<String, String>();
        request.add("user_id", Context.getUserData().getUserId());
        request.add("timestamp", String.valueOf(timestamp.toEpochSecond()));
        request.add("document", messageHash);
        request.add("session_id", Context.getSessionId());
        request.add("text_sms", otpProperties.getService().getText());

        ResponseEntity<SignRequestResponseDto> signRequestResponse;
        try {
            signRequestResponse = restTemplate.postForEntity(
                    otpProperties.getService().getSignUrl(),
                    new HttpEntity<>(request, headers),
                    SignRequestResponseDto.class
            );
        } catch (Exception e) {
            if (!otpProperties.isDebug()) {
                throw e;
            } else {
                final var mockBody = new SignRequestResponseDto()
                        .setOtpId(UUID.randomUUID().toString())
                        .setPhone(RandomStringUtils.randomNumeric(4));
                signRequestResponse = new ResponseEntity<>(mockBody, HttpStatus.OK);
                log.debug("Отправка ОТП {} в DEBUG режиме", mockBody.getOtpId());
            }
        }
        if (signRequestResponse.getBody() == null) {
            throw new IllegalStateException();
        }
        log.debug("Запрос на отправку ОТП выполнен");

        final var body = signRequestResponse.getBody();

        final var result = new PreSignResultDto();
        result.setOtpId(body.getOtpId());
        result.setPhone(body.getPhone());
        return result;
    }

    public void validatePassword(String messageHash, String otpId, ZonedDateTime timestamp, String otpPwd) {
        log.debug("Запрос на проверку ОТП для подписи {} за дату {}", otpId, timestamp);
        if (otpProperties.isDebug() && "1234".equals(otpPwd)) {
            log.debug("Подписано в DEBUG режиме подписью 1234");
            return;
        }

        final var headers = new HttpHeaders();
        final var uriVariables = new LinkedMultiValueMap<String, String>();
        uriVariables.add("user_id", Context.getUserData().getUserId());
        uriVariables.add("otp_id", String.valueOf(otpId));
        uriVariables.add("document", messageHash);
        uriVariables.add("timestamp", String.valueOf(timestamp.toEpochSecond()));
        uriVariables.add("session_id", Context.getSessionId());
        uriVariables.add("code", otpPwd);

        try {
            final var checkUrl = otpProperties.getService().getCheckUrl();
            final var url = UriComponentsBuilder.fromHttpUrl(checkUrl).queryParams(uriVariables).toUriString();
            final var checkRequestResponse = restTemplate.exchange(url, GET, new HttpEntity<>(headers), SignCheckRequestResponseDto.class, uriVariables);
            final var body = checkRequestResponse.getBody();

            if (body != null && body.getResult()) {
                log.debug("Проверка подписи ОТП в DEBUG режиме {} успешна", otpId);
            } else {
                throw new SignInvalidPasswordException();
            }
        } catch (Exception e) {
            log.error("Ошибка при проверке ОТП: " + e.getLocalizedMessage(), e);
            throw e;
        }
        log.debug("Код ОТП {} успешно проверен", otpId);
    }
}
