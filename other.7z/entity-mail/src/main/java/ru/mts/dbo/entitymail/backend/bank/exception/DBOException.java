package ru.mts.dbo.entitymail.backend.bank.exception;

import lombok.Data;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.error.FailureType;

import java.util.Map;

@Data
public abstract class DBOException extends RuntimeException {
    private FailureType type;
    private String passedMessage;

    public DBOException(FailureType type) {
        this(type, type.getMessage());
    }

    public DBOException(FailureType type, String message) {
        super(message);
        this.type = type;
        this.passedMessage = message;
    }

    /**
     * @return Текст ошибки, отправляемый клиенту
     */
    public String getClientMessage() {
        return passedMessage != null ? passedMessage : getType().getMessage();
    }

    /**
     * @return Расширенный текст ошибки, записываемый в лог
     */
    public String getLogMessage() {
        final var ctx = Map.of(
                "sessionId", Context.getSessionId(),
                "requestId", Context.getRequestId(),
                "clientSystemId", Context.getClientSystemId(),
                "userData", Context.getUserData()
        );
        return getClientMessage() + " (context " + ctx + ")";
    }
}
