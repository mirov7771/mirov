package ru.mts.dbo.entitymail.controller.dto.save;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.mts.dbo.entitymail.controller.dto.base.BaseResponse;

import java.util.UUID;

@Data
@Schema(description = "Ответ на создание документа")
public class SaveResponse__1_0 extends BaseResponse {

    @Schema(title = "Идентификатор документа", example = "6be91728-e0ad-4e38-aec1-1b3573ca5421", required = true)
    private UUID id;
}
