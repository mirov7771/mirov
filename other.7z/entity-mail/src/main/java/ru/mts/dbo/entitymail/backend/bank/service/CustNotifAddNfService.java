package ru.mts.dbo.entitymail.backend.bank.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.entitymail.backend.dto.CustNotifAddNf;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustNotifAddNfService extends AbstractFDXOperation<CustNotifAddNf> {

    private final BackendCustNotifAddNfProperties backendCustNotifAddNfProperties;

    @Override
    protected String getMessageType() {
        return backendCustNotifAddNfProperties.getMessageType();
    }

    @Override
    protected String getRequestSender() {
        return backendCustNotifAddNfProperties.getRequestSender();
    }

    @Override
    protected String getRequestReceiver() {
        return backendCustNotifAddNfProperties.getRequestReceiver();
    }

    @Override
    protected String getExtendedMessageType() {
        return backendCustNotifAddNfProperties.getExtendedMessageType();
    }

    @Override
    protected String getBusinessProcessId() {
        return backendCustNotifAddNfProperties.getBusinessProcessId();
    }

    @Override
    protected String getUsername() {
        return backendCustNotifAddNfProperties.getUsername();
    }

    @Override
    protected String getPassword() {
        return backendCustNotifAddNfProperties.getPassword();
    }

    @Override
    protected Long getTimeout() {
        return backendCustNotifAddNfProperties.getTimeout();
    }

    @Override
    protected String getRequestQueueUrl() {
        return backendCustNotifAddNfProperties.getRequestQueueUrl();
    }

    @Override
    protected String getResponseQueueUrl() {
        return backendCustNotifAddNfProperties.getResponseQueueUrl();
    }
}
