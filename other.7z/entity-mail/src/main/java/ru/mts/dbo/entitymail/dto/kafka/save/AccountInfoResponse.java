package ru.mts.dbo.entitymail.dto.kafka.save;

import lombok.Data;
import ru.mts.dbo.entitymail.dto.kafka.base.BaseResponse;

import java.math.BigInteger;

@Data
public class AccountInfoResponse extends BaseResponse {

    private String inn;

    private String branchId;

    private BigInteger organizationId;
}
