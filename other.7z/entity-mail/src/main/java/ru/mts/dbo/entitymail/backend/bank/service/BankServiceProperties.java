package ru.mts.dbo.entitymail.backend.bank.service;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;

@Getter
@Setter
@ToString(callSuper = true)
public abstract class BankServiceProperties {
    @NotNull
    private String messageType;

    @NotNull
    private String requestSender;

    @NotNull
    private String requestReceiver;

    private String extendedMessageType;

    @NotNull
    private String businessProcessId;

    @NotNull
    private String username;

    @NotNull
    private String password;

    @NotNull
    private Long timeout;

    @NotNull
    private String requestQueueUrl;

    @NotNull
    private String responseQueueUrl;
}
