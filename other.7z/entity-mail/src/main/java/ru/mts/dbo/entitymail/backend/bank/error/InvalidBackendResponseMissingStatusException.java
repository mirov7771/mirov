package ru.mts.dbo.entitymail.backend.bank.error;

public class InvalidBackendResponseMissingStatusException extends InvalidBackendResponseException {
    private static final String DEFAULT = "Missing Status in the bank response.";

    public InvalidBackendResponseMissingStatusException() {
        super(DEFAULT);
    }
}
