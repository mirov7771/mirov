package ru.mts.dbo.entitymail.backend.bank.error;

import ru.mts.dbo.entitymail.error.DBOException;
import ru.mts.dbo.entitymail.error.FailureType;

public abstract class RequestProcessingException extends DBOException {

    RequestProcessingException(FailureType type) {
        super(type);
    }

    RequestProcessingException(FailureType type, String message) {
        super(type, message);
    }
}
