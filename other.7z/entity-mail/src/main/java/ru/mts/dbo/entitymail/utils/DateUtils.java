package ru.mts.dbo.entitymail.utils;

import lombok.experimental.UtilityClass;
import org.jetbrains.annotations.NotNull;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@UtilityClass
public final class DateUtils {
    public static final ZoneId MOSCOW_ZONE = ZoneId.of("Europe/Moscow");

    @NotNull
    public static ZonedDateTime localDateToZonedDateTime(@NotNull LocalDate ld) {
        return ld.atStartOfDay(MOSCOW_ZONE);
    }

    @NotNull
    public static LocalDate zonedDateTimeToLocalDate(@NotNull ZonedDateTime zdt) {
        ZonedDateTime moscowZoned = zdt.withZoneSameInstant(MOSCOW_ZONE);
        return moscowZoned.toLocalDate();
    }

    @NotNull
    public static LocalDateTime zonedDateTimeToLocalDateTime(@NotNull ZonedDateTime zdt) {
        ZonedDateTime moscowZoned = zdt.withZoneSameInstant(MOSCOW_ZONE);
        return moscowZoned.toLocalDateTime();
    }

    public static ZonedDateTime now() {
        return ZonedDateTime.now(MOSCOW_ZONE);
    }
}
