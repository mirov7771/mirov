package ru.mts.dbo.entitymail.backend.bank.util;


public final class FDXTypeConverter {
    public static final String BANK_RESPONSE_SUCCESS_STATE = "0";

    private FDXTypeConverter() {
    }

}
