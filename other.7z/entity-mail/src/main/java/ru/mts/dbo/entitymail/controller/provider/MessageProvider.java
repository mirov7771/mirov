package ru.mts.dbo.entitymail.controller.provider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.entitymail.connector.otp.OtpConnector;
import ru.mts.dbo.entitymail.controller.dto.presign.PresignRequest__1_0;
import ru.mts.dbo.entitymail.controller.dto.presign.PresignResponse__1_0;
import ru.mts.dbo.entitymail.model.DbOtp;
import ru.mts.dbo.entitymail.service.OtpService;
import ru.mts.dbo.entitymail.utils.DateUtils;
import ru.mts.dbo.entitymail.utils.SecurityUtils;

@Slf4j
@Component
@RequiredArgsConstructor
public class MessageProvider {
    private final OtpService otpService;
    private final OtpConnector otpConnector;

    public PresignResponse__1_0 presign(final PresignRequest__1_0 request) {
        SecurityUtils.checkContextOrganizationId(request.getOrganizationId());

        final var dateTime = DateUtils.now();

        final var preSignResultDto = otpConnector.sendOtp(request.getMessageHash(), dateTime);

        final var otp = new DbOtp()
                .setHash(request.getMessageHash())
                .setOtpId(preSignResultDto.getOtpId())
                .setOtpValue(null);// еще нет
        final var savedOtp = otpService.save(otp);
        log.info("Сохранен запрос ОТП: {}", savedOtp);

        return new PresignResponse__1_0(new PresignResponse__1_0.Presign(
                preSignResultDto.getOtpId(),
                preSignResultDto.getSmsNum(),
                preSignResultDto.getPhone()
        ));
    }
}
