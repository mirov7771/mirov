package ru.mts.dbo.entitymail.backend.bank.service;

import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.backend.bank.error.BackendRejectionException;
import ru.mts.dbo.entitymail.backend.bank.error.InvalidBackendResponseMissingStatusException;
import ru.mts.dbo.entitymail.backend.bank.util.FDXTypeConverter;
import ru.mts.dbo.entitymail.backend.dto.ServerInfoType;
import ru.mts.dbo.entitymail.backend.dto.Status;

import java.time.LocalDateTime;
import java.util.UUID;

public abstract class AbstractFDXOperation<I> extends AbstractBankOperation<I> {

    public ServerInfoType fillServerInfo() {
        ServerInfoType serverInfoType = new ServerInfoType();
        serverInfoType.setMsgUID(UUID.randomUUID().toString());
        serverInfoType.setRqUID(Context.getRequestId());
        serverInfoType.setSPName(getRequestSender());
        serverInfoType.setMsgType(getMessageType());
        serverInfoType.setExtMsgType(getExtendedMessageType());
        serverInfoType.setMsgReceiver(getRequestReceiver());
        serverInfoType.setServerDt(convertToXMLDateTime(LocalDateTime.now()));
        serverInfoType.setBpId(getBusinessProcessId());
        return serverInfoType;
    }

    public void checkBackendRejection(Status state) {
        if (state == null) {
            throw new InvalidBackendResponseMissingStatusException();
        }
        if (!checkBackendRejectionIsSuccess(state)) {
            throw new BackendRejectionException(state.getStatusCode(), state.getSeverity(), state.getStatusDesc());
        }
    }

    public boolean checkBackendRejectionIsSuccess(Status state) {
        return FDXTypeConverter.BANK_RESPONSE_SUCCESS_STATE.equals(state.getStatusCode());
    }
}
