package ru.mts.dbo.entitymail.controller.provider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.entitymail.controller.dto.topics.TopicsResponse__1_0;
import ru.mts.dbo.entitymail.model.Topics;

import java.util.Arrays;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class TopicsProvider {
    public TopicsResponse__1_0 list() {
        final var topics = Arrays.stream(Topics.values())
                .map(topic -> new TopicsResponse__1_0.Topic(
                        topic.name(),
                        topic.getTitle(),
                        topic.getDescription()
                ))
                .collect(Collectors.toList());
        return new TopicsResponse__1_0(topics);
    }
}
