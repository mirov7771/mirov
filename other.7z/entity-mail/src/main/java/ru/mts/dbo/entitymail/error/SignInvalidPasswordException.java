package ru.mts.dbo.entitymail.error;

public class SignInvalidPasswordException extends DBOException {
    public SignInvalidPasswordException() {
        super(FailureType.DOCUMENT_SIGN_PASSWORD_INVALID);
    }
}
