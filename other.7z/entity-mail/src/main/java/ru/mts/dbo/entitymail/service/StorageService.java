package ru.mts.dbo.entitymail.service;

import com.hierynomus.msdtyp.AccessMask;
import com.hierynomus.msfscc.FileAttributes;
import com.hierynomus.mssmb2.SMB2CreateDisposition;
import com.hierynomus.mssmb2.SMB2CreateOptions;
import com.hierynomus.mssmb2.SMB2ShareAccess;
import com.hierynomus.smbj.SMBClient;
import com.hierynomus.smbj.auth.AuthenticationContext;
import com.hierynomus.smbj.connection.Connection;
import com.hierynomus.smbj.session.Session;
import com.hierynomus.smbj.share.DiskShare;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;
import ru.mts.dbo.entitymail.model.DbFile;
import ru.mts.dbo.entitymail.utils.DateUtils;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

import static java.util.EnumSet.of;


@Slf4j
@Service
@RequiredArgsConstructor
@EnableConfigurationProperties(StorageProperties.class)
public class StorageService {

    private final StorageProperties properties;

    public List<DbFile> addFiles(List<DbFile> files, UUID messageId) throws IOException {
        for (DbFile file : files) {
            final var url = addFile(file.getData(), file.getFileName(), messageId);
            file.setUrl(url);
        }
        return files;
    }

    private String addFile(byte[] file, String filename, UUID messageId) throws IOException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
        String date = formatter.format(LocalDate.now(DateUtils.MOSCOW_ZONE));

        SMBClient client = new SMBClient();
        try (Connection connection = client.connect(properties.getServer())) {
            AuthenticationContext ac = AuthenticationContext.anonymous();
            Session session = connection.authenticate(ac);

            try (DiskShare s = ((DiskShare) session.connectShare(properties.getShare()))) {

                mkdir(s, properties.getDfsPath() + File.separator + date);

                mkdir(s, properties.getDfsPath() + File.separator + date + File.separator + messageId);

                String path = properties.getDfsPath() + File.separator +
                        date + File.separator +
                        messageId + File.separator +
                        filename;

                final var f = s.openFile(path,
                        of(AccessMask.GENERIC_WRITE),
                        of(FileAttributes.FILE_ATTRIBUTE_NORMAL),
                        SMB2ShareAccess.ALL,
                        SMB2CreateDisposition.FILE_CREATE,
                        of(SMB2CreateOptions.FILE_RANDOM_ACCESS));
                try (OutputStream oStream = f.getOutputStream()) {
                    oStream.write(file);
                }
                return path;
            }
        }
    }

    public void removeFiles(List<DbFile> files) {
        for (DbFile file : files) {
            String url = file.getUrl();
            if (url != null) {
                try {
                    SMBClient client = new SMBClient();

                    try (Connection connection = client.connect(properties.getServer())) {
                        AuthenticationContext ac = AuthenticationContext.guest();
                        Session session = connection.authenticate(ac);

                        try (DiskShare s = (DiskShare) session.connectShare(properties.getShare())) {
                            s.rm(url);
                        }
                    }
                } catch (IOException e) {
                    log.error("Error rollback Storage Service", e);
                }
            }
        }
    }

    private void mkdir(DiskShare diskShare, String path) {
        if (!diskShare.folderExists(path)) {
            diskShare.mkdir(path);
        }
    }
}
