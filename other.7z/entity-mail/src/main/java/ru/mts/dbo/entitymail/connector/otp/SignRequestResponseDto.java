package ru.mts.dbo.entitymail.connector.otp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class SignRequestResponseDto {
    @JsonProperty("otp_id")
    private String otpId; // GUID кода подтвеждения

    @JsonProperty("last_digit_phone")
    private String phone; // Последние четыре цифры номера телефона клиента
}
