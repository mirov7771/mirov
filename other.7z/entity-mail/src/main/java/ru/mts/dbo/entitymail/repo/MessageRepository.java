package ru.mts.dbo.entitymail.repo;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import ru.mts.dbo.entitymail.model.DbMessage;

import java.math.BigInteger;
import java.util.List;
import java.util.UUID;

public interface MessageRepository extends JpaRepository<DbMessage, UUID> {

    List<DbMessage> findDbMessageByOrganizationIdOrderByDateTimeDesc(BigInteger organizationId, Pageable pageable);
}
