package ru.mts.dbo.entitymail.controller.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.mts.dbo.entitymail.controller.dto.topics.TopicsResponse__1_0;
import ru.mts.dbo.entitymail.controller.provider.TopicsProvider;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("topics")
@Tag(name = "topic", description = "Контроллер для работы с типами обращений")
public class TopicsController {
    private final TopicsProvider topicsProvider;

    @GetMapping("1.0/{clientSystemId}/list")
    @Operation(summary = "Запрос списка типов обращений v1.0", tags = "1.0")
    public TopicsResponse__1_0 check__1_0(
            @Parameter(
                    description = "Тип клиента (системы, приславшей запрос)",
                    example = "edbo-mobile-ios",
                    required = true
            )
            @PathVariable("clientSystemId") String clientSystemId
    ) {
        return topicsProvider.list();
    }
}
