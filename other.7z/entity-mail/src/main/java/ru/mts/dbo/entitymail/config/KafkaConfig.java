package ru.mts.dbo.entitymail.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.*;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.ErrorHandler;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoRequest;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoResponse;

import static java.util.Optional.ofNullable;

@Slf4j
@EnableKafka
@RefreshScope
@Configuration
@RequiredArgsConstructor
public class KafkaConfig {
    private final ApplicationEventPublisher eventPublisher;

    @Value("${kafka.concurrency}")
    private Integer concurrency;

    @Bean("accountInfoContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, AccountInfoRequest> accountInfoRequestConcurrentKafkaListenerContainerFactory(KafkaProperties properties) {
        return defaultContainerFactory(defaultConsumerFactory(properties, AccountInfoRequest.class), accountInfoRequestKafkaTemplate(null, null));
    }


    @Bean
    public ReplyingKafkaTemplate<String, AccountInfoRequest, AccountInfoResponse> accountInfoRequestKafkaTemplate(
            KafkaProperties properties,
            @Value("${kafka.topic.AccountInfoResponse}") String topicResponse) {
        return new ReplyingKafkaTemplate<>(
                defaultProducerFactory(properties),
                defaultMessageListenerContainer(properties, AccountInfoResponse.class, topicResponse)
        );
    }

    @NotNull
    private <T> ConcurrentMessageListenerContainer<String, T> defaultMessageListenerContainer(KafkaProperties properties, Class<T> responseClass, String... topics) {
        final var consumerFactory = defaultConsumerFactory(properties, responseClass);
        final var containerProperties = new ContainerProperties(topics);
        return new ConcurrentMessageListenerContainer<>(consumerFactory, containerProperties);
    }

    @NotNull
    private <T> DefaultKafkaConsumerFactory<String, T> defaultConsumerFactory(KafkaProperties properties, Class<T> clazz) {
        return new DefaultKafkaConsumerFactory<>(
                properties.buildConsumerProperties(),
                new StringDeserializer(),
                new JsonDeserializer<>(clazz, false)
        );
    }

    @NotNull
    private <T> ProducerFactory<String, T> defaultProducerFactory(KafkaProperties properties) {
        return new DefaultKafkaProducerFactory<>(
                properties.buildProducerProperties(),
                new StringSerializer(),
                new JsonSerializer<>()
        );
    }

    @NotNull
    private <IN, OUT> ConcurrentKafkaListenerContainerFactory<String, IN> defaultContainerFactory(ConsumerFactory<String, IN> consumerFactory, KafkaTemplate<String, OUT> kafkaTemplate) {
        final var factory = new ConcurrentKafkaListenerContainerFactory<String, IN>();
        factory.setConsumerFactory(consumerFactory);
        factory.setErrorHandler(kafkaErrorHandler(eventPublisher));
        factory.setApplicationEventPublisher(eventPublisher);
        if (kafkaTemplate != null) {
            factory.setReplyTemplate(kafkaTemplate);
        }
        factory.setConcurrency(concurrency);
        factory.setRecordInterceptor(record -> {
            log.debug("ConsumerRecord(topic = {}, partition = {}, offset = {}, CreateTime = {}, serialized key size = {}, serialized value size = {}, headers = {}, key = {})",
                    record.topic(), record.partition(), record.offset(), record.timestamp(), record.serializedKeySize(), record.serializedValueSize(), record.headers(), record.key());
            return record;
        });
        return factory;
    }

    @NotNull
    public ErrorHandler kafkaErrorHandler(ApplicationEventPublisher eventPublisher) {
        return new ErrorHandler() {
            @Override
            public void handle(Exception thrownException, ConsumerRecord<?, ?> data) {
                final var requestData = ofNullable(data).map(ConsumerRecord::value).map(String::valueOf).orElse(null);
                final var topic = ofNullable(data).map(ConsumerRecord::topic).orElse(null);
                log.error("Error in kafka [" + topic + ": " + requestData + "]: " + thrownException.getLocalizedMessage(), thrownException);
                eventPublisher.publishEvent(thrownException);
            }

            @Override
            public void clearThreadState() {
                Context.clearContext();
            }
        };
    }
}
