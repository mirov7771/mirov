package ru.mts.dbo.entitymail.controller.dto.base;

import lombok.Data;

@Data
public class BaseRequest {
}
