package ru.mts.dbo.entitymail.controller.dto.topics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.mts.dbo.entitymail.controller.dto.base.BaseResponse;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Модель ответа запроса списка типов обращений v1.0")
public class TopicsResponse__1_0 extends BaseResponse {
    @Schema(title = "Список типов обращений")
    private List<Topic> mailtopics;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Модель типа обращений v1.0")
    public static class Topic {
        @Schema(title = "Идентификатор")
        private String id;

        @Schema(title = "Название типа обращения")
        private String title;

        @Schema(title = "Пояснение к типу обращения")
        private String help;
    }
}
