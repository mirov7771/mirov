package ru.mts.dbo.entitymail.connector.otp;

import lombok.Data;
import org.hibernate.validator.constraints.URL;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

@Data
@Validated
@RefreshScope
@Configuration
@ConfigurationProperties("otp")
public class OtpProperties {
    @NotNull
    @Positive
    private long timeout = 10 * 60L;

    @NotNull
    private boolean debug = false;

    private Service service = new Service();

    @Data
    @Validated
    public static class Service {
        @URL
        @NotBlank
        private String signUrl;

        @URL
        @NotBlank
        private String checkUrl;

        @NotBlank
        private String text = "Добрый день, ###fio###!\\nВведите код ###code### для подписания сообщения.";
    }
}
