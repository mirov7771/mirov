package ru.mts.dbo.entitymail.controller.dto.presign;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.mts.dbo.entitymail.controller.dto.base.BaseResponse;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Модель ответа запроса ОТП v1.0")
public class PresignResponse__1_0 extends BaseResponse {

    @Schema(title = "Запрос на подпись сообщения")
    private Presign presignrequest;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Модель запроса на подпись сообщения v1.0")
    public static class Presign {
        @Schema(title = "Идентификатор одноразового пароля", example = "123")
        private String otpId;

        @Schema(title = "Порядковый номер отправленного сообщения", description = "Нам его неоткуда получить, но возвращать надо")
        private Integer smsNum;

        @Schema(title = "Последние 4 цифры номера телефона пользователя", example = "+79093476433")
        private String phone;
    }
}
