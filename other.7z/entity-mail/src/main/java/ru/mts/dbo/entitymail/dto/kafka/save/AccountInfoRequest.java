package ru.mts.dbo.entitymail.dto.kafka.save;

import lombok.Data;
import ru.mts.dbo.entitymail.dto.kafka.base.BaseRequest;

@Data
public class AccountInfoRequest extends BaseRequest {

    private String accountNumber;
}
