package ru.mts.dbo.entitymail.backend.bank.error;

import ru.mts.dbo.entitymail.error.FailureType;

import java.text.MessageFormat;

public class MqRestUnexpectedException extends RequestProcessingException {
    public MqRestUnexpectedException(int httpStatusCode, String body) {
        super(
                FailureType.BACKEND_TECH_ERROR,
                MessageFormat.format("statusCode={0}, body={1}", httpStatusCode, body)
        );
    }
}
