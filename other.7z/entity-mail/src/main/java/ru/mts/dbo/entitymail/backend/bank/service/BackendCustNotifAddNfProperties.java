package ru.mts.dbo.entitymail.backend.bank.service;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
@RefreshScope
@Configuration
@ConfigurationProperties("backend.custnotifaddnf")
public class BackendCustNotifAddNfProperties extends BankServiceProperties {
}
