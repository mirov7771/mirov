package ru.mts.dbo.entitymail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntityMailApplication {

    public static void main(String[] args) {
        SpringApplication.run(EntityMailApplication.class, args);
    }

}
