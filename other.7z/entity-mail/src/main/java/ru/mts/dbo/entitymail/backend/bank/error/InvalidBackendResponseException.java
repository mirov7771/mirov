package ru.mts.dbo.entitymail.backend.bank.error;

import ru.mts.dbo.entitymail.error.FailureType;

public abstract class InvalidBackendResponseException extends RequestProcessingException {
    public InvalidBackendResponseException(String message) {
        super(FailureType.INVALID_BACKEND_RESPONSE, message);
    }
}
