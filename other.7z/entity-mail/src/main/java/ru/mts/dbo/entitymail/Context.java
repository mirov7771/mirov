package ru.mts.dbo.entitymail;

import lombok.Data;
import lombok.experimental.UtilityClass;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.util.Map;
import java.util.UUID;

import static java.util.Optional.ofNullable;
import static org.springframework.web.context.request.RequestAttributes.SCOPE_REQUEST;

@UtilityClass
public class Context {
    private static final String PATH_ATTRIBUTE = "org.springframework.web.servlet.View.pathVariables";

    private static final ThreadLocal<ContextValue> contextHolder = new InheritableThreadLocal<>() {
        @Override
        protected ContextValue initialValue() {
            return new ContextValue();
        }
    };

    public void clearContext() {
        contextHolder.remove();
    }

    public static String getRequestId() {
        return ofNullable(contextHolder.get().getRequestId())
                .map(UUID::toString)
                .orElse(null);
    }

    public static UUID getRequestUUID() {
        return ofNullable(contextHolder.get().getRequestId())
                .orElse(null);
    }

    public static void setRequestId(UUID requestId) {
        contextHolder.get().setRequestId(requestId);
    }

    public static String getSessionId() {
        return ofNullable(contextHolder.get().getSessionId())
                .or(() -> ofNullable(RequestContextHolder.getRequestAttributes())
                        .map(RequestAttributes::getSessionId)
                        .map(sessionId -> contextHolder.get().setSessionId(sessionId).getSessionId())
                ).orElse(null);
    }

    public static void setSessionId(String sessionId) {
        contextHolder.get().setSessionId(sessionId);
    }

    public static String getClientSystemId() {
        return ofNullable(contextHolder.get().getClientSystemId())
                .or(() -> ofNullable(RequestContextHolder.getRequestAttributes())
                        .map(requestAttributes -> requestAttributes.getAttribute(PATH_ATTRIBUTE, SCOPE_REQUEST))
                        .filter(Map.class::isInstance)
                        .map(Map.class::cast)
                        .map(map -> map.get("clientSystemId"))
                        .map(String::valueOf)
                        .map(clientSystemId -> contextHolder.get().setClientSystemId(clientSystemId).getClientSystemId())
                ).orElse(null);
    }

    public static String getFullName() {
        return ofNullable(contextHolder.get().getUserData())
                .map(User::getUserData)
                .map(User.UserData::getFullName)
                .orElse(null);
    }

    public static String getMacAddr() {
        return contextHolder.get().getMacAddr(); // todo: брать из токена
    }

    public static String getIpAddrs() {
        return contextHolder.get().getIpAddr();
    }

    public static void setIpAddrs(String ipAddrs) {
        contextHolder.get().setIpAddr(ipAddrs);
    }

    public static User getUserData() {
        return ofNullable(contextHolder.get().getUserData()).orElse(new User());
    }

    public static void setUserData(User userData) {
        contextHolder.get().setUserData(userData);
    }

    @Data
    private static class ContextValue {
        private UUID requestId;
        private String sessionId;
        private String clientSystemId;
        private String macAddr;
        private String ipAddr;

        private User userData;
    }
}
