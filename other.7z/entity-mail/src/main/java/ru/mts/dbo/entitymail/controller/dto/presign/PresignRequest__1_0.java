package ru.mts.dbo.entitymail.controller.dto.presign;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.mts.dbo.entitymail.controller.dto.base.BaseRequest;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Модель запроса ОТП v1.0")
public class PresignRequest__1_0 extends BaseRequest {
    @NotNull(message = "ID организации должен быть заполнен")
    @DecimalMax(value = "99999999999999999999999999999999999999", message = "ID организации не должен превышать 38 символов")
    @Schema(title = "Идентификатор организации", example = "1234", required = true)
    private BigInteger organizationId;

    @NotEmpty(message = "Хэш должен быть заполнен")
    @Schema(title = "Хэш реквизитов документов и приложенных файлов", example = "0J/RgNC40LLQtdGC")
    private String messageHash;
}
