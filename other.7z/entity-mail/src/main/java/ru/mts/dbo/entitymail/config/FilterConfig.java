package ru.mts.dbo.entitymail.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.mts.dbo.entitymail.filter.RequestIdFilter;
import ru.mts.dbo.entitymail.filter.TokenFilter;

@Configuration
public class FilterConfig {

    @Bean
    public FilterRegistrationBean<RequestIdFilter> requestIdFilter(ObjectMapper objectMapper) {
        final var filterBean = new FilterRegistrationBean<>(new RequestIdFilter(objectMapper));
        filterBean.addUrlPatterns(
                "/topics/*",
                "/message/*"
        );
        return filterBean;
    }

    @Bean
    public FilterRegistrationBean<TokenFilter> tokenFilterRegistrationBean(ObjectMapper objectMapper) {
        final var filterBean = new FilterRegistrationBean<>(new TokenFilter(objectMapper));
        filterBean.addUrlPatterns(
                "/*"
        );
        return filterBean;
    }
}
