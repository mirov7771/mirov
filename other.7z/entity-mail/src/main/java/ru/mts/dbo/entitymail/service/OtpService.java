package ru.mts.dbo.entitymail.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.mts.dbo.entitymail.model.DbOtp;
import ru.mts.dbo.entitymail.repo.OtpRepository;

import java.util.Optional;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class OtpService {
    private final OtpRepository otpRepository;

    public DbOtp save(final DbOtp otp) {
        return otpRepository.save(otp);
    }

    public Optional<DbOtp> getOtp(final String id) {
        return otpRepository.findById(id);
    }
}
