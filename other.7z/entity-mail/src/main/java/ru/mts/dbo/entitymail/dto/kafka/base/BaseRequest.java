package ru.mts.dbo.entitymail.dto.kafka.base;

import lombok.Data;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.User;

import java.util.List;
import java.util.UUID;

@Data
public class BaseRequest {

    private UUID requestId = Context.getRequestUUID();

    private List<User.Organization> organizations = Context.getUserData().getUserData().getOrganizations();
}
