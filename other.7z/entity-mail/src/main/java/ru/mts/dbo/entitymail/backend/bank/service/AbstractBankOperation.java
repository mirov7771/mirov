package ru.mts.dbo.entitymail.backend.bank.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import ru.mts.dbo.entitymail.backend.bank.util.BankMessageParser;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Validated
public abstract class AbstractBankOperation<I> {

    private static final DateTimeFormatter BANK_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    @Autowired
    private BankMessageParser bankMessageParser;
    @Autowired
    private MqRestApi mqRestApi;
    @Autowired
    private DatatypeFactory xmlFactory;

    protected abstract String getMessageType();

    protected abstract String getRequestSender();

    protected abstract String getRequestReceiver();

    protected abstract String getExtendedMessageType();

    protected abstract String getBusinessProcessId();

    protected abstract String getUsername();

    protected abstract String getPassword();

    protected abstract Long getTimeout();

    protected abstract String getRequestQueueUrl();

    protected abstract String getResponseQueueUrl();

    public  <X> X requestBank(I bankRequest, Class<X> responseClass) {

        String xml = bankMessageParser.convertToXML(bankRequest);

        log.info("Bank request ({}, {}): {}", getRequestQueueUrl(), getResponseQueueUrl(), xml);

        String messageId = mqRestApi.send(getRequestQueueUrl(), xml, getUsername(), getPassword());
        log.debug("got message id {}", messageId);

        String responsePayload = mqRestApi.receiveWithTimeout(getResponseQueueUrl(), messageId, getTimeout(),
                getUsername(), getPassword());

        log.info("Bank response: {}", responsePayload);
        return bankMessageParser.parseXML(responsePayload, responseClass);

    }

    public void requestBank(I bankRequest) {

        String xml = bankMessageParser.convertToXML(bankRequest);

        log.info("Bank request ({}, {}): {}", getRequestQueueUrl(), getResponseQueueUrl(), xml);

        String messageId = mqRestApi.send(getRequestQueueUrl(), xml, getUsername(), getPassword());
        log.debug("got message id {}", messageId);
    }

    protected XMLGregorianCalendar convertToXMLDateTime(LocalDateTime dateTime) {
        if (dateTime == null) {
            return null;
        } else {
            return xmlFactory.newXMLGregorianCalendar(dateTime.format(BANK_DATE_TIME_FORMATTER));
        }
    }

}
