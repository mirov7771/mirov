package ru.mts.dbo.entitymail.error;


import static ru.mts.dbo.entitymail.error.FailureType.SIZE_FILE_INVALID;

public class SizeFileInvalidException extends DBOException {
    public SizeFileInvalidException(FailureType type, String message) {
        super(type, message);
    }

    public SizeFileInvalidException(String message) {
        this(SIZE_FILE_INVALID, message);
    }

    public SizeFileInvalidException() {
        this(SIZE_FILE_INVALID.getMessage());
    }
}
