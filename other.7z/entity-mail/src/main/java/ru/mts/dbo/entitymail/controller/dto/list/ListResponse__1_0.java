package ru.mts.dbo.entitymail.controller.dto.list;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.mts.dbo.entitymail.controller.dto.base.BaseResponse;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Перечнь документов")
public class ListResponse__1_0 extends BaseResponse {

    @Schema(title = "Список писем")
    private List<Message> messageList;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Письмо")
    public static class Message {

        @Schema(title = "Идентификатор документа", example = "6be91728-e0ad-4e38-aec1-1b3573ca5421", required = true)
        private UUID messageId;

        @Schema(title = "Дата + время создания/публикации документа", example = "2019-06-01T21:56:22+0300", required = true)
        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
        private ZonedDateTime datetime;

        @Schema(title = "Заголовок типа обращения", example = "Обновление анкет", required = true)
        private String subject;

        @Schema(title = "Текст сообщения", example = "Привет мир!")
        private String message;

        @Schema(title = "Количество вложенных файлов", example = "15")
        private Integer attach;
    }
}
