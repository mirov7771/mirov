package ru.mts.dbo.entitymail.connector.otp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class SignCheckRequestResponseDto {
    @JsonProperty("result")
    private Boolean result; // Результат выполнения операции
}
