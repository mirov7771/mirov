package ru.mts.dbo.entitymail.backend.bank.util;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Вспомогательный компонент для сериализации/десериализации POJO-XML.
 *
 * @author Андрей Колинко (aa.kolinko@mts.ru)
 */
@Component
public class BankMessageParser {
    private ConcurrentMap<Class<?>, JAXBContext> marshallerMap = new ConcurrentHashMap<>();

    private ConcurrentMap<Class<?>, JAXBContext> parserMap = new ConcurrentHashMap<>();

    public String convertToXML(Object request) {
        JAXBContext context = marshallerMap.computeIfAbsent(request.getClass(), xClass -> {
            Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
            marshaller.setClassesToBeBound(xClass);
            return marshaller.getJaxbContext();
        });
        try {
            StringWriter sw = new StringWriter();

            context.createMarshaller().marshal(request, sw);

            return sw.toString();
        } catch (JAXBException e) {
            throw new IllegalStateException("Failed to serialize object: " + request, e);
        }
    }

    @SuppressWarnings("unchecked")
    public  <X> X parseXML(String xml, Class<X> beanClass) {
        JAXBContext context = parserMap.computeIfAbsent(beanClass, xClass -> {
            Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
            marshaller.setClassesToBeBound(xClass);
            return marshaller.getJaxbContext();
        });
        try {
            return (X) context.createUnmarshaller().unmarshal(new StringReader(xml));
        } catch (JAXBException e) {
            throw new IllegalStateException("Failed to parse object: " + beanClass + ". XML: " + xml, e);
        }
    }
}
