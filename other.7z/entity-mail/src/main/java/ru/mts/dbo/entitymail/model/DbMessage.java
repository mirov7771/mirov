package ru.mts.dbo.entitymail.model;

import lombok.Data;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import ru.mts.dbo.entitymail.utils.DateUtils;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigInteger;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Entity
@Table(name = "T_MESSAGE")
public class DbMessage {

    @Id
    @GeneratedValue
    private UUID id;

    @NotBlank
    private String accountNumber;

    private BigInteger organizationId;

    @NotNull
    private Topics topic;

    private String message;

    @Enumerated(EnumType.STRING)
    private State state = State.DRAFT;

    private ZonedDateTime dateTime = DateUtils.now();

    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "message", fetch = FetchType.EAGER)
    private List<DbFile> files;
}
