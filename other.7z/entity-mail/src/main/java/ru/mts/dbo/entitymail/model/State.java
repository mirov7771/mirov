package ru.mts.dbo.entitymail.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum State {
    DRAFT,
    ERROR_SEND,
    SENT
}
