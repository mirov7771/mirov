package ru.mts.dbo.entitymail.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import ru.mts.dbo.entitymail.backend.bank.service.CustNotifAddNfService;
import ru.mts.dbo.entitymail.backend.dto.CustNotifAddNf;
import ru.mts.dbo.entitymail.model.DbFile;
import ru.mts.dbo.entitymail.model.Topics;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
@EnableConfigurationProperties(StorageProperties.class)
public class SendService {

    private final Environment env;
    private final StorageProperties properties;
    private final CustNotifAddNfService sendFeedback;

    @Value("${mq.feedback.from}")
    private String from;
    private final String charset = "utf-8";
    private final String bodyContentType = "text/html; charset=utf-8";

    public void sendEmail(Topics topic, String message, List<DbFile> files, String branchId) throws Exception {
        CustNotifAddNf custNotifAddNf = messageGeneration(topic, message, files, branchId);
        sendFeedback.requestBank(custNotifAddNf);
    }

    private CustNotifAddNf messageGeneration(Topics topic, String text, List<DbFile> files, String branchId) throws Exception {
        String htmlTemplateName = "save.html";
        String messageFormat = readHtmlTemplate(htmlTemplateName);

        String[] params = {
                text,
                files.stream().map(dbFile -> getUrl(dbFile.getUrl(), dbFile.getFileName()))
                        .collect(Collectors.joining("\n"))
        };

        CustNotifAddNf custNotifAddNf = new CustNotifAddNf();
        custNotifAddNf.setServerInfo(sendFeedback.fillServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = new CustNotifAddNf.NotifInfo();
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = new CustNotifAddNf.NotifInfo.EmailInfo();
        CustNotifAddNf.NotifInfo.EmailInfo.Body body = new CustNotifAddNf.NotifInfo.EmailInfo.Body();
        CustNotifAddNf.NotifInfo.EmailInfo.Body.Data data = new CustNotifAddNf.NotifInfo.EmailInfo.Body.Data();

        List<String> dataSend = getDataSend(topic, branchId);
        emailInfo.setSubject(dataSend.get(0));
        emailInfo.setTo(dataSend.get(1));
        emailInfo.setFrom(from);
        emailInfo.setBodyContentType(bodyContentType);
        data.setCharset(charset);
        String message = MessageFormat.format(messageFormat, (Object[]) params);

        byte[] msg = message.getBytes(StandardCharsets.UTF_8);
        data.setData(msg);

        body.setData(data);
        emailInfo.setBody(body);
        notifInfo.setEmailInfo(emailInfo);
        custNotifAddNf.setNotifInfo(notifInfo);
        return custNotifAddNf;
    }

    private String readHtmlTemplate(String fileName) throws IOException {
        StringBuilder contentBuilder = new StringBuilder();
        ClassPathResource resource = new ClassPathResource("template.html" + File.separator + fileName);
        InputStream inputStream = resource.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        String str;
        while ((str = in.readLine()) != null) {
            contentBuilder.append(str);
        }
        in.close();

        return contentBuilder.toString();
    }

    private List getDataSend(Topics topics, String branchId) {
        for (Topics.Email email : topics.getEmails()) {
            if (topics.getEmails().size() == 1) {
                String e = env.getProperty("mq.feedback." + email.getEmail());
                return List.of(email.getSubject(), e);
            } else if (email.getBranchIdEquals() != null && branchId.equals(email.getBranchIdEquals())) {
                String e = env.getProperty("mq.feedback." + email.getEmail());
                return List.of(email.getSubject(), e);
            } else if (email.getBranchIdNotEquals() != null && !branchId.equals(email.getBranchIdNotEquals())) {
                String e = env.getProperty("mq.feedback." + email.getEmail());
                return List.of(email.getSubject(), e);
            }
        }
        return null;
    }

    private String getUrl(String url, String name) {
        url = url.replace("/", "\\");
        return "<a href=\"\\\\" + properties.getServer()
                + "\\" + properties.getShare()
                + "\\" + url
                + "\">" + name
                + "</a>";
    }
}
