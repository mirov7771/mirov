package ru.mts.dbo.entitymail.backend.bank.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.*;
import org.springframework.retry.annotation.Retryable;
import org.springframework.util.StopWatch;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.entitymail.backend.bank.error.MqRestTimeoutException;
import ru.mts.dbo.entitymail.backend.bank.error.MqRestUnexpectedException;
import ru.mts.dbo.entitymail.error.DboResourceAccessException;

import java.util.Collections;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.MediaType.ALL;

@Slf4j
@RequiredArgsConstructor
public class MqRestApi {

    private final RestTemplate restTemplate;

    public String send(String requestQueueUrl, String xml, String username, String password) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(CONTENT_TYPE, "application/xml;charset=utf-8");
        headers.setAccept(Collections.singletonList(ALL));
        addStdHeaders(headers);
        addAuthHeaders(username, password, headers);
        headers.add("ibm-mq-md-persistence", "persistent");

        HttpEntity<String> request = new HttpEntity<>(xml, headers);

        log.info("do request {} by url {}", request, requestQueueUrl);

        StopWatch sw = new StopWatch();
        sw.start();

        ResponseEntity<String> response;
        try {
            response = restTemplate.exchange(requestQueueUrl, HttpMethod.POST, request, String.class);
        } catch (ResourceAccessException rae) {
            throw new DboResourceAccessException(rae);
        }

        sw.stop();

        log.info("and get response {}, trip {} ms", response, sw.getTotalTimeMillis());

        if (HttpStatus.CREATED == response.getStatusCode()) {
            return response.getHeaders().getFirst("ibm-mq-md-messageId");
        }

        throw new MqRestUnexpectedException(response.getStatusCodeValue(), response.getBody());
    }

    @Retryable(
            maxAttempts = 5,
            value = {MqRestTimeoutException.class, HttpServerErrorException.class}
    )
    public String receiveWithTimeout(String responseQueueUrl, String correlationId, long timeout, String username, String password) {

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.TEXT_PLAIN));
        addStdHeaders(headers);

        addAuthHeaders(username, password, headers);

        HttpEntity<String> request = new HttpEntity<>(null, headers);

        String fullResponseQueueUrl = responseQueueUrl
                + "?correlationId=" + correlationId + "&wait=" + timeout;

        log.info("do request with corrid {} by url {}", request, fullResponseQueueUrl);

        ResponseEntity<String> response;
        try {
            response = restTemplate.exchange(fullResponseQueueUrl, HttpMethod.DELETE, request, String.class);
        } catch (ResourceAccessException rae) {
            throw new DboResourceAccessException(rae);
        } catch (HttpServerErrorException e) {
            throw new MqRestTimeoutException(timeout);
        }

        log.info("and get response {}", response);

        switch (response.getStatusCode()) {
            case OK:
                return response.getBody();
            case NO_CONTENT:
            case BAD_GATEWAY:
            case GATEWAY_TIMEOUT:
            case SERVICE_UNAVAILABLE:
            case INTERNAL_SERVER_ERROR:
                throw new MqRestTimeoutException(timeout);
            default:
                throw new MqRestUnexpectedException(response.getStatusCodeValue(), response.getBody());
        }

    }

    private void addStdHeaders(HttpHeaders headers) {
        headers.add(ACCEPT_CHARSET, UTF_8.name());
        headers.add(CONTENT_ENCODING, UTF_8.name());
        headers.add("ibm-mq-rest-csrf-token", "token_value");
    }

    private void addAuthHeaders(String username, String password, HttpHeaders headers) {
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(UTF_8));
        String authHeader = "Basic " + new String(encodedAuth);
        headers.add("Authorization", authHeader);
    }
}
