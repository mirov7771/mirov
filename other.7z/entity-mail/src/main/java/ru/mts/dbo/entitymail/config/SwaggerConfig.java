package ru.mts.dbo.entitymail.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.parameters.HeaderParameter;
import io.swagger.v3.oas.models.parameters.Parameter;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Base64;
import java.util.List;
import java.util.UUID;

import static ru.mts.dbo.entitymail.controller.RestCommons.*;

/**
 * Конфигурация документации API (springdoc-openapi-ui).
 */
@Configuration
@ConditionalOnProperty(value = "swagger.enabled", havingValue = "true")
public class SwaggerConfig {
    @Bean
    public OpenAPI api() {
        return new OpenAPI()
                .info(new Info()
                        .title("API ДБО для ЮЛ")
                        .description("API сервисов ДБО для юридических лиц")
                        .version("1.0")
                );
    }

    @Bean
    public OpenApiCustomiser headerOpenAPICustomiser() {
        final var commonParameters = getCommonParameters();
        return openApi -> openApi.getPaths().values().stream()
                .flatMap(pathItem -> pathItem.readOperations().stream())
                .forEach(operation -> commonParameters.forEach(operation::addParametersItem));
    }

    private List<Parameter> getCommonParameters() {
        return List.of(
                new HeaderParameter()
                        .description("Глобально уникальный идентификатор запроса")
                        .name(REQUEST_ID_HTTP_HEADER)
                        .example(UUID.randomUUID())
                        .allowEmptyValue(false)
                        .required(true),
                new HeaderParameter()
                        .description("Токен авторизации")
                        .name(TOKEN_HEADER_NAME)
                        .example(BEARER_PART_NAME + " " + Base64.getUrlEncoder().encodeToString("Hello".getBytes()))
                        .allowEmptyValue(false)
                        .required(true)
        );
    }
}
