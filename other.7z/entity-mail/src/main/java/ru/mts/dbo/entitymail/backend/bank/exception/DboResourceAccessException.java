package ru.mts.dbo.entitymail.backend.bank.exception;

import org.springframework.web.client.ResourceAccessException;
import ru.mts.dbo.entitymail.error.FailureType;

public class DboResourceAccessException extends DBOException {
    private final String logMessage;

    public DboResourceAccessException(ResourceAccessException rae) {
        super(FailureType.BACKEND_TECH_ERROR);
        logMessage = rae.getLocalizedMessage();
    }

    @Override
    public String getLogMessage() {
        return logMessage;
    }
}
