package ru.mts.dbo.entitymail.connector.kafka;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.stereotype.Component;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoRequest;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoResponse;
import ru.mts.dbo.entitymail.error.DboResourceAccessException;

import java.time.Duration;
import java.util.concurrent.ExecutionException;

@Slf4j
@Component
@RequiredArgsConstructor
public class AccountInfoKafkaConnector {
    private final ReplyingKafkaTemplate<String, AccountInfoRequest, AccountInfoResponse> kafkaTemplate;

    @Value("${kafka.topic.AccountInfoRequest}")
    private String topic;

    public AccountInfoResponse getData(AccountInfoRequest request) {
        log.debug("Request from dbo service received :  {}", request);
        try {
            AccountInfoResponse response = kafkaTemplate.sendAndReceive(new ProducerRecord<>(topic, request), Duration.ofSeconds(30)).get().value();
            log.debug("A response was sent to the dbo service : {}", response);
            return response;
        } catch (InterruptedException | ExecutionException e) {
            throw new DboResourceAccessException("Kafka error");
        }
    }
}