package ru.mts.dbo.entitymail.controller.dto.save;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.jcajce.provider.digest.SHA3;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import ru.mts.dbo.entitymail.controller.dto.base.BaseRequest;
import ru.mts.dbo.entitymail.error.CommonInvalidFrontendRequestException;
import ru.mts.dbo.entitymail.model.Topics;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.IOException;
import java.math.BigInteger;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Data
@Schema(description = "Запрос на создание документа")
public class SaveRequest__1_0 extends BaseRequest {

    @NotBlank(message = "Номер счёта должен быть не пустым")
    @Pattern(regexp = "^[0-9]{20}$")
    @Schema(title = "Номер счёта", example = "40702810100000000123", required = true)
    private String accountNumber;

    @NotNull(message = "Тип оброщение должен быть не пустым")
    @Schema(title = "Тип обращения", example = "321", required = true)
    private Topics topicId;

    @Schema(title = "Комментарий", example = "Привет мир!")
    private String message;

    @NotBlank
    @Schema(title = "Идентификатор OTP", example = "6be91728-e0ad-4e38-aec1-1b3573ca5422", required = true)
    private String otpId;

    @NotBlank(message = "Код OTP должен быть не пустым")
    @Schema(title = "Введенный код OTP", example = "1234", required = true)
    private String pwd;

    @Schema(title = "Вложения")
    private List<MultipartFile> attachments;

    @JsonIgnore
    public boolean isValid() {
        return StringUtils.isNotEmpty(message) || !CollectionUtils.isEmpty(attachments);
    }

    @JsonIgnore
    @SneakyThrows
    public String hash(BigInteger organizationId) {
        final var digestSHA3 = new SHA3.Digest512();
        String fileHash = attachments.stream()
                .map(attachment ->
                {
                    try {
                        return Hex.encodeHexString(digestSHA3.digest(attachment.getBytes()));
                    } catch (IOException e) {
                        log.error("IO error", e);
                        throw new CommonInvalidFrontendRequestException();
                    }
                })
                .collect(Collectors.joining());

        final var raw = Stream.of(
                organizationId,
                topicId,
                message,
                fileHash
        ).map(String::valueOf).collect(Collectors.joining("$$"));

        final var digest = digestSHA3.digest(raw.getBytes());
        return Hex.encodeHexString(digest);
    }
}
