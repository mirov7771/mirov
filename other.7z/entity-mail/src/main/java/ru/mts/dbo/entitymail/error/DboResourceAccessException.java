package ru.mts.dbo.entitymail.error;

import org.springframework.web.client.ResourceAccessException;

public class DboResourceAccessException extends DBOException {
    private final String logMessage;

    public DboResourceAccessException(ResourceAccessException rae) {
        super(FailureType.BACKEND_TECH_ERROR);
        this.logMessage = rae.getLocalizedMessage();
    }

    public DboResourceAccessException(String logMessage) {
        super(FailureType.BACKEND_TECH_ERROR);
        this.logMessage = logMessage;
    }

    @Override
    public String getLogMessage() {
        return logMessage;
    }
}
