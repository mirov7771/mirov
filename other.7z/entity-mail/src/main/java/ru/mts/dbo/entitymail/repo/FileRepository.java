package ru.mts.dbo.entitymail.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.mts.dbo.entitymail.model.DbFile;

import java.util.UUID;

public interface FileRepository extends JpaRepository<DbFile, UUID> {
}
