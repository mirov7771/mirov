package ru.mts.dbo.entitymail.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MimeType {
    CSV(
            "text/csv",
            "csv"
    ),
    DOC(
            "application/msword",
            "doc"
    ),
    MSOFFICE(
            "application/x-tika-msoffice",
            "doc"
    ),
    MSEXCEL(
            "application/x-tika-ooxml",
            "xlsx"
    ),
    DOCX(
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "docx"
    ),
    GIF(
            "image/gif",
            "gif"
    ),
    JPEG(
            "image/jpeg",
            "jpeg"
    ),
    ODP(
            "application/vnd.oasis.opendocument.presentation",
            "odp"
    ),
    ODS(
            "application/vnd.oasis.opendocument.spreadsheet",
            "ods"
    ),
    ODT(
            "application/vnd.oasis.opendocument.text",
            "odt"
    ),
    PNG(
            "image/png",
            "png"
    ),
    PDF(
            "application/pdf",
            "pdf"
    ),
    PPT(
            "application/vnd.ms-powerpoint",
            "ppt"
    ),
    PPTX(
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "pptx"
    ),
    RTF(
            "application/rtf",
            "rtf"
    ),
    TXT(
            "text/plain",
            "txt"
    ),
    XLS(
            "application/vnd.ms-excel",
            "xls"
    ),
    XLSX(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "xlsx"
    ),
    ZIP(
            "application/zip",
            "zip"
    );

    private final String mimeType;
    private final String description;
}
