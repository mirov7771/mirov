package ru.mts.dbo.entitymail.utils;

import lombok.experimental.UtilityClass;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.User;
import ru.mts.dbo.entitymail.error.EntityNotFoundException;

import java.math.BigInteger;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import static java.util.Optional.ofNullable;

@UtilityClass
public final class SecurityUtils {

    public static void checkContextOrganizationId(BigInteger organizationId) {
        if (!existContextOrganizationId(organizationId)) {
            throw new EntityNotFoundException(); // fixme: пока что
        }
    }

    public static boolean existContextOrganizationId(BigInteger organizationId) {
        return getContextOrganizations().stream()
                .map(User.Organization::getId)
                .anyMatch(org -> Objects.equals(org, String.valueOf(organizationId)));
    }

    public List<User.Organization> getContextOrganizations() {
        return ofNullable(Context.getUserData().getUserData())
                .map(User.UserData::getOrganizations)
                .orElseThrow(EntityNotFoundException::new);
    }

    public static void setContext(String orgId) {
        User.Organization organization = new User.Organization().setId(orgId);
        User.UserData userData = new User.UserData().setOrganizations(Collections.singletonList(organization));
        User user = new User().setUserData(userData);
        Context.setUserData(user);
    }

    public static void setContext(List<User.Organization> organizations) {
        User.UserData userData = new User.UserData().setOrganizations(organizations);
        User user = new User().setUserData(userData);
        Context.setUserData(user);
    }
}
