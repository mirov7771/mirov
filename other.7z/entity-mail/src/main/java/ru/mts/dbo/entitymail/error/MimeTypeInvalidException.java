package ru.mts.dbo.entitymail.error;


import static ru.mts.dbo.entitymail.error.FailureType.MIME_TYPE_INVALID;

public class MimeTypeInvalidException extends DBOException {
    public MimeTypeInvalidException(FailureType type, String message) {
        super(type, message);
    }

    public MimeTypeInvalidException(String message) {
        this(MIME_TYPE_INVALID, message);
    }

    public MimeTypeInvalidException() {
        this(MIME_TYPE_INVALID.getMessage());
    }
}
