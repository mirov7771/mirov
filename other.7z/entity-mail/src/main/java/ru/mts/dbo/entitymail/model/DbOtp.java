package ru.mts.dbo.entitymail.model;

import lombok.Data;
import ru.mts.dbo.entitymail.Context;
import ru.mts.dbo.entitymail.utils.DateUtils;

import javax.persistence.*;
import java.time.ZonedDateTime;

@Data
@Entity
@Table(name = "T_OTP")
public class DbOtp {
    @Id
    private String otpId;

    private String session = Context.getSessionId();

    private String otpValue;

    private String hash;

    private ZonedDateTime dateCreation = DateUtils.now();

    private ZonedDateTime signDate;

    private String userId = Context.getUserData().getUserId();

    @OneToOne
    private DbMessage message;
}
