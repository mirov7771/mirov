package ru.mts.dbo.entitymail.model;

import lombok.Data;
import lombok.ToString;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@Data
@Entity
@Table(name = "T_FILE")
@ToString(exclude = "message")
public class DbFile {

    @Id
    @GeneratedValue
    private UUID id;

    @NotBlank
    private String originalFileName;

    @NotBlank
    private String fileName;

    @NotNull
    private Long size;

    @NotBlank
    private String type;

    @NotBlank
    private String url;

    @ManyToOne
    private DbMessage message;

    @Transient
    private byte[] data;
}
