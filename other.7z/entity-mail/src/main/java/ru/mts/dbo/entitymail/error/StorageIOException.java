package ru.mts.dbo.entitymail.error;


import static ru.mts.dbo.entitymail.error.FailureType.INVALID_BACKEND_RESPONSE;

public class StorageIOException extends DBOException {
    public StorageIOException(FailureType type, String message) {
        super(type, message);
    }

    public StorageIOException(String message) {
        this(INVALID_BACKEND_RESPONSE, message);
    }

    public StorageIOException() {
        this(INVALID_BACKEND_RESPONSE.getMessage());
    }
}
