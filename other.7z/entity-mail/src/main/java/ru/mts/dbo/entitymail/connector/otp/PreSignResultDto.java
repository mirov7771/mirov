package ru.mts.dbo.entitymail.connector.otp;

import lombok.Data;

@Data
public class PreSignResultDto {
    private String crc;
    private String otpId;
    private String phone;
    private Integer smsNum;
}
