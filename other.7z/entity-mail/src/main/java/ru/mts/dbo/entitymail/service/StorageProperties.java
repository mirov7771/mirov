package ru.mts.dbo.entitymail.service;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(prefix = "storage")
public class StorageProperties {

    @Value("${storage.share}")
    private String share;

    @Value("${storage.server}")
    private String server;

    @Value("${storage.path}")
    private String dfsPath;
}
