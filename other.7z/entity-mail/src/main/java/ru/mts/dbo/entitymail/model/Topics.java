package ru.mts.dbo.entitymail.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

import java.util.Collections;
import java.util.List;

@Getter
@AllArgsConstructor
public enum Topics {
    TOPIC_ANKETA(
            "Обновление данных",
            "Уведомление банка об изменениях в реквизитах или предоставление копий обосновывающих документов согласно требованиям Федерального закона от 07.08.2001 г. №115-ФЗ",
            Collections.singletonList(new Email(null,null, "Обновление анкет по 115-ФЗ",
                    "anketa"))
    ),
    TOPIC_SFM(
            "Запросы по операциям",
            "Предоставление дополнительной информации и документов для подтверждения операций согласно требованиям финансового мониторинга",
            List.of(new Email("001",null, "Отдел финансового мониторинга",
                            "ofm"),
                    new Email(null,"001", "ЦСПКО СФМ Отдел по работе с филиальной сетью Томск",
                            "sfm"))
//    ),
//    TOPIC_OTHERS(
//            "Другое",
//            "Запросы и уведомления в банк по вопросам, не относящимся к перечисленным выше",
//            null
    );

    private final String title;
    private final String description;
    private final List<Email> emails;

    @Data
    public static class Email {
        private final String branchIdEquals;
        private final String branchIdNotEquals;
        private final String subject;
        private final String email;
    }
}
