package ru.mts.dbo.entitymail.integration.mq;

import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.entitymail.backend.bank.service.MqRestApi;

import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@AutoConfigureEmbeddedDatabase
@Import(ru.mts.dbo.entitymail.integration.mq.MqRestApiTest.TestMqApiController.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MqRestApiTest {
    private static final String TEST_CONTROLLER_PATH = "MqRestApiTest/TestMqApiController";
    private static String TEXT = randomAlphabetic(10) + "аАбБвВгГдДеЕёЁжЖзЗиИ" + randomAlphabetic(10); // кириллица
    @LocalServerPort
    protected int port;
    @Value("#{servletContext.contextPath}")
    protected String contextPath;
    @Autowired
    protected MqRestApi mqRestApi;

    @Test
    public void mqApiCharsetEncodingTest() {
        final var url = "http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH;
        final var response = mqRestApi.send(url, TEXT, randomAlphabetic(10), randomAlphabetic(10));
        assertNotNull(response);
    }


    @RestController
    @RequestMapping(TEST_CONTROLLER_PATH)
    static class TestMqApiController {
        @PostMapping
        @ResponseStatus(HttpStatus.CREATED)
        public void receive(
                HttpServletResponse response,
                @RequestBody String received
        ) {
            if (!received.contains(TEXT)) {
                throw new IllegalArgumentException();
            }
            response.setHeader("ibm-mq-md-messageId", UUID.randomUUID().toString());
        }
    }
}
