package ru.mts.dbo.entitymail;

import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.RandomStringUtils;
import org.jetbrains.annotations.NotNull;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static java.util.Optional.ofNullable;

@UtilityClass
public final class ContextUtils {

    private void setContextUserOrganizations(List<User.Organization> organizations) {
        User.Name userName = new User.Name()
                .setFirstName("Test-FirstName")
                .setLastName("Test-LastName")
                .setMiddleName("Test-MiddleName");

        User.UserData userData = new User.UserData()
                .setOrganizations(organizations)
                .setName(userName)
                .setRboId("test-rboId")
                .setIbsoId("test-ibsoId");

        User user = new User()
                .setUserData(userData)
                .setUserId(BigInteger.TEN.toString())
                .setClientId("msb_test");

        Context.setUserData(user);
    }

    public static void addContextOrganization(@NotNull BigInteger orgId) {
        final var existingOrganizations = ofNullable(Context.getUserData().getUserData())
                .map(User.UserData::getOrganizations)
                .map(ArrayList::new)
                .orElseGet(ArrayList::new);
        existingOrganizations.add(
                new User.Organization()
                        .setName(RandomStringUtils.randomAlphabetic(10))
                        .setId(orgId.toString())
        );
        setContextUserOrganizations(existingOrganizations);
    }

    public static void setUserId(@NotNull BigInteger userId) {
        Context.getUserData().setUserId(String.valueOf(userId));
    }
}
