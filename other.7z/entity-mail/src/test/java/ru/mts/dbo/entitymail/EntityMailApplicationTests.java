package ru.mts.dbo.entitymail;

import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@AutoConfigureEmbeddedDatabase
class EntityMailApplicationTests {

    @Test
    void contextLoads() {
    }

}
