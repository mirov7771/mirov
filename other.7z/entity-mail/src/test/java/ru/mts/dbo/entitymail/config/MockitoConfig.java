package ru.mts.dbo.entitymail.config;


import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.entitymail.backend.bank.service.MqRestApi;
import ru.mts.dbo.entitymail.connector.otp.OtpProperties;

@Configuration
@ConditionalOnWebApplication
public class MockitoConfig {
    @Bean
    @Primary
    public RestTemplate spyRestTemplate() {
        return Mockito.spy(new RestTemplate());
    }

    @Bean
    @Primary
    public TestRestTemplate testRestTemplate() {
        return Mockito.spy(new TestRestTemplate());
    }

    @Bean
    @Primary
    public MqRestApi spyMqRestApi() {
        return Mockito.spy(new MqRestApi(spyRestTemplate()));
    }

    @Bean
    @Primary
    public OtpProperties spyOtpProperties() {
        return Mockito.spy(new OtpProperties());
    }
}
