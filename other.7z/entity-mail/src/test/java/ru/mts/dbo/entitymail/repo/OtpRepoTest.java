package ru.mts.dbo.entitymail.repo;

import ru.mts.dbo.entitymail.model.DbOtp;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;

public class OtpRepoTest extends AbstractRepoTest<DbOtp, String> {
    @Override
    DbOtp generateOneEntity() {
        return new DbOtp()
                .setOtpValue(randomNumeric(6))
                .setOtpId(randomAlphanumeric(10))
                .setHash(randomAlphanumeric(128));
    }

    @Override
    String extractId(final DbOtp entity) {
        return entity.getOtpId();
    }
}
