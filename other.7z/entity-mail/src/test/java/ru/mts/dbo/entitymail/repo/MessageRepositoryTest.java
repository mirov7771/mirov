package ru.mts.dbo.entitymail.repo;

import org.junit.Test;
import ru.mts.dbo.entitymail.model.DbFile;
import ru.mts.dbo.entitymail.model.DbMessage;
import ru.mts.dbo.entitymail.model.State;
import ru.mts.dbo.entitymail.model.Topics;

import java.util.Collections;
import java.util.UUID;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static ru.mts.dbo.entitymail.TestUtils.randomBI;
import static ru.mts.dbo.entitymail.TestUtils.randomEnum;

public class MessageRepositoryTest extends AbstractRepoTest<DbMessage, UUID> {
    @Override
    DbMessage generateOneEntity() {
        final var file = new DbFile().setFileName(randomAlphanumeric(20))
                .setOriginalFileName(randomAlphanumeric(20))
                .setSize(2L)
                .setType("353")
                .setUrl("https://www.mtsbank.ru/");

        final var message = new DbMessage()
                .setOrganizationId(randomBI())
                .setState(randomEnum(State.class))
                .setMessage(randomAlphanumeric(20))
                .setAccountNumber(randomAlphanumeric(20))
                .setTopic(randomEnum(Topics.class))
                .setFiles(Collections.singletonList(file));
        return message;
    }

    @Override
    UUID extractId(final DbMessage entity) {
        return entity.getId();
    }

    @Test
    public void saveFileTest() {
        var message = repository.save(generateOneEntity());
        final var optionalMessage = repository.findById(message.getId());
        assertNotNull(optionalMessage);
        final var messages = message.getFiles();
        assertNotNull(messages);
        assertEquals(1, messages.size());
    }
}