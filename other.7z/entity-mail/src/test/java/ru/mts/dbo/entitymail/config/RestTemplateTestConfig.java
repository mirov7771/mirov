package ru.mts.dbo.entitymail.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.UUID;

import static ru.mts.dbo.entitymail.controller.RestCommons.REQUEST_ID_HTTP_HEADER;


@Configuration
@ConditionalOnWebApplication
@Profile("!" + RestTemplateTestConfig.DISABLE)
public class RestTemplateTestConfig {
    public static final String DISABLE = "DISABLE_REQUEST_ID";

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @PostConstruct
    public void initRestTemplate() {
        final ClientHttpRequestInterceptor requestIdInterceptor = (request, body, execution) -> {
            request.getHeaders().add(REQUEST_ID_HTTP_HEADER, UUID.randomUUID().toString());
            return execution.execute(request, body);
        };

        restTemplate.getInterceptors().add(requestIdInterceptor);

        testRestTemplate.getRestTemplate().getInterceptors().add(requestIdInterceptor);
    }
}
