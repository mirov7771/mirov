package ru.mts.dbo.entitymail.rest;

import org.apache.commons.lang3.RandomUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import ru.mts.dbo.entitymail.ContextUtils;
import ru.mts.dbo.entitymail.connector.kafka.AccountInfoKafkaConnector;
import ru.mts.dbo.entitymail.controller.dto.list.ListResponse__1_0;
import ru.mts.dbo.entitymail.model.DbFile;
import ru.mts.dbo.entitymail.model.DbMessage;
import ru.mts.dbo.entitymail.model.State;
import ru.mts.dbo.entitymail.model.Topics;
import ru.mts.dbo.entitymail.repo.FileRepository;
import ru.mts.dbo.entitymail.repo.MessageRepository;
import ru.mts.dbo.entitymail.service.StorageService;
import ru.mts.dbo.entitymail.utils.DateUtils;

import java.math.BigInteger;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;
import static org.junit.Assert.*;
import static org.springframework.http.HttpStatus.OK;
import static ru.mts.dbo.entitymail.error.FailureType.*;

public class MessageListRestTest extends BaseRestTest {

    @Autowired
    private FileRepository fileRepository;

    @Autowired
    private MessageRepository messageRepository;

    @Before
    public void cleanup() {
        fileRepository.deleteAll();
        messageRepository.deleteAll();
    }

    @Test
    public void list__1_0_Test() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(1);

        var message = messageRepository.save(new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50)));

        message = messageRepository.save(message.setFiles(Collections.singletonList(new DbFile().setMessage(message)
                .setOriginalFileName("Мир")
                .setFileName("mir")
                .setSize(1L)
                .setType("txt")
                .setUrl("url"))));

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("messageId", message.getId());
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var messages = data.getMessageList();

        assertNotNull(messages);
        assertEquals(1, messages.size());

        final var message1 = messages.get(0);
        assertEquals(message.getFiles().size(), message1.getAttach().intValue());
        assertEquals(message.getDateTime().toLocalDate(), message1.getDatetime().toLocalDate());
        assertEquals(message.getMessage(), message1.getMessage());
        assertEquals(message.getTopic().getTitle(), message1.getSubject());
        assertNotNull(message1.getMessageId());
    }

    @Test
    public void list__1_0_AttachmentsCountTest() {
        final var url = getUrl__1_0();
        final var orgId = BigInteger.valueOf(1);

        final var generatedMessage = new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50));
        final var files = IntStream.range(0, RandomUtils.nextInt(5, 10)).boxed()
                .map(i -> new DbFile()
                        .setOriginalFileName(randomAlphabetic(1, 5))
                        .setFileName(randomAlphabetic(1, 5))
                        .setSize(1L)
                        .setType(randomAlphabetic(1, 5))
                        .setUrl(randomAlphabetic(1, 5))
                        .setMessage(generatedMessage)
                )
                .collect(Collectors.toList());

        final var message = messageRepository.save(generatedMessage.setFiles(files));

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("messageId", message.getId());
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        assertEquals(files.size(), fileRepository.count());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var messages = data.getMessageList();

        assertNotNull(messages);
        assertEquals(1, messages.size());

        final var message1 = messages.get(0);
        assertEquals(files.size(), message1.getAttach().intValue());
        assertEquals(message.getDateTime().toLocalDate(), message1.getDatetime().toLocalDate());
        assertEquals(message.getMessage(), message1.getMessage());
        assertEquals(message.getTopic().getTitle(), message1.getSubject());
        assertNotNull(message1.getMessageId());
    }

    @Test
    public void list__1_0_InvaliUuidTest() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(1);

        var message = messageRepository.save(new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50)));

        messageRepository.save(message.setFiles(Collections.singletonList(new DbFile().setMessage(message)
                .setOriginalFileName("Мир")
                .setFileName("mir")
                .setSize(1L)
                .setType("txt")
                .setUrl("url"))));

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("messageId", UUID.randomUUID());
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(ENTITY_NOT_FOUND.getCode(), data.getErrorCode());
        assertEquals(ENTITY_NOT_FOUND.getMessage(), data.getErrorMessage());
    }


    @Test
    public void list__1_0_InvalidMessageIdTest() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(2);

        var message = messageRepository.save(new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50)));

        messageRepository.save(message.setFiles(Collections.singletonList(new DbFile().setMessage(message)
                .setOriginalFileName("Мир")
                .setFileName("mir")
                .setSize(1L)
                .setType("txt")
                .setUrl("url"))));

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("messageId", "gfiufuitftyfc");
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        assertEquals(INVALID_FRONTEND_REQUEST.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(INVALID_FRONTEND_REQUEST.getCode(), data.getErrorCode());
        assertEquals(INVALID_FRONTEND_REQUEST.getMessage(), data.getErrorMessage());
    }

    @Test
    public void list__1_0_ListTest() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(3);

        var message1 = messageRepository.save(new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50)));

        message1 = messageRepository.save(message1.setFiles(Collections.singletonList(new DbFile().setMessage(message1)
                .setOriginalFileName("Мир")
                .setFileName("mir")
                .setSize(1L)
                .setType("txt")
                .setUrl("url"))));
        final var message2 = messageRepository.save(new DbMessage().setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50))
                .setDateTime(DateUtils.now().minusDays(2)));
        messageRepository.save(new DbMessage().setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50))
                .setDateTime(DateUtils.now().minusDays(3)));

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("limit", 2);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var messages = data.getMessageList();

        assertNotNull(messages);
        assertEquals(2, messages.size());

        final var message1_1 = messages.get(0);
        assertEquals(message1.getFiles().size(), message1_1.getAttach().intValue());
        assertEquals(message1.getDateTime().toLocalDate(), message1_1.getDatetime().toLocalDate());
        assertEquals(message1.getMessage(), message1_1.getMessage());
        assertEquals(message1.getTopic().getTitle(), message1_1.getSubject());
        assertNotNull(message1_1.getMessageId());

        final var message2_2 = messages.get(1);
        assertEquals(0, message2_2.getAttach().intValue());
        assertEquals(message2.getDateTime().toLocalDate(), message2_2.getDatetime().toLocalDate());
        assertEquals(message2.getMessage(), message2_2.getMessage());
        assertEquals(message2.getTopic().getTitle(), message2_2.getSubject());
        assertNotNull(message2_2.getMessageId());
    }

    @Test
    public void list__1_0_LimitDefault20Test() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(4);

        IntStream.range(0, 11).boxed()
                .map(i -> messageRepository.save(new DbMessage()
                        .setOrganizationId(orgId)
                        .setAccountNumber(randomNumeric(20))
                        .setState(State.SENT)
                        .setTopic(Topics.TOPIC_ANKETA)
                        .setMessage(randomAlphabetic(50)))
                ).collect(Collectors.toList());
        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("messageId", null);
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var messages = data.getMessageList();

        assertNotNull(messages);
        assertEquals(10, messages.size());
        assertNotEquals(messageRepository.findAll().size(), messages.size());
    }

    @Test
    public void list__1_0_OrganizationNullTest() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(5);

        messageRepository.save(new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50)));

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", null);
        params.put("messageId", null);
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(UNEXPECTED_ERROR.getCode(), data.getErrorCode());
        assertNotNull(data.getErrorMessage());
    }

    @Test
    public void list__1_0_InvalidOrganizationTest() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(6);

        messageRepository.save(new DbMessage()
                .setOrganizationId(orgId)
                .setAccountNumber(randomNumeric(20))
                .setState(State.SENT)
                .setTopic(Topics.TOPIC_ANKETA)
                .setMessage(randomAlphabetic(50)));

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("messageId", null);
        params.put("limit", null);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&messageId={messageId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(ENTITY_NOT_FOUND.getCode(), data.getErrorCode());
        assertEquals(ENTITY_NOT_FOUND.getMessage(), data.getErrorMessage());
    }

    @Test
    public void list__1_0_EmptyListTest() {
        final var url = getUrl__1_0();
        BigInteger orgId = BigInteger.valueOf(7);

        ContextUtils.addContextOrganization(orgId);

        Map<String, Object> params = new HashMap<>();
        params.put("organizationId", orgId);
        params.put("limit", 2);

        final var response = testRestTemplate.getForEntity(url + "?organizationId={organizationId}&limit={limit}", ListResponse__1_0.class, params);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var messages = data.getMessageList();

        assertNotNull(messages);
        assertEquals(0, messages.size());
    }

    @Override
    protected String getMethod() {
        return "list";
    }

    @Override
    protected String getMethodBase() {
        return "message";
    }

    @TestConfiguration
    public static class MessageSaveRestTestConfiguration {

        @Bean
        @Primary
        public AccountInfoKafkaConnector getOrganizationInfoKafkaConnectorSpy(AccountInfoKafkaConnector accountInfoKafkaConnector) {
            return Mockito.spy(accountInfoKafkaConnector);
        }

        @Bean
        @Primary
        public StorageService getDfsServiceSpy(StorageService storageService) {
            return Mockito.spy(storageService);
        }
    }
}
