package ru.mts.dbo.entitymail;

import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;
import org.springframework.util.ResourceUtils;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.Random;

@UtilityClass
public class TestUtils {
    private static final Random random = new SecureRandom();

    @SneakyThrows
    public static String readTestFile(String path) {
        final var xmlFile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + path);
        return Files.readString(Path.of(xmlFile.getPath()));
    }

    public static BigDecimal randomBD() {
        return randomBD(BigDecimal.ZERO, new BigDecimal(100));
    }

    public static BigDecimal randomBD(BigDecimal from, BigDecimal to) {
        return randomBD(from, to, 2);
    }

    public static BigDecimal randomBD(BigDecimal from, BigDecimal to, int scale) {
        final var randomBigDecimal = from.add(BigDecimal.valueOf(Math.random()).multiply(to.subtract(from)));
        return randomBigDecimal.setScale(scale, RoundingMode.HALF_DOWN);
    }

    public static BigInteger randomBI() {
        return BigInteger.probablePrime(40, random);
    }

    public static <T extends Enum<?>> T randomEnum(Class<T> clazz) {
        int x = random.nextInt(clazz.getEnumConstants().length);
        return clazz.getEnumConstants()[x];
    }
}
