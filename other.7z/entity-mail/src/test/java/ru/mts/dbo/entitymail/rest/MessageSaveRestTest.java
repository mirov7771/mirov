package ru.mts.dbo.entitymail.rest;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import ru.mts.dbo.entitymail.ContextUtils;
import ru.mts.dbo.entitymail.backend.bank.service.MqRestApi;
import ru.mts.dbo.entitymail.backend.bank.util.BankMessageParser;
import ru.mts.dbo.entitymail.backend.dto.CustNotifAddNf;
import ru.mts.dbo.entitymail.connector.kafka.AccountInfoKafkaConnector;
import ru.mts.dbo.entitymail.connector.otp.OtpProperties;
import ru.mts.dbo.entitymail.connector.otp.SignCheckRequestResponseDto;
import ru.mts.dbo.entitymail.connector.otp.SignRequestResponseDto;
import ru.mts.dbo.entitymail.controller.dto.save.SaveResponse__1_0;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoRequest;
import ru.mts.dbo.entitymail.dto.kafka.save.AccountInfoResponse;
import ru.mts.dbo.entitymail.model.DbFile;
import ru.mts.dbo.entitymail.model.DbOtp;
import ru.mts.dbo.entitymail.model.Topics;
import ru.mts.dbo.entitymail.service.OtpService;
import ru.mts.dbo.entitymail.service.StorageService;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.*;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.atLeastOnce;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpStatus.OK;
import static ru.mts.dbo.entitymail.TestUtils.randomBI;
import static ru.mts.dbo.entitymail.error.FailureType.*;

public class MessageSaveRestTest extends BaseRestTest {

    @Autowired
    private Environment env;
    @Autowired
    private MqRestApi mqRestApi;
    @Autowired
    private OtpService otpService;
    @Autowired
    private StorageService storageService;
    @Autowired
    private OtpProperties otpProperties;
    @Autowired
    private BankMessageParser bankMessageParser;
    @Autowired
    private AccountInfoKafkaConnector accountInfoKafkaConnector;

    private static final String TEST_CONTROLLER_PATH = "TestOtpApiController";
    private static final String TEST_CHECK_PATH = "TestCheckApiController";

    @Value("${mq.feedback.from}")
    private String from;
    @Value("classpath:file/mts.png")
    private Resource resourceFilePng;
    @Value("classpath:file/mts.gif")
    private Resource resourceFileGif;
    @Value("classpath:file/mts.jpg")
    private Resource resourceFileJpg;
    @Value("classpath:file/mts.doc")
    private Resource resourceFileDoc;
    @Value("classpath:file/mtsmsoffice.doc")
    private Resource resourceFileDocMsoffice;
    @Value("classpath:file/mts.txt")
    private Resource resourceFileTxt;
    @Value("classpath:file/mts.odt")
    private Resource resourceFileOdt;
    @Value("classpath:file/mts.xls")
    private Resource resourceFileXls;
    @Value("classpath:file/mts.xlsx")
    private Resource resourceFileXlsx;
    @Value("classpath:file/mtsmsoffice.xlsx")
    private Resource resourceFileXLSXMsoffice;
    @Value("classpath:file/mts.ods")
    private Resource resourceFileOds;
    @Value("classpath:file/m ts.csv")
    private Resource resourceFileCsv;
    @Value("classpath:file/mts.rtf")
    private Resource resourceFileRtf;
    @Value("classpath:file/mts.jpeg")
    private Resource resourceFileJpeg;
    @Value("classpath:file/mts.docx")
    private Resource resourceFileDocx;
    @Value("classpath:file/mts.accdb")
    private Resource resourceFileAccdb;
    @Value("classpath:file/mts.zip")
    private Resource resourceFileZip;
    @Value("classpath:file/mtsEmpty.zip")
    private Resource resourceFileZipEmpty;
    @Value("classpath:file/mtsEncryption.zip")
    private Resource resourceFileZipEncryption;
    @Value("classpath:file/mts.odp")
    private Resource resourceFileOdp;
    @Value("classpath:file/mts.pptx")
    private Resource resourceFilePptx;
    @Value("classpath:file/mts.ppt")
    private Resource resourceFilePpt;
    @Value("classpath:file/mtsmsoffice.ppt")
    private Resource resourceFilePptMsoffice;
    @Value("classpath:file/mts.pdf")
    private Resource resourceFilePdf;
    @Value("classpath:file/mtsOversized.zip")
    private Resource resourceFileZipOversized;
    @Value("classpath:file/mts1.4mb.zip")
    private Resource resourceFileZip1_4mb;

    @Test
    public void save__1_0_ZipOversizedTest() throws IOException {
        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();

        ContextUtils.addContextOrganization(orgId);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001").setOrganizationId(randomBI()))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));
        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileZipOversized.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(SIZE_FILE_INVALID.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(SIZE_FILE_INVALID.getCode(), data.getErrorCode());
        assertEquals(SIZE_FILE_INVALID.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_PdfTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFilePdf.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_OTPErrorTest() throws IOException {
        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFilePdf.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(DOCUMENT_SIGN_PASSWORD_INVALID.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(DOCUMENT_SIGN_PASSWORD_INVALID.getCode(), data.getErrorCode());
        assertEquals(DOCUMENT_SIGN_PASSWORD_INVALID.getMessage(), data.getErrorMessage());

    }

    @Test
    public void save__1_0_OdpTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileOdp.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_PptTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFilePpt.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_PptMsofficeTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFilePptMsoffice.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_PptxTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var orgId = randomBI();

        final var accountNumber = randomNumeric(20);
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFilePptx.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_RtfTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();

        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileRtf.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_XlsTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileXls.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_XlsxTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileXlsx.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_XlsxMsofficeTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileXLSXMsoffice.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_OdsTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileOds.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_CsvTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileCsv.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_DocMsofficeTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileDocMsoffice.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_DocTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileDoc.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_TxtTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileTxt.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_OdtTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileOdt.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_DocxTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileDocx.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_PngTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFilePng.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_GifTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileGif.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_JpgTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_JpegTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileJpeg.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("002"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_31AttachmentTest() throws IOException {
        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001").setOrganizationId(randomBI()))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);


        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(SIZE_FILE_INVALID.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(SIZE_FILE_INVALID.getCode(), data.getErrorCode());
        assertEquals(SIZE_FILE_INVALID.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_AllAttachmentOversize30MbTest() throws IOException {
        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("attachments", new FileSystemResource(resourceFileZip1_4mb.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001").setOrganizationId(randomBI()))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));
        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(SIZE_FILE_INVALID.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(SIZE_FILE_INVALID.getCode(), data.getErrorCode());
        assertEquals(SIZE_FILE_INVALID.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_ZipTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileZip.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_ZipEmptyTest() throws IOException {
        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileZipEmpty.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());


        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(SIZE_FILE_INVALID.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(SIZE_FILE_INVALID.getCode(), data.getErrorCode());
        assertEquals(SIZE_FILE_INVALID.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_ZipPasswordTest() throws IOException {
        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileZipEncryption.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(ZIP_ENCRYPTION_ERROR.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(ZIP_ENCRYPTION_ERROR.getCode(), data.getErrorCode());
        assertEquals(ZIP_ENCRYPTION_ERROR.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_MimeTypeInvalidTest() throws IOException {
        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileAccdb.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(MIME_TYPE_INVALID.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(MIME_TYPE_INVALID.getCode(), data.getErrorCode());
        assertEquals(MIME_TYPE_INVALID.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_MessageAndAttachmentsIsNullTest() {
        final var url = getUrl__1_0();

        final var orgId = randomBI();
        final var accountNumber = randomNumeric(20);
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", "123");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(INVALID_FRONTEND_REQUEST.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(INVALID_FRONTEND_REQUEST.getCode(), data.getErrorCode());
        assertEquals(INVALID_FRONTEND_REQUEST.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_InvalidOrganizationTest() throws IOException {
        final var url = getUrl__1_0();

        final var accountNumber = randomNumeric(20);


        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileZipEncryption.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", "123");
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(ENTITY_NOT_FOUND.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(ENTITY_NOT_FOUND.getCode(), data.getErrorCode());
        assertEquals(ENTITY_NOT_FOUND.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_InvalidOTPTest() throws IOException {
        final var url = getUrl__1_0();

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileJpeg.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", "12345");
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001").setOrganizationId(randomBI()))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(ENTITY_NOT_FOUND.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(ENTITY_NOT_FOUND.getCode(), data.getErrorCode());
        assertEquals(ENTITY_NOT_FOUND.getMessage(), data.getErrorMessage());
    }

    @Test
    public void save__1_0_MessageNullTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("attachments", new FileSystemResource(resourceFileJpg.getFile()));
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_ANKETA.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001"))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.doReturn(Collections.singletonList(new DbFile().setFileName("test")
                .setOriginalFileName("test")
                .setSize(11L)
                .setType("jpg")
                .setUrl("share\\date\\messageId\\name")
                .setMessage(otpService.getOtp("1").get().getMessage())))
                .when(storageService).addFiles(Mockito.any(), Mockito.any(UUID.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_ANKETA.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_AttachmentsIsNullTest() throws IOException {
        final String bodyContentType = "text/html; charset=utf-8";

        final var url = getUrl__1_0();

        final var otp = new DbOtp().setOtpId("1")
                .setOtpValue("2")
                .setDateCreation(ZonedDateTime.now())
                .setSession("123")
                .setHash(RandomStringUtils.randomAlphanumeric(10, 128));

        otpService.save(otp);

        final var accountNumber = randomNumeric(20);
        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("accountNumber", accountNumber);
        body.add("topicId", Topics.TOPIC_SFM.name());
        body.add("otpId", otp.getOtpId());
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        Mockito.doReturn(new AccountInfoResponse().setInn("1234567890").setBranchId("001").setOrganizationId(randomBI()))
                .when(accountInfoKafkaConnector).getData(Mockito.any(AccountInfoRequest.class));

        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service()
                        .setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH)
                        .setCheckUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH + "/" + TEST_CHECK_PATH)
                );
        Mockito.doReturn(new ResponseEntity<>(new SignRequestResponseDto().setOtpId(UUID.randomUUID().toString()).setPhone(String.valueOf(4000 + new Random().nextInt(1000))), OK))
                .when(restTemplate).postForEntity(anyString(), any(HttpEntity.class), eq(SignRequestResponseDto.class));
        Mockito.doReturn(new ResponseEntity<>(new SignCheckRequestResponseDto().setResult(true), OK))
                .when(restTemplate).exchange(anyString(), eq(GET), any(HttpEntity.class), eq(SignCheckRequestResponseDto.class), anyMap());
        Mockito.doReturn(new ResponseEntity<>(new LinkedMultiValueMap<>(Map.of("ibm-mq-md-messageId", List.of(randomAlphabetic(10)))), HttpStatus.CREATED))
                .when(restTemplate).exchange(anyString(), eq(POST), any(HttpEntity.class), eq(String.class));

        var captor = ArgumentCaptor.forClass(String.class);
        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);
        assertNotNull(response);
        assertEquals(OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        Mockito.verify(mqRestApi, atLeastOnce()).send(anyString(), captor.capture(), anyString(), anyString());
        String xml = captor.getValue();
        assertNotNull(xml);

        CustNotifAddNf custNotifAddNf = bankMessageParser.parseXML(xml, CustNotifAddNf.class);

        assertNotNull(custNotifAddNf);
        assertNotNull(custNotifAddNf.getServerInfo());
        CustNotifAddNf.NotifInfo notifInfo = custNotifAddNf.getNotifInfo();
        assertNotNull(notifInfo);
        CustNotifAddNf.NotifInfo.EmailInfo emailInfo = notifInfo.getEmailInfo();
        assertNotNull(emailInfo);

        Topics.Email email = Topics.TOPIC_SFM.getEmails().get(0);

        assertEquals(env.getProperty("mq.feedback." + email.getEmail()), emailInfo.getTo());
        assertEquals(from, emailInfo.getFrom());
        assertEquals(bodyContentType, emailInfo.getBodyContentType());
        assertNull(emailInfo.getAttachInfo());
        assertNull(emailInfo.getBcc());
        assertNull(emailInfo.getCc());
        assertNull(emailInfo.getConnInfo());
        assertNull(emailInfo.getMultiPartContentType());
        assertNull(emailInfo.getReplyTo());
        assertEquals(email.getSubject(), emailInfo.getSubject());
    }

    @Test
    public void save__1_0_AccountNumberNullTest() {
        final var url = getUrl__1_0();

        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("topicId", Topics.TOPIC_SFM.name());
        body.add("otpId", "123");
        body.add("message", "test");
        body.add("pwd", "test");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<>(body, headers);

        final var response = testRestTemplate.postForEntity(url, request, SaveResponse__1_0.class);   assertNotNull(response);
        assertEquals(INVALID_FRONTEND_REQUEST.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(INVALID_FRONTEND_REQUEST.getCode(), data.getErrorCode());
        assertEquals("Номер счёта должен быть не пустым", data.getErrorMessage());
    }

    @Override
    protected String getMethod() {
        return "save";
    }

    @Override
    protected String getMethodBase() {
        return "message";
    }

    @TestConfiguration
    public static class MessageSaveRestTestConfiguration {

        @Bean
        @Primary
        public AccountInfoKafkaConnector getOrganizationInfoKafkaConnectorSpy(AccountInfoKafkaConnector accountInfoKafkaConnector) {
            return Mockito.spy(accountInfoKafkaConnector);
        }

        @Bean
        @Primary
        public StorageService getDfsServiceSpy(StorageService storageService) {
            return Mockito.spy(storageService);
        }
    }
}
