package ru.mts.dbo.entitymail.rest;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import ru.mts.dbo.entitymail.controller.dto.topics.TopicsResponse__1_0;
import ru.mts.dbo.entitymail.model.Topics;

import static org.junit.Assert.*;

public class TopicsListRestTest extends BaseRestTest {

    @Test
    public void list__1_0_Test() {
        final var url = getUrl__1_0();
        final var response = testRestTemplate.getForEntity(url, TopicsResponse__1_0.class);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var mailTopics = data.getMailtopics();
        assertNotNull(mailTopics);
        assertEquals(2, mailTopics.size());

        mailTopics.forEach(mailTopic -> {
            final var topic = Topics.valueOf(mailTopic.getId());
            assertEquals(topic.getTitle(), mailTopic.getTitle());
            assertEquals(topic.getDescription(), mailTopic.getHelp());
        });
    }

    @Override
    protected String getMethod() {
        return "list";
    }

    @Override
    protected String getMethodBase() {
        return "topics";
    }
}
