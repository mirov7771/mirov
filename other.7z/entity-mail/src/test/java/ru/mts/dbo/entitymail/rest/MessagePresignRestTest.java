package ru.mts.dbo.entitymail.rest;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import ru.mts.dbo.entitymail.ContextUtils;
import ru.mts.dbo.entitymail.connector.otp.OtpProperties;
import ru.mts.dbo.entitymail.connector.otp.SignRequestResponseDto;
import ru.mts.dbo.entitymail.controller.dto.presign.PresignRequest__1_0;
import ru.mts.dbo.entitymail.controller.dto.presign.PresignResponse__1_0;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.springframework.http.HttpStatus.OK;
import static ru.mts.dbo.entitymail.TestUtils.randomBI;

@Import(MessagePresignRestTest.TestOtpSignApiController.class)
public class MessagePresignRestTest extends BaseRestTest {
    private static final String TEST_CONTROLLER_PATH = "TestOtpApiController";

    @Autowired
    private OtpProperties otpProperties;

    @Test
    public void presign__1_0_Test() {
        Mockito.when(otpProperties.getService())
                .thenReturn(new OtpProperties.Service().setSignUrl("http://localhost:" + port + contextPath + "/" + TEST_CONTROLLER_PATH));

        final var url = getUrl__1_0();

        final var orgId = randomBI();
        ContextUtils.addContextOrganization(orgId);
        ContextUtils.setUserId(randomBI());

        final var request = new PresignRequest__1_0()
                .setMessageHash(RandomStringUtils.randomAlphanumeric(10, 128))
                .setOrganizationId(orgId);
        final var response = testRestTemplate.postForEntity(url, request, PresignResponse__1_0.class);
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var presignrequest = data.getPresignrequest();
        assertNotNull(presignrequest);
        assertNotNull(presignrequest.getOtpId());
        assertNotNull(presignrequest.getPhone());
        assertNull(presignrequest.getSmsNum());
    }

    @Override
    protected String getMethod() {
        return "presign";
    }

    @Override
    protected String getMethodBase() {
        return "message";
    }

    @Controller
    @RequestMapping(TEST_CONTROLLER_PATH)
    static class TestOtpSignApiController {
        @PostMapping
        @ResponseBody
        @ResponseStatus(OK)
        public SignRequestResponseDto receive(
                HttpServletRequest request
        ) throws IOException {

            Map<String, String> params = stringToMap(IOUtils.toString(request.getReader()));

            assertNotNull(params.get("document"));
            assertNotNull(params.get("session_id"));
            assertNotNull(params.get("text_sms"));
            assertNotNull(params.get("timestamp"));
            assertNotNull(params.get("user_id"));
            return new SignRequestResponseDto()
                    .setOtpId(UUID.randomUUID().toString())
                    .setPhone(RandomStringUtils.randomNumeric(4));
        }

        private Map<String, String> stringToMap(String params) {
            return Arrays.stream(params.split("&"))
                    .map(s -> s.split("="))
                    .collect(Collectors.toMap(s -> s[0], s -> s[1]));
        }
    }
}
