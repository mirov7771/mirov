package com.example.demo.gate;

import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class HumanFactorGate {

    private static String url;
    private final RestTemplate restTemplate;

    public HumanFactorGate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
        url = "http://factor-site-test:8080/suggestions/api/4_1/rs/suggest/address";
    }

    public Map<String, Object> execute(String address) {
        Map<String, Object> outputParams = new HashMap<>();
        if (!url.equals("none")) {
            JsonObject param = new JsonObject();
            param.addProperty("query", address);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> rq = new HttpEntity<>(param.toString(), headers);
            outputParams = restTemplate.postForObject(url, rq, HashMap.class);
        }
        return outputParams;
    }

    public <T> T call(Class<T> cls, String address) {
        if (!url.equals("none")) {
            JsonObject param = new JsonObject();
            param.addProperty("query", address);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> rq = new HttpEntity<>(param.toString(), headers);
            return restTemplate.postForObject(url, rq, cls);
        }
        return null;
    }


}
