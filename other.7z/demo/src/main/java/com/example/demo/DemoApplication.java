package com.example.demo;

import com.example.demo.config.ApplicationConfig;
import com.example.demo.crypt.EncryptorDecryptorImpl;
import com.example.demo.dao.TestRepository;
import com.example.demo.dao.model.Test;
import com.example.demo.gate.AddressBuilder;
import com.example.demo.gate.HumanFactorData;
import com.example.demo.gate.HumanFactorGate;
import com.example.demo.gate.MtsMoneyGateWay;
import com.example.demo.rest.gate.RestGate;
import com.example.demo.rest.gate.impl.RestGateImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import okhttp3.Headers;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.validation.constraints.Size;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@SpringBootApplication
public class DemoApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(DemoApplication.class);
	}
}

@RestController
@Slf4j
class Controller{

	@Autowired
	ApplicationConfig applicationConfig;

	@Autowired
	MtsGate mtsGate;

	@GetMapping(path = "/")
	public String getPass(){
		return applicationConfig.toString();
	}

	@GetMapping(path = "/check/{token}")
	public String getClientInfo(@PathVariable("token") String token) throws IOException {
		return mtsGate.getClientInfo(token);
	}

	@GetMapping(path = "/xor")
	public String xor(){
		String value = "ZME\u001eTYX^\u0015FX";
		String retVal = null;
		if (!StringUtils.isEmpty(value)) {
			String key = "mts-bank-platform";
			char[] decodedPhoneNumberChars = new char[value.length()];
			for (int i = 0; i < value.length(); i++) {
				decodedPhoneNumberChars[i] = (char) (value.charAt(i) ^ key.charAt(i % key.length()));
			}
			retVal = new String(decodedPhoneNumberChars);
		}
		return retVal;
	}

	private TestRepository testRepository;

	public Controller(TestRepository testRepository) {
		this.testRepository = testRepository;
	}

	ObjectMapper objectMapper = new ObjectMapper();

	@GetMapping(value = "/pass")
	public BigDecimal getPassHash() throws NoSuchAlgorithmException {
		Date curDate = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(curDate);
		cal.add(Calendar.SECOND, 120);
		Date time = cal.getTime();
		return BigDecimal.valueOf((double)time.getTime() / 8.64E7D).add(BigDecimal.valueOf(new Double("25569.0")));
	}

	@GetMapping(value = "/summ")
	public BigDecimal getSumm(@RequestParam("value") BigDecimal value){
		return value.setScale(0, RoundingMode.HALF_UP);
	}

	@GetMapping(value = "/data")
	public String getData(){
		String test = "22072025";
		String retVal = "";
		retVal = test.substring(test.length()-4);
		retVal += test.substring(2,4);
		return retVal;
	}

	@GetMapping(value = "/{fileName}")
	public void getJsFils(@PathVariable String fileName
						 ,HttpServletResponse response)
	{
		InputStream inputStream = null;
		OutputStream outputStream = null;
		response.setContentType("application/javascript");
		try{
			inputStream = getFileInputStream(MtsGate.class, "js", fileName);
			System.out.println("InputStream "+inputStream);
			outputStream = response.getOutputStream();
			IOUtils.copy(inputStream, outputStream);
		} catch (IOException e){
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(inputStream);
			IOUtils.closeQuietly(outputStream);
		}
	}

	@GetMapping(value = "/decrypt/{pass}")
	public String decrypt(@PathVariable("pass") String pass){
		return getHash(pass);
	}

	@GetMapping(value = "/app/{userId}")
	public ResponseEntity<?> sendRedirect(@PathVariable("userId") String userId) throws URISyntaxException {
		URI uri = new URI("https://redirect.appmetrica.yandex.com/serve/"+userId);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setLocation(uri);
		return new ResponseEntity<>(httpHeaders, HttpStatus.SEE_OTHER);
	}

	@GetMapping("/testnew")
	public String getText(){
		String var = "qxRTbieMW8NdjO+gXslSuDUIpYICYZFx3FR7Dweh+8SVQGnwVMHYg3dizBn9W9QRzssZJUFz9rMQkpamQRiDHOd0Vd9Dj3JbDRQXo6P4nRcZW8DcPSVUWNHa/ZigcJbk9396u8MneoXIdF5q717u7ID7JW2EwqA2YHvgd2zL1MQGuAFOre9QbIncr84KJ2Oyx34pHFhH7XqpTlCh+fyyqCGyp5u3AbBdF+rs37pzuamPpyX1XJVFsSPd+v15RQNYK7wxM44B1J+/ymHrVGCnceTpdWF9KipJ0uhhaB3fJL8YRHV758dFGa6S4IoZeoPwQiYa8M8Gt+PMTJBeV9g32w\\u003d\\u003d";
		return var;
	}

	private byte[] prepare(byte[] bytes){
		String s = new String(bytes);
		if (s.contains(","))
			s = s.substring(s.indexOf(",")+1);
		System.out.println("!!!!    "+s);
		return s.getBytes();
	}

	@GetMapping("/checkfile")
	public byte[] getFile() throws IOException {
		InputStream resourceAsStream =new FileInputStream(new File("C:\\Users\\amirov\\demo\\src\\main\\resources\\doc.txt"));
		System.out.println("!!!"+resourceAsStream);
		byte[] bytes = IOUtils.toByteArray(resourceAsStream);
		return Base64.getDecoder().decode(prepare(bytes));
	}

	public static InputStream getFileInputStream(Class cls, String path, String name) {
		System.out.println("path = "+path);
		System.out.println("name = "+name);
		return cls.getResourceAsStream(path+"/"+name);
	}

	public String getHash(String phrase) {
		try {
			return  Base64.getEncoder().encodeToString(MessageDigest.
					getInstance("SHA-1").digest(phrase.getBytes("ISO-8859-1")));
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return "Error!";
	}

	@Autowired
	private Authorize authorize;

	@GetMapping(value = "/authtest")
	public Response get() throws IOException {
		Response response = authorize.get();
		Headers headers = response.headers();

		System.out.println("!!!!!"+headers.toString());
		System.out.println("!!!!!"+response.code());
		System.out.println("!!!!!"+response.body().string());

		new SimpleHttp().get();

		return response;
	}

	@Autowired
	private CardSvcInq cardSvcInq;

	@GetMapping(value = "/cardsvc")
	public List<Map<String, String>> getCardSvc(){
		List<Map<String, String>> cardBalance = cardSvcInq.get();
		for(Map<String, String> map : cardBalance){
			if (!isEmpty(map.get("amount")))
					//&& isDigits(map.get("amount"))
			{
				BigDecimal amount = new BigDecimal(map.get("amount"));
				System.out.println("!!!!!!!!!!!!!!" + amount);
				break;
			}
		}
		return cardBalance;
	}

	public static boolean isEmpty(String str) {
		return str == null || str.length() == 0;
	}

	public static boolean isEmpty(CharSequence cs) {
		return cs == null || cs.length() == 0;
	}

	public static boolean isDigits(String str) {
		return isNumeric(str);
	}

	public static boolean isNumeric(CharSequence cs) {
		if (isEmpty(cs)) {
			return false;
		} else {
			int sz = cs.length();

			for(int i = 0; i < sz; ++i) {
				if (!Character.isDigit(cs.charAt(i))) {
					return false;
				}
			}

			return true;
		}
	}

	@GetMapping(value = "/getdate")
	public String checkDate(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS+SSSS");
		return sdf.format(new Date());
	}

	@Autowired
	private RestGate restGate;

	@GetMapping(value = "/gate")
	public String gate(){
		return restGate.call(String.class
				, "http://services-ump2-test.mbrd.ru:8080/dbo-otherbank-offer/"
		,"v1/getOffers/79517732177"
		,null
		,"GET");
	}


	private final ObjectMapper mapper = new ObjectMapper();

	@GetMapping(value = "/tokencheck")
	public String paramData(){
		return getSenderPam("Bearer v2.local.GpuSA7K4vZw4ogh27oiB_thZYcBB-b1GN8v6vTZ4rRj2lPOOYmNrkIDlb1cI3DeV7xbvKqAeeNhLbSAKs8a7woe8Ebh464a_6ZZYEvDaWK6lLEgo01ejP3AHw5rEQtfEdDncxbsAeRdW5bL3LX7rg0wci2ouMSLBmP1eh79W5nH6_s_qw1VBQL_O7zVoN6KGr6s-wscYab0BcUtGhm_cOXhDChfiieafYuO2jkF8yggd-TwwYxxyaPRYVkYHOft9Yv2TP4iUj4rg6pGBGCIz1QxUbEFaLk8z4n9tYObTlc_4aLaANjlwway3KGdP0OQ-1_VDeJ1smsO9rW2aitYe0ze5mNPpkZA3vn35ixBSk2Cl3r1HBFtKikF8.eyJ1c2VyX2lkIjoyMTE2NSwiY2xpZW50X2lkIjoidGVzdF9kZXNrdG9wX3YyIiwiZXhwaXJ5IjoiMjAyMC0xMi0wNFQxMzoyNDoyNloiLCJkdXJhdGlvbiI6MzAwLCJ1c2VyX2RhdGEiOnsicmJvX2lkIjoiMTk0NDMzNzMzNDkzIiwiaWJzb19pZCI6bnVsbCwicGhvbmVfbnVtYmVyIjoiWk1KXHUwMDE0W1hXUlx1MDAxNEFZIiwiZnVsbF9uYW1lIjp7ImZpcnN0X25hbWUiOiLQodCi0JDQndCY0KHQm9CQ0JIiLCJsYXN0X25hbWUiOiLQoSIsIm1pZGRsZV9uYW1lIjoi0JDQm9CV0JrQodCQ0J3QlNCg0J7QktCY0KcifSwib3JnYW5pemF0aW9ucyI6W10sImlzX2Z1bGx5X2lkZW50Ijp0cnVlfX0=")
				.toString();
	}

	private static final String key = "mts-bank-platform";

	@GetMapping(value = "/encryptXor")
	public String encryptXor(@RequestParam("val") String val) throws UnsupportedEncodingException {
		String outputString = "";
		int len = val.length();
		for (int i = 0; i < len; i++)
		{
			outputString = outputString +
					(char) (val.charAt(i) ^ key.charAt(i % key.length()));
		}

		String test = "{\"user_id\":3638,\"client_id\":\"mts-money-android-mtsid\",\"expiry\":\"2020-09-21T08:43:36Z\",\"duration\":600,\"user_data\":{\"rbo_id\":null,\"ibso_id\":null,\"phone_number\":\""+outputString+"\",\"full_name\":{\"first_name\":\"Руслан\",\"last_name\":\"З\",\"middle_name\":\"Фаизович\"},\"organizations\":[]}}";
		System.out.println("!!!!!! "+test);
		return Base64.getEncoder().encodeToString(test.getBytes("UTF-8"));
	}

	@GetMapping(value = "/decryptXor")
	public String decryptXor(@RequestParam("val") String val){
		String retVal = null;
		if (val != null) {
			String value = (String) val;
			if (!StringUtils.isEmpty(value)) {
				String key = "mts-bank-platform";
				char[] decodedPhoneNumberChars = new char[value.length()];
				for (int i = 0; i < value.length(); i++) {
					decodedPhoneNumberChars[i] = (char) (value.charAt(i) ^ key.charAt(i % key.length()));
				}
				retVal = new String(decodedPhoneNumberChars);
			}
		}
		return retVal;
	}

	@Autowired
	private AddressBuilder addressBuilder;

	@GetMapping(value = "/hf")
	private String hf(){
		return addressBuilder.call("Москва, Нарвская").toString();
	}

	@Autowired
	private MtsMoneyGateWay mtsMoneyGateWay;

	@GetMapping(value = "/money")
	private String money(){
		List<String> list = new ArrayList<>();
		list.add("214647740690");
		return mtsMoneyGateWay.execute("getAccountList",list);
	}

	private static final ObjectMapper mapper2 = new ObjectMapper();

	public static Long getRboIdFromToken(String token){
		Long ret = 0L;
		try {
			if (!isEmpty(token)) {
				String[] list = token.split("\\.");
				String lastPart = list[list.length - 1].replaceAll("-", "+").replaceAll("_", "/");
				String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
				Map<String, Object> outputParams;
				outputParams = mapper2.readValue(decodePart, Map.class);
				if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
					Map<String, Object> userData = (HashMap) outputParams.get("user_data");
					String rboId = (String) userData.get("rbo_id");
					if (!StringUtils.isEmpty(rboId) && isDigits(rboId))
						ret = Long.valueOf(rboId);
				}
			}
		} catch (IOException | IllegalArgumentException e){
			e.printStackTrace();
		}
		return ret;
	}

	@GetMapping(value = "getRboId")
	private Long getRboId(){
		return getRboIdFromToken("Bearer v2.local.suWF0MyTdNeGQzxs5yC4HPFnZblOQLLml2JQbO_vMIpTE7yBdFgBHHNEdDNIJr59x0GhGwG5CCimwTuOHQZ5lQ5zzOcAj722c2r0Ov1QcumkzXv0w13A2Nh2WpFyFB5RIxhzo8gW32cQYiV1CdookQ7UlTSTSwhJhe83H03R3kWEzS-5gSTp-c5R7e73JMOM2CwGoQhhEzjlG5IA57DQ0I4CwKLJhSFe7sylnUE4pUUmIV2yBLqaLCvvShUbLh5ppe43kU_cdqDQPOS1m0FUMo8Kuu-rmiQoZ1eD1XgALcQjQ2xjL9bffqQFDepLXZdmzdVpF9h4ZF4K_CFMBjw-MoKESUJPrDoG-WssGq1z22kjExFe43GGgs2gcOcH54BAmR8.eyJ1c2VyX2lkIjoxNTg5OCwiY2xpZW50X2lkIjoibXRzLW1vbmV5LWFuZHJvaWQtbXRzaWQiLCJleHBpcnkiOiIyMDIwLTExLTIzVDEwOjI4OjUxWiIsImR1cmF0aW9uIjo2MDAsInVzZXJfZGF0YSI6eyJyYm9faWQiOiI3MjkyNTA0MTczNSIsImlic29faWQiOm51bGwsInBob25lX251bWJlciI6IlpNQlx1MDAxNFVTW15cdTAwMWVDWiIsImZ1bGxfbmFtZSI6eyJmaXJzdF9uYW1lIjoi0JzQsNGA0LjRjyIsImxhc3RfbmFtZSI6ItCSIiwibWlkZGxlX25hbWUiOiLQktC40LrRgtC-0YDQvtCy0L3QsCJ9LCJvcmdhbml6YXRpb25zIjpbXSwiaXNfZnVsbHlfaWRlbnQiOnRydWV9fQ");
	}



	@GetMapping(value = "/utf")
	private String utf(){
		String tttt = "<ns2:SiteDataExchange xmlns:ns2=\"mbrd\">\n" +
				"    <mtsRequestId>Android-1045180</mtsRequestId>\n" +
				"    <messageId>ad07d1da-5f17-4cb4-9aff-72aa34b54b8d</messageId>\n" +
				"    <messageType>REGISTER_REQ_SITE</messageType>\n" +
				"    <messageDateTime>2020-12-14T14:26:05</messageDateTime>\n" +
				"    <SPName>MTS_EIP_UMP</SPName>\n" +
				"    <MsgReceiver>SIEBEL</MsgReceiver>\n" +
				"    <request>\n" +
				"        <client>\n" +
				"            <clientCommonData>\n" +
				"                <family>Корсакова</family>\n" +
				"                <name>Ирина</name>\n" +
				"                <fatherName>Геннадьевна</fatherName>\n" +
				"                <birthDate>1987-02-06</birthDate>\n" +
				"                <clientSex>Sx2</clientSex>\n" +
				"                <birthPlace>С. ТАМБОВКА ТАМБОВСКОГО Р-НА АМУРСКОЙ ОБЛ.</birthPlace>\n" +
				"                <citizenship>\n" +
				"                    <countryName>Россия</countryName>\n" +
				"                    <countryCode>643</countryCode>\n" +
				"                </citizenship>\n" +
				"                <martialStatus>FAMILY.STATUS.4</martialStatus>\n" +
				"                <educationStatus>EDUCATION.LEVEL.5</educationStatus>\n" +
				"                <statusIPDL>IPDL.4</statusIPDL>\n" +
				"                <dependents>2</dependents>\n" +
				"                <totalIncome>\n" +
				"                    <summa>65000.0</summa>\n" +
				"                    <currency>RUB</currency>\n" +
				"                </totalIncome>\n" +
				"                <total_experiance>179</total_experiance>\n" +
				"                <flag_allow_pass_BKI>true</flag_allow_pass_BKI>\n" +
				"                <flag_allow_pass_BKI_Date>2020-12-14</flag_allow_pass_BKI_Date>\n" +
				"                <flagAllowReceiveInfoFromBank>true</flagAllowReceiveInfoFromBank>\n" +
				"                <codeWord>юбки</codeWord>\n" +
				"                <flagChangeFIO>false</flagChangeFIO>\n" +
				"                <flagAllowPassOthersOrg>true</flagAllowPassOthersOrg>\n" +
				"            </clientCommonData>\n" +
				"            <clientListDocument>\n" +
				"                <clientDocument documentType=\"DOCTYPE.FIRST.1\" isActive=\"true\" isPrimary=\"true\">\n" +
				"                    <serial>1007</serial>\n" +
				"                    <number>018834</number>\n" +
				"                    <issueOrgCode>282-002</issueOrgCode>\n" +
				"                    <issueOrgName>УПРАВЛЕНИЕМ ВНУТРЕННИХ ДЕЛ ГОРОДА БЛАГОВЕЩЕНСКА</issueOrgName>\n" +
				"                    <issueDate>2007-02-11</issueDate>\n" +
				"                </clientDocument>\n" +
				"            </clientListDocument>\n" +
				"            <clientListAddress>\n" +
				"                <clientAddress addressType=\"ADDRESS.TYPE.1\">\n" +
				"                    <countryName>Российская Федерация</countryName>\n" +
				"                    <countryCode>643</countryCode>\n" +
				"                    <regionName>Амурская</regionName>\n" +
				"                    <regionCode>обл</regionCode>\n" +
				"                    <regionSocr>обл</regionSocr>\n" +
				"                    <districtName>Благовещенский</districtName>\n" +
				"                    <localityName>Амурская</localityName>\n" +
				"                    <streetName>Победы</streetName>\n" +
				"                    <house>3</house>\n" +
				"                    <flat>2</flat>\n" +
				"                    <zipCode>675520</zipCode>\n" +
				"                    <isKladr>false</isKladr>\n" +
				"                    <isMailAddress>true</isMailAddress>\n" +
				"                </clientAddress>\n" +
				"                <clientAddress addressType=\"ADDRESS.TYPE.2\">\n" +
				"                    <countryName>Российская Федерация</countryName>\n" +
				"                    <countryCode>643</countryCode>\n" +
				"                    <regionName>Амурская</regionName>\n" +
				"                    <regionCode>обл</regionCode>\n" +
				"                    <regionSocr>обл</regionSocr>\n" +
				"                    <cityName>Благовещенск</cityName>\n" +
				"                    <streetName>50 лет Октября</streetName>\n" +
				"                    <house>143</house>\n" +
				"                    <flat>16</flat>\n" +
				"                    <zipCode>675016</zipCode>\n" +
				"                    <isKladr>false</isKladr>\n" +
				"                    <isMailAddress>true</isMailAddress>\n" +
				"                </clientAddress>\n" +
				"            </clientListAddress>\n" +
				"            <clientListContact>\n" +
				"                <clientContact contactType=\"CONTACT.TYPE.1\" isPrimary=\"true\">+79146148678</clientContact>\n" +
				"                <clientContact contactType=\"CONTACT.TYPE.8\" isPrimary=\"false\">+7 963 818-41-43</clientContact>\n" +
				"            </clientListContact>\n" +
				"            <clientListWork>\n" +
				"                <clientWork workType=\"true\">\n" +
				"                    <employmentType>WORKACTIVITY.1</employmentType>\n" +
				"                    <fullName>ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ \"АТИК-ЕВРОАВТО\"</fullName>\n" +
				"                    <activityType>ACTIVITY.TYPE.SER.4</activityType>\n" +
				"                    <addresses>\n" +
				"                        <address addressType=\"ADDRESS.WRK.CHIEF\">\n" +
				"                            <countryName>Российская Федерация</countryName>\n" +
				"                            <countryCode>643</countryCode>\n" +
				"                            <regionName>Амурская</regionName>\n" +
				"                            <regionCode>обл</regionCode>\n" +
				"                            <regionSocr>обл</regionSocr>\n" +
				"                            <cityName>Благовещенск</cityName>\n" +
				"                            <streetName>Новотроицкое</streetName>\n" +
				"                            <house>12/1</house>\n" +
				"                            <zipCode>675028</zipCode>\n" +
				"                            <isKladr>false</isKladr>\n" +
				"                            <isMailAddress>true</isMailAddress>\n" +
				"                        </address>\n" +
				"                        <address addressType=\"ADDRESS.WRK.LEGAL\">\n" +
				"                            <countryName>Российская Федерация</countryName>\n" +
				"                            <countryCode>643</countryCode>\n" +
				"                            <regionName>Амурская</regionName>\n" +
				"                            <regionCode>обл</regionCode>\n" +
				"                            <regionSocr>обл</regionSocr>\n" +
				"                            <cityName>Благовещенск</cityName>\n" +
				"                            <streetName>Новотроицкое</streetName>\n" +
				"                            <house>12/1</house>\n" +
				"                            <zipCode>675028</zipCode>\n" +
				"                            <isKladr>false</isKladr>\n" +
				"                            <isMailAddress>true</isMailAddress>\n" +
				"                        </address>\n" +
				"                    </addresses>\n" +
				"                    <addForEmployment>\n" +
				"                        <worker>\n" +
				"                            <positionLevel>POSITION.LEVEL.3</positionLevel>\n" +
				"                            <startDate>02.2019</startDate>\n" +
				"                        </worker>\n" +
				"                    </addForEmployment>\n" +
				"                    <accountingPhone contactType=\"CONTACT.TYPE.7\">+7 416 277-80-00</accountingPhone>\n" +
				"                    <INNCompany>2801164276</INNCompany>\n" +
				"                </clientWork>\n" +
				"            </clientListWork>\n" +
				"        </client>\n" +
				"        <clientRequest>\n" +
				"            <clientRequestCommonData>\n" +
				"                <product>\n" +
				"                    <productType>NCPK.STANDARD</productType>\n" +
				"                    <productCode>НЦПК_Стандарт</productCode>\n" +
				"                    <creditPeriod>36</creditPeriod>\n" +
				"                    <currency>RUR</currency>\n" +
				"                    <requestSumma>60000.0</requestSumma>\n" +
				"                </product>\n" +
				"                <callback>\n" +
				"                    <callTime>CALLING.TIME.3</callTime>\n" +
				"                    <timeZone>CLIENT.TIME.ZONE.2</timeZone>\n" +
				"                </callback>\n" +
				"                <bankInfoSource>\n" +
				"                    <sourceOfInformation>SOURCE.OF.INFORMATION.17</sourceOfInformation>\n" +
				"                </bankInfoSource>\n" +
				"                <creditGoal>OtherTarget</creditGoal>\n" +
				"                <creditOtherGoal>иная цель</creditOtherGoal>\n" +
				"            </clientRequestCommonData>\n" +
				"        </clientRequest>\n" +
				"    </request>\n" +
				"    <questionnaireType>FULL</questionnaireType>\n" +
				"    <requestContinType>CC</requestContinType>\n" +
				"</ns2:SiteDataExchange>";
		ByteBuffer buffer = StandardCharsets.UTF_8.encode(tttt);

		String utf8EncodedString = StandardCharsets.UTF_8.decode(buffer).toString();

		okhttp3.RequestBody requestBody = RequestBody.create(okhttp3.MediaType.parse("application/xml; charset=utf-8"), tttt);
		return requestBody.toString();
	}

	private SenderPAM getSenderPam(String token) {
		SenderPAM senderPAM = new SenderPAM();
		try {
			String[] list = token.split("\\.");
			String lastPart = list[list.length - 1].replaceAll("-", "+").replaceAll("_", "/");
			String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
			Map<String, Object> outputParams;
			outputParams = mapper.readValue(decodePart, Map.class);
			if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
				Map<String, Object> userData = (HashMap) outputParams.get("user_data");
				if (userData.get("full_name") != null && userData.get("full_name") instanceof HashMap){
					Map<String, String> fullName = (HashMap) userData.get("full_name");
					String senderPam = fullName.get("first_name");
					String senderPamShort = fullName.get("first_name");
					if (!StringUtils.isEmpty(fullName.get("middle_name")))
						senderPam += " "+fullName.get("middle_name");
					if (!StringUtils.isEmpty(fullName.get("last_name"))) {
						senderPam += " " + fullName.get("last_name");
						senderPamShort += " " + fullName.get("last_name");
					}
					senderPAM.setSenderPam(senderPam);
					senderPAM.setSenderPamShort(senderPamShort);
				}
			}
		} catch (IOException e){
			return null;
		}
		return senderPAM;
	}

	@ToString
	@Getter @Setter
	private static class SenderPAM{
		private String senderPam;
		private String senderPamShort;
	}


	@Autowired
	private PDFFromFOP pdfFromFOP;

	@GetMapping(value = "/pdfdoc")
	public void createPdf(){
		pdfFromFOP.createPdf();
	}

}
