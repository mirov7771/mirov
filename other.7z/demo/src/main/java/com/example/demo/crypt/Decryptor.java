package com.example.demo.crypt;

import javax.validation.constraints.NotNull;

@FunctionalInterface
public interface Decryptor {
    byte[] decrypt(@NotNull byte[] plaintext);

    public static class DecryptException extends Exception {
        public DecryptException(Throwable cause) {
            this(null, cause);
        }

        public DecryptException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
