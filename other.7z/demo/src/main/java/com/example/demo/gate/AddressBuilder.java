package com.example.demo.gate;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

@Component
public class AddressBuilder {

    @Autowired
    private HumanFactorGate humanFactorGate;

    public Address call(String addr){
        HumanFactorData hf = humanFactorGate.call(HumanFactorData.class, addr);
        if (hf != null && !CollectionUtils.isEmpty(hf.getSuggestions())){
            Address address = new Address();
            HumanFactorData.Suggestions suggestion = hf.getSuggestions().get(0);
            address.setAddr(suggestion.getValue());
            if (suggestion.getData() != null){
                HumanFactorData.Suggestions.HfData data = suggestion.getData();
                address.setCountryName(data.getCountryName());
                address.setCountryCode(data.getCountryCode());
                address.setRegionName(data.getRegionName());
                address.setRegionCode(data.getRegionCode());
                address.setRegionSocr(data.getRegionCode());
                address.setDistrictName(data.getDistrictName());
                address.setCityName(data.getCityName());
                address.setLocalityName(data.getLocalityName());
                address.setStreetName(data.getStreetName());
                address.setHouse(data.getHouse());
                address.setBlock(data.getBlock());
                address.setBuilding(data.getBuilding());
                address.setZipCode(data.getZipCode());
                address.setFlat(data.getFlat());
            }
            return address;
        }
        return null;
    }

}
