package com.example.demo.crypt;

import java.io.*;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptorDecryptorImpl implements Encryptor, Decryptor {
    private static final String RSA_ALG_TYPE = "RSA/ECB/OAEPWithSHA1AndMGF1Padding";
    private static final String AES_ALG_TYPE = "AES/CBC/PKCS5PADDING";

    private static final String ALGORITHM = "RSA";
    private static final String KEYSTORE_TYPE = "PKCS12";

    private static final Base64.Encoder encoder = Base64.getEncoder();
    private static final Base64.Decoder decoder = Base64.getDecoder();

    @Override
    public byte[] encrypt(byte[] plaintext) {
        try {
            PublicKey cert = restorePublic();
            return encryptAndPack(cert, plaintext);
            //byte[] crpyt = encryptAndPack(cert, plaintext);
            //return encoder.encode(crpyt);
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public byte[] decrypt(byte[] ciphertextin) {
        try {
            //byte[] ciphertext = decoder.decode(ciphertextin);
            byte[] ciphertext = ciphertextin;
            PrivateKey privateKey = loadRsaKeyMaterial();
            byte[] aesKey = rsaDecrypt(privateKey, java.util.Arrays.copyOfRange(ciphertext, 0, 256));
            byte[] aesIv = java.util.Arrays.copyOfRange(ciphertext, 256, 256+16);
            return aesDecrypt(aesKey, aesIv, java.util.Arrays.copyOfRange(ciphertext, 256+16, ciphertext.length));
        } catch(Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private byte[] rsaDecrypt(PrivateKey key, byte[] ciphertext) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(RSA_ALG_TYPE);
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(ciphertext);
    }

    private byte[] aesDecrypt(byte[] aesKey, byte[] iv, byte[] cipherData) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
        SecretKeySpec skeySpec = new SecretKeySpec(aesKey, "AES");
        Cipher cipher = Cipher.getInstance(AES_ALG_TYPE);
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivParameterSpec);
        return cipher.doFinal(cipherData);
    }

    private byte[] encryptAndPack(PublicKey key, byte[] plaintext) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, KeyStoreException, IOException, FileNotFoundException, CertificateException, UnrecoverableEntryException, InvalidAlgorithmParameterException {
        SecretKey aesKey = generateAes256Key();
        AesEncryptResult aesData = aesEncrypt(aesKey, plaintext);
        byte[] aesKeyRsaEncrypted = rsaEncrypt(key, aesKey.getEncoded());

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        baos.write(aesKeyRsaEncrypted);
        baos.write(aesData.getIv());
        baos.write(aesData.getCiphertext());

        return baos.toByteArray();
    }

    private byte[] rsaEncrypt(PublicKey key, byte[] plaintext) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        Cipher cipher = Cipher.getInstance(RSA_ALG_TYPE);
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(plaintext);
    }

    private SecretKey generateAes256Key() throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);
        return keyGenerator.generateKey();
    }

    private byte[] randomBytes() {
        byte[] bytes = new byte[128/8];
        SecureRandom sc = new SecureRandom();
        sc.nextBytes(bytes);
        return bytes;
    }

    private AesEncryptResult aesEncrypt(SecretKey aesKey, byte[] plainData) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        Cipher cipher = Cipher.getInstance(AES_ALG_TYPE);

        byte[] iv = randomBytes();
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, new IvParameterSpec(iv));

        byte[] encrypted = cipher.doFinal(plainData);
        return new AesEncryptResult(iv, encrypted);
    }

    private static class AesEncryptResult {
        byte[] iv;
        byte[] ciphertext;

        public AesEncryptResult(byte[] iv, byte[] ciphertext) {
            this.iv = iv;
            this.ciphertext = ciphertext;
        }

        public byte[] getIv() {
            return iv;
        }

        public void setIv(byte[] iv) {
            this.iv = iv;
        }

        public byte[] getCiphertext() {
            return ciphertext;
        }

        public void setCiphertext(byte[] ciphertext) {
            this.ciphertext = ciphertext;
        }
    }

    private PublicKey restorePublic() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
        final String PUBLIC_KEY_FILE = "C:\\Users\\amirov\\demo\\src\\main\\resources\\private.key";
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
        byte[] ff = fileToKey(PUBLIC_KEY_FILE);
        EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(ff);
        return keyFactory.generatePublic(publicKeySpec);
    }

    private byte[] fileToKey(String file) throws IOException {
        BufferedReader pubIn = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        StringBuilder sb = new StringBuilder();
        String tmp;
        do {
            tmp = pubIn.readLine();
            if (tmp != null) {
                if (!tmp.contains("-----BEGIN PUBLIC KEY-----") && !tmp.contains("-----END PUBLIC KEY-----")) {
                    sb.append(tmp);
                }
            }
        } while (tmp != null);
        return decoder.decode(sb.toString());
    }

    private PrivateKey loadRsaKeyMaterial() throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException, UnrecoverableEntryException  {
        KeyStore ks = KeyStore.getInstance(KEYSTORE_TYPE);
        ks.load(EncryptorDecryptorImpl.class.getResourceAsStream("public.key"), "".toCharArray());
        KeyStore.PrivateKeyEntry rsaEntry = (KeyStore.PrivateKeyEntry)ks.getEntry("cn-am", new KeyStore.PasswordProtection("".toCharArray()));
        return rsaEntry.getPrivateKey();
    }

}
