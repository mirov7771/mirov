package com.example.demo.gate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
@Slf4j
public class MtsMoneyGateWay {

    private final RestTemplate restTemplate;
    private static String mtsUrl;

    public MtsMoneyGateWay(RestTemplate restTemplate){
        this.restTemplate = restTemplate;
        mtsUrl = "http://services-ump2-test.mbrd.ru:8090/mtsmoney-gateway/";
    }

    public String execute(String method, List<String> rboId) {
        StringBuilder url = new StringBuilder(mtsUrl + method);
        int sz = rboId.size();
        for(int i=0;i<sz;i++){
            if (i == 0)
                url.append("?");
            if (i < sz-1)
                url.append("bankClientId").append("=").append(rboId.get(i)).append("&");
            else
                url.append("bankClientId").append("=").append(rboId.get(i));
        }
        ResponseEntity<String> response = restTemplate.getForEntity(url.toString(), String.class);
        if (response.getStatusCodeValue() == 200)
            return response.getBody();
        return null;
    }

}
