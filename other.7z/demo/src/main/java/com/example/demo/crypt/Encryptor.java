package com.example.demo.crypt;

import javax.validation.constraints.NotNull;

@FunctionalInterface
public interface Encryptor {
    byte[] encrypt(@NotNull byte[] plaintext);

    public static class EncryptException extends Exception {
        public EncryptException(Throwable cause) {
            this(null, cause);
        }

        public EncryptException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
