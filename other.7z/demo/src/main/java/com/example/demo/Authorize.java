package com.example.demo;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class Authorize {

    public Response get() throws IOException {
        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        Request request = new Request.Builder()
                .url("http://sso-test.mbrd.ru:8090/api/authorize?response_type=code&client_id=dbo3_web&code_challenge_method=S256&scope=all&tid=0fc4bae1-440c-4a5d-5862-7069bef8f53c&state=315c6eeb-bbdd-4a12-bd4f-e81ead6edfb2&code_challenge=ypUSPUYaAYk5orjMdEqXqflnz5HvfnepkrBfNIYvYrY%253D")
                .method("GET", null)
                .addHeader("Host", "sso-test.mbrd.ru")
                .build();
        Response execute = client.newCall(request).execute();
        System.out.println("!!!!!"+execute.body().string());
        execute.close();
        return execute;
    }

}
