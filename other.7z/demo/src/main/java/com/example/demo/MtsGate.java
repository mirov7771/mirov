package com.example.demo;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class MtsGate {

    private final OkHttpClient httpClient = new OkHttpClient();

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public String getClientInfo(String token) throws IOException {
        String phone = null;
        String authorization = "Bearer "+token;
        Request request =new Request.Builder()
                .url("https://login.mts.ru/amserver/oauth2/api")
                .addHeader("Host","login.mts.ru")
                .addHeader("Accept-Encoding","application/json")
                .addHeader("Authorization",authorization)
                .get()
                .build();
        try(Response response = httpClient.newCall(request).execute()){
            if (response.isSuccessful() && response.body() != null){
                Map<String, Object> map;
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
                map = objectMapper.readValue(response.body().string(), Map.class);
                if (!map.isEmpty()) {
                    if (map.get("mobile:phone") != null)
                        phone = getString(map.get("mobile:phone"));
                    else if (map.get("phone_number") != null)
                        phone = getString(map.get("phone_number"));
                }
            }
        }
        return phone;
    }

    public static String getString(Object value) {
        if (value instanceof String)
            return (String) value;
        if (value instanceof Long){
            Long val = (Long) value;
            return val.toString();
        }
        if (value instanceof Integer){
            Integer val = (Integer) value;
            return val.toString();
        }
        return null;
    }

}
