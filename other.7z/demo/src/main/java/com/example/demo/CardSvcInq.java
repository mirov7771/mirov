package com.example.demo;

import com.example.demo.jaxb.XmlUnmarshaler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.NodeList;
import ru.mtsbank.integration.mts.xsd.DBOCust.cardsvcinqrs.CardSvcInqRs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class CardSvcInq {

    private static final String answer = "<FDX>\n" +
            "\t<ServerInfo>\n" +
            "\t\t<MsgUID>c267dfd7-136f-463f-80a9-62c2a3e2e876</MsgUID>\n" +
            "\t\t<RqUID>c267dfd7-136f-463f-80a9-62c2a3e2e876</RqUID>\n" +
            "\t\t<SPName>Processing</SPName>\n" +
            "\t\t<MsgReceiver>MTS_EIP_UMP</MsgReceiver>\n" +
            "\t\t<ServerDt>2020-11-30T09:47:18</ServerDt>\n" +
            "\t\t<MsgType>CardSvcInqRs</MsgType>\n" +
            "\t\t<BpId>c267dfd7-136f-463f-80a9-62c2a3e2e876</BpId>\n" +
            "\t</ServerInfo>\n" +
            "\t<BankSvcRs>\n" +
            "\t\t<ReturnData>\n" +
            "\t\t\t<Response>\n" +
            "\t\t\t\t<item>\n" +
            "\t\t\t\t\t<hashed_card>7C82BD796BDBDE7C7DE5A3C0DFEDD2EF1DC909F7</hashed_card>\n" +
            "\t\t\t\t\t<amount>61396.27</amount>\n" +
            "\t\t\t\t\t<credit>0.00</credit>\n" +
            "\t\t\t\t\t<locked>16760.30</locked>\n" +
            "\t\t\t\t\t<locked_d>16760.30</locked_d>\n" +
            "\t\t\t\t\t<locked_c>0.00</locked_c>\n" +
            "\t\t\t\t\t<currency>RUB</currency>\n" +
            "\t\t\t\t\t<expiry>2205</expiry>\n" +
            "\t\t\t\t\t<status>000</status>\n" +
            "\t\t\t\t\t<status_description>Approved</status_description>\n" +
            "\t\t\t\t\t<stop_code/>\n" +
            "\t\t\t\t\t<stop_code_description/>\n" +
            "\t\t\t\t\t<user_stop_code/>\n" +
            "\t\t\t\t\t<user_stop_code_description/>\n" +
            "\t\t\t\t\t<pin_counter>0</pin_counter>\n" +
            "\t\t\t\t\t<pin_initial>1</pin_initial>\n" +
            "\t\t\t\t\t<pin_chng_date>03.06.2019 18:51:26</pin_chng_date>\n" +
            "\t\t\t\t</item>\n" +
            "\t\t\t\t<item>\n" +
            "\t\t\t\t\t<hashed_card>74309A62BCA7C623561C2B93286C6F0010218C1C</hashed_card>\n" +
            "\t\t\t\t\t<amount>6665.80</amount>\n" +
            "\t\t\t\t\t<credit>0.00</credit>\n" +
            "\t\t\t\t\t<locked>-5265.80</locked>\n" +
            "\t\t\t\t\t<locked_d>0.00</locked_d>\n" +
            "\t\t\t\t\t<locked_c>-5265.80</locked_c>\n" +
            "\t\t\t\t\t<currency>RUB</currency>\n" +
            "\t\t\t\t\t<expiry>2110</expiry>\n" +
            "\t\t\t\t\t<status>000</status>\n" +
            "\t\t\t\t\t<status_description>Approved</status_description>\n" +
            "\t\t\t\t\t<stop_code/>\n" +
            "\t\t\t\t\t<stop_code_description/>\n" +
            "\t\t\t\t\t<user_stop_code/>\n" +
            "\t\t\t\t\t<user_stop_code_description/>\n" +
            "\t\t\t\t\t<pin_counter>0</pin_counter>\n" +
            "\t\t\t\t\t<pin_initial>1</pin_initial>\n" +
            "\t\t\t\t\t<pin_chng_date/>\n" +
            "\t\t\t\t</item>\n" +
            "\t\t\t\t<item>\n" +
            "\t\t\t\t\t<hashed_card>893FE247EF9F22892223AFD5434B166EEEC73100</hashed_card>\n" +
            "\t\t\t\t\t<amount>12.53</amount>\n" +
            "\t\t\t\t\t<credit>0.00</credit>\n" +
            "\t\t\t\t\t<locked>0.08</locked>\n" +
            "\t\t\t\t\t<locked_d>0.08</locked_d>\n" +
            "\t\t\t\t\t<locked_c>0.00</locked_c>\n" +
            "\t\t\t\t\t<currency>EUR</currency>\n" +
            "\t\t\t\t\t<expiry>2206</expiry>\n" +
            "\t\t\t\t\t<status>000</status>\n" +
            "\t\t\t\t\t<status_description>Approved</status_description>\n" +
            "\t\t\t\t\t<stop_code/>\n" +
            "\t\t\t\t\t<stop_code_description/>\n" +
            "\t\t\t\t\t<user_stop_code/>\n" +
            "\t\t\t\t\t<user_stop_code_description/>\n" +
            "\t\t\t\t\t<pin_counter>0</pin_counter>\n" +
            "\t\t\t\t\t<pin_initial>1</pin_initial>\n" +
            "\t\t\t\t\t<pin_chng_date/>\n" +
            "\t\t\t\t</item>\n" +
            "\t\t\t</Response>\n" +
            "\t\t</ReturnData>\n" +
            "\t\t<Status>\n" +
            "\t\t\t<StatusCode>0</StatusCode>\n" +
            "\t\t\t<Severity>Info</Severity>\n" +
            "\t\t</Status>\n" +
            "\t</BankSvcRs>\n" +
            "</FDX>";

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    public List<Map<String, String>> get(){
        CardSvcInqRs cardSvcInqRs = xmlUnmarshaler.parse(CardSvcInqRs.class, answer);
        List<Map<String, String>> cardsToCount = new ArrayList<>();
        if (cardSvcInqRs != null
                && cardSvcInqRs.getBankSvcRs() != null
                && cardSvcInqRs.getBankSvcRs().getReturnData() != null
                && cardSvcInqRs.getBankSvcRs().getReturnData().getResponse() != null)
        {
            org.w3c.dom.Element elementExtInfo = (org.w3c.dom.Element) cardSvcInqRs.getBankSvcRs().getReturnData().getResponse();
            if (elementExtInfo.getChildNodes() != null){
                NodeList childNodes = elementExtInfo.getChildNodes();

                for(int i=0; i<childNodes.getLength(); i++) {
                    if (childNodes.item(i) instanceof org.w3c.dom.Element) {
                        org.w3c.dom.Element node = (org.w3c.dom.Element) childNodes.item(i);
                        Map<String, String> map = new HashMap<>();
                        for(int j=0; j<node.getChildNodes().getLength();j++) {
                            if (node.getChildNodes().item(j) instanceof org.w3c.dom.Element) {
                                org.w3c.dom.Element childNode = (org.w3c.dom.Element) node.getChildNodes().item(j);
                                if ("amount".equalsIgnoreCase(childNode.getTagName())) {
                                    map.put("amount", childNode.getTextContent());
                                } else if ("hashed_card".equalsIgnoreCase(childNode.getTagName())) {
                                    map.put("hashed_card", childNode.getTextContent());
                                } else if ("currency".equalsIgnoreCase(childNode.getTagName())) {
                                    map.put("currency", childNode.getTextContent());
                                }
                            }
                        }
                        cardsToCount.add(map);
                    }
                }
            }
        }
        return cardsToCount;
    }

}
