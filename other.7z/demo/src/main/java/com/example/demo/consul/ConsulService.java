package com.example.demo.consul;

import com.ecwid.consul.v1.ConsulClient;
import com.ecwid.consul.v1.Response;
import com.ecwid.consul.v1.kv.model.GetValue;
import com.example.demo.config.ApplicationConfig;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException;

@Service
@Slf4j
public class ConsulService {

    private ConsulClient client;
    private final ApplicationEventPublisher applicationEventPublisher;

    @Value("${app.name}")
    private String appName;
    @Value("${app.key}")
    private String appKey;

    public ConsulService(ApplicationEventPublisher applicationEventPublisher) {
        this.applicationEventPublisher = applicationEventPublisher;
    }

    @PostConstruct
    private void init() {
        String consulHost = System.getenv("consul_host");
        String[] consulHostAndPort = consulHost.split(":");
        String consulHostName = consulHostAndPort[0];
        int consulPort = Integer.parseInt(consulHostAndPort[1]);
        client = new ConsulClient(consulHostName, consulPort);
    }

    @Bean
    public ApplicationConfig getApplicationConfig(){
        return loadApplicationConfigByKey();
    }

    private ApplicationConfig loadApplicationConfigByKey() {
        String consulPrefix = System.getenv("consul_config_path");
        String consulToken = System.getenv("consul_config_acl_token");
        String consulPath = consulPrefix + "/" + appKey+"/"+appName+"/application";
        log.info("*** consul env "+consulPath+" / "+consulToken);
        ApplicationConfig config = null;
        try{
            Response<GetValue> kvValue = client.getKVValue(consulPath, consulToken);
            String consulValue = kvValue.getValue().getDecodedValue();
            if (consulValue != null) {
                config = buildConfig(consulValue);
            }
        } catch (NullPointerException | IOException e) {
            log.error("Unable to load consul data for: {}", consulPath);
            e.printStackTrace();
        }
        return config;
    }

    public ApplicationConfig buildConfig(String json) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        ApplicationConfig applicationConfig = objectMapper.readValue(json, new TypeReference<ApplicationConfig>() {});
        return applicationConfig;
    }

}
