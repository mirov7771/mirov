package com.example.demo;


import java.io.IOException;
import java.net.HttpCookie;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

public class SimpleHttp {

    public void get() throws IOException {
        URL url = new URL("http://sso-test.mbrd.ru:8090/api/authorize?response_type=code&client_id=dbo3_web&code_challenge_method=S256&scope=all&tid=0fc4bae1-440c-4a5d-5862-7069bef8f53c&state=315c6eeb-bbdd-4a12-bd4f-e81ead6edfb2&code_challenge=ypUSPUYaAYk5orjMdEqXqflnz5HvfnepkrBfNIYvYrY%253D");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.connect();
        int responseCode = con.getResponseCode();
        String cookiesHeader = con.getHeaderField("Set-Cookie");
        System.out.println("!!!!!!!"+cookiesHeader);
        System.out.println("!!!!!!!"+responseCode);
    }

}
