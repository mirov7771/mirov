window.onload = function() {

    setInterval(function () {$('.scroller').trigger('sizeChange')}, 1500)//костыль. нужно инициализировать скролл при загрузке основной области.

	$('.panel').on('shown.bs.collapse hidden.bs.collapse ', function () {
		$('.scroller').trigger('sizeChange');
	})

	/*
	$('.panel').on('hide.bs.collapse', function () {
		
		$(this).children('.panel-heading').addClass('collapsed');
		console.log($(this).children('.panel-title'));
	})
	$('.panel').on('show.bs.collapse', function () {
		$(this).children('.panel-heading').removeClass('collapsed');
		
	})*/

	$('.sidebar-menu .close-button').on('click', function () {
        $('body').toggleClass('tech-menu-show');
		
	})

    $('.menu-button a').on('click', function () {
        $('body').toggleClass('tech-menu-show');

    })



	
};
$( document ).ready(function() {

    $('textarea.code').each(function(){
        var e = ace.edit(this);
        e.setTheme("ace/theme/chrome");
        e.getSession().setMode("ace/mode/javascript");
        e.setOptions({
            maxLines: Infinity
        });
    });


    $("body").tooltip({ selector: '[data-toggle=tooltip]', container: 'body'});

    $( ".scroller:not([data-baron-v])" ).each(function( index ) {
        $(this).baron({
            scroller: $(this),
            bar: $(this).children('.scroller-track').children('.scroller-bar'),
            barOnCls: 'baron'
        });
    });


/*
    $('.baron-ini:not(.baron)').baron({
        root: '.baron-ini',
        scroller: '.scroller',
        bar: '.scroller__bar',
        barOnCls: 'baron'
    });*/
/*
    window.left = baron({
        root: '.wrapper_1',
        scroller: '.scroller',
        bar: '.scroller__bar',
        barOnCls: 'baron'
    }).fix({
        elements: '.header__title',
        outside: 'header__title_state_fixed',
        before: 'header__title_position_top',
        after: 'header__title_position_bottom',
        clickable: true
    }).pull({
        block: '.load',
        elements: [{
            self: '.load__value',
            property: 'width'
        }],
        limit: 115,
        onExpand: function() {
            $('.load').css('background', 'red');
        }
    });



    window.right = baron({
        root: '.wrapper_2',
        scroller: '.scroller',
        bar: '.scroller__bar',
        barOnCls: 'baron'
    }).fix({
        elements: '.header__title',
        outside: 'header__title_state_fixed',
        before: 'header__title_position_top',
        after: 'header__title_position_bottom',
        clickable: true
    }).pull({
        block: '.load',
        elements: [{
            self: '.load__value',
            property: 'width'
        }],
        limit: 115,
        onExpand: function() {
            $('.load').css('background', 'red');
        }
    });

    window.center = baron({
        root: '.wrapper_3',
        scroller: '.scroller',
        bar: '.scroller__bar',
        barOnCls: 'baron'
    }).fix({
        elements: '.header__title',
        outside: 'header__title_state_fixed',
        before: 'header__title_position_top',
        after: 'header__title_position_bottom',
        clickable: true
    }).pull({
        block: '.load',
        elements: [{
            self: '.load__value',
            property: 'width'
        }],
        limit: 115,
        onExpand: function() {
            $('.load').css('background', 'red');
        }
    });
*/
});