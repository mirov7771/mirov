package ru.mts.dbo.entityoptions.rest;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import ru.mts.dbo.entityoptions.ContextUtils;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseResponse;
import ru.mts.dbo.entityoptions.controller.dto.block.BlockRequest__1_0;
import ru.mts.dbo.entityoptions.controller.rest.BlockController;
import ru.mts.dbo.entityoptions.model.Block;
import ru.mts.dbo.entityoptions.repo.BlockRepository;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;
import static org.junit.Assert.*;
import static ru.mts.dbo.entityoptions.TestUtils.randomBI;
import static ru.mts.dbo.entityoptions.error.FailureType.INVALID_FRONTEND_REQUEST;

public class BlockControllerBlockRestTest extends BaseRestTest {

    @Autowired
    private BlockRepository repository;

    @Test
    public void ContextLoads() {
        assertNotNull(context.getBean(BlockController.class));
    }

    @Test
    public void block__1_0_Test() {
        final var url = getUrl__1_0();

        final var block = new Block().setId("mainpage.credits.visible")
                .setUserId(randomBI().toString())
                .setState(1);

        repository.save(block);

        ContextUtils.setContextOrganization(block.getUserId());

        final var request = new BlockRequest__1_0().setId(block.getId())
                .setState(5);

        final var response = testRestTemplate.postForEntity(url, request, BaseResponse.class);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());
    }

    @Test
    public void block__1_0_UserNotFoundTest() {
        final var url = getUrl__1_0();

        ContextUtils.setContextOrganization(randomAlphabetic(10));

        final var request = new BlockRequest__1_0().setId(randomAlphabetic(10))
                .setState(Integer.parseInt(randomNumeric(2)));

        final var response = testRestTemplate.postForEntity(url, request, BaseResponse.class);

        assertNotNull(response);
        assertEquals(INVALID_FRONTEND_REQUEST.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(INVALID_FRONTEND_REQUEST.getCode(), data.getErrorCode());
        assertEquals(INVALID_FRONTEND_REQUEST.getMessage(), data.getErrorMessage());
    }

    @Override
    protected String getMethodBase() {
        return "";
    }

    @Override
    protected String getMethod() {
        return "block";
    }
}
