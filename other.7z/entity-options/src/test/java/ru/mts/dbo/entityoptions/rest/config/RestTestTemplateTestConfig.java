package ru.mts.dbo.entityoptions.rest.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import ru.mts.dbo.entityoptions.Context;

import javax.annotation.PostConstruct;
import java.util.Base64;

import static ru.mts.dbo.entityoptions.controller.RestCommons.BEARER_PART_NAME;
import static ru.mts.dbo.entityoptions.controller.RestCommons.TOKEN_HEADER_NAME;
import static ru.mts.dbo.entityoptions.rest.config.RestTestTemplateTestConfig.DISABLE;


@Configuration
@Profile("!" + DISABLE)
@ConditionalOnWebApplication
public class RestTestTemplateTestConfig {
    public static final String DISABLE = "DISABLE_USER_DATE";

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    @PostConstruct
    public void initRestTemplate() {
        testRestTemplate.getRestTemplate().getInterceptors().add((request, body, execution) -> {
            request.getHeaders().add(TOKEN_HEADER_NAME,
                    BEARER_PART_NAME
                            + " "
                            + RandomStringUtils.randomAlphabetic(10) + "."
                            + Base64.getUrlEncoder().encodeToString(objectMapper.writeValueAsString(Context.getUserData()).getBytes()));
            return execution.execute(request, body);
        });
    }
}
