package ru.mts.dbo.entityoptions.persistence.repo;


import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.EntityNotFoundException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@DataJpaTest
@RunWith(SpringRunner.class)
@AutoConfigureEmbeddedDatabase
public abstract class AbstractRepoTest<T, ID> {
    @Autowired
    protected EntityManager entityManager;
    @Autowired
    protected JpaRepository<T, ID> repository;

    @Test
    public void saveOneTest() {
        final var entity = generateOneEntity();
        final var savedEntity = repository.save(entity);
        assertNotNull(savedEntity);
        assertNotNull(extractId(savedEntity));
    }

    @Test
    @Transactional
    public void findOneTest() {
        final var entity = generateOneEntity();
        final var savedEntity = repository.save(entity);
        assertNotNull(savedEntity);
        assertNotNull(extractId(savedEntity));
        final var found = repository.findById(extractId(savedEntity))
                .orElseThrow(EntityNotFoundException::new);
        assertNotNull(found);
        assertEquals(found, savedEntity);
    }

    abstract T generateOneEntity();

    abstract ID extractId(T entity);
}
