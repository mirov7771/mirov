package ru.mts.dbo.entityoptions.rest.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.web.client.RestTemplate;
import ru.mts.dbo.entityoptions.Context;

import javax.annotation.PostConstruct;

import static java.util.Optional.ofNullable;

@Configuration
@ConditionalOnWebApplication
public class RestTemplateSessionConfig {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @PostConstruct
    public void initRestTemplate() {
        final ClientHttpRequestInterceptor cookieInterceptor = (request, body, execution) -> {
            ofNullable(Context.getSessionId())
                    .ifPresent(sessionId -> request.getHeaders().add(HttpHeaders.COOKIE, "JSESSIONID=" + sessionId));
            final var response = execution.execute(request, body);
            ofNullable(response.getHeaders().getFirst(HttpHeaders.SET_COOKIE))
                    .map(cookie -> cookie.substring("JSESSIONID=".length(), cookie.indexOf(";")))
                    .ifPresent(Context::setSessionId);
            return response;
        };

        restTemplate.getInterceptors().add(cookieInterceptor);

        testRestTemplate.getRestTemplate().getInterceptors().add(cookieInterceptor);
    }
}
