package ru.mts.dbo.entityoptions.rest;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import ru.mts.dbo.entityoptions.ContextUtils;
import ru.mts.dbo.entityoptions.controller.dto.blocks.BlocksResponse__1_0;
import ru.mts.dbo.entityoptions.controller.rest.BlockController;
import ru.mts.dbo.entityoptions.model.Block;
import ru.mts.dbo.entityoptions.repo.BlockRepository;

import java.util.List;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.junit.Assert.*;
import static ru.mts.dbo.entityoptions.TestUtils.randomBI;
import static ru.mts.dbo.entityoptions.error.FailureType.INVALID_FRONTEND_REQUEST;

public class BlockControllerBlocksRestTest extends BaseRestTest {

    @Autowired
    private BlockRepository repository;

    @Test
    public void ContextLoads() {
        assertNotNull(context.getBean(BlockController.class));
    }

    @Test
    public void blocks__1_0_Test() {
        final var url = getUrl__1_0();

        final var block1 = new Block().setId("mainpage.credits.visible")
                .setUserId(randomBI().toString())
                .setState(1);

        final var block2 = new Block().setId("mainpage.credits.test")
                .setUserId(block1.getUserId())
                .setState(4);

        repository.saveAll(List.of(block1, block2));

        ContextUtils.setContextOrganization(block1.getUserId());


        final var response = testRestTemplate.getForEntity(url + "?filter=mainpage.credits", BlocksResponse__1_0.class);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var bloks = data.getBlocksList();
        assertNotNull(bloks);
        assertEquals(2, bloks.size());

        final var block1_1Optional = bloks.stream().filter(block -> block.getId().equals(block1.getId())).findFirst();
        assertTrue(block1_1Optional.isPresent());
        final var blocks1_1 = block1_1Optional.get();
        assertEquals(block1.getId(), blocks1_1.getId());
        assertEquals(block1.getState(), blocks1_1.getState());

        final var block2_2Optional = bloks.stream().filter(block -> block.getId().equals(block2.getId())).findFirst();
        assertTrue(block2_2Optional.isPresent());
        final var blocks2_2 = block2_2Optional.get();
        assertEquals(block2.getId(), blocks2_2.getId());
        assertEquals(block2.getState(), blocks2_2.getState());
    }

    @Test
    public void blocks__1_0_FilterTest() {
        final var url = getUrl__1_0();

        final var block1 = new Block().setId("mainpage.credits.visible")
                .setUserId(randomBI().toString())
                .setState(1);

        final var block2 = new Block().setId("mainpage.credits.test")
                .setUserId(block1.getUserId())
                .setState(4);

        repository.saveAll(List.of(block1, block2));

        ContextUtils.setContextOrganization(block1.getUserId());


        final var response = testRestTemplate.getForEntity(url + "?filter=mainpage.credits.visible", BlocksResponse__1_0.class);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(0, data.getErrorCode());
        assertNull(data.getErrorMessage());

        final var bloks = data.getBlocksList();
        assertNotNull(bloks);
        assertEquals(1, bloks.size());

        final var block1_1Optional = bloks.stream().filter(block -> block.getId().equals(block1.getId())).findFirst();
        assertTrue(block1_1Optional.isPresent());
        final var blocks1_1 = block1_1Optional.get();
        assertEquals(block1.getId(), blocks1_1.getId());
        assertEquals(block1.getState(), blocks1_1.getState());
    }

    @Test
    public void blocks__1_0_FilterNullTest() {
        final var url = getUrl__1_0();

        final var block1 = new Block().setId("mainpage.credits.visible")
                .setUserId(randomBI().toString())
                .setState(1);

        final var block2 = new Block().setId("mainpage.credits.test")
                .setUserId(block1.getUserId())
                .setState(4);

        repository.saveAll(List.of(block1, block2));

        ContextUtils.setContextOrganization(block1.getUserId());


        final var response = testRestTemplate.getForEntity(url, BlocksResponse__1_0.class);

        assertNotNull(response);
        assertEquals(INVALID_FRONTEND_REQUEST.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(INVALID_FRONTEND_REQUEST.getCode(), data.getErrorCode());
        assertEquals("Не указано условие filter", data.getErrorMessage());
    }

    @Test
    public void blocks__1_0_UserNotFoundTest() {
        final var url = getUrl__1_0();

        final var block1 = new Block().setId("mainpage.credits.visible")
                .setUserId(randomBI().toString())
                .setState(1);

        final var block2 = new Block().setId("mainpage.credits.test")
                .setUserId(block1.getUserId())
                .setState(4);

        repository.saveAll(List.of(block1, block2));

        ContextUtils.setContextOrganization(randomAlphabetic(10));

        final var response = testRestTemplate.getForEntity(url + "?filter=mainpage.credits", BlocksResponse__1_0.class);

        assertNotNull(response);
        assertEquals(INVALID_FRONTEND_REQUEST.getHttpStatus(), response.getStatusCode());

        final var data = response.getBody();
        assertNotNull(data);
        assertEquals(INVALID_FRONTEND_REQUEST.getCode(), data.getErrorCode());
        assertEquals(INVALID_FRONTEND_REQUEST.getMessage(), data.getErrorMessage());
    }

    @Override
    protected String getMethodBase() {
        return "";
    }

    @Override
    protected String getMethod() {
        return "blocks";
    }
}
