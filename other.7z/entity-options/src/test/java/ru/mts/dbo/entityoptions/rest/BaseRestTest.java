package ru.mts.dbo.entityoptions.rest;

import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContext;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.mts.dbo.entityoptions.Context;


@RunWith(SpringRunner.class)
@AutoConfigureEmbeddedDatabase
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public abstract class BaseRestTest {
    @LocalServerPort
    protected int port;
    @Value("#{servletContext.contextPath}")
    protected String contextPath;
    @Autowired
    protected ApplicationContext context;
    @Autowired
    protected RestTemplate restTemplate;
    @Autowired
    protected TestRestTemplate testRestTemplate;

    @Before
    public void setup() {
        Context.clearContext();
        Mockito.reset(restTemplate);
    }

    protected String getUrl(String base, String method, String version) {
        return getUrl(base, getMethodSegment(), method, version);
    }

    protected String getUrl(String base, String segment, String method, String version) {
        return UriComponentsBuilder.fromUriString("http://localhost/entity-options/")
                .port(port)
                .path(contextPath)
                .pathSegment(base, segment, version, getClient(), method)
                .toUriString();
    }

    protected String getUrl(String method, String version) {
        return getUrl(getMethodBase(), method, version);
    }

    protected String getUrl(String version) {
        return getUrl(getMethod(), version);
    }

    protected String getUrl__1_0() {
        return getUrl("1.0");
    }

    protected String getUrl__1_1() {
        return getUrl("1.1");
    }

    protected String getUrl__1_2() {
        return getUrl("1.2");
    }

    protected String getUrl__1_3() {
        return getUrl("1.3");
    }

    protected String getUrl__1_4() {
        return getUrl("1.4");
    }

    protected String getUrl__1_5() {
        return getUrl("1.5");
    }

    protected String getMethodBase() {
        return "test";
    }

    protected String getMethodSegment() {
        return null;
    }

    protected String getMethod() {
        return "test";
    }

    protected String getClient() {
        return "test";
    }
}
