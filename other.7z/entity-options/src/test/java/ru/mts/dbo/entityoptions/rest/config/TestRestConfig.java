package ru.mts.dbo.entityoptions.rest.config;


import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

@Configuration
@ConditionalOnWebApplication
public class TestRestConfig {
    @Bean
    @Primary
    public RestTemplate restTemplate() {
        return Mockito.spy(new RestTemplate());
    }

    @Bean
    @Primary
    public TestRestTemplate testRestTemplate() {
        return Mockito.spy(new TestRestTemplate());
    }
}
