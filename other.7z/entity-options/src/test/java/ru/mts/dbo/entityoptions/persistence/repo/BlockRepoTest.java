package ru.mts.dbo.entityoptions.persistence.repo;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import ru.mts.dbo.entityoptions.model.Block;
import ru.mts.dbo.entityoptions.repo.BlockRepository;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang3.RandomStringUtils.randomNumeric;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class BlockRepoTest extends AbstractRepoTest<Block, String> {
    @Autowired
    private BlockRepository repository;

    @Test
    public void findByUserIdAndIdIgnoreCaseStartingWithTest() {
        final var saved = repository.save(generateOneEntity());
        final var found = repository.findByUserIdAndIdIgnoreCaseStartingWith(
                saved.getUserId(),
                saved.getId()
        );
        assertNotNull(found);
        assertEquals(1, found.size());
        final var bank = found.iterator().next();
        assertNotNull(bank);
        assertEquals(saved, bank);
    }

    @Test
    public void findByIdAndUserIdTest() {
        final var saved = repository.save(generateOneEntity());
        final var found = repository.findByIdAndUserId(saved.getId(), saved.getUserId());
        assertNotNull(found);
        assertEquals(saved, found.get());
    }

    @Override
    Block generateOneEntity() {
        final var bank = new Block();
        bank.setId(randomAlphabetic(128));
        bank.setUserId(randomNumeric(250));
        bank.setState(Integer.parseInt(randomNumeric(2)));
        return bank;
    }

    @Override
    String extractId(Block entity) {
        return entity.getId();
    }
}
