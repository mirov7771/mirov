CREATE TABLE IF NOT EXISTS T_BLOCKS
(
    id      varchar(128) PRIMARY KEY,   -- Идентификатор блока
    user_id varchar(250) NOT NULL,      -- Идентификатор владельца
    state   numeric(2)   NULL DEFAULT 1 -- Состояние блока и расположение
)
;

COMMENT ON TABLE T_BLOCKS
    IS 'Перечень блоков'
;

COMMENT ON COLUMN T_BLOCKS.id
    IS 'Идентификатор блока'
;

COMMENT ON COLUMN T_BLOCKS.user_id
    IS 'Идентификатор владельца'
;

COMMENT ON COLUMN T_BLOCKS.state
    IS 'Состояние блока и расположение'
;