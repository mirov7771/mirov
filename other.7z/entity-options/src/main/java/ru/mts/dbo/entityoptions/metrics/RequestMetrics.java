package ru.mts.dbo.entityoptions.metrics;

import io.prometheus.client.Counter;
import io.prometheus.client.Histogram;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;

@Slf4j
@UtilityClass
class RequestMetrics {
    private static final Histogram requestDurationMetric = Histogram.build()
            .name("api_request_duration_seconds")
            .help("Время работы API с разделением по методам и версиям")
            .labelNames("method_name", "method_version")
            .register();
    private static final Counter requestCounter = Counter.build()
            .name("api_request_count")
            .help("Количество запросов API с разделением по методам, версиям и возвращаемым HTTP кодам")
            .labelNames("method_name", "method_version", "http_code")
            .register();

    static Histogram.Timer getRequestMetricsTimer(String url) {
        final var mvTuple = extractMethodAndVersion(url);
        return requestDurationMetric
                .labels(mvTuple.getKey(), mvTuple.getValue())
                .startTimer();
    }

    static void incrementApiRequest(String url, int httpCode) {
        final var mvTuple = extractMethodAndVersion(url);
        requestCounter.labels(mvTuple.getKey(), mvTuple.getValue(), String.valueOf(httpCode)).inc();
    }

    private static Pair<String, String> extractMethodAndVersion(String url) {
        final var urlPathArray = url.replaceAll("/", " ").strip().split(" ");
        final var methodName = urlPathArray[urlPathArray.length - 1];
        final var apiVersion = urlPathArray.length > 2 ? urlPathArray[2] : null;
        return Pair.of(methodName, apiVersion);
    }
}
