package ru.mts.dbo.entityoptions.filter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.mts.dbo.entityoptions.metrics.Metrics;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
@RequiredArgsConstructor
public class MetricsFilter extends OncePerRequestFilter {

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        return HttpMethod.OPTIONS.name().equals(request.getMethod());
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        final var timer = Metrics.getRequestHistogramTimer(request.getRequestURI());
        try {
            filterChain.doFilter(request, response);
        } finally {
            timer.observeDuration();
            Metrics.incrementApiRequest(request.getRequestURI(), response.getStatus());
        }
    }
}
