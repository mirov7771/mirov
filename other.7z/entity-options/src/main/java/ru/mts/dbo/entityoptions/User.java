package ru.mts.dbo.entityoptions;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Data
public class User {
    @JsonAlias("user_id")
    private String userId;

    @JsonAlias("client_id")
    private String clientId;

    @JsonAlias("user_data")
    private UserData userData = new UserData();

    @Data
    public static class UserData {
        @JsonAlias("rbo_id")
        private String rboId;

        @JsonAlias("ibso_id")
        private String ibsoId;

        @JsonAlias("full_name")
        private Name name = new Name();

        @JsonAlias("organizations")
        private List<Organization> organizations = new ArrayList<>();

        public String getFullName() {
            return Stream.of(
                    getName().getLastName(),
                    getName().getFirstName(),
                    getName().getMiddleName()
            )
                    .filter(StringUtils::isNotEmpty)
                    .collect(Collectors.joining(" "));
        }
    }

    @Data
    public static class Name {
        @JsonAlias("first_name")
        private String firstName;

        @JsonAlias("last_name")
        private String lastName;

        @JsonAlias("middle_name")
        private String middleName;
    }

    @Data
    public static class Organization {
        @JsonAlias("id")
        private String id;

        @JsonAlias("name")
        private String name;
    }
}
