package ru.mts.dbo.entityoptions.metrics;

import io.prometheus.client.Histogram;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Metrics {
    public static Histogram.Timer getRequestHistogramTimer(String url) {
        return RequestMetrics.getRequestMetricsTimer(url);
    }

    public static void incrementApiRequest(String url, int httpCode) {
        RequestMetrics.incrementApiRequest(url, httpCode);
    }
}
