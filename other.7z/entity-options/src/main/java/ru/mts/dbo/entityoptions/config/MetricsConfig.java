package ru.mts.dbo.entityoptions.config;

import io.prometheus.client.hibernate.HibernateStatisticsCollector;
import io.prometheus.client.spring.web.EnablePrometheusTiming;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.SessionFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManagerFactory;

@Slf4j
@Configuration
@EnablePrometheusTiming
@RequiredArgsConstructor
@ConditionalOnProperty(value = "metrics.enabled", havingValue = "true")
public class MetricsConfig {
    private final EntityManagerFactory entityManagerFactory;

    @PostConstruct
    public void initBeansMetrics() {
        try {
            final var sessionFactory = entityManagerFactory.unwrap(SessionFactory.class);
            new HibernateStatisticsCollector(sessionFactory, "entity-options").register();
        } catch (Exception e) {
            log.error("Could not initialize Hibernate metrics because of {}", e.getLocalizedMessage());
        }
    }
}
