package ru.mts.dbo.entityoptions.controller.dto.block;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseRequest;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Модель запроса блок v1.0")
public class BlockRequest__1_0 extends BaseRequest {

    @NotEmpty(message = "Идентификатор блока должен быть заполнен")
    @Schema(title = "Идентификатор блока", example = "fe49ab56-d944-45c3-ac07-74f31a22e5f4", required = true)
    private String id;

    @NotNull(message = "Значение блока должено быть заполнено")
    @Schema(title = "Значение блока", example = "mainpage.accounts", required = true)
    private Integer state;
}
