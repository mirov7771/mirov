package ru.mts.dbo.entityoptions.controller;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.mts.dbo.entityoptions.Context;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseResponse;
import ru.mts.dbo.entityoptions.error.FailureType;

import java.util.Arrays;


@Slf4j
@UtilityClass
public class RestCommons {
    public static final String BEARER_PART_NAME = "Bearer";
    public static final String TOKEN_HEADER_NAME = "Authorization";
    public static final String REQUEST_ID_HTTP_HEADER = "Request-Id";

    public static <P extends BaseResponse> ResponseEntity<P> getResponse(P payload) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(REQUEST_ID_HTTP_HEADER, Context.getRequestId());

        return new ResponseEntity<>(payload, headers,
                httpStatusByBusinessCode(payload.getErrorCode())
        );
    }

    public static <P extends BaseResponse> ResponseEntity<P> getErrorResponse(int errorCode, String errorMessage) {
        return getResponse(BaseResponse.error(errorCode, errorMessage));
    }

    private static HttpStatus httpStatusByBusinessCode(int businessCode) {
        if (businessCode == BaseResponse.SUCCESS_CODE) {
            return HttpStatus.OK;
        }

        try {
            return Arrays.stream(FailureType.values())
                    .filter(it -> it.getCode() == businessCode)
                    .findAny()
                    .orElseThrow(() -> new IllegalArgumentException("Unknown errorCode: " + businessCode))
                    .getHttpStatus();
        } catch (IllegalArgumentException ex) {
            log.error("Failed to resolve HTTP status", ex);

            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }
}
