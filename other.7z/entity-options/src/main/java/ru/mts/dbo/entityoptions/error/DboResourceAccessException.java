package ru.mts.dbo.entityoptions.error;

public class DboResourceAccessException extends DBOException {

    public DboResourceAccessException() {
        super(FailureType.BACKEND_TECH_ERROR);
    }
}
