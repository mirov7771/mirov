package ru.mts.dbo.entityoptions.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.mts.dbo.entityoptions.filter.RequestIdFilter;
import ru.mts.dbo.entityoptions.filter.TokenFilter;
import ru.mts.dbo.entityoptions.filter.MetricsFilter;

@Configuration
public class FilterConfig {

    @Bean
    @ConditionalOnBean(MetricsConfig.class)
    public FilterRegistrationBean<MetricsFilter> metricsFilter() {
        final var filterBean = new FilterRegistrationBean<>(new MetricsFilter());
        filterBean.addUrlPatterns(
                "/entity-options/1.0/*"
        );
        return filterBean;
    }

    @Bean
    public FilterRegistrationBean<RequestIdFilter> requestIdFilter(ObjectMapper objectMapper) {
        final var filterBean = new FilterRegistrationBean<>(new RequestIdFilter(objectMapper));
        filterBean.addUrlPatterns(
                "/entity-options/1.0/*"
        );
        return filterBean;
    }

    @Bean
    public FilterRegistrationBean<TokenFilter> tokenFilterRegistrationBean(ObjectMapper objectMapper) {
        final var filterBean = new FilterRegistrationBean<>(new TokenFilter(objectMapper));
        filterBean.addUrlPatterns(
                "/*"
        );
        return filterBean;
    }
}
