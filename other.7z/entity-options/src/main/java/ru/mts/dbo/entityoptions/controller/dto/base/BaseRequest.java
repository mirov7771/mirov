package ru.mts.dbo.entityoptions.controller.dto.base;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@Schema(description = "Общий класс-родитель для всех запросов")
public class BaseRequest {
}
