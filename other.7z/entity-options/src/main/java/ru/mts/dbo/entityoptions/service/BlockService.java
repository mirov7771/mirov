package ru.mts.dbo.entityoptions.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.mts.dbo.entityoptions.model.Block;
import ru.mts.dbo.entityoptions.repo.BlockRepository;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class BlockService {
    private final BlockRepository repository;

    public Block save(final Block block) {
        return repository.save(block);
    }

    public Optional<Block> findByIdAndUserId(final String inquiryId, String userId) {
        return repository.findByIdAndUserId(inquiryId, userId);
    }

    public List<Block> getBlocks(final  String userId, final String filter) {
        return repository.findByUserIdAndIdIgnoreCaseStartingWith(userId, filter);
    }
}
