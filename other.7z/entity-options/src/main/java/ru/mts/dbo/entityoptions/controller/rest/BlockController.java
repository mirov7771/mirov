package ru.mts.dbo.entityoptions.controller.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseResponse;
import ru.mts.dbo.entityoptions.controller.dto.block.BlockRequest__1_0;
import ru.mts.dbo.entityoptions.controller.dto.blocks.BlocksResponse__1_0;
import ru.mts.dbo.entityoptions.controller.provider.BlockProvider;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(value = "entity-options", produces = "application/json")
@Tag(name = "block", description = "Контроллер для работы с скрываемыми блоками")
public class BlockController {
    private final BlockProvider blockProvider;

    @PostMapping("1.0/{clientSystemId}/block")
    @Operation(summary = "Изменение текущего сохраненного состояния скрываемого блока (спойлера) v1.0", tags = "1.0")
    public BaseResponse block__1_0(
            @Parameter(
                    description = "Тип клиента (системы, приславшей запрос)",
                    example = "edbo-mobile-ios",
                    required = true
            )
            @PathVariable("clientSystemId") String clientSystemId,
            @Valid @RequestBody BlockRequest__1_0 request
    ) {
        return blockProvider.block__1_0(request);
    }

    @GetMapping("1.0/{clientSystemId}/blocks")
    @Operation(summary = "Получение текущего сохраненного состояния скрываемых блоков (спойлеров и/или баннеров) v1.0", tags = "1.0")
    public BlocksResponse__1_0 blocks__1_0(
            @Parameter(
                    description = "Тип клиента (системы, приславшей запрос)",
                    example = "edbo-mobile-ios",
                    required = true
            )
            @PathVariable("clientSystemId") String clientSystemId,
            @Parameter(
                    description = "Строка фильтрации названий блоков",
                    example = "mainpage.payments.visible",
                    required = true
            )
            @RequestParam(value = "filter", required = false) @NotBlank(message = "Не указано условие filter") String filter
    ) {
        return blockProvider.blocks__1_0(filter);
    }
}
