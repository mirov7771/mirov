package ru.mts.dbo.entityoptions.controller.provider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.entityoptions.Context;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseResponse;
import ru.mts.dbo.entityoptions.controller.dto.block.BlockRequest__1_0;
import ru.mts.dbo.entityoptions.controller.dto.blocks.BlocksResponse__1_0;
import ru.mts.dbo.entityoptions.error.CommonInvalidFrontendRequestException;
import ru.mts.dbo.entityoptions.service.BlockService;

import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class BlockProvider {
    private final BlockService service;

    public BaseResponse block__1_0(BlockRequest__1_0 request) {
        final var userId = Context.getUserData().getUserId();
        final var blockOptional = service.findByIdAndUserId(request.getId(), userId);
        System.err.println(Context.getRequestId());
        if (blockOptional.isEmpty()) {
            throw new CommonInvalidFrontendRequestException();
        }
        final var block = blockOptional.get().setState(request.getState());
        service.save(block);
        return new BaseResponse();
    }

    public BlocksResponse__1_0 blocks__1_0(String filter) {
        final var userId = Context.getUserData().getUserId();

        final var blocks = service.getBlocks(userId, filter);

        if (CollectionUtils.isEmpty(blocks)) {
            throw new CommonInvalidFrontendRequestException();
        }

        return new BlocksResponse__1_0().setBlocksList(blocks.stream()
                .map(block -> new BlocksResponse__1_0.Block(block.getId(), block.getState()))
                .collect(Collectors.toList()));
    }
}
