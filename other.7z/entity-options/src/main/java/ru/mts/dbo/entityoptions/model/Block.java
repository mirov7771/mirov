package ru.mts.dbo.entityoptions.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Data
@Entity
@Table(name = "T_BLOCKS")
public class Block {

    @Id
    private String id;

    private String userId;

    private Integer state;
}
