package ru.mts.dbo.entityoptions.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.*;

@Getter
@AllArgsConstructor
public enum FailureType {
    /**
     * Нештатная, не предусмотренная реализацией ошибка.
     */
    UNEXPECTED_ERROR(100, INTERNAL_SERVER_ERROR),

    /**
     * Клиент прислал запрос нарушающий контракт сервиса.
     */
    INVALID_FRONTEND_REQUEST(101, BAD_REQUEST),

    /**
     * От одной из систем получен ответ нарушающий контракт.
     */
    INVALID_BACKEND_RESPONSE(102, INTERNAL_SERVER_ERROR),

    /**
     * Клиентский запрос не был обработан в отведённое время (см. ${service.request.timeout}).
     */
    REQUEST_TIMEOUT(103, INTERNAL_SERVER_ERROR),

    /**
     * Аутентификация не была выполнена
     */
    UNAUTHORIZED_ERROR(104, UNAUTHORIZED),

    /**
     * Одна из систем вернула сообщение с ошибкой
     */
    BACKEND_REJECTION(105, BAD_REQUEST),

    /**
     * Одна из систем не вернула сообщение по таймату
     */
    BACKEND_TIMEOUT(106, SERVICE_UNAVAILABLE),

    /**
     * Одна из систем не вернула сообщение из-за технической ошибки
     */
    BACKEND_TECH_ERROR(107, INTERNAL_SERVER_ERROR),

    ENTITY_NOT_FOUND(108, NOT_FOUND, "Запрашиваемая сущность не найдена"),

    DOCUMENT_NOT_FOUND(109, NOT_FOUND, "Document not found!"),

    DUPLICATE_DOCUMENT(110, BAD_REQUEST, "Найден дубликат документа"),

    INVALID_CLIENT(127, UNAUTHORIZED, "Invalid_client"),

    DOCUMENTS_OF_VARIOUS_ORGANIZATIONS(201, BAD_REQUEST, "Недоступная операция на документах разных организаций"),

    ACCOUNT_NUMBER_NOT_FOUND_ERROR(1075, NOT_FOUND, "Не найден счет"),

    ORG_NOT_REGISTERED_ERROR(1076, NOT_FOUND, "Организация не зарегистрирована"),

    INVALID_REQUEST_CHECK_VERSION(1191, BAD_REQUEST, "Не указана версия приложения"),

    DOCUMENT_CANNOT_BE_SIGNED(1201, BAD_REQUEST, "Документ не может быть подписан"),

    DOCUMENT_SIGN_PASSWORD_INVALID(1202, BAD_REQUEST, "Ошибочный пароль"),

    DOCUMENT_SIGNATURE_INVALID(1203, BAD_REQUEST, "Ошибка проверки подписи"),

    DOCUMENTS_CANNOT_BE_SIGNED(1211, BAD_REQUEST, "Все документы не могут быть подписаны"),

    ERROR_SEND_DOCUMENT(1221, BAD_REQUEST, "Ошибка отправки документа"),

    DOCUMENT_CANNOT_BE_PRESIGNED(1223, PRECONDITION_FAILED, "Подпись не может быть установлена на этом документе"),

    DOCUMENT_HASH_INVALID(1224, BAD_REQUEST, "Хэш реквизитов документа не корректен"),

    DOCUMENT_CANNOT_BE_PRESIGNED_TIMEOUT(1225, PRECONDITION_FAILED, "Подпись не может быть установлена на этом документе"),

    PAYOUT_LIMIT_EXCEEDED(1226, PRECONDITION_FAILED, "Превышен лимит на сумму платежей"),

    DOCUMENT_NOT_SIGNED(1261, PRECONDITION_FAILED, "Документ не подписан"),

    DOCUMENT_CANNOT_BE_UNSIGNED(1262, BAD_REQUEST, "Подпись документа не может быть снята");

    private int code;

    private HttpStatus httpStatus;

    private String message;

    FailureType(int code, HttpStatus status) {
        this(code, status, status.getReasonPhrase());
    }
}
