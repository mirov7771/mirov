package ru.mts.dbo.entityoptions.error;

public class EntityNotFoundException extends DBOException {
    public EntityNotFoundException() {
        super(FailureType.ENTITY_NOT_FOUND);
    }
}
