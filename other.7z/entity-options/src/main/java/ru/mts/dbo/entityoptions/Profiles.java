package ru.mts.dbo.entityoptions;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Profiles {

    @UtilityClass
    public static class Application {
        /**
         * Используется для полностью локальной разработки
         */
        public static final String LOCAL = "local";

        /**
         * Используется для локальной разработки на dev стенде (контур МТС ИТ)
         */
        public static final String DEV_LOCAL = "dev_local";

        /**
         * Используется для запуска в контуре МТСБ
         */
        public static final String DEV = "dev";
    }
}
