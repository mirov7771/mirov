package ru.mts.dbo.entityoptions.controller.dto.blocks;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseResponse;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Модель ответа состояния скрываемых блоков v1.0")
public class BlocksResponse__1_0 extends BaseResponse {

    @Schema(title = "Массив объектов блок")
    private List<Block> blocksList;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(name = "BlocksResponse__1_0.Block", description = "Модель объекта \"блок\"")
    public static class Block {

        @Schema(title = "Идентификатор блока")
        private String id;

        @Schema(title = "Значение блока")
        private Integer state;
    }
}
