package ru.mts.dbo.entityoptions.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.mts.dbo.entityoptions.error.FailureType;
import ru.mts.dbo.entityoptions.Context;
import ru.mts.dbo.entityoptions.controller.dto.base.BaseResponse;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

import static ru.mts.dbo.entityoptions.controller.RestCommons.REQUEST_ID_HTTP_HEADER;


@Slf4j
@RequiredArgsConstructor
public class RequestIdFilter extends OncePerRequestFilter {
    private final ObjectMapper objectMapper;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        return HttpMethod.OPTIONS.name().equals(request.getMethod());
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        final var requestId = request.getHeader(REQUEST_ID_HTTP_HEADER);
        if (StringUtils.isEmpty(requestId)) {
            final var errorMessage = "Missing required HTTP header: " + REQUEST_ID_HTTP_HEADER;
            final var error = BaseResponse.error(FailureType.INVALID_FRONTEND_REQUEST.getCode(), errorMessage);
            response.getWriter().write(objectMapper.writeValueAsString(error));
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.setHeader("Content-Type", "application/json;charset=UTF-8");
            log.error(errorMessage);
            return;
        }
        try {
            final var uuid = UUID.fromString(requestId);
            Context.setRequestId(uuid);
            Context.setIpAddrs(request.getRemoteAddr());
            MDC.put(REQUEST_ID_HTTP_HEADER, Context.getRequestId());
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            final var errorMessage = REQUEST_ID_HTTP_HEADER + " HTTP header is incorrect";
            final var error = BaseResponse.error(FailureType.INVALID_FRONTEND_REQUEST.getCode(), errorMessage);
            response.getWriter().write(objectMapper.writeValueAsString(error));
            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.setHeader("Content-Type", "application/json;charset=UTF-8");
            log.error(errorMessage);
        } finally {
            Context.clearContext();
            MDC.clear();
        }
    }
}
