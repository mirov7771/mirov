package ru.mts.dbo.entityoptions.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.mts.dbo.entityoptions.model.Block;

import java.util.List;
import java.util.Optional;

public interface BlockRepository extends JpaRepository<Block, String> {

    Optional<Block> findByIdAndUserId(String id, String userId);

    List<Block> findByUserIdAndIdIgnoreCaseStartingWith(String userId, String filter);
}
