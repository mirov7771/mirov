package ru.mts.dbo.entityoptions.controller.dto.base;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.SneakyThrows;

@Data
@Schema(description = "Общий класс-родитель для всех ответов")
public class BaseResponse {

    public static final int SUCCESS_CODE = 0;

    @Schema(
            title = "Код отказа",
            defaultValue = "0",
            description = "Бизнесовый код ошибки, 0 -- ошибок нет",
            required = true
    )
    private int errorCode = SUCCESS_CODE;

    @Schema(
            title = "Описание причины отказа",
            defaultValue = "null",
            description = "Текст ошибки, при отсутствии -- ошибок нет"
    )
    private String errorMessage;

    public static <T extends BaseResponse> T error(int errorCode, String errorMessage) {
        return (T) error(errorCode, errorMessage, BaseResponse.class);
    }

    @SneakyThrows
    public static <T extends BaseResponse> T error(int errorCode, String errorMessage, Class<T> clazz) {
        return (T) clazz.newInstance()
                .setErrorCode(errorCode)
                .setErrorMessage(errorMessage);
    }
}
