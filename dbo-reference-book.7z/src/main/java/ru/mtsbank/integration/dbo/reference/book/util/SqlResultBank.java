package ru.mtsbank.integration.dbo.reference.book.util;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SqlResultBank {

    private String BIN;
    private String BIC;
    private String BANKID;
    private String BANKNAME;
    private String BANKENGNAME;
    private String CORACCOUNT;

}
