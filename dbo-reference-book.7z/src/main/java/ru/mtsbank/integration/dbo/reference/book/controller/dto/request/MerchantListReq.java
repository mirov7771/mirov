package ru.mtsbank.integration.dbo.reference.book.controller.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class MerchantListReq {

    @JsonProperty("placeDesc")
    private String placeDesc;
    @JsonProperty("mcc_code")
    private String mccCode;

}
