package ru.mtsbank.integration.dbo.reference.book.service.impl.v2;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.response.BindingLimitsRes;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.support.Limits;
import ru.mtsbank.integration.dbo.reference.book.repository.Repository;
import ru.mtsbank.integration.dbo.reference.book.service.Service;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultLimit;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component("v2")
public class ServiceV2Impl implements Service {

    @Autowired
    private Repository repository;

    @Override
    public ResponseEntity<?> getBindingLimits(Long rboId) {
        log.info("Start get binding limits");
        List<BindingLimitsRes> limitRes = new ArrayList<>();
        List<SqlResultLimit> limitList = repository.getLimitList(rboId);
        if (!CollectionUtils.isEmpty(limitList)) {
            for (SqlResultLimit limit : limitList) {
                BindingLimitsRes res = new BindingLimitsRes();
                res.setBindingType(limit.getSYSNAME());
                res.setLimits(new Limits(limit.getMAXSUMMA(), limit.getCURRENCY()));
                limitRes.add(res);
            }
        }
        log.info("End get binding limits");
        return ResponseEntity.ok(limitRes);
    }
}
