package ru.mtsbank.integration.dbo.reference.book.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.BankListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.MerchantListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.RefenceReq;
import ru.mtsbank.integration.dbo.reference.book.service.Service;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;
import static ru.mts.dbo.utils.Utils.getRboIdFromToken;
import static ru.mts.dbo.utils.Utils.isDigits;

@RestController
@RequestMapping("dbo-reference-book")
@Slf4j
public class ServiceController {

    private static final ObjectMapper mapper = new ObjectMapper();

    @Autowired
    private Map<String, Service> services;

    @GetMapping(value = "{version}/reference")
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<?> getReferenceData(@PathVariable final String version,
                                              @RequestParam(name = "type", required = false) String[] type) {
        return services.get(version).getRef(type);
    }

    @PostMapping(value = "{version}/reference/add", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(hidden = true)
    public void save(@PathVariable final String version, @RequestBody RefenceReq req){
        services.get(version).saveReference(req);
    }


    @GetMapping(value = "{version}/bank")
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<?> getBank(@PathVariable final String version
                                    ,@RequestParam(name = "bin", required = false) String bin
                                    ,@RequestParam(name = "bic", required = false) String bic)
    {
        if (StringUtils.isEmpty(bic) && StringUtils.isEmpty(bin)) {
            BaseResponse res = new BaseResponse();
            res.createError(100,
                    "Не корректный запрос",
                    400,
                    null,
                    "Некорректный запрос",
                    "bankList",
                    null);
            return ResponseBuilder.build(res);
        }
        if (!StringUtils.isEmpty(bic)) {
            return services.get(version).getBankByBic(bic);
        } else {
            return services.get(version).getBankByBin(bin);
        }
    }

    @PostMapping(value = "{version}/bankList", produces = APPLICATION_JSON_UTF8_VALUE)
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<?> getBankList(@PathVariable final String version
                                        ,@Valid @RequestBody(required = false) List<BankListReq> bankList)
    {
        if (CollectionUtils.isEmpty(bankList)
                || (bankList.size() == 1 && bankList.get(0).preValidate()))
        {
            BaseResponse res = new BaseResponse();
            res.createError(1001, "Не корректный запрос", 404, null, null, "bankList", null);
            return ResponseBuilder.build(res);
        }
        return services.get(version).getBankList(bankList);
    }

    @GetMapping(value = "{version}/bindinglimits")
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1", "v2"}))
    public ResponseEntity<?> getPaymentLimits(@PathVariable final String version,
                                              @RequestHeader(value = "rbo_id", required = false) String rboId,
                                              @RequestHeader(value = "authorization", required = false) String authorization)
    {
        Long rboID = null;
        if (!StringUtils.isEmpty(authorization))
            rboID = getRboIdFromToken(authorization);
        else if (!StringUtils.isEmpty(rboId) && isDigits(rboId))
            rboID = Long.valueOf(rboId);
        return services.get(version).getBindingLimits(rboID);
    }

    @PostMapping(value = "{version}/merchantList", produces = APPLICATION_JSON_UTF8_VALUE)
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<?> getMerchantList(@PathVariable final String version
                                            ,@RequestBody List<MerchantListReq> merchantList)
    {
        return services.get(version).getMerchantList(merchantList);
    }

}
