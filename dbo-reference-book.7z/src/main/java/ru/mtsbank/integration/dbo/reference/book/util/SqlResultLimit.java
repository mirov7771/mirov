package ru.mtsbank.integration.dbo.reference.book.util;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class SqlResultLimit {

    private Integer ID;
    private String SYSNAME;
    private String CURRENCY;
    private BigDecimal MAXSUMMA;
    private String DESCRIPTION;
}
