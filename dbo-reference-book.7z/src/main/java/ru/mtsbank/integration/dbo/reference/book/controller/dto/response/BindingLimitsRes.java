package ru.mtsbank.integration.dbo.reference.book.controller.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.support.Limits;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class BindingLimitsRes extends BaseResponse {

    @JsonProperty("bindingType")
    private String bindingType;
    @JsonProperty("limits")
    private Limits limits;

}
