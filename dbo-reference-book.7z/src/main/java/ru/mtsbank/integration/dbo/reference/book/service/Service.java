package ru.mtsbank.integration.dbo.reference.book.service;

import org.springframework.http.ResponseEntity;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.BankListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.MerchantListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.RefenceReq;

import java.util.List;

public interface Service {

    default ResponseEntity<?> getRef(String[] type) {
        return ResponseEntity.badRequest().body("This method is not implemented in current version");
    }

    default ResponseEntity<?> getBankByBin(String bin) {
        return ResponseEntity.badRequest().body("This method is not implemented in current version");
    }

    default ResponseEntity<?> getBankByBic(String bic) {
        return ResponseEntity.badRequest().body("This method is not implemented in current version");
    }

    default ResponseEntity<?> getBankList(List<BankListReq> bankListReqs) {
        return ResponseEntity.badRequest().body("This method is not implemented in current version");
    }

    default ResponseEntity<?> getBindingLimits(Long rboId) {
        return ResponseEntity.badRequest().body("This method is not implemented in current version");
    }

    default ResponseEntity<?> getMerchantList(List<MerchantListReq> merchantList) {
        return ResponseEntity.badRequest().body("This method is not implemented in current version");
    }

    default void saveReference(RefenceReq req){}

}
