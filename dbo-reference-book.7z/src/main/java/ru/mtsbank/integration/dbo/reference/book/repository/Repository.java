package ru.mtsbank.integration.dbo.reference.book.repository;

import org.springframework.stereotype.Service;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.MerchantListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.RefenceReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.response.MerchantListRes;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultBank;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultLimit;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultRef;

import java.util.List;

@Service
public interface Repository {

    List<SqlResultRef> getReferenceData(String[] type);
    List<SqlResultBank> getBankData(String bin);
    List<SqlResultBank> getBankDataByBic(String bic);
    List<SqlResultBank> getBankList(List<String> bins, List<String> bics);

    List<SqlResultLimit> getLimitList(Long rboId);

    List<MerchantListRes> getMerchantList(List<MerchantListReq> reqs);

    void saveReference(RefenceReq req);

}
