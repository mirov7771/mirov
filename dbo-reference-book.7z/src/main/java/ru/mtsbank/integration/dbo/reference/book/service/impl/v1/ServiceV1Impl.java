package ru.mtsbank.integration.dbo.reference.book.service.impl.v1;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.BankListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.MerchantListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.RefenceReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.response.BankRes;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.response.BindingLimitsRes;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.support.Limits;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.support.Response;
import ru.mtsbank.integration.dbo.reference.book.repository.Repository;
import ru.mtsbank.integration.dbo.reference.book.service.Service;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultBank;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultLimit;
import ru.mtsbank.integration.dbo.reference.book.util.SqlResultRef;

import java.util.*;

import static ru.mtsbank.integration.dbo.reference.book.util.AnswerUtils.getRefItem;

@Component("v1")
@Slf4j
public class ServiceV1Impl implements Service {

    @Autowired
    private Repository repository;

    private static final String IMAGE_PATH = "http://mtsmoney.mts.ru/fs/banklogo/";

    @Override
    public ResponseEntity<?> getRef(String[] type) {
        log.info("Start search reference");
        List<SqlResultRef> list = repository.getReferenceData(type);
        if (!CollectionUtils.isEmpty(list)) {
            Map<String, Object> content = new HashMap<>();
            Set<String> refNames = new HashSet<>();
            for (SqlResultRef item : list) {
                String refName = item.getREFERENCEBRIEF();
                if (!refNames.contains(refName))
                    refNames.add(refName);
            }
            refNames.forEach(ref -> {
                content.put(ref, getRefItem(ref, list));
            });
            log.info("End search reference - success");
            return ResponseEntity.ok(content);
        } else {
            Response res = new Response();
            res.createError(1001, "Справочник не найден", 404, null, null, "reference", null);
            log.info("End search reference - error");
            return ResponseBuilder.build(res);
        }
    }

    @Override
    public ResponseEntity<?> getBankByBin(String bin) {
        log.info("Start search bank");
        BankRes res = new BankRes();
        if (Utils.isDigits(bin)) {
            List<SqlResultBank> bankData = repository.getBankData(bin);
            if (!CollectionUtils.isEmpty(bankData)) {
                if (bankData.size() == 1) {
                    SqlResultBank sqlResultBank = bankData.get(0);
                    res.setBankId(sqlResultBank.getBANKID());
                    res.setBankName(sqlResultBank.getBANKNAME());
                    res.setBic(sqlResultBank.getBIC());
                    res.setBin(sqlResultBank.getBIN());
                    res.setCorrAccount(sqlResultBank.getCORACCOUNT());
                    res.setImage(IMAGE_PATH + sqlResultBank.getBIC() + ".png");
                } else {
                    res.createError(1044, "не возможно однозначно определить банк", 417, null, null, "bank", null);
                }
            } else {
                res.createError(1043, "Не найден банк по БИН или БИК", 404, null, null, "bank", null);
            }
        } else {
            res.createError(1061, "Передан неверный БИН", 417, null, null, "bank", null);
        }
        return ResponseBuilder.build(res);
    }

    @Override
    public ResponseEntity<?> getBankByBic(String bic) {
        log.info("Start search bank");
        BankRes res = new BankRes();
        List<SqlResultBank> bankData = repository.getBankDataByBic(bic);
        if (Utils.isDigits(bic)) {
            if (!CollectionUtils.isEmpty(bankData)) {
                if (bankData.size() == 1) {
                    SqlResultBank sqlResultBank = bankData.get(0);
                    res.setBankId(sqlResultBank.getBANKID());
                    res.setBankName(sqlResultBank.getBANKNAME());
                    res.setBic(sqlResultBank.getBIC());
                    res.setBin(sqlResultBank.getBIN());
                    res.setCorrAccount(sqlResultBank.getCORACCOUNT());
                    res.setImage(IMAGE_PATH + sqlResultBank.getBIC() + ".png");
                } else {
                    res.createError(1044, "не возможно однозначно определить банк", 417, null, null, "bank", null);
                }
            } else {
                res.createError(1043, "Не найден банк по БИН или БИК", 404, null, null, "bank", null);
            }
        } else {
            res.createError(1061, "Передан неверный БИК", 417, null, null, "bank", null);
        }
        return ResponseBuilder.build(res);
    }

    @Override
    public ResponseEntity<?> getBankList(List<BankListReq> bankListReqs) {
        log.info("Start search bank list");
        List<BankRes> bankRes = new ArrayList<>();
        List<String> bics = new ArrayList<>();
        List<String> bins = new ArrayList<>();
        log.info("input list"+Arrays.toString(bankListReqs.toArray()));
        if (!CollectionUtils.isEmpty(bankListReqs)) {
            log.info("start preparing query params");
            for (BankListReq req : bankListReqs) {
                if (!StringUtils.isEmpty(req.getBic()))
                    bics.add(req.getBic());
                if (!StringUtils.isEmpty(req.getBin()))
                    bins.add(req.getBin());
            }
            List<SqlResultBank> bankList = repository.getBankList(bins, bics);
            if (!CollectionUtils.isEmpty(bankList)) {
                for (SqlResultBank bank : bankList) {
                    BankRes res = new BankRes();
                    res.setBankId(bank.getBANKID());
                    res.setBankName(bank.getBANKNAME());
                    res.setBic(bank.getBIC());
                    res.setImage(IMAGE_PATH + bank.getBIC() + ".png");
                    bankRes.add(res);
                }
            }
        }
        log.info("End search bank list");
        return ResponseEntity.ok(bankRes);
    }

    @Override
    public ResponseEntity<?> getBindingLimits(Long rboId) {
        log.info("Start get binding limits");
        List<BindingLimitsRes> limitRes = new ArrayList<>();
        List<SqlResultLimit> limitList = repository.getLimitList(null);
        if (!CollectionUtils.isEmpty(limitList)) {
            for (SqlResultLimit limit : limitList) {
                BindingLimitsRes res = new BindingLimitsRes();
                res.setBindingType(limit.getSYSNAME());
                res.setLimits(new Limits(limit.getMAXSUMMA(), limit.getCURRENCY()));
                limitRes.add(res);
            }
        }
        log.info("End get binding limits");
        return ResponseEntity.ok(limitRes);
    }

    @Override
    public ResponseEntity<?> getMerchantList(List<MerchantListReq> merchantList) {
        return ResponseEntity.ok(repository.getMerchantList(merchantList));
    }

    @Override
    public void saveReference(RefenceReq req) {
        repository.saveReference(req);
    }
}
