package ru.mtsbank.integration.dbo.reference.book.util;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SqlResultMcc {

    private String MCCCODE;
    private String MCCNAME;
    private String MCCIMG;

}
