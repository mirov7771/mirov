package ru.mtsbank.integration.dbo.reference.book.controller.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class MerchantListRes extends BaseResponse {

    @JsonProperty("placeDesc")
    private String placeDesc;
    @JsonProperty("mcc_code")
    private String mccCode;
    @JsonProperty("placeName")
    private String placeName;
    @JsonProperty("placeImg")
    private String placeImg;
    @JsonProperty("mcc_name")
    private String mccName;
    @JsonProperty("mcc_img")
    private String mccImg;

    @JsonIgnore
    public boolean isNotNull() {
        return placeDesc != null
                || mccCode != null
                || placeName != null
                || placeImg != null
                || mccName != null
                || mccImg != null;
    }
}
