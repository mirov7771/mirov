package ru.mtsbank.integration.dbo.reference.book.controller.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class BankRes extends BaseResponse {

    @JsonProperty("bankId")
    private String bankId;
    @JsonProperty("bankName")
    private String bankName;
    @JsonProperty("BIC")
    private String bic;
    @JsonProperty("BIN")
    private String bin;
    @JsonProperty("image")
    private String image;
    @JsonProperty("corrAccount")
    private String corrAccount;

}
