package ru.mtsbank.integration.dbo.reference.book.controller.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import org.springframework.util.StringUtils;

@Getter
public class BankListReq {

    @JsonProperty("bic")
    private String bic;
    @JsonProperty("bin")
    private String bin;

    public boolean preValidate(){
        return StringUtils.isEmpty(bic) && StringUtils.isEmpty(bin);
    }

}
