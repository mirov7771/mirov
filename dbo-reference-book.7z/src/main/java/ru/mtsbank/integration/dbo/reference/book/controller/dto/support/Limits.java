package ru.mtsbank.integration.dbo.reference.book.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
@AllArgsConstructor
public class Limits {

    @JsonProperty("max_amount")
    private BigDecimal max_amount;
    @JsonProperty("currency")
    private String currency;
}
