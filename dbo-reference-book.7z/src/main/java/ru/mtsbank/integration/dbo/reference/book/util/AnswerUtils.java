package ru.mtsbank.integration.dbo.reference.book.util;

import ru.mtsbank.integration.dbo.reference.book.controller.dto.support.ReferenceItem;

import java.util.ArrayList;
import java.util.List;

public class AnswerUtils {

    public static List<ReferenceItem> getRefItem(String refname, List<SqlResultRef> list){
        List<ReferenceItem> referenceItems = new ArrayList<>();
        for(SqlResultRef item : list) {
            String refsysname = item.getREFERENCEBRIEF();
            if (refsysname.equalsIgnoreCase(refname)) {
                ReferenceItem referenceItem = new ReferenceItem();
                referenceItem.setName(item.getNAME());
                referenceItem.setValue(item.getBRIEF());
                referenceItem.setExtraValue(item.getEXTRAVALUE());
                referenceItem.setDescription(item.getDESCRIPTION());
                referenceItem.setCode(item.getCODE());
                //TODO переделать на нормально решение
                if ("WorkActivity".equalsIgnoreCase(refname)){
                    switch (referenceItem.getValue()){
                        case "WORKACTIVITY.1":
                            referenceItem.setAdditionalFields("1");
                            break;
                        case "WORKACTIVITY.2":
                            referenceItem.setAdditionalFields("1");
                            break;
                        case "WORKACTIVITY.3":
                            referenceItem.setAdditionalFields("1");
                            break;
                        case "WORKACTIVITY.4":
                            referenceItem.setAdditionalFields("1");
                            break;
                        case "WORKACTIVITY.5":
                            referenceItem.setAdditionalFields("0");
                            break;
                        case "WORKACTIVITY.6":
                            referenceItem.setAdditionalFields("0");
                            break;
                        case "WORKACTIVITY.7":
                            referenceItem.setAdditionalFields("0");
                            break;
                    }
                }
                referenceItems.add(referenceItem);
            }
        }
        return referenceItems;
    }
}
