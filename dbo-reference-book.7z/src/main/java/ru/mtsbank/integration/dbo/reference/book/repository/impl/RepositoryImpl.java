package ru.mtsbank.integration.dbo.reference.book.repository.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ParameterizedPreparedStatementSetter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.MerchantListReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.request.RefenceReq;
import ru.mtsbank.integration.dbo.reference.book.controller.dto.response.MerchantListRes;
import ru.mtsbank.integration.dbo.reference.book.repository.Repository;
import ru.mtsbank.integration.dbo.reference.book.util.*;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

@org.springframework.stereotype.Repository("dboReferenceBookRepository")
@Slf4j
public class RepositoryImpl implements Repository {

    @Autowired
    protected JdbcTemplate jdbcTemplate;

    private static final String SELECT_ALL = Utils.getSqlCommand(RepositoryImpl.class, "selectAll");
    private static final String SELECT_LIST = Utils.getSqlCommand(RepositoryImpl.class, "selectList");
    private static final String SELECT_BANK = Utils.getSqlCommand(RepositoryImpl.class, "selectBank");
    private static final String SELECT_BANK_BIC = Utils.getSqlCommand(RepositoryImpl.class, "selectBankBic");
    private static final String SELECT_BANK_LIST_ALL = Utils.getSqlCommand(RepositoryImpl.class, "selectBankListAll");
    private static final String SELECT_BANK_LIST = Utils.getSqlCommand(RepositoryImpl.class, "selectBankList");
    private static final String SELECT_BANK_LIST_BY_BIN = Utils.getSqlCommand(RepositoryImpl.class, "selectBankListByBin");
    private static final String SELECT_BANK_LIST_BY_BIC = Utils.getSqlCommand(RepositoryImpl.class, "selectBankListByBic");
    private static final String SELECT_LIMITS_LIST_ALL = Utils.getSqlCommand(RepositoryImpl.class, "selectLimitsListAll");
    private static final String SELECT_PLACE = Utils.getSqlCommand(RepositoryImpl.class, "selectPlace");
    private static final String SELECT_MCC = Utils.getSqlCommand(RepositoryImpl.class, "selectMcc");

    @Override
    public List<SqlResultRef> getReferenceData(String[] type) {
        String select = SELECT_ALL;
        if (type != null && type.length > 0) {
            StringBuilder condition;
            if (type.length > 1) {
                int sz = type.length;
                condition = new StringBuilder();
                for (int i = 0; i < sz; i++) {
                    String value = type[i];
                    condition.append("'").append(value).append("'");
                    if (i < sz - 1)
                        condition.append(",");
                }
            } else {
                condition = new StringBuilder("'"+type[0]+"'");
            }
            select = SELECT_LIST.replace("'%s%'",condition.toString());
        }
        return jdbcTemplate.query(select, new BeanPropertyRowMapper(SqlResultRef.class));
    }

    @Override
    public List<SqlResultBank> getBankData(String bin) {
        String select = SELECT_BANK.replace("%s%",bin);
        return jdbcTemplate.query(select, new BeanPropertyRowMapper(SqlResultBank.class));
    }

    @Override
    public List<SqlResultBank> getBankDataByBic(String bic) {
        String select = SELECT_BANK_BIC.replace("%s%", bic);
        log.info("SQL: "+select);
        return jdbcTemplate.query(select, new BeanPropertyRowMapper(SqlResultBank.class));
    }

    @Override
    public List<SqlResultBank> getBankList(List<String> bins, List<String> bics){
        String binsstr = prepareStringFromArray(bins);
        String bicsstr = prepareStringFromArray(bics);
        String select = SELECT_BANK_LIST_ALL;
        if (!StringUtils.isEmpty(bicsstr) && !StringUtils.isEmpty(binsstr)){
            select = SELECT_BANK_LIST.replace("'%s%'", binsstr).replace("'%ss%'", bicsstr);
        } else if (StringUtils.isEmpty(bicsstr) && !StringUtils.isEmpty(binsstr)){
            select = SELECT_BANK_LIST_BY_BIN.replace("'%s%'", binsstr);
        } else if (!StringUtils.isEmpty(bicsstr) && StringUtils.isEmpty(binsstr)){
            select = SELECT_BANK_LIST_BY_BIC.replace("'%s%'", bicsstr);
        }
        return jdbcTemplate.query(select, new BeanPropertyRowMapper(SqlResultBank.class));
    }

    @Override
    public List<SqlResultLimit> getLimitList(Long rboId) {
        String query = SELECT_LIMITS_LIST_ALL.replace("{}", rboId == null ? "rboid is null" : "rboid = " + rboId);
        List<SqlResultLimit> result;
        result = jdbcTemplate.query(query, new BeanPropertyRowMapper(SqlResultLimit.class));
        if (CollectionUtils.isEmpty(result)){
            query = SELECT_LIMITS_LIST_ALL.replace("{}", "rboid is null");
            result = jdbcTemplate.query(query, new BeanPropertyRowMapper(SqlResultLimit.class));
        }
        return result;
    }

    @Override
    public List<MerchantListRes> getMerchantList(List<MerchantListReq> reqs) {
        List<String> places = new ArrayList<>();
        List<String> mccs = new ArrayList<>();
        reqs.forEach(item -> {
            places.add(prepareString(item.getPlaceDesc()));
            mccs.add(prepareString(item.getMccCode()));
        });

        String selectPlace = SELECT_PLACE.replace("'%s%'", prepareStringFromArray(places));
        String selectMcc = SELECT_MCC.replace("'%s%'", prepareStringFromArray(mccs));

        List<SqlResultPlace> place = jdbcTemplate.query(selectPlace, new BeanPropertyRowMapper(SqlResultPlace.class));
        List<SqlResultMcc> mcc = jdbcTemplate.query(selectMcc, new BeanPropertyRowMapper(SqlResultMcc.class));

        List<MerchantListRes> merchantList = new ArrayList<>();

        for(MerchantListReq req : reqs){
            MerchantListRes res = new MerchantListRes();
            String mccCode = req.getMccCode();
            String placeDesc = req.getPlaceDesc();
            res.setPlaceDesc(placeDesc);
            res.setMccCode(mccCode);
            if (!CollectionUtils.isEmpty(place)){
                for(SqlResultPlace placeItem : place) {
                    if (prepareString(placeDesc).equals(prepareString(placeItem.getPLACEDESC()))) {
                        res.setPlaceName(placeItem.getPLACENAME());
                        res.setPlaceImg(placeItem.getPLACEIMG());
                    }
                }
            }
            if (!CollectionUtils.isEmpty(mcc)){
                for(SqlResultMcc mccItem : mcc) {
                    if (mccCode.equals(mccItem.getMCCCODE())) {
                        res.setMccImg(mccItem.getMCCIMG());
                        res.setMccName(mccItem.getMCCNAME());
                        break;
                    }
                }
            }

            if (res.isNotNull())
                merchantList.add(res);
        }
        return merchantList;
    }

    private String prepareStringFromArray(List<String> list){
        String retStr = null;
        if (!CollectionUtils.isEmpty(list)) {
            StringBuilder condition;
            if (list.size() > 1) {
                int sz = list.size();
                condition = new StringBuilder();
                for (int i = 0; i < sz; i++) {
                    String value = list.get(i);
                    condition.append("'").append(value).append("'");
                    if (i < sz - 1)
                        condition.append(",");
                }
            } else {
                condition = new StringBuilder("'" + list.get(0) + "'");
            }
            retStr = condition.toString();
        }
        return retStr;
    }

    private String prepareString(String str){
        return str
                .toUpperCase()
                .replaceAll("'","")
                .replaceAll("\\s+","")
                .replaceAll("\\\\","");
    }


    @Override
    public void saveReference(RefenceReq req) {
        String insertQuery = "insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values (?, ?)";
        jdbcTemplate.update(insertQuery, req.getType(), req.getName());

        String selectQuery = "select REFERENCEID from REFERENCE where REFERENCEBRIEF = ?";
        Long referenceid = jdbcTemplate.query(selectQuery, new Object[]{req.getType()}, rs -> rs.next() ? rs.getLong("REFERENCEID") : 0L);

        if (referenceid != null && !referenceid.equals(0L)){
            String insertBatchQuery = "insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (?, ?, ?, ?, ?)";
//            jdbcTemplate.batchUpdate(insertBatchQuery, req.getRefList(), req.getRefList().size(), new ParameterizedPreparedStatementSetter<RefenceReq.Ref>() {
//                @Override
//                public void setValues(PreparedStatement preparedStatement, RefenceReq.Ref ref) throws SQLException {
//                    preparedStatement.setInt(1, referenceid);
//                    preparedStatement.setString(2, ref.getName());
//                    preparedStatement.setString(3, ref.getValue());
//                    preparedStatement.setString(4, ref.getExtraValue());
//                    preparedStatement.setString(5, ref.getCode());
//                }
//            });
            for(RefenceReq.Ref ref : req.getRefList()){
                jdbcTemplate.update(insertBatchQuery, referenceid, ref.getName(), ref.getValue(), ref.getExtraValue(), ref.getCode());
            }
        }
    }
}