package ru.mtsbank.integration.dbo.reference.book.controller.dto.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.mts.dbo.dto.BaseRequest;

import java.util.List;

@Getter @Setter
@ToString
public class RefenceReq extends BaseRequest {
    private String type;
    private String name;
    private List<Ref> refList;
    @Getter @Setter @ToString
    public static class Ref {
        private String name;
        private String value;
        private String extraValue;
        private String code;
    }
}
