    SELECT id, sysname, currency, maxsumma, description FROM paylimits
    WHERE {}