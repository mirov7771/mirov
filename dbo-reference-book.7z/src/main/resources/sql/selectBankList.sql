       SELECT b.BIN,c.BIC,c.BANKID,c.BANKNAME,c.BANKENGNAME,c.CORACCOUNT
         FROM BANKBIN b,BANKBIC c
        WHERE b.BIC = c.BIC
          AND b.BIN IN ('%s%')
        UNION
       SELECT b.BIN,c.BIC,c.BANKID,c.BANKNAME,c.BANKENGNAME,c.CORACCOUNT
         FROM BANKBIC c
    LEFT JOIN  BANKBIN b
           ON b.BIC = c.BIC
         WHERE c.BIC IN ('%ss%')