       SELECT distinct c.BIC,c.BANKID,c.BANKNAME,c.BANKENGNAME,c.CORACCOUNT
         FROM BANKBIC c
        WHERE c.BIC IN ('%s%')