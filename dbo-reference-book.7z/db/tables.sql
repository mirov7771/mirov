CREATE TABLE REFERENCE
(REFERENCEID BIGINT GENERATED ALWAYS AS IDENTITY
,REFERENCEBRIEF VARCHAR(150)
,REFERENCENAME VARCHAR(255));

CREATE INDEX X1_REFERENCE ON REFERENCE(REFERENCEBRIEF);

CREATE TABLE REFERENCEITEMS
(ITEMID BIGINT GENERATED ALWAYS AS IDENTITY
,REFERENCEID BIGINT
,BRIEF VARCHAR(255) NULL
,NAME VARCHAR(755) NULL
,EXTRAVALUE VARCHAR(755) NULL
,CODE VARCHAR(100) NULL
,DESCRIPTION TEXT NULL);

CREATE INDEX X1_REFERENCEITEMS ON REFERENCEITEMS(REFERENCEID);

insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('LoanPurpose', 'Цель кредита ДБО');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('WorkActivity', 'Тип занятости');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('PositionLevel', 'Уровень должности');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('EducationLevel', 'Образование');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('MaritalStatus', 'Семейное положение');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('IPDLStatusCode', 'Публичное должностное лицо');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('Country', 'Страна');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('signTaxResident', 'признаки налогового резидента');
insert into REFERENCE (REFERENCEBRIEF,REFERENCENAME) values ('signTaxpayerUSA', 'принадлежности к налогоплательщика США');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'Обустройство жилья/мебель','ConstructionHouseroom','999999;5000000','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'Туризм','Tourism','999999;5000000','7');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'Кредит на любые цели','AnyPurpose','20000;999999','2');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'На бытовую технику/электронику','BuyElectronics','999999;5000000','6');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'Ремонт/строительство','ConstructionBuilding','999999;5000000','3');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE,DESCRIPTION) values (1,'Рефинансирование кредита','Refinance','20000;5000000','1','При рефинансировании вы должны в течение 90 дней погасить кредит в другом банке. Если этого не сделать,то процентная ставка по кредиту будет увеличена');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'АВТО: Покупка/ремонт/страх-ие','BuyCar','999999;5000000','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (1,'Иное','OtherTarget','999999;5000000','8');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'Пенсионер','WORKACTIVITY.6','Пенсионер','6');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'Иной вид деятельности','WORKACTIVITY.4','Иной вид деятельности','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'Не занят (нет работы, бизнеса)','WORKACTIVITY.5','Не занят (нет работы, бизнеса)','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'ИП/частная практика','WORKACTIVITY.3','ИП/частная практика','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'Работа/служба по найму','WORKACTIVITY.1','Работа/служба по найму','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'Собственный бизнес, доля в уставном капитале','WORKACTIVITY.2','Собственный бизнес, доля в уставном капитале','2');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (2,'Студент','WORKACTIVITY.7','Студент','7');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (3,'Руководитель высшего звена','POSITION.LEVEL.1','Руководитель высшего звена','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (3,'Неруководящий сотрудник/ работник','POSITION.LEVEL.3','Неруководящий сотрудник/ работник','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (3,'Руководитель среднего/ низового звена','POSITION.LEVEL.2' ,'Руководитель среднего/ низового звена','2');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (4,'Два и более высших/ аспирантура/ ученая степень','EDUCATION.LEVEL.6','Два и более высших/ аспирантура/ ученая степень','6');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (4,'Не оконченное высшее','EDUCATION.LEVEL.4','Не оконченное высшее','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (4,'Высшее','EDUCATION.LEVEL.5','Высшее','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (4,'Начальное/ среднее профессиональное','EDUCATION.LEVEL.3','Начальное/ среднее профессиональное','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (4,'Неоконченное среднее','EDUCATION.LEVEL.1','Неоконченное среднее','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (4,'Среднее общее','EDUCATION.LEVEL.2','Среднее общее','2');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (5,'Гражданский брак','FAMILY.STATUS.5','Гражданский брак','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (5,'Разведен(а)','FAMILY.STATUS.4','Разведен(а)','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (5,'Замужем/ женат','FAMILY.STATUS.2','Замужем/ женат','2');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (5,'Вдова/ вдовец','FAMILY.STATUS.3','Вдова/ вдовец','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (5,'В браке не состоял(а)','FAMILY.STATUS.1','В браке не состоял(а)','1');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (6,'Никем из перечисленных не являюсь','IPDL.4','Никем из перечисленных не являюсь','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (6,'Публичным должностным лицом (ПДЛ)','IPDL.5','Публичным должностным лицом (ПДЛ)','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (6,'Действующим от имени иностранного публичного должностного лица','IPDL.3','Действующим от имени иностранного публичного должностного лица','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (6,'Иностранным публичным должностным лицом','IPDL.1','Иностранным публичным должностным лицом','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (6,'Супруг(ом/ой), родственником иностранного публичного должностного лица','IPDL.2','Супруг(ом/ой), родственником иностранного публичного должностного лица','2');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Австрия','40','Австрия','2');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Босния и Герцеговина','70','Босния и Герцеговина','9');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Дания','208','Дания','16');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Испания','724','Испания','23');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Корея (Республика)','410','Корея (Республика)','30');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Малайзия','458','Малайзия','37');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Пакистан','586','Пакистан','44');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Таджикистан','762','Таджикистан','51');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Франция','250','Франция','58');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Япония','392','Япония','65');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Бельгия','56','Бельгия','7');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Греция','300','Греция','14');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Ирландия','372','Ирландия','21');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Киргизия','417','Киргизия','28');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Люксембург','442','Люксембург','35');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Нидерланды','528','Нидерланды','42');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Словения','705','Словения','49');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Узбекистан','860','Узбекистан','56');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Эстония','233','Эстония','63');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Абхазия','895','Абхазия','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Болгария','100','Болгария','8');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Грузия','268','Грузия','15');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Исландия','352','Исландия','22');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Китай','156','Китай','29');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Македония','807','Македония','36');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Норвегия','578','Норвегия','43');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Соединенные Штаты Америки','840','Соединенные Штаты Америки','50');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Украина','804','Украина','57');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Югославия','891','Югославия','64');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Беларусь','112','Беларусь','6');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Германия','276','Германия','13');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Индонезия','360','Индонезия','20');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Кипр','196','Кипр','27');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Лихтенштейн','438','Лихтенштейн','34');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Монголия','496','Монголия','41');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Словакия','703','Словакия','48');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Турция','792','Турция','55');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Швеция','752','Швеция','62');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Армения','51','Армения','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Венгрия','348','Венгрия','11');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Израиль','376','Израиль','18');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Казахстан','398','Казахстан','25');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Латвия','428','Латвия','32');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Молдова','498','Молдова','39');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Россия','643','Россия','46');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Тайвань','158','Тайвань','53');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Чехия','203','Чехия','60');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Афганистан','4','Афганистан','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Вьетнам','704','Вьетнам','12');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Индия','356','Индия','19');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Канада','124','Канада','26');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Литва','440','Литва','33');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Монако','492','Монако','40');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Румыния','642','Румыния','47');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Туркмения','795','Туркмения','54');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Швейцария','756','Швейцария','61');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Азербайджан','31','Азербайджан','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Великобритания','826','Великобритания','10');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Египет','818','Египет','17');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Италия','380','Италия','24');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Куба','192','Куба','31');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Мальта','470','Мальта','38');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Польша','616','Польша','45');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Таиланд','764','Таиланд','52');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (7,'Хорватия','191','Хорватия','59');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Идентификация соответствующего лица как налогового резидента иностранного государства (наличие иностранного идентификационного номера налогоплательщика (его аналог), отличного от присваиваемого каждому налогоплательщику единого на всей территории Российской Федерации по всем видам налогов и сборов ИНН в соответствии с пунктом 7 статьи 84 Налогового кодекса Российской Федерации)','1','Идентификация соответствующего лица как налогового резидента иностранного государства (наличие иностранного идентификационного номера налогоплательщика (его аналог), отличного от присваиваемого каждому налогоплательщику единого на всей территории Российской Федерации по всем видам налогов и сборов ИНН в соответствии с пунктом 7 статьи 84 Налогового кодекса Российской Федерации)','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Паспорт гражданина иностранного государства (территории)','2','Паспорт гражданина иностранного государства (территории)','2');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Адрес места фактического проживания или почтовый адрес в иностранном государстве','3','Адрес места фактического проживания или почтовый адрес в иностранном государстве','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Номер телефона в иностранном государстве (при отсутствии российского телефонного номера)','4','Номер телефона в иностранном государстве (при отсутствии российского телефонного номера)','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Поручение на постоянное перечисление средств на счет или адрес в иностранном государстве','5','Поручение на постоянное перечисление средств на счет или адрес в иностранном государстве','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Доверенность или право подписи, предоставленные лицу, проживающему в иностранном государстве','6','Доверенность или право подписи, предоставленные лицу, проживающему в иностранном государстве','6');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (8,'Адрес до востребования в иностранной юрисдикции (в отсутствии иного адреса в отношении данного клиента, выгодоприобретателя или бенефициарного владельца)','8','Адрес до востребования в иностранной юрисдикции (в отсутствии иного адреса в отношении данного клиента, выгодоприобретателя или бенефициарного владельца)','8');

insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (9,'Вы родились в США','1','Вы родились в США','1');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (9,'Наличие гражданства США, в т.ч. одновременно с гражданством РФ или другого государства','2','Наличие гражданства США, в т.ч. одновременно с гражданством РФ или другого государства','2');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (9,'Наличие green-cardили иного документа, подтверждающего вид на жительство в США','3','Наличие green-cardили иного документа, подтверждающего вид на жительство в США','3');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (9,'Адрес регистрации в США','4','Адрес регистрации в США','4');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (9,'Адрес места жительства в США','5','Адрес места жительства в США','5');
insert into REFERENCEITEMS(REFERENCEID,NAME,BRIEF,EXTRAVALUE,CODE) values (9,'Номер телефона зарегистрирован в США (начинается с +1)','6','Номер телефона зарегистрирован в США (начинается с +1)','6');

/////////////////////////////////////////////////////////////
CREATE TABLE BANKBIN
(BIN VARCHAR(255)
,BIC VARCHAR(20)
,BANKENGNAME TEXT);

CREATE INDEX X1_BANKBIN ON BANKBIN(BIN);

CREATE TABLE BANKBIC
(BIC VARCHAR(200)
,BANKID VARCHAR(200) NULL
,BANKNAME VARCHAR(255)
,BANKENGNAME VARCHAR(255)
,CORACCOUNT VARCHAR(255) NULL);

CREATE INDEX X1_BANKBIC ON BANKBIC(BANKENGNAME);

CREATE TABLE PLACEINFO
(PLACEID  BIGINT GENERATED ALWAYS AS IDENTITY
,PLACEDESC VARCHAR(255) NULL
,PLACENAME VARCHAR(255) NULL
,PLACEIMG VARCHAR(255) NULL);

CREATE INDEX X1_PLACEINFO ON PLACEINFO(PLACEDESC);

CREATE TABLE MCCINFO
(MCCCODE VARCHAR(150)
,MCCNAME VARCHAR(255) NULL
,MCCIMG VARCHAR(255) NULL);

CREATE INDEX X1_MCCINFO ON MCCINFO(MCCCODE);

CREATE TABLE public.paylimits
(
    id bigint,
    sysname character varying(64) COLLATE pg_catalog."default",
    currency character varying(3) COLLATE pg_catalog."default",
    maxsumma numeric(38,2),
    description character varying(255) COLLATE pg_catalog."default",
    rboid bigint
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;
