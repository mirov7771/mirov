package ru.sberx.user.auth.dao.model.other;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.dto.user.auth.res.AuthRes;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "SESSION_CONFIG")
@Getter
@Setter
@NoArgsConstructor
public class SessionConfig implements Serializable {

    private static final long serialVersionUID = -8029453999833992634L;

    @Id
    @Column(name = "CLIENTID")
    private String clientId;
    @Column(name = "SESSIONTIMEOUT")
    private Integer sessionTimeout;
    @Column(name = "RESPONSETYPE")
    private String responseType;
    @Column(name = "SCOPE")
    private String scope;
    @Column(name = "REDIRECTURI")
    private String redirectUri;
    @Column(name = "STATE")
    private String state;
    @Column(name = "CLIENTSECRET")
    private String clientSecret;
    @Column(name = "GRANTTYPE")
    private String grantType;
    @Column(name = "OPENID_URI")
    private String openidUri;

    public SessionConfig(SessionConfig config, AuthRes res, String clientSecret) {
        this.clientId = res.getNonce();
        this.sessionTimeout = config.getSessionTimeout();
        this.responseType = config.getResponseType();
        this.scope = config.getScope();
        this.redirectUri = res.getRedirectUri();
        this.state = config.getState();
        this.clientSecret = clientSecret;
        this.grantType = config.getGrantType();
        this.openidUri = config.getOpenidUri();
    }
}
