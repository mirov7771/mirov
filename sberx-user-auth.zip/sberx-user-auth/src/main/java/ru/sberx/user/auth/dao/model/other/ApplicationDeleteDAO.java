package ru.sberx.user.auth.dao.model.other;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "APPLICATION_DELETE")
@Getter
@Setter
@NoArgsConstructor
public class ApplicationDeleteDAO implements Serializable {

    private static final long serialVersionUID = 3251161455761476057L;

    @Id
    @Column(name = "APPLICATION_ID")
    private Long applicationId;
    @Column(name = "USER_ID")
    private Long userId;
    @Column(name = "DATE")
    private Date date;

    public ApplicationDeleteDAO(Long id, Long userId, Date date) {
        this.applicationId = id;
        this.userId = userId;
        this.date = date;
    }
}
