package ru.sberx.user.auth.dao.model.user;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "USER_ROLE_LINK")
@Getter
@Setter
public class UserRoleLink implements Serializable {

    private static final long serialVersionUID = -1582374837915595407L;

    @Id
    @Column(name = "LINKID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long linkId;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "ROLEID")
    private Long roleId;
    @OneToOne
    @JoinColumn(name = "ROLEID", referencedColumnName = "ROLEID", updatable = false, insertable = false)
    private UserRole userRole;

}
