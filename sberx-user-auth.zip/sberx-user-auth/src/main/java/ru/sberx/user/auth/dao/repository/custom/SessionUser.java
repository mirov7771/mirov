package ru.sberx.user.auth.dao.repository.custom;

import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter @Setter
public class SessionUser {
    private String login;
    private Date expiry;
    private Long userId;
    private Long externalId;
}
