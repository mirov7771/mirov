package ru.sberx.user.auth.service.impl.method.auth;

import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.external.gate.dto.SbUserInfo;
import ru.sberx.user.auth.dao.model.other.SessionConfig;

@Component("login")
public class Login extends AuthService {

    @Override
    public AuthRes execute(AuthReq req) {
        if (req.getCode() == null || req.getState() == null || req.getSessionState() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: grant_type, code, state, session_state");
        String state = req.getState() != null ? req.getState() : req.getSessionState();
        AuthRes res = new AuthRes();
        SessionConfig config = getConfiguration(req.getNonce(), req.getClientId());
        if (config == null)
            throw new SberxException(SberxErrors.INVALID_SESSION);
        if (!state.equalsIgnoreCase(config.getState()))
            throw new SberxException(SberxErrors.INVALID_SESSION, String.format("Wrong state: client state %s, suid state %s", config.getState(), state));
        UserToken userToken = checkToken(getBodyForRequest(req, config));
        if (!config.getClientId().equalsIgnoreCase(userToken.getNonce()))
            throw new SberxException(SberxErrors.INVALID_SESSION, String.format("Wrong nonce: client nonce %s, suid nonce %s", config.getClientId(), userToken.getNonce()));
        SbUserInfo info = externalService.getJwtToken(userToken.getAccessToken());
        if (info == null || info.getSub() == null)
            throw new SberxException(SberxErrors.AUTHORIZATION_FAILED);
        if (info.getUserId() == null) {
            if (info.getSub().length() > 50)
                info.setUserId(info.getSub().substring(50));
            else
                info.setUserId(info.getSub());
        }
        createClientSession(info, config, res, userToken.getRefreshToken(), userToken.getExp());
        return res;
    }

    private String getBodyForRequest(AuthReq req, SessionConfig config){
        return "grant_type=" + config.getGrantType() +
                "&code=" + req.getCode() +
                "&client_id=sberunity" +
                "&client_secret=" + clientSecret +
                "&redirect_uri=" + config.getRedirectUri();
    }

}
