package ru.sberx.user.auth.dao.model.consent;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "USER_CONSENT")
@Getter
@Setter
@NoArgsConstructor
public class UserConsent implements Serializable {

    private static final long serialVersionUID = 5181797368337407634L;

    @Id
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "TERMSID")
    private Long termsId;
    @Column(name = "POLICYID")
    private Long policyId;
    @Column(name = "SBER_500_PRIVACY_POLICY_ID")
    private Long sber500PrivacyPolicyId;
    @Column(name = "SBER_500_CONSENT_ID")
    private Long sber500ConsentId;
    @Column(name = "SBER_500_TERM_OF_USE_ID")
    private Long sber500TermOfUseId;
    @Column(name = "SBER_500_PERSONAL_DATA_CONSENT_ID")
    private Long sber500PersonalDataConsentId;
    @Column(name = "SIGNDTTM")
    private Date signDttm;
    @Column(name = "MAILING_CONSENT")
    private Long mailingConsent;

}
