package ru.sberx.user.auth.service.job;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.dto.activity.req.GetReq;
import ru.sberx.dto.activity.res.ReplyGetRes;
import ru.sberx.dto.activity.support.ReplyInfoDto;
import ru.sberx.dto.notifications.req.NotifyReq;
import ru.sberx.dto.notifications.support.NoticeDto;
import ru.sberx.dto.questionary.questionary.pilot.req.PilotListReq;
import ru.sberx.dto.questionary.questionary.pilot.res.PilotListRes;
import ru.sberx.dto.questionary.questionary.pilot.support.PilotDto;
import ru.sberx.dto.questionary.questionary.questionary.req.QuestionnaireListReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.questionary.questionary.questionary.support.QuestionnaireDto;
import ru.sberx.dto.questionary.questionary.round.req.RoundListReq;
import ru.sberx.dto.questionary.questionary.round.res.RoundListRes;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.unity.gate.activity.ActivityService;
import ru.sberx.unity.gate.notifications.NotificationService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.user.auth.dao.model.other.ApplicationDeleteDAO;
import ru.sberx.user.auth.dao.model.other.DeleteInfo;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.consent.UserConsentRepository;
import ru.sberx.user.auth.dao.repository.custom.SessionUser;
import ru.sberx.user.auth.dao.repository.other.ApplicationDeleteDAORepository;
import ru.sberx.user.auth.dao.repository.other.DeleteInfoRepository;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;
import ru.sberx.user.auth.dao.repository.user.UserProfileRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleLinkRepository;
import ru.sberx.user.auth.dao.repository.user.UserSessionRepository;
import ru.sberx.user.auth.service.impl.method.auth.DeleteUser;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@EnableAsync
@Component
@RequiredArgsConstructor
@Slf4j
public class JobService {

    private final DeleteInfoRepository deleteInfoRepository;
    private final UserEntityRepository userEntityRepository;
    private final UserRoleLinkRepository userRoleLinkRepository;
    private final UserSessionRepository userSessionRepository;
    private final UserProfileRepository userProfileRepository;
    private final UserConsentRepository userConsentRepository;
    private final QuestionaryService questionaryService;
    private final NotificationService notificationService;
    private final ActivityService activityService;
    private final ApplicationDeleteDAORepository applicationDeleteDAORepository;
    private final DeleteUser deleteUser;

    @Value("${application.notify.investor}")
    private Integer investor;
    @Value("${application.notify.corporate}")
    private Integer corporate;

    private static final List<Long> APPROVE_STATE = List.of(20004L);
    private static final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ssZ");

    @Scheduled(cron = "${application.cron}")
    public void setNewFlag(){
        log.info("started job at {}", new Date());
        List<UserEntity> newUsers = userEntityRepository.findNewUsers(new Date());
        if (!CollectionUtils.isEmpty(newUsers)){
            newUsers.forEach(ue -> {
                Long id = ue.getUserId();
                if (ue.getExternalId() != null) {
                    Long eId = ue.getExternalId();
                    userProfileRepository.deleteById(eId);
                }
                userEntityRepository.deleteByUserId(id);
                userRoleLinkRepository.deleteByUserId(id);
                userSessionRepository.deleteByUserId(id);
                userConsentRepository.deleteByUserId(id);

                DeleteInfo deleteInfo = new DeleteInfo();
                deleteInfo.setUserId(id);
                deleteInfo.setQuestionnaireId(0L);
                deleteInfo.setDeleteDttm(new Date());
                deleteInfo.setComment("Удаление по истечению срока жизни временного пароля");
                deleteInfoRepository.save(deleteInfo);
            });
        }

        //STARTUPHUB-4531 [BACK] удаление профиля пользователя по его инициативе
        applicationDelete();
        log.info("end job at {}", new Date());
    }

    @Scheduled(cron = "${application.cron-users}")
    public void notifyUsers(){
        //STARTUPHUB-3749 [BACK] логика для schedule для инвестора, который не заходил 504 ч
        notifyInvestors();
        //STARTUPHUB-3742 [BACK] логика для schedule для корпораций -отклики на пилоты
        notifyCorporate();
    }

    private void notifyInvestors(){
        List<SessionUser> users = userSessionRepository.findByExpiry(2, getDaysDiff(investor));
        if (!CollectionUtils.isEmpty(users)){
            ThreadContext.put("requestId", UUID.randomUUID().toString());
            ThreadContext.put("client-id", "8385");
            Optional<Date> min = users.stream().map(SessionUser::getExpiry).min(Date::compareTo);
            QuestionnaireListReq qReq = new QuestionnaireListReq();
            qReq.setType(0);
            qReq.setState(APPROVE_STATE);
            RoundListReq rReq = new RoundListReq();
            rReq.setState(APPROVE_STATE);
            min.ifPresent(date -> {
                qReq.setFromDateTime(dateFormat.format(date));
                rReq.setFromDateTime(dateFormat.format(date));
            });
            List<QuestionnaireDto> questionnaireList = questionaryService.getQuestionnaireList(qReq);
            RoundListRes roundList = questionaryService.getRoundList(rReq);

            for(SessionUser user : users){
                Map<String, Object> params = new HashMap<>();
                long newStartup = 0;
                long newRound = 0;
                if (!CollectionUtils.isEmpty(questionnaireList))
                    newStartup = questionnaireList.stream().filter(i -> i.getCreated().after(user.getExpiry())).count();

                if (!CollectionUtils.isEmpty(roundList.getList()))
                    newRound = roundList.getList().stream().filter(i -> i.getCreated().after(user.getExpiry())).count();

                if (newStartup == 0 && newRound == 0)
                    continue;
                params.put("NewStartup", newStartup);
                params.put("NewRound", newRound);
                NotifyReq req = new NotifyReq();
                req.setParams(params);
                req.setReceiver(user.getLogin());
                req.setSysName("InvestorRemine");
                req.setType(NotifyReq.Types.EMAIL);
                notificationService.notify(req);

                //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
                if (user.getUserId() != null) {
                    NoticeDto noticeReq = new NoticeDto();
                    noticeReq.setTemplateSysName("InvestorRemine");
                    noticeReq.setParams(params);
                    noticeReq.setUserId(user.getUserId());
                    noticeReq.setEvent("Авторизация");
                    notificationService.notice(noticeReq);
                }

                //удаляем сессии чтобы повторно не отправлять письма
                userSessionRepository.deleteByUserId(user.getUserId());
            }
        }
    }

    private void notifyCorporate(){
        List<SessionUser> users = userSessionRepository.findByExpiry(1, getDaysDiff(corporate));
        if (!CollectionUtils.isEmpty(users)) {
            setContext();
            PilotListReq pReq = new PilotListReq();
            pReq.setUserId(users.stream().map(SessionUser::getExternalId).collect(Collectors.toList()));
            pReq.setState(APPROVE_STATE);
            PilotListRes res = questionaryService.getPilotsList(pReq);
            List<PilotDto> pilotList = res != null ? res.getList() : null;
            if (!CollectionUtils.isEmpty(pilotList)){
                for(SessionUser user : users){
                    List<PilotDto> pilotForUser = pilotList
                            .stream()
                            .filter(i -> i.getUserId().contains(user.getExternalId()))
                            .collect(Collectors.toList());
                    if (CollectionUtils.isEmpty(pilotForUser))
                        continue;

                    GetReq gReq = new GetReq();
                    gReq.setName("Pilot");
                    gReq.setId(pilotForUser.stream().map(PilotDto::getPilotId).collect(Collectors.toList()));
                    gReq.setDays(getDaysDiff(new Date(), user.getExpiry()));
                    List<ReplyGetRes> replies = activityService.getReplies(gReq);
                    if (CollectionUtils.isEmpty(replies) || replies.stream().allMatch(i -> i.getTotalCount().equals(0)))
                        continue;

                    int sum = replies.stream().mapToInt(ReplyGetRes::getTotalCount).sum();
                    Map<String, Object> params = new HashMap<>();

                    params.put("newReply", sum);
                    params.put("text", sum == 1 ? "непросмотренный отклик" : "непросмотренных откликов");
                    NotifyReq req = new NotifyReq();
                    req.setParams(params);
                    req.setReceiver(user.getLogin());
                    req.setSysName("NewReply");
                    req.setType(NotifyReq.Types.EMAIL);
                    notificationService.notify(req);

                    //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
                    if (user.getUserId() != null) {
                        NoticeDto noticeReq = new NoticeDto();
                        noticeReq.setTemplateSysName("NewReply");
                        noticeReq.setParams(params);
                        noticeReq.setUserId(user.getUserId());
                        noticeReq.setEvent("Авторизация");
                        notificationService.notice(noticeReq);
                    }

                    //удаляем сессии чтобы повторно не отправлять письма
                    userSessionRepository.deleteByUserId(user.getUserId());
                }
            }
        }
    }

    @Scheduled(cron = "${application.cron-reply}")
    public void notifyForReply(){
        List<UserEntity> users = userEntityRepository.findByUserRole(1);
        if (!CollectionUtils.isEmpty(users)) {
            setContext();
            PilotListReq pReq = new PilotListReq();
            pReq.setUserId(users.stream().map(UserEntity::getExternalId).collect(Collectors.toList()));
            pReq.setState(APPROVE_STATE);
            PilotListRes res = questionaryService.getPilotsList(pReq);
            List<PilotDto> pilotList = res != null ? res.getList() : null;
            if (!CollectionUtils.isEmpty(pilotList)){
                for(UserEntity user : users) {
                    if (user.getExternalId() != null) {
                        List<PilotDto> pilotForUser = pilotList
                                .stream()
                                .filter(i -> i.getUserId().contains(user.getExternalId()))
                                .collect(Collectors.toList());
                        if (CollectionUtils.isEmpty(pilotForUser))
                            continue;

                        GetReq gReq = new GetReq();
                        gReq.setName("Pilot");
                        gReq.setId(pilotForUser.stream().map(PilotDto::getPilotId).collect(Collectors.toList()));
                        List<ReplyGetRes> replies = activityService.getReplies(gReq);

                        List<TypeRes> types = questionaryService.getTypeByUserId(user.getExternalId());
                        List<ReplyGetRes> offers = null;
                        if (!CollectionUtils.isEmpty(types)){
                            gReq = new GetReq();
                            gReq.setIsPilotOffer(true);
                            gReq.setId(List.of(types.get(0).getQuestionnaireId()));
                            gReq.setName("Questionnaire");
                            offers = activityService.getReplies(gReq);
                        }
                        int newReply = 0;
                        int newOffer = 0;

                        if (!CollectionUtils.isEmpty(replies) && replies.stream().noneMatch(i -> CollectionUtils.isEmpty(i.getReplies()))) {
                            for (ReplyGetRes r : replies) {
                                if (!CollectionUtils.isEmpty(r.getReplies())) {
                                    for (ReplyInfoDto d : r.getReplies()) {
                                        if (d.getState().equals(20011L) && !Boolean.TRUE.equals(d.getIsPilotOffer()))
                                            newReply += 1;
                                    }
                                }
                            }
                        }

                        if (!CollectionUtils.isEmpty(offers) && offers.stream().noneMatch(i -> CollectionUtils.isEmpty(i.getReplies()))) {
                            for (ReplyGetRes r : offers) {
                                if (!CollectionUtils.isEmpty(r.getReplies())) {
                                    for (ReplyInfoDto d : r.getReplies()) {
                                        if (d.getState().equals(20011L) && Boolean.TRUE.equals(d.getIsPilotOffer()))
                                            newOffer += 1;
                                    }
                                }
                            }
                        }

                        if (newReply == 0 && newOffer == 0)
                            continue;

                        Map<String, Object> params = new HashMap<>();

                        if (newReply == 1 && newOffer == 0) {
                            params.put("newReply", 1);
                            params.put("text1", "новый отклик на ваш запрос");
                        } else if (newReply == 1 && newOffer == 1) {
                            params.put("newReply", 1);
                            params.put("text1", "новый отклик на ваш запрос");
                            params.put("text2", "и");
                            params.put("newOffer", 1);
                            params.put("text3", "предложение на проведение совместного пилота от стартапа");
                        } else if (newReply == 1 && newOffer > 1) {
                            params.put("newReply", 1);
                            params.put("text1", "новых откликов на ваши запросы");
                            params.put("text2", "и");
                            params.put("newOffer", newOffer);
                            params.put("text3", "предложений на проведение совместного пилота от стартапа");
                        } else if (newReply > 1 && newOffer == 0) {
                            params.put("newReply", newReply);
                            params.put("text1", "новый отклик на ваш запрос");
                        } else if (newReply > 1 && newOffer > 1) {
                            params.put("newReply", newReply);
                            params.put("text1", "новых откликов на ваши запросы");
                            params.put("text2", "и");
                            params.put("newOffer", newOffer);
                            params.put("text3", "предложений на проведение совместного пилота от стартапа");
                        } else if (newReply == 0 && newOffer == 1) {
                            params.put("newOffer", newOffer);
                            params.put("text3", "предложение на проведение совместного пилота от стартапа");
                        } else if (newReply == 0 && newOffer > 1) {
                            params.put("newOffer", newOffer);
                            params.put("text3", "предложений на проведение совместного пилота от стартапа");
                        }
                        NotifyReq req = new NotifyReq();
                        req.setParams(params);
                        req.setReceiver(user.getLogin());
                        req.setSysName("NewReply");
                        req.setType(NotifyReq.Types.EMAIL);
                        notificationService.notify(req);

                        //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
                        if (user.getUserId() != null) {
                            NoticeDto noticeReq = new NoticeDto();
                            noticeReq.setTemplateSysName("NewReply");
                            noticeReq.setParams(params);
                            noticeReq.setUserId(user.getUserId());
                            noticeReq.setEvent("Авторизация");
                            notificationService.notice(noticeReq);
                        }
                    }
                }
            }
        }
    }

    private void applicationDelete(){
        List<ApplicationDeleteDAO> list = applicationDeleteDAORepository.findByDateBefore(new Date());
        if (!CollectionUtils.isEmpty(list)){
            list.forEach(i -> {
                AuthReq req = new AuthReq();
                req.setQuestionnaireId(i.getApplicationId());
                req.setUserId(i.getUserId());
                AuthRes res = deleteUser.deleteUserInJobMode(req);
                if (res != null && StringUtils.hasText(res.getLogin())) {
                    if (res.getDeleteRes() != null) {
                        notifyAboutApplicationDelete(res.getLogin(), res.getDeleteRes().getFullName(), i.getDate());
                    } else {
                        notifyAboutApplicationDelete(res.getLogin(), "", i.getDate());
                    }
                }
                applicationDeleteDAORepository.deleteByUserId(i.getUserId());
            });
        }
    }

    private void notifyAboutApplicationDelete(String login, String fullName, Date date) {
        if (!StringUtils.hasText(login))
            return;

        Map<String, Object> params = new HashMap<>();
        params.put("userName", login);
        if (date != null) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.DAY_OF_MONTH, -5);
            SimpleDateFormat format = new SimpleDateFormat(
                    "yyyy-MM-dd HH:mm");
            params.put("appDate", format.format(cal.getTime()));
        } else {
            params.put("appDate", "-");
        }
        params.put("fullName", Objects.requireNonNullElse(fullName, ""));

        NotifyReq req = new NotifyReq();
        req.setParams(params);
        req.setReceiver(login);
        req.setSysName("profileDeletion");
        req.setType(NotifyReq.Types.EMAIL);
        notificationService.notify(req);
    }

    private void setContext(){
        ThreadContext.put("requestId", UUID.randomUUID().toString());
        ThreadContext.put("client-id", "8385");
    }

    private Date getDaysDiff(Integer amount){
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.add(Calendar.HOUR, amount);
        return dateCalendar.getTime();
    }

    private int getDaysDiff(Date date1, Date date2){
        long milliseconds = date1.getTime() - date2.getTime();
        return  (int) (milliseconds / (24 * 60 * 60 * 1000));
    }
}
