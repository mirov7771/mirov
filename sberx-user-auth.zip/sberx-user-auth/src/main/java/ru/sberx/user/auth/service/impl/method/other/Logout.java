package ru.sberx.user.auth.service.impl.method.other;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.external.gate.SberUserIdService;
import ru.sberx.user.auth.dao.model.other.SessionConfig;
import ru.sberx.user.auth.dao.model.user.UserSession;
import ru.sberx.user.auth.dao.repository.other.SessionConfigRepository;
import ru.sberx.user.auth.dao.repository.user.UserSessionRepository;
import ru.sberx.user.auth.service.impl.method.auth.util.Status;

@Component
@RequiredArgsConstructor
public class Logout {

    private final UserSessionRepository userSessionRepository;
    private final SberUserIdService externalService;
    private final SessionConfigRepository sessionConfigRepository;

    @Value("${application.auth.client-secret:0}")
    protected String clientSecret;

    public AuthRes execute(String sessionId) {
        UserSession session = userSessionRepository.findBySessionId(sessionId);
        String id = session != null ? session.getClientId() : null;
        String token = session != null ? session.getRefreshToken() : null;
        userSessionRepository.delete(sessionId);
        AuthRes res = new AuthRes();
        res.setStatus(Status.OK.toString());

        try {
            if (StringUtils.hasText(id)
                    && StringUtils.hasText(token)) {
                SessionConfig config = sessionConfigRepository.findByClientId(id);
                if (config != null)
                    externalService.logout("refresh_token=" + token +
                            "&client_id=sberunity" +
                            "&client_secret=" + clientSecret);
                sessionConfigRepository.deleteById(id);
            }
        } catch (Exception e){
            e.printStackTrace();
        }

        return res;
    }

}
