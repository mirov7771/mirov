package ru.sberx.user.auth.dao.model.access;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "API_ACCESS_RIGHTS")
@Entity
@Getter
@Setter
public class ApiAccessRight implements Serializable {

    private static final long serialVersionUID = 6836516956721918801L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "METHOD")
    private String method;
    @Column(name = "ACTION")
    private String action;
    @Column(name = "PARAMS")
    private String params;

}
