package ru.sberx.user.auth.service.impl.method.auth;

import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.external.gate.dto.SbUserInfo;
import ru.sberx.user.auth.dao.model.other.SessionConfig;

import java.util.Base64;

@Component("mocklogin")
public class MockLogin extends AuthService {

    private static final Base64.Encoder encoder = Base64.getEncoder();

    @Override
    public AuthRes execute(AuthReq req) {
        AuthRes res = new AuthRes();
        SessionConfig config = getConfiguration(null, req.getClientId());
        String base_part = "{\"sub\":\"sber_bus_id\",\"aud\":\"111260\",\"orgOgrn\":\"1127746210597\",\"iss\":\"https://edupirfintech.sberbank.ru:9443\",\"name\":\"Фам59701 Имя59701 Отч59701\",\"inn\":\"5092906610\",\"orgJuridicalAddress\":\"121222, Россия, г.Москва, г. Москва, ул.Космонавтов, д.1, корп./стр.1, кв.1\",\"phone_number\":\"79057305971\",\"orgFullName\":\"Общество с ограниченной ответственностью ПАРТНЕР-597\\\"\",\"OrgName\":\"ООО \\\"ПАРТНЕР-597\\\"\",\"userId\":85575,\"email\":\"Partner_Test59701@test.ru\"}";
        String mock_jwt = "start.base_part.end";
        base_part = base_part.replace("sber_bus_id", req.getCode());
        SbUserInfo info = getInfoFromToken(mock_jwt.replace("base_part", encoder.encodeToString(base_part.getBytes())));
        createClientSession(info, config, res, null, null);
        return res;
    }
}
