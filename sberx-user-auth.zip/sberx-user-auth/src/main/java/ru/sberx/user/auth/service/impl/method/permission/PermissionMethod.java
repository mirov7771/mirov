package ru.sberx.user.auth.service.impl.method.permission;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.support.Permission;
import ru.sberx.user.auth.dao.model.permission.PermissionRoleLink;
import ru.sberx.user.auth.dao.model.permission.Permissions;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.repository.permission.PermissionRoleLinkRepository;
import ru.sberx.user.auth.dao.repository.permission.PermissionsRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class PermissionMethod {

    private final PermissionRoleLinkRepository permissionRoleLinkRepository;
    private final PermissionsRepository permissionsRepository;
    private final UserRoleRepository userRoleRepository;

    public List<Permission> list(){
        List<Permissions> permissions = permissionsRepository.findAll();
        return permissions.stream().map(Permissions::toFullDto).collect(Collectors.toList());
    }

    public Permission save(Permission req){
        Permission res = new Permission();
        res.setId(permissionsRepository.save(new Permissions(req)).getId());
        return res;
    }

    public void delete(Long id){
        permissionsRepository.deleteById(id);
        permissionRoleLinkRepository.deleteByPermissionId(id);
    }

    public void permissionToRole(AuthReq req){
        UserRole role = userRoleRepository.findByRoleSysName(req.getRole());
        if (role == null || role.getRoleId() == null)
            role = userRoleRepository.save(new UserRole(req.getRole()));
        permissionRoleLinkRepository.deleteByRoleId(role.getRoleId());

        for(Permission permission : req.getPermissions()){
            Optional<Permissions> permissionOpt = permissionsRepository.findByTypeAndName(permission.getType(), permission.getName());
            Permissions permissionsDao;
            if (permissionOpt.isEmpty())
                permissionsDao = permissionsRepository.save(new Permissions(permission));
            else
                permissionsDao = permissionOpt.get();
            PermissionRoleLink link = new PermissionRoleLink();
            link.setRoleId(role.getRoleId());
            link.setPermissionId(permissionsDao.getId());
            permissionRoleLinkRepository.save(link);
        }

    }
}
