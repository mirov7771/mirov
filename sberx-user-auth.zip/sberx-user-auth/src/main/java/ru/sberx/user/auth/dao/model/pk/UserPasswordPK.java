package ru.sberx.user.auth.dao.model.pk;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserPasswordPK implements Serializable {
    private static final long serialVersionUID = 5641707353751905628L;
    private Long userId;
    private String password;
}
