package ru.sberx.user.auth.dao.repository.custom;

import org.hibernate.transform.ResultTransformer;

import java.util.List;

@FunctionalInterface
public interface ListResultTransformer extends ResultTransformer {
    @Override
    default List transformList(List tuples) {
        return tuples;
    }
}
