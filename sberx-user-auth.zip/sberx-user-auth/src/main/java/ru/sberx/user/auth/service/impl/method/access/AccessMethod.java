package ru.sberx.user.auth.service.impl.method.access;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.user.auth.support.Access;
import ru.sberx.user.auth.dao.model.access.RoleAccessLink;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.repository.access.RoleAccessLinkRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class AccessMethod {

    private final RoleAccessLinkRepository roleAccessLinkRepository;
    private final UserRoleRepository userRoleRepository;

    public List<Access> getAccess(){
        List<Access> res = new ArrayList<>();
        List<RoleAccessLink> roleAccessLinks = roleAccessLinkRepository.findAll();
        if (!CollectionUtils.isEmpty(roleAccessLinks)){
            List<UserRole> roles = userRoleRepository
                    .findByRoleIdIn(roleAccessLinks.stream()
                            .map(RoleAccessLink::getRoleId)
                            .distinct().collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(roles)){
                for(UserRole role : roles){
                    Access access = new Access();
                    access.setRole(role.getRoleSysName());
                    access.setApi(new ArrayList<>());
                    for(RoleAccessLink link : roleAccessLinks){
                        if (role.getRoleId().equals(link.getRoleId()) && link.getAccessRight() != null) {
                            Access.Api api = new Access.Api();
                            api.setMethod(link.getAccessRight().getMethod());
                            api.setAction(link.getAccessRight().getAction());
                            api.setParams(link.getAccessRight().getParams());
                            access.getApi().add(api);
                        }
                    }
                    res.add(access);
                }
            }
        }
        return res;
    }

}
