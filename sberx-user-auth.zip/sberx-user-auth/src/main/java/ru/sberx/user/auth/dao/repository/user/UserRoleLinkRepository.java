package ru.sberx.user.auth.dao.repository.user;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;

import java.util.List;

@Repository
public interface UserRoleLinkRepository extends CrudRepository<UserRoleLink, Long> {

    @Transactional
    @Modifying
    @Query("delete from UserRoleLink where userId = :userId")
    void deleteByUserId(@Param("userId") Long userId);
    List<UserRoleLink> findByUserId(Long userId);

}
