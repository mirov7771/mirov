package ru.sberx.user.auth.dao.model.user;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "USER_PROFILE")
@Getter
@Setter
@NoArgsConstructor
public class UserProfile implements Serializable {

    private static final long serialVersionUID = -5531515181448119279L;

    @Id
    @Column(name = "USERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;
    @Column(name = "SBERBUSINESSID")
    private String sbId;
    @Column(name = "NAME")
    private String name;
    @Column(name = "INN")
    private String inn;
    @Column(name = "KPP")
    private String kpp;
    @Column(name = "ORGNAME")
    private String orgName;
    @Column(name = "OGRN")
    private String ogrn;
    @Column(name = "OKPO")
    private String okpo;
    @Column(name = "OKTMO")
    private String oktmo;
    @Column(name = "FACTADDRESS")
    private String factAddress;
    @Column(name = "JURADDRESS")
    private String jurAddress;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "PHONENUMBER")
    private String phoneNumber;
    @Column(name = "POSITION")
    private String position;
    @Column(name = "ROLES")
    private String roles;

}
