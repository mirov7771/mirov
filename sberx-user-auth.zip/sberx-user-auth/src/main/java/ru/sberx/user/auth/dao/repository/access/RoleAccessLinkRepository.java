package ru.sberx.user.auth.dao.repository.access;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.access.RoleAccessLink;

import javax.annotation.Nonnull;
import java.util.List;

@Repository
public interface RoleAccessLinkRepository extends CrudRepository<RoleAccessLink, Long> {
    @Nonnull
    @Override
    List<RoleAccessLink> findAll();
}
