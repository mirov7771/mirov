package ru.sberx.user.auth.dao.model.access;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "ROLE_ACCESS_LINK")
@Entity
@Getter
@Setter
public class RoleAccessLink implements Serializable {

    private static final long serialVersionUID = -545439512001783908L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "ROLE_ID")
    private Long roleId;
    @Column(name = "ACCESS_ID")
    private Long accessId;
    @OneToOne
    @JoinColumn(name = "ACCESS_ID", referencedColumnName = "ID", updatable = false, insertable = false)
    private ApiAccessRight accessRight;
}
