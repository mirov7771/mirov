package ru.sberx.user.auth.service.impl.method.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.notifications.req.NotifyReq;
import ru.sberx.dto.questionary.questionary.questionary.req.PostUserQuestionnaireReq;
import ru.sberx.dto.questionary.questionary.questionary.res.GetUserListRes;
import ru.sberx.dto.questionary.questionary.questionary.res.QuestionaryRes;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.questionary.questionary.questionary.support.QuestionnaireDto;
import ru.sberx.dto.questionary.tariff.support.TariffDto;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.dto.user.auth.res.CompanyUsersListRes;
import ru.sberx.dto.user.auth.support.CompanyUserInfo;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserProfile;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;
import ru.sberx.utils.util.CastUtils;

import java.util.*;
import java.util.stream.Collectors;

@Component("companyuser")
@RequiredArgsConstructor
public class CompanyUsersMethod extends AuthService {

    private static final Long MAX_USERS_DEFAULT = 3L;

    public CompanyUsersListRes getCompanyUsers(Long userId) {
        CompanyUsersListRes res = new CompanyUsersListRes();
        UserEntity user = userEntityRepository.findByExternalId(userId);
        userId = user.getUserId() != null ? user.getUserId() : null;
        Long externalId = user.getExternalId() != null ? user.getExternalId() : null;
        if (!Boolean.TRUE.equals(user.getMainUser()))
            throw new SberxException(SberxErrors.INTERNAL_ERROR);
        List<UserRole> role = userRoleRepository.findByUserId(userId);
        List<TypeRes> type = questionaryService.getTypeByUserId(user.getExternalId());
        res.setMaxUsers(getMaxUsers(CollectionUtils.isEmpty(type) ? user.getUserRole() : type.get(0).getType(), role.get(0).getRoleSysName(), externalId));

        GetUserListRes userListRes = questionaryService.getUserList(externalId);
        List<Long> ids = userListRes.getExternalId();
        if (!CollectionUtils.isEmpty(ids)) {
            List<UserEntity> userEntityList = userEntityRepository.findByExternalIdIn(ids);
            List<CompanyUserInfo> infoList = userEntityList.stream()
                    .map(ue -> {
                        CompanyUserInfo info = new CompanyUserInfo();
                        info.setLogin(ue.getLogin());
                        info.setCreated(ue.getCreated());
                        info.setEnters(CastUtils.castToLong(ue.getEnters()));
                        info.setExpiry(ue.getExpiry());
                        info.setMainUser(Boolean.TRUE.equals(ue.getMainUser()));
                        return info;
                    })
                    .collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(infoList)) {
                res.setUsers(infoList);
                return res;
            }
        }
        throw new SberxException(SberxErrors.USER_NOT_FOUND);
    }

    @Override
    public AuthRes execute(AuthReq req) {
        if (!StringUtils.hasText(req.getLogin()))
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);
        UserEntity userEntity = userEntityRepository.findByExternalId(req.getUserId());
        if (userEntity == null || !Boolean.TRUE.equals(userEntity.getMainUser()))
            throw new SberxException(SberxErrors.AUTHORIZATION_FAILED);
        GetUserListRes userList = questionaryService.getUserList(req.getUserId());
        QuestionaryRes questionaryRes = questionaryService.getQuestionaryById(userList.getQuestionnaireId(), null);
        QuestionnaireDto questionnaire = questionaryRes.getQuestionnaire();
        if (questionnaire == null)
            throw new SberxException(SberxErrors.QUESTIONNAIRE_NOT_FOUND);

        List<UserRoleLink> roleLinks = userRoleLinkRepository.findByUserId(userEntity.getUserId());
        List<TypeRes> type = questionaryService.getTypeByUserId(req.getUserId());
        Long maxUsers = getMaxUsers(CollectionUtils.isEmpty(type) ? userEntity.getUserRole() : type.get(0).getType(), roleLinks.get(0).getUserRole().getRoleSysName(), req.getUserId());
        Long userCount = userList.getUserCount() != null ? userList.getUserCount() : 0;
        if (userCount.compareTo(maxUsers) >= 0)
            throw new SberxException(SberxErrors.CREATED_MAX_USERS);
        UserEntity createUser = userEntityRepository.findByLoginIgnoreCase(req.getLogin());
        String pass = getRandomPassword();
        String hashPass = getHash(pass);
        if (createUser != null) {
            if (Integer.valueOf(0).equals(createUser.getEnters()) && !CollectionUtils.isEmpty(userList.getExternalId())) {
                createUser.setPassword(hashPass);
                userEntityRepository.save(createUser);
            } else {
                throw new SberxException(SberxErrors.USER_EXISTS);
            }
            Long externalId = createUser.getExternalId();
            if (!CollectionUtils.isEmpty(userList.getExternalId())
                    && userList.getExternalId().stream().anyMatch(id -> id.equals(externalId)))
                throw new SberxException(SberxErrors.USER_EXISTS);
        } else {

            UserProfile userInfo = new UserProfile();
            userInfo.setEmail(req.getLogin());
            userInfo.setSbId("NO_SBB_ID");
            userInfo = userProfileRepository.save(userInfo);

            createUser = new UserEntity();
            createUser.setExternalId(userInfo.getUserId());
            createUser.setLogin(req.getLogin());
            createUser.setNewUser(true);
            createUser.setEnters(0);
            createUser.setPassword(hashPass);
            createUser.setUserRole(questionnaire.getType());
            createUser.setCreated(new Date());
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(new Date());
            calendar.add(Calendar.DAY_OF_MONTH, 5);
            createUser.setExpiry(calendar.getTime());
            UserEntity newUser = userEntityRepository.save(createUser);

            UserRoleLink link = new UserRoleLink();
            link.setUserId(newUser.getUserId());
            link.setRoleId(roleLinks.get(0).getRoleId());
            userRoleLinkRepository.save(link);

            PostUserQuestionnaireReq uqReq = new PostUserQuestionnaireReq();
            uqReq.setLogin(createUser.getLogin());
            uqReq.setUserId(createUser.getExternalId());
            uqReq.setQuestionnaireId(userList.getQuestionnaireId());
            questionaryService.saveUserQuestionnaire(uqReq);
        }

        NotifyReq notifyReq = new NotifyReq();
        Map<String, Object> params = new HashMap<>();
        params.put("email", createUser.getLogin());
        params.put("password", pass);
        params.put("name", questionnaire.getName());
        notifyReq.setParams(params);
        notifyReq.setReceiver(createUser.getLogin());
        notifyReq.setSysName("NewCompanyUser");
        notifyReq.setType(NotifyReq.Types.EMAIL);
        notificationService.notify(notifyReq);
        return null;
    }

    private Long getMaxUsers(Integer type, String role, Long externalId) {
        Long maxUsers = MAX_USERS_DEFAULT;
        if (!Integer.valueOf(0).equals(type)) {
            TariffDto tariffDto = questionaryService.getTariff(externalId, role, null, null);
            maxUsers = tariffDto != null ? CastUtils.castToLong(tariffDto.getMaxUsers()) : 0;
        }
        return maxUsers;
    }
}
