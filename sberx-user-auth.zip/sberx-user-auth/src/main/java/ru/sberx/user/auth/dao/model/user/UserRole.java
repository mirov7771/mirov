package ru.sberx.user.auth.dao.model.user;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "USER_ROLE")
@Getter
@Setter
@NoArgsConstructor
public class UserRole implements Serializable {

    private static final long serialVersionUID = -3892552697464099374L;

    @Id
    @Column(name = "ROLEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long roleId;
    @Column(name = "ROLENAME")
    private String roleName;
    @Column(name = "ROLESYSNAME")
    private String roleSysName;
    @Column(name = "EXTERNAL_NAME")
    private String externalName;

    public UserRole(String roleName){
        this.roleName = roleName;
        this.roleSysName = roleName;
    }

}
