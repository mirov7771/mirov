package ru.sberx.user.auth.service.impl.method.other;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.support.LastSessionDto;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserSession;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;
import ru.sberx.user.auth.dao.repository.user.UserSessionRepository;

import java.util.Calendar;
import java.util.Date;

@Component
@RequiredArgsConstructor
@Slf4j
public class LastSessionMethod {

    private final UserEntityRepository userEntityRepository;
    private final UserSessionRepository userSessionRepository;

    @Value("${application.session.timeout:300}")
    protected Integer sessionTimeout;

    public LastSessionDto execute(Long externalId) {
        LastSessionDto res = new LastSessionDto();
        UserEntity userEntity = userEntityRepository.findByExternalId(externalId);
        if (userEntity == null)
            throw new SberxException(SberxErrors.USER_NOT_FOUND);

        UserSession userSession = userSessionRepository.findFirstByUserEntityOrderByExpiryDesc(userEntity);
        if (userSession != null)
            res.setLastSession(getDateLastVisit(userSession));
        else
            res.setLastSession(userEntity.getLastEnter());

        return res;
    }

    public Date getDateLastVisit(UserSession userSession) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(userSession.getExpiry());
        cal.add(Calendar.MINUTE, -10 * sessionTimeout);
        return cal.getTime();
    }
}
