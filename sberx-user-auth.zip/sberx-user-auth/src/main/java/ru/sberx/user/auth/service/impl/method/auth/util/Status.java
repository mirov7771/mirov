package ru.sberx.user.auth.service.impl.method.auth.util;

public enum Status {
    OK,
    ERROR,
    EXPIRED,
    CHANGEPASSWORD,
    SIGNTERMOFUSE,
    SETPHONE,
    OTP
}
