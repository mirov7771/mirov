package ru.sberx.user.auth.dao.repository.permission;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.CrudRepository;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.permission.Permissions;

import javax.annotation.Nonnull;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public interface PermissionsRepository extends CrudRepository<Permissions, Long> {
    @Nonnull
    List<Permissions> findAll();
    Optional<Permissions> findByTypeAndName(String type, String name);
    @Transactional
    @Modifying
    void deleteById(@NonNull Long id);
}
