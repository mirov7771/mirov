package ru.sberx.user.auth.service.impl.method.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.other.DeleteInfo;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.other.DeleteInfoRepository;

import java.util.Date;

@Component("delete")
@RequiredArgsConstructor
public class DeleteUserById extends AuthService {

    private final DeleteInfoRepository deleteInfoRepository;

    @Override
    public AuthRes execute(AuthReq req) {
        UserEntity user = validateAccessUserExecuteDeleting(req);
        UserEntity userById = userEntityRepository.findByUserId(req.getUserId());
        if (userById != null) {
            DeleteInfo deleteInfo = new DeleteInfo();
            deleteInfo.setUserId(userById.getUserId());
            deleteInfo.setQuestionnaireId(0L);
            deleteInfo.setDeleteDttm(new Date());
            deleteInfo.setFullName(userById.getLogin());
            if (Integer.valueOf(6).equals(user.getUserRole()) || Integer.valueOf(7).equals(user.getUserRole()))
                deleteInfo.setComment("Удаление по инициативе пользователя");
            else
                deleteInfo.setComment(req.getComment());
            deleteInfoRepository.save(deleteInfo);

            if (userById.getExternalId() != null)
                userProfileRepository.deleteById(userById.getExternalId());
            userEntityRepository.deleteByUserId(userById.getUserId());
            userRoleLinkRepository.deleteByUserId(userById.getUserId());
            userSessionRepository.deleteByUserId(userById.getUserId());
            userConsentRepository.deleteByUserId(userById.getUserId());
        }
        return null;
    }
}
