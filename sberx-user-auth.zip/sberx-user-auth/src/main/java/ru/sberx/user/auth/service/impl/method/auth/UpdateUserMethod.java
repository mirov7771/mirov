package ru.sberx.user.auth.service.impl.method.auth;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleLinkRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleRepository;

@Component("update")
@RequiredArgsConstructor
@Slf4j
public class UpdateUserMethod extends AuthService {

    private final UserRoleRepository userRoleRepository;
    private final UserEntityRepository userEntityRepository;
    private final UserRoleLinkRepository userRoleLinkRepository;

    public AuthRes execute(AuthReq req) {
        UserEntity user = userEntityRepository.findByUserId(req.getUserId());
        if (user == null)
            return null;
        if (req.getRole() != null) {
            UserRole role = userRoleRepository.findByRoleSysName(req.getRole());
            if (role != null){
                UserRoleLink link = new UserRoleLink();
                link.setUserId(user.getUserId());
                link.setRoleId(role.getRoleId());
                userRoleLinkRepository.save(link);
            }
        }
        if (req.getPassword() != null) {
            user.setPassword(req.getPassword());
        }
        AuthRes res = new AuthRes();
        if (req.getDepartmentId() != null)
            user.setDepartmentId(req.getDepartmentId());
        if (req.getUserRole() != null)
            user.setUserRole(req.getUserRole());
        if (req.getExternalId() != null)
            user.setExternalId(req.getExternalId());
        if (req.getLogin() != null)
            user.setLogin(req.getLogin());
        userEntityRepository.save(user);
        res.setUserId(user.getUserId());
        return res;
    }

}
