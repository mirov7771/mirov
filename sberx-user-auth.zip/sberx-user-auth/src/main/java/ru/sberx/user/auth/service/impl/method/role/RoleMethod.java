package ru.sberx.user.auth.service.impl.method.role;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.permission.PermissionRoleLink;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.repository.permission.PermissionRoleLinkRepository;
import ru.sberx.user.auth.dao.repository.permission.PermissionsRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleRepository;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class RoleMethod {

    private final UserRoleRepository userRoleRepository;
    private final PermissionsRepository permissionsRepository;
    private final PermissionRoleLinkRepository permissionRoleLinkRepository;

    public List<AuthRes> list(){
        List<AuthRes> res = new ArrayList<>();
        List<UserRole> roles = userRoleRepository.findAll();
        for(UserRole role : roles){
            AuthRes a = new AuthRes();
            a.setRole(role.getRoleSysName());
            a.setRoleName(role.getRoleName());
            a.setRoleId(role.getRoleId());
            List<PermissionRoleLink> links = permissionRoleLinkRepository.findByRoleId(role.getRoleId());
            if (!CollectionUtils.isEmpty(links)){
                a.setPermissions(new ArrayList<>());
                for(PermissionRoleLink link : links){
                    permissionsRepository.findById(link.getPermissionId()).ifPresent(i -> a.getPermissions().add(i.toDto()));
                }
            }
            res.add(a);
        }
        return res;
    }

}
