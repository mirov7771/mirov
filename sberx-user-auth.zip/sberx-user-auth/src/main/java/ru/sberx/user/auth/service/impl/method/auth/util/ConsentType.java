package ru.sberx.user.auth.service.impl.method.auth.util;

public class ConsentType {
    public static final String TERM_OF_USE = "term_of_use";
    public static final String PRIVACY_POLICY = "privacy_policy";
    public static final String SBER500_PRIVACY_POLICY = "sber500_privacy_policy";
    public static final String SBER500_CONSENT = "sber500_consent";
    public static final String SBER500_TERM_OF_USE = "sber500_term_of_use";
    public static final String SBER500_PERSONAL_DATA_CONSENT = "sber500_personal_data_consent";
    public static final String MAILING_CONSENT = "mailing_consent";
}
