package ru.sberx.user.auth.service.impl.method.auth;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.notifications.req.NotifyReq;
import ru.sberx.dto.notifications.support.NoticeDto;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleLinkRepository;
import ru.sberx.user.auth.dao.repository.user.UserRoleRepository;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component("create")
@RequiredArgsConstructor
@Slf4j
public class CreateUserMethod extends AuthService {

    private final UserRoleRepository userRoleRepository;
    private final UserEntityRepository userEntityRepository;
    private final UserRoleLinkRepository userRoleLinkRepository;

    public AuthRes execute(AuthReq req) {
        if (req.getLogin() == null || req.getRole() == null || req.getUserRole() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: login || role || userRole");
        UserRole role = userRoleRepository.findByRoleSysName(req.getRole());
        if (role == null)
            throw new SberxException(SberxErrors.ROLE_NOT_FOUND);
        String pass = req.getPassword() == null ? getRandomPassword() : req.getPassword();
        String hash = getHash(pass);
        if (hash == null)
            throw new SberxException(SberxErrors.INTERNAL_ERROR);
        AuthRes res = new AuthRes();
        UserEntity user = userEntityRepository.findByLoginIgnoreCase(req.getLogin());
        if (user != null && user.getUserId() != null && user.getUserRole().equals(4)) {
            UserExistsError userExistsError = buildUserExistsError(req.getLogin());
            throw new SberxException(userExistsError.getDescription(),
                    userExistsError.getCode(),
                    userExistsError.getStatus(),
                    userExistsError.getMessage(),
                    userExistsError.getTitle(), List.of(userExistsError.getDescription()),
                    userExistsError.getButtonText(),
                    "/",
                    null);
        }

        if (user == null) {
            user = new UserEntity();
            user.setLogin(req.getLogin());
            user.setExternalId(null);
            user.setNewUser(true);
        }
        checkuser(user, req);
        user.setEnters(0);
        user.setPassword(hash);
        user.setUserRole(req.getUserRole());
        if (req.getDepartmentId() != null)
            user.setDepartmentId(req.getDepartmentId());
        user.setCreated(new Date());
        UserEntity newUser = userEntityRepository.save(user);
        UserRoleLink link = new UserRoleLink();
        link.setUserId(newUser.getUserId());
        link.setRoleId(role.getRoleId());
        userRoleLinkRepository.save(link);

        try {
            NotifyReq notifyReq = new NotifyReq();
            notifyReq.setType(NotifyReq.Types.EMAIL);
            notifyReq.setReceiver(req.getLogin());
            notifyReq.setParams(Map.of("login", req.getLogin(), "password", pass));
            notifyReq.setSysName("NewSyndicate");
            notificationService.notify(notifyReq);

            //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
            if (user.getUserId() != null) {
                NoticeDto noticeReq = new NoticeDto();
                noticeReq.setTemplateSysName("NewSyndicate");
                noticeReq.setParams(Map.of("login", req.getLogin(), "password", "*******"));
                noticeReq.setUserId(user.getUserId());
                noticeReq.setEvent("Создание пользователя Клуб");
                notificationService.notice(noticeReq);
            }
        } catch (Exception e) {
            log.error("error sending email ", e);
        }

        return res;
    }

    private void checkuser(UserEntity userEntity, AuthReq req) {
        if (Objects.nonNull(userEntity.getUserRole())) {
            if (!userEntity.getUserRole().equals(req.getUserRole()) || userEntity.getEnters().equals(1)) {
                UserExistsError userExistsError = buildUserExistsError(req.getLogin());
                throw new SberxException(userExistsError.getDescription(),
                        userExistsError.getCode(),
                        userExistsError.getStatus(),
                        userExistsError.getMessage(),
                        userExistsError.getTitle(), List.of(userExistsError.getDescription()),
                        userExistsError.getButtonText(),
                        "/",
                        null);
            }
        }
    }
}
