package ru.sberx.user.auth.service.impl.method.other;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.other.SessionConfig;
import ru.sberx.user.auth.dao.repository.other.SessionConfigRepository;
import ru.sberx.utils.util.ObjectUtils;

import java.util.Map;
import java.util.UUID;

@Component
@RequiredArgsConstructor
@Slf4j
public class Preauthorize {

    private final SessionConfigRepository sessionConfigRepository;

    @Value("${application.auth.client-secret:0}")
    private String clientSecret;

    public AuthRes execute(String clientId, Map<String, String> params){
        String reqClientId = clientId;
        if (params != null && StringUtils.hasText(params.get("clientId"))) {
            reqClientId = params.get("clientId");
            params.remove("clientId");
        }
        SessionConfig configuration = sessionConfigRepository.findByClientId(reqClientId);
        if (configuration == null)
            throw new SberxException(SberxErrors.CONFIGURATION_NOT_FOUND);

        AuthRes res = new AuthRes();
        res.setResponseType(configuration.getResponseType());
        res.setScope(configuration.getScope());
        res.setRedirectUri(configuration.getRedirectUri());
        res.setNonce(UUID.randomUUID().toString());
        res.setState(configuration.getState());
        res.setOpenidUri(configuration.getOpenidUri());
        if (params != null && !params.isEmpty()){
            StringBuilder redirectUri = new StringBuilder(res.getRedirectUri());
            int i = 0;
            for(Map.Entry<String, String> item : params.entrySet()){
                if (i == 0)
                    if (!redirectUri.toString().endsWith("auth")
                            && "type".equals(item.getKey())
                            && ("1".equals(item.getValue()) || "2".equals(item.getValue())))
                        redirectUri.append("auth?").append(item.getKey()).append("=").append(item.getValue());
                    else
                        redirectUri.append("?").append(item.getKey()).append("=").append(item.getValue());
                else
                    redirectUri.append("&").append(item.getKey()).append("=").append(item.getValue());
                i++;
            }
            res.setRedirectUri(redirectUri.toString());
        }
        sessionConfigRepository.save(new SessionConfig(configuration, res, clientSecret));
        return res;
    }

}
