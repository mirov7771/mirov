package ru.sberx.user.auth.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.*;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.dto.user.auth.res.CompanyUsersListRes;
import ru.sberx.dto.user.auth.res.ConsentRes;
import ru.sberx.dto.user.auth.res.UserListRes;
import ru.sberx.dto.user.auth.support.*;
import ru.sberx.user.auth.service.Service;
import ru.sberx.user.auth.service.impl.method.access.AccessMethod;
import ru.sberx.user.auth.service.impl.method.auth.AuthService;
import ru.sberx.user.auth.service.impl.method.auth.CheckSession;
import ru.sberx.user.auth.service.impl.method.auth.CompanyUsersMethod;
import ru.sberx.user.auth.service.impl.method.consent.ConsentMethod;
import ru.sberx.user.auth.service.impl.method.consent.ConsentSignMethod;
import ru.sberx.user.auth.service.impl.method.other.*;
import ru.sberx.user.auth.service.impl.method.permission.PermissionMethod;
import ru.sberx.user.auth.service.impl.method.role.RoleMethod;
import ru.sberx.user.auth.service.impl.method.user.UserInfoListMethod;
import ru.sberx.user.auth.service.impl.method.user.UserListMethod;

import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class ServiceImpl implements Service {

    private final Map<String, AuthService> methods;
    private final Logout logout;
    private final DeleteUserSessions deleteUserSessions;
    private final CheckSession checkSession;
    private final Preauthorize preauthorize;
    private final ConsentMethod consentMethod;
    private final PermissionMethod permissionMethod;
    private final RoleMethod roleMethod;
    private final UserListMethod userListMethod;
    private final AccessMethod accessMethod;
    private final LastSessionMethod lastSessionMethod;
    private final ConsentSignMethod consentSignMethod;
    private final ApplicationDeleteMethod applicationDeleteMethod;
    private final UserInfoListMethod userInfoListMethod;
    private final CompanyUsersMethod companyUsersMethod;

    @Override
    public AuthRes call(AuthReq req, String method) {
        return methods.get(method).execute(req);
    }

    @Override
    public AuthRes deleteSession(String sessionId) {
        return logout.execute(sessionId);
    }

    @Override
    public void deleteSessionByUserId(Long userId) {
        deleteUserSessions.execute(userId);
    }

    @Override
    public AuthRes checkSession(String sessionId) {
        return checkSession.execute(new AuthReq(sessionId));
    }

    @Override
    public AuthRes preauthorize(String clientId, Map<String, String> param) {
        return preauthorize.execute(clientId, param);
    }

    @Override
    public List<AuthRes> roleList() {
        return roleMethod.list();
    }

    @Override
    public ConsentRes getConsentUrls(ConsentReq req) {
        return consentMethod.getConsentUrls(req);
    }

    @Override
    public List<Permission> getPermissionList() {
        return permissionMethod.list();
    }

    @Override
    public Permission savePermission(Permission req) {
        return permissionMethod.save(req);
    }

    @Override
    public void deletePermission(Long id) {
        permissionMethod.delete(id);
    }

    @Override
    public void permissionToRole(AuthReq req) {
        permissionMethod.permissionToRole(req);
    }

    @Override
    public UserListRes getUserList(UserListReq req) {
        return userListMethod.getList(req);
    }

    @Override
    public List<Access> getAccess() {
        return accessMethod.getAccess();
    }

    @Override
    public LastSessionDto getLastSession(Long externalId) {
        return lastSessionMethod.execute(externalId);
    }

    @Override
    public ConsentSignDttm getConsentSign(Long userId) {
        return consentSignMethod.getConsentSign(userId);
    }

    @Override
    public void applicationDelete(Long userId, String role, ApplicationDeleteReq req) {
        applicationDeleteMethod.execute(userId, role, req);
    }

    @Override
    public List<UserInfoDto> getUserInfoList(UserInfoListReq req) {
        return userInfoListMethod.getList(req);
    }

    @Override
    public CompanyUsersListRes getCompanyUsers(Long userId) {
        return companyUsersMethod.getCompanyUsers(userId);
    }
}
