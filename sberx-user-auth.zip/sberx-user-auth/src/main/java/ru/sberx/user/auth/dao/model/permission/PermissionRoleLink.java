package ru.sberx.user.auth.dao.model.permission;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Table(name = "PERMISSION_ROLE_LINK")
@Entity
@Getter
@Setter
public class PermissionRoleLink implements Serializable {

    private static final long serialVersionUID = -2945305511737496637L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "PERMISSION_ID")
    private Long permissionId;
    @Column(name = "ROLE_ID")
    private Long roleId;

}
