package ru.sberx.user.auth.dao.repository.user;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.sberx.user.auth.dao.model.user.UserRole;

import javax.annotation.Nonnull;
import java.util.List;

public interface UserRoleRepository extends CrudRepository<UserRole, Long> {
    UserRole findByRoleSysName(String roleSysName);
    @Nonnull
    List<UserRole> findAll();
    List<UserRole> findByRoleIdIn(List<Long> roleId);
    List<UserRole> findByExternalNameIn(List<String> externalNames);

    @Query(value = "select ur.* " +
            "     from public.user_role ur " +
            "inner join user_role_link url " +
            "on url.roleid = ur.roleid " +
            "and url.userid = :userId", nativeQuery = true)
    List<UserRole> findByUserId(@Param("userId") Long userId);
}
