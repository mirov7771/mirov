package ru.sberx.user.auth.dao.model.other;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "DELETE_INFO")
@Getter
@Setter
public class DeleteInfo implements Serializable {

    private static final long serialVersionUID = -1223010082452543497L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "QUESTIONNAIREID")
    private Long questionnaireId;
    @Column(name = "FULLNAME")
    private String fullName;
    @Column(name = "COMMENT")
    private String comment;
    @Column(name = "DELETE_DTTM")
    private Date deleteDttm;
}
