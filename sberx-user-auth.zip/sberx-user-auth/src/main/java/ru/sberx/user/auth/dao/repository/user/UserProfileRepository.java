package ru.sberx.user.auth.dao.repository.user;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.user.UserProfile;

@Repository
public interface UserProfileRepository extends CrudRepository<UserProfile, Long> {
    UserProfile findBySbId(String sbId);
    UserProfile findByInn(String inn);
    UserProfile findByEmail(String email);
}
