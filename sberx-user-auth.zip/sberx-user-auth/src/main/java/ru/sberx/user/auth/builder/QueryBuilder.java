package ru.sberx.user.auth.builder;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Component;
import ru.sberx.configs.db.HibernateUtil;
import ru.sberx.dto.user.auth.req.UserListReq;
import ru.sberx.user.auth.dao.model.user.*;

import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class QueryBuilder {

    private final HibernateUtil hibernateUtil;

    public List<UserEntity> getListWithCriteria(UserListReq req) {
        try (Session session = hibernateUtil.getHibernateSession().openSession()) {
            CriteriaBuilder cb = session.getCriteriaBuilder();
            CriteriaQuery<UserEntity> query = cb.createQuery(UserEntity.class);
            Root<UserEntity> root =  query.from(UserEntity.class);
            List<Predicate> predicates = new ArrayList<>();
            if (req.getUserRole() != null){
                predicates.add(cb.equal(root.get(UserEntity_.USER_ROLE), req.getUserRole()));
            }
            if (req.getRole() != null){
                Subquery<UserRoleLink> subQuery = query.subquery(UserRoleLink.class);
                Root<UserRoleLink> linkRoot = subQuery.from(UserRoleLink.class);
                List<Predicate> linkPredicates = new ArrayList<>();
                linkPredicates.add(cb.equal(linkRoot.get(UserRoleLink_.USER_ID), root.get(UserEntity_.USER_ID)));
                Predicate[] linkPrs = new Predicate[linkPredicates.size()];

                Subquery<UserRole> subQuery2 = subQuery.subquery(UserRole.class);
                Root<UserRole> roleRoot = subQuery2.from(UserRole.class);
                List<Predicate> rolePredicates = new ArrayList<>();
                rolePredicates.add(cb.equal(roleRoot.get(UserRole_.ROLE_ID), linkRoot.get(UserRoleLink_.ROLE_ID)));
                rolePredicates.add(cb.equal(roleRoot.get(UserRole_.ROLE_SYS_NAME), req.getRole()));
                Predicate[] rolePrs = new Predicate[rolePredicates.size()];

                linkPredicates.add(cb.exists(subQuery2));

                subQuery2.select(roleRoot)
                        .where(rolePredicates
                                .toArray(rolePrs));

                subQuery.select(linkRoot)
                        .where(linkPredicates
                                .toArray(linkPrs));

                predicates.add(cb.exists(subQuery));
            }
            if (req.getName() != null){
                predicates.add(cb.like(root.get(UserEntity_.LOGIN), "%" + req.getName() + "%"));
            }
            Predicate[] prs = new Predicate[predicates.size()];
            query.where(predicates.toArray(prs));
            query.orderBy(cb.desc(root.get(UserEntity_.USER_ID)));
            Query<UserEntity> list = session.createQuery(query).setMaxResults(100);
            return list.getResultList();
        }
    }

}
