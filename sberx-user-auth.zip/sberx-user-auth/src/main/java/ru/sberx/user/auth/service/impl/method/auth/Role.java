package ru.sberx.user.auth.service.impl.method.auth;

import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;

@Component("role")
public class Role extends AuthService {

    @Override
    public AuthRes execute(AuthReq req) {
        AuthRes res = new AuthRes();
        UserRole role = userRoleRepository.findByRoleSysName(req.getRole());
        if (req.getUserId() != null) {
            if (role == null)
                throw new SberxException(SberxErrors.ROLE_NOT_FOUND);
            UserEntity user = userEntityRepository.findByUserId(req.getUserId());
            if (user == null)
                throw new SberxException(SberxErrors.USER_NOT_FOUND);
            user.setUserRole(req.getUserRole() == null ? 0 : req.getUserRole());
            userRoleLinkRepository.deleteByUserId(user.getUserId());
            UserRoleLink l = new UserRoleLink();
            l.setRoleId(role.getRoleId());
            l.setUserId(user.getUserId());
            userRoleLinkRepository.save(l);
            res.setUserId(user.getUserId());
            res.setRole(role.getRoleSysName());
        } else {
            if (role == null)
                role = new UserRole();
            role.setRoleName(req.getName());
            role.setRoleSysName(req.getSysName());
            userRoleRepository.save(role);
        }
        return res;
    }

}
