package ru.sberx.user.auth.dao.repository.other;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.sberx.user.auth.dao.model.other.SessionConfig;

@Repository
public interface SessionConfigRepository extends CrudRepository<SessionConfig, Long> {

    SessionConfig findByClientId(String clientId);

    @Transactional
    @Modifying
    @Query("delete from SessionConfig where clientId = :clientId")
    void deleteById(@Param("clientId") String clientId);

}
