package ru.sberx.user.auth.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.service.Service;
import ru.sberx.utils.builder.ResponseBuilder;

import java.util.List;

import static ru.sberx.constants.Constants.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("${spring.application.name}/role")
@RequiredArgsConstructor
public class RoleController {

    private final Service service;

    @GetMapping(value = "/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<AuthRes>> roleList() {
        return ResponseBuilder.ok(service.roleList());
    }

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> role(@RequestBody AuthReq req) {
        return ResponseBuilder.ok(service.call(req, "role"));
    }

}
