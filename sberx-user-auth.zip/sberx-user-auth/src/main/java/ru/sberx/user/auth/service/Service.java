package ru.sberx.user.auth.service;

import ru.sberx.dto.user.auth.req.*;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.dto.user.auth.res.CompanyUsersListRes;
import ru.sberx.dto.user.auth.res.ConsentRes;
import ru.sberx.dto.user.auth.res.UserListRes;
import ru.sberx.dto.user.auth.support.*;

import java.util.List;
import java.util.Map;

public interface Service {
    AuthRes call(AuthReq req, String method);
    AuthRes deleteSession(String sessionId);
    void deleteSessionByUserId(Long userId);
    AuthRes checkSession(String sessionId);
    AuthRes preauthorize(String clientId, Map<String, String> param);
    List<AuthRes> roleList();
    ConsentRes getConsentUrls(ConsentReq req);
    List<Permission> getPermissionList();
    Permission savePermission(Permission req);
    void deletePermission(Long id);
    void permissionToRole(AuthReq req);
    UserListRes getUserList(UserListReq req);
    List<Access> getAccess();
    LastSessionDto getLastSession(Long externalId);
    ConsentSignDttm getConsentSign(Long userId);
    void applicationDelete(Long userId, String role, ApplicationDeleteReq req);
    List<UserInfoDto> getUserInfoList(UserInfoListReq req);
    CompanyUsersListRes getCompanyUsers(Long userId);
}


