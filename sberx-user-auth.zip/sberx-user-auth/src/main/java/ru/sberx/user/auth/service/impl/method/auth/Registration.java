package ru.sberx.user.auth.service.impl.method.auth;

import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.application.support.ApplicationDto;
import ru.sberx.dto.questionary.tariff.req.PostTariffReq;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserProfile;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;
import ru.sberx.user.auth.service.impl.method.auth.util.Status;

import java.util.Date;
import java.util.List;

@Component("registration")
public class Registration extends AuthService {

    @Override
    public AuthRes execute(AuthReq req) {
        if (req.getApplicationId() == null || req.getPassword() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: applicationId and password");

        ApplicationDto application;
        try {
            application = questionaryService.getApplicationByUid(req.getApplicationId(), false);
        } catch (Exception e){
            UserExistsError userExistsError = buildUserExistsError(req.getLogin());
            throw new SberxException(userExistsError.getDescription(),
                    userExistsError.getCode(),
                    userExistsError.getStatus(),
                    userExistsError.getMessage(),
                    userExistsError.getTitle(),
                    List.of(userExistsError.getDescription()),
                    userExistsError.getButtonText(),
                    "/",
                    null);
        }
        if (application == null || application.getEmail() == null || application.getLogin() == null) {
            UserExistsError userExistsError = buildUserExistsError(req.getLogin());
            throw new SberxException(userExistsError.getDescription(),
                    userExistsError.getCode(),
                    userExistsError.getStatus(),
                    userExistsError.getMessage(),
                    userExistsError.getTitle(), List.of(userExistsError.getDescription()),
                    userExistsError.getButtonText(),
                    "/",
                    null);
        }
        if (userEntityRepository.findByLoginIgnoreCase(application.getLogin()) != null && !Boolean.TRUE.equals(req.getTermOfUseConsent())) {
            UserExistsError userExistsError = buildUserExistsError(application.getLogin());
            throw new SberxException(userExistsError.getDescription(),
                    userExistsError.getCode(),
                    userExistsError.getStatus(),
                    userExistsError.getMessage(),
                    userExistsError.getTitle(), List.of(userExistsError.getDescription()),
                    userExistsError.getButtonText(),
                    "/",
                    null);
        }
        AuthRes res = new AuthRes();
        UserEntity user;
        if (!Boolean.TRUE.equals(req.getTermOfUseConsent())) {
            UserRole role = userRoleRepository.findByRoleSysName("Client");
            if (role == null)
                throw new SberxException(SberxErrors.ROLE_NOT_FOUND);
            user = new UserEntity();
            user.setLogin(application.getLogin());
            UserProfile userInfo = userProfileRepository.findByEmail(application.getLogin());
            if (userInfo == null || userInfo.getUserId() == null) {
                userInfo = new UserProfile();
                userInfo.setEmail(application.getLogin());
                userInfo.setSbId("NO_SBB_ID");
                userProfileRepository.save(userInfo);
                user.setExternalId(userInfo.getUserId());
            } else {
                user.setExternalId(userInfo.getUserId());
            }
            user.setEnters(1);
            user.setNewUser(false);
            user.setPassword(req.getPassword());
            user.setUserRole(req.getUserRole() == null ? 0 : req.getUserRole());
            user.setCreated(new Date());
            user.setMainUser(true);
            userEntityRepository.save(user);
            UserRoleLink link = new UserRoleLink();
            link.setUserId(user.getUserId());
            link.setRoleId(role.getRoleId());
            userRoleLinkRepository.save(link);
            if (user.getLogin().equals(application.getEmail())) {
                saveConsent(true, true, false, false, false, false, false, user.getUserId());
                createSession(user, res, null, null, null);
                res.setStatus(Status.OK.toString());
            } else {
                res.setStatus(Status.SIGNTERMOFUSE.toString());
            }
            setAppId(user, res);
            PostTariffReq tariffReq = new PostTariffReq();
            tariffReq.setSysname(application.getTariff());
            questionaryService.postTariff(tariffReq, user.getExternalId(), "Client");
        } else {
            user = userEntityRepository.findByLoginIgnoreCase(application.getLogin());
            saveConsent(true, true, false, false, false, false, false, user.getUserId());
            createSession(user, res, null, null, null);
            res.setStatus(Status.OK.toString());
        }
        return res;
    }

}
