package ru.sberx.user.auth.dao.model.user;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "USER_SESSION")
@Getter
@Setter
public class UserSession implements Serializable {

    private static final long serialVersionUID = -7487900489144934697L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "SESSIONID")
    private String sessionId;
    @Column(name = "USERID")
    private Long userId;
    @Column(name = "EXPIRY")
    private Date expiry;
    @Column(name = "CLIENTID")
    private String clientId;
    @Column(name = "REFRESH_TOKEN")
    private String refreshToken;
    @ManyToOne
    @JoinColumn(name = "USERID", referencedColumnName = "USERID", updatable = false, insertable = false)
    private UserEntity userEntity;
    @Column(name = "EXP")
    private Date exp;

}
