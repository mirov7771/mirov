package ru.sberx.user.auth.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.dto.user.auth.req.*;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.dto.user.auth.res.CompanyUsersListRes;
import ru.sberx.dto.user.auth.res.ConsentRes;
import ru.sberx.dto.user.auth.res.UserListRes;
import ru.sberx.dto.user.auth.support.Access;
import ru.sberx.dto.user.auth.support.ConsentSignDttm;
import ru.sberx.dto.user.auth.support.LastSessionDto;
import ru.sberx.dto.user.auth.support.UserInfoDto;
import ru.sberx.user.auth.service.Service;
import ru.sberx.utils.builder.ResponseBuilder;
import ru.sberx.utils.builder.SessionBuilder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

import static ru.sberx.constants.Constants.APPLICATION_JSON_VALUE;
import static ru.sberx.constants.Constants.Header.*;

@RestController
@RequestMapping("${spring.application.name}")
@RequiredArgsConstructor
public class ServiceController {

    private final Service service;
    private final SessionBuilder sessionBuilder;

    @PostMapping(value = "auth/{type}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> auth(@PathVariable("type") String type,
                                        @CookieValue(value = "AUTH_SESSION_ID", required = false) String sessionId,
                                        @RequestBody AuthReq req) {
        if (req.getSessionId() == null && sessionId != null) {
            req.setSessionId(sessionId);
        }
        req.setType(type);
        return ResponseBuilder.okWithCookie(service.call(req, "auth"));
    }

    @DeleteMapping(value = "logout/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> logout(@PathVariable("id") String sessionId,
                                          HttpServletResponse response) {
        response.addCookie(new Cookie("AUTH_SESSION_ID", null));
        return ResponseBuilder.ok(service.deleteSession(sessionBuilder.decodeSessionId(sessionId)));
    }

    @DeleteMapping(value = "session/{userId}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<?> deleteUserSessions(@PathVariable("userId") Long userId) {
        service.deleteSessionByUserId(userId);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }

    @GetMapping(value = "checksession/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> checkSession(@PathVariable("id") String sessionId) {
        return ResponseBuilder.ok(service.checkSession(sessionBuilder.decodeSessionId(sessionId)));
    }

    @PostMapping(value = "user", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> createUser(@RequestBody AuthReq req) {
        return ResponseBuilder.ok(service.call(req, "create"));
    }

    @GetMapping(value = "preauthorize", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> preauthorize(@RequestHeader(CLIENT_ID) String clientId,
                                                @RequestParam Map<String, String> param) {
        return ResponseBuilder.ok(service.preauthorize(clientId, param));
    }

    @PostMapping(value = "login", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> login(@RequestHeader(CLIENT_ID) String clientId,
                                         @RequestBody AuthReq req) {
        req.setClientId(clientId);
        return ResponseBuilder.okWithCookie(service.call(req, (req.getCode() != null && req.getCode().contains("9999")) ? "mocklogin" : "login"));
    }

    @GetMapping(value = "user-info", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> userInfo(AuthReq req) {
        return ResponseBuilder.ok(service.call(req, "user_info"));
    }

    @PostMapping(value = "user-info/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<UserInfoDto>> userInfoList(@RequestBody UserInfoListReq req) {
        return ResponseBuilder.ok(service.getUserInfoList(req));
    }

    @DeleteMapping(value = "user/{questionnaireId}")
    public ResponseEntity<AuthRes> deleteUser(@PathVariable Long questionnaireId,
                                              @RequestBody AuthReq req,
                                              @RequestParam(value = "isClient", required = false) Boolean isClient) {
        req.setQuestionnaireId(questionnaireId);
        req.setSessionId(sessionBuilder.decodeSessionId(req.getSessionId()));
        req.setIsClient(isClient);
        service.call(req, "delete-user");
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @DeleteMapping(value = "user")
    public ResponseEntity<Void> user(@RequestParam Long userId,
                                     @RequestBody AuthReq req) {
        req.setUserId(userId);
        req.setSessionId(sessionBuilder.decodeSessionId(req.getSessionId()));
        service.call(req, "delete");
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PostMapping(value = "restore-password", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> restorePassword(@RequestHeader(CLIENT_ID) String clientId,
                                                   @RequestBody AuthReq req) {
        req.setClientId(clientId);
        return ResponseBuilder.ok(service.call(req, "restore_password"));
    }

    @PostMapping(value = "registration", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> registration(@RequestHeader(CLIENT_ID) String clientId,
                                                @RequestBody AuthReq req) {
        req.setClientId(clientId);
        return ResponseBuilder.okWithCookie(service.call(req, "registration"));
    }

    @PutMapping(value = "user/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> updateUser(@PathVariable("id") Long id,
                                              @RequestBody AuthReq req) {
        req.setUserId(id);
        return ResponseBuilder.ok(service.call(req, "update"));
    }

    @GetMapping(value = "consent", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ConsentRes> getConsentUrls(ConsentReq req) {
        return ResponseBuilder.ok(service.getConsentUrls(req));
    }

    @PostMapping(value = "consent", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> saveConsent(@RequestBody AuthReq req) {
        return ResponseBuilder.ok(service.call(req, "consent"));
    }

    @GetMapping(value = "user/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<UserListRes> getList(UserListReq req) {
        return ResponseBuilder.ok(service.getUserList(req));
    }

    @GetMapping(value = "access", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Access>> getAccess() {
        return ResponseBuilder.ok(service.getAccess());
    }

    @GetMapping(value = "last-session", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<LastSessionDto> getLastSession(@RequestParam Long externalId) {
        return ResponseBuilder.ok(service.getLastSession(externalId));
    }

    @GetMapping(value = "/user/{userId}/consent", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<ConsentSignDttm> getConsentSign(@PathVariable("userId") Long userId) {
        return ResponseBuilder.ok(service.getConsentSign(userId));
    }

    @DeleteMapping(value = "application-delete", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> applicationDelete(@RequestHeader(value = USER_ID, required = false) Long userId,
                                                  @RequestHeader(value = ROLE, required = false) String role,
                                                  @RequestBody ApplicationDeleteReq req) {
        service.applicationDelete(userId, role, req);
        return ResponseBuilder.ok(null);
    }

    @GetMapping(value = "companyuser/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<CompanyUsersListRes> getCompanyUsers(@RequestHeader(USER_ID) Long userId) {
        return ResponseBuilder.ok(service.getCompanyUsers(userId));
    }

    @PostMapping(value = "companyuser", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<AuthRes> postCompanyUsers(@RequestHeader(USER_ID) Long userId,
                                                    @RequestBody AuthReq req) {
        req.setUserId(userId);
        return ResponseBuilder.ok(service.call(req, "companyuser"));
    }
}
