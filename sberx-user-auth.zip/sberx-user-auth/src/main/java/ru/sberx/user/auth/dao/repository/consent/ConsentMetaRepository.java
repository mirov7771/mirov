package ru.sberx.user.auth.dao.repository.consent;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.consent.ConsentMeta;

import java.util.List;

@Repository
public interface ConsentMetaRepository extends CrudRepository<ConsentMeta, Long> {
    List<ConsentMeta> findByRelevant(Boolean relevant);
}
