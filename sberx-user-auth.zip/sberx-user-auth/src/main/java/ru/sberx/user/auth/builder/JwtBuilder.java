package ru.sberx.user.auth.builder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

@Component
@Slf4j
public class JwtBuilder {

    private static final Base64.Decoder decoder = Base64.getUrlDecoder();

    private static final ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_NULL_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES);
        mapper.disable(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
        mapper.enable(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT);
    }

    public JwtPayload getJwtPayload(String jwtToken) {
        String[] jwtParts = jwtToken.split("\\.");
        if (jwtParts.length != 3) {
            throw new SberxException(SberxErrors.BAD_REQUEST, "wrong jwt format");
        }
        String jwtEncodedPayload = jwtParts[1];
        byte[] jwtDecodedPayload = decoder.decode(jwtEncodedPayload.getBytes(StandardCharsets.UTF_8));
        try {
            return mapper.readValue(jwtDecodedPayload, JwtPayload.class);
        } catch (IOException e) {
            log.error("Error while parsing jwt token", e);
            throw new SberxException(SberxErrors.BAD_REQUEST, "cannot parse jwt");
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Data
    public static class JwtPayload {
        @JsonProperty("nonce")
        private String nonce;
        @JsonProperty("exp")
        private Long exp;
        @JsonProperty("aud")
        private Object aud;
        @JsonProperty("sub")
        private String sub;
    }

}
