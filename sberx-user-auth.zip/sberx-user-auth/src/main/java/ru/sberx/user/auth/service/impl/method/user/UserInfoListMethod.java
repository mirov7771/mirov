package ru.sberx.user.auth.service.impl.method.user;

import com.google.common.collect.Lists;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.req.UserInfoListReq;
import ru.sberx.dto.user.auth.support.UserInfoDto;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class UserInfoListMethod {

    private final UserEntityRepository userEntityRepository;

    private static final Integer MAX_SIZE_LIST = 10000;

    public List<UserInfoDto> getList(UserInfoListReq req) {
        List<UserEntity> userEntityList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(req.getUserId())) {
            List<List<Long>> partition = Lists.partition(req.getUserId(), MAX_SIZE_LIST);
            partition.forEach(list -> userEntityList.addAll(userEntityRepository.findByUserIdIn(list)));
        } else if (!CollectionUtils.isEmpty(req.getExternalId())) {
            List<List<Long>> partition = Lists.partition(req.getExternalId(), MAX_SIZE_LIST);
            partition.forEach(list -> userEntityList.addAll(userEntityRepository.findByExternalIdIn(list)));
        } else if (!CollectionUtils.isEmpty(req.getLogin())) {
            List<List<String>> partition = Lists.partition(req.getLogin(), MAX_SIZE_LIST);
            partition.forEach(list -> userEntityList.addAll(userEntityRepository.findByLoginIgnoreCaseIn(list)));
        } else
            userEntityList.addAll(userEntityRepository.findAll());

        if (CollectionUtils.isEmpty(userEntityList))
            throw new SberxException(SberxErrors.USER_NOT_FOUND);

        return userEntityList.stream()
                .map(ue -> {
                    UserInfoDto dto = new UserInfoDto();
                    dto.setUserId(ue.getUserId());
                    dto.setExternalId(ue.getExternalId());
                    dto.setLogin(ue.getLogin());
                    return dto;
                }).collect(Collectors.toList());
    }
}
