package ru.sberx.user.auth.service.impl.method.consent;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.user.auth.req.ConsentReq;
import ru.sberx.dto.user.auth.res.ConsentRes;
import ru.sberx.user.auth.dao.model.consent.ConsentMeta;
import ru.sberx.user.auth.dao.repository.consent.ConsentMetaRepository;

import java.util.List;

import static ru.sberx.user.auth.service.impl.method.auth.util.ConsentType.*;

@Component
@RequiredArgsConstructor
public class ConsentMethod {

    private final ConsentMetaRepository consentMetaRepository;

    public ConsentRes getConsentUrls(ConsentReq req) {
        ConsentRes r = new ConsentRes();
        List<ConsentMeta> consents = consentMetaRepository.findByRelevant(true);
        if (!CollectionUtils.isEmpty(consents)){
            consents.forEach(i -> {
                if (Boolean.TRUE.equals(req.getTermsOfUse()) && TERM_OF_USE.equals(i.getConsentType()))
                    r.setTermsURL(i.getConsentUrl());
                if (Boolean.TRUE.equals(req.getPrivacyPolicy()) && PRIVACY_POLICY.equals(i.getConsentType()))
                    r.setPolicyURL(i.getConsentUrl());
                if (Boolean.TRUE.equals(req.getSber500PrivacyPolicy()) && SBER500_PRIVACY_POLICY.equals(i.getConsentType()))
                    r.setSber500PrivacyPolicyURL(i.getConsentUrl());
                if (Boolean.TRUE.equals(req.getSber500Consent()) && SBER500_CONSENT.equals(i.getConsentType()))
                    r.setSber500ConsentURL(i.getConsentUrl());
                if (Boolean.TRUE.equals(req.getSber500TermOfUse()) && SBER500_TERM_OF_USE.equals(i.getConsentType()))
                    r.setSber500TermOfUseURL(i.getConsentUrl());
                if (Boolean.TRUE.equals(req.getSber500PersonalDataConsent()) && SBER500_PERSONAL_DATA_CONSENT.equals(i.getConsentType()))
                    r.setSber500PersonalDataConsentURL(i.getConsentUrl());
                if (Boolean.TRUE.equals(req.getMailingConsent()) && MAILING_CONSENT.equals(i.getConsentType()))
                    r.setMailingConsentURL(i.getConsentUrl());
            });
        }
        return r;
    }

}
