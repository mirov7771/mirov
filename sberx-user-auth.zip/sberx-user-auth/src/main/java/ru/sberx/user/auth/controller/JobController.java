package ru.sberx.user.auth.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.sberx.user.auth.service.job.JobService;

@RestController
@RequiredArgsConstructor
@RequestMapping("${spring.application.name}/job")
public class JobController {

    private final JobService jobService;

    @GetMapping("notify-users")
    public void notifyUsers(){
        jobService.notifyUsers();
    }

}
