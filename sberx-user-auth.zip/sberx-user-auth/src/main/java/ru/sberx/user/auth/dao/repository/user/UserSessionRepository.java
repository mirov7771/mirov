package ru.sberx.user.auth.dao.repository.user;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserSession;
import ru.sberx.user.auth.dao.repository.custom.CustomRepository;

import javax.transaction.Transactional;
import java.util.Date;

@Repository
public interface UserSessionRepository extends CrudRepository<UserSession, Long>, CustomRepository {

    UserSession findBySessionIdAndExpiryAfter(String sessionId, Date expiry);
    @Transactional
    @Modifying
    @Query("delete from UserSession where sessionId = :sessionId")
    void delete(@Param("sessionId") String sessionId);
    @Transactional
    @Modifying
    @Query("delete from UserSession where userId = :userId")
    void deleteByUserId(@Param("userId") Long userId);
    @Query(value = "select * from USER_SESSION where SESSIONID = :sessionId limit 1", nativeQuery = true)
    UserSession findBySessionId(@Param("sessionId") String sessionId);
    UserSession findFirstByUserEntityOrderByExpiryDesc(UserEntity userEntity);

}
