package ru.sberx.user.auth.service.impl.method.other;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.user.auth.dao.repository.user.UserSessionRepository;

@Component
@RequiredArgsConstructor
public class DeleteUserSessions {

    private final UserSessionRepository userSessionRepository;

    public void execute(Long userId) {
        userSessionRepository.deleteByUserId(userId);
    }
}
