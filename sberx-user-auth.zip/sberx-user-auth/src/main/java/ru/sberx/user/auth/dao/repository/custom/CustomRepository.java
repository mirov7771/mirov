package ru.sberx.user.auth.dao.repository.custom;

import java.util.Date;
import java.util.List;

public interface CustomRepository {
    List<SessionUser> findByExpiry(Integer role, Date expiry);
}
