package ru.sberx.user.auth.service.impl.method.consent;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.sberx.dto.questionary.questionary.questionary.req.QuestionnaireUpdateReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;
import ru.sberx.user.auth.service.impl.method.auth.AuthService;

import java.util.List;

@Component("consent")
@RequiredArgsConstructor
public class SaveConsentMethod extends AuthService {

    private final UserEntityRepository userEntityRepository;

    @Override
    public AuthRes execute(AuthReq req) {
        UserEntity userEntity = userEntityRepository.findByExternalId(req.getUserId());
        Long userId = req.getUserId();
        if (userEntity != null && userEntity.getUserId() != null)
            userId = userEntity.getUserId();
        saveConsent(req.getTermsOfUse(),
                req.getPrivacyPolicy(),
                req.getSber500PrivacyPolicy(),
                req.getSber500Consent(),
                req.getSber500TermOfUse(),
                req.getSber500PersonalDataConsent(),
                req.getMailingConsent(),
                userId);
        if (req.getMailingConsent() != null) {
            userEntity = userEntityRepository.findByUserId(userId);
            if (userEntity != null && userEntity.getExternalId() != null) {
                List<TypeRes> types = questionaryService.getTypeByUserId(userEntity.getExternalId());
                QuestionnaireUpdateReq updateReq = new QuestionnaireUpdateReq();
                updateReq.setIsMarketing(Boolean.TRUE.equals(req.getMailingConsent()) ? "ДА" : "НЕТ");
                types.forEach(t -> questionaryService.updateQuestionary(t.getQuestionnaireId(), updateReq));
            }
        }
        return null;
    }
}
