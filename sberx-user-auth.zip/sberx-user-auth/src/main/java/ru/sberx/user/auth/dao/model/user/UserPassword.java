package ru.sberx.user.auth.dao.model.user;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.user.auth.dao.model.pk.UserPasswordPK;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "USER_PASSWORD")
@IdClass(UserPasswordPK.class)
@Getter
@Setter
public class UserPassword implements Serializable {

    private static final long serialVersionUID = 400119298127460225L;
    @Id
    @Column(name = "USERID")
    private Long userId;
    @Id
    @Column(name = "PASSWORD")
    private String password;
    @Column(name = "DATE")
    private Date date;

}
