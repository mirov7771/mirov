package ru.sberx.user.auth.dao.repository.user;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.user.UserPassword;

import java.util.List;

@Repository
public interface UserPasswordRepository extends CrudRepository<UserPassword, Long> {
    @Query(value = "select * from USER_PASSWORD where USERID = :userId order by DATE desc limit 4", nativeQuery = true)
    List<UserPassword> findByUserId(@Param("userId") Long userId);
}
