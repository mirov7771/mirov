package ru.sberx.user.auth.dao.model.consent;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "CONSENT_META")
@Getter
@Setter
@NoArgsConstructor
public class ConsentMeta implements Serializable {

    private static final long serialVersionUID = 6698704181812927726L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "RELEVANT")
    private Boolean relevant;
    @Column(name = "CONSENT_TEXT")
    private String consentText;
    @Column(name = "CONSENT_URL")
    private String consentUrl;
    @Column(name = "CONSENT_NAME")
    private String consentName;
    @Column(name = "CONSENT_TYPE")
    private String consentType;
}
