package ru.sberx.user.auth.dao.model.user;

import lombok.Getter;
import lombok.Setter;
import ru.sberx.dto.user.auth.res.AuthRes;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "USER_ENTITY")
@Getter
@Setter
public class UserEntity implements Serializable {

    private static final long serialVersionUID = -6561372579779881926L;

    @Id
    @Column(name = "USERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;
    @Column(name = "LOGIN")
    private String login;
    @Column(name = "PASSWORD")
    private String password;
    @Column(name = "ENTERS")
    private Integer enters;
    @Column(name = "DEPARTMENTID")
    private String departmentId;
    @Column(name = "EXTERNALID")
    private Long externalId;
    @Column(name = "SUB")
    private String sub;
    @Column(name = "EXPIRY")
    private Date expiry;
    @Column(name = "WRONG_AUTH_COUNT")
    private Integer wrongAuthCount;
    @Column(name = "WRONG_AUTH_LOCK")
    private Date wrongAuthLock;
    @Column(name = "EXPIRE_LOCK")
    private Date expireLock;
    @Column(name = "USER_ROLE")
    private Integer userRole;
    @OneToMany(mappedBy = "userId")
    private List<UserRoleLink> userRoleLinkList;
    @OneToMany(mappedBy = "userEntity")
    private List<UserSession> userSession;
    @Column(name = "NEW_USER")
    private Boolean newUser;
    @Column(name = "REPORTS_USE")
    private Boolean reportsUse;
    @Column(name = "CREATED")
    private Date created;
    @Column(name = "PHONE")
    private String phone;
    @Column(name = "PHONE_VERIFIED")
    private Boolean phoneVerified;
    @Column(name = "OTP")
    private String otp;
    @Column(name = "LASTENTER")
    private Date lastEnter;
    @Column(name = "MAIN_USER")
    private Boolean mainUser;

    public AuthRes toDto() {
        AuthRes res = new AuthRes();
        res.setExternalId(this.userId);
        res.setLogin(this.login);
        res.setEnters(this.enters);
        res.setEntersName(this.enters != null && this.enters.equals(1) ? "Активный" : "Ожидает входа");
        res.setCreated(this.created);
        return res;
    }
}
