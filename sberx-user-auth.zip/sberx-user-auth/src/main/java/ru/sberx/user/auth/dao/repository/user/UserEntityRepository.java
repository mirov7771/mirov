package ru.sberx.user.auth.dao.repository.user;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nonnull;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.user.UserEntity;

@Repository
public interface UserEntityRepository extends JpaRepository<UserEntity, Long> {

    UserEntity findByLoginIgnoreCase(String login);
    UserEntity findByUserId(Long userId);
    List<UserEntity> findBySub(String sub);
    @Query(value = "select * from user_entity where externalId = :externalId limit 1", nativeQuery = true)
    UserEntity findByExternalId(@Param("externalId") Long externalId);
    @Query(value = "select * " +
            "from user_entity u " +
            "inner join user_role_link l " +
        "on l.userid = u.userid " +
        "inner join role_classify c " +
        "on c.roletype = :roleType " +
        " and c.roleid = l.roleid " +
        "where upper(u.login) = :login " +
        "and u.password = :password " +
        "limit 1", nativeQuery = true)
    UserEntity findUser(@Param("login") String login,
        @Param("password") String password,
        @Param("roleType") String roleType);

    @Query("from UserEntity as e join e.userRoleLinkList as r join r.userRole as ur where ur.roleSysName = :role")
    List<UserEntity> findUsersByRole(String role);

    @Modifying
    @Transactional
    void deleteByUserId(Long userId);

    @Query(value = "select * from user_entity ue where expiry < :date and new_user = true", nativeQuery = true)
    List<UserEntity> findNewUsers(@Param("date") Date date);

    @Query(value = "select *" +
            "from user_entity ue " +
            "where (upper(login) = upper(:login)) " +
            "or (formatPhone(phone) = formatPhone(:login)) " +
            "limit 1", nativeQuery = true)
    Optional<UserEntity> findByLoginOrPhone(@Param("login") String login);

    @Query(value = "select *" +
            "from user_entity ue " +
            "where (upper(login) = upper(:login)) " +
            "or (formatPhone(phone) = formatPhone(:login)) " +
            "and password = :password " +
            "and otp = :otp " +
            "limit 1", nativeQuery = true)
    Optional<UserEntity> findByLoginOrPhoneAndPasswordAndOtp(@Param("login") String login,
                                                             @Param("password") String password,
                                                             @Param("otp") String otp);

    List<UserEntity> findByUserRole(Integer userRole);
    List<UserEntity> findByUserIdIn(List<Long> userId);
    List<UserEntity> findByExternalIdIn(List<Long> externalId);
    List<UserEntity> findByLoginIgnoreCaseIn(List<String> login);
    @Nonnull
    @Override
    List<UserEntity> findAll();
}
