package ru.sberx.user.auth.service.impl.method.user;

import lombok.RequiredArgsConstructor;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.UserListReq;
import ru.sberx.dto.user.auth.res.UserListRes;
import ru.sberx.user.auth.builder.QueryBuilder;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.utils.util.ListUtils;

import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class UserListMethod {

    private final QueryBuilder queryBuilder;

    public UserListRes getList(UserListReq req){
        UserListRes res = new UserListRes();
        List<UserEntity> list = queryBuilder.getListWithCriteria(req);
        res.setTotalRowCount(list.size());
        int rowCount = req.getRowCount() != null && list.size() > req.getRowCount() ? req.getRowCount() : list.size();
        res.setRowCount(rowCount);
        Pair<List<UserEntity>, Integer> shortenList = ListUtils.pagination(list, rowCount, req.getPageToken());
        res.setList(shortenList.getFirst().stream().map(UserEntity::toDto).collect(Collectors.toList()));
        res.setTotalPageCount((int) Math.ceil(res.getTotalRowCount()/res.getRowCount().floatValue()));
        res.setNextPageToken(shortenList.getSecond() > 0? shortenList.getSecond() : null);
        return res;
    }

}
