package ru.sberx.user.auth.dao.repository.custom;

import org.hibernate.query.Query;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

public class CustomRepositoryImpl implements CustomRepository{

    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Override
    public List<SessionUser> findByExpiry(Integer role, Date expiry) {
        Query<SessionUser> query = entityManager.createNativeQuery("select ue.login, us.expiry, us.userid, ue.externalid " +
                        "from user_session us " +
                        "inner join user_entity ue " +
                        "on ue.userid = us.userid " +
                        "and ue.user_role = :role " +
                        "and ue.externalid is not null " +
                        "where us.expiry < :expiry")
                .unwrap(Query.class)
                .setResultTransformer((ListResultTransformer)
                        (tuple, aliases) -> new SessionUser(
                                ((String) tuple[0]),
                                ((Date) tuple[1]),
                                ((BigInteger) tuple[2]).longValue(),
                                ((BigInteger) tuple[3]).longValue()));
        query.setParameter("expiry", expiry);
        query.setParameter("role", role);
        return query.getResultList();
    }
}
