package ru.sberx.user.auth.service.impl.method.consent;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.dto.user.auth.support.ConsentSignDttm;
import ru.sberx.user.auth.dao.model.consent.UserConsent;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.consent.UserConsentRepository;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;

import java.util.List;

@Component
@RequiredArgsConstructor
public class ConsentSignMethod {

    private final UserConsentRepository userConsentRepository;
    private final UserEntityRepository userEntityRepository;

    public ConsentSignDttm getConsentSign(Long userId) {
        ConsentSignDttm res = new ConsentSignDttm();
        UserEntity userEntity = userEntityRepository.findByExternalId(userId);
        if (userEntity != null) {
            List<UserConsent> consents = userConsentRepository.findByUserId(userEntity.getUserId());
            if (!CollectionUtils.isEmpty(consents)) {
                UserConsent uc = consents.get(0);
                res.setTermsOfUse(uc.getTermsId() != null ? uc.getSignDttm() : null);
                res.setPrivacyPolicy(uc.getPolicyId() != null ? uc.getSignDttm() : null);
                res.setSber500PrivacyPolicy(uc.getSber500PrivacyPolicyId() != null ? uc.getSignDttm() : null);
                res.setSber500Consent(uc.getSber500ConsentId() != null ? uc.getSignDttm() : null);
                res.setSber500TermOfUse(uc.getSber500TermOfUseId() != null ? uc.getSignDttm() : null);
                res.setSber500PersonalDataConsent(uc.getSber500PersonalDataConsentId() != null ? uc.getSignDttm() : null);
                res.setMailingConsent(uc.getMailingConsent() != null ? uc.getSignDttm() : null);
            }
        }
        return res;
    }
}
