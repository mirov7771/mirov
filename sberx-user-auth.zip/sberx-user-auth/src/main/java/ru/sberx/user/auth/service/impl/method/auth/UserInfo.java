package ru.sberx.user.auth.service.impl.method.auth;

import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;

@Component("user_info")
public class UserInfo extends AuthService {

    @Override
    public AuthRes execute(AuthReq req) {
        UserEntity ue;
        if (req.getExternalId() != null)
            ue = userEntityRepository.findByExternalId(req.getExternalId());
        else if (req.getUserId() != null)
            ue = userEntityRepository.findByUserId(req.getUserId());
        else if (req.getEmail() != null)
            ue = userEntityRepository.findByLoginIgnoreCase(req.getEmail());
        else
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS);

        if (ue == null)
            throw new SberxException(SberxErrors.USER_NOT_FOUND);

        AuthRes res = new AuthRes();
        res.setUserId(ue.getUserId());
        res.setExternalId(ue.getExternalId());
        res.setLogin(ue.getLogin());
        return res;
    }
}
