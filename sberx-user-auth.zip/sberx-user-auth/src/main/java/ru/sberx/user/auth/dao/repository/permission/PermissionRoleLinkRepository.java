package ru.sberx.user.auth.dao.repository.permission;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.permission.PermissionRoleLink;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface PermissionRoleLinkRepository extends CrudRepository<PermissionRoleLink, Long> {
    List<PermissionRoleLink> findByRoleIdIn(List<Long> roleIds);
    List<PermissionRoleLink> findByRoleId(Long roleId);

    @Transactional
    @Modifying
    void deleteByPermissionId(Long permissionId);

    @Transactional
    @Modifying
    void deleteByRoleId(Long roleId);
}
