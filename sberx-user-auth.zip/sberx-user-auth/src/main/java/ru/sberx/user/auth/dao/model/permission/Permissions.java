package ru.sberx.user.auth.dao.model.permission;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sberx.dto.user.auth.support.Permission;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "PERMISSIONS")
@Getter
@Setter
@NoArgsConstructor
public class Permissions implements Serializable {

    private static final long serialVersionUID = -7166354019492475993L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "NAME")
    private String name;

    public Permission toDto(){
        Permission permission = new Permission();
        permission.setName(this.name);
        permission.setType(this.type);
        return permission;
    }

    public Permission toFullDto(){
        Permission permission = toDto();
        permission.setId(this.id);
        return permission;
    }

    public Permissions(Permission req){
        if (req.getId() != null)
            this.id = req.getId();
        this.name = req.getName();
        this.type = req.getType();
    }
}
