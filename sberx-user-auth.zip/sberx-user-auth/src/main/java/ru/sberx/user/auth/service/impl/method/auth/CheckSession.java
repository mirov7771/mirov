package ru.sberx.user.auth.service.impl.method.auth;

import org.springframework.stereotype.Component;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;

@Component("checksession")
public class CheckSession extends AuthService {

    @Override
    public AuthRes execute(AuthReq req) {
        UserEntity user = validateSession(req);
        AuthRes res = new AuthRes();
        res.setLogin(user.getLogin());
        res.setExternalId(user.getExternalId());
        UserRoleLink role = user.getUserRoleLinkList().get(0);
        res.setRole(role.getUserRole().getRoleSysName());
        res.setUserRole(user.getUserRole());
        res.setDepartmentId(user.getDepartmentId());
        res.setUserId(user.getUserId());
        res.setReportsUse(user.getReportsUse());
        res.setPermissions(getPermissions(user));
        return res;
    }

}
