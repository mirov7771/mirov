package ru.sberx.user.auth.service.impl.method.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.questionary.questionary.res.DeleteQuestionnaireRes;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.other.DeleteInfo;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.other.DeleteInfoRepository;

import java.util.Date;

@Component("delete-user")
@RequiredArgsConstructor
public class DeleteUser extends AuthService {

    private final DeleteInfoRepository deleteInfoRepository;

    @Override
    public AuthRes execute(AuthReq req) {
        return deleteUser(req, false);
    }

    public AuthRes deleteUserInJobMode(AuthReq req) {
        return deleteUser(req, true);
    }


    private AuthRes deleteUser(AuthReq req, boolean jobMode) {
        AuthRes res = new AuthRes();
        UserEntity user;
        if (jobMode) {
            user = userEntityRepository.findByUserId(req.getUserId());
        } else {
            user = validateAccessUserExecuteDeleting(req);
        }
        if (user == null) {
            throw new SberxException(SberxErrors.USER_NOT_FOUND);
        }
        DeleteQuestionnaireRes info = questionaryService.deleteQuestionary(req.getQuestionnaireId());
        if (info != null) {
            Long userId = info.getUserId();
            DeleteInfo deleteInfo = new DeleteInfo();
            deleteInfo.setUserId(userId == null ? 0 : userId);
            deleteInfo.setQuestionnaireId(req.getQuestionnaireId());
            deleteInfo.setDeleteDttm(new Date());
            deleteInfo.setFullName(info.getFullName());
            if (Integer.valueOf(6).equals(user.getUserRole()) || Integer.valueOf(7).equals(user.getUserRole())) {
                deleteInfo.setComment("Удаление по инициативе пользователя");
            } else {
                deleteInfo.setComment(req.getComment());
            }
            deleteInfoRepository.save(deleteInfo);

            if (userId != null || jobMode) {
                UserEntity ue;
                if (jobMode) {
                    ue = userEntityRepository.findByUserId(user.getUserId());
                } else {
                    ue = userEntityRepository.findByExternalId(userId);
                }
                if (ue != null && ue.getUserId() != null) {
                    if (jobMode && StringUtils.hasText(ue.getLogin())) {
                        res.setLogin(ue.getLogin());
                    }
                    if (ue.getExternalId() != null) {
                        Long eId = ue.getExternalId();
                        userProfileRepository.deleteById(eId);
                    }
                    long userIdForDelete = ue.getUserId() != null ? ue.getUserId() : null;
                    userEntityRepository.deleteByUserId(userIdForDelete);
                    userRoleLinkRepository.deleteByUserId(userIdForDelete);
                    userSessionRepository.deleteByUserId(userIdForDelete);
                    userConsentRepository.deleteByUserId(userIdForDelete);
                }
            }
            res.setDeleteRes(info);
        }
        if (Boolean.TRUE.equals(req.getIsClient())){
            throw new SberxException(SberxErrors.INVALID_SESSION, null);
        }
        return res;
    }

}
