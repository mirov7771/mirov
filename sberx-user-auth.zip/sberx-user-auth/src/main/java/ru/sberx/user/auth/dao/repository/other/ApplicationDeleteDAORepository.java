package ru.sberx.user.auth.dao.repository.other;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sberx.user.auth.dao.model.other.ApplicationDeleteDAO;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

@Repository
public interface ApplicationDeleteDAORepository extends CrudRepository<ApplicationDeleteDAO, Long> {
    List<ApplicationDeleteDAO> findByDateBefore(Date date);
    List<ApplicationDeleteDAO> findByApplicationId(Long applicationId);
    @Transactional
    @Modifying
    @Query(value = "delete from application_delete where user_id = :userId", nativeQuery = true)
    void deleteByUserId(@Param("userId") Long userId);
    List<ApplicationDeleteDAO> findByUserId(Long userId);
}
