package ru.sberx.user.auth.service.impl.method.auth;

import java.util.*;

import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.Constants;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.external.gate.SberNotifyService;
import ru.sberx.user.auth.dao.model.user.UserPassword;
import ru.sberx.user.auth.dao.repository.user.UserPasswordRepository;
import ru.sberx.user.auth.dao.model.other.ApplicationDeleteDAO;
import ru.sberx.user.auth.dao.model.user.UserSession;
import ru.sberx.user.auth.service.impl.method.auth.util.AuthConfig;
import ru.sberx.user.auth.dao.model.consent.UserConsent;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.service.impl.method.auth.util.Status;

import static ru.sberx.utils.builder.SessionBuilder.decrypt;

@Component("auth")
public class Auth extends AuthService {

    @Autowired
    private AuthConfig authConfig;
    @Autowired
    private SberNotifyService sberNotifyService;
    @Autowired
    private UserPasswordRepository userPasswordRepository;

    @Value("${application.notify.syssenderurn}")
    private String sysSenderUrn;
    @Value("${application.notify.subsystemcode}")
    private String subSystemCode;
    @Value("${application.notify.msgtype}")
    private String msgType;
    @Value("${application.notify.clientid}")
    private String clientId;
    @Value("${application.notify.clientsecret}")
    private String clientSecret;
    @Value("${application.notify.granttype}")
    private String grantType;
    @Value("${application.notify.scope}")
    private String scope;

    private static final String CLIENT_AUTH = "client";
    private static final String OTP_AUTH = "otp";

    @Override
    public AuthRes execute(AuthReq req) {
        AuthRes res = new AuthRes();
        if (isReqForPasswordCheckingOrChanging(req, res))
            return res;
        validateAuth(req);
        UserEntity user;
        if (OTP_AUTH.equalsIgnoreCase(req.getType())) {
            authByOtp(req, res);
        } else {
            if (Boolean.TRUE.equals(req.getTermOfUseConsent())) {
                user = userEntityRepository.findByLoginIgnoreCase(req.getLogin().toUpperCase());
                saveConsent(true, true, false, false, false, false, false, user.getUserId());
            } else {
                user = userEntityRepository.findUser(req.getLogin().toUpperCase(), req.getPassword(), req.getType());
            }
            if (checkForDelete(req, user, res))
                return res;

            if (user == null) {
                if (CLIENT_AUTH.equals(req.getType())) {
                    user = userEntityRepository.findByLoginIgnoreCase(req.getLogin());
                    if (user != null)
                        setWrongAuthCount(user);
                }
                throw new SberxException(SberxErrors.WRONG_LOGIN_PASSWORD);
            } else if (Boolean.TRUE.equals(isExpired(user.getExpiry())) &&
                    user.getLogin().contains("@")) {
                res.setStatus(Status.EXPIRED.toString());
                processExistsClient(generateAndSendPassword(user.getLogin(), null, "RestorePassword", user.getUserId()), user, user.getUserRole(), null);
            } else if (CLIENT_AUTH.equals(req.getType())
                    && Boolean.TRUE.equals(userIsBlocked(user.getWrongAuthLock()))) {
                throw new SberxException(1026, HttpStatus.BAD_REQUEST, getBlockedMsg(user.getWrongAuthLock()), null);
            } else if (noEnters(req.getNewPassword(), user.getEnters())) {
                res.setStatus(Status.CHANGEPASSWORD.toString());
            } else {
                long userId = user.getUserId() != null ? user.getUserId() : null;
                List<UserPassword> userPasswords = userPasswordRepository.findByUserId(userId);
                if (!CollectionUtils.isEmpty(userPasswords)
                        && userPasswords.stream().noneMatch(i -> getDaysDiff(new Date(), i.getDate()) <= 80)) {
                    res.setStatus(Status.CHANGEPASSWORD.toString());
                } else {
                    if (req.getNewPassword() != null) {
                        if (!CollectionUtils.isEmpty(userPasswords)
                                && userPasswords.stream().anyMatch(i -> i.getPassword().equalsIgnoreCase(req.getNewPassword())))
                            throw new SberxException(SberxErrors.PASSWORD_EXISTS);

                        user.setEnters(1);
                        user.setPassword(req.getNewPassword());
                        user.setExpiry(getClientExpiry());
                        user.setWrongAuthCount(0);
                        user.setWrongAuthLock(null);
                        user.setExpireLock(null);
                        user.setNewUser(false);
                        userEntityRepository.save(user);

                        UserPassword userPassword = new UserPassword();
                        userPassword.setUserId(user.getUserId());
                        userPassword.setPassword(req.getNewPassword());
                        userPassword.setDate(new Date());
                        userPasswordRepository.save(userPassword);
                    } else if (CLIENT_AUTH.equals(req.getType())) {
                        user.setWrongAuthCount(0);
                        user.setWrongAuthLock(null);
                        user.setExpireLock(null);
                        user.setNewUser(false);
                        userEntityRepository.save(user);
                    }
                    if (CLIENT_AUTH.equals(req.getType()) && !Boolean.TRUE.equals(req.getTermOfUseConsent())) {
                        List<UserConsent> consents = userConsentRepository.findByUserId(user.getUserId());
                        if (isTermOfUse(consents)) {
                            user.setEnters(1);
                            user.setNewUser(false);
                            userEntityRepository.save(user);
                        } else {
                            res.setStatus(Status.SIGNTERMOFUSE.toString());
                            return res;
                        }
                    }
                    createSession(user, res, null, null, null);
                }
            }
            if (!CLIENT_AUTH.equals(req.getType())
                    && res.getStatus() != null
                    && "OK".equals(res.getStatus()))
                res.setLogin(user.getLogin());
            else if (user.getExternalId() != null) {
                List<TypeRes> type = questionaryService.getTypeByUserId(user.getExternalId());
                if (!CollectionUtils.isEmpty(type)){
                    res.setType(type.get(0).getType());
                    res.setApplicationId(type.get(0).getQuestionnaireId());
                    res.setUuid(type.get(0).getUid());
                } else {
                    setAppId(user, res);
                }
            }
        }
        return res;
    }

    private boolean checkForDelete(AuthReq req, UserEntity user, AuthRes res) {
        if (!StringUtils.hasText(req.getLogin())
                || !StringUtils.hasText(req.getPassword()))
            return false;

        if (user != null && user.getUserId() != null
                && StringUtils.hasText(user.getPassword())
                && req.getPassword().equals(user.getPassword())) {
            List<ApplicationDeleteDAO> appDeleteList = applicationDeleteDAORepository
                    .findByUserId(user.getUserId());
            if (appDeleteList.size() > 1) {
                res.setAppId(
                        Collections.max(
                                appDeleteList,
                                Comparator.comparing(ApplicationDeleteDAO::getDate))
                                .getApplicationId());
                return true;
            }
            if (appDeleteList.size() == 1) {
                res.setAppId(appDeleteList.get(0).getApplicationId());
                return true;
            }
        }
        return false;
    }

    private boolean isReqForPasswordCheckingOrChanging(AuthReq req, AuthRes res) {
        if (req.getLogin() == null && StringUtils.hasText(req.getPassword())
                && StringUtils.hasText(req.getSessionId())) {
            String sessionIdDecrypted;
            try {
                sessionIdDecrypted = decrypt(new String(Constants.Decoders.BASE_64.decode(req.getSessionId())));
                if (sessionIdDecrypted == null) {
                    throw new SberxException(SberxErrors.INVALID_SESSION);
                }
            } catch (Exception e) {
                throw new SberxException(SberxErrors.INVALID_SESSION);
            }
            UserSession session = userSessionRepository.findBySessionId(sessionIdDecrypted);
            if (session != null
                    && session.getUserEntity() != null
                    && session.getUserEntity().getUserId() != null
                    && StringUtils.hasText(session.getUserEntity().getPassword())
                    && session.getUserEntity().getPassword().equals(req.getPassword())) {
                if (StringUtils.hasText(req.getNewPassword())) {
                    session.getUserEntity().setPassword(req.getNewPassword());
                    userEntityRepository.save(session.getUserEntity());
                }
                res.setStatus("OK");
                return true;
            } else {
                throw new SberxException(SberxErrors.WRONG_LOGIN_PASSWORD);
            }
        }
        return false;
    }

    private String getBlockedMsg(Date lockTime){
        String locale = ThreadContext.get("locale") == null ? "ru" : ThreadContext.get("locale");
        String errMsg = SberxErrors.USER_BLOCKED.getMessage().get(locale);
        errMsg += ("ru".equals(locale) ? " по "  : " until ") + lockTime;
        return errMsg;
    }

    private void authByOtp(AuthReq req, AuthRes res){
        Optional<UserEntity> userDao = userEntityRepository.findByLoginOrPhone(req.getLogin());
        if (userDao.isEmpty())
            throw new SberxException(SberxErrors.USER_NOT_FOUND);
        if (!req.getPassword().equals(userDao.get().getPassword())) {
            setWrongAuthCount(userDao.get());
            throw new SberxException(SberxErrors.WRONG_LOGIN_PASSWORD);
        }
        if (Boolean.TRUE.equals(userIsBlocked(userDao.get().getWrongAuthLock())))
            throw new SberxException(1026, HttpStatus.BAD_REQUEST, getBlockedMsg(userDao.get().getWrongAuthLock()), null);
        if (Boolean.TRUE.equals(isExpired(userDao.get().getExpiry()))){
            res.setStatus(Status.EXPIRED.toString());
            processExistsClient(generateAndSendPassword(userDao.get().getLogin(),
                    null,
                    "RestorePassword",
                            userDao.get().getUserId()),
                    userDao.get(),
                    userDao.get().getUserRole(),
                    null);
        } else if (noEnters(req.getNewPassword(), userDao.get().getEnters())) {
            res.setStatus(Status.CHANGEPASSWORD.toString());
        } else {
            UserEntity user = userDao.get();
            if (Boolean.TRUE.equals(req.getResendOTP())){
                increaseWrongAuthCount(user);
                user.setOtp(getHash(sendSmsCode(ThreadContext.get(Constants.Header.REQUEST_ID),
                        user.getPhone())));
                res.setStatus(Status.OTP.toString());
                res.setPhoneMask(user.getPhone());
                userEntityRepository.save(user);
            } else if (StringUtils.hasText(req.getOtp())){
                Optional<UserEntity> otp = userEntityRepository.findByLoginOrPhoneAndPasswordAndOtp(req.getLogin(),
                        req.getPassword(),
                        req.getOtp());
                if (otp.isEmpty()){
                    increaseWrongAuthCount(user);
                    userEntityRepository.save(user);
                    res.setStatus(Status.OTP.toString());
                    res.setPhoneMask(user.getPhone());
                } else {
                    if (Boolean.TRUE.equals(req.getTermOfUseConsent())) {
                        saveConsent(true, true, false, false, false, false, false, user.getUserId());
                    }
                    if (isTermOfUse(userConsentRepository.findByUserId(user.getUserId()))){
                        user.setEnters(1);
                        user.setNewUser(false);
                        userEntityRepository.save(user);
                        createSession(user, res, null, null, null);
                    } else {
                        res.setStatus(Status.SIGNTERMOFUSE.toString());
                    }
                }
            } else {
                if (!Boolean.TRUE.equals(userDao.get().getPhoneVerified())){
                    if (StringUtils.hasText(req.getNewPhone())){
                        user.setPhone(req.getNewPhone());
                        user.setPhoneVerified(true);
                        increaseWrongAuthCount(user);
                        user.setOtp(getHash(sendSmsCode(ThreadContext.get(Constants.Header.REQUEST_ID),
                                user.getPhone())));
                        res.setStatus(Status.OTP.toString());
                        res.setPhoneMask(user.getPhone());
                        userEntityRepository.save(user);
                    } else {
                        res.setStatus(Status.SETPHONE.toString());
                    }
                } else {
                    user.setOtp(getHash(sendSmsCode(ThreadContext.get(Constants.Header.REQUEST_ID),
                            user.getPhone())));
                    res.setStatus(Status.OTP.toString());
                    res.setPhoneMask(user.getPhone());
                    userEntityRepository.save(user);
                }
            }
        }
    }

    private String sendSmsCode(String rqUid,
                               String phone){
        String code = createCode();
        String result = sberNotifyService.sendOauth(sysSenderUrn,
                subSystemCode,
                msgType,
                rqUid,
                phone,
                code,
                clientId,
                clientSecret,
                grantType,
                scope);
        if (result.equalsIgnoreCase("SUCCESS"))
            throw new SberxException(SberxErrors.EMAIL_SERVER_NOT_REACHABLE);
        return code;
    }

    private void setWrongAuthCount(UserEntity user){
        increaseWrongAuthCount(user);
        Integer lockMin = authConfig.getLock().get(user.getWrongAuthCount());
        if (lockMin != null && !lockMin.equals(0)) {
            user.setWrongAuthLock(createExpiry(Calendar.MINUTE, lockMin));
            user.setExpireLock(new Date());
        }
        userEntityRepository.save(user);
    }

    private void increaseWrongAuthCount(UserEntity user){
        Integer wrongAuthCount = user.getWrongAuthCount() == null ? 1 : user.getWrongAuthCount() + 1;
        user.setWrongAuthCount(wrongAuthCount);
    }

    private boolean userIsBlocked(Date lock){
        return lock != null &&
                lock.after(new Date());
    }

    private boolean isExpired(Date expiry){
        return expiry != null &&
                expiry.before(new Date());
    }

    private boolean noEnters(String pwd, Integer ent){
        return pwd == null && ent != null && ent.equals(0);
    }

    private String createCode(){
        Random rand = new Random();
        StringBuilder pin = new StringBuilder();
        for(int i = 0; i < 4; i++) {
            String s1 = rand.nextInt(10) + "";
            pin.append(s1, 0, 1);
        }
        return pin.toString();
    }

    private int getDaysDiff(Date date1, Date date2){
        long milliseconds = date1.getTime() - date2.getTime();
        return  (int) (milliseconds / (24 * 60 * 60 * 1000));
    }

}
