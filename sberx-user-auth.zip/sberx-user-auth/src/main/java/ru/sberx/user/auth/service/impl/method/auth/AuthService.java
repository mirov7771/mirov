package ru.sberx.user.auth.service.impl.method.auth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.passay.CharacterData;
import org.passay.CharacterRule;
import org.passay.EnglishCharacterData;
import org.passay.PasswordGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.sberx.constants.Constants;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.notifications.req.NotifyReq;
import ru.sberx.dto.notifications.support.NoticeDto;
import ru.sberx.dto.questionary.application.support.ApplicationDto;
import ru.sberx.dto.questionary.questionary.questionary.req.DraftReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.dto.user.auth.support.Permission;
import ru.sberx.external.gate.SberUserIdService;
import ru.sberx.external.gate.dto.SbUserInfo;
import ru.sberx.external.gate.dto.Token;
import ru.sberx.unity.gate.notifications.NotificationService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.user.auth.builder.JwtBuilder;
import ru.sberx.user.auth.dao.model.consent.ConsentMeta;
import ru.sberx.user.auth.dao.model.consent.UserConsent;
import ru.sberx.user.auth.dao.model.other.SessionConfig;
import ru.sberx.user.auth.dao.model.permission.PermissionRoleLink;
import ru.sberx.user.auth.dao.model.user.*;
import ru.sberx.user.auth.dao.repository.consent.ConsentMetaRepository;
import ru.sberx.user.auth.dao.repository.consent.UserConsentRepository;
import ru.sberx.user.auth.dao.repository.other.ApplicationDeleteDAORepository;
import ru.sberx.user.auth.dao.repository.other.SessionConfigRepository;
import ru.sberx.user.auth.dao.repository.permission.PermissionRoleLinkRepository;
import ru.sberx.user.auth.dao.repository.permission.PermissionsRepository;
import ru.sberx.user.auth.dao.repository.user.*;
import ru.sberx.user.auth.service.impl.method.auth.util.Status;
import ru.sberx.utils.builder.SessionBuilder;

import static ru.sberx.user.auth.service.impl.method.auth.util.ConsentType.*;

@Slf4j
public abstract class AuthService {

    @Autowired
    protected UserEntityRepository userEntityRepository;
    @Autowired
    protected UserSessionRepository userSessionRepository;
    @Autowired
    protected SessionConfigRepository sessionConfigRepository;
    @Autowired
    protected SberUserIdService externalService;
    @Autowired
    protected QuestionaryService questionaryService;
    @Autowired
    protected UserRoleRepository userRoleRepository;
    @Autowired
    protected UserRoleLinkRepository userRoleLinkRepository;
    @Autowired
    private SessionBuilder sessionBuilder;
    @Autowired
    protected UserProfileRepository userProfileRepository;
    @Autowired
    protected UserConsentRepository userConsentRepository;
    @Autowired
    private ConsentMetaRepository consentMetaRepository;
    @Autowired
    protected NotificationService notificationService;
    @Autowired
    private PermissionRoleLinkRepository permissionRoleLinkRepository;
    @Autowired
    private PermissionsRepository permissionsRepository;
    @Autowired
    protected ApplicationDeleteDAORepository applicationDeleteDAORepository;
    @Autowired
    private JwtBuilder jwtBuilder;
    @Value("${application.session.timeout:300}")
    protected Integer sessionTimeout;
    protected Integer customTimeout;
    @Value("${application.session.pwdexpiry:5}")
    private Integer pwdExpiry;
    @Value("${application.default.clientId}")
    protected String defaultClientId;
    @Value("${application.default.password}")
    protected String defaultPassword;
    @Value("${application.aud}")
    private String[] auds;
    @Value("${application.auth.client-secret:0}")
    protected String clientSecret;

    private static final Set<String> ALLOWED_USERS = Set.of("Administrator", "Client", "SuperClient");

    public abstract AuthRes execute(AuthReq req);

    protected void validateAuth(AuthReq req){
        if (req.getLogin() == null && req.getPassword() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: login, password");
        else if (req.getLogin() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: login");
        else if (req.getPassword() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: password");
    }

    protected UserEntity validateSession(AuthReq req){
        if (req.getSessionId() == null)
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: sessionid");
        String sId = req.getSessionId();
        UserSession session = userSessionRepository.findBySessionIdAndExpiryAfter(sId, new Date());
        if (session == null) {
            userSessionRepository.delete(sId);
            throw new SberxException(SberxErrors.INVALID_SESSION);
        }

        if (session.getExp() != null
                && StringUtils.hasText(session.getRefreshToken())
                && session.getExp().before(new Date()))
        {
            SessionConfig config = sessionConfigRepository.findByClientId(session.getClientId());
            if (config == null)
                throw new SberxException(SberxErrors.INVALID_SESSION, "no config found for session");
            UserToken userToken = checkToken("grant_type=refresh_token&client_id=sberunity&client_secret="
                    + clientSecret + "&refresh_token=" + session.getRefreshToken());
            if (userToken != null && userToken.getExp() != null && StringUtils.hasText(userToken.getRefreshToken())){
                session.setExpiry(getExpiry());
                session.setExp(userToken.getExp());
                session.setRefreshToken(userToken.getRefreshToken());
                userSessionRepository.save(session);
            }
        }

        validateRole(session.getUserEntity());
        UserRoleLink link = session.getUserEntity().getUserRoleLinkList().get(0);
        if (link.getUserRole() == null)
            throw new SberxException(SberxErrors.INVALID_SESSION);
        if (dateDiff(session.getExpiry(), new Date()) <= 5){
            session.setExpiry(getExpiry());
            userSessionRepository.save(session);
        }
        return session.getUserEntity();
    }

    protected UserToken checkToken(String query) {
        Token accessToken = externalService.getAccessToken(query);
        if (accessToken == null || accessToken.getAccessToken() == null || accessToken.getIdToken() == null)
            throw new SberxException(SberxErrors.AUTHORIZATION_FAILED);
        JwtBuilder.JwtPayload payload = jwtBuilder.getJwtPayload(accessToken.getAccessToken());
        JwtBuilder.JwtPayload idPayload = jwtBuilder.getJwtPayload(accessToken.getIdToken());
        if (payload == null || idPayload == null)
            throw new SberxException(SberxErrors.INVALID_SESSION);
        if (payload.getExp() == null)
            throw new SberxException(SberxErrors.INVALID_SESSION, "Empty exp");
        Date exp = getDateFromTimestamp(payload.getExp());
        if (exp.before(new Date()))
            throw new SberxException(SberxErrors.INVALID_SESSION, String.format("Expired exp %s, currentDate %s", exp, new Date()));
        //checkAud(payload.getAud());
        checkAud(idPayload.getAud());
        return new UserToken(accessToken.getAccessToken(), accessToken.getRefreshToken(), exp, payload.getNonce());
    }

    private Date getDateFromTimestamp(Long time){
        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("UTC"));
        cal.setTimeInMillis(time * 1000L);
        return cal.getTime();
    }

    @SuppressWarnings("unchecked")
    private void checkAud(Object aud) {
        if (aud == null)
            throw new SberxException(SberxErrors.INVALID_SESSION, "Empty aud");
        if (!(aud instanceof String) && !(aud instanceof List))
            throw new SberxException(SberxErrors.INVALID_SESSION, "Unexpected aud");
        List<String> audConfigList = Arrays.asList(auds);
        if (aud instanceof String && audConfigList.stream().noneMatch(i -> i.equalsIgnoreCase((String) aud)))
            throw new SberxException(SberxErrors.INVALID_SESSION, "Wrong aud");
        if (aud instanceof List) {
            List<String> audList = (List<String>) aud;
            if (audList.stream().noneMatch(audConfigList::contains))
                throw new SberxException(SberxErrors.INVALID_SESSION, "Wrong aud");
        }
    }

    protected void validateRole(UserEntity userEntity){
        if (userEntity == null)
            throw new SberxException(SberxErrors.INVALID_SESSION);
        if (userEntity.getUserRoleLinkList() == null
                || userEntity.getUserRoleLinkList().size() == 0)
            throw new SberxException(SberxErrors.INVALID_SESSION);
    }

    protected Date getExpiry(){
        return createExpiry(Calendar.MINUTE, customTimeout == null ? sessionTimeout : customTimeout);
    }

    protected Date getPwdExpiry(){
        return createExpiry(Calendar.MINUTE, pwdExpiry);
    }

    protected Date getClientExpiry(){
        return createExpiry(Calendar.YEAR, 20);
    }

    protected Date createExpiry(int latency, Integer timeOut){
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(latency, timeOut*10);
        return cal.getTime();
    }

    private long dateDiff(Date d1, Date d2){
        long diff = d1.getTime() - d2.getTime();
        return TimeUnit.MILLISECONDS.toMinutes(diff);
    }

    protected SessionConfig getConfiguration(String nonce, String clientId){
        SessionConfig config = null;
        if (StringUtils.hasText(nonce))
            config = sessionConfigRepository.findByClientId(nonce);
        if (config == null || config.getClientId() == null) {
            if (StringUtils.hasText(clientId))
                config = sessionConfigRepository.findByClientId(clientId);
        }
        if (config == null)
            throw new SberxException(SberxErrors.CONFIGURATION_NOT_FOUND);
        return config;
    }

    protected void createSession(UserEntity user, AuthRes res, String clientId, String refreshToken, Date exp){
        Integer timeOut = customTimeout == null ? sessionTimeout : customTimeout;
        Long id = user.getUserId();
        if (user.getUserSession() != null)
            userSessionRepository.deleteByUserId(id);

        UserSession session = new UserSession();
        session.setUserId(user.getUserId());
        Date expiry = getExpiry();
        session.setExpiry(expiry);
        session.setSessionId(UUID.randomUUID().toString());
        session.setExp(exp);
        if (StringUtils.hasText(clientId)
                && StringUtils.hasText(refreshToken))
        {
            session.setClientId(clientId);
            session.setRefreshToken(refreshToken);
        }
        UserSession s = userSessionRepository.save(session);
        res.setSessionId(sessionBuilder.encodeSessionId(s.getSessionId()));
        res.setStatus(Status.OK.toString());
        res.setExpiry(expiry);
        res.setTimeOut(timeOut*100);
        res.setPermissions(getPermissions(user));
        res.setLogin(user.getLogin());

        user.setLastEnter(new Date());
        userEntityRepository.save(user);

        applicationDeleteDAORepository.deleteByUserId(id);

        try {
            if (user.getExternalId() != null) {
                Long externalId = user.getExternalId();
                questionaryService.lastEnter(externalId);
            }
        } catch (Exception e) {
            log.error("Error updating last enter time: ", e);
        }
    }

    protected SbUserInfo getInfoFromToken(String token){
        try {
            String[] split = token.split("\\.");
            String s = decodeUrlSafe(split[1].getBytes());
            ObjectMapper mapper = new ObjectMapper();
            mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            return mapper.readValue(s, SbUserInfo.class);
        } catch (JsonProcessingException e){
            return null;
        }
    }

    private String decodeUrlSafe(byte[] data) {
        byte[] encode = Arrays.copyOf(data, data.length);
        for (int i = 0; i < encode.length; i++) {
            if (encode[i] == '-') {
                encode[i] = '+';
            } else if (encode[i] == '_') {
                encode[i] = '/';
            }
        }
        return new String(Base64.getDecoder().decode(encode));
    }

    protected void createClientSession(SbUserInfo info, SessionConfig config, AuthRes res, String refreshToken, Date exp){
        List<UserEntity> userList = userEntityRepository.findBySub(info.getSub());
        UserEntity user = null;
        if (userList != null && userList.size() > 0)
            user = userList.get(0);
        else if (info.getEmail() != null)
            user = userEntityRepository.findByLoginIgnoreCase(info.getEmail());

        if (user == null){
            user = new UserEntity();
            if (user.getPassword() == null || "".equals(user.getPassword()))
                user.setPassword(info.getSub());
            user.setSub(info.getSub());
            user.setLogin(info.getEmail());
            user.setEnters(1);
            user.setNewUser(false);
            user.setDepartmentId("0");
            user.setCreated(new Date());
        }

        List<UserRole> roles = new ArrayList<>();
        if (info.getResourceAccess() != null
                && info.getResourceAccess().getRole() != null
                && !CollectionUtils.isEmpty(info.getResourceAccess().getRole().getRoles())){
            roles = userRoleRepository.findByExternalNameIn(info.getResourceAccess().getRole().getRoles());
        }

        if (!StringUtils.hasText(user.getSub()))
            user.setSub(info.getSub());

        if (user.getUserId() == null)
            userEntityRepository.save(user);

        if (!StringUtils.hasText(info.getSub()) || !info.getSub().equalsIgnoreCase(user.getSub()))
            throw new SberxException(SberxErrors.INVALID_SESSION, String.format("Wrong sub. Received: %s , exists: %s", info.getSub(), user.getSub()));

        List<UserRole> userRoles = userRoleRepository.findByUserId(user.getUserId());
        if (CollectionUtils.isEmpty(roles)) {
            userRoleLinkRepository.deleteByUserId(user.getUserId());
        } else if (CollectionUtils.isEmpty(userRoles)){
            UserRole role = roles.get(0);
            UserRoleLink link = new UserRoleLink();
            link.setUserId(user.getUserId());
            link.setRoleId(role.getRoleId());
            userRoleLinkRepository.save(link);
        } else if (userRoles.stream().noneMatch(roles::contains)) {
            userRoleLinkRepository.deleteByUserId(user.getUserId());
            UserRoleLink link = new UserRoleLink();
            link.setUserId(user.getUserId());
            link.setRoleId(roles.get(0).getRoleId());
            userRoleLinkRepository.save(link);
        }

        customTimeout = config.getSessionTimeout();
        createSession(user, res, config.getClientId(), refreshToken, exp);
    }

    protected String getRandomPassword(){
        PasswordGenerator gen = new PasswordGenerator();
        CharacterData lowerCaseChars = EnglishCharacterData.LowerCase;
        CharacterRule lowerCaseRule = new CharacterRule(lowerCaseChars);
        lowerCaseRule.setNumberOfCharacters(2);

        CharacterData upperCaseChars = EnglishCharacterData.UpperCase;
        CharacterRule upperCaseRule = new CharacterRule(upperCaseChars);
        upperCaseRule.setNumberOfCharacters(2);

        CharacterData digitChars = EnglishCharacterData.Digit;
        CharacterRule digitRule = new CharacterRule(digitChars);
        digitRule.setNumberOfCharacters(2);

        CharacterData specialChars = new CharacterData() {
            public String getErrorCode() {
                return "401";
            }

            public String getCharacters() {
                return "!@#$%^&*()_+";
            }
        };
        CharacterRule splCharRule = new CharacterRule(specialChars);
        splCharRule.setNumberOfCharacters(2);

        return gen.generatePassword(10, splCharRule, lowerCaseRule,
                upperCaseRule, digitRule);
    }

    protected String getHash(String value){
        try {
            return Base64.getEncoder().encodeToString(
                    MessageDigest.getInstance("SHA-1").digest(value.getBytes(StandardCharsets.ISO_8859_1))
            );
        } catch (NoSuchAlgorithmException e){
            log.error("error in saving user ", e);
        }
        return null;
    }

    protected void processExistsClient(String pass, UserEntity entity, Integer type, String clientId){
        entity.setPassword(getHash(pass));
        entity.setEnters(0);
        entity.setNewUser(false);
        if (clientId != null && clientId.equals(defaultClientId)){
            entity.setEnters(1);
            entity.setPassword(defaultPassword);
        }
        entity.setExpiry(getPwdExpiry());
        entity.setWrongAuthCount(0);
        entity.setWrongAuthLock(null);
        entity.setExpireLock(null);
        entity.setUserRole(type);
        userEntityRepository.save(entity);
    }

    protected String generateAndSendPassword(String email, String clientId, String sysName, Long userId){
        if (clientId != null && clientId.equals(defaultClientId))
            return defaultPassword;
        if (email.endsWith("@unity-test.ru"))
            return defaultPassword;
        String pass = getRandomPassword();
        NotifyReq req = new NotifyReq();
        req.setSysName(sysName);
        req.setType(NotifyReq.Types.EMAIL);
        req.setReceiver(email);
        req.setParams(Map.of("password", pass));
        notificationService.notify(req);

        //STARTUPHUB-4019 [БЭК] Центр уведомлений. Добавить сохранение уведомлений во все места, где отправляются письма клиентам
        if (userId != null) {
            NoticeDto noticeReq = new NoticeDto();
            noticeReq.setTemplateSysName(sysName);
            noticeReq.setParams(Map.of("password", "******"));
            noticeReq.setUserId(userId);
            noticeReq.setEvent("Восстановление пароля");
            notificationService.notice(noticeReq);
        }
        return pass;
    }

    protected boolean isInteger(String s) {
        if(s.isEmpty()) return false;
        for(int i = 0; i < s.length(); i++) {
            if(i == 0 && s.charAt(i) == '-') {
                if(s.length() == 1) return false;
                else continue;
            }
            if(Character.digit(s.charAt(i),10) < 0) return false;
        }
        return true;
    }

    protected boolean isTermOfUse(List<UserConsent> consents){
        return !CollectionUtils.isEmpty(consents)
                && consents.stream().anyMatch(i -> i.getSignDttm() != null && i.getTermsId() != null);
    }

    protected void saveConsent(Boolean termsOfUse,
                               Boolean privacyPolicy,
                               Boolean sber500PrivacyPolicy,
                               Boolean sber500Consent,
                               Boolean sber500TermOfUse,
                               Boolean sber500PersonaDataConsent,
                               Boolean mailingConsent,
                               Long userId)
    {
        List<UserConsent> userConsents = userConsentRepository.findByUserId(userId);
        UserConsent us = CollectionUtils.isEmpty(userConsents) ? new UserConsent() : userConsents.get(0);
        us.setUserId(userId);
        us.setSignDttm(new Date());
        List<ConsentMeta> consents = consentMetaRepository.findByRelevant(true);
        if (!CollectionUtils.isEmpty(consents)) {
            consents.forEach(i -> {
                if (Boolean.TRUE.equals(termsOfUse) && TERM_OF_USE.equals(i.getConsentType())) {
                    us.setTermsId(i.getId());
                }
                if (Boolean.TRUE.equals(privacyPolicy) && PRIVACY_POLICY.equals(i.getConsentType())) {
                    us.setPolicyId(i.getId());
                }
                if (Boolean.TRUE.equals(sber500PrivacyPolicy) && SBER500_PRIVACY_POLICY.equals(i.getConsentType())) {
                    us.setSber500PrivacyPolicyId(i.getId());
                }
                if (Boolean.TRUE.equals(sber500Consent) && SBER500_CONSENT.equals(i.getConsentType())) {
                    us.setSber500ConsentId(i.getId());
                }
                if (Boolean.TRUE.equals(sber500TermOfUse) && SBER500_TERM_OF_USE.equals(i.getConsentType())) {
                    us.setSber500TermOfUseId(i.getId());
                }
                if (Boolean.TRUE.equals(sber500PersonaDataConsent) && SBER500_PERSONAL_DATA_CONSENT.equals(i.getConsentType())) {
                    us.setSber500PersonalDataConsentId(i.getId());
                }
                if (Boolean.TRUE.equals(mailingConsent) && MAILING_CONSENT.equals(i.getConsentType())) {
                    us.setMailingConsent(i.getId());
                }
            });
        }
        userConsentRepository.save(us);
    }

    protected List<Permission> getPermissions(UserEntity user){
        List<Permission> permissions = new ArrayList<>();
        List<UserRoleLink> userRoleLinks;
        if (!CollectionUtils.isEmpty(user.getUserRoleLinkList())){
            userRoleLinks = user.getUserRoleLinkList();
        } else {
            userRoleLinks = userRoleLinkRepository.findByUserId(user.getUserId());
        }
        if (!CollectionUtils.isEmpty(userRoleLinks)){
            List<PermissionRoleLink> permissionRoleLinks = permissionRoleLinkRepository.
                    findByRoleIdIn(userRoleLinks.
                            stream().
                            map(UserRoleLink::getRoleId).
                            collect(Collectors.toList()));
            if (!CollectionUtils.isEmpty(permissionRoleLinks)){
                for(PermissionRoleLink i : permissionRoleLinks){
                    permissionsRepository.findById(i.getPermissionId()).ifPresent(x -> permissions.add(x.toDto()));
                }
            }
        }
        return permissions;
    }

    protected UserEntity validateAccessUserExecuteDeleting(AuthReq req) {
        UserEntity user = validateSession(req);
        validateRole(user);
        boolean allowedToDelete = user.getUserRoleLinkList().stream()
                .anyMatch(link -> link.getUserRole() != null && ALLOWED_USERS.contains(link.getUserRole().getRoleSysName()));
        if (!allowedToDelete) {
            throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
        }
        return user;
    }

    @AllArgsConstructor
    @Data
    public static class UserToken {
        private String accessToken;
        private String refreshToken;
        private Date exp;
        private String nonce;
    }

    @AllArgsConstructor
    @Data
    public static class UserExistsError {
        private String title;
        private String description;
        private String message;
        private String buttonText;
        private HttpStatus status;
        private Integer code;
    }

    protected UserExistsError buildUserExistsError(String login){
        String locale = ThreadContext.get(Constants.Header.LOCALE) != null ? ThreadContext.get(Constants.Header.LOCALE) : "ru";
        String title = "ru".equalsIgnoreCase(locale) ? "Вход" : "Log in";
        String description = "ru".equalsIgnoreCase(locale) ? "Участник уже зарегестрирован на платформе" : "User already exists";
        if (StringUtils.hasText(login))
            description = String.format(("ru".equalsIgnoreCase(locale) ? "Участник с электронной почтой **%s** уже зарегестрирован на платформе" : "User **%s** already exists"), login);
        String message = "ru".equalsIgnoreCase(locale) ? "Ссылка больше не действительна" : "Link is not valid";
        String buttonText = "ru".equalsIgnoreCase(locale) ? "На главную" : "Go to the main page";
        return new UserExistsError(title, description, message, buttonText, HttpStatus.BAD_REQUEST, 1025);
    }

    protected void setAppId(UserEntity entity, AuthRes res) {
        DraftReq req = new DraftReq();
        req.setUserId(entity.getExternalId());
        req.setEmail(entity.getLogin());
        req.setSbid("NO_SBB_ID");
        req.setType(entity.getUserRole() != null ? entity.getUserRole() : 0);
        TypeRes draft = questionaryService.draft(req);
        if (draft != null) {
            res.setUuid(draft.getUid());
            res.setType(draft.getType());
            res.setApplicationId(draft.getQuestionnaireId());
        }
//        if (!entity.getUserRole().equals(0)){
//            ApplicationDto application = questionaryService.getApplication(null, entity.getLogin());
//            if (application != null)
//                res.setApplicationId(application.getApplicationId());
//        }
        if (res.getType() == null)
            res.setType(entity.getUserRole());
    }

}
