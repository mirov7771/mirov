package ru.sberx.user.auth.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.support.Permission;
import ru.sberx.user.auth.service.Service;
import ru.sberx.utils.builder.ResponseBuilder;

import java.util.List;

import static ru.sberx.constants.Constants.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("${spring.application.name}/permission")
@RequiredArgsConstructor
public class PermissionController {

    private final Service service;

    @GetMapping(value = "/list", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Permission>> list(){
        return ResponseBuilder.ok(service.getPermissionList());
    }

    @PostMapping(produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Permission> post(@RequestBody Permission req){
        return ResponseBuilder.ok(service.savePermission(req));
    }

    @PutMapping(value = "/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Permission> put(@PathVariable("id") Long id,
                                          @RequestBody Permission req)
    {
        req.setId(id);
        return ResponseBuilder.ok(service.savePermission(req));
    }

    @DeleteMapping(value = "/{id}", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> delete(@PathVariable("id") Long id){
        service.deletePermission(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping(value = "/role", produces = APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> permissionToRole(@RequestBody AuthReq req){
        service.permissionToRole(req);
        return ResponseEntity.ok().build();
    }

}
