package ru.sberx.user.auth.service.impl.method.other;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.notifications.req.NotifyReq;
import ru.sberx.dto.questionary.manage.req.VerifyReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.user.auth.req.ApplicationDeleteReq;
import ru.sberx.unity.gate.notifications.NotificationService;
import ru.sberx.unity.gate.questionary.QuestionaryService;
import ru.sberx.user.auth.dao.model.other.ApplicationDeleteDAO;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.repository.other.ApplicationDeleteDAORepository;
import ru.sberx.user.auth.dao.repository.user.UserEntityRepository;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
@RequiredArgsConstructor
public class ApplicationDeleteMethod {

    private final QuestionaryService questionaryService;
    private final UserEntityRepository userEntityRepository;
    private final ApplicationDeleteDAORepository applicationDeleteDAORepository;
    private final NotificationService notificationService;

    private final DateFormat dateFormat = new SimpleDateFormat("dd.MM.YYYY");

    public void execute(Long userId, String role, ApplicationDeleteReq req) {
        if (!Boolean.TRUE.equals(req.getIsRecovery())) {
            if (!"SuperClient".equalsIgnoreCase(role))
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            TypeRes type = userId != null ? questionaryService.getOneTypeByUserId(userId) : null;
            if (type == null)
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            if (type.getType().equals(1) || (type.getType().equals(2) && !"Бизнес-ангел".equalsIgnoreCase(type.getInvestorType())))
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            UserEntity user = userEntityRepository.findByExternalId(userId);
            if (user == null || CollectionUtils.isEmpty(user.getUserSession()))
                throw new SberxException(SberxErrors.INVALID_SESSION);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, 5);
            applicationDeleteDAORepository.save(new ApplicationDeleteDAO(
                    type.getQuestionnaireId(),
                    user.getUserId(),
                    cal.getTime()
            ));
            callNotify(type, "profileDeletionRq", user.getLogin(), cal.getTime());

            if (type.getChildId() != null) {
                callVerify(type.getChildId(), "Questionnaire", 20004L, null);
            }
            callVerify(type.getQuestionnaireId(), "Questionnaire", 20016L, "Анкета на удаление по инциативе пользователя");
            if (!CollectionUtils.isEmpty(type.getReplyIds()))
                type.getReplyIds().forEach(id -> callVerify(id, "Reply", 20013L, "Отклик отозван при получении заявки на удаление профиля"));
            if (!CollectionUtils.isEmpty(type.getRoundIds()))
                type.getRoundIds().forEach(id -> callVerify(id, "Round", 20013L, "Раунд снят с публикации при получении заявки на удаление профиля"));
            if (!CollectionUtils.isEmpty(type.getCommunityIds()))
                type.getCommunityIds().forEach(id -> callVerify(id, "Community", 20014L, "Профиль на удаление"));
        } else {
            List<ApplicationDeleteDAO> applicationDeleteList = req.getAppId() != null ? applicationDeleteDAORepository.findByApplicationId(req.getAppId()) : null;
            if (CollectionUtils.isEmpty(applicationDeleteList))
                throw new SberxException(SberxErrors.EMPTY_QUERY_RESULT);
            Optional<Long> appUserId = applicationDeleteList.stream().map(ApplicationDeleteDAO::getUserId).findFirst();
            UserEntity user = null;
            if (appUserId.isPresent())
                user = userEntityRepository.findByUserId(appUserId.get());
            if (user == null)
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            List<TypeRes> typeList = questionaryService.getTypeByUserId(user.getExternalId());
            if (CollectionUtils.isEmpty(typeList))
                throw new SberxException(SberxErrors.NOT_ACCEPTABLE_METHOD);
            applicationDeleteDAORepository.deleteByUserId(appUserId.get());
            TypeRes type = typeList.get(0);
            callNotify(type, "restoreProfile", user.getLogin(), null);
            callVerify(type.getQuestionnaireId(), "Questionnaire", 20002L, "Анкета восстановлена по инциативе пользователя");
            if (!CollectionUtils.isEmpty(type.getReplyIds()))
                type.getReplyIds().forEach(id -> callVerify(id, "Reply", 20011L, "Отклик переведен в данный статус при восстановлении профиля"));
            if (!CollectionUtils.isEmpty(type.getRoundIds()))
                type.getRoundIds().forEach(id -> callVerify(id, "Round", 20011L, "Раунд переведен в данный статус при восстановлении профиля"));
        }
    }

    private void callVerify(Long tableId, String tableName, Long state, String comment) {
        VerifyReq verifyReq = new VerifyReq();
        verifyReq.setTableId(tableId);
        verifyReq.setTableName(tableName);
        verifyReq.setState(state);
        verifyReq.setComment(comment);
        questionaryService.verify(verifyReq);
    }

    private void callNotify(TypeRes type, String sysName, String login, Date date) {
        NotifyReq notifyReq = new NotifyReq();
        Map<String, Object> params = new HashMap<>();
        params.put("full_name", type.getFullName());
        params.put("user_name", login);
        if (date != null)
            params.put("deleteDate", dateFormat.format(date));
        notifyReq.setParams(params);
        notifyReq.setSysName(sysName);
        notifyReq.setReceiver(login);
        notifyReq.setType(NotifyReq.Types.EMAIL);
        notificationService.notify(notifyReq);
    }
}
