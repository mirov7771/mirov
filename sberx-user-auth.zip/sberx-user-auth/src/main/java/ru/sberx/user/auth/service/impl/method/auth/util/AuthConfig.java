package ru.sberx.user.auth.service.impl.method.auth.util;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@ConfigurationProperties(prefix = "application.auth")
@Getter @Setter
public class AuthConfig {
    private Map<Integer, Integer> lock;
}
