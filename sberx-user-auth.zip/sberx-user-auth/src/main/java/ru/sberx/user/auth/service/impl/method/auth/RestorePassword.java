package ru.sberx.user.auth.service.impl.method.auth;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sberx.constants.exception.SberxErrors;
import ru.sberx.constants.exception.SberxException;
import ru.sberx.dto.questionary.application.support.ApplicationDto;
import ru.sberx.dto.questionary.questionary.questionary.req.DraftReq;
import ru.sberx.dto.questionary.questionary.questionary.res.TypeRes;
import ru.sberx.dto.user.auth.req.AuthReq;
import ru.sberx.dto.user.auth.res.AuthRes;
import ru.sberx.user.auth.dao.model.user.UserEntity;
import ru.sberx.user.auth.dao.model.user.UserProfile;
import ru.sberx.user.auth.dao.model.user.UserRole;
import ru.sberx.user.auth.dao.model.user.UserRoleLink;

@Component("restore_password")
public class RestorePassword extends AuthService {

    @Value("${application.bad.domains}")
    private String[] badDomains;

    @Override
    public AuthRes execute(AuthReq req) {
        if (req.getEmail() ==  null || "".equals(req.getEmail()))
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: email");

        if (req.getAction() ==  null
                || "".equals(req.getAction())
                || (!"restore".equals(req.getAction())
                && !"registration".equals(req.getAction())))
            throw new SberxException(SberxErrors.MISSING_REQUIRED_PARAMETERS, "Required params: action");

        if ("registration".equals(req.getAction())) {
            for (String s : badDomains) {
                if (req.getEmail().toUpperCase().endsWith("@"+s.toUpperCase()))
                    throw new SberxException(SberxErrors.WRONG_INPUT_EMAIL);
            }
        }

        //Ищем пользователя по email
        UserEntity entity = userEntityRepository.findByLoginIgnoreCase(req.getEmail());
        boolean useOpenId = false;

        //Если пользователь не найден, ищем профиль клиента по email
        if (entity == null){
            UserProfile userInfo = userProfileRepository.findByEmail(req.getEmail());

            //Если профиль найден, ищем УЗ по externalId
            if (userInfo != null && userInfo.getUserId() != null)
                entity = userEntityRepository.findByExternalId(userInfo.getUserId());

            useOpenId = entity != null && entity.getUserId() != null;
        }

        //если действие = сброс пароля и УЗ не найдена или заблокирована, то возвращаем ошибку
        if ("restore".equalsIgnoreCase(req.getAction())){
            if (entity == null || entity.getUserId() == null) {
                //Пользователь не найден
                throw new SberxException(SberxErrors.USER_NOT_FOUND);
            } else if (entity.getWrongAuthLock() != null && entity.getWrongAuthLock().after(new Date())) {
                //Пользователь заблокирован
                throw new SberxException(SberxErrors.USER_BLOCKED);
            }
        }

        //если действие = регистрация и УЗ найдена и не заходили через сббид, то возвращаем ошибку
        if ("registration".equalsIgnoreCase(req.getAction())
                && !Boolean.TRUE.equals(useOpenId)
                && entity != null && entity.getUserId() != null) {
            UserExistsError userExistsError = buildUserExistsError(entity.getLogin());
            throw new SberxException(userExistsError.getDescription(),
                    userExistsError.getCode(),
                    userExistsError.getStatus(),
                    userExistsError.getMessage(),
                    userExistsError.getTitle(), List.of(userExistsError.getDescription()),
                    userExistsError.getButtonText(),
                    "/",
                    null);
        }

        Integer type = (req.getType() == null
                || "".equals(req.getType())
                || !Boolean.TRUE.equals(isInteger(req.getType())))
                ? 0
                : Integer.parseInt(req.getType());
        return process(req.getEmail(), entity, type, req.getClientId(), req.getAction(), req.getTermsOfUse());
    }

    private AuthRes process(String email, UserEntity entity, Integer type, String clientId, String action, Boolean termsOfUse) {
        AuthRes res = new AuthRes();

        //генерим временный пароль и отправляем его на почту
        String pass;
        if ("registration".equalsIgnoreCase(action)) {
            pass = generateAndSendPassword(email, clientId, "NewPassword", entity != null ? entity.getUserId() : null);
        } else {
            pass = generateAndSendPassword(email, clientId, "RestorePassword", entity != null ? entity.getUserId() : null);
        }

        //обрабатываем учетную запись
        if (entity == null || entity.getUserId() == null){
            processNewClient(pass, email, type, clientId, res);
        } else {
            entity.setLogin(email);

            //сбрасываем пароль
            processExistsClient(pass, entity, type, clientId);
            if (Boolean.TRUE.equals(termsOfUse))
                saveConsent(true, true, false, false, false, false, false, entity.getUserId());
        }
        res.setStatus("OK");
        return res;
    }

    private void processNewClient(String pass,
                                  String email,
                                  Integer type,
                                  String clientId,
                                  AuthRes res)
    {
        //создаем профиль клиента
        UserProfile info = new UserProfile();
        info.setEmail(email);
        info.setSbId("NO_SBB_ID");
        userProfileRepository.save(info);

        //создаем УЗ клиента
        UserEntity entity = new UserEntity();
        entity.setPassword(getHash(pass));
        entity.setEnters(0);
        entity.setNewUser(true);
        if (clientId != null && clientId.equals(defaultClientId)){
            entity.setEnters(1);
            entity.setNewUser(true);
            entity.setPassword(defaultPassword);
        }
        entity.setDepartmentId("0");
        entity.setLogin(email);
        entity.setExternalId(info.getUserId());
        entity.setExpiry(getPwdExpiry());
        entity.setWrongAuthCount(0);
        entity.setWrongAuthLock(null);
        entity.setExpireLock(null);
        entity.setUserRole(type);
        entity.setCreated(new Date());
        entity.setMainUser(true);
        userEntityRepository.save(entity);

        //присваеваем роль УЗ
        UserRole role = userRoleRepository.findByRoleSysName("Client");
        UserRoleLink link = new UserRoleLink();
        link.setUserId(entity.getUserId());
        link.setRoleId(role.getRoleId());
        userRoleLinkRepository.save(link);
        saveConsent(true, true, false, false, false, false, false, entity.getUserId());

        setAppId(entity, res);

    }

}
