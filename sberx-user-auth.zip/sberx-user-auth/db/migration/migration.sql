create table user_entity
(
    userid bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    login varchar(50),
    password varchar(150),
    enters smallint,
    departmentid varchar(150),
    externalid bigint
);

create index x1_user_entity on user_entity(login, password);

create table user_session
(
    sessionid bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    userid bigint,
    expiry timestamp
);

create index x1_user_session on user_session(userid);

create table user_role
(
    roleid bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    rolename varchar(100),
    rolesysname varchar(100)
);

insert into user_role(rolename, rolesysname) values('Бизнес-юнит', 'BisunessUnit');
insert into user_role(rolename, rolesysname) values('Администратор', 'Administrator');
insert into user_role(rolename, rolesysname) values('Администратор-Бран', 'AdministratorBran');
insert into user_role(rolename, rolesysname) values('Скаут', 'Scout');
insert into user_role(rolename, rolesysname) values('Клиент', 'Client');
insert into user_role(rolename, rolesysname) values('Супер Клиент', 'SuperClient');

    create table user_role_link
(
    linkid bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    userid bigint,
    roleid bigint
);

create index x1_user_role_link on user_role_link(userid);

create table session_config
(
    clientid varchar(100) PRIMARY KEY,
    sessiontimeout bigint,
    responsetype varchar(100) default 'code',
    scope text null,
    redirecturi varchar(150) null,
    state varchar(150) null,
    clientsecret varchar(150) null,
    granttype varchar(150) null
);

create table delete_info (
    id bigserial primary key,
    fullname varchar,
    comment varchar,
    delete_dttm timestamp
);