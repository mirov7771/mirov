--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3652_2
delete from public.permissions where name like '%syndicate%';
insert into public.permissions (type, name) values ('menu', 'syndicate');
insert into public.permissions (type, name) values ('menu', 'syndicate/requests');
insert into public.permissions (type, name) values ('menu', 'syndicate/operation');

insert into permission_role_link (permission_id, role_id)
select (select roleid from user_role where rolesysname = 'Administrator') , id
from permissions p
where name like '%syndicate%';