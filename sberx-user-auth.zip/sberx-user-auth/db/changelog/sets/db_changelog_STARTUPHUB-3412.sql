--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3412
alter table public.user_entity add column if not exists new_user boolean null default true;
update public.user_entity set new_user = false;