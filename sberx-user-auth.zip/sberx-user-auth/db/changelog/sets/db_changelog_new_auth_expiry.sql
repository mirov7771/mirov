--liquibase formatted sql
--changeset Mirov AA:new_auth
alter table user_entity add expiry timestamp null;