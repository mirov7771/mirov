--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1193
create table role_classify(
    roletype varchar(70) null,
    roleid   bigint
);

create index x1_role_classify on role_classify(roletype, roleid);

insert into role_classify values('unity', (select roleid from user_role where rolesysname = 'Administrator'));
insert into role_classify values('unity', (select roleid from user_role where rolesysname = 'AdministratorBran'));
insert into role_classify values('bran', (select roleid from user_role where rolesysname = 'Scout'));
insert into role_classify values('bran', (select roleid from user_role where rolesysname = 'BusinessUnit'));