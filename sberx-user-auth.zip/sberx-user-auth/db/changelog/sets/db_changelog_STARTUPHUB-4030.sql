--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3546
alter table public.session_config add column if not exists OPENID_URI varchar null;