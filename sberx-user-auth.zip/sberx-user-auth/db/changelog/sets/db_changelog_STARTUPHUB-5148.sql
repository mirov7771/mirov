--liquibase formatted sql
--changeset Leskov-LS:STARTUPHUB-5148
alter table user_entity add column if not exists main_user boolean null default false;
update user_entity set main_user = 'true' where userid in (
    select ue.userid
    from user_entity ue, user_role ur, user_role_link url
    where ue.userid = url.userid and ur.roleid = url.roleid
      and ur.rolesysname in ('Client', 'SuperClient')
);
