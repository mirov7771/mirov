--liquibase formatted sql
--changeset Mirov AA:user_role
alter table user_entity add column user_role smallint null default 0;
