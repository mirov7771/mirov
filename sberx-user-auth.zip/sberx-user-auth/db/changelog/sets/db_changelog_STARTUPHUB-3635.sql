--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3635
drop table if exists permissions;
create table permissions
(
    id bigserial primary key,
    type varchar not null,
    name varchar not null
);

drop table if exists permission_role_link;
create table permission_role_link
(
    id bigserial primary key,
    permission_id bigint null,
    role_id bigint null
);

create index x1_permission_role_link on permission_role_link(permission_id);
create index x2_permission_role_link on permission_role_link(role_id);