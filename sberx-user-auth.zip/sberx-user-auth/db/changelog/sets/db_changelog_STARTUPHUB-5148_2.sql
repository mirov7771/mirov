--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5148_2
delete from api_access_rights where id in (615, 616);
insert into api_access_rights values(615, 'GET', '/companyuser/list', null);
insert into api_access_rights values(616, 'POST', '/companyuser', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (615, 616);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Client'), id
from api_access_rights
where id in (615, 616);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));