--liquibase formatted sql
--changeset Timofeev V V:STARTUPHUB-2395
alter table public.user_session add column if not exists clientid varchar(100);