--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4531
create table if not exists application_delete
(
    application_id bigint,
    user_id bigint,
    date timestamp
);

create index x1_application_delete on application_delete(user_id);
create index x2_application_delete on application_delete(user_id, date);