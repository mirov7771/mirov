--liquibase formatted sql
--changeset Mirov AA:new_auth
insert into role_classify values('client', (select roleid from user_role where rolesysname = 'Client'));
insert into role_classify values('client', (select roleid from user_role where rolesysname = 'SuperClient'));

alter table user_entity add sub varchar(255) null;