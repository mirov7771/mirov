--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4918
delete from api_access_rights where id in (606, 607, 608);
insert into api_access_rights values(606, 'GET', '/company', null);
insert into api_access_rights values(607, 'GET', '/company/list', null);
insert into api_access_rights values(608, 'POST', '/add-activity', null);


insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (606, 607, 608);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Client'), id
from api_access_rights
where id in (606, 607, 608);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));