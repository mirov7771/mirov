--liquibase formatted sql
--changeset Mirov AA:format_phone
create or replace function formatPhone(phone varchar) returns varchar
language plpgsql
as
$$
declare
return_phone varchar;
begin
select case when length(replace(replace(replace(replace(replace(phone,'+', ''), ' ',''),'(',''),')',''), '-', '')) > 10
                then substring(replace(replace(replace(replace(replace(phone,'+', ''), ' ',''),'(',''),')',''), '-', ''), length(replace(replace(replace(replace(replace(phone,'+', ''), ' ',''),'(',''),')',''), '-', '')) - 9, 10)
            else replace(replace(replace(replace(replace(phone,'+', ''), ' ',''),'(',''),')',''), '-', '') end
into return_phone;

return return_phone;
end;
$$;
