--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4568
delete from api_access_rights where id in (599, 600, 601, 602);
insert into api_access_rights values(599, 'GET', '/metric', null);
insert into api_access_rights values(600, 'GET', '/metrics', null);
insert into api_access_rights values(601, 'POST', '/metric', null);
insert into api_access_rights values(602, 'DELETE', '/metric', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (599, 600, 601, 602);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Client'), id
from api_access_rights
where id in (599, 600, 601, 602);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));