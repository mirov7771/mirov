--liquibase formatted sql
--changeset Mirov AA:SBERXTECH-277
alter table user_entity add wrong_auth_count bigint null default 0;
alter table user_entity add wrong_auth_lock timestamp null;
alter table user_entity add expire_lock timestamp null;

update user_entity
set sub = password
where login not like '%@%';