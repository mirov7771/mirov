--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3546
alter table public.user_entity add column if not exists reports_use boolean null default true;

update public.user_entity
set reports_use = true
where lower(login) = 'avitabelov@omega.sbrf.ru';