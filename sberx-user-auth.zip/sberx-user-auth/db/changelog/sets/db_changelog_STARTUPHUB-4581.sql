--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4581
alter table user_entity add column if not exists lastenter timestamp null;