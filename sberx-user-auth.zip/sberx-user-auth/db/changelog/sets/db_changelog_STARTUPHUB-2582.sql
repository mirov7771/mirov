--liquibase formatted sql
--changeset Timoshkin MA:STARTUPHUB-2582
create table delete_info (
    id bigserial primary key,
    fullname varchar,
    comment varchar,
    delete_dttm timestamp
);