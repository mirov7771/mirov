--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3652
delete from public.user_role where rolesysname = 'SberbankEmployee';

select setval('public.user_role_roleid_seq',  (SELECT max(roleid)+1 FROM public.user_role ur));
insert into public.user_role (rolename, rolesysname) values('Сотрудник Сбербанка', 'SberbankEmployee');


delete from public.user_role_link url where userid = (select userid from public.user_entity ue where login = 'AEVoynolovich@sberbank.ru');

select setval('public.user_role_link_linkid_seq',  (SELECT max(linkid)+1 FROM public.user_role_link ur));

insert into public.user_role_link (userid, roleid)
values ((select userid from public.user_entity ue where login = 'AEVoynolovich@sberbank.ru'), (select roleid from user_role where rolesysname = 'SberbankEmployee'));


insert into public.role_classify
values ('unity', (select roleid from user_role where rolesysname = 'SberbankEmployee'));

delete from permissions;

insert into permissions (type, name) values ('menu', 'vas');
insert into permissions (type, name) values ('menu', 'requests/corp');
insert into permissions (type, name) values ('menu', 'requests/invest');
insert into permissions (type, name) values ('menu', 'questionnaire/startup');
insert into permissions (type, name) values ('menu', 'questionnaire/corporate');
insert into permissions (type, name) values ('menu', 'questionnaire/investor');
insert into permissions (type, name) values ('menu', 'pilot');
insert into permissions (type, name) values ('menu', 'invest');
insert into permissions (type, name) values ('menu', 'community');
insert into permissions (type, name) values ('menu', 'statistics');
insert into permissions (type, name) values ('menu', 'syndicate');

delete from permission_role_link;

insert into permission_role_link (role_id, permission_id)
select (select roleid from user_role where rolesysname = 'Administrator') , id
from permissions p;

insert into permission_role_link (role_id, permission_id)
select (select roleid from user_role where rolesysname = 'SberbankEmployee') , id
from permissions p
where name = 'community';