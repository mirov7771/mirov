--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4336_3
delete
from permission_role_link
where role_id in (
    select roleid
    from user_role ur
    where rolesysname = 'SberbankEmployee'
);

insert into permission_role_link (permission_id, role_id)
values ((select id
         from permissions p
         where name = 'questionnaire/startup'),
        (select roleid
         from user_role ur
         where rolesysname = 'SberbankEmployee'));

insert into permission_role_link (permission_id, role_id)
values ((select id
         from permissions p
         where name = 'community'),
        (select roleid
         from user_role ur
         where rolesysname = 'SberbankEmployee'));

delete from role_access_link
where role_id in (
    select roleid
    from user_role ur
    where rolesysname = 'SberbankEmployee'
);

delete from api_access_rights where id in (597);
insert into api_access_rights values(597, 'GET', '/questionary', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SberbankEmployee'), id
from api_access_rights
where id in (3, 60, 11, 22, 66, 81, 71, 82, 597);