--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3404
drop table if exists CONSENT_META;
CREATE TABLE CONSENT_META (
   id bigserial NOT NULL primary key,
   relevant bool NOT NULL,
   CONSENT_TEXT varchar NULL,
   CONSENT_URL varchar(150) NULL,
   CONSENT_NAME varchar(150) NOT NULL,
   CONSENT_TYPE varchar(150) NOT NULL
);

create index x1_consent_meta on CONSENT_META(relevant);
create index x2_consent_meta on CONSENT_META(relevant, CONSENT_TYPE);

INSERT INTO public.CONSENT_META (relevant, CONSENT_URL, CONSENT_NAME, CONSENT_TYPE)
VALUES(true, 'https://sberunity.ru/sberx-gateway/file/politics_1.pdf', 'Политика конфиденциальности сервиса «онлайн-платформа SberUnity»', 'privacy_policy');
INSERT INTO public.CONSENT_META (relevant, CONSENT_URL, CONSENT_NAME, CONSENT_TYPE)
VALUES(true, 'https://sberunity.ru/sberx-gateway/file/politics_2.pdf', 'ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ', 'term_of_use');

INSERT INTO public.CONSENT_META (relevant, CONSENT_URL, CONSENT_NAME, CONSENT_TYPE)
VALUES(true, 'https://sberunity.ru/sberx-gateway/file/sber500_privacy_policy.pdf', 'Политика конфедициальности sber500', 'sber500_privacy_policy');
INSERT INTO public.CONSENT_META (relevant, CONSENT_URL, CONSENT_NAME, CONSENT_TYPE)
VALUES(true, 'https://sberunity.ru/sberx-gateway/file/sber500_consent.pdf', 'Ссылка на согласие на участие в продукте Акселератор Сбера', 'sber500_consent');
INSERT INTO public.CONSENT_META (relevant, CONSENT_URL, CONSENT_NAME, CONSENT_TYPE)
VALUES(true, 'https://sberunity.ru/sberx-gateway/file/sber500_term_of_use.pdf', 'Ссылка на согласие c Правилами участия в программе Sber500', 'sber500_term_of_use');
INSERT INTO public.CONSENT_META (relevant, CONSENT_URL, CONSENT_NAME, CONSENT_TYPE)
VALUES(true, 'https://sberunity.ru/sberx-gateway/file/sber500_personal_data_consent.pdf', 'Политикой в области обработки и защиты персональных данных', 'sber500_personal_data_consent');

drop table if exists privacy_policy;
drop table if exists terms_of_use;
