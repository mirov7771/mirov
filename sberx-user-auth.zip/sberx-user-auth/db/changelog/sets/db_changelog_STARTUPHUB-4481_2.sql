--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4481_2
insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Unauthorized'), id
from api_access_rights
where id in (598);
