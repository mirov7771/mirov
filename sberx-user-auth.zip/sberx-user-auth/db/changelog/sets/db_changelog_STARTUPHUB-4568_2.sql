--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4568_2
update api_access_rights set action = '/metric/list' where id = 600;