--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2187
create index x2_user_session on user_session(sessionid, expiry);
create index x3_user_session on user_session(expiry);

create index x3_user_entity on user_entity (upper(login), password);