--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-5379
update user_role set rolesysname = 'CorpLight', rolename = 'Light' where rolesysname = 'CorpDemo';
update user_role set rolesysname = 'InvestLight', rolename = 'Light' where rolesysname = 'InvestDemo';