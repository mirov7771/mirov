--liquibase formatted sql
--changeset Zakutskiy MY:role_access_link_new_roles
delete from role_access_link ral where ral.role_id in (select ur.roleid
                                                       from user_role ur
                                                       where ur.rolesysname in ('CorpLight', 'InvestLight', 'CorpPro', 'InvestPro', 'InvestAngel', 'CorpProPlus'));

select setval('role_access_link_id_seq',  (SELECT max(id)+1 FROM role_access_link));

insert into role_access_link (role_id, access_id)
select (select ur2.roleid as role_id from user_role ur2 where ur2.rolesysname = 'CorpLight'),
       accessTab.access_id from (select ral.access_id as access_id from role_access_link ral where ral.role_id = (select ur.roleid from user_role ur where ur.rolesysname = 'SuperClient')) as accessTab;

insert into role_access_link (role_id, access_id)
select (select ur2.roleid as role_id from user_role ur2 where ur2.rolesysname = 'InvestLight'),
       accessTab.access_id from (select ral.access_id as access_id from role_access_link ral where ral.role_id = (select ur.roleid from user_role ur where ur.rolesysname = 'SuperClient')) as accessTab;

insert into role_access_link (role_id, access_id)
select (select ur2.roleid as role_id from user_role ur2 where ur2.rolesysname = 'CorpPro'),
       accessTab.access_id from (select ral.access_id as access_id from role_access_link ral where ral.role_id = (select ur.roleid from user_role ur where ur.rolesysname = 'SuperClient')) as accessTab;

insert into role_access_link (role_id, access_id)
select (select ur2.roleid as role_id from user_role ur2 where ur2.rolesysname = 'InvestPro'),
       accessTab.access_id from (select ral.access_id as access_id from role_access_link ral where ral.role_id = (select ur.roleid from user_role ur where ur.rolesysname = 'SuperClient')) as accessTab;

insert into role_access_link (role_id, access_id)
select (select ur2.roleid as role_id from user_role ur2 where ur2.rolesysname = 'InvestAngel'),
       accessTab.access_id from (select ral.access_id as access_id from role_access_link ral where ral.role_id = (select ur.roleid from user_role ur where ur.rolesysname = 'SuperClient')) as accessTab;

insert into role_access_link (role_id, access_id)
select (select ur2.roleid as role_id from user_role ur2 where ur2.rolesysname = 'CorpProPlus'),
       accessTab.access_id from (select ral.access_id as access_id from role_access_link ral where ral.role_id = (select ur.roleid from user_role ur where ur.rolesysname = 'SuperClient')) as accessTab;
