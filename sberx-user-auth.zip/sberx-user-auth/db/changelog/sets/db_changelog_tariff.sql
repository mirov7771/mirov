--liquibase formatted sql
--changeset Leskov-LS:user_roles_tariff
delete from user_role where (rolesysname like 'Corp%') or (rolesysname like 'Invest%');

INSERT INTO public.user_role (rolename,rolesysname,external_name) VALUES ('Pro Plus','CorpProPlus',NULL);
INSERT INTO public.user_role (rolename,rolesysname,external_name) VALUES ('Pro Бизнес-ангел','InvestAngel',NULL);
INSERT INTO public.user_role (rolename,rolesysname,external_name) VALUES ('Pro Фонд','InvestPro',NULL);
INSERT INTO public.user_role (rolename,rolesysname,external_name) VALUES ('Demo','CorpDemo',NULL);
INSERT INTO public.user_role (rolename,rolesysname,external_name) VALUES ('Pro','CorpPro',NULL);
INSERT INTO public.user_role (rolename,rolesysname,external_name) VALUES ('Demo','InvestDemo',NULL);