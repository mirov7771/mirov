--liquibase formatted sql
--changeset Timofeev V V:STARTUPHUB-2875
alter table public.user_session add column if not exists refresh_token text null;