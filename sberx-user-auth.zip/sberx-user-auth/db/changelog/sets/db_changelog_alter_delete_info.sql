--liquibase formatted sql
--changeset Timoshkin MA:alter_delete_info
alter table delete_info add column userid bigint not null default 0;
alter table delete_info add column questionnaireid bigint not null default 0;
