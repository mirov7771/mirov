--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4365
alter table public.user_consent add column if not exists mailing_consent bigint null;