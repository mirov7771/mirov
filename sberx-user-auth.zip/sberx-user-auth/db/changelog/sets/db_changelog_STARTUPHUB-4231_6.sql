--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4231_6
delete from api_access_rights where id in (91, 92);
insert into api_access_rights values(91, 'GET', '/partner', null);
insert into api_access_rights values(92, 'POST', '/partner', null);
insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Unauthorized'), id
from api_access_rights
where id in (91,92);
select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));