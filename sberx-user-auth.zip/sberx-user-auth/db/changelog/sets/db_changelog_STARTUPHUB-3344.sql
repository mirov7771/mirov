--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3344
drop table if exists privacy_policy;
CREATE TABLE privacy_policy (
  policyid bigserial NOT NULL,
  relevant bool NOT NULL,
  policytext varchar NULL,
  policyurl varchar(150) NULL,
  policyname varchar(150) NOT NULL,
  CONSTRAINT policy_pkey PRIMARY KEY (policyid)
);

drop table if exists terms_of_use;
CREATE TABLE terms_of_use (
  termsid bigserial NOT NULL,
  relevant bool NOT NULL,
  termstext varchar NULL,
  termsurl varchar(150) NULL,
  termsname varchar(150) NOT NULL,
  CONSTRAINT terms_pkey PRIMARY KEY (termsid)
);

drop table if exists user_consent;
CREATE TABLE user_consent (
  userid int8 NOT NULL,
  termsid int8 NULL,
  policyid int8 NULL,
  signdttm timestamp NULL,
  CONSTRAINT user_consent_pkey PRIMARY KEY (userid)
);

INSERT INTO public.privacy_policy
(policyid, relevant, policytext, policyurl, policyname)
VALUES(1, true, NULL, 'https://sberunity.ru/sberx-gateway/file/politics_1.pdf', 'Политика конфиденциальности сервиса «онлайн-платформа SberUnity»');

INSERT INTO public.terms_of_use
(termsid, relevant, termstext, termsurl, termsname)
VALUES(1, true, NULL, 'https://sber-unity.ru/sberx-gateway/file/politics_2.pdf', 'ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ');

drop table if exists user_profile;
CREATE TABLE user_profile (
  userid bigserial NOT NULL,
  sberbusinessid varchar(150) NOT NULL,
  "name" varchar(200) NULL,
  inn varchar(15) NULL,
  kpp varchar(15) NULL,
  orgname varchar(255) NULL,
  ogrn varchar(50) NULL,
  okpo varchar(50) NULL,
  oktmo varchar(50) NULL,
  factaddress varchar(255) NULL,
  juraddress varchar(255) NULL,
  email varchar(100) NULL,
  phonenumber varchar(20) NULL,
  "position" varchar(170) NULL,
  roles varchar(255) NULL,
  CONSTRAINT user_pkey PRIMARY KEY (userid)
);
CREATE INDEX x1_user_profiler ON public.user_profile USING btree (sberbusinessid);
CREATE INDEX x2_user_profile ON public.user_profile USING btree (email);
CREATE INDEX x3_user_profile ON public.user_profile USING btree (inn);
CREATE INDEX x4_user_profile ON public.user_profile USING btree (userid);
CREATE INDEX x5_user_profile ON public.user_profile USING btree (orgname);
CREATE INDEX x6_user_profile ON public.user_profile USING btree (userid, sberbusinessid);

insert into user_profile (email, sberbusinessid)
select distinct login, 'NO_SBB_ID'
from public.user_entity;