--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3968_8
insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Client'), id
from api_access_rights
where id in (71);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SyndicateUser'), id
from api_access_rights
where id in (71);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SberbankEmployee'), id
from api_access_rights
where id in (71);
