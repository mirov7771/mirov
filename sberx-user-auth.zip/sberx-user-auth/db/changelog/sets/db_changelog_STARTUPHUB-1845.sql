--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-1845

INSERT INTO public.user_entity
(login, "password", enters, departmentid, externalid)
VALUES('AVitaBelov@omega.sbrf.ru', '+A6XB/B9tzv2uiV3KR1Uovkw7Jo=', 1, '11', NULL);