--liquibase formatted sql
--changeset Mirov AA:scouting
delete from public.permissions where name = 'scouting';

insert into public.permissions (type, name)
values ('menu', 'scouting');

insert into public.permission_role_link(permission_id, role_id)
values((select id from permissions where name = 'scouting'), (select roleid from public.user_role ur where rolesysname = 'Administrator'))