--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4293
insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Client'), id
from api_access_rights
where id in (52);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (52);
