--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-2766
delete from public.session_config where clientid = 'sberunity';

insert into session_config
values('sberunity',
       1800,
       'code',
       'openid personal_info email phone roles',
       'https://startuphubadmin-ci03048693-etestenab-sberunity-dev.apps.test.enablers.sbrf.ru/auth',
       'af0ifjsldkj',
       'dc2635ef-0749-4864-bd14-1bbb240c6699',
       'authorization_code');