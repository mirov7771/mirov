--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3968_5
alter table public.user_role add column if not exists external_name varchar null;

create index x_external_name on user_role(external_name);

update user_role
set external_name = 'sberunity_admin'
where rolesysname = 'Administrator';

update user_role
set external_name = 'sberunity_community'
where rolesysname = 'SberbankEmployee';