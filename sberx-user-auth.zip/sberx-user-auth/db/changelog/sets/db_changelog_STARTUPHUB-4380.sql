--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4380
delete from consent_meta where consent_type = 'mailing_consent';
insert into consent_meta (id, relevant, consent_url, consent_name, consent_type)
values (100, true, 'https://sberunity.ru/sberx-gateway/file/mailingconsent.pdf', 'Согласие на рассылку', 'mailing_consent');