--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4884
drop table if exists user_password;
create table user_password (
    userid bigint,
    password varchar,
    date timestamp
);

create index x1_user_password on user_password(userid);
