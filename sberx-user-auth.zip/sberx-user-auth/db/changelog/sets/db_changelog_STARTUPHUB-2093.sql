--liquibase formatted sql
--changeset Molotkov DE:STARTUPHUB-2093 добавление роли администратора

DELETE FROM public.user_role_link WHERE userid = (select  userid from public.user_entity where login = 'AVitaBelov@omega.sbrf.ru');



insert into public.user_role_link(userid,roleid)
    values((select  userid from public.user_entity where login = 'AVitaBelov@omega.sbrf.ru'),(select roleid from public.user_role where rolesysname = 'Administrator'));
