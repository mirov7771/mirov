--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3546
alter table public.user_entity add column if not exists created timestamp null default current_date;