--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-1101
truncate table user_session;
alter table user_session drop column sessionid;
alter table user_session add column sessionid varchar(255) not null;
alter table user_session add column id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY;