--liquibase formatted sql
--changeset Leskov-LS:NT Tuning
CREATE INDEX IF NOT EXISTS idx_externalid on user_entity(externalid);