--liquibase formatted sql
--changeset Zakutskiy MY:role_classify_new_roles
delete from role_classify rc
where rc.roleid in (select ur.roleid
                    from user_role ur
                    where ur.rolesysname in ('CorpLight', 'InvestLight', 'CorpPro', 'InvestPro', 'InvestAngel', 'CorpProPlus'));

insert into role_classify(roletype, roleid)
select 'client', ur.roleid
from user_role ur
where ur.rolesysname in ('CorpLight', 'InvestLight', 'CorpPro', 'InvestPro', 'InvestAngel', 'CorpProPlus');