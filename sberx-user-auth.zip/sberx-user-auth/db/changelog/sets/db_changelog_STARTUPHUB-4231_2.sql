--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4231_2
delete from api_access_rights where id = 75;
insert into api_access_rights values(75, 'GET', '/round', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (75);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));