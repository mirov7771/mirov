--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4610
delete from api_access_rights where id in (611);
insert into api_access_rights values(611, 'DELETE', '/application-delete', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (611);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Unauthorized'), id
from api_access_rights
where id in (611);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));