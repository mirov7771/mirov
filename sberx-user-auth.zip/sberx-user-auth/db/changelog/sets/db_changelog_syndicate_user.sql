--liquibase formatted sql
--changeset Mirov AA:syndicate_user
delete from public.user_role where rolesysname = 'SyndicateUser';

select setval('public.user_role_roleid_seq',  (SELECT max(roleid)+1 FROM public.user_role ur));
insert into public.user_role (rolename, rolesysname) values('Пользователь Синдиката', 'SyndicateUser');

insert into public.role_classify
values ('client', (select roleid from user_role where rolesysname = 'SyndicateUser'));