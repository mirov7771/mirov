--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3968
select setval('public.user_role_roleid_seq',  (SELECT max(roleid)+1 FROM public.user_role ur));
insert into user_role(rolename, rolesysname)
values ('Неавторизованный пользователь', 'Unauthorized');

drop table if exists api_access_rights;
create table api_access_rights(
                                  id bigserial,
                                  method varchar null,
                                  action varchar null,
                                  params varchar null
);

drop table if exists role_access_link;
create table role_access_link(
                                 id bigserial,
                                 role_id bigint,
                                 access_id bigint
);