--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3968_2
drop table if exists api_access_rights;
create table api_access_rights(
                                  id bigserial primary key,
                                  method varchar null,
                                  action varchar null,
                                  params varchar null
);

drop table if exists role_access_link;
create table role_access_link(
                                 id bigserial primary key,
                                 role_id bigint,
                                 access_id bigint
);

create index x1_role_access_link on role_access_link(role_id);

insert into api_access_rights values(1, 'GET', '/structure/pages', null);
insert into api_access_rights values(2, 'GET', '/features', null);
insert into api_access_rights values(3, 'GET', '/v2/list', 'type=0');
insert into api_access_rights values(4, 'GET', '/v2/list', 'type=1');
insert into api_access_rights values(5, 'GET', '/v2/list', 'type=2');
insert into api_access_rights values(6, 'GET', '/v2/list', 'type=4');
insert into api_access_rights values(7, 'GET', '/view', 'type=0&preauthorize=true&action=1');
insert into api_access_rights values(8, 'GET', '/view', 'type=1&preauthorize=true&action=1');
insert into api_access_rights values(9, 'GET', '/view', 'type=2&preauthorize=true&action=1');
insert into api_access_rights values(10, 'GET', '/view', 'type=3&preauthorize=true&action=1');
insert into api_access_rights values(11, 'GET', '/file', null);
insert into api_access_rights values(12, 'GET', '/guide', null);
insert into api_access_rights values(13, 'POST', '/community', null);
insert into api_access_rights values(14, 'GET', '/vas/list', null);
insert into api_access_rights values(15, 'POST', '/restore-password', null);
insert into api_access_rights values(16, 'POST', '/application', null);
insert into api_access_rights values(17, 'POST', '/auth/client', null);
insert into api_access_rights values(18, 'POST', '/auth/unity', null);
insert into api_access_rights values(36, 'GET', '/preauthorize', null);
insert into api_access_rights values(50, 'GET', '/view', 'type=1&action=2&name=New_Corporate_Short');
insert into api_access_rights values(51, 'GET', '/view', 'type=2&action=2&name=New_Investor_Short');
insert into api_access_rights values(52, 'GET', '/view-card', null);
insert into api_access_rights values(58, 'POST', '/syndicate', null);
insert into api_access_rights values(64, 'GET', '/search', null);
insert into api_access_rights values(65, 'GET', '/smart-search', null);
insert into api_access_rights values(68, 'GET', '/faq/list', null);

insert into api_access_rights values(19, 'GET', '/workspace/client', null);
insert into api_access_rights values(20, 'GET', '/syndicate/list', null);
insert into api_access_rights values(21, 'GET', '/view', 'type=12');
insert into api_access_rights values(22, 'POST', '/logout', null);

insert into api_access_rights values(23, 'GET', '/v2/popup', null);
insert into api_access_rights values(24, 'GET', '/popup', null);
insert into api_access_rights values(25, 'GET', '/onboarding', null);
insert into api_access_rights values(26, 'GET', '/list/round', null);
insert into api_access_rights values(27, 'GET', '/view', 'type=10');
insert into api_access_rights values(28, 'GET', '/view', 'type=7');
insert into api_access_rights values(29, 'GET', '/view', 'type=3');
insert into api_access_rights values(30, 'GET', '/view', 'type=4');
insert into api_access_rights values(31, 'POST', '/questionary', null);
insert into api_access_rights values(32, 'POST', '/pilot', null);
insert into api_access_rights values(33, 'POST', '/reply', null);
insert into api_access_rights values(34, 'POST', '/file', null);
insert into api_access_rights values(35, 'GET', '/v2/list', 'type=7');
insert into api_access_rights values(42, 'PUT', '/add-favorite', null);
insert into api_access_rights values(43, 'POST', '/round', null);
insert into api_access_rights values(44, 'PUT', '/round', null);
insert into api_access_rights values(45, 'POST', '/community', null);
insert into api_access_rights values(46, 'PUT', '/questionary', null);
insert into api_access_rights values(47, 'POST', '/onboarding/status', null);
insert into api_access_rights values(48, 'POST', '/onboarding', null);
insert into api_access_rights values(49, 'GET', '/v2/files/', null);
insert into api_access_rights values(53, 'GET', '/link', null);
insert into api_access_rights values(54, 'PUT', '/notice/watched', null);
insert into api_access_rights values(55, 'GET', '/notice/list', null);
insert into api_access_rights values(56, 'GET', '/notice', null);
insert into api_access_rights values(57, 'GET', '/menu', null);
insert into api_access_rights values(59, 'PUT', '/community', null);
insert into api_access_rights values(60, 'GET', '/view', 'type=0');
insert into api_access_rights values(61, 'GET', '/view', 'type=1');
insert into api_access_rights values(62, 'GET', '/view', 'type=2');
insert into api_access_rights values(63, 'GET', '/view', 'type=3');
insert into api_access_rights values(66, 'GET', '/community', null);
insert into api_access_rights values(67, 'POST', '/feedback', null);

insert into api_access_rights values(37, 'GET', '**', null);
insert into api_access_rights values(38, 'POST', '**', null);
insert into api_access_rights values(39, 'PUT', '**', null);
insert into api_access_rights values(40, 'DELETE', '**', null);
insert into api_access_rights values(41, 'PATCH', '**', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Unauthorized'), id
from api_access_rights
where id in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18, 36, 49, 50, 51, 52, 58, 64, 65, 68);


insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SyndicateUser'), id
from api_access_rights
where id in (19, 2, 11, 20, 21, 22);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (19, 2, 11, 12, 22, 3, 4, 5, 6, 14, 1, 13, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 42, 43, 44, 45, 46, 47, 48, 49, 53, 54, 55, 56, 57, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Administrator'), id
from api_access_rights
where id in (37, 38, 39, 40, 41);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Client'), id
from api_access_rights
where id in (19, 2, 11, 12, 22, 3, 4, 5, 6, 14, 1, 13, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 42, 43, 44, 45, 46, 47, 48, 49, 53, 54, 55, 56, 57, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));