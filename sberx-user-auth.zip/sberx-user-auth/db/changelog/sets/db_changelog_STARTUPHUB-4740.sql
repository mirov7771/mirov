--liquibase formatted sql
--changeset Zakutskiy MY:STARTUPHUB-4740
delete from api_access_rights where id in (604);
insert into api_access_rights values(604, 'GET', '/audit', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'Administrator'), id
from api_access_rights
where id in (604);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));