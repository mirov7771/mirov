--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-3217
alter table public.user_entity add column if not exists phone varchar null;
alter table public.user_entity add column if not exists phone_verified boolean null default false;
alter table public.user_entity add column if not exists otp varchar null;

create index x5_user_entity on user_entity(phone);