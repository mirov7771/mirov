--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4289
alter table USER_SESSION add column if not exists EXP timestamp null;