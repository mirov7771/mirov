--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4422
insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SyndicateUser'), id
from api_access_rights
where id in (71);