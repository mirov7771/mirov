--liquibase formatted sql
--changeset Mirov AA:STARTUPHUB-4231_3
delete from api_access_rights where id in (77, 78, 79, 80);
insert into api_access_rights values(77, 'GET', '/comment', null);
insert into api_access_rights values(78, 'PUT', '/comment', null);
insert into api_access_rights values(79, 'POST', '/comment', null);
insert into api_access_rights values(80, 'DELETE', '/comment', null);

insert into role_access_link (role_id, access_id)
select
    (select roleid
     from public.user_role ur
     where rolesysname = 'SuperClient'), id
from api_access_rights
where id in (77,78,79,80);

select setval('public.api_access_rights_id_seq',  (SELECT max(id)+1 FROM public.api_access_rights));