--liquibase formatted sql
--changeset Mirov AA:USER_CONSENT
alter table public.USER_CONSENT add column if not exists SBER_500_PRIVACY_POLICY_ID bigint null;
alter table public.USER_CONSENT add column if not exists SBER_500_CONSENT_ID bigint null;
alter table public.USER_CONSENT add column if not exists SBER_500_TERM_OF_USE_ID bigint null;
alter table public.USER_CONSENT add column if not exists SBER_500_PERSONAL_DATA_CONSENT_ID bigint null;

drop table if exists user_profile;
CREATE TABLE user_profile (
  userid bigserial NOT NULL,
  sberbusinessid varchar(150) NOT NULL,
  "name" varchar(200) NULL,
  inn varchar(15) NULL,
  kpp varchar(15) NULL,
  orgname varchar(255) NULL,
  ogrn varchar(50) NULL,
  okpo varchar(50) NULL,
  oktmo varchar(50) NULL,
  factaddress varchar(255) NULL,
  juraddress varchar(255) NULL,
  email varchar(100) NULL,
  phonenumber varchar(20) NULL,
  "position" varchar(170) NULL,
  roles varchar(255) NULL,
  CONSTRAINT user_pkey PRIMARY KEY (userid)
);
CREATE INDEX x1_user_profiler ON public.user_profile USING btree (sberbusinessid);
CREATE INDEX x2_user_profile ON public.user_profile USING btree (email);
CREATE INDEX x3_user_profile ON public.user_profile USING btree (inn);
CREATE INDEX x4_user_profile ON public.user_profile USING btree (userid);
CREATE INDEX x5_user_profile ON public.user_profile USING btree (orgname);
CREATE INDEX x6_user_profile ON public.user_profile USING btree (userid, sberbusinessid);

insert into user_profile (userid, email, sberbusinessid) OVERRIDING SYSTEM VALUE
select externalid, max(login), 'NO_SBB_ID'
from public.user_entity
where externalid is not null
group by externalid;

select setval('public.user_profile_userid_seq',  (SELECT max(userid)+1 FROM public.user_profile));