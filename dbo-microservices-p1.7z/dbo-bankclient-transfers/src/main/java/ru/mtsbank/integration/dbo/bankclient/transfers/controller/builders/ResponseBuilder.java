package ru.mtsbank.integration.dbo.bankclient.transfers.controller.builders;

import org.springframework.http.ResponseEntity;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;

public class ResponseBuilder {

    public static ResponseEntity<BaseResponse> build(BaseResponse data){
        if (data.getErrorResponse() == null || data.getErrorResponse().getError() == null) {
            return ResponseEntity.ok(data);
        } else {
            return ResponseEntity.status(data.getErrorResponse().getError().getHttpCode()).body(data.getErrorResponse());
        }
    }

}
