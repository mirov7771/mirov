package ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.*;
import ru.mtsbank.integration.dbo.bankclient.transfers.builders.TransferBuilder;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.CheckTransferReq;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.CheckTransferRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport.Source;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport.Target;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport.TransferParams;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.TransferSettingRepository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.TransferSetting;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.EsbGate;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.MtsMoneyGateWay;
import ru.mtsbank.integration.dbo.bankclient.transfers.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.ths.DBOServiceClient;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.TransferException;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.CustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FDXPhoneNum;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.PersonInfoTypeCustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.TransferOperations;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.*;

@Component("checktransfer")
@Slf4j
public class CheckTransferService {

    @Autowired
    private TransferBuilder transferBuilder;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private TransferSettingRepository transferSettingRepository;

    @Autowired
    private MtsMoneyGateWay mtsMoneyGateWay;

    @Autowired
    private DBOServiceClient dboServiceClient;

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    private final ObjectMapper mapper = new ObjectMapper();

    public CheckTransferRes call(CheckTransferReq req) {

        String uid = UUID.randomUUID().toString();

        log.info("{} checkTransfer service start with params {}, rboId = {}, phone = {}",uid,req.toString(), req.getRboID(), req.getSrcPhone());
        CheckTransferRes res = new CheckTransferRes();

        try {
            log.info("{} start searching settings",uid);
            TransferSetting setting = transferSettingRepository.findByPhoneNumber(Utils.castPhone(req.getRecipientPhone()));

            if (setting != null) {
                if (setting.getIsEnabled() != null && setting.getIsEnabled().equals(1)) {
                    CustSearchInqRs custSearchInqRs = null;
                    if (StringUtils.isEmpty(req.getSenderPam()) || StringUtils.isEmpty(req.getSenderPamShort()) || StringUtils.isEmpty(req.getSrcPhone())) {
                        log.info("{} get sender info from Siebel", uid);
                        custSearchInqRs = xmlUnmarshaler.parse(CustSearchInqRs.class
                                , esbGate.sendSalesMessageWithAnswer(
                                        xmlUnmarshaler.createXml(
                                                custSearchInqRqBuilder.createCustSearchInqRq(
                                                        req.getRboID().toString(), uid)
                                        )
                                )
                        );
                    }
                    if (!StringUtils.isEmpty(req.getSrcCardHash()) || !StringUtils.isEmpty(req.getSrcAccountNumber())) {
                        checkTransfer(custSearchInqRs, setting, req, res, uid);
                    } else {
                        res.createError(107, "Сервис временно недоступен", 501, null, "Не передан платежный инструмент", "CheckTransfer", uid);
                    }
                } else {
                    res.createError(1108, "У получателя платежа запрещено получение переводов по номеру телефона.", 400, null, "", "CheckTransfer", uid);
                }
            } else {
                res.createError(107, "Сервис временно недоступен", 501, null, "Не найден получатель", "CheckTransfer", uid);
            }
        } catch (TransferException e){
            log.error("{} Error: {}",uid,e);
            res.createError(e.getCode(), e.getMessage(), e.getHttpCode(), null, e.getDetails(), e.getService(), uid);
            e.printStackTrace();
        }catch (Exception e){
            log.error("{} Error: {}",uid,e);
            res.createError(107, "Сервис временно недоступен", 501, null, "", "CheckTransfer", uid);
            e.printStackTrace();
        }

        log.info("{} checkTransfer service end", uid);
        return res;
    }

    private void checkTransfer(CustSearchInqRs custSearchInqRs, TransferSetting setting, CheckTransferReq req, CheckTransferRes res, String uid) throws TransferException, IOException {

        Request req1;
        String number;

        req1 = Request.builder()
                .rboId(req.getRboID())
                .rcvSource(setting.getLinkValue())
                .rcvType(setting.getLinkType())
                .rcvName("MTS HUB")
                .phone("+" + req.getRecipientPhone())
                .amount(req.getAmount())
                .channel(getReqChannel(req.getClientId()))
                .documentId(new Date().getTime())
                .purpose(!StringUtils.isEmpty(req.getUserMessage()) ? req.getUserMessage() : "Перевод по номеру телефона другому клиенту МТС-Банка")
                .trnType(0)
                .build();

        if (!StringUtils.isEmpty(req.getSrcCardHash())){

            CardList cardList = getProductList("getCardList", req.getRboID().toString(), CardList.class);

            Optional<Card> optionalCard = cardList.getCards().stream()
                    .filter(item -> item.getHashPan().equalsIgnoreCase(req.getSrcCardHash()))
                    .findFirst();
            validateCard(optionalCard,req.getSrcCardExpiry());
            Card card = optionalCard.orElseGet(Card::new);

            log.info("{} card hashPAN: {}",uid, card.getHashPan());
            number = card.getNumber();

            YearMonth month = YearMonth.parse(req.getSrcCardExpiry().substring(0, 4) + "-" + req.getSrcCardExpiry().substring(4, 6)); //обработать ошибку
            req1.setSrcCardHash(req.getSrcCardHash());
            req1.setSrcCardExpire(Utils.getDate(Integer.parseInt(month.atEndOfMonth().toString().substring(0, 4)),
                    Integer.parseInt(month.atEndOfMonth().toString().substring(5, 7)),
                    Integer.parseInt(month.atEndOfMonth().toString().substring(8))));
        } else {
            AccountList accountList = getProductList("getAccountList", req.getRboID().toString(), AccountList.class);
            Optional<Account> accountOptional = accountList.getAccounts().stream()
                    .filter(item -> req.getSrcAccountNumber().equalsIgnoreCase(item.getNumber()))
                    .findFirst();
            validateAccount(accountOptional);

            req1.setSrcAccountNumber(req.getSrcAccountNumber());
            number = req.getSrcAccountNumber();
            log.info("{} card account number: {}",uid, number);
        }

        log.info("{} Start build transfer params",uid);
        TransferParams transferParams = getTransferParams(req.getRecipientPhone()
                , setting.getRecipientPAM()
                , setting.getRecipientPAMShort()
                , req.getUserMessage()
                , number
                , custSearchInqRs
                , req.getSenderPam()
                , req.getSenderPamShort()
                , req.getSrcPhone());
        if (transferParams != null && !StringUtils.isEmpty(transferParams.getSenderPAM()))
            req1.setSenderName(transferParams.getSenderPAM());


        String answer = esbGate.sendPayMessageWithAnswer(
                xmlUnmarshaler.createXml(transferBuilder.getRequest(req1,uid))
        );

        if (!StringUtils.isEmpty(answer)) {
            TransferOperations oper = xmlUnmarshaler.parse(TransferOperations.class, answer);
            transferBuilder.getPreCheckResponse(res, oper, req1, uid);

            log.info("{} Preprocess complete. TransferId: {}",uid, res.getTransferId());
            if (!StringUtils.isEmpty(res.getTransferId())) {

                String linkValue = setting.getLinkValue();
                BigDecimal amtForThs = Utils.devideSum(nvl(res.getTransferTotalAmt(), req.getAmount()));
                log.info("{} *** New Amount For Ths {}",uid,amtForThs);
                RegisterTransfer registerTransfer = RegisterTransfer.builder()
                        .rqid(uid)
                        .transferId(nvl(res.getTransferId(), uid))
                        .transferType("INT_BYPHONE")
                        .transferAmount(amtForThs)
                        .currency("RUB")
                        .source(getSource(req))
                        .target(getTarget(linkValue))
                        .transferParams(transferParams)
                        .build();
                log.info("{} TransferFeeAmt: {}",uid, res.getTransferFeeAmt());
                if (!res.getTransferFeeAmt().equals(BigDecimal.ZERO)){
                    registerTransfer.setFeeAmount(res.getTransferFeeAmt());
                }
                String ths = mapper.writeValueAsString(registerTransfer);

                log.info("{} Start save operation in THS - check {}",uid,ths);
                Integer answerFromThs = dboServiceClient.call(ths, "registerTransfer");
                log.info("{} End save operation in THS - check {}",uid,answerFromThs);

                if (answerFromThs.equals(0)) {
                    log.info("{} registerTransfer complete {}",uid,answerFromThs);
                    res.setRecipientPAM(setting.getRecipientPAM());
                    res.setUserMessage(req.getUserMessage());
                    res.setState(null);
                    res.setGuid(null);
                } else {
                    res.createError(1116, "Не удалось выполнить сохранение операции", 424, null, "No response from THS", "CheckTransfer", uid);
                }
            }
        } else {
            res.createError(107, "Сервис временно недоступен", 501, null, "!StringUtils.isEmpty(answer)", "CheckTransfer", uid);
        }
    }

    private String getReqChannel(String clientId) {
        String channel = "IB";
        if (!StringUtils.isEmpty(clientId)){
            channel = clientId.contains("ios") ? "IOS" : "ANDR";
        }
        return channel;
    }

    private void validateCard(Optional<Card> optionalCard, String exp) throws TransferException {
        if (!optionalCard.isPresent())
            throw new TransferException(1121,424,"Указаны некорректные реквизиты карты",null,"CheckTransfer");
        Card card = optionalCard.get();
        if (!card.getProductInfo().getStatus().getCode().equalsIgnoreCase("WRK"))
            throw new TransferException(1123,424,"Карты неактивна",null,"CheckTransfer");
        if (!StringUtils.isEmpty(card.getValidThru())){
            String cardExp = getData(card.getValidThru());
            if (!cardExp.equals(exp))
                throw new TransferException(1122,424,"Указаны некорректные реквизиты карты",null,"CheckTransfer");
        }
    }

    private void validateAccount(Optional<Account> accountOptional) throws TransferException {
        if (!accountOptional.isPresent())
            throw new TransferException(1124,424,"Указаны некорректные реквизиты счета",null,"CheckTransfer");
        Account account = accountOptional.get();
        if (!Boolean.TRUE.equals(account.getIsActive()))
            throw new TransferException(1125,424,"Счет неактивен",null,"CheckTransfer");
    }

    public String getData(String value){
        String retVal = "";
        retVal = value.substring(value.length()-4);
        retVal += value.substring(2,4);
        return retVal;
    }

    private <T> T nvl(T a, T b){
        return a != null ? a : b;
    }

    private TransferParams
    getTransferParams(String phone, String pam, String pamShort, String userMsg, String number, CustSearchInqRs custSearchInqRs, String senderPam, String senderPamShort, String sndrPhone){
        TransferParams params = TransferParams.builder()
                .receiverBankBIC("044525232")
                .receiverBankId("100000000017")
                .receiverBankName("МТС Банк")
                .receiverPhone(phone)
                .receiverPAM(pam)
                .receiverPAMShort(pamShort)
                .senderBankBIC("044525232")
                .senderBankName("МТС Банк")
                .senderBankId("100000000017")
                .operationPartnerName("Приложение «МТС Банк»")
                .transferType("INT_BYPHONE")
                .build();
        if (!StringUtils.isEmpty(userMsg))
            params.setUserMessage(userMsg);

        if (!StringUtils.isEmpty(number))
            params.setAccSuffix(number.substring(number.length()-4));

        if (StringUtils.isEmpty(senderPam) && StringUtils.isEmpty(senderPamShort)) {
            String senderPhone = null;
            String senderPAM = null;
            String senderPAMShort = null;
            if (custSearchInqRs != null
                    && custSearchInqRs.getBankSvcRs() != null
                    && custSearchInqRs.getBankSvcRs().getCustInfo() != null
                    && custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo() != null) {
                PersonInfoTypeCustSearchInqRs personInfo = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo();

                if (personInfo.getContactInfo() != null && !CollectionUtils.isEmpty(personInfo.getContactInfo().getPhoneNum())) {

                    if (personInfo.getPersonName() != null) {
                        senderPAM = personInfo.getPersonName().getFirstName() + " " + nvl(personInfo.getPersonName().getMiddleName(), "") + " " + personInfo.getPersonName().getLastName();
                        senderPAMShort = personInfo.getPersonName().getFirstName() + " " + personInfo.getPersonName().getLastName();
                    }
                    if (StringUtils.isEmpty(senderPAM))
                        senderPAM = personInfo.getFullName();

                    for (FDXPhoneNum item : personInfo.getContactInfo().getPhoneNum()) {
                        if (item.isPrimary()
                                && item.getPhoneType().equals("Mobile")
                                && !StringUtils.isEmpty(item.getPhone())) {
                            senderPhone = Utils.formatPhone(item.getPhone());
                        }
                    }

                }
            }
            if (!StringUtils.isEmpty(senderPhone))
                params.setSenderPhone(senderPhone);
            if (!StringUtils.isEmpty(senderPAM))
                params.setSenderPAM(Utils.formatName(senderPAM));
            if (!StringUtils.isEmpty(senderPAMShort))
                params.setSenderPAMShort(Utils.formatName(senderPAMShort));
        } else {
            params.setSenderPAM(senderPam);
            params.setSenderPAMShort(senderPamShort);
            if (!StringUtils.isEmpty(sndrPhone)){
                params.setSenderPhone(sndrPhone);
            }
        }

        return params;
    }

    private Target getTarget(String value){
        return Target.builder()
                .hashedPAN(value)
                .build();
    }

    private Source getSource(CheckTransferReq req){
        Source source = Source.builder()
                .bankClientId(req.getRboID().toString())
                .bindingId(req.getSrcBindingId())
                .build();
        if (!StringUtils.isEmpty(req.getSrcCardHash())){
            source.setHashedPAN(req.getSrcCardHash());
        } else {
            source.setAccountNumber(req.getSrcAccountNumber());
        }
        return source;
    }

    private <T> T  getProductList(String method, String rboID, Class<T> cls) throws IOException {
        List<String> bankClientId = new ArrayList<>();
        bankClientId.add(rboID);
        String answer = mtsMoneyGateWay.getProductList(method, bankClientId);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(answer, cls);
    }

}
