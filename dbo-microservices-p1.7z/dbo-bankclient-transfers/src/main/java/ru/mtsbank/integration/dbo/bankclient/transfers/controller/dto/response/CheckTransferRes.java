package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class CheckTransferRes extends BaseResponse {

    @JsonProperty("transferId")
    private String transferId;
    @JsonProperty("transferFeeAmt")
    private BigDecimal transferFeeAmt;
    @JsonProperty("transferTotalAmt")
    private BigDecimal transferTotalAmt;
    @JsonProperty("recipientPAM")
    private String recipientPAM;
    @JsonProperty("userMessage")
    private String userMessage;

    @JsonIgnore
    private String state;
    @JsonIgnore
    private String guid;

}
