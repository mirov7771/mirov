package ru.mtsbank.integration.dbo.bankclient.transfers.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI configure(ApplicationConfig applicationConfig){
        ApplicationConfig.Springdoc springdoc = applicationConfig.getSpringdoc();
        return new OpenAPI()
                .components(new Components())
                .info(new Info()
                        .title(springdoc.getTitle())
                        .description(springdoc.getAuthor())
                        .version(springdoc.getVersion()));
    }

}
