package ru.mtsbank.integration.dbo.bankclient.transfers.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.TransferSetting;

@Repository
public interface TransferSettingRepository extends CrudRepository<TransferSetting, String> {

    TransferSetting findByRboId(Long rboId);
    TransferSetting findByPhoneNumber(String phoneNumber);

}
