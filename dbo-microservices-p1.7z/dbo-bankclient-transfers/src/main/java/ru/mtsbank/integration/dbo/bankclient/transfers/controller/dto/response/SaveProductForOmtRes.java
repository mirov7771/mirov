package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class SaveProductForOmtRes extends BaseResponse {

    @JsonProperty("success")
    private Boolean success;
    @JsonProperty("code")
    private Integer code;
    @JsonProperty("message")
    private String message;

}
