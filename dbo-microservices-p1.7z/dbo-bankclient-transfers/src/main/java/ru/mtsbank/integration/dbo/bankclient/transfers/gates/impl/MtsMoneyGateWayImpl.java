package ru.mtsbank.integration.dbo.bankclient.transfers.gates.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.mtsbank.integration.dbo.bankclient.transfers.config.ApplicationConfig;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.MtsMoneyGateWay;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class MtsMoneyGateWayImpl implements MtsMoneyGateWay {

    private static ApplicationConfig.Mts.Money money;

    public MtsMoneyGateWayImpl(ApplicationConfig applicationConfig) {
        money = applicationConfig.getMts().getMoney();
    }

    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public Map<String, Object> getApi(String method, String paramName, List<String> paramValues) throws IOException {
        log.info("start calling "+ method);
        Map<String, Object> outputParams = new HashMap<>();
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .readTimeout(20000, TimeUnit.MILLISECONDS)
                .build();
        StringBuilder url = new StringBuilder(money.getGate() + method);
        int sz = paramValues.size();
        for(int i=0 ; i<sz ; i++){
            if (i == 0)
                url.append("?");
            if (i < sz-1)
                url.append(paramName).append("=").append(paramValues.get(i)).append("&");
            else
                url.append(paramName).append("=").append(paramValues.get(i));
        }


        log.info("Call "+url);
        Request request = new Request.Builder()
                .url(url.toString())
                .addHeader("Accept-Encoding", "identity")
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Connection", "keep-alive")
                .get()
                .build();
        Response response = httpClient.newCall(request).execute();
        if (response != null){
            String answer = response.body().string();
            log.info("Receive gateway answer " + answer);
            outputParams = mapper.readValue(answer, Map.class);
        }
        log.info("end calling "+ method);
        return outputParams;
    }

    @Override
    public String getProductList(String method, List<String> rboId) throws IOException{
        log.info("start calling getCardList");
        String res="";
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .readTimeout(20000, TimeUnit.MILLISECONDS)
                .build();
        StringBuilder url = new StringBuilder(money.getGate() + method);
        int sz = rboId.size();
        for(int i=0;i<sz;i++){
            if (i == 0)
                url.append("?");
            if (i < sz-1)
                url.append("bankClientId").append("=").append(rboId.get(i)).append("&");
            else
                url.append("bankClientId").append("=").append(rboId.get(i));
        }

        log.info("Call "+url);
        Request request = new Request.Builder()
                .url(url.toString())
                .addHeader("Accept-Encoding", "identity")
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Connection", "keep-alive")
                .get()
                .build();
        Response response = httpClient.newCall(request).execute();
        if (response != null) {
            String answer = response.body().string();
            log.info("Receive gateway answer " + answer);
            res = answer;
        }
        return res;
    }

}
