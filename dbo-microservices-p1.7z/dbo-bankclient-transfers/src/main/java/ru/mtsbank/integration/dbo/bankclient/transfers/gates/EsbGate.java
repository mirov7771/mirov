package ru.mtsbank.integration.dbo.bankclient.transfers.gates;

import org.springframework.stereotype.Service;
import java.io.IOException;

@Service
public interface EsbGate {

    String sendInfoMessageWithAnswer(String messageXml) throws IOException;
    String sendSalesMessageWithAnswer(String messageXml) throws IOException;
    String sendPayMessageWithAnswer(String messageXml) throws IOException;
    void sendInfoMessage(String messageXml) throws IOException;
    void sendSalesMessage(String messageXml) throws IOException;

}
