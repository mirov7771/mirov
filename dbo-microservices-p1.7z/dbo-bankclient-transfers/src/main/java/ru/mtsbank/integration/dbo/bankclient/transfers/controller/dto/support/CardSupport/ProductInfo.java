package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.CardSupport;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class ProductInfo {

    @JsonProperty("account")
    private PropertiesInfo account;
    @JsonProperty("general")
    private PropertiesInfo general;
    @JsonProperty("group")
    private PropertiesInfo group;
    @JsonProperty("insurance")
    private PropertiesInfo insurance;
    @JsonProperty("plastic")
    private PropertiesInfo plastic;
    @JsonProperty("schema")
    private PropertiesInfo schema;
    @JsonProperty("status")
    private PropertiesInfo status;
    @JsonProperty("statusExt")
    private PropertiesInfo statusExt;
    @JsonProperty("type")
    private PropertiesInfo type;



}
