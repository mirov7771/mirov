package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class Account {

    @JsonProperty("number")
    private String number;
    @JsonProperty("isActive")
    private Boolean isActive;

}
