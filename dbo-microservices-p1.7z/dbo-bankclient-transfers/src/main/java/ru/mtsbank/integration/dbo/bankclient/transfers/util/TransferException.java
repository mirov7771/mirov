package ru.mtsbank.integration.dbo.bankclient.transfers.util;

import lombok.Getter;

@Getter
public class TransferException extends Exception {

    private final Integer code;
    private final int httpCode;
    private final String message;
    private final String details;
    private final String service;

    public TransferException(Integer code
                            ,int httpCode
                            ,String message
                            ,String details
                            ,String service)
    {
        super(message);
        this.code = code;
        this.httpCode = httpCode;
        this.details = details;
        this.message = message;
        this.service = service;
    }

}
