package ru.mtsbank.integration.dbo.bankclient.transfers.builders;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.mts.xsd.DBOCust.acctlistinqrq.AcctListInqRq;
import ru.mtsbank.integration.mts.xsd.DBOCust.acctlistinqrq.BankSvcRq;
import ru.mtsbank.integration.mts.xsd.DBOCust.acctlistinqrq.ServerInfoType;


import java.util.Date;
import java.util.UUID;

import static ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils.getXmlGregorianCalendar;

@Component
public class AcctListInqRqBuilder {

    public AcctListInqRq acctListInqRq(String rboId){
        AcctListInqRq acctListInqRq = new AcctListInqRq();
        String rqUid = UUID.randomUUID().toString();
        ServerInfoType serverInfo = acctListInqRq.getServerInfo();
        serverInfo.setMsgUID(rqUid);
        serverInfo.setRqUID(rqUid);
        serverInfo.setMsgType("AcctListInqRq");
        serverInfo.setBpId("MTS_DBO_ACC_LIST");
        serverInfo.setServerDt(getXmlGregorianCalendar(new Date()));
        serverInfo.setSPName("MTS_EIP_UMP");
        serverInfo.setMsgReceiver("RBO");
        acctListInqRq.setServerInfo(serverInfo);
        BankSvcRq bankSvcRq = new BankSvcRq();
        bankSvcRq.setCustId(rboId);
        acctListInqRq.setBankSvcRq(bankSvcRq);
        return acctListInqRq;
    }

}
