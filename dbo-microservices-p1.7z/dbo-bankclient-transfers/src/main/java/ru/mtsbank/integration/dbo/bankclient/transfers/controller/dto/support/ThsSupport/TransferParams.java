package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@Builder
public class TransferParams {

    @JsonProperty("receiverBankBIC")
    private String receiverBankBIC;
    @JsonProperty("receiverBankName")
    private String receiverBankName;
    @JsonProperty("receiverBankId")
    private String receiverBankId;
    @JsonProperty("receiverPhone")
    private String receiverPhone;
    @JsonProperty("receiverPAM")
    private String receiverPAM;
    @JsonProperty("receiverPAMShort")
    private String receiverPAMShort;
    @JsonProperty("userMessage")
    private String userMessage;
    @JsonProperty("senderBankBIC")
    private String senderBankBIC;
    @JsonProperty("senderBankName")
    private String senderBankName;
    @JsonProperty("senderBankId")
    private String senderBankId;
    @JsonProperty("senderPhone")
    private String senderPhone;
    @JsonProperty("senderPAM")
    private String senderPAM;
    @JsonProperty("senderPAMShort")
    private String senderPAMShort;
    @JsonProperty("operationPartnerName")
    private String operationPartnerName;
    @JsonProperty("accSuffix")
    private String accSuffix;
    @JsonProperty("transferType")
    private String transferType;

}
