package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseRequest;

@Getter
@Setter
public class CreateTransferReq extends BaseRequest {

    @JsonProperty("transferId")
    private String transferId;
    @JsonProperty("otpToken")
    private String otpToken;
    @JsonProperty("clientId")
    private String clientId;

}
