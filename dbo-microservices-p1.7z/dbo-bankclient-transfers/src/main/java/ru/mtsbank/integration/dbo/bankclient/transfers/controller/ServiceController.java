package ru.mtsbank.integration.dbo.bankclient.transfers.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.builders.ResponseBuilder;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.*;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.*;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.Service;

import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Tag(name = "BankclientTransfersController")
@RestController
@RequestMapping("dbo-bankclient-transfers")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/checkTransfer", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "проверка возможности совершения перевода"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CheckTransferRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> checkTransfer(@PathVariable final String version
                                                     ,@RequestHeader(value = "rboid", required = false) String rboId
                                                     ,@RequestHeader(value = "authorization", required = false) String authorization
                                                     ,@RequestHeader(value = "phone", required = false) String phone
                                                     ,@RequestHeader(value = "client-id", required = false) String clientId
                                                     ,@RequestBody CheckTransferReq req)
    {
        if (StringUtils.isEmpty(req.getSenderPam()) && StringUtils.isEmpty(req.getSenderPamShort())){
            if (!StringUtils.isEmpty(authorization))
                req.setSenderPam(authorization);
        }
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        if (req.getSrcPhone() == null)
            req.setSrcPhone(phone,authorization);
        req.setClientId(clientId);
        return ResponseBuilder.build(services.get(version).checkTransfer(req));
    }

    @PostMapping(value = "{version}/createTransfer", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "запуск перевода"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CreateTransferRes.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> createTransfer(@PathVariable final String version
                                                      ,@RequestHeader(value = "rboid", required = false) String rboId
                                                      ,@RequestHeader(value = "authorization", required = false) String authorization
                                                      ,@RequestHeader(value = "client-id", required = false) String clientId
                                                      ,@RequestBody CreateTransferReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        req.setClientId(clientId);
        return ResponseBuilder.build(services.get(version).createTransfer(req));
    }


    @PostMapping(value = "{version}/getClientByPhone", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "поиск клиента/клиентов по номеру телефона"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = GetClientByPhoneRes.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> getClientByPhone(@PathVariable final String version
                                                        ,@RequestHeader(value = "phone", required = false) String phone
                                                        ,@RequestHeader(value = "authorization", required = false) String authorization
                                                        ,@RequestBody GetClientByPhoneReq req)
    {
        if (req.getSrcPhone() == null)
            req.setSrcPhone(phone,authorization);
        return ResponseBuilder.build(services.get(version).getClientByPhone(req));
    }

    @PostMapping(value = "{version}/saveProductForOmt", produces = APPLICATION_JSON_UTF8_VALUE)
    @ResponseBody
    @Operation(summary = "привязка источника пополнения к ОМТ"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = SaveProductForOmtRes.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> saveProductForOmt(@PathVariable final String version
                                                         ,@RequestBody SaveProductForOmtReq req)
    {
        return ResponseBuilder.build(services.get(version).saveProductForOmt(req));
    }

}
