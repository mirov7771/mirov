package ru.mtsbank.integration.dbo.bankclient.transfers.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.Transfer;

@Repository
public interface TransferRepository extends CrudRepository<Transfer, String> {

    Transfer findByDocExtIdAndClientExtId(String docExtId, Long clientExtId);

}
