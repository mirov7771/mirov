package ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.GetClientByPhoneReq;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.GetClientByPhoneRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Card;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.CardList;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Phone;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Product;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.TransferSettingRepository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.TransferSetting;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.EsbGate;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.MtsMoneyGateWay;
import ru.mtsbank.integration.dbo.bankclient.transfers.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.TransferException;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrq.CustSearchInqRq;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.CustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.PersonNameType;

import java.io.IOException;
import java.util.*;

import static ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils.castPhone;

@Component("getclientbyphone")
@Slf4j
public class GetClientByPhoneService {

    @Autowired
    private MtsMoneyGateWay mtsMoneyGateWay;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    @Autowired
    private TransferSettingRepository transferSettingRepository;

    public GetClientByPhoneRes call(GetClientByPhoneReq req) {
        log.info("Start getclientbyphone");
        GetClientByPhoneRes res = new GetClientByPhoneRes();
        String uid = UUID.randomUUID().toString();
        try {
            Map<String,Object> paramMap = getParamValues(req);
            List<String> paramValues = (ArrayList) paramMap.get("paramValues");
            boolean isMassive = (Boolean) paramMap.get("isMassive");
            Map<String, Object> map = mtsMoneyGateWay.getApi("CheckPhoneList", "phoneList", paramValues);
            checkGateWayAnswer(map);
            List<Map<String, Object>> clientList = (ArrayList) map.get("clientList");
            if (Boolean.TRUE.equals(isMassive)) {
                setAnswerForList(req, res, clientList);
            } else {
                String rboId = getRboIdFromList(clientList);
                Map<String, String> custSearchInqRs = getCustSearchInqRs(rboId, uid);
                String fullName = "";
                String shortName = "";
                if (!custSearchInqRs.isEmpty()){
                    fullName = custSearchInqRs.get("fullName");
                    shortName = custSearchInqRs.get("shortName");
                }
                res.setClientName(fullName);
                TransferSetting setting = transferSettingRepository.findByRboId(Long.valueOf(rboId));
                if (setting != null) {
                    log.info("client found in DB, request phone {}, db phone {}", req.getPhone(), setting.getPhoneNumber());
                    if (setting.getIsEnabled() != null
                            && setting.getIsEnabled().equals(1))
                    {
                        if (validateCard(setting.getLinkValue(), rboId)){
                            res.setPermission(true);
                            res.setLinkValue(setting.getLinkValue());
                            res.setLinkType(setting.getLinkType());
                            res.setBindingId(setting.getBindingId());
                            if (!req.getPhone().equals(setting.getPhoneNumber()))
                                saveToDB (null, fullName, shortName, castPhone(req.getPhone()), rboId, setting);
                        } else {
                            Product newCard = getNewCard(rboId);
                            if (newCard != null){
                                res.setPermission(true);
                                res.setLinkValue(newCard.getValue());
                                res.setLinkType(newCard.getType());
                                res.setBindingId(newCard.getId());

                                saveToDB (newCard, fullName, shortName, castPhone(req.getPhone()), rboId, setting);
                            } else {
                                res.createError(1107,"Отсутствует финансовый инструмент для получения платеж", 406, null,null,"GetClientByPhone", uid);
                            }
                        }
                    } else {
                        res.createError(1108, "У получателя платежа запрещено получение переводов по номеру телефона", 422, null, null, "GetClientByPhone", uid);
                    }
                } else {
                    Product newCard = getNewCard(rboId);
                    if (newCard != null) {
                        res.setPermission(true);
                        res.setLinkValue(newCard.getValue());
                        res.setLinkType(newCard.getType());
                        res.setBindingId(newCard.getId());

                        saveToDB (newCard, fullName, shortName, castPhone(req.getPhone()), rboId, null);
                    } else {
                        res.createError(1107,"Отсутствует финансовый инструмент для получения платеж", 406, null,null,"GetClientByPhone", uid);
                    }
                }
            }
        } catch (TransferException e){
            log.error("Error: "+e);
            res.createError(e.getCode(), e.getMessage(), e.getHttpCode(), null, e.getDetails(), e.getService(), uid);
            e.printStackTrace();
        } catch (IOException e){
            log.error("Error: "+e);
            res.createError(107, "Сервис временно недоступен", 424, null, "", "GetClientByPhone", uid);
            e.printStackTrace();
        }
        log.info("End getclientbyphone");
        return res;
    }

    private Map<String,String> getCustSearchInqRs(String rboId, String uid) throws IOException,TransferException {
        Map<String, String> retMap = new HashMap<>();
        String fullName = "";
        String shortName = "";
        CustSearchInqRq rq = custSearchInqRqBuilder.createCustSearchInqRq(rboId, uid);
        String rs = esbGate.sendSalesMessageWithAnswer(xmlUnmarshaler.createXml(rq));
        if (StringUtils.isEmpty(rs))
            throw new TransferException(1117, 406, "Клиент не найден", "No response from CustSearchInq method", "GetClientByPhone");
        CustSearchInqRs custSearchInqRs = xmlUnmarshaler.parse(CustSearchInqRs.class, rs);
        if (custSearchInqRs == null
            || custSearchInqRs.getBankSvcRs() == null
            || custSearchInqRs.getBankSvcRs().getCustInfo() == null
            || custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo() == null
            || custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getPersonName() == null)
            throw new TransferException(1117, 406, "Клиент не найден", "Incorrect response from CustSearchInq method", "GetClientByPhone");
        PersonNameType personName = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getPersonName();
        if (personName.getFirstName() != null) {
            fullName = personName.getFirstName().charAt(0) + personName.getFirstName().substring(1).toLowerCase();
            shortName = personName.getFirstName().charAt(0) + personName.getFirstName().substring(1).toLowerCase();
        }
        if (personName.getMiddleName() != null)
            fullName += " " + personName.getMiddleName().charAt(0) + personName.getMiddleName().substring(1).toLowerCase();
        if (personName.getLastName() != null) {
            fullName += " " + personName.getLastName().charAt(0) + ".";
            shortName += " " + personName.getLastName().charAt(0) + ".";
        }
        retMap.put("fullName", fullName);
        retMap.put("shortName", shortName);
        return retMap;
    }

    private String getRboIdFromList(List<Map<String, Object>> clientList) throws TransferException {
        String rboId = null;
        for (Map<String, Object> item2 : clientList) {
            if (item2.get("rboId") != null) {
                rboId = (String) item2.get("rboId");
                break;
            }
        }
        if (StringUtils.isEmpty(rboId))
            throw new TransferException(1117, 424, "Клиент не найден", null, "GetClientByPhone");
        return rboId;
    }

    private void setAnswerForList(GetClientByPhoneReq req, GetClientByPhoneRes res, List<Map<String, Object>> clientList) {
        List<Phone> phoneList = req.getPhoneList();
        for (Phone item : phoneList) {
            String phone = castPhone(item.getPhone());
            for (Map<String, Object> item2 : clientList) {
                String phone2 = (String) item2.get("phone");
                if (item2.get("rboId") != null && phone.equals(phone2)) {
                    item.setIsClient(true);
                    break;
                }
            }
        }
        phoneList.forEach(item -> {
            if (!Boolean.TRUE.equals(item.getIsClient()))
                item.setIsClient(false);
        });
        res.setPhoneList(phoneList);
    }

    private void checkGateWayAnswer(Map<String, Object> map) throws TransferException {
        if (map.isEmpty())
            throw new TransferException(107, 424, "Сервис временно недоступен", "No response from CheckPhoneList method", "GetClientByPhone");
        if (map.get("clientList") == null || !(map.get("clientList") instanceof ArrayList))
            throw new TransferException(107, 424, "Сервис временно недоступен", "Incorrect response from CheckPhoneList method", "GetClientByPhone");
    }

    private Map<String,Object> getParamValues(GetClientByPhoneReq req) throws TransferException{
        req.checkInputParams();
        Map<String, Object> map = new HashMap<>();
        List<String> paramValues = new ArrayList();
        boolean isMassive = false;
        if (!CollectionUtils.isEmpty(req.getPhoneList())) {
            isMassive = true;
            for (Phone phone : req.getPhoneList()) {
                if (!StringUtils.isEmpty(phone.getPhone())) {
                    paramValues.add(castPhone(phone.getPhone()));
                }
            }
        } else {
            if (!StringUtils.isEmpty(req.getPhone())) {
                paramValues.add(castPhone(req.getPhone()));
            }
        }
        if (CollectionUtils.isEmpty(paramValues))
            throw new TransferException(101, 400, "Не передан номер телефона", "Incorrect Format", "GetClientByPhone");
        map.put("paramValues",paramValues);
        map.put("isMassive",isMassive);
        return map;
    }


    private Boolean validateCard (String hashPan, String rboId) throws IOException {
        CardList cardList = callGetCardList(rboId);
        Optional<Card> optionalCard = cardList.getCards().stream()
                .filter(item -> item.getHashPan().equalsIgnoreCase(hashPan))
                .findFirst();
        Card card = optionalCard.orElseGet(Card::new);
        return card.getProductInfo().getStatus().getCode().equalsIgnoreCase("WRK");
    }

    private CardList callGetCardList (String rboId) throws IOException {
        List<String> bankClientIdList = new ArrayList<>();
        bankClientIdList.add(rboId);
        String cards = mtsMoneyGateWay.getProductList("getCardList", bankClientIdList);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(cards, CardList.class);
    }

    private Product getNewCard (String rboId) throws IOException {
        log.info("Service getCardValue start");
        Product value = null;
        CardList cardList = callGetCardList(rboId);
        if(cardList != null && !CollectionUtils.isEmpty(cardList.getCards())){
            List<Product> activeMainDebetCardList = new ArrayList<>();
            List<Product> activeMainCreditCardList = new ArrayList<>();
            List<Product> acitveMainVirtCardList = new ArrayList<>();
            List<Product> activeNotMainDebetCardList = new ArrayList<>();
            List<Product> activeNotMainCreditCardList = new ArrayList<>();
            List<Product> activeNotMainVirtCardList = new ArrayList<>();
            for (Card item: cardList.getCards()) {
                if (item.getProductInfo() != null
                        && item.getProductInfo().getStatus() != null
                        && "WRK".equalsIgnoreCase(item.getProductInfo().getStatus().getCode())
                        && item.getProductInfo().getType() != null
                        && Utils.isRub(item.getCurrency())) {
                    if (Boolean.TRUE.equals(item.getIsMainCard())
                            && "DEBIT_CARD".equalsIgnoreCase(item.getProductInfo().getType().getDetail())) {
                        activeMainDebetCardList.add(getCardProduct(item));
                    } else if (Boolean.TRUE.equals(item.getIsMainCard())
                            && "CREDIT_CARD".equalsIgnoreCase(item.getProductInfo().getType().getDetail())) {
                        activeMainCreditCardList.add(getCardProduct(item));
                    } else if (!Boolean.TRUE.equals(item.getIsMainCard())
                            && "DEBIT_CARD".equalsIgnoreCase(item.getProductInfo().getType().getDetail())) {
                        activeNotMainDebetCardList.add(getCardProduct(item));
                    } else if (!Boolean.TRUE.equals(item.getIsMainCard())
                            && "CREDIT_CARD".equalsIgnoreCase(item.getProductInfo().getType().getDetail())) {
                        activeNotMainCreditCardList.add(getCardProduct(item));
                    }
                } else if (Boolean.TRUE.equals(item.getIsMainCard())
                        && item.getProductInfo() != null
                        && item.getProductInfo().getType() != null
                        && !StringUtils.isEmpty(item.getProductInfo().getType().getDetail())
                        && item.getProductInfo().getType().getDetail().contains("VIRT"))
                {
                    acitveMainVirtCardList.add(getCardProduct(item));
                } else if (!Boolean.TRUE.equals(item.getIsMainCard())
                        && item.getProductInfo() != null
                        && item.getProductInfo().getType() != null
                        && !StringUtils.isEmpty(item.getProductInfo().getType().getDetail())
                        && item.getProductInfo().getType().getDetail().contains("VIRT"))
                {
                    activeNotMainVirtCardList.add(getCardProduct(item));
                }
            }

            if (!CollectionUtils.isEmpty(activeMainDebetCardList)){
                activeMainDebetCardList.sort(Product.COMPARE_BY_DATE);
                value = activeMainDebetCardList.get(0);
                log.info("Card is main debet. Binding id: "+ value.getId());
            } else if (!CollectionUtils.isEmpty(activeMainCreditCardList)){
                activeMainCreditCardList.sort(Product.COMPARE_BY_DATE);
                value = activeMainCreditCardList.get(0);
                log.info("Card is main credit. Binding id: "+ value.getId());
            } else if (!CollectionUtils.isEmpty(activeNotMainDebetCardList)){
                activeNotMainDebetCardList.sort(Product.COMPARE_BY_DATE);
                value = activeNotMainDebetCardList.get(0);
                log.info("Card is not main debet. Binding id: "+ value.getId());
            } else if (!CollectionUtils.isEmpty(activeNotMainCreditCardList)){
                activeNotMainCreditCardList.sort(Product.COMPARE_BY_DATE);
                value = activeNotMainCreditCardList.get(0);
                log.info("Card is not main credit. Binding id: "+ value.getId());
            } else if (!CollectionUtils.isEmpty(acitveMainVirtCardList)){
                acitveMainVirtCardList.sort(Product.COMPARE_BY_DATE);
                value = acitveMainVirtCardList.get(0);
                log.info("Card is main virt. Binding id: "+ value.getId());
            } else if (!CollectionUtils.isEmpty(activeNotMainCreditCardList)){
                activeNotMainCreditCardList.sort(Product.COMPARE_BY_DATE);
                value = activeNotMainCreditCardList.get(0);
                log.info("Card is not main virt. Binding id: "+ value.getId());
            }

        }
        log.info("Service getCardValue end");
        return value;
    }

    private Product getCardProduct(Card item) {
        return new Product(item.getId(),
                item.getHashPan(),
                Utils.getDate(Integer.parseInt(item.getIssueDate().substring(4, 8)),
                        Integer.parseInt(item.getIssueDate().substring(2, 4)),
                        Integer.parseInt(item.getIssueDate().substring(0, 2))),
                "CARD",
                Utils.getDate(Integer.parseInt(item.getValidThru().substring(4)),
                        Integer.parseInt(item.getValidThru().substring(2, 4)),
                        Integer.parseInt(item.getValidThru().substring(0, 2))));
    }

    private void saveToDB (Product product, String fullName, String shortName, String phone, String rboId,TransferSetting transferSetting) {
        if (transferSetting == null)
            transferSetting = new TransferSetting();
        if (product != null) {
            transferSetting.setLinkValue(product.getValue());
            transferSetting.setLinkType(product.getType());
            transferSetting.setIsEnabled(1);
            transferSetting.setBindingId(product.getId());
            transferSetting.setRboId(Long.valueOf(rboId));
            transferSetting.setRecipientPAM(fullName);
            transferSetting.setRecipientPAMShort(shortName);
            transferSetting.setExpireDate(product.getExpireDate());
        }
        transferSetting.setPhoneNumber(phone);
        transferSettingRepository.save(transferSetting);
    }

}
