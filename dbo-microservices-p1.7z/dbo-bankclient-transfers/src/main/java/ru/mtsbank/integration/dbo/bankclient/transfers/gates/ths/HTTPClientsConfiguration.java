package ru.mtsbank.integration.dbo.bankclient.transfers.gates.ths;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import ru.mtsbank.integration.dbo.bankclient.transfers.config.ApplicationConfig;

import javax.net.ssl.SSLContext;
import java.io.File;
import java.time.Duration;

@Configuration
@Slf4j
public class HTTPClientsConfiguration {

    private static ApplicationConfig.External.FtdDbo ftdDbo;

    public HTTPClientsConfiguration(ApplicationConfig applicationConfig){
        ftdDbo = applicationConfig.getExternal().getFtdDbo();
    }

    @Bean
    RestTemplate dboRestTemplate(RestTemplateBuilder builder) {
        log.info("Start initialize Rest Template");
        return createRestTemplate(builder);
    }

    private Duration getDuration(String value){
        return Duration.ofSeconds(Long.parseLong(value.replaceAll("s","")));
    }

    private RestTemplate createRestTemplate(RestTemplateBuilder builder) {
        ClientHttpRequestFactory requestFactory = createRequestFactory();

        builder = builder.rootUri(ftdDbo.getBaseUrl())
                .requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
                .setConnectTimeout(getDuration(ftdDbo.getConnectTimeout()))
                .setReadTimeout(getDuration(ftdDbo.getReadTimeout()));

        return builder.build();
    }

    private ClientHttpRequestFactory createRequestFactory() {

        int poolSize = Integer.parseInt(ftdDbo.getPoolSize());
        HttpClientBuilder clientBuilder = HttpClientBuilder.create()
                .setMaxConnTotal(poolSize)
                .setMaxConnTotal(poolSize);

        clientBuilder
                .setSSLContext(createSSLContext(ftdDbo.getSsl()))
                .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);

        if (ftdDbo.getProxy() != null) {
            log.info("Start adding proxy");
            log.info("Start getting host and port");
            HttpHost proxy = new HttpHost(ftdDbo.getProxy().getHost(), Integer.parseInt(ftdDbo.getProxy().getPort()));
            clientBuilder.setProxy(proxy);
        }

        return new HttpComponentsClientHttpRequestFactory(clientBuilder.build());
    }

    private SSLContext createSSLContext(ApplicationConfig.External.FtdDbo.Ssl ssl) {
        log.info("*** SSL initialize");
        try {
            return SSLContextBuilder.create()
                    .loadKeyMaterial(new File(ssl.getKeystore()),
                            ssl.getKeystorepassword().toCharArray(),
                            ssl.getKeypassword().toCharArray())
                    .loadTrustMaterial(new File(ssl.getTrustcert()),
                            ssl.getTruststorepassword().toCharArray())
                    .build();
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to initialize SSL context", ex);
        }
    }
}
