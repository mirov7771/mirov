package ru.mtsbank.integration.dbo.bankclient.transfers.gates.impl;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.stereotype.Service;
import ru.mtsbank.integration.dbo.bankclient.transfers.config.ApplicationConfig;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.EsbGate;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class EsbGateImpl implements EsbGate {

    private static ApplicationConfig.Esb esb;
    private static ApplicationConfig.Esb.Info info;
    private static ApplicationConfig.Esb.Sales sales;
    private static ApplicationConfig.Esb.Pay pay;

    public EsbGateImpl(ApplicationConfig applicationConfig){
        esb = applicationConfig.getEsb();
        info = esb.getInfo();
        sales = esb.getSales();
        pay = esb.getPay();
    }

    @Override
    public String sendInfoMessageWithAnswer(String messageXml) throws IOException {
        return requestDelete(requestPost(messageXml, info.getIn()), info.getOut());
    }

    @Override
    public String sendSalesMessageWithAnswer(String messageXml) throws IOException {
        return requestDelete(requestPost(messageXml, sales.getIn()), sales.getOut());
    }

    @Override
    public String sendPayMessageWithAnswer(String messageXml) throws IOException {
        return requestDelete(requestPost(messageXml, pay.getIn()), pay.getOut());
    }

    @Override
    public void sendInfoMessage(String messageXml) throws IOException {
        requestPost(messageXml, info.getIn());
    }

    @Override
    public void sendSalesMessage(String messageXml) throws IOException {
        requestPost(messageXml, sales.getIn());
    }

    public String requestDelete(String correlationId, String esbOutUrl) throws IOException {
        log.info("start searching response for correlationid "+correlationId);
        OkHttpClient httpClient = new OkHttpClient.Builder()
                .readTimeout(150000, TimeUnit.MILLISECONDS)
                .build();
        String url = esbOutUrl + "?correlationId=" + correlationId + "&wait=150000";
        Request request = new Request.Builder()
                .url(url)
                .addHeader("ibm-mq-rest-csrf-token", esb.getToken())
                .addHeader("Content-Type", "text/plain;charset=utf-8")
                .addHeader("Authorization", esb.getPassword())
                .delete()
                .build();
        log.info("end searching response in "+url);
        Response response = httpClient.newCall(request).execute();
        String answer = response.body().string();
        log.info("end searching response for correlationid "+correlationId+" get answer "+answer);
        return answer;
    }

    private String requestPost(String messageXml, String esbInUrl) throws IOException {
        OkHttpClient httpClient = new OkHttpClient();
        log.info("start sending request "+messageXml);
        RequestBody requestBody = RequestBody.create(MediaType.parse("application/xml; charset=utf-8"), messageXml);
        Request request = new Request.Builder()
                .url(esbInUrl)
                .addHeader("ibm-mq-rest-csrf-token", esb.getToken())
                .addHeader("Content-Type", "application/xml")
                .addHeader("Authorization", esb.getPassword())
                .post(requestBody)
                .build();
        log.info("end sending request");
        Response response = httpClient.newCall(request).execute();
        return response.header("ibm-mq-md-messageid");
    }

}