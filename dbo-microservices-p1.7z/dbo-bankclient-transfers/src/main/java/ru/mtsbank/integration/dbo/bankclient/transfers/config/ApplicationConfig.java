package ru.mtsbank.integration.dbo.bankclient.transfers.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ApplicationConfig {

    @JsonProperty("spring")
    private Spring spring;
    @JsonProperty("esb")
    private Esb esb;
    @JsonProperty("mts")
    private Mts mts;
    @JsonProperty("external")
    private External external;
    @JsonProperty("sms")
    private Sms sms;
    @JsonProperty("springdoc")
    private Springdoc springdoc;

    @Data
    public static class Spring {
        @JsonProperty("datasource")
        private Datasource datasource;
        @Data
        public static class Datasource {
            @JsonProperty("driver-class-name")
            private String driverclassname;
            @JsonProperty("password")
            private String password;
            @JsonProperty("url")
            private String url;
            @JsonProperty("username")
            private String username;
        }
    }

    @Data
    public static class Esb {
        @JsonProperty("info")
        private Info info;
        @JsonProperty("pay")
        private Pay pay;
        @JsonProperty("sales")
        private Sales sales;
        @JsonProperty("password")
        private String password;
        @JsonProperty("token")
        private String token;
        @Data
        public static class Info {
            @JsonProperty("in")
            private String in;
            @JsonProperty("out")
            private String out;
        }

        @Data
        public static class Pay {
            @JsonProperty("in")
            private String in;
            @JsonProperty("out")
            private String out;
        }

        @Data
        public static class Sales {
            @JsonProperty("in")
            private String in;
            @JsonProperty("out")
            private String out;
        }
    }

    @Data
    public static class Mts {
        @JsonProperty("money")
        private Money money;
        @Data
        public static class Money{
            @JsonProperty("gate")
            private String gate;
        }
    }

    @Data
    public static class Sms {
        @JsonProperty("url")
        private String url;
    }

    @Data
    public static class Springdoc {
        @JsonProperty("author")
        private String author;
        @JsonProperty("title")
        private String title;
        @JsonProperty("version")
        private String version;
    }

    @Data
    public static class External {
        @JsonProperty("ftb-dbo")
        private FtdDbo ftdDbo;
        @Data
        public static class FtdDbo {
            @JsonProperty("base-url")
            private String baseUrl;
            @JsonProperty("client-id")
            private String clientId;
            @JsonProperty("connect-timeout")
            private String connectTimeout;
            @JsonProperty("pool-size")
            private String poolSize;
            @JsonProperty("read-timeout")
            private String readTimeout;
            @JsonProperty("proxy")
            private Proxy proxy;
            @JsonProperty("ssl")
            private Ssl ssl;
            @Data
            public static class Proxy{
                @JsonProperty("host")
                private String host;
                @JsonProperty("port")
                private String port;
            }
            @Data
            public static class Ssl{
                @JsonProperty("key-password")
                private String keypassword;
                @JsonProperty("key-store")
                private String keystore;
                @JsonProperty("key-store-password")
                private String keystorepassword;
                @JsonProperty("trust-store")
                private String truststore;
                @JsonProperty("trust-store-password")
                private String truststorepassword;
                @JsonProperty("trust-cert")
                private String trustcert;
            }
        }
    }
}
