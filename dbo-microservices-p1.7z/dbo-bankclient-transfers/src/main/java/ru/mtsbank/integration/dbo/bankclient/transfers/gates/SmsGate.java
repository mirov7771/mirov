package ru.mtsbank.integration.dbo.bankclient.transfers.gates;

import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public interface SmsGate {

    String execute(String token, String type, Long rboId) throws IOException;

}