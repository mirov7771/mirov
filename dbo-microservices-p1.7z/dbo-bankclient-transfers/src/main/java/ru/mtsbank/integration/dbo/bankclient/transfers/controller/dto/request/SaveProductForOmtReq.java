package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseRequest;

@Getter
@Setter
public class SaveProductForOmtReq extends BaseRequest {

    @JsonProperty("rboId")
    private Long rboId;
    @JsonProperty("isEnabled")
    private Boolean isEnabled;
    @JsonProperty("linkValue")
    private String linkValue;
    @JsonProperty("linkType")
    private String linkType;
    @JsonProperty("bindingId")
    private String bindingId;

}
