package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.ErrorResponse;

import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Slf4j
public class BaseResponse {

    @JsonIgnore
    private ErrorResponse errorResponse;

    @JsonProperty("requestId")
    private String requestId;

    public ErrorResponse createError(Integer code, String message, int httpCode, String externalCode, String details, String service, String requestId){
        String uid = StringUtils.isEmpty(requestId) ? UUID.randomUUID().toString() : requestId;
        log.error(uid+"\rError in service "+service+"\r Message "+message+" \r Code"+code);
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setError(
                new ErrorResponse.Error(code, message, uid, externalCode, details, httpCode)
        );
        this.errorResponse = errorResponse;
        return errorResponse;
    }

}


