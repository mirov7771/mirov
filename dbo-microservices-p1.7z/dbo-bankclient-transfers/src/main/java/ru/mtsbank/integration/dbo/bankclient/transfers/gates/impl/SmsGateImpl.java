package ru.mtsbank.integration.dbo.bankclient.transfers.gates.impl;

import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.mtsbank.integration.dbo.bankclient.transfers.config.ApplicationConfig;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.SmsGate;

import java.io.IOException;

@Service
@Slf4j
public class SmsGateImpl implements SmsGate {

    private static ApplicationConfig.Sms sms;

    public SmsGateImpl(ApplicationConfig applicationConfig) {
        sms = applicationConfig.getSms();
    }

    private final OkHttpClient httpClient = new OkHttpClient();
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    @Override
    public String execute(String token, String type, Long rboId) throws IOException {
        JsonObject param = new JsonObject();
        param.addProperty("otpToken",token);
        param.addProperty("type", type);
        param.addProperty("rboId",rboId);
        RequestBody requestBody = RequestBody.create(JSON, param.toString());
        String url = sms.getUrl();
        log.info("Call "+url+" with params "+param.toString());
        Request request = new Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json")
                .post(requestBody)
                .build();
        Response response = httpClient.newCall(request).execute();
        String ret = "BAD_ANSWER";
        if (response != null){
            String answer = response.body().string();
            log.info("Receive answer from sms service "+answer);
            if (answer.contains("true"))
                ret = "GOOD_ANSWER";
        }
        return ret;
    }
}
