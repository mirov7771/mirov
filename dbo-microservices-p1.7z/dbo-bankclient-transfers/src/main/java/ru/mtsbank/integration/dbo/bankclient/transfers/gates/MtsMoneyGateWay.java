package ru.mtsbank.integration.dbo.bankclient.transfers.gates;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Service
public interface MtsMoneyGateWay {

    Map<String, Object> getApi(String method, String paramName, List<String> paramValues) throws IOException;
    String getProductList(String method, List<String> rboId) throws IOException;

}
