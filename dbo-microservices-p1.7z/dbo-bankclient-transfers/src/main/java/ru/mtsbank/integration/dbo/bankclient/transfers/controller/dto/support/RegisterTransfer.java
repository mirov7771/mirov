package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport.Source;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport.Target;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.ThsSupport.TransferParams;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@Builder
public class RegisterTransfer {

    @JsonProperty("rqid")
    private String rqid;
    @JsonProperty("transferId")
    private String transferId;
    @JsonProperty("transferType")
    private String transferType;
    @JsonProperty("transferAmount")
    private BigDecimal transferAmount;
    @JsonProperty("feeAmount")
    private BigDecimal feeAmount;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("source")
    private Source source;
    @JsonProperty("target")
    private Target target;
    @JsonProperty("transferParams")
    private TransferParams transferParams;


}
