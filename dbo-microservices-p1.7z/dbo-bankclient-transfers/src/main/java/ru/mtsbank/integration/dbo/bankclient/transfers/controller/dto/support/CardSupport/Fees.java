package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.CardSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class Fees {

    @JsonProperty("byProcessing")
    private String byProcessing;
    @JsonProperty("totalAmount")
    private Float totalAmount;
}
