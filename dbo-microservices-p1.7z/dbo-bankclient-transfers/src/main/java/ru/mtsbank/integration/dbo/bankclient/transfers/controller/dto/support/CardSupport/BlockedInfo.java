package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.CardSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class BlockedInfo {

    @JsonProperty("channel")
    private String channel;
    @JsonProperty("date")
    private String date;        //DDMMYYYYHH24MISS
}
