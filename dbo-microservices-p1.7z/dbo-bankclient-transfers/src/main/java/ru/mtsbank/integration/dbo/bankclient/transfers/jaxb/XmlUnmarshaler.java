package ru.mtsbank.integration.dbo.bankclient.transfers.jaxb;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringWriter;

@Component
@Slf4j
public class XmlUnmarshaler {

    @Autowired
    private JaxbContextCache jaxbContextCache;

    public <T> T parse(Class<T> clazz, String xml) {

        if (StringUtils.isEmpty(xml)) {
            return null;
        }
        try {
            byte[] bytes = xml.getBytes();
            JAXBContext jaxbContext = jaxbContextCache.get(clazz);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            T unmarshal = (T) unmarshaller
                  .unmarshal(IOUtils.toInputStream(new String(bytes, "UTF-8"), "UTF-8"));
            return unmarshal;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    public <T> String createXml(T input) {

        try {
            Class clazz = input.getClass();
            JAXBContext jaxbContext = jaxbContextCache.get(clazz);
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            StringWriter sw = new StringWriter();
            marshaller.marshal(input, sw);
            String xml = sw.toString();
            xml = StringUtils.replace(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>", "");
            xml = StringUtils.replace(xml, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            return xml;
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }
}