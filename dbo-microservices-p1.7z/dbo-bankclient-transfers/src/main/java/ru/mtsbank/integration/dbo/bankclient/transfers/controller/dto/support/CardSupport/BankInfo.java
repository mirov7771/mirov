package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.CardSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class BankInfo {

    @JsonProperty("name")
    private String name;
    @JsonProperty("tin")
    private String tin;
    @JsonProperty("inn")
    private String inn;
    @JsonProperty("rrc")
    private String rrc;
    @JsonProperty("kpp")
    private String kpp;
    @JsonProperty("bic")
    private String bic;
    @JsonProperty("corrAccount")
    private String corrAccount;
    @JsonProperty("branchId")
    private String branchId;
    @JsonProperty("agencyId")
    private String agencyId;


}
