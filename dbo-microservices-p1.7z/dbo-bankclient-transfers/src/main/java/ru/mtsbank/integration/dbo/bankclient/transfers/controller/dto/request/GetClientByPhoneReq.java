package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Phone;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseRequest;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.TransferException;

import java.util.ArrayList;
import java.util.Objects;

import static ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils.castPhone;

@Getter
@Setter
public class GetClientByPhoneReq extends BaseRequest {

    @JsonProperty("phoneList")
    private ArrayList<Phone> phoneList;
    @JsonProperty("phone")
    private String phone;

    @Override
    public void checkInputParams() throws TransferException {
        if (StringUtils.isEmpty(phone) && CollectionUtils.isEmpty(phoneList))
            throw new TransferException(101,400,"Не передан номер телефона",null,"GetClientByPhone");
        if (CollectionUtils.isEmpty(phoneList)
                && (StringUtils.isEmpty(castPhone(phone))
                || StringUtils.isEmpty((castPhone(super.getSrcPhone())))
                || Objects.equals(castPhone(phone), castPhone(super.getSrcPhone()))))
            throw new TransferException(1109,422,"Запрошен перевод по телефону на собственный аккаунт",null,"GetClientByPhone");
    }
}
