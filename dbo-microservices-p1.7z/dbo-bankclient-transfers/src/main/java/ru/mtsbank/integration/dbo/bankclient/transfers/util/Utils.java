package ru.mtsbank.integration.dbo.bankclient.transfers.util;

import org.springframework.util.StringUtils;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Utils {

    public static String castPhone(String phone){
        if (StringUtils.isEmpty(phone))
            return null;
        switch(phone.charAt(0))
        {
            case '7' :
            case '8' : return "+7" + phone.substring(1);
            case '9' : return "+7" + phone;
            case '+' : return phone;
            default: return null;
        }
    }

    public static String formatPhone(String phone){
        String retPhone = phone;
        if (!StringUtils.isEmpty(retPhone)){
            if (retPhone.length() == 10)
                retPhone =  "7"+retPhone;
            else if (retPhone.startsWith("7") && retPhone.length() == 11)
                retPhone =  phone;
            else if (retPhone.startsWith("8") && retPhone.length() == 11)
                retPhone = "7"+phone.substring(1,11);
            else
                retPhone = phone;
        }
        return retPhone.replace("+", "");
    }

    public static XMLGregorianCalendar getXmlGregorianCalendar(Date date) {
        if (date == null) {
            return null;
        }
        GregorianCalendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").format(date));
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static BigDecimal devideSum(BigDecimal sum) {
        return sum.divide(new BigDecimal(100)).setScale(2, BigDecimal.ROUND_DOWN);
    }

    public static Date getDate(int year, int month, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static String formatName(String senderPAM) {
        String retVal;
        String[] items = senderPAM.split(" ");
        if (items.length >= 3){
            retVal = formatPart(items[0])+" ";
            retVal += formatPart(items[1])+" ";
            retVal += items[2].toUpperCase().charAt(0)+".";
        } else if (items.length == 2){
            retVal = formatPart(items[0])+" ";
            retVal += items[1].toUpperCase().charAt(0)+".";
        } else {
            retVal = formatPart(senderPAM);
        }
        return retVal;
    }

    private static String formatPart(String part){
        return part.substring(0,1).toUpperCase()+part.substring(1).toLowerCase();
    }

    public static Boolean isRub(String value){
        return ("RUR".equalsIgnoreCase(value) || "RUB".equalsIgnoreCase(value) || "810".equalsIgnoreCase(value) || "643".equalsIgnoreCase(value));
    }
}
