package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseRequest;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Getter @Setter
@ToString
@Slf4j
public class CheckTransferReq extends BaseRequest {

    @JsonProperty("srcCardHash")
    private String srcCardHash;
    @JsonProperty("srcCardExpiry")
    private String srcCardExpiry;
    @JsonProperty("srcBindingId")
    private String srcBindingId;
    @JsonProperty("srcAccountNumber")
    private String srcAccountNumber;
    @JsonProperty("recipientPhone")
    private String recipientPhone;
    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("userMessage")
    private String userMessage;
    @JsonProperty("clientId")
    private String clientId;
    @JsonProperty("senderPam")
    private String senderPam;
    @JsonProperty("senderPamShort")
    private String senderPamShort;

    public void setSenderPam(String token) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            String[] list = token.split("\\.");
            String lastPart = list[list.length - 1].replaceAll("-", "+").replaceAll("_", "/");
            String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
            Map<String, Object> outputParams;
            outputParams = mapper.readValue(decodePart, Map.class);
            if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
                Map<String, Object> userData = (HashMap) outputParams.get("user_data");
                if (userData.get("full_name") != null && userData.get("full_name") instanceof HashMap){
                    Map<String, String> fullName = (HashMap) userData.get("full_name");
                    String senderPam = fullName.get("first_name");
                    String senderPamShort = fullName.get("first_name");
                    if (!StringUtils.isEmpty(fullName.get("middle_name")))
                        senderPam += " "+fullName.get("middle_name");
                    if (!StringUtils.isEmpty(fullName.get("last_name"))) {
                        senderPam += " " + fullName.get("last_name");
                        senderPamShort += " " + fullName.get("last_name");
                    }
                    this.senderPam = Utils.formatName(senderPam);
                    this.senderPamShort = Utils.formatName(senderPamShort);
                }
            }
        } catch (IOException e){
            log.error("Error in sender pam from token "+e);
            e.printStackTrace();
        }
    }

}
