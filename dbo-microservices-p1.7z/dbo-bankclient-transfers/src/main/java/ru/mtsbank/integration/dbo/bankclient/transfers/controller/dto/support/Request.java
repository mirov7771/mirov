package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter @Setter
@Builder
public class Request {

    @JsonProperty("rboId")
    private Long rboId;
    @JsonProperty("srcBindingId")
    private String srcBindingId;
    @JsonProperty("srcCardHash")
    private String srcCardHash;
    @JsonProperty("srcCardExpire")
    private Date srcCardExpire;
    @JsonProperty("srcAccountNumber")
    private String srcAccountNumber;
    @JsonProperty("rcvSource")
    private String rcvSource;
    @JsonProperty("rcvType")
    private String rcvType;
    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("purpose")
    private String purpose;
    @JsonProperty("transferId")
    private Long transferId;
    @JsonProperty("isEnabled")
    private Boolean isEnabled;
    @JsonProperty("linkValue")
    private String linkValue;
    @JsonProperty("linkType")
    private String linkType;
    @JsonProperty("bindingId")
    private String bindingId;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("phoneList")
    private List<Phone> phoneList;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("documentId")
    private Long documentId;
    @JsonProperty("rcvName")
    private String rcvName;
    @JsonProperty("docExtId")
    private String docExtId;
    @JsonProperty("trnType")
    private Integer trnType;
    @JsonProperty("otpToken")
    private String otpToken;
    @JsonProperty("senderName")
    private String senderName;

}
