package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Comparator;
import java.util.Date;

@AllArgsConstructor
@Builder
@Getter @Setter
public class Product{
    private String id;
    private String value;
    private Date date;
    private String type;
    private Date expireDate;

    public static final Comparator<Product> COMPARE_BY_DATE = (o1, o2) -> o2.value.compareTo(o1.value);
}
