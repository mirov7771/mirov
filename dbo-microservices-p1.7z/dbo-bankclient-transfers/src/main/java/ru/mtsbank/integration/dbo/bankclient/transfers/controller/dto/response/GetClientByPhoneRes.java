package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Phone;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class GetClientByPhoneRes extends BaseResponse {

    @JsonProperty("name")
    private String name;
    @JsonProperty("surname")
    private String surname;
    @JsonProperty("patronymic")
    private String patronymic;

    @JsonProperty("clientName")
    private String clientName;
    @JsonProperty("permission")
    private Boolean permission;
    @JsonProperty("linkValue")
    private String linkValue;
    @JsonProperty("linkType")
    private String linkType;
    @JsonProperty("bindingId")
    private String bindingId;
    @JsonProperty("phoneList")
    private List<Phone> phoneList;

}
