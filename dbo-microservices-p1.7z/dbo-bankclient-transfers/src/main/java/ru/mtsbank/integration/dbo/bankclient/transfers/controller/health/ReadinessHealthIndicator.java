package ru.mtsbank.integration.dbo.bankclient.transfers.controller.health;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ReadinessHealthIndicator implements HealthIndicator {

    private boolean isHealthy = false;

    public ReadinessHealthIndicator() {
    }

    @Override
    public Health health() {
        isHealthy = true;
        return isHealthy ? Health.up().build() : Health.down().build();
    }
}
