package ru.mtsbank.integration.dbo.bankclient.transfers.builders;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.mts.xsd.CardListInq.CardListInqRq;
import ru.mtsbank.integration.mts.xsd.CardListInq.CustInfo;

import java.util.UUID;

@Component
public class CardListInqRqBuilder {

    public CardListInqRq cardListInqRq(String rboId){
        CardListInqRq cardListInqRq = new CardListInqRq();
        cardListInqRq.setBpId("MBR_EGAR_CRD_ALL");
        cardListInqRq.setRqUID(UUID.randomUUID().toString());
        cardListInqRq.setPCIDSS(true);
        cardListInqRq.setMsgType("CardListInqRq");
        cardListInqRq.setSPName("MTS_EIP_UMP");
        cardListInqRq.setMsgReceiver("RBO");
        CustInfo custInfo = new CustInfo();
        custInfo.setCustId(rboId);
        cardListInqRq.setCustInfo(custInfo);
        return cardListInqRq;
    }

}
