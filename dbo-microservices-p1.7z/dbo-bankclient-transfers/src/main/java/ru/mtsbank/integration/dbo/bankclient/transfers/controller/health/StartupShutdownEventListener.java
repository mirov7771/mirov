package ru.mtsbank.integration.dbo.bankclient.transfers.controller.health;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class StartupShutdownEventListener {

    @EventListener
    public void onStartup(ApplicationReadyEvent event) {
        try {
            log.info("Started DboBankClientTransferApplication");
        } catch (Exception e) {
            log.error("error: ", e);
        }
    }
}
