package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@Builder
public class StartTransfer {

    @JsonProperty("rqid")
    private String rqid;
    @JsonProperty("transferId")
    private String transferId;
}
