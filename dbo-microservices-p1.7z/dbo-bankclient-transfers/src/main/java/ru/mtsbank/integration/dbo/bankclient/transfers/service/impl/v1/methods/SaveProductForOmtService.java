package ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.SaveProductForOmtReq;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.SaveProductForOmtRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.TransferSettingRepository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.TransferSetting;

@Component("saveproductforomt")
@Slf4j
public class SaveProductForOmtService {

    @Autowired
    private TransferSettingRepository transferSettingRepository;

    @Transactional
    public SaveProductForOmtRes call(SaveProductForOmtReq req) {
        log.info("Start saveproductforomt");
        SaveProductForOmtRes res = new SaveProductForOmtRes();
        TransferSetting transferSetting = transferSettingRepository.findByRboId(req.getRboId());
        if (transferSetting == null){
            transferSetting = new TransferSetting();
            transferSetting.setRboId(req.getRboId());
        }
        transferSetting.setBindingId(req.getBindingId());
        transferSetting.setIsEnabled(req.getIsEnabled() ? 1 : 0);
        transferSetting.setLinkType(req.getLinkType());
        transferSetting.setLinkValue(req.getLinkValue());
        transferSettingRepository.save(transferSetting);
        log.info("End saveproductforomt");
        return res;
    }

}
