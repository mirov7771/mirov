package ru.mtsbank.integration.dbo.bankclient.transfers.gates.ths;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.ths.model.ThsResponse;

@Component
@RequiredArgsConstructor
@Slf4j
public class DBOServiceClient {

    private static final String GET_TRANSFER_STATE_URL = "/transfer_history/1.0/dbo-bankclient-transfers/";

    private final RestTemplate dboRestTemplate;

    public Integer call(String jsonString, String method) {
        Integer i = 1;
        String url = GET_TRANSFER_STATE_URL+method;
        log.info("***POST request*** "+url+" with params "+jsonString);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/json");

        HttpEntity<String> request =
                new HttpEntity<>(jsonString, headers);

        ThsResponse response = dboRestTemplate.postForObject(url, request,ThsResponse.class);
        if (response != null) {
            log.info("Get Response From THS " + response.toString());
            i = response.getErrorCode();
        }
        return i;
    }
}
