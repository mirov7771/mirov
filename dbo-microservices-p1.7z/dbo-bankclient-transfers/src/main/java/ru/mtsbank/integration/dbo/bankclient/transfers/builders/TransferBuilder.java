package ru.mtsbank.integration.dbo.bankclient.transfers.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Request;

import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.CheckTransferRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.CreateTransferRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Content;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.TransferRepository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.Transfer;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.TransferException;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.*;

import java.math.BigDecimal;
import java.util.Date;

import static ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils.*;
import static ru.mtsbank.integration.dbo.bankclient.transfers.util.Utils.getXmlGregorianCalendar;
import static ru.mtsbank.integration.mts.xsd.transferOperations.reqres.ExternalSystemTypeIntPayment.*;
import static ru.mtsbank.integration.mts.xsd.transferOperations.reqres.SimpleMsgTypeType.*;

@Component
@Slf4j
public class TransferBuilder {

    @Autowired
    private TransferRepository transferRepository;

    public TransferOperations getRequest(Request request, String uid){
        log.info("{} Method getRequest start",uid);
        TransferOperations transferOperations = new TransferOperations();
        transferOperations.setServerInfo(getServerInfo(request, uid));
        transferOperations.setBankSvcRq(getBankSvcRq(request));
        log.info("{} Method getRequest end",uid);
        return transferOperations;
    }

    public void getPreCheckResponse(CheckTransferRes res, TransferOperations operations, Request request, String uid) throws TransferException {
        if (operations != null
                && operations.getBankSvcRs() != null
                && operations.getBankSvcRs().getStatus() != null
        ){
            PreprocessInternalTransferResponse preprocessInternalTransfer = operations.getBankSvcRs().getPreprocessInternalTransfer();
            ExternalSystemStatus status = operations.getBankSvcRs().getStatus();
            long sc = status.getStatusCode();
            String scd = status.getStatusDesc();
            if (sc == 0 && preprocessInternalTransfer.getDocument() != null) {
                InternalDoc document = preprocessInternalTransfer.getDocument();
                res.setState(preprocessInternalTransfer.getStatus().value());
                if (request.getTrnType().equals(0)) {
                    res.setTransferId(document.getDocExtId());
                    BigDecimal fee = BigDecimal.ZERO;
                    BigDecimal amt = request.getAmount();
                    if (document.getAdditionalFieldList() != null
                            && !CollectionUtils.isEmpty(document.getAdditionalFieldList().getAdditionalField())) {
                        for (Field item : document.getAdditionalFieldList().getAdditionalField()) {
                            if (item.getName().equalsIgnoreCase("TransferFeeAmt")) {
                                fee = devideSum(new BigDecimal(item.getValue()));
                                amt = amt.add(fee);
                                break;
                            }
                        }
                    }
                    res.setTransferFeeAmt(fee);
                    res.setTransferTotalAmt(amt);

                    transferRepository.save(new Transfer(new Date()
                            , preprocessInternalTransfer.getDocument().getDocNumber()
                            , preprocessInternalTransfer.getDocument().getDocumentId()
                            , request.getRboId()
                            , getSrcType(request).value()
                            , getSrc(request)
                            , request.getSrcCardExpire()
                            , request.getAmount()
                            , request.getRcvName()
                            , request.getRcvType()
                            , request.getRcvSource()
                            , request.getPurpose()
                            , request.getPhone()
                            , preprocessInternalTransfer.getDocument().getDocExtId()
                            , fee
                            , amt
                            , preprocessInternalTransfer.getStatus().value()
                            , request.getSenderName()));
                }
            } else {
                if (sc == 8003 || sc == 8004 || sc == 8006 || sc == 8010 || sc == 8012 || sc == 8014)
                    throw new TransferException(1110,410,"Операция отклонена банком.",null,uid);
                else if (sc == 8002)
                    throw new TransferException(1111,409,"Истек срок действия карты.",null,uid);
                else if (sc == 8011 || sc == 3333)
                    throw new TransferException(1112,409,"Недостаточно средств для совершения перевода.",null,uid);
                else if (sc == 8022)
                    throw new TransferException(1113,406,"Указаны некорректные реквизиты счета.",null,uid);
                else if (sc == 8009 || sc == 8023)
                    throw new TransferException(1114,406,"Указаны некорректные реквизиты счета.",null,uid);
                else if (sc == 8008)
                    throw new TransferException(1115,409,"Указанная сумма не удовлетворяет установленным лимитам.",null,uid);
                else
                    throw new TransferException(1199,424,"Неизвестная ошибка платежной системы",scd,uid);
            }
        } else {
            throw new TransferException(1199,424,"PHUB error",null,uid);
        }
    }

    public String getPreCheckResponse(TransferOperations operations, Request request){
        String retStatus = "ERROR";
        if (operations != null
                && operations.getBankSvcRs() != null
                && operations.getBankSvcRs().getStatus() != null)
        {
            PreprocessInternalTransferResponse preprocessInternalTransfer = operations.getBankSvcRs().getPreprocessInternalTransfer();
            ExternalSystemStatus status = operations.getBankSvcRs().getStatus();
            long sc = status.getStatusCode();
            if (sc == 0 && preprocessInternalTransfer.getStatus() != null && request.getTrnType().equals(1)) {
                retStatus = preprocessInternalTransfer.getStatus().value();
            }
        }
        return retStatus;
    }

    public void getTrnResponse(TransferOperations operations, CreateTransferRes res){
        if (operations != null
                && operations.getBankSvcRs() != null
                && operations.getBankSvcRs().getInternalTransfer() != null
                && operations.getBankSvcRs().getInternalTransfer().getStatus() != null){
            Content content = Content.builder()
                    .state(operations.getBankSvcRs().getInternalTransfer().getStatus().value())
                    .guid(operations.getServerInfo().getRqUID())
                    .build();
            res.setContent(content);
        }
    }

    private ExternalSystemRequest getBankSvcRq(Request request){
        ExternalSystemRequest rq = new ExternalSystemRequest();
        InternalDoc internalDoc = new InternalDoc();
        internalDoc.setType(OTHERCLIENT);
        internalDoc.setDocNumber(request.getDocumentId().toString());
        internalDoc.setDocumentId(getDocumentId(request));
        internalDoc.setClientExtId(request.getRboId().toString());
        internalDoc.setSourceProductType(getSrcType(request));
        internalDoc.setSourceProductId(getSrc(request));
        if (!StringUtils.isEmpty(request.getSrcCardExpire()))
            internalDoc.setCardExpiry(getXmlGregorianCalendar(request.getSrcCardExpire()));
        internalDoc.setCurrencyISOCode("643");
        BigDecimal amt = request.getAmount();
        internalDoc.setSum(amt);
        internalDoc.setDepositSum(amt);
        internalDoc.setTotalSum(amt);
        internalDoc.setDepositCurrencyISOCode("643");

        InternalDoc.AdditionalFieldList additionalFieldList = new InternalDoc.AdditionalFieldList();
        Field field = new Field();
        field.setValue("false");
        field.setName("receiverNotification");
        additionalFieldList.getAdditionalField().add(field);
        internalDoc.setAdditionalFieldList(additionalFieldList);

        if (request.getRcvName()!= null)
            internalDoc.setReceiverName(request.getRcvName());
        internalDoc.setReceiverProductType(getRcvType(request));
        internalDoc.setReceiverProductId(request.getRcvSource());
        if (request.getPurpose() != null)
            internalDoc.setPurpose(request.getPurpose());
        internalDoc.setRate(BigDecimal.ONE);
        if (request.getDocExtId() != null)
            internalDoc.setDocExtId(request.getDocExtId());
        if (request.getTrnType().equals(2)){
            InternalTransferRequest intReq = new InternalTransferRequest();
            intReq.setDocument(internalDoc);
            rq.setInternalTransfer(intReq);
        } else {
            PreprocessInternalTransferRequest preReq = new PreprocessInternalTransferRequest();
            preReq.setDocument(internalDoc);
            rq.setPreprocessInternalTransfer(preReq);
        }
        return rq;
    }

    private ServerInfo getServerInfo(Request request, String uid){
        ServerInfo serverInfo = new ServerInfo();
        serverInfo.setRqUID(uid);
        serverInfo.setMsgUID(uid);
        serverInfo.setSPName("MTS_EIP_UMP");
        serverInfo.setMsgReceiver("PHUB");
        if (request.getTrnType().equals(2))
            serverInfo.setMsgType(INTERNAL_TRANSFER);
        else if (request.getTrnType().equals(3)){
            serverInfo.setMsgType(GET_DOCUMENTS_STATE);
        } else
            serverInfo.setMsgType(PREPROCESS_INTERNAL_TRANSFER);
        serverInfo.setServerDt(getXmlGregorianCalendar(new Date()));
        return serverInfo;
    }


    private ExternalSystemProductType getSrcType(Request request){
        return request.getSrcCardHash() != null ?
                ExternalSystemProductType.CARD :
                ExternalSystemProductType.ACCOUNT;
    }

    private String getSrc(Request request){
        return request.getSrcCardHash() != null ?
                request.getSrcCardHash() :
                request.getSrcAccountNumber();
    }

    private String getDocumentId(Request request){
        return request.getChannel() != null ? request.getChannel()+"-"+request.getDocumentId() : request.getDocumentId().toString();
    }

    private ExternalSystemProductType getRcvType(Request request){
        String type = request.getRcvType();
        ExternalSystemProductType retType = ExternalSystemProductType.ACCOUNT;
        switch (type){
            case "CARD":
                retType = ExternalSystemProductType.CARD;
                break;
            case "ACCOUNT":
                retType = ExternalSystemProductType.ACCOUNT;
                break;
        }
        return retType;
    }
}
