package ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.Request;
import ru.mtsbank.integration.dbo.bankclient.transfers.builders.TransferBuilder;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.CreateTransferReq;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.CheckTransferRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.response.CreateTransferRes;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.StartTransfer;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.TransferRepository;
import ru.mtsbank.integration.dbo.bankclient.transfers.dao.model.Transfer;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.EsbGate;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.MtsMoneyGateWay;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.SmsGate;
import ru.mtsbank.integration.dbo.bankclient.transfers.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.bankclient.transfers.gates.ths.DBOServiceClient;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.TransferException;
import ru.mtsbank.integration.mts.xsd.transferOperations.reqres.TransferOperations;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

@Component("createtransfer")
@Slf4j
public class CreateTransferService {

    @Autowired
    private TransferBuilder transferBuilder;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private TransferRepository transferRepository;

    @Autowired
    private SmsGate smsGate;

    @Autowired
    private MtsMoneyGateWay mtsMoneyGateWay;

    @Autowired
    private DBOServiceClient dboServiceClient;

    private final ObjectMapper mapper = new ObjectMapper();

    public CreateTransferRes call(CreateTransferReq req) {
        log.info("Start createtransfer");
        CreateTransferRes res = new CreateTransferRes();
        String uid = UUID.randomUUID().toString();
        try{
            String token = smsGate.execute(req.getOtpToken(), "internaltransfer", req.getRboID());
            log.info("SMS confirm result {}",token);
            checkToken(token);
            String channel = "IB";
            if (!StringUtils.isEmpty(req.getClientId())){
                channel = req.getClientId().contains("ios") ? "IOS" : "ANDR";
            }
            Transfer transfer = validateTransfer(transferRepository.findByDocExtIdAndClientExtId(req.getTransferId(), req.getRboID()));

            Request req1;

            BigDecimal amount = transfer.getAmount().setScale(0, RoundingMode.HALF_UP);
            log.info("*** internal amount "+amount);
            req1 = Request.builder()
                     .rboId(transfer.getClientExtId())
                     .rcvSource(transfer.getRcvId())
                     .rcvType(transfer.getRcvType())
                     .rcvName("MTS HUB")
                     .phone(transfer.getRcvPhone())
                     .amount(amount)
                     .channel(channel)
                     .documentId(transfer.getTransferId())
                     .trnType(1)
                     .docExtId(transfer.getDocExtId())
                     .build();

            if (transfer.getSrcType().equals("CARD")){
                req1.setSrcCardExpire(transfer.getCardExpiry());
                req1.setSrcCardHash(transfer.getSrcId());
            } else {
                req1.setSrcAccountNumber(transfer.getSrcId());
            }

            //PREPROCESS
            String answer = esbGate.sendPayMessageWithAnswer(
                    xmlUnmarshaler.createXml(transferBuilder.getRequest(req1, uid))
            );
            validateAnswer(answer, "payment");

            TransferOperations oper = xmlUnmarshaler.parse(TransferOperations.class, answer);
            validateAnswer(transferBuilder.getPreCheckResponse(oper, req1), "status");

            req1.setTrnType(2);
            answer = esbGate.sendPayMessageWithAnswer(
                    xmlUnmarshaler.createXml(transferBuilder.getRequest(req1, uid))
            );

            if (!StringUtils.isEmpty(answer)) {
                oper = xmlUnmarshaler.parse(TransferOperations.class, answer);
                transferBuilder.getTrnResponse(oper, res);
            } else {
                res.createError(107, "Сервис временно недоступен", 501, null, "!StringUtils.isEmpty(answer)", "CreateTransfer", uid);
            }

            StartTransfer startTransfer = StartTransfer.builder()
                    .rqid(uid)
                    .transferId(req.getTransferId())
                    .build();
            String ths = mapper.writeValueAsString(startTransfer);
            log.info("Start save operation in THS - create "+ths);
            Integer answerFromThs = dboServiceClient.call(ths, "startTransfer");
            log.info("End save operation in THS - create "+answerFromThs);

            if (!answerFromThs.equals(0)){
                res.createError(1116, "Не удалось выполнить сохранение операции", 424, null, "No response from THS", "CheckTransfer", uid);
            }
        } catch (TransferException e){
            log.error("Error: "+e);
            res.createError(e.getCode(), e.getMessage(), e.getHttpCode(), null, e.getDetails(), e.getService(), uid);
            e.printStackTrace();
        } catch (IOException e){
            log.error("Error: "+e);
            res.createError(107, "Сервис временно недоступен", 501, null, "", "CreateTransfer", uid);
            e.printStackTrace();
        }
        log.info("End createtransfer");
        return res;
    }

    private void validateAnswer(String answer, String type) throws TransferException {
        if ("payment".equals(type)){
            if (StringUtils.isEmpty(answer))
                throw new TransferException(107, 501, "Сервис временно недоступен", "", "CreateTransfer");
        } else if ("status".equals(type)){
            if (!"VERIFIED".equals(answer))
                throw new TransferException(1120, 424, "Ошибка подтверждения перевода", "", "CreateTransfer");
        }
    }

    private Transfer validateTransfer(Transfer transfer) throws TransferException {
        if (transfer == null)
            throw new TransferException(1117, 406, "Перевод с указанным идентификатором не найден", "", "CreateTransfer");
        return transfer;
    }

    private void checkToken(String token) throws TransferException {
        if (!(!StringUtils.isEmpty(token) && "GOOD_ANSWER".equalsIgnoreCase(token)))
            throw new TransferException(1120,424, "Ошибка подтверждения перевода","","CreateTransfer");
    }

}
