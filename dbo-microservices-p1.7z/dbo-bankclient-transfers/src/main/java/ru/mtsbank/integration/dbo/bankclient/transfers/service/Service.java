package ru.mtsbank.integration.dbo.bankclient.transfers.service;

import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.*;

public interface Service {

    BaseResponse checkTransfer(CheckTransferReq req);
    BaseResponse createTransfer(CreateTransferReq req);
    BaseResponse getClientByPhone(GetClientByPhoneReq req);
    BaseResponse saveProductForOmt(SaveProductForOmtReq req);
}
