package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.support.CardSupport.*;

@Builder
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties
public class Card {

    @JsonProperty("agreement")
    private String agreement;
    @JsonProperty("bankInfo")
    private BankInfo bankInfo;
    @JsonProperty("blockedInfo")
    private BlockedInfo blockedInfo;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("embossedName")
    private String embossedName;
    @JsonProperty("fees")
    private Fees fees;
    @JsonProperty("hashPan")
    private String hashPan;
    @JsonProperty("id")
    private String id;
    @JsonProperty("isMainCard")
    private Boolean isMainCard;
    @JsonProperty("issueDate")
    private String issueDate;
    @JsonProperty("mainCardInfo")
    private MainCardInfo mainCardInfo;
    @JsonProperty("number")
    private String number;
    @JsonProperty("ownerRboId")
    private String ownerRboId;
    @JsonProperty("pan")
    private String pan;
    @JsonProperty("paymentSystem")
    private String paymentSystem;
    @JsonProperty("productInfo")
    private ProductInfo productInfo;
    @JsonProperty("validThru")
    private String validThru;
    @JsonProperty("planCloseDate")
    private String planCloseDate;

}
