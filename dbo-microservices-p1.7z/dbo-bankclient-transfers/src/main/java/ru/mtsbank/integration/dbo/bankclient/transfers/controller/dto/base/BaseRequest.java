package ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods.CheckTransferService;
import ru.mtsbank.integration.dbo.bankclient.transfers.util.TransferException;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Getter
@Slf4j
public class BaseRequest {

    private static final ObjectMapper mapper = new ObjectMapper();

    @JsonProperty("rboId")
    private Long rboID;
    @JsonProperty("srcPhone")
    private String srcPhone;

    public void setRboID(String rboID, String token){
        Long rboIdToSet = 0L;
        if (!StringUtils.isEmpty(token)){
            rboIdToSet = getRboIdFromToken(token);
        }
        if (!rboIdToSet.equals(0L)){
            log.info("set rbo_id from token "+rboIdToSet);
            this.rboID = rboIdToSet;
        } else if (!StringUtils.isEmpty(rboID)){
            log.info("set rbo_id from header "+rboID);
            this.rboID = Long.valueOf(rboID);
        }
    }

    public void setSrcPhone(String phone, String token){
        String srcPhoneToSet = "";
        if (!StringUtils.isEmpty(token)){
            log.info("set phone from token "+srcPhoneToSet);
            srcPhoneToSet = getSrcPhoneFromToken(token);
        }
        if (!StringUtils.isEmpty(srcPhoneToSet)){
            log.info("set phone from token "+srcPhoneToSet);
            this.srcPhone = srcPhoneToSet;
        } else if (!StringUtils.isEmpty(phone)) {
            log.info("set phone from header "+phone);
            this.srcPhone = phone;
        }
    }

    private String getSrcPhoneFromToken(String token) {
        String phone = "";
        try {
            String[] list = token.split("\\.");
            String lastPart = list[list.length - 1].replaceAll("-","+").replaceAll("_","/");
            log.info("Search rbo id in token "+lastPart);
            String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
            Map<String, Object> outputParams;
            outputParams = mapper.readValue(decodePart, Map.class);
            if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
                Map<String, Object> userData = (HashMap) outputParams.get("user_data");
                String phoneNumber = getPhoneFromXor(userData.get("phone_number"));
                phone = phoneNumber;
            }
        } catch (IOException | IllegalArgumentException e){
            log.error("Error in getting phone from token "+e);
            e.printStackTrace();
        }
        return phone;
    }

    private String getPhoneFromXor(Object phone_number) {
        String retVal = null;
        if (phone_number != null) {
            String value = (String) phone_number;
            if (!StringUtils.isEmpty(value)) {
                String key = "mts-bank-platform";
                char[] decodedPhoneNumberChars = new char[value.length()];
                for (int i = 0; i < value.length(); i++) {
                    decodedPhoneNumberChars[i] = (char) (value.charAt(i) ^ key.charAt(i % key.length()));
                }
                retVal = new String(decodedPhoneNumberChars);
            }
        }
        return retVal;
    }

    private Long getRboIdFromToken(String token){
        long ret = 0L;
        try {
            String[] list = token.split("\\.");
            String lastPart = list[list.length - 1].replaceAll("-","+").replaceAll("_","/");
            log.info("Search rbo id in token "+lastPart);
            String decodePart = new String(Base64.getDecoder().decode(lastPart.getBytes()));
            Map<String, Object> outputParams;
            outputParams = mapper.readValue(decodePart, Map.class);
            if (outputParams.get("user_data") != null && outputParams.get("user_data") instanceof HashMap) {
                Map<String, Object> userData = (HashMap) outputParams.get("user_data");
                String rboId = (String) userData.get("rbo_id");
                ret = Long.parseLong(rboId);
            }
        } catch (IOException | IllegalArgumentException e){
            log.error("Error in getting rboId from token "+e);
            e.printStackTrace();
        }
        return ret;
    }

    public void checkInputParams() throws TransferException {

    }


}
