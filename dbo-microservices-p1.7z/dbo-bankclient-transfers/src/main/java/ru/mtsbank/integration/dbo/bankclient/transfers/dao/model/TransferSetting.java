package ru.mtsbank.integration.dbo.bankclient.transfers.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "TRANSFERSETTING")
@Getter @Setter
public class TransferSetting {

    @Id
    @Column(name = "RBOID")
    private Long rboId;
    @Column(name = "ISENABLED")
    private Integer isEnabled;
    @Column(name = "LINKVALUE")
    private String linkValue;
    @Column(name = "LINKTYPE")
    private String linkType;
    @Column(name =  "BINDINGID")
    private String bindingId;
    @Column(name = "PHONENUMBER")
    private String phoneNumber;
    @Column(name = "RECIPIENTPAM")
    private String recipientPAM;
    @Column(name = "RECIPIENTPAMSHORT")
    private String recipientPAMShort;
    @Column(name = "EXPIREDATE")
    private Date expireDate;

}
