package ru.mtsbank.integration.dbo.bankclient.transfers.gates.ths.model;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ThsResponse {

    private String rqid;
    private Integer errorCode;
    private String errorCause;

    @Override
    public String toString() {
        return "RqId:"+this.rqid+" errorCode:"+this.errorCode+" errorCause:"+this.errorCause;
    }
}
