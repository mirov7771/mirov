package ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.base.BaseResponse;
import ru.mtsbank.integration.dbo.bankclient.transfers.controller.dto.request.*;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.Service;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods.CheckTransferService;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods.CreateTransferService;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods.GetClientByPhoneService;
import ru.mtsbank.integration.dbo.bankclient.transfers.service.impl.v1.methods.SaveProductForOmtService;

@Component("v1")
public class ServiceV1Impl implements Service {

    private final CheckTransferService checkTransferService;
    private final CreateTransferService createTransferService;
    private final GetClientByPhoneService getClientByPhoneService;
    private final SaveProductForOmtService saveProductForOmtService;

    @Autowired
    public ServiceV1Impl(CheckTransferService checkTransferService,
                         CreateTransferService createTransferService,
                         GetClientByPhoneService getClientByPhoneService,
                         SaveProductForOmtService saveProductForOmtService)
    {
        this.checkTransferService = checkTransferService;
        this.createTransferService = createTransferService;
        this.getClientByPhoneService = getClientByPhoneService;
        this.saveProductForOmtService = saveProductForOmtService;
    }

    @Override
    public BaseResponse checkTransfer(CheckTransferReq req) {
        return checkTransferService.call(req);
    }

    @Override
    public BaseResponse createTransfer(CreateTransferReq req) {
        return createTransferService.call(req);
    }

    @Override
    public BaseResponse getClientByPhone(GetClientByPhoneReq req) {
        return getClientByPhoneService.call(req);
    }

    @Override
    public BaseResponse saveProductForOmt(SaveProductForOmtReq req) {
        return saveProductForOmtService.call(req);
    }

}
