-- Table: public.transfer

-- DROP TABLE public.transfer;

CREATE TABLE public.transfer
(
    transferid bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    docnumber character varying(255) COLLATE pg_catalog."default",
    documentid character varying(255) COLLATE pg_catalog."default",
    trndate timestamp without time zone,
    clientextid bigint,
    srctype character varying(50) COLLATE pg_catalog."default",
    srcid character varying(50) COLLATE pg_catalog."default",
    cardexpiry date,
    amount numeric(38,2),
    rcvname character varying(255) COLLATE pg_catalog."default",
    rcvtype character varying(50) COLLATE pg_catalog."default",
    rcvid character varying(50) COLLATE pg_catalog."default",
    purpose character varying(255) COLLATE pg_catalog."default",
    rcvphone character varying(25) COLLATE pg_catalog."default",
    docextid character varying(150) COLLATE pg_catalog."default",
    feeamt numeric(38,2),
    totalamt numeric(38,2),
    state character varying(150) COLLATE pg_catalog."default"
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.transfer
    OWNER to postgres;
-- Index: x1_transfer

-- DROP INDEX public.x1_transfer;

CREATE INDEX x1_transfer
    ON public.transfer USING btree
    (transferid ASC NULLS LAST, clientextid ASC NULLS LAST)
    TABLESPACE pg_default;

-- Table: public.transfersetting

-- DROP TABLE public.transfersetting;

CREATE TABLE public.transfersetting
(
    rboid bigint,
    isenabled smallint,
    linkvalue character varying(150) COLLATE pg_catalog."default",
    linktype character varying(70) COLLATE pg_catalog."default",
    bindingid character varying(150) COLLATE pg_catalog."default",
    phonenumber character varying(150) COLLATE pg_catalog."default",
    recipientpam character varying(150) COLLATE pg_catalog."default",
    recipientpan character varying(150) COLLATE pg_catalog."default",
    expiredate date
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.transfersetting
    OWNER to postgres;
-- Index: x1_transfersetting

-- DROP INDEX public.x1_transfersetting;

CREATE INDEX x1_transfersetting
    ON public.transfersetting USING btree
    (rboid ASC NULLS LAST)
    TABLESPACE pg_default;

alter table transfer add sendername varchar(255) null;
alter table transfersetting add recipientpamshort varchar(255) null;