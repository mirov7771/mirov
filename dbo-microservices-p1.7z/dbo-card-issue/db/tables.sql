CREATE TABLE ISSUES
(
 ISSUEID BIGINT GENERATED ALWAYS AS IDENTITY
,REQUESTID VARCHAR(150) NULL
,CLIENTNAME VARCHAR(255)
,CLIENTDOC VARCHAR(255)
,PHONENUMBER VARCHAR(70)
,EMAIL VARCHAR(150) NULL
,CREATIONDATE TIMESTAMP
,TYPE VARCHAR(50)
,REQUESTSUMMA NUMERIC(38,2)
);

CREATE INDEX X1_ISSUES ON ISSUES(REQUESTID);

CREATE TABLE DELIVERYZONE
(
 ID BIGINT GENERATED ALWAYS AS IDENTITY
,ZONEID VARCHAR(150) NULL
,FIASCODE VARCHAR(255) NULL
,DELIVERYINTERVAL VARCHAR(255) NULL
,DELIVERYDAYS VARCHAR(255) NULL
);

CREATE INDEX X1_DELIVERYZONE ON DELIVERYZONE(ZONEID);
CREATE INDEX X2_DELIVERYZONE ON DELIVERYZONE(FIASCODE);

CREATE TABLE OPERATIONS
(
 OPERID BIGINT GENERATED ALWAYS AS IDENTITY
,HASHPAN VARCHAR(150) NULL
,OPERDATE TIMESTAMP NULL
)

CREATE INDEX X1_OPERATIONS ON OPERATIONS(HASHPAN);

alter table DELIVERYZONE add REGION varchar(255) null;
alter table DELIVERYZONE add DISTRICT varchar(255) null;
alter table DELIVERYZONE add CITY varchar(255) null;
alter table DELIVERYZONE add STATEPROV varchar(255) null;

------------------------------------------------------
CREATE TABLE TARIFF_CATEGORY
(
    CATEGORYID BIGINT,
    CATEGORYTYPE SMALLINT, --1 КАТЕГОРИЯ (КОМИССИИ, ЛИМИТЫ, ПРОЦЕНТЫ), 2 ПОДКАТЕГОРИИ, 3 ПОДКАТЕГОРИИ ПОДКАТЕГОРИЙ
    PARENTCATEGORYID BIGINT NULL,
    NAME VARCHAR(255),
    DESCRIPTION VARCHAR(255) NULL,
    POINT VARCHAR(50),
    SYSNAME VARCHAR(255) NULL
);

CREATE INDEX X1_TARIFF_CATEGORY ON TARIFF_CATEGORY(CATEGORYID);

CREATE TABLE TARIFF_TYPE
(
    PRODCODE VARCHAR(255),
    TARIFFNUMBER VARCHAR(150)
);

CREATE INDEX X1_TARIFF_TYPE ON TARIFF_TYPE(PRODCODE);

CREATE TABLE TARIFF_VALUE
(
    ID BIGINT GENERATED ALWAYS AS IDENTITY,
    TARIFFNUMBER VARCHAR(150),
    CATEGORYID BIGINT NULL,
    SYSNAME VARCHAR(255) NULL,
    VALUE TEXT NULL
);

CREATE INDEX X1_TARIFF_VALUE ON TARIFF_VALUE(TARIFFNUMBER);

INSERT INTO TARIFF_TYPE VALUES('70. МТС Smart Деньги неим','70');
INSERT INTO TARIFF_TYPE VALUES('70_MC_World CashbackPP неим МТС Деньги RUR','70');
INSERT INTO TARIFF_TYPE VALUES('71_MC_World Weekend PP МТС Деньги Weekend RUR','71');
INSERT INTO TARIFF_TYPE VALUES('71_MC_World Weekend PP неим МТС Деньги Weekend RUR','71');
INSERT INTO TARIFF_TYPE VALUES('72_MC World Weekend Pay Pass RUR','72');
INSERT INTO TARIFF_TYPE VALUES('72_MC World Weekend Pay Pass неим RUR','72');
INSERT INTO TARIFF_TYPE VALUES('73_MC_World Weekend МТС Деньги RUR','73');
INSERT INTO TARIFF_TYPE VALUES('73_MC_World Weekend МТС Деньги RUR неим','73');
INSERT INTO TARIFF_TYPE VALUES('74_VisaClassic RUR МТС Деньги Weekend RUR для ипотеки','74');
INSERT INTO TARIFF_TYPE VALUES('74_VisaClassic неим RUR МТС Деньги Weekend RUR для ипотеки','74');
INSERT INTO TARIFF_TYPE VALUES('75. Visa Prepaid Детский Мир','75');
INSERT INTO TARIFF_TYPE VALUES('76. MasterCard World DM Детский Мир','76');
INSERT INTO TARIFF_TYPE VALUES('76. MasterCard World DM неим Детский Мир','76');
INSERT INTO TARIFF_TYPE VALUES('77_MC Platinum МТС Smart Деньги','77');
INSERT INTO TARIFF_TYPE VALUES('77_MC_World CashbackPP МТС Деньги RUR','77');
INSERT INTO TARIFF_TYPE VALUES('77_MC_World CashbackPP неим МТС Деньги RUR','77');
INSERT INTO TARIFF_TYPE VALUES('77_МТС Smart Деньги','77');
INSERT INTO TARIFF_TYPE VALUES('78_MC_Standard RUR неим 78. МТС Деньги ZERO','78');
INSERT INTO TARIFF_TYPE VALUES('78_MC_Standard RUR 78. МТС Деньги ZERO','78');
INSERT INTO TARIFF_TYPE VALUES('81. WBE MTS Premium RUR','81');
INSERT INTO TARIFF_TYPE VALUES('82. Visa Infinite МТС Private Banking RUR','82');
INSERT INTO TARIFF_TYPE VALUES('82. Visa Infinite МТС Private Banking USD','82');
INSERT INTO TARIFF_TYPE VALUES('83_MC_World_Cashback_Virtual','83');
INSERT INTO TARIFF_TYPE VALUES('84_MC_World CashbackPP МТС Деньги RUR','84');
INSERT INTO TARIFF_TYPE VALUES('84_MC_World CashbackPP неим МТС Деньги RUR','84');
INSERT INTO TARIFF_TYPE VALUES('85.Prepaid CashBack Виртуальная','85');
INSERT INTO TARIFF_TYPE VALUES('MasterCard Gold EUR 1.1. CLUB CARD EUR','86 Gold');
INSERT INTO TARIFF_TYPE VALUES('MasterCard Gold RUR 1.1. CLUB CARD RUR','86 Gold');
INSERT INTO TARIFF_TYPE VALUES('MasterCard Gold USD 1.1. CLUB CARD USD','86 Gold');
INSERT INTO TARIFF_TYPE VALUES('MasterCard Platinum EUR 1.1. CLUB CARD EUR','86 Platinum');
INSERT INTO TARIFF_TYPE VALUES('MasterCard Platinum RUR 1.1. CLUB CARD RUR','86 Platinum');
INSERT INTO TARIFF_TYPE VALUES('MasterCard Platinum USD 1.1. CLUB CARD USD','86 Platinum');
INSERT INTO TARIFF_TYPE VALUES('Visa Gold RUR 1.1. CLUB CARD RUR','86 Gold');
INSERT INTO TARIFF_TYPE VALUES('Visa Gold USD 1.1. CLUB CARD USD','86 Gold');
INSERT INTO TARIFF_TYPE VALUES('Visa Platinum RUR 1.1. CLUB CARD RUR','86 Platinum');
INSERT INTO TARIFF_TYPE VALUES('Visa Platinum USD 1.1. CLUB CARD USD','86 Platinum');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT) VALUES(1,1,0,'Комиссии','1');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT) VALUES(2,1,0,'Лимиты снятия наличных','2');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT,SYSNAME) VALUES(3,1,0,'Проценты на остаток','3', 'rate_interestBalance');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT) VALUES(4,1,0,'Процентная ставка по кредиту','4');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT,SYSNAME) VALUES(5,1,0,'Кредитный лимит','5','rate_creditLimit');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT,SYSNAME) VALUES(6,1,0,'Доступ в Бизнес-залы аэропортов по программе Lounge Key','6','additional_loungeKey');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT,SYSNAME) VALUES(7,1,0,'Доступ в VIP-залы аэропортов по Программе Priority Pass','7','additional_priorityPass');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT,SYSNAME) VALUES(8,1,0,'Кэшбэк','8','additional_cashback');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT) VALUES(9,1,0,'Тарифы и условия','9');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,POINT,DESCRIPTION,SYSNAME) VALUES(50,2,9,'ссылка на подробные Условия и Тарифы','9_1','ссылка на страницу с подробными условиями тарифа','webLink');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(10,2,1,'За обслуживание карты',NULL,'1_1');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(25,3,10,'Оформление основной карты','комиссия за выпуск основной карты','1_1_1','comission_issueMainCard');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(26,3,10,'Оформление дополнительной карты','комиссия за выпуск дополнительной карты','1_1_2','comission_issueAdditionalCard');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(27,3,10,'Годовое обслуживание основной карты','годовое обслуживание основной карты','1_1_3','comission_annualPaymentMainCard');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(28,3,10,'Годовое обслуживание дополнительной карты','годовое обслуживание дополнительной карты','1_1_4','comission_annualPaymentAdditionalCard');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(29,3,10,'Обслуживание карты при наличии задолженности','комисиия за обслуживание карты при наличии задолженности','1_1_5','comission_servicePaymentDebt');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(30,3,10,'Условия обслуживания карты','условия обслуживания карты','1_1_6','cardServiceTerms');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(11,2,1,'За перевыпуск карты',NULL,'1_2');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(31,3,11,'По истечении срока действия карты','комиссия за перевыпуск карты по истечению срока действия','1_2_1','comission_cardRenewal');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(32,3,11,'По заявлению держателя карты','комисиия за перевыпуск карты по инициативе держателя карты','1_2_2','comission_cardRenewalCardholderInitiative');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(33,3,11,'В случае утери и кражи','комиссия за перевыпуск утерянной карты','1_2_3','comission_lostCardRenewal');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(12,2,1,'За снятие наличных с помощью карты','комиссия за получения наличных без использования карты','1_3');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(34,3,12,'В банкоматах МТС-Банк','комиссия за выдачу наличных в банкомате МТС-Банка','1_3_1','comission_fromAtm');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(35,3,12,'В кассах МТС-Банк','комиссия за выдачу наличных из кассы МТС-Банка','1_3_2','comission_fromCashDesk');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(36,3,12,'В банкоматах иных банков, в пределах РФ','комиссия за выдачу наличных в банкоматах иного банка в пределах РФ','1_3_3','comission_fromAtmOtherBanks');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(37,3,12,'В кассах иных банков, в пределах РФ','комиссия за выдачу наличных в кассах иного банка в пределах РФ','1_3_4','comission_fromCashDeskOtherBanks');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(38,3,12,'В банкоматах иных банков, за пределами РФ','комиссия за выдачу наличных в банкоматах иного банка за пределами РФ','1_3_5','comission_fromAtmOtherBanksAbroad');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(39,3,12,'В кассах иных банков, за пределами РФ','комиссия за выдачу наличных в кассах иного банка за пределами РФ','1_3_6','comission_fromCashDeskOtherBanksAbroad');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(13,2,1,'За снятие наличных без использования карты','комиссия за смс информирование','1_4','comission_cashWithoutCard');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(14,3,1,'За услугу SMS-Банк-Инфо',NULL,'1_5','comission_smsInfo');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(15,2,2,'В банкоматах ПАО МТС Банк',NULL,'2_1');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(40,3,15,'Ежедневный','лимит на снятие наличных в банкомате МТС-Банка (ежедневный)','2_1_1','limits_fromAtmDay');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(41,3,15,'Ежемесячный','лимит на снятие наличных в банкомате МТС-Банка (ежемесячный)','2_1_2','limits_fromAtmMonth');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(16,2,2,'В кассе ПАО МТС Банк',NULL,'2_2');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(42,2,16,'В кассе ПАО МТС Банк',NULL,'2_2_1','limits_fromCashDeskDay');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(43,2,16,'В кассе ПАО МТС Банк',NULL,'2_2_2','limits_fromCashDeskMonth');


INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(17,2,2,'В банкоматах стороннего банка',NULL,'2_3');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(44,3,17,'Ежедневный','лимит на снятие наличных из кассы МТС-Банка (ежедневный)','2_3_1','limits_fromAtmOtherBanksDay');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(45,3,17,'Ежемесячный','лимит на снятие наличных из кассы МТС-Банка (ежемесячный)','2_3_2','limits_fromAtmOtherBanksMonth');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT) VALUES(18,2,2,'В кассах стороннего банка',NULL,'2_4');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(46,3,18,'Ежедневный','лимит на снятие наличных из кассы стороннего банка (ежедневный)','2_4_1','limits_fromCashDeskOtherBanksDay');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(47,3,18,'Ежемесячный','лимит на снятие наличных из кассы стороннего банка (ежемесячный)','2_4_2','limits_fromCashDeskOtherBanksMonth');

INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(19,4,4,'Льготный период','льготный период','4_1','rate_gracePeriod');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(20,4,4,'На покупки в льготный период','ставка на покупки в льготный период','4_2','rate_gracePeriodTrue');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(21,4,4,'На покупки вне льготного периода','ставка на покупки при невыполнении условий Льготного периода кредитования','4_3','rate_gracePeriodFalse');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(22,4,4,'Минимальный платеж','минимальный платеж','4_4','rate_minPayment');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(23,4,4,'Просроченная задолженность','плата за пропуск минимального платежа','4_5','rate_skipMinPayment');
INSERT INTO TARIFF_CATEGORY(CATEGORYID,CATEGORYTYPE,PARENTCATEGORYID,NAME,DESCRIPTION,POINT,SYSNAME) VALUES(24,4,4,'Штраф за несоблюдение условий кредитного договора','штраф за несоблюдение условий кредитного договора','4_6','rate_violationCondition');



INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_issueMainCard','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_issueAdditionalCard','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_annualPaymentMainCard','Без комиссии - (при выполнении условий)<br>99 руб. - начиная с третьего месяца (при невыполнении условий)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_annualPaymentAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','cardServiceTerms','Сумма операций от 15 000 руб. или при поддержании неснижаемого остатка на карте и накопительном счете от 30 000 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_cardRenewalCardholderInitiative','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_lostCardRenewal','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_fromCashDeskOtherBanks','1% (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_fromAtmOtherBanksAbroad','1% (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_fromCashDeskOtherBanksAbroad','1% (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_cashWithoutCard','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','comission_smsInfo','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromAtmMonth','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromAtmOtherBanksMonth','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('71','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_issueAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_annualPaymentMainCard','900 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_annualPaymentAdditionalCard','900 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_cardRenewalCardholderInitiative','900 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_lostCardRenewal','900 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_fromAtm','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_fromCashDesk','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_fromAtmOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_fromCashDeskOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_fromAtmOtherBanksAbroad','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_fromCashDeskOtherBanksAbroad','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_cashWithoutCard','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromAtmMonth','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_gracePeriod','51 день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_gracePeriodFalse','23,9% - 27% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_minPayment','5% от суммы задолженности, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_skipMinPayment','36,5% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','rate_creditLimit','До 299 999 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('72','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_issueAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_annualPaymentAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_cardRenewalCardholderInitiative','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_lostCardRenewal','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_fromCashDeskOtherBanks','1% от суммы операции (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_fromAtmOtherBanksAbroad','1% от суммы операции (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_fromCashDeskOtherBanksAbroad','1% от суммы операции (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_cashWithoutCard','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','comission_smsInfo','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromAtmMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('73','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_issueAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_annualPaymentMainCard','Без комиссии -(при выполнении условий)</br>99 руб. - начиная с третьего месяца (при не выполнении условий)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_annualPaymentAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','cardServiceTerms','Сумма операций от 15 000 руб. или при поддержании неснижаемого остатка на карте и накопительном счете от 30 000 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_cardRenewalCardholderInitiative','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_lostCardRenewal','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_fromCashDeskOtherBanks','1% от суммы операции (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_fromAtmOtherBanksAbroad','1% от суммы операции (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_fromCashDeskOtherBanksAbroad','1% от суммы операции (мин. 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_cashWithoutCard','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','comission_smsInfo','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromAtmMonth','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('74','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('75','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('75','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('75','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('75','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_annualPaymentMainCard','Без комиссии - в течение первого календарного года;<br>590 руб.- в течение второго и последующих лет обслуживания.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_cardRenewalCardholderInitiative','590 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_lostCardRenewal','590 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_fromAtm','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_fromCashDesk','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_fromAtmOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_fromAtmOtherBanksAbroad','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_fromCashDeskOtherBanksAbroad','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_cashWithoutCard','В пределах остатка денежных средств 0,5% от суммы операции.<br>За счет Кредита Банка 4% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromAtmMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_gracePeriod','51 день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_gracePeriodFalse','24,9% - 27%');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_minPayment','5% от суммы задолженности, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_skipMinPayment','0,365');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','rate_creditLimit','До 299999 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('76','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_issueMainCard','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_servicePaymentDebt','30 руб. в день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_cardRenewalCardholderInitiative','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_lostCardRenewal','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_fromCashDeskOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_fromAtmOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_fromCashDeskOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_cashWithoutCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromAtmMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_gracePeriod','51 день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_gracePeriodFalse','10% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_minPayment','5% от суммы задолженности, но не менее 100 руб., но не менее 500 руб. + комиссия за обслуживание ');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_skipMinPayment','36,5% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','rate_creditLimit','20 000 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('78','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_lostCardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_fromAtm','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_fromCashDesk','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_fromAtmOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_fromCashDeskOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_fromAtmOtherBanksAbroad','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_fromCashDeskOtherBanksAbroad','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_cashWithoutCard','За счет собственных средств: Без комиссии<br>За счет Кредита Банка - 4% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','limits_fromAtmMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_gracePeriod','111 дней');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_gracePeriodFalse','11,9% - 25,9% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_minPayment','5% от суммы задолженности, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_skipMinPayment','36,5% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','rate_creditLimit','До 500 000 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('83','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_issueMainCard','299 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_lostCardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_fromAtm','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_fromCashDesk','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_fromAtmOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_fromCashDeskOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_fromAtmOtherBanksAbroad','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_fromCashDeskOtherBanksAbroad','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_cashWithoutCard','За счет собственных средств: Без комиссии<br>За счет Кредита Банка - 4% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromAtmMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_gracePeriod','111 дней');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_gracePeriodFalse','11,9% - 25,9% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_minPayment','5% от суммы задолженности, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_skipMinPayment','36,5% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','rate_creditLimit','До 500 000 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('84','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','comission_cashWithoutCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','limits_fromAtmDay','5 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','limits_fromAtmMonth','40 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','limits_fromAtmOtherBanksDay','5 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','limits_fromAtmOtherBanksMonth','40 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','rate_interestBalance','0%<br>Остаток денежных средств - не более 60 000 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('85','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_issueMainCard','199 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_annualPaymentMainCard','99 руб./мес, если номер для вознаграждения не обслуживается в ПАО«МТС»');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_cardRenewalCardholderInitiative','199 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_lostCardRenewal','199 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_fromCashDesk','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_fromAtmOtherBanks','1% от суммы операции, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_fromCashDeskOtherBanks','1% от суммы операции, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_fromAtmOtherBanksAbroad','1% от суммы операции, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_fromCashDeskOtherBanksAbroad','1% от суммы операции, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_cashWithoutCard','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromAtmMonth','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromAtmOtherBanksMonth','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('70','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_issueMainCard','199 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_annualPaymentMainCard','99 руб./мес, если номер для вознаграждения не обслуживается в ПАО«МТС»');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_cardRenewalCardholderInitiative','199 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_lostCardRenewal','199 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_fromAtm','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_fromCashDesk','За счет собственных средств: 0,5% от суммы операции<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_fromAtmOtherBanks','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_fromCashDeskOtherBanks','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_fromAtmOtherBanksAbroad','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_fromCashDeskOtherBanksAbroad','За счет собственных средств: 1% от суммы операции, но не менее 100 руб.<br>За счет Кредита Банка: 3,9% от суммы операции + 350 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_cashWithoutCard','За счет собственных средств: 0,5% от суммы операции;<br>За счет Кредита Банка - 4% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromAtmDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromAtmMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromCashDeskDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromCashDeskMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromAtmOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromAtmOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromCashDeskOtherBanksDay','50 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','limits_fromCashDeskOtherBanksMonth','600 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_gracePeriod','111 дней');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_gracePeriodFalse','24,9% - 27% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_minPayment','5% от суммы задолженности, но не менее 100 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_skipMinPayment','36,5% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','rate_creditLimit','До 299 999 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('77','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_issueAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_annualPaymentAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_lostCardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_fromCashDeskOtherBanks','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_fromAtmOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_fromCashDeskOtherBanksAbroad','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_cashWithoutCard','0,5% от суммы операции');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','comission_smsInfo','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromAtmDay','300 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromAtmMonth','1 500 000 руб. (эквивалент в USD / ЕВРО по курсу Банка)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromCashDeskDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromCashDeskMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromAtmOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromAtmOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromCashDeskOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','limits_fromCashDeskOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','rate_interestBalance','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','additional_loungeKey','8 бесплатных посещений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','additional_cashback','До 4%, в зависимости от среднемесячного баланса');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('81','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_issueAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_annualPaymentMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_annualPaymentAdditionalCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_lostCardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_fromAtm','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3% от суммы операции (минимум 200 руб.)	');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_fromCashDesk','За счет собственных средств: 0,5% от суммы операции;<br>За счет Кредита Банка: 3% от суммы операции (минимум 200 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_fromAtmOtherBanks','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3% от суммы операции (минимум 200 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_fromCashDeskOtherBanks','');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_fromAtmOtherBanksAbroad','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3% от суммы операции (минимум 200 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_fromCashDeskOtherBanksAbroad','За счет собственных средств: 0,5% от суммы операции;<br>За счет Кредита Банка: 3% от суммы операции (минимум 200 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_cashWithoutCard','За счет собственных средств: Без комиссии<br>За счет Кредита Банка: 3% от суммы операции (минимум 100 руб.)');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','comission_smsInfo','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromAtmDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromAtmMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromCashDeskDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromCashDeskMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromAtmOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromAtmOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromCashDeskOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','limits_fromCashDeskOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_interestBalance','0.2% годовых на счет в долларах США;<br>3,25% годовых на счет в руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_gracePeriod','111 дней');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_gracePeriodFalse','25,99% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_minPayment','5% от суммы задолженности, но не менее 300 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_skipMinPayment','500 руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_violationCondition','0,1% от задолженности за каждый день');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','rate_creditLimit','0 долларов США<br>До 2 000 000 в руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','additional_loungeKey','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','additional_priorityPass','');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('82','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_annualPaymentMainCard','Без комиссии – в течение первого года обслуживания<br>150 USD / 4000 RUB / 150 EUR – в течение последующих лет обслуживания.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_lostCardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_fromCashDeskOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_fromAtmOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_fromCashDeskOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_cashWithoutCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromAtmDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromAtmMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromCashDeskDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromCashDeskMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromAtmOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromAtmOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromCashDeskOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','limits_fromCashDeskOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_interestBalance','0,00% годовых на счет в USD<br>0,00% годовых на счет в EUR<br>0.00% годовых на счет в RUB');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_gracePeriod','111 дней');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_gracePeriodFalse','в USD - 12% годовых<br>в EUR – 12% годовых<br>в RUB – 14% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_minPayment','5% от суммы задолженности, но не менее 10 USD/EUR/ 300 RUB ');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_skipMinPayment','10% от минимальной суммы внесения средств на счет, включая проценты, входящие в состав минимального платежа, которые не были размещены в предыдущих расчетных периодов, но не менее 500 hуб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_violationCondition','10% от суммы просроченной задолженности по состоянию на конец последнего дня месяца, но не менее 500 pуб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','rate_creditLimit','до 65 000 USD<br>до 50 000 EUR<br>до 2 000 000 RUB');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Platinum','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_issueMainCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_annualPaymentMainCard','Без комиссии – в течение первого года обслуживания<br>250 USD / 6500 RUB / 250 EUR – в течение последующих лет обслуживания.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_cardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_cardRenewalCardholderInitiative','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_lostCardRenewal','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_fromAtm','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_fromCashDesk','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_fromAtmOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_fromCashDeskOtherBanks','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_fromAtmOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_fromCashDeskOtherBanksAbroad','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_cashWithoutCard','Без комиссии');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','comission_smsInfo','2 мес. бесплатно, далее 59 руб/мес');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromAtmDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromAtmMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromCashDeskDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromCashDeskMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromAtmOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromAtmOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromCashDeskOtherBanksDay','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','limits_fromCashDeskOtherBanksMonth','Без ограничений');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_interestBalance','0,00% годовых на счет в USD<br>0,00% годовых на счет в EUR<br>0.00% годовых на счет в RUB');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_gracePeriod','111 дней');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_gracePeriodTrue','0');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_gracePeriodFalse','в USD - 13% годовых<br>в EUR – 13% годовых<br>в RUB – 15% годовых');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_minPayment','5% от суммы задолженности, но не менее 10 USD/EUR/ 300 RUB ');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_skipMinPayment','10% от минимальной суммы внесения средств на счет, включая проценты, входящие в состав минимального платежа, которые не были размещены в предыдущих расчетных периодов, но не менее 500 Руб.');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_violationCondition','10% от суммы просроченной задолженности по состоянию на конец последнего дня месяца, но не менее 500 Руб. ');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','rate_creditLimit','до 65 000 USD<br>до 50 000 EUR<br>до 2 000 000 RUB');
INSERT INTO TARIFF_VALUE(TARIFFNUMBER,SYSNAME,VALUE) VALUES('86 Gold','webLink','https://www.mtsbank.ru/chastnim-licam/tarif/');

update TARIFF_VALUE
set categoryid = (select TARIFF_CATEGORY.categoryid from TARIFF_CATEGORY where TARIFF_CATEGORY.SYSNAME = TARIFF_VALUE.SYSNAME)
where exists (select 1 from TARIFF_CATEGORY where TARIFF_CATEGORY.SYSNAME = TARIFF_VALUE.SYSNAME);


/////////////////
create table LIMIT_ISSUE(
    ISSUEID BIGINT GENERATED ALWAYS AS IDENTITY,
    CHANNEL VARCHAR(255),
    CODEPROC SMALLINT,
    REQUESTSUMMA NUMERIC(38,2) NULL,
    HASHEDPAN VARCHAR(255),
    CREATIONDATE TIMESTAMP,
    STATUS VARCHAR(150)
);

create index X1_LIMIT_ISSUE on LIMIT_ISSUE(ISSUEID);