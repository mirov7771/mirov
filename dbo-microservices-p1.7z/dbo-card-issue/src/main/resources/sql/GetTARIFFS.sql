        select c.categoryid,
               point,
               name,
               value,
               null as podcategory,
               null as maincategory,
               null as podpoint,
               null as mainpoint
          from TARIFF_VALUE v
    inner join TARIFF_CATEGORY c
            on c.categoryid       = v.categoryid
           and c.parentcategoryid = 0
    where v.TARIFFNUMBER     = '%TARIFFNUMBER%'
    union
        select c.categoryid,
               c.point,
               c.name,
               v.value,
               null as podcategory,
               p.name as maincategory,
               null as podpoint,
               p.point as mainpoint
          from TARIFF_VALUE v
    inner join TARIFF_CATEGORY c
            on c.categoryid       = v.categoryid
    inner join TARIFF_CATEGORY p
            on c.parentcategoryid = p.categoryid
           and p.parentcategoryid = 0
         where v.TARIFFNUMBER     = '%TARIFFNUMBER%'
    union
        select c.categoryid,
               c.point,
               c.name,
               v.value,
               p.name as podcategory,
               e.name as maincategory,
               p.point as podpoint,
               e.point as mainpoint
          from TARIFF_VALUE v
    inner join TARIFF_CATEGORY c
            on c.categoryid       = v.categoryid
    inner join TARIFF_CATEGORY p
            on c.parentcategoryid = p.categoryid
    inner join TARIFF_CATEGORY e
            on p.parentcategoryid = e.categoryid
           and e.parentcategoryid = 0
         where v.TARIFFNUMBER     = '%TARIFFNUMBER%'
    order by 2