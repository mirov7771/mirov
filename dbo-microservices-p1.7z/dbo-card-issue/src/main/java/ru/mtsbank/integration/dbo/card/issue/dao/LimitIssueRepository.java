package ru.mtsbank.integration.dbo.card.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.LimitIssue;

@Repository
public interface LimitIssueRepository extends CrudRepository<LimitIssue, String> {

    LimitIssue findByIssueId(Long issueId);

}
