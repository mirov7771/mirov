package ru.mtsbank.integration.dbo.card.issue.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.*;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.response.*;
import ru.mtsbank.integration.dbo.card.issue.service.Service;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Tag(name = "CardIssue")
@RestController
@RequestMapping("dbo-card-issue")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/createCard", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "оформление карты"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CreateCardRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> createCard(@PathVariable final String version
                                                  ,@RequestBody CreateCardReq req)
    {
        return ResponseBuilder.build(services.get(version).createCard(req));
    }

    @PostMapping(value = "{version}/checkDeliveryAddress", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "метод проверяет, возможность доставки дебетовой карты"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CheckDeliveryAddressRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> checkDeliveryAddress(@PathVariable final String version
                                                            ,@Valid @RequestBody CheckDeliveryAddressReq req)
    {
        return ResponseBuilder.build(services.get(version).checkDeliveryAddress(req));
    }

    @PostMapping(value = "{version}/closeCard", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "запрос на проверку закрытия карты или закрытия карты"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = CloseCardRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "409", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> closeCard(@PathVariable final String version
                                                 ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                 ,@RequestHeader(value = "authorization", required = false) String authorization
                                                 ,@Valid @RequestBody CloseCardReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).closeCard(req));
    }

    @GetMapping(value = "{version}/getTariff", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "метод для получения тарифов по карте"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = GetTariffRes.class))
            }),
            @ApiResponse(responseCode = "400", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<?> getTariff(@PathVariable final String version
                                      ,@RequestParam("productCode") String productCode)
    {
        GetTariffReq req = new GetTariffReq();
        req.setProductCode(productCode);
        List<Map<String, Object>> tariff = services.get(version).getTariff(req);
        if (CollectionUtils.isEmpty(tariff)){
            return ResponseEntity.status(406).body(new GetTariffRes().createError(1056
                    , "Тарифы по переданному продукту не найдены"
                    , 406
                    , null
                    , null
                    , "getTariff"
                    , null));
        } else {
            return ResponseEntity.ok(tariff);
        }
    }

    @PostMapping(value = "{version}/changeLimit", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "изменение кредитного лимита"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ChangeLimitRes.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> changeLimit(@PathVariable final String version
                                                   ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                   ,@RequestHeader(value = "phone", required = false) String phone
                                                   ,@RequestHeader(value = "authorization", required = false) String authorization
                                                   ,@RequestHeader(value = "client-id", required = false) String clientId
                                                   ,@RequestBody ChangeLimitReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        if (req.getSrcPhone() == null)
            req.setSrcPhone(phone,authorization);
        req.setChannel(clientId);
        return ResponseBuilder.build(services.get(version).changeLimit(req));
    }
}
