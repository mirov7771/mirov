package ru.mtsbank.integration.dbo.card.issue.controllers.dto.response;

import ru.mts.dbo.dto.BaseResponse;

public class ChangeLimitRes extends BaseResponse {
}
