package ru.mtsbank.integration.dbo.card.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.card.issue.dao.DeliveryZoneRepository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.DeliveryZone;
import ru.mtsbank.integration.mts.xsd.CardDeliveryZoneListMod.*;

import java.util.List;

@Component("dbo.card.delivery.zone")
@Slf4j
public class CardDeliveryZoneListModNfService implements NotificationService{

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private DeliveryZoneRepository deliveryZoneRepository;

    @Override
    public void handleRequest(String xmlRequest) {
        log.info("Start consuming CardDeliveryZoneListModNf");
        CardDeliveryZoneListModNf nf = xmlUnmarshaler.parse(CardDeliveryZoneListModNf.class, xmlRequest);
        if (nf.getBankSvcRq() != null && nf.getBankSvcRq().getStateProvList() != null){
            StateProvList provList = nf.getBankSvcRq().getStateProvList();
            List<StateProvRec> stateProvRecs = provList.getStateProvRec();
            if (!CollectionUtils.isEmpty(stateProvRecs)){
                for(StateProvRec stateProvRec : stateProvRecs){
                    log.info("Start saving delivery interval for "+stateProvRec.getRegion()+" / "+stateProvRec.getCity());
                    StringBuilder deliveryDays = new StringBuilder();
                    if (stateProvRec.getDeliveryOrgList() != null && !CollectionUtils.isEmpty(stateProvRec.getDeliveryOrgList().getDeliveryOrgRec())){
                        for(DeliveryOrgRec item : stateProvRec.getDeliveryOrgList().getDeliveryOrgRec()){
                            if (item.getProcessList() != null && !CollectionUtils.isEmpty(item.getProcessList().getProcessRec())){
                                int sz = item.getProcessList().getProcessRec().size();
                                for(int i=0;i<sz;i++){
                                    ProcessRec rec = item.getProcessList().getProcessRec().get(i);
                                    deliveryDays.append(rec.getDeliveryDays());
                                    if (i != sz - 1)
                                        deliveryDays.append(",");
                                }
                            }
                        }
                    }
                    deliveryZoneRepository.save(new DeliveryZone(stateProvRec.getId()
                            , stateProvRec.getFIASCode()
                            , stateProvRec.getDeliveryInterval()
                            , deliveryDays.toString()
                            , stateProvRec.getRegion()
                            , stateProvRec.getCity()
                            , stateProvRec.getStateProv()));
                }
            }
        }
        log.info("End consuming CardDeliveryZoneListModNf");
    }


}
