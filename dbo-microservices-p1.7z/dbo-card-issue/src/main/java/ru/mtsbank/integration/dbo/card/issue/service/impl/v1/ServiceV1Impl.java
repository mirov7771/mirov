package ru.mtsbank.integration.dbo.card.issue.service.impl.v1;

import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.*;
import ru.mtsbank.integration.dbo.card.issue.service.Service;
import ru.mtsbank.integration.dbo.card.issue.service.impl.v1.methods.*;

import java.util.List;
import java.util.Map;

@Component("v1")
public class ServiceV1Impl implements Service {

    private final CreateCardMethod createCardMethod;
    private final CheckDeliveryAddressMethod checkDeliveryAddressMethod;
    private final CloseCardMethod closeCardMethod;
    private final GetTariffMethod getTariffMethod;
    private final ChangeLimitMethod changeLimitMethod;

    public ServiceV1Impl(CreateCardMethod createCardMethod
                        ,CheckDeliveryAddressMethod checkDeliveryAddressMethod
                        ,CloseCardMethod closeCardMethod
                        ,GetTariffMethod getTariffMethod
                        ,ChangeLimitMethod changeLimitMethod)
    {
        this.createCardMethod = createCardMethod;
        this.checkDeliveryAddressMethod = checkDeliveryAddressMethod;
        this.closeCardMethod = closeCardMethod;
        this.getTariffMethod = getTariffMethod;
        this.changeLimitMethod = changeLimitMethod;
    }

    @Override
    public BaseResponse createCard(CreateCardReq req) {
        return createCardMethod.call(req);
    }

    @Override
    public BaseResponse checkDeliveryAddress(CheckDeliveryAddressReq req) {
        return checkDeliveryAddressMethod.call(req);
    }

    @Override
    public BaseResponse closeCard(CloseCardReq req) {
        return closeCardMethod.call(req);
    }

    @Override
    public List<Map<String, Object>> getTariff(GetTariffReq req) {
        return getTariffMethod.call(req);
    }

    @Override
    public BaseResponse changeLimit(ChangeLimitReq req) {
        return changeLimitMethod.call(req);
    }
}
