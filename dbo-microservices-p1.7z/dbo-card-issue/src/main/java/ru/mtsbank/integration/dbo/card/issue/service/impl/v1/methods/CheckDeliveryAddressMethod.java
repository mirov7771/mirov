package ru.mtsbank.integration.dbo.card.issue.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.CheckDeliveryAddressReq;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.response.CheckDeliveryAddressRes;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.Address;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.Day;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.Interval;
import ru.mtsbank.integration.dbo.card.issue.builders.DeliveryDateBuilder;
import ru.mtsbank.integration.dbo.card.issue.dao.DeliveryZoneRepository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.DeliveryZone;

import java.io.IOException;
import java.util.*;

@Component("checkdeliveryaddress")
@Slf4j
public class CheckDeliveryAddressMethod {

    @Autowired
    private DeliveryZoneRepository deliveryZoneRepository;

    @Autowired
    private DeliveryDateBuilder deliveryDateBuilder;

    @Autowired
    private EsbGate esbGate;

    public CheckDeliveryAddressRes call(CheckDeliveryAddressReq req) {
        log.info("Start service checkdeliveryaddress");
        CheckDeliveryAddressRes res = new CheckDeliveryAddressRes();
        try{
            Address deliveryAddress = req.getDeliveryAddress();
            String region = deliveryAddress.getRegionName();
            String district = deliveryAddress.getDistrictName();
            if (StringUtils.isEmpty(district))
                district = deliveryAddress.getLocalityName();
            String city = deliveryAddress.getCityName();
            List<DeliveryZone> dzlist;
            DeliveryZone dz = null;

            if (!StringUtils.isEmpty(district) && !StringUtils.isEmpty(city))
                dzlist = deliveryZoneRepository.findByRegionAndDistrictAndCity(region,district,city);
            else if (!StringUtils.isEmpty(district))
                dzlist = deliveryZoneRepository.findByRegionAndDistrict(region,district);
            else if (!StringUtils.isEmpty(city))
                dzlist = deliveryZoneRepository.findByRegionAndCity(region,city);
            else
                dzlist = deliveryZoneRepository.findByRegion(region);

            if (!CollectionUtils.isEmpty(dzlist))
                dz = dzlist.get(0);
            
            if (dz != null) {

                String deliveryTime = dz.getDeliveryInterval();
                String zoneId = dz.getZoneId();

                log.info("DeliveryTime is " + deliveryTime);
                if (StringUtils.isEmpty(deliveryTime)) {
                    res.createError(1021, "<b>Доставка по выбранному адресу пока недоступна.</b> Вы можете указать другой адрес  или выбрать самовывоз", 406, null, null,"checkdeliveryaddress", null);
                } else {
                    List<Date> dateList = deliveryDateBuilder.getDates(
                            esbGate.sendSalesMessageWithAnswer(
                                    deliveryDateBuilder.build(zoneId)
                            )
                    );
                    if (!CollectionUtils.isEmpty(dateList)) {
                        List<Day> calDays = new ArrayList<>();
                        for (Date day : dateList) {
                            calDays.add(new Day(day));
                        }

                        String[] calendar = deliveryTime.split(",");
                        List<Interval> intervals = new ArrayList<>();

                        for (String item : calendar) {
                            log.info("Set delivery time " + item);
                            Interval interval = new Interval();
                            interval.setValue(item);
                            intervals.add(interval);
                        }

                        res.setDeliveryInterval(intervals);
                        calDays.sort(Day.COMPARE_BY_VALUE);
                        res.setDeliveryDays(calDays);
                    } else {
                        res.createError(1021, "<b>Доставка по выбранному адресу пока недоступна.</b> Вы можете указать другой адрес  или выбрать самовывоз", 406, null, null,"checkdeliveryaddress", null);
                    }
                }
            } else {
                res.createError(1021, "<b>Доставка по выбранному адресу пока недоступна.</b> Вы можете указать другой адрес  или выбрать самовывоз", 406, null, null,"checkdeliveryaddress", null);
            }
            log.info("End service checkdeliveryaddress");
        } catch (IOException e){
            log.error("Error "+e);
            res.createError(1021, "<b>Доставка по выбранному адресу пока недоступна.</b> Вы можете указать другой адрес  или выбрать самовывоз", 406, null, null,"checkdeliveryaddress", null);
            e.printStackTrace();
        }
        return res;
    }

}
