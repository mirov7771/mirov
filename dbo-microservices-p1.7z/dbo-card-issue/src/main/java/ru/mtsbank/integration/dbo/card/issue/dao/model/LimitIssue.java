package ru.mtsbank.integration.dbo.card.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "LIMIT_ISSUE")
@Getter @Setter
public class LimitIssue implements Serializable {

    private static final long serialVersionUID = -6497247389459471210L;

    @Id
    @Column(name = "ISSUEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long issueId;
    @Column(name = "CHANNEL")
    private String chanel;
    @Column(name = "CODEPROC")
    private Integer codeProc;
    @Column(name = "REQUESTSUMMA")
    private BigDecimal requestSumma;
    @Column(name = "HASHEDPAN")
    private String hashedPan;
    @Column(name = "CREATIONDATE")
    private Date creationDate;
    @Column(name = "STATUS")
    private String status;

}
