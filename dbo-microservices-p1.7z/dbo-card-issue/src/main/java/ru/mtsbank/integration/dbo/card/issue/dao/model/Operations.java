package ru.mtsbank.integration.dbo.card.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "OPERATIONS")
@Getter @Setter
public class Operations implements Serializable {

    private static final long serialVersionUID = -7976065146028047856L;

    @Id
    @Column(name = "OPERID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long operId;
    @Column(name = "HASHPAN")
    private String hashPan;
    @Column(name = "OPERDATE")
    private Date operDate;

    public Operations(){

    }

    public Operations(String hashPan){
        this.operDate = new Date();
        this.hashPan = hashPan;
    }

}
