package ru.mtsbank.integration.dbo.card.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class ForeignResident {

    @JsonProperty("issueCountry")
    private String issueCountry;
    @JsonProperty("issueCountryINN")
    private String issueCountryINN;

}
