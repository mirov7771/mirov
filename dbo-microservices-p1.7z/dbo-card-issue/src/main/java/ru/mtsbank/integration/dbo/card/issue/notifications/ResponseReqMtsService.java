package ru.mtsbank.integration.dbo.card.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.card.issue.dao.LimitIssueRepository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.LimitIssue;
import ru.mtsbank.integration.mts.xsd.ReqMts.res.ResponseReqMts;

@Component("dbo.card.limit.response")
@Slf4j
public class ResponseReqMtsService implements NotificationService {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private LimitIssueRepository limitIssueRepository;

    @Override
    public void handleRequest(String xmlRequest) {
        log.info("Start consuming RESPONSE_REQ_MTS");
        ResponseReqMts responseReqMts = xmlUnmarshaler.parse(ResponseReqMts.class, xmlRequest);
        if (responseReqMts != null
                && responseReqMts.getBankSvcRs() != null
                && responseReqMts.getBankSvcRs().getStatus() != null)
        {
            Long mtsRequestId = prepareId(responseReqMts.getMtsRequestId());
            if (mtsRequestId != null) {
                LimitIssue issue = limitIssueRepository.findByIssueId(mtsRequestId);
                if (issue != null) {
                    String statusCode = responseReqMts.getBankSvcRs().getStatus().getStatusCode();
                    issue.setStatus("0".equals(statusCode) ? "DONE" : "REFUSE");
                    limitIssueRepository.save(issue);
                }
            }
        }
        log.info("End consuming RESPONSE_REQ_MTS");
    }

    private Long prepareId(String value){
        if (StringUtils.isEmpty(value))
            return null;
        String id = value.replace("IB3-","")
                .replace("IOS3-","")
                .replace("ANDR3-","");
        if (Utils.isDigits(id))
            return Long.valueOf(id);
        return null;
    }
}
