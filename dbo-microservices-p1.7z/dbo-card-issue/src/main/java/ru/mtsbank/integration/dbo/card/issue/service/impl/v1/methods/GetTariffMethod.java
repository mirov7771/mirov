package ru.mtsbank.integration.dbo.card.issue.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.GetTariffReq;
import ru.mtsbank.integration.dbo.card.issue.dao.TariffTypeRepository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.TariffType;
import ru.mtsbank.integration.dbo.card.issue.dao.operations.CardOperations;
import ru.mtsbank.integration.dbo.card.issue.dao.sql.TariffValue;

import java.util.*;

@Component
@Slf4j
public class GetTariffMethod {

    @Autowired
    private TariffTypeRepository tariffTypeRepository;

    @Autowired
    private CardOperations cardOperations;
    
    private static final String KEY_FIELD = "name";
    private static final String VALUE_FIELD = "value";
    private static final String VALUE_LIST = "list";
    private static final String VALUE_LINK = "link";
    private static final String POINT_FIELD = "point";
    private static String mainPoint = null;

    public List<Map<String, Object>> call(GetTariffReq req) {
        log.info("start service getTariff");
        List<Map<String, Object>> tariffList = new ArrayList<>();
        TariffType prodCode = tariffTypeRepository.findByProdCode(req.getProductCode());
        if (prodCode != null) {
            String tariffNumber = prodCode.getTariffNumber();
            log.info("***Start searching tariffs for {}",tariffNumber);
            List<TariffValue> tariffs = cardOperations.getTariffs(tariffNumber);
            if (!CollectionUtils.isEmpty(tariffs)){
                Set<String> mainCats = new HashSet<>();
                List<TariffValue> mainList = new ArrayList<>();
                Set<String> podCats = new HashSet<>();
                List<TariffValue> podList = new ArrayList<>();

                prepareCategory(mainCats, podCats, mainList, podList, tariffs);

                for(TariffValue tariff : tariffs){
                    Map<String, Object> map = new HashMap<>();
                    if (StringUtils.isEmpty(tariff.getMaincategory())){
                        map.put(POINT_FIELD, tariff.getPoint());
                        map.put(KEY_FIELD, tariff.getName());
                        map.put(getKey(tariff.getValue()), tariff.getValue());
                        tariffList.add(map);
                    }
                }
                log.info("***Main categories {}",Arrays.toString(mainCats.toArray()));
                if (mainCats.size() > 0 && !CollectionUtils.isEmpty(mainList)){
                    for(String cat : mainCats){
                        mainPoint = null;
                        prepareCatList(cat, mainList, tariffList, podCats, podList);
                    }
                }
                tariffList.sort(new MapComparator(POINT_FIELD));
                removePoint(tariffList);
            }
        }
        log.info("end service getTariff");
        return tariffList;
    }

    private void prepareCategory(Set<String> mainCats
                                ,Set<String> podCats
                                ,List<TariffValue> mainList
                                ,List<TariffValue> podList
                                ,List<TariffValue> tariffs)
    {
        tariffs.forEach(item -> {
            String maincategory = item.getMaincategory();
            String podcategory = item.getPodcategory();
            if (!StringUtils.isEmpty(maincategory) && !mainCats.contains(maincategory)){
                mainCats.add(maincategory);
            }
            if (!StringUtils.isEmpty(podcategory) && !podCats.contains(podcategory)){
                podCats.add(podcategory);
            }
            if (StringUtils.isEmpty(podcategory) && !StringUtils.isEmpty(maincategory)) {
                mainList.add(item);
            }
            if (!StringUtils.isEmpty(podcategory) && !StringUtils.isEmpty(maincategory)) {
                podList.add(item);
            }
        });
    }


    private void prepareCatList(String cat
                               ,List<TariffValue> mainList
                               ,List<Map<String, Object>> tariffList
                               ,Set<String> podCats
                               ,List<TariffValue> podList)
    {
        Map<String, Object> map = new HashMap<>();
        List<Map<String, Object>> childList = new ArrayList<>();
        for(TariffValue tariff : mainList){
            if (StringUtils.isEmpty(tariff.getPodcategory())) {
                String maincategory = tariff.getMaincategory();
                if (maincategory.equalsIgnoreCase(cat)) {
                    log.info("***set pod cat for {}{}{}",cat,maincategory,tariff.getPoint());
                    Map<String, Object> podMap = new HashMap<>();
                    podMap.put(POINT_FIELD, tariff.getPoint());
                    podMap.put(KEY_FIELD, tariff.getName());
                    podMap.put(getKey(tariff.getValue()), tariff.getValue());
                    if (mainPoint == null)
                        mainPoint = tariff.getMainpoint();
                    childList.add(podMap);
                }
            }
        }
        log.info("***Pod categories "+Arrays.toString(podCats.toArray()));
        if (podCats.size() > 0 && !CollectionUtils.isEmpty(podList)){
            for(String podCat : podCats){
                preparePodCatList(podCat, childList, podList, cat);
            }
        }
        if (!CollectionUtils.isEmpty(childList)){
            map.put(POINT_FIELD, mainPoint);
            map.put(KEY_FIELD, cat);
            childList.sort(new MapComparator(POINT_FIELD));
            removePoint(childList);
            map.put(VALUE_LIST, childList);
            tariffList.add(map);
        }
    }

    private void preparePodCatList(String podCat, List<Map<String, Object>> childList, List<TariffValue> podList, String cat) {
        Map<String, Object> childMap = new HashMap<>();
        List<Map<String, Object>> extraChildList = new ArrayList<>();
        String podPoint = null;
        for(TariffValue value : podList){
            if (podCat.equalsIgnoreCase(value.getPodcategory()) && cat.equalsIgnoreCase(value.getMaincategory())){
                log.info("***set extrapod cat for {}{}{}",podCat,value.getPodcategory(),value.getPoint());
                Map<String, Object> extraPodMap = new HashMap<>();
                extraPodMap.put(KEY_FIELD, value.getName());
                extraPodMap.put(getKey(value.getValue()), value.getValue());
                extraPodMap.put(POINT_FIELD, value.getPoint());
                if (podPoint == null)
                    podPoint = value.getPodpoint();
                if (mainPoint == null && value.getMainpoint() != null)
                    mainPoint = value.getMainpoint();
                extraChildList.add(extraPodMap);
            }
        }
        if (!CollectionUtils.isEmpty(extraChildList)){
            childMap.put(KEY_FIELD, podCat);
            extraChildList.sort(new MapComparator(POINT_FIELD));
            removePoint(extraChildList);
            childMap.put(VALUE_LIST, extraChildList);
            childMap.put(POINT_FIELD, podPoint);
            childList.add(childMap);
        }
    }

    private void removePoint(List<Map<String, Object>> list){
        list.forEach(item -> item.remove(POINT_FIELD));
    }

    static class MapComparator implements Comparator<Map<String, Object>>
    {
        private final String key;

        public MapComparator(String key) {
            this.key = key;
        }

        @Override
        public int compare(Map<String, Object> first
                          ,Map<String, Object> second)
        {
            String firstValue = (String) first.get(key);
            String secondValue = (String) second.get(key);
            if (firstValue == null || secondValue == null)
                return 0;
            return firstValue.compareTo(secondValue);
        }
    }

    private String getKey(String value){
        if (value != null && value.startsWith("http"))
            return VALUE_LINK;
        return VALUE_FIELD;
    }

}
