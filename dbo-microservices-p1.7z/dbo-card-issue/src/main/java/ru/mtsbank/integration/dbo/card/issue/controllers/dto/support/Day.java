package ru.mtsbank.integration.dbo.card.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

import java.util.Comparator;
import java.util.Date;

@Setter
public class Day {

    @JsonProperty("value")
    private Date value;

    public static final Comparator<Day> COMPARE_BY_VALUE = (o1, o2) -> o2.value.compareTo(o1.value);

    public Day(Date value){
        this.value = value;
    }

}
