package ru.mtsbank.integration.dbo.card.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.DeliveryZone;

import java.util.List;

@Repository
public interface DeliveryZoneRepository extends CrudRepository<DeliveryZone, String> {

    List<DeliveryZone> findByRegion(String region);
    List<DeliveryZone> findByRegionAndDistrict(String region, String district);
    List<DeliveryZone> findByRegionAndDistrictAndCity(String region, String district, String city);
    List<DeliveryZone> findByRegionAndCity(String region, String city);

}
