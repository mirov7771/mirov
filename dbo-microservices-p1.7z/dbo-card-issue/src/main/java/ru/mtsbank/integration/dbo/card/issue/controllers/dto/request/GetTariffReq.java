package ru.mtsbank.integration.dbo.card.issue.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseRequest;

@Getter @Setter
public class GetTariffReq extends BaseRequest {

    @JsonProperty("productCode")
    private String productCode;

}
