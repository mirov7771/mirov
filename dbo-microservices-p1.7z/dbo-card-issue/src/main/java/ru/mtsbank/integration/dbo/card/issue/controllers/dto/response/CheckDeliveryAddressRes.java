package ru.mtsbank.integration.dbo.card.issue.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.Day;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.Interval;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class CheckDeliveryAddressRes extends BaseResponse {

    @JsonProperty("deliveryInterval")
    private List<Interval> deliveryInterval;
    @JsonProperty("deliveryDays")
    private List<Day> deliveryDays;

}
