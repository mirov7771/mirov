package ru.mtsbank.integration.dbo.card.issue.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.gates.SmsGate;
import ru.mtsbank.integration.dbo.card.issue.builders.CloseCardBuilder;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.CloseCardReq;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.response.CloseCardRes;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@Component("closecard")
@Slf4j
public class CloseCardMethod {

    private static Set<String> STATES = new HashSet<>();
    private static Set<String> CODES = new HashSet<>();
    static {
        STATES.add("CLS");
        STATES.add("WRK");

        CODES.add("0");
        CODES.add("1");
        CODES.add("2");
        CODES.add("3");
        CODES.add("4");
        CODES.add("5");
        CODES.add("6");
        CODES.add("7");
        CODES.add("8");
    }

    @Autowired
    private CloseCardBuilder closeCardBuilder;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private SmsGate smsGate;

    public CloseCardRes call(CloseCardReq req) {
        log.info("Start service closecard");
        CloseCardRes res = new CloseCardRes();
        String rqUid = UUID.randomUUID().toString();
        try {
            String type = req.getType() == null ? "info" : req.getType();

            String checkOtpTokenStatus = type.equalsIgnoreCase("info") ? "GOOD_ANSWER" : smsGate.execute(req.getOtpToken(), "closecard", req.getRboID());
            if (checkOtpTokenStatus.equals("GOOD_ANSWER")) {
                String rq = closeCardBuilder.build(req, type, rqUid);
                String rs = esbGate.sendInfoMessageWithAnswer(rq);
                Map<String, String> rsMap = closeCardBuilder.check(rs, type);

                if (rsMap.isEmpty()) {
                    res.createError(501,"Сервис временно недоступен",400, null, null, "closecard", rqUid);
                } else {
                    String sc = rsMap.get("statusCode");
                    String status = rsMap.get("status");
                    if (CODES.contains(sc)) {
                        if (type.equalsIgnoreCase("close")){
                            res.setResultCode(status);
                        }
                        if (type.equalsIgnoreCase("info")){
                            res.setCardStatusCode(sc);
                            res.setDescription(rsMap.get("descriprion"));
                        }
                        res.setRequestId(rqUid);
                    } else {
                        switch (sc){
                            case "1":
                                res.createError(1029, "Карта не найдена", 500, null, null, "closecard", rqUid);
                                break;
                            case "2":
                                res.createError(1030, "Карта находится не в рабочем состояние", 500, null, null, "closecard", rqUid);
                                break;
                            case "300":
                                res.createError(1030, "Операция доступна только по основной карте", 500, null, null, "closecard", rqUid);
                                break;
                            case "500":
                                res.createError(1033, "Заявка на закрытие уже принята", 500, null, null, "closecard", rqUid);
                                break;
                            case "700":
                                res.createError(1034, "Карта закрыта", 500, null, null, "closecard", rqUid);
                                break;
                            case "1000":
                                res.createError(1035, rsMap.get("statusDesc"), 500, null, null, "closecard", rqUid);
                                break;
                            case "1100":
                                res.createError(1036, "По вашей карте есть не оплаченная комиссия. Погасите задолженность и повторите операцию", 500, null, null, "closecard", rqUid);
                                break;
                            case "1200":
                                res.createError(1037, rsMap.get("statusDesc"), 500, null, null, "closecard", rqUid);
                                break;
                            case "1300":
                                res.createError(1038, "Счет карты заблокирован. Обратитесь в контактный центр или отделение банка", 500, null, null, "closecard", rqUid);
                                break;
                            case "1600":
                                res.createError(1039, "По вашей карте не закрыт пакет банковских услуг VIP. Обратитесь в отделение банка", 500, null, null, "closecard", rqUid);
                                break;
                            case "1700":
                                res.createError(1040, "У вас есть неподтвержденные операции. Повторите попытку позже.", 500, null, null, "closecard", rqUid);
                                break;
                            case "-1":
                                res.createError(101, "Unexpected error", 500, "-1", rsMap.get("statusDesc"), "closecard", rqUid);
                                break;
                            default:
                                res.createError(107, "BackEnd Tech Error", 400, sc, rsMap.get("statusDesc"), "closecard", rqUid);
                                break;
                        }
                    }
                }
            } else {
                res.createError(1020,"Передан неверный код подтверждения операции",409, null, null, "closecard", rqUid);
            }
        } catch (IOException e) {
            log.error("Error: "+e);
            res.createError(501,"Сервис временно недоступен",400, null, null, "closecard", rqUid);
            e.printStackTrace();
        }
        log.info("End service closecard");
        return res;
    }

}
