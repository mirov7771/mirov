package ru.mtsbank.integration.dbo.card.issue.builders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.mts.xsd.deliveryDateListInq.*;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Component
public class DeliveryDateBuilder {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    public String build(String zoneId){
        DeliveryDateListInqRq rq =  new DeliveryDateListInqRq();
        ServerInfoType serverInfoType = new ServerInfoType();
        String uuid = UUID.randomUUID().toString();
        serverInfoType.setMsgUID(uuid);
        serverInfoType.setRqUID(uuid);
        serverInfoType.setSPName("MTS_EIP_UMP");
        serverInfoType.setMsgReceiver("ESB");
        serverInfoType.setMsgType("DeliveryDateListInqRq");
        serverInfoType.setServerDt(Utils.getXmlGregorianCalendar(new Date()));
        rq.setServerInfo(serverInfoType);

        BankSvcRq bankSvcRq = new BankSvcRq();
        DeliveryZoneList deliveryZoneList = new DeliveryZoneList();
        DeliveryZoneRec rec = new DeliveryZoneRec();
        rec.setId(zoneId);
        deliveryZoneList.getDeliveryZoneRec().add(rec);
        bankSvcRq.setDeliveryZoneList(deliveryZoneList);
        bankSvcRq.setDeliveryZoneList(deliveryZoneList);
        rq.setBankSvcRq(bankSvcRq);
        return xmlUnmarshaler.createXml(rq);
    }

    public List<Date> getDates(String xml){
        DeliveryDateListInqRs rs = xmlUnmarshaler.parse(DeliveryDateListInqRs.class, xml);
        List<Date> dateList = new ArrayList<>();
        if (rs != null
                && rs.getBankSvcRs() != null
                && rs.getBankSvcRs().getDeliveryZoneList() != null
                && !CollectionUtils.isEmpty(rs.getBankSvcRs().getDeliveryZoneList().getDeliveryZoneRec())){
            DeliveryZoneRec rec = rs.getBankSvcRs().getDeliveryZoneList().getDeliveryZoneRec().get(0);
            if (rec.getDeliveryDateList() != null
                    && !CollectionUtils.isEmpty(rec.getDeliveryDateList().getDeliveryDateRec())){
                for(DeliveryDateRec dateRec : rec.getDeliveryDateList().getDeliveryDateRec()){
                    dateList.add(parseFdxDate(dateRec.getDeliveryDt().getYear()
                            ,dateRec.getDeliveryDt().getMonth()
                            ,dateRec.getDeliveryDt().getDay()));
                }
            }

        }
        return dateList;
    }

    public Date parseFdxDate(final int year, final int month, final int day) {
        LocalDate localDate = LocalDate.of(year, month, day);
        return Date.from(localDate.atStartOfDay(ZoneId.of("GMT")).toInstant());
    }

}
