package ru.mtsbank.integration.dbo.card.issue.dao.sql;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TariffValue {

    private Long categoryid;
    private String point;
    private String name;
    private String value;
    private String podcategory;
    private String maincategory;
    private String podpoint;
    private String mainpoint;

}
