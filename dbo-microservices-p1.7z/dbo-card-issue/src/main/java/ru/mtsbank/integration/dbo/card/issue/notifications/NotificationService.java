package ru.mtsbank.integration.dbo.card.issue.notifications;

public interface NotificationService {

    void handleRequest(String xmlRequest);

}
