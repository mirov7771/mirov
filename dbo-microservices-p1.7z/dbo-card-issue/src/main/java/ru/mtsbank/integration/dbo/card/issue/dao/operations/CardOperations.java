package ru.mtsbank.integration.dbo.card.issue.dao.operations;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.card.issue.dao.sql.TariffValue;

import java.util.List;

@Component
@Slf4j
public class CardOperations {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String GET_TARIFFS = Utils.getSqlCommand(CardOperations.class, "GetTARIFFS");

    public void deleteOperations(String hashPan){
        String delete = "DELETE FROM OPERATIONS WHERE HASHPAN = ?";
        jdbcTemplate.update(delete, hashPan);
    }

    public List<TariffValue> getTariffs(String prodCode){
        log.info("***Input Query {}", GET_TARIFFS);
        String query = GET_TARIFFS.replaceAll("%TARIFFNUMBER%", prodCode);
        log.info("***Run Query {}", query);
        return jdbcTemplate.query(query, new BeanPropertyRowMapper(TariffValue.class));
    }

}
