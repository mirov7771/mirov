package ru.mtsbank.integration.dbo.card.issue.dao.model;

import lombok.Getter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Table(name = "TARIFF_TYPE")
@Entity
@Getter
public class TariffType implements Serializable {

    private static final long serialVersionUID = 4926559530015879613L;

    @Id
    @Column(name = "PRODCODE")
    private String prodCode;

    @Column(name = "TARIFFNUMBER")
    private String tariffNumber;

}
