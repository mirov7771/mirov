package ru.mtsbank.integration.dbo.card.issue.builders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.ChangeLimitReq;
import ru.mtsbank.integration.mts.xsd.ReqMts.res.*;

import java.util.Date;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@Component
public class RegisterReqMtsBuilder {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    public String createRegisterReqMts(ChangeLimitReq req, String rqUid){
        RegisterReqMts reqMts = new RegisterReqMts();
        reqMts.setMessageId(rqUid);
        reqMts.setMessageType(MessageType.REGISTER_REQ_MTS);
        reqMts.setMessageDateTime(getXmlGregorianCalendar(new Date()));
        reqMts.setSPName(SystemType.MTS_EIP_UMP);
        reqMts.setMsgReceiver(SystemType.SIEBEL);
        reqMts.setSiebelBpId(String.valueOf(req.getCodeProc()));
        RegisterReqMts.Request request = new RegisterReqMts.Request();
        ClientData client = new ClientData();
        ClientData.ClientListContact clientListContact = new ClientData.ClientListContact();
        Contact contact = new Contact();
        contact.setClientContact(Utils.formatPhoneWithPlus(req.getSrcPhone()));
        contact.setContactType("CONTACT.TYPE.1");
        contact.setIsPrimary(true);
        clientListContact.getClientContact().add(contact);
        client.setClientListContact(clientListContact);
        request.setClient(client);

        ClientRequestData clientRequest = new ClientRequestData();
        ClientRequestCommonDataType clientRequestCommonData = new ClientRequestCommonDataType();
        ClientRequestProductDataType product = new ClientRequestProductDataType();

        ClientRequestCardDataType card = new ClientRequestCardDataType();
        card.setCardNumberHashed(req.getHashedPAN());
        product.setCard(card);

        if (req.getCodeProc().equals(4))
            product.setRequestSumma(req.getRequestSumma());

        clientRequestCommonData.setProduct(product);
        clientRequest.setClientRequestCommonData(clientRequestCommonData);
        request.setClientRequest(clientRequest);
        reqMts.setRequest(request);
        return xmlUnmarshaler.createXml(reqMts);
    }

}
