package ru.mtsbank.integration.dbo.card.issue.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter @Setter
public class ChangeLimitReq extends BaseRequest {

    @JsonProperty("requestSumma")
    private BigDecimal requestSumma;
    @JsonProperty("codeProc")
    @NotNull
    private Integer codeProc;
    @JsonProperty("hashedPAN")
    @NotNull
    private String hashedPAN;
    @JsonIgnore
    private String channel;
}
