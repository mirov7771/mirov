package ru.mtsbank.integration.dbo.card.issue.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;

import javax.validation.constraints.NotNull;

@Getter
public class CardReissueReq extends BaseRequest {

    @JsonProperty("hashPan")
    @NotNull
    private String hashPan;
    @JsonProperty("phoneNumber")
    @NotNull
    private String phoneNumber;
    @JsonProperty("expiry")
    @NotNull
    private String expiry;
    @JsonProperty("currency")
    @NotNull
    private String currency;

}
