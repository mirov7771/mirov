package ru.mtsbank.integration.dbo.card.issue.dao.model;

import lombok.Getter;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "ISSUES")
@Getter
public class Issues implements Serializable {

    private static final long serialVersionUID = -1225188245356626179L;

    @Id
    @Column(name = "ISSUEID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long issueId;
    @Column(name = "REQUESTID")
    private String requestId;
    @Column(name = "CLIENTNAME")
    private String clientName;
    @Column(name = "CLIENTDOC")
    private String clientDoc;
    @Column(name = "PHONENUMBER")
    private String phoneNumber;
    @Column(name = "EMAIL")
    private String email;
    @Column(name = "CREATIONDATE")
    private Date creationDate;
    @Column(name = "TYPE")
    private String type;
    @Column(name = "REQUESTSUMMA")
    private BigDecimal requestSumma;

    public static class Builder{
        private String clientName;
        private String clientDoc;
        private String phoneNumber;
        private String email;
        private final Date creationDate = new Date();
        private String type;
        private BigDecimal requestSumma;

        public Builder setClientName(String clientName){
            this.clientName = clientName;
            return this;
        }

        public Builder setClienDoc(String clientDoc){
            this.clientDoc = clientDoc;
            return this;
        }

        public Builder setPhoneNumber(String phoneNumber){
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder setEmail(String email){
            this.email = email;
            return this;
        }

        public Builder setType(String type){
            this.type = type;
            return this;
        }

        public Builder setRequestSumma(BigDecimal requestSumma){
            this.requestSumma = requestSumma;
            return this;
        }

        public Issues build(){
            return new Issues(this);
        }
    }

    private Issues(Builder builder){
        this.clientName = builder.clientName;
        this.clientDoc = builder.clientDoc;
        this.phoneNumber = builder.phoneNumber;
        this.email = builder.email;
        this.creationDate = builder.creationDate;
        this.type = builder.type;
        this.requestSumma = builder.requestSumma;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Issues() {
    }
}
