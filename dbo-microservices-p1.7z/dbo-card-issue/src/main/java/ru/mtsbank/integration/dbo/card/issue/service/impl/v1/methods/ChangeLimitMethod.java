package ru.mtsbank.integration.dbo.card.issue.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.card.issue.builders.RegisterReqMtsBuilder;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.ChangeLimitReq;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.response.ChangeLimitRes;
import ru.mtsbank.integration.dbo.card.issue.dao.LimitIssueRepository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.LimitIssue;

import java.util.Date;

@Component
@Slf4j
public class ChangeLimitMethod {

    @Autowired
    private RegisterReqMtsBuilder registerReqMtsBuilder;

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    private LimitIssueRepository limitIssueRepository;

    public ChangeLimitRes call(ChangeLimitReq req){
        ChangeLimitRes res = new ChangeLimitRes();

        String channel = "IB3";
        if (!StringUtils.isEmpty(req.getChannel())){
            if (req.getChannel().contains("ios"))
                channel = "IOS3";
            else
                channel = "ANDR3";
        }

        LimitIssue li = new LimitIssue();
        li.setCodeProc(req.getCodeProc());
        li.setCreationDate(new Date());
        li.setHashedPan(req.getHashedPAN());
        li.setRequestSumma(req.getRequestSumma());
        li.setChanel(channel);
        li.setStatus("INPUT");
        LimitIssue issue = limitIssueRepository.save(li);

        String uid = channel+"-"+issue.getIssueId();
        String xml = registerReqMtsBuilder.createRegisterReqMts(req, uid);
        log.info("start send xml "+xml+"to kafka topic dbo.card.limit");
        kafkaTemplate.send("dbo.card.limit", xml);
        log.info("end send xml "+xml+"to kafka topic dbo.card.limit");
        res.setRequestId(uid);
        return res;
    }

}
