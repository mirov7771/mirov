package ru.mtsbank.integration.dbo.card.issue.service;

import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.*;
import java.util.List;
import java.util.Map;

public interface Service {

    BaseResponse createCard(CreateCardReq req);
    BaseResponse checkDeliveryAddress(CheckDeliveryAddressReq req);
    BaseResponse closeCard(CloseCardReq req);
    List<Map<String, Object>> getTariff(GetTariffReq req);
    BaseResponse changeLimit(ChangeLimitReq req);

}
