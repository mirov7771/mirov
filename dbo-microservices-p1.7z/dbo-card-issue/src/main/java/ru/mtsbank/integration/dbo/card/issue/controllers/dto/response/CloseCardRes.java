package ru.mtsbank.integration.dbo.card.issue.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class CloseCardRes extends BaseResponse {

    @JsonProperty("cardStatusCode")
    private String cardStatusCode;
    @JsonProperty("description")
    private String description;
    @JsonProperty("resultCode")
    private String resultCode;

}
