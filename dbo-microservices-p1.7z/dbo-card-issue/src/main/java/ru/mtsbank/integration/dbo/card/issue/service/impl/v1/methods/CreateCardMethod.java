package ru.mtsbank.integration.dbo.card.issue.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.CreateCardReq;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.response.CreateCardRes;
import ru.mtsbank.integration.dbo.card.issue.builders.CreateCardBuilder;
import ru.mtsbank.integration.dbo.card.issue.dao.model.Issues;
import ru.mtsbank.integration.dbo.card.issue.dao.IssuesRepository;

import java.io.IOException;
import java.math.BigDecimal;

@Component("createcard")
@Slf4j
public class CreateCardMethod {

    @Autowired
    private CreateCardBuilder createCardBuilder;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private IssuesRepository issuesRepository;

    public CreateCardRes call(CreateCardReq req) {
        log.info("Start service createCard");
        CreateCardRes res = new CreateCardRes();
        try {
            String clientName = req.getFamily() + " " + req.getName() + " " + Utils.nvl(req.getFatherName(), "");
            String clientDoc = req.getPassportData().getSerial() + " " + req.getPassportData().getNumber();

            BigDecimal reqSumma = req.getRequestedLimit() == null ? BigDecimal.ZERO : req.getRequestedLimit().getAmount();
            Issues issue = issuesRepository.save(new Issues.Builder()
                    .setClientName(clientName)
                    .setClienDoc(clientDoc)
                    .setPhoneNumber(req.getMobilePhone())
                    .setEmail(req.getEmail())
                    .setType(req.getType())
                    .setRequestSumma(reqSumma)
                    .build());

            String requestId = StringUtils.isEmpty(req.getChannel()) ? "IB-" + issue.getIssueId() : req.getChannel() + "2-" + issue.getIssueId();
            String xml = createCardBuilder.build(req, requestId);
            esbGate.sendSalesMessage(xml);
            issue.setRequestId(requestId);
            issuesRepository.save(issue);
            res.setRequestId(requestId);
            res.setProcessUid(requestId);
        } catch (IOException e) {
            log.error("Error: "+e);
            res.createError(501,"Сервис временно недоступен",400, null, null, "createcard", null);
            e.printStackTrace();
        }
        log.info("End service createCard");
        return res;
    }

}
