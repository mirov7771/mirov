package ru.mtsbank.integration.dbo.card.issue.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.*;

import javax.validation.constraints.NotNull;

@Getter
public class CreateCardReq extends BaseRequest {

    @JsonProperty("lastName")
    @NotNull
    private String family;
    @JsonProperty("type")
    private String type;
    @JsonProperty("firstName")
    @NotNull
    private String name;
    @JsonProperty("middleName")
    private String fatherName;
    @JsonProperty("mobilePhone")
    @NotNull
    private String mobilePhone;
    @JsonProperty("email")
    private String email;
    @JsonProperty("totalIncome")
    private Money totalIncome;
    @JsonProperty("channel")
    private String channel;
    @JsonProperty("requestId")
    private String requestId;
    @JsonProperty("requestedLimit")
    private Money requestedLimit;
    @JsonProperty("flagChangeFio")
    private Boolean flagChangeFio;
    @JsonProperty("prevName")
    private String prevName;
    @JsonProperty("prevFamily")
    private String prevFamily;
    @JsonProperty("prevFatherName")
    private String prevFatherName;
    @JsonProperty("codeWord")
    private String codeWord;
    @JsonProperty("gatkaFlag")
    private Boolean gatkaFlg;
    @JsonProperty("smsAgreeFlag")
    private Boolean smsAgreeFlag;
    @JsonProperty("persInfoFlag")
    private Boolean persInfoFlag;
    @JsonProperty("bkiFlag")
    private Boolean bkiFlag;
    @JsonProperty("taxUSAFlag")
    private Boolean taxUSAFlag;
    @JsonProperty("publicFlag")
    private Boolean publicFlag;
    @JsonProperty("passportData")
    @NotNull
    private PassportData passportData;
    @JsonProperty("foreignResident")
    private ForeignResident foreignResident;
    @JsonProperty("deliveryData")
    private DeliveryData deliveryData;
    @JsonProperty("contacts")
    private Contacts contacts;
    @JsonProperty("employment")
    private Employment employment;
    @JsonProperty("requestProduct")
    private String requestProduct;
    @JsonProperty("factAddress")
    private Address factAddress;

}
