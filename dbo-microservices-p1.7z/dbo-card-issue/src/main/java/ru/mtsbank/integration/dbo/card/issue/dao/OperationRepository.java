package ru.mtsbank.integration.dbo.card.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.Operations;

@Repository
public interface OperationRepository extends CrudRepository<Operations, String> {

    Operations findByHashPan(String hashPan);

}
