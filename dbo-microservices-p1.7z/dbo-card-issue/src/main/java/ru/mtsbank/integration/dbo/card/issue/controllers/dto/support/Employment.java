package ru.mtsbank.integration.dbo.card.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

@Getter
public class Employment {

    @JsonProperty("type")
    private String type;
    @JsonProperty("organization")
    private Organization organization;

    @Getter
    public static class Organization {
        @JsonProperty("fullName")
        private String fullName;
        @JsonProperty("activity")
        private Activity activity;

        @Getter
        public static class Activity {
            @JsonProperty("type")
            private String type;
            @JsonProperty("details")
            private String details;
        }

        @JsonProperty("factAddressWork")
        private Address factAddressWork;
    }

}
