package ru.mtsbank.integration.dbo.card.issue.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.TariffType;

@Repository
public interface TariffTypeRepository extends CrudRepository<TariffType, String> {

    TariffType findByProdCode(String prodCode);

}
