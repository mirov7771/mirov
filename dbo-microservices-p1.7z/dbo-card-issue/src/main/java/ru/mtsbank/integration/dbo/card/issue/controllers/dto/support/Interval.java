package ru.mtsbank.integration.dbo.card.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

@Setter
public class Interval {

    @JsonProperty("value")
    private String value;

}
