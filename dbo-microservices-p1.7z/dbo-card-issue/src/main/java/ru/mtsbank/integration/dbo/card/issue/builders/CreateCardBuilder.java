package ru.mtsbank.integration.dbo.card.issue.builders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.CreateCardReq;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.Address;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.DeliveryData;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.ForeignResident;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.support.PassportData;
import ru.mtsbank.integration.mts.xsd.SITE.req.*;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.*;

@Component
public class CreateCardBuilder {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    public String build(CreateCardReq req, String requestId){
        XMLGregorianCalendar curDate = getXmlGregorianCalendar(new Date());
        MtsSingleRequest mtsRequest = new MtsSingleRequest();
        mtsRequest.setMtsRequestId(requestId);
        mtsRequest.setMessageId(UUID.randomUUID().toString());
        mtsRequest.setMessageType(MessageType.REGISTER_REQ_SITE);
        mtsRequest.setMessageDateTime(curDate);
        mtsRequest.setSPName(SystemType.MTS_EIP_UMP);
        mtsRequest.setMsgReceiver(SystemType.SIEBEL);
        mtsRequest.setQuestionnaireType("SHORT");
        mtsRequest.setRequestContinType("CC");

        MtsSingleRequest.Request request = new MtsSingleRequest.Request();
        ClientData client = new ClientData();
        ClientRequestData clientRequest = new ClientRequestData();

        ClientCommonDataType clientCommonDataType = new ClientCommonDataType();
        ClientData.ClientListDocument clientListDocument = new ClientData.ClientListDocument();
        ClientData.ClientListAddress clientListAddress = new ClientData.ClientListAddress();
        ClientData.ClientListContact clientListContact = new ClientData.ClientListContact();

        clientCommonDataType.setFamily(req.getFamily());
        clientCommonDataType.setName(req.getName());
        clientCommonDataType.setFatherName(req.getFatherName());
        PassportData pasportData = req.getPassportData();
        clientCommonDataType.setClientSex(pasportData.getSex().equals(0) ? "Sx1" : "Sx2");
        clientCommonDataType.setBirthPlace(pasportData.getBirthPlace());
        clientCommonDataType.setBirthDate(getXmlGregorianCalendar(pasportData.getBirthDate()));
        clientCommonDataType.setStatusIPDL("IPDL.4");
        if (Boolean.TRUE.equals(req.getBkiFlag())) {
            clientCommonDataType.setFlagAllowPassBKI(true);
            clientCommonDataType.setFlagAllowPassBKIDate(curDate);
        } else {
            clientCommonDataType.setFlagAllowPassBKI(false);
        }
        clientCommonDataType.setFlagAllowReceiveInfoFromBank(Boolean.TRUE.equals(req.getSmsAgreeFlag()));
        clientCommonDataType.setFlagAllowPassOthersOrg(Boolean.TRUE.equals(req.getPersInfoFlag()));
        clientCommonDataType.setCodeWord(req.getCodeWord());
        clientCommonDataType.setGatkaFlg(Boolean.TRUE.equals(req.getGatkaFlg()));
        clientCommonDataType.setOfferAcceptance(Boolean.TRUE.equals(req.getPersInfoFlag()));

        if (Boolean.TRUE.equals(req.getFlagChangeFio())){
            clientCommonDataType.setFlagChangeFIO(true);
            clientCommonDataType.setPrevFamily(req.getPrevFamily());
            clientCommonDataType.setPrevName(req.getPrevName());
            clientCommonDataType.setPrevFatherName(req.getPrevFatherName());
        } else {
            clientCommonDataType.setFlagChangeFIO(false);
        }

        clientCommonDataType.setFlagAllowPassOthersOrg(true);
        if (req.getTotalIncome() != null
                && req.getTotalIncome().getAmount() != null){
            Amount totalIncome = new Amount();
            totalIncome.setCurrency(req.getTotalIncome().getCurrency() == null ? "RUR" : req.getTotalIncome().getCurrency());
            totalIncome.setSumma(req.getTotalIncome().getAmount());
            clientCommonDataType.setTotalIncome(totalIncome);
        }

        CountryInfo countryInfo = new CountryInfo();
        countryInfo.setCountryCode("643");
        countryInfo.setCountryName("Россия");
        clientCommonDataType.setCitizenship(countryInfo);

        client.setClientCommonData(clientCommonDataType);

        DocumentFullDataType doc = new DocumentFullDataType();
        doc.setIsPrimary(true);
        doc.setIsActive(true);
        doc.setDocumentType("DOCTYPE.FIRST.1");
        doc.setSerial(pasportData.getSerial());
        doc.setNumber(pasportData.getNumber());
        doc.setIssueOrgCode(pasportData.getIssueOrgCode());
        doc.setIssueOrgName(pasportData.getIssueOrgName());
        doc.setIssueDate(getXmlGregorianCalendar(pasportData.getIssueDate()));
        clientListDocument.getClientDocument().add(doc);

        ForeignResident foreignResident = req.getForeignResident();
        if (foreignResident != null && !StringUtils.isEmpty(foreignResident.getIssueCountry())) {
            DocumentFullDataType doc1 = new DocumentFullDataType();
            doc1.setIssueCountry(foreignResident.getIssueCountry());
            doc1.setDocumentType("FOREIGN.INN");
            doc1.setNumber(foreignResident.getIssueCountryINN());
            doc1.setIsActive(true);
            clientListDocument.getClientDocument().add(doc1);
        }

        client.setClientListDocument(clientListDocument);

        if (pasportData.getAddress() != null)
            clientListAddress.getClientAddress().add(getKladrAddress(pasportData.getAddress(), "req"));

        if (req.getFactAddress() != null)
            clientListAddress.getClientAddress().add(getKladrAddress(req.getFactAddress(), "fact"));


        if (req.getDeliveryData() != null
                && req.getDeliveryData().getDeliveryAddress() != null
                && !StringUtils.isEmpty(req.getDeliveryData().getDeliveryAddress().getCountryName())) {
            clientListAddress.getClientAddress().add(getDeliveryKladrAddress(req.getDeliveryData().getDeliveryAddress()));
        }

        client.setClientListAddress(clientListAddress);

        Contact phone = new Contact();
        phone.setIsPrimary(true);
        phone.setContactType("CONTACT.TYPE.1");
        phone.setValue(req.getMobilePhone());
        clientListContact.getClientContact().add(phone);
        Contact email = new Contact();
        email.setIsPrimary(false);
        email.setContactType("CONTACT.TYPE.4");
        email.setValue(req.getEmail());
        clientListContact.getClientContact().add(email);
        client.setClientListContact(clientListContact);

        if (req.getContacts() != null){
            if (!isEmpty(req.getContacts().getAdditionalPhone1())) {
                Contact extPhone1 = new Contact();
                extPhone1.setIsPrimary(false);
                extPhone1.setContactType("CONTACT.TYPE.8");
                extPhone1.setValue(req.getContacts().getAdditionalPhone1());
                clientListContact.getClientContact().add(extPhone1);
            }
            if (!isEmpty(req.getContacts().getAdditionalPhone2())) {
                Contact extPhone2 = new Contact();
                extPhone2.setIsPrimary(false);
                extPhone2.setContactType("CONTACT.TYPE.6");
                extPhone2.setValue(req.getContacts().getAdditionalPhone2());
                clientListContact.getClientContact().add(extPhone2);
            }
        }

        if (req.getDeliveryData() != null
                && req.getDeliveryData().getDeliveryAddress() != null
                && req.getDeliveryData().getDeliveryDate() != null
                && req.getDeliveryData().getDeliveryTime() != null)
        {
            ClientData.ClientDeliveryInfo clientDeliveryInfo = new ClientData.ClientDeliveryInfo();
            clientDeliveryInfo.setTimeIntervalDelivery(req.getDeliveryData().getDeliveryTime());
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            clientDeliveryInfo.setDateDelivery(df.format(req.getDeliveryData().getDeliveryDate()));
            clientDeliveryInfo.setClientAppDeliveryInHand(true);
            client.setClientDeliveryInfo(clientDeliveryInfo);
        }

        if (req.getEmployment() != null && req.getEmployment().getOrganization() != null) {
            ClientData.ClientListWork clientListWork = new ClientData.ClientListWork();
            PerWorkType perWorkType = new PerWorkType();
            perWorkType.setWorkType(true);
            perWorkType.setFullName(req.getEmployment().getOrganization().getFullName());
            if (req.getEmployment().getOrganization().getFactAddressWork() != null){
                ClientWorkAddressList clientWorkAddressList = new ClientWorkAddressList();
                clientWorkAddressList.getAddress().add(getKladrAddress(req.getEmployment().getOrganization().getFactAddressWork(), "employ"));
                clientWorkAddressList.getAddress().add(getKladrAddress(req.getEmployment().getOrganization().getFactAddressWork(), "legal"));
                perWorkType.setAddresses(clientWorkAddressList);
            }
            if (req.getEmployment().getOrganization().getActivity() != null
                    && !isEmpty(req.getEmployment().getOrganization().getActivity().getType()))
            {
                perWorkType.setActivityType(req.getEmployment().getOrganization().getActivity().getType());
                if (!isEmpty(req.getEmployment().getOrganization().getActivity().getDetails()))
                    perWorkType.setActivityTypeDetail(req.getEmployment().getOrganization().getActivity().getDetails());
            }
            if (!isEmpty(req.getEmployment().getType())){
                perWorkType.setEmploymentType(req.getEmployment().getType());
            }
            clientListWork.getClientWork().add(perWorkType);
            client.setClientListWork(clientListWork);
        }

        request.setClient(client);

        String type = req.getType();
        ClientRequestCommonDataType requestCommonDataType = new ClientRequestCommonDataType();
        ClientRequestProductDataType product = new ClientRequestProductDataType();
        product.setProductType("CARD");
        if (isEmpty(req.getRequestProduct())) {
            product.setProductCode(type.equals("DEBET") ? "MTS.MONEY.WEEKEND" : "none");
        } else {
            product.setProductCode(req.getRequestProduct());
        }
        if (req.getRequestedLimit() != null) {
            product.setCurrency(isEmpty(req.getRequestedLimit().getCurrency()) ? "RUR" : req.getRequestedLimit().getCurrency());
            product.setRequestSumma(req.getRequestedLimit().getAmount() == null ? BigDecimal.ZERO : req.getRequestedLimit().getAmount());
        } else {
            product.setCurrency("RUR");
            product.setRequestSumma(BigDecimal.ZERO);
        }
        product.setCard(new ClientRequestCardDataType(){{
            setCardCategory(type.equals("DEBET") ? "MASTER.INT.WORLD" : "MASTER.INT.STANDART");
            setCardType(type.equals("DEBET") ? "Д" : "К");
            setPlastCat("CARD.EXPRESS");
            setSubProductType(type.equals("DEBET") ? "MTS.WEEKEND" : "MTS.WEEKEND.CC");
        }});
        requestCommonDataType.setProduct(product);

        String deliveryTime = "";
        DeliveryData deliveryData = req.getDeliveryData();
        if (deliveryData != null && deliveryData.getDeliveryTime() != null)
            deliveryTime = deliveryData.getDeliveryTime();

        String callingTime;
        if (deliveryTime.equals("09:00 - 14:00")) {
            callingTime = "CALLING.TIME.1";
        } else if (deliveryTime.equals("14:00 - 19:00")) {
            callingTime = "CALLING.TIME.2";
        } else {
            callingTime = "CALLING.TIME.3";
        }

        requestCommonDataType.setCallback(new ClientRequestCommonDataType.Callback(){{
            setCallTime(callingTime);
            setTimeZone("CLIENT.TIME.ZONE.2");
        }});
        requestCommonDataType.setChannel(req.getChannel());
        requestCommonDataType.setBankInfoSource(new ClientRequestCommonDataType.BankInfoSource(){{
            setSourceOfInformation("SOURCE.OF.INFORMATION.17");
        }});
        requestCommonDataType.setUtmInfo(new ClientRequestCommonDataType.UtmInfo(){{
            setUtmSource("none");
            setUtmMedium("none");
            setUtmCampaign("none");
            setUtmLeads("none");
            setUtmTerm("none");
            setUtmContent("none");
        }});

        clientRequest.setClientRequestCommonData(requestCommonDataType);
        request.setClientRequest(clientRequest);

        mtsRequest.setRequest(request);
        return xmlUnmarshaler.createXml(mtsRequest);
    }

    private AddressKLADRFull getKladrAddress(Address reqAddr, String type){
        AddressKLADRFull address = new AddressKLADRFull();
        String addrType = "ADDRESS.TYPE.1";
        if ("fact".equals(type))
            addrType = "ADDRESS.TYPE.2";
        else if ("legal".equals(type))
            addrType = "ADDRESS.WRK.LEGAL";
        else if ("employ".equals(type))
            addrType = "ADDRESS.WRK.CHIEF";
        address.setAddressType(addrType);
        address.setCountryName(reqAddr.getCountryName());
        address.setCountryCode(reqAddr.getCountryCode());
        address.setRegionName(reqAddr.getRegionName());
        address.setRegionCode(reqAddr.getRegionCode());
        address.setRegionSocr(reqAddr.getRegionSocr());
        address.setDistrictName(reqAddr.getDistrictName());
        address.setLocalityName(reqAddr.getLocalityName());
        address.setCityName(reqAddr.getCityName());
        address.setStreetName(reqAddr.getStreetName());
        address.setHouse(reqAddr.getHouse());
        address.setBuilding(reqAddr.getBuilding());
        address.setBlock(reqAddr.getBlock());
        address.setFlat(reqAddr.getFlat());
        address.setZipCode(reqAddr.getZipCode());
        address.setIsKladr(false);
        address.setIsMailAddress(true);
        address.setCitySocr(reqAddr.getCityType());
        address.setLocalitySocr(reqAddr.getLocalityType());
        address.setStreetSocr(reqAddr.getStreetType());
        return address;
    }

    private AddressKLADRFull getDeliveryKladrAddress(Address reqAddr){
        AddressKLADRFull address = new AddressKLADRFull();
        address.setAddressType("ADDRESS.TYPE.7");
        address.setCountryName(reqAddr.getCountryName());
        address.setCountryCode(reqAddr.getCountryCode());
        address.setRegionName(reqAddr.getRegionName());
        address.setRegionCode(reqAddr.getRegionCode());
        address.setRegionSocr(reqAddr.getRegionSocr());
        address.setDistrictName(reqAddr.getDistrictName());
        address.setLocalityName(reqAddr.getLocalityName());
        address.setCityName(reqAddr.getCityName());
        address.setStreetName(reqAddr.getStreetName());
        address.setHouse(reqAddr.getHouse());
        address.setBuilding(reqAddr.getBuilding());
        address.setBlock(reqAddr.getBlock());
        address.setFlat(reqAddr.getFlat());
        address.setZipCode(reqAddr.getZipCode());
        address.setIsKladr(false);
        address.setIsMailAddress(true);
        address.setCitySocr(reqAddr.getCityType());
        address.setLocalitySocr(reqAddr.getLocalityType());
        address.setStreetSocr(reqAddr.getStreetType());
        return address;
    }

}
