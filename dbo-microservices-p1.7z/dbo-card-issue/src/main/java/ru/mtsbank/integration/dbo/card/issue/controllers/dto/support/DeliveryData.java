package ru.mtsbank.integration.dbo.card.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.Date;

@Getter
public class DeliveryData {

    @JsonProperty("deliveryTime")
    private String deliveryTime;
    @JsonProperty("deliveryDate")
    private Date deliveryDate;
    @JsonProperty("deliveryAddress")
    private Address deliveryAddress;

}
