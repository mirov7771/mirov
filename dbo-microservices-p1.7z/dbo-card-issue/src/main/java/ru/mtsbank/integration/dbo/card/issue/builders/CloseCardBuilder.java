package ru.mtsbank.integration.dbo.card.issue.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.card.issue.controllers.dto.request.CloseCardReq;
import ru.mtsbank.integration.dbo.card.issue.dao.OperationRepository;
import ru.mtsbank.integration.dbo.card.issue.dao.model.Operations;
import ru.mtsbank.integration.dbo.card.issue.dao.operations.CardOperations;
import ru.mtsbank.integration.mts.xsd.CardStatusMod.*;

import java.util.*;

import static ru.mts.dbo.utils.Utils.getSumm;
import static ru.mts.dbo.utils.Utils.nvl;

@Component
@Slf4j
public class CloseCardBuilder {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private OperationRepository operationRepository;

    @Autowired
    private CardOperations cardOperations;

    private static final Set<String> STATUS_CODE = new HashSet<>();
    static {
        STATUS_CODE.add("1");
        STATUS_CODE.add("2");
        STATUS_CODE.add("3");
        STATUS_CODE.add("4");
        STATUS_CODE.add("5");
        STATUS_CODE.add("6");
        STATUS_CODE.add("7");
        STATUS_CODE.add("8");
    }

    public String build(CloseCardReq req, String operType, String rqUid){
        CardStatusModRq rq = new CardStatusModRq();
        rq.setBpId("MTS_CRD_STAT_MOD");
        rq.setRqUID(rqUid);
        rq.setMsgUID(rqUid);
        rq.setSPName("MTS_EIP_UMP");
        rq.setMsgReceiver("RBO");
        rq.setMsgType("CardStatusModRq");

        CardInfo cardInfo = new CardInfo();
        cardInfo.setHashPAN(req.getHashPan());
        FDXCardStatus cardStatus = new FDXCardStatus();
        String type = "2";
        String extMsgType = "2";
        Operations oper;
        String hashPan = req.getHashPan();
        if (operType.equalsIgnoreCase("info")) {
            cardOperations.deleteOperations(hashPan);
            oper = operationRepository.save(new Operations(hashPan));
        } else {
            oper = operationRepository.findByHashPan(hashPan);
        }
        if (!StringUtils.isEmpty(req.getType()) && req.getType().equalsIgnoreCase("close")) {
            extMsgType = "3";
            if (oper.getOperId() != null)
                rq.setExtOrderId(oper.getOperId().toString());
        }
        cardStatus.setCardStatusCode(type);
        cardInfo.setCardStatus(cardStatus);
        rq.setCardInfo(cardInfo);
        rq.setXferInfo(new XferInfo(){{
            setXferCode("0");
        }});
        //rq.setBankIncome(true);
        rq.setExtMsgType(extMsgType);
        return xmlUnmarshaler.createXml(rq);
    }

    public Map<String, String> check(String xml, String type){
        Map<String, String> output = new HashMap<>();
        if (!StringUtils.isEmpty(xml)) {
            CardStatusModRs rs = xmlUnmarshaler.parse(CardStatusModRs.class, xml);
            if (rs != null
                    && rs.getStatus() != null
                    && rs.getStatus().getStatusCode() != null)
            {
                String statusCode = rs.getStatus().getStatusCode();
                output.put("statusCode", statusCode);
                String cardStatusCode = null;
                String cardActualStatusCode = null;
                String statusDesc = null;
                if (rs.getCardInfo().getCardStatus() != null) {
                    cardStatusCode = rs.getCardInfo().getCardStatus().getCardStatusCode();
                    statusDesc = rs.getCardInfo().getCardStatus().getStatusDesc();
                }
                if (!statusCode.equals("0")
                        && !statusCode.equals("3"))
                    output.put("statusDesc", nvl(rs.getStatus().getStatusDesc(),"Технический сбой"));
                if ("info".equals(type)) {
                    if (rs.getCardInfo() != null && rs.getStatus() != null){
                        statusDesc = rs.getStatus().getStatusDesc();
                        String amt = getSumm(rs.getStatus().getStatusDesc());
                        log.info("Amt {}", amt);
                        switch (statusCode){
                            case "1":
                                statusDesc = "Для закрытия карты необходимо погасить задолженность";
                                break;
                            case "2":
                                statusDesc = "Для закрытия карты необходимо погасить комиссию";
                                break;
                            case "3":
                                statusDesc = "На вашем счету *** рублей, сначала выведите остаток и повторите попытку. Чтобы закрыть карту сейчас, нажмите Закрыть, тогда  карта будет закрыта, а остаток переведен банку.";
                                break;
                            case "4":
                                statusDesc = "На вашем счету *** рублей, сначала выведите остаток и повторите попытку";
                                break;
                            case "5":
                                statusDesc = "Счет заблокирован. Обратись в службу поддержки https://www.mtsbank.ru/os";
                                break;
                            case "6":
                                statusDesc = "Заявка на закрытие счета по карте уже принята.";
                                break;
                            case "7":
                                statusDesc = "Карта закрыта. До новых встреч:)";
                                break;
                            case "8":
                                statusDesc = "Эх, эта операция доступна только по основной карте:(";
                                break;
                            case "0":
                                statusDesc = "Ваша карта будет закрыта. Совсем скоро вы не сможете ее использовать.";
                                break;
                        }
                        output.put("cardStatusCode", cardActualStatusCode);
                        if (statusDesc.contains("***")) {
                            statusDesc = statusDesc.replace("***", amt);
                        }
                        output.put("descriprion", statusDesc);
                    } else {
                        output.put("cardStatusCode", "0");
                        output.put("descriprion", "Ваша карта будет закрыта. Совсем скоро вы не сможете ее использовать.");
                    }
                } else if ("close".equals(type)) {
                    if (rs.getCardInfo() != null && rs.getCardInfo().getCardStatus() != null){
                        output.put("cardStatusCode", cardStatusCode);
                        output.put("descriprion", statusDesc);
                    }
                }
                output.put("status", cardStatusCode);
            }
        }
        return output;
    }

}
