package ru.mtsbank.integration.dbo.card.issue.dao.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "DELIVERYZONE")
@Getter @Setter
public class DeliveryZone implements Serializable {

    private static final long serialVersionUID = -7376910519649730419L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "ZONEID")
    private String zoneId;
    @Column(name = "FIASCODE")
    private String fiasCode;
    @Column(name = "DELIVERYINTERVAL")
    private String deliveryInterval;
    @Column(name = "DELIVERYDAYS")
    private String deliveryDays;
    @Column(name = "REGION")
    private String region;
    @Column(name = "DISTRICT")
    private String district;
    @Column(name = "CITY")
    private String city;
    @Column(name = "STATEPROV")
    private String stateProv;

    public DeliveryZone(){

    }

    public DeliveryZone(String zoneId
            , String fiasCode
            , String deliveryInterval
            , String deliveryDays
            , String region
            , String city
            , String stateProv){
        this.zoneId = zoneId;
        this.fiasCode = fiasCode;
        this.deliveryInterval = deliveryInterval;
        this.deliveryDays = deliveryDays;
        this.region = region;
        this.city = city;
        this.stateProv = stateProv;
    }

}
