package ru.mtsbank.integration.dbo.card.issue.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;

import java.util.Date;

@Getter
public class PassportData {

    @JsonProperty("sex")
    private Integer sex;
    @JsonProperty("birthDate")
    private Date birthDate;
    @JsonProperty("birthPlace")
    private String birthPlace;
    @JsonProperty("serial")
    private String serial;
    @JsonProperty("number")
    private String number;
    @JsonProperty("issueOrgCode")
    private String issueOrgCode;
    @JsonProperty("issueOrgName")
    private String issueOrgName;
    @JsonProperty("issueDate")
    private Date issueDate;
    @JsonProperty("address")
    private Address address;

}
