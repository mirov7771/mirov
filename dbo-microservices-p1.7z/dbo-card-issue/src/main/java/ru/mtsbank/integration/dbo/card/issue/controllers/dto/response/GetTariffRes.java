package ru.mtsbank.integration.dbo.card.issue.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;

import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class GetTariffRes extends BaseResponse {

    @JsonProperty("tariffList")
    private List<Map<String, Object>> tariffList;

}
