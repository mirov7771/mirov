package ru.mtsbank.integration.dbo.card.issue.notifications;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
@Slf4j
public class NotificationConsumer {

    @Autowired
    private Map<String, NotificationService> notificationServices;

    @KafkaListener(topics = {"dbo.card.delivery.zone"}, containerFactory = "kafkaListenerContainerFactory")
    public void consume(ConsumerRecord<? , String> message){
        try{
            String topic = message.topic();
            String value = message.value();
            log.info("get message from topic ["+topic+"] with value ["+value+"]");
            NotificationService service = notificationServices.get(topic);
            service.handleRequest(message.value());
        } catch (Exception e) {
            log.error("Error send to topic: "+e);
            e.printStackTrace();
        }
    }

}
