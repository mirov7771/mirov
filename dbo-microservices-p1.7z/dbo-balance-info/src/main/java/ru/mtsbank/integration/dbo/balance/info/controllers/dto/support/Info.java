package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;

@Setter @Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Info {

    @JsonProperty("accounts")
    private Product accounts;
    @JsonProperty("cards")
    private Product cards;
    @JsonProperty("deposits")
    private Product deposits;
    @JsonProperty("loans")
    private Product loans;
    @JsonProperty("others")
    private Product others;

    @Setter @Getter
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Product {

        private BigDecimal amount;
        private List<Prd> list;

        @Setter @Getter
        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class Prd {
            private Integer id;
            private String number;
            private String agree;
            private BigDecimal rest;
            private BigDecimal restRur;
            private BigDecimal debt;
            private BigDecimal debtRur;
            private String paymentSystem;
            private String currency;
            private String bankName;
            private String hashPan;
            private String type;
        }

        @JsonIgnore
        public Boolean isEmpty(){
            return CollectionUtils.isEmpty(list) && (BigDecimal.ZERO.equals(amount) || amount == null);
        }
    }

    @JsonIgnore
    public Boolean isEmpty(){
        return accounts != null
                && accounts.isEmpty()
                && cards != null
                && cards.isEmpty()
                && deposits != null
                && deposits.isEmpty()
                && loans != null
                && loans.isEmpty()
                && others != null
                && others.isEmpty();
    }

}
