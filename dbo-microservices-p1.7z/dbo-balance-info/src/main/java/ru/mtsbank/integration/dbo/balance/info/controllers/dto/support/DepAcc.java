package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class DepAcc {

    @JsonProperty("number")
    private String number;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("agreement")
    private Agreement agreement;
    @JsonProperty("amountInfo")
    private AmountInfo amountInfo;
    @JsonProperty("type")
    private String type;

}
