package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Loans {

    @JsonProperty("loans")
    private List<Loan> loans;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Loan{
        @JsonProperty("agreementNum")
        private String agreementNum;
        @JsonProperty("debtAmount")
        private BigDecimal debtAmount;
        @JsonProperty("loanStatusCode")
        private String loanStatusCode;
        @JsonProperty("loanCurCode")
        private String loanCurCode;
        @JsonProperty("loanType")
        private String loanType;
        @JsonProperty("agreementCurCode")
        private String agreementCurCode;
    }

}
