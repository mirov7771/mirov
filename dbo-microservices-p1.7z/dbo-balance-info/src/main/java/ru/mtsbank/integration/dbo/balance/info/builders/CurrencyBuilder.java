package ru.mtsbank.integration.dbo.balance.info.builders;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.enums.Currency;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;
import ru.mtsbank.integration.dbo.balance.info.gates.CurrencyGate;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static ru.mts.dbo.utils.Utils.isEmpty;

@RequiredArgsConstructor
@Component
@Slf4j
public class CurrencyBuilder {

    private final CurrencyGate currencyGate;

    public Map<String, String> prepareCurrencies(Accounts accounts, Cards cards, Deposits deposits, Loans loans, Offers offers, String uid) throws IOException {
        Map<String, String> map = new HashMap<>();
        map.put("RUB","1");
        map.put("RUR","1");
        map.put("810","1");
        map.put("643","1");
        Set<String> curr = new HashSet<>();
        if (accounts != null && !CollectionUtils.isEmpty(accounts.getAccounts())){
            log.info("{} get accounts currency",uid);
            for(DepAcc account : accounts.getAccounts()){
                if (!curr.contains(account.getCurrency()) && !Currency.isRub(account.getCurrency()))
                    curr.add(account.getCurrency());
            }
        }
        if (cards != null && !CollectionUtils.isEmpty(cards.getCards())){
            log.info("{} get cards currency",uid);
            for(Cards.Card card : cards.getCards()){
                if (!curr.contains(card.getCurrency()) && !Currency.isRub(card.getCurrency()))
                    curr.add(card.getCurrency());
            }
        }
        if (deposits != null && !CollectionUtils.isEmpty(deposits.getDeposits())){
            log.info("{} get deposits currency",uid);
            for(DepAcc deposit : deposits.getDeposits()){
                if (!curr.contains(deposit.getCurrency()) && !Currency.isRub(deposit.getCurrency()))
                    curr.add(deposit.getCurrency());
            }
        }
        if (loans != null && !CollectionUtils.isEmpty(loans.getLoans())){
            log.info("{} get loans currency",uid);
            for(Loans.Loan loan : loans.getLoans()){
                if (!curr.contains(loan.getLoanCurCode()) && !Currency.isRub(loan.getLoanCurCode()))
                    curr.add(loan.getLoanCurCode());
            }
        }
        if (offers != null && !CollectionUtils.isEmpty(offers.getOfferList())){
            for(Offers.Offer offer : offers.getOfferList()){
                if (!CollectionUtils.isEmpty(offer.getAccounts())){
                    log.info("{} get offers currency",uid);
                    for (Offers.Offer.OfferAccount offerAccount : offer.getAccounts()){
                        String currency = offerAccount.getCurrency();
                        if ("840".equals(currency))
                            currency = "USD";
                        else if ("978".equals(currency))
                            currency = "EUR";
                        else if ("826".equals(currency))
                            currency = "GPB";
                        if (!curr.contains(currency) && !Currency.isRub(currency))
                            curr.add(currency);
                    }
                }
            }
        }

        for(String cur : curr){
            log.info("{} search rate for currency {}",uid, cur);
            CurrencyRate currencyRate = currencyGate.getCurrency(cur);
            if (currencyRate != null && currencyRate.getData() != null && !isEmpty(currencyRate.getData().getBuy())) {
                log.info("{} get rate for currency {} is {} ",uid, cur, currencyRate.getData().getBuy());
                map.put(cur, currencyRate.getData().getBuy());
            }
        }
        log.info("{} currency map {}",uid, map);
        return map;
    }

    public String getCurrencyName(String currency){
        if ("840".equals(currency))
            currency = "USD";
        else if ("978".equals(currency))
            currency = "EUR";
        else if ("826".equals(currency))
            currency = "GPB";
        else if ("810".equals(currency))
            currency = "RUR";
        else if ("RUB".equals(currency))
            currency = "RUB";
        return currency;
    }

}
