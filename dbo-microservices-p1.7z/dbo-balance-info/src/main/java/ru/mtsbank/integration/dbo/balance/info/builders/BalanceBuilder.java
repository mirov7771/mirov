package ru.mtsbank.integration.dbo.balance.info.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.response.BalanceRes;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Slf4j
public class BalanceBuilder extends ResBuilder<BalanceRes> {

    @Override
    public void build(BalanceRes res
            , Long rboId
            , String phone
            , String uuid)
    throws ExecutionException, InterruptedException, IOException
    {
        uid = uuid;
        BigDecimal amount = BigDecimal.ZERO;
        CompletableFuture<Accounts> callAccounts = asyncCall.getAccounts(rboId);
        CompletableFuture<Cards> callCards = asyncCall.getCards(rboId);
        CompletableFuture<Offers> callOffers = asyncCall.getOffers(phone);
        CompletableFuture.allOf(callAccounts, callCards, callOffers);

        Accounts accounts = callAccounts.get();
        Cards cards = callCards.get();
        Offers offers = callOffers.get();

        currencies = currencyBuilder.prepareCurrencies(accounts, cards, null,null, offers, uid);

        Info info = new Info();
        if (accounts != null && !CollectionUtils.isEmpty(accounts.getAccounts())) {
            Info.Product account = getAccounts(accounts, "account");
            Info.Product deposit = getAccounts(accounts, "deposit");
            if (!Boolean.TRUE.equals(account.isEmpty())) {
                info.setAccounts(account);
                amount = amount.add(account.getAmount());
            }
            if (!Boolean.TRUE.equals(deposit.isEmpty())) {
                info.setDeposits(deposit);
                amount = amount.add(deposit.getAmount());
            }
        }
        if (cards != null && !CollectionUtils.isEmpty(cards.getCards())) {
            Info.Product card = getCards(cards);
            if (!Boolean.TRUE.equals(card.isEmpty())) {
                info.setCards(card);
                amount = amount.add(card.getAmount());
            }
        }
        if (offers != null && !CollectionUtils.isEmpty(offers.getOfferList())) {
            Info.Product other = getOthers(offers, "rest");
            if (!Boolean.TRUE.equals(other.isEmpty())) {
                info.setOthers(other);
                amount = amount.add(other.getAmount());
            }
        }
        if (!Boolean.TRUE.equals(info.isEmpty())) {
            res.setInfo(info);
        }
        res.setAmount(amount);
        res.setRequestId(uid);
        log.info("{} all products amount is {}", uid, amount);
    }

}
