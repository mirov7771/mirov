package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class CurrencyRate {

    @JsonProperty("data")
    private CurData data;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class CurData{
        @JsonProperty("buy")
        private String buy;
    }

}
