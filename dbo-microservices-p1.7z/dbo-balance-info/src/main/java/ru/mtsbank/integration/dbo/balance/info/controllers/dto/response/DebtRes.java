package ru.mtsbank.integration.dbo.balance.info.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.Info;

import java.math.BigDecimal;

@Setter @Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DebtRes extends BaseResponse {

    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("info")
    private Info info;

}
