package ru.mtsbank.integration.dbo.balance.info.service;

import ru.mts.dbo.dto.BaseResponse;

public interface Service {
    BaseResponse balance(Long rboId, String phone);
    BaseResponse debt(Long rboId, String phone);
}
