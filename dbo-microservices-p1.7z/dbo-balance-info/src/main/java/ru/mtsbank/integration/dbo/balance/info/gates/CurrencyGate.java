package ru.mtsbank.integration.dbo.balance.info.gates;

import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.CurrencyRate;

import java.io.IOException;

public interface CurrencyGate {

    CurrencyRate getCurrency(String currency) throws IOException;

}
