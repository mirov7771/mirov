package ru.mtsbank.integration.dbo.balance.info.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.response.BalanceRes;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.response.DebtRes;
import ru.mtsbank.integration.dbo.balance.info.service.Service;

import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;
import static ru.mts.dbo.utils.Utils.getRboIdFromToken;
import static ru.mts.dbo.utils.Utils.getSrcPhoneFromToken;

@Tag(name = "BalanceInfo")
@RestController
@RequestMapping("dbo-balance-info")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;


    @GetMapping(value = "{version}/balance", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "Метод получает сумму всех остатков"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = BalanceRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> balance (@PathVariable final String version
                                                ,@RequestHeader(value = "Authorization", required = false) String authorization)
    {
        return ResponseBuilder.build(services.get(version).balance(getRboIdFromToken(authorization), getSrcPhoneFromToken(authorization)));
    }

    @GetMapping(value = "{version}/debt", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "Метод получает сумму всех задолженностей"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = DebtRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            }),
            @ApiResponse(responseCode = "403", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> debt (@PathVariable final String version
                                             ,@RequestHeader(value = "Authorization", required = false) String authorization)
    {
        return ResponseBuilder.build(services.get(version).debt(getRboIdFromToken(authorization), getSrcPhoneFromToken(authorization)));
    }

}
