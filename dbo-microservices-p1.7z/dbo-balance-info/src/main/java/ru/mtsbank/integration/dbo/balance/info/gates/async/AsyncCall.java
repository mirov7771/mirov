package ru.mtsbank.integration.dbo.balance.info.gates.async;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;
import ru.mtsbank.integration.dbo.balance.info.gates.MtsGate;

import java.util.concurrent.CompletableFuture;

@Component
@RequiredArgsConstructor
public class AsyncCall {

    private final MtsGate mtsGate;

    @Async
    public CompletableFuture<Accounts> getAccounts(Long rboId){
        return CompletableFuture.completedFuture(mtsGate.getAccountList(rboId));
    }

    @Async
    public CompletableFuture<Deposits> getDeposits(Long rboId){
        return CompletableFuture.completedFuture(mtsGate.getDepositList(rboId));
    }

    @Async
    public CompletableFuture<Cards> getCards(Long rboId){
        return CompletableFuture.completedFuture(mtsGate.getCardList(rboId));
    }

    @Async
    public CompletableFuture<Loans> getLoans(Long rboId){
        return CompletableFuture.completedFuture(mtsGate.getLoanList(rboId));
    }

    @Async
    public CompletableFuture<Offers> getOffers(String phone){
        return CompletableFuture.completedFuture(mtsGate.getOffers(phone));
    }

}
