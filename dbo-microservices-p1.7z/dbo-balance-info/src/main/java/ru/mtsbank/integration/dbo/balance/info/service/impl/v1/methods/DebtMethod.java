package ru.mtsbank.integration.dbo.balance.info.service.impl.v1.methods;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.utils.DboException;
import ru.mtsbank.integration.dbo.balance.info.builders.DebtBuilder;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.response.DebtRes;

import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import static ru.mts.dbo.utils.Utils.getStackError;
import static ru.mts.dbo.utils.Utils.preCheckToken;

@Component
@RequiredArgsConstructor
@Slf4j
public class DebtMethod {

    private final DebtBuilder debtBuilder;

    public DebtRes call(Long rboId, String phone) {
        DebtRes res = new DebtRes();
        String uuid = UUID.randomUUID().toString();
        log.info("{} Start service Debt with params: rboId = {}, phone = {}",uuid,rboId,phone);
        try {
            preCheckToken(rboId, phone, "balance", uuid);
            debtBuilder.build(res, rboId, phone, uuid);
            res.setRequestId(uuid);
        } catch (DboException e){
            throw new DboException(e.getType(),e.getSystem(),e.getUuid());
        } catch (ExecutionException | InterruptedException | IOException e){
            getStackError(e);
            res.createError(501, "Сервис временно недоступен", 406, null, null, "balance", uuid);
        }
        log.info("{} End service Debt", uuid);
        return res;
    }

}
