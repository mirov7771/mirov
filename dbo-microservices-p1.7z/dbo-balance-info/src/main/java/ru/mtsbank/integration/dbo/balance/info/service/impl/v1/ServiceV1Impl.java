package ru.mtsbank.integration.dbo.balance.info.service.impl.v1;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.response.DebtRes;
import ru.mtsbank.integration.dbo.balance.info.service.Service;
import ru.mtsbank.integration.dbo.balance.info.service.impl.v1.methods.*;

@Component("v1")
@RequiredArgsConstructor
public class ServiceV1Impl implements Service {


    private final BalanceMethod balanceMethod;
    private final DebtMethod debtMethod;

    @Override
    public BaseResponse balance(Long rboId, String phone){
        return balanceMethod.call(rboId,phone);
    }

    @Override
    public DebtRes debt(Long rboId, String phone){
        return debtMethod.call(rboId,phone);
    }


}
