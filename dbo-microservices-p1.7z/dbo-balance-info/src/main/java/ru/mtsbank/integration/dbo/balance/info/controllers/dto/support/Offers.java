package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Offers {

    @JsonProperty("offerList")
    private List<Offer> offerList;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Offer{
        @JsonProperty("accounts")
        private List<OfferAccount> accounts;
        @JsonProperty("bankName")
        private String bankName;
        @JsonProperty("bankConsent")
        private Boolean bankConsent;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @Data
        public static class OfferAccount{
            @JsonProperty("name")
            private String name;
            @JsonProperty("type")
            private String type;
            @JsonProperty("balance")
            private BigDecimal balance;
            @JsonProperty("debt")
            private BigDecimal debt;
            @JsonProperty("currency")
            private String currency;
            @JsonProperty("consent")
            private Boolean consent;
        }
    }

}
