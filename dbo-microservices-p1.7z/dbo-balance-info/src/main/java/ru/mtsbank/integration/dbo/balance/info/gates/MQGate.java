package ru.mtsbank.integration.dbo.balance.info.gates;

import ru.mtsbank.integration.mts.xsd.DBOCust.cardsvcinqrs.CardSvcInqRs;

import java.io.IOException;

public interface MQGate {

    CardSvcInqRs getCardBalance(String xml) throws IOException;

}
