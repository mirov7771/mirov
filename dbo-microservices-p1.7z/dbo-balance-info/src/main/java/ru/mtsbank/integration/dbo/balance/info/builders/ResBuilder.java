package ru.mtsbank.integration.dbo.balance.info.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.w3c.dom.NodeList;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.utils.Utils;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;
import ru.mtsbank.integration.dbo.balance.info.gates.MQGate;
import ru.mtsbank.integration.dbo.balance.info.gates.async.AsyncCall;
import ru.mtsbank.integration.mts.xsd.DBOCust.cardsvcinqrs.CardSvcInqRs;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Slf4j
public abstract class ResBuilder<T extends BaseResponse> {

    @Autowired
    protected MQGate mqGate;

    @Autowired
    protected AsyncCall asyncCall;

    @Autowired
    protected CurrencyBuilder currencyBuilder;

    @Autowired
    protected XmlBuilder xmlBuilder;

    protected static Map<String, String> currencies = new HashMap<>();
    protected static String uid;

    public abstract void build(T res, Long rboId, String phone, String uuid) throws ExecutionException, InterruptedException, IOException;

    protected Info.Product getLoans(Loans loans){
        Info.Product product = new Info.Product();
        BigDecimal amt = BigDecimal.ZERO;
        List<Info.Product.Prd> list = new ArrayList<>();
        int i = 1;
        for(Loans.Loan item : loans.getLoans()){
            if ("WORK".equalsIgnoreCase(item.getLoanStatusCode())
                    && item.getDebtAmount() != null
                    && item.getLoanCurCode() != null)
            {
                log.info("{} processing loan {}", uid,item.toString());
                Info.Product.Prd prd = new Info.Product.Prd();
                prd.setId(i);
                prd.setNumber(item.getAgreementNum());
                prd.setType(item.getLoanType());
                prd.setDebt(item.getDebtAmount());
                String currency = currencyBuilder.getCurrencyName(item.getAgreementCurCode());
                prd.setCurrency(currency);
                prd.setDebtRur(item.getDebtAmount().multiply(new BigDecimal(currencies.get(currency))));
                amt = amt.add(prd.getDebtRur());
                if (!prd.getDebtRur().equals(BigDecimal.ZERO))
                    list.add(prd);
            }
        }
        product.setList(list);
        product.setAmount(amt);
        log.info("{} loan debt is {}", uid, amt);
        return product;
    }

    protected Info.Product getAccounts(Accounts accounts, String type){
        Info.Product product = new Info.Product();
        BigDecimal amt = BigDecimal.ZERO;
        List<Info.Product.Prd> list = new ArrayList<>();
        int i = 1;
        for(DepAcc item : accounts.getAccounts()) {
            log.info("{} processing acc product {}", uid, item.toString());
            if (item.getAgreement() != null
                    && "WORK".equalsIgnoreCase(item.getAgreement().getStatus())
                    && item.getAmountInfo() != null
                    && item.getAmountInfo().getBalance() != null
                    && item.getAmountInfo().getBalance().getAmount() != null) {
                if (type.equals("deposit")) {
                    if ("DEPOSIT_ACC".equalsIgnoreCase(item.getType())) {
                        log.info("{} processing deposit {}", uid, item.toString());
                        String currency = currencyBuilder.getCurrencyName(item.getCurrency());
                        Info.Product.Prd prd = new Info.Product.Prd();
                        prd.setId(i);
                        prd.setAgree(item.getAgreement().getNumber());
                        prd.setNumber(item.getNumber());
                        prd.setRest(item.getAmountInfo().getBalance().getAmount());
                        prd.setRestRur(item.getAmountInfo().getBalance().getAmount().multiply(new BigDecimal(currencies.get(currency))));
                        prd.setCurrency(currency);
                        prd.setType(item.getType());
                        amt = amt.add(prd.getRestRur());
                        if (!prd.getRestRur().equals(BigDecimal.ZERO))
                            list.add(prd);
                        ++i;
                    }
                } else {
                    if (!"DEPOSIT_ACC".equalsIgnoreCase(item.getType())) {
                        log.info("{} processing account {}", uid, item.toString());
                        String currency = currencyBuilder.getCurrencyName(item.getCurrency());
                        Info.Product.Prd prd = new Info.Product.Prd();
                        prd.setId(i);
                        prd.setAgree(item.getAgreement().getNumber());
                        prd.setNumber(item.getNumber());
                        prd.setRest(item.getAmountInfo().getBalance().getAmount());
                        prd.setRestRur(item.getAmountInfo().getBalance().getAmount().multiply(new BigDecimal(currencies.get(currency))));
                        prd.setCurrency(currency);
                        prd.setType(item.getType());
                        amt = amt.add(prd.getRestRur());
                        if (!prd.getRestRur().equals(BigDecimal.ZERO))
                            list.add(prd);
                        ++i;
                    }
                }
            }
        }
        product.setAmount(amt);
        product.setList(list);
        return product;
    }

    protected Info.Product getCards(Cards cards) throws IOException {
        Info.Product product = new Info.Product();
        List<Info.Product.Prd> list = new ArrayList<>();
        BigDecimal amt = BigDecimal.ZERO;
        log.info("{} start preparing card info", uid);
        int i = 1;
        for(Cards.Card card : cards.getCards()){
            log.info("{} start preparing card {}", uid, card.toString());
            if (!Utils.isEmpty(card.getHashPan())
                    && card.getProductInfo() != null
                    && card.getProductInfo().getStatus() != null
                    && card.getProductInfo().getType() != null
                    && "WRK".equalsIgnoreCase(card.getProductInfo().getStatus().getCode())
                    && !Utils.isEmpty(card.getProductInfo().getType().getCode())
                    && card.getProductInfo().getType().getCode().contains("DEBET"))
            {
                log.info("{} add active debet card {}",uid,card.getHashPan());
                Info.Product.Prd prd = new Info.Product.Prd();
                prd.setId(i);
                prd.setCurrency(card.getCurrency());
                prd.setPaymentSystem(card.getPaymentSystem());
                prd.setNumber(card.getPan());
                prd.setHashPan(card.getHashPan());
                list.add(prd);
                ++i;
            }
        }
        List<Map<String, String>> cardBalance = getCardBalance(list);

        for(Info.Product.Prd item : list){
            String hashPan = item.getHashPan();
            String currency = currencyBuilder.getCurrencyName(item.getCurrency());
            for(Map<String, String> map : cardBalance){
                if (hashPan.equalsIgnoreCase(map.get("hashed_card"))
                        && !Utils.isEmpty(map.get("amount")))
                {
                    log.info("{} add rest to card {}",uid,hashPan);
                    BigDecimal amount = new BigDecimal(map.get("amount"));
                    item.setRest(amount);
                    item.setRestRur(amount.multiply(new BigDecimal(currencies.get(currency))));
                    amt = amt.add(item.getRestRur());
                    break;
                }
            }
        }
        if (!CollectionUtils.isEmpty(list))
            list = list.stream().filter(item -> !item.getRestRur().equals(BigDecimal.ZERO)).collect(Collectors.toList());
        product.setAmount(amt);
        product.setList(list);
        return product;
    }

    protected Info.Product getOthers(Offers offers, String type){
        Info.Product product = new Info.Product();
        List<Info.Product.Prd> list = new ArrayList<>();
        BigDecimal amt = BigDecimal.ZERO;
        int i = 1;
        for(Offers.Offer offer : offers.getOfferList()){
            if (Boolean.TRUE.equals(offer.getBankConsent()) && !CollectionUtils.isEmpty(offer.getAccounts())){
                log.info("{} start getting offer amount for offer {}", uid, offer);
                for(Offers.Offer.OfferAccount item : offer.getAccounts()){
                    if ((item.getBalance() != null || item.getDebt() != null) && Boolean.TRUE.equals(item.getConsent())) {
                        log.info("{} processing offer {}", uid, item.toString());
                        String currency = currencyBuilder.getCurrencyName(item.getCurrency());
                        Info.Product.Prd prd = new Info.Product.Prd();
                        prd.setCurrency(currency);
                        prd.setBankName(offer.getBankName());
                        prd.setNumber(item.getName());
                        prd.setType(item.getType());
                        prd.setId(i);
                        BigDecimal rate = new BigDecimal(currencies.get(currency));
                        BigDecimal amount;
                        if ("debt".equals(type)) {
                            BigDecimal debt = Utils.nvl(item.getDebt(), BigDecimal.ZERO);
                            prd.setDebt(debt);
                            prd.setDebtRur(debt.multiply(rate));
                            amount = prd.getDebt();
                            amt = amt.add(prd.getDebtRur());
                        } else {
                            BigDecimal rest = Utils.nvl(item.getBalance(), BigDecimal.ZERO);
                            prd.setRest(rest);
                            prd.setRestRur(rest.multiply(rate));
                            amount = prd.getRest();
                            amt = amt.add(prd.getRestRur());
                        }
                        if (amount != null && !amount.equals(BigDecimal.ZERO))
                            list.add(prd);
                        ++i;
                    }
                }
            }
        }
        product.setAmount(amt);
        product.setList(list);
        return product;
    }

    protected List<Map<String, String>> getCardBalance(List<Info.Product.Prd> list) throws IOException {
        List<Map<String, String>> cards = new ArrayList<>();
        if (!CollectionUtils.isEmpty(list)) {
            String cardSvcInqRq = xmlBuilder.cardSvcInqRq(uid, list);
            CardSvcInqRs cardSvcInqRs = mqGate.getCardBalance(cardSvcInqRq);
            if (cardSvcInqRs != null
                    && cardSvcInqRs.getBankSvcRs() != null
                    && cardSvcInqRs.getBankSvcRs().getReturnData() != null
                    && cardSvcInqRs.getBankSvcRs().getReturnData().getResponse() != null)
            {
                org.w3c.dom.Element elementExtInfo = (org.w3c.dom.Element) cardSvcInqRs.getBankSvcRs().getReturnData().getResponse();
                if (elementExtInfo.getChildNodes() != null){
                    NodeList childNodes = elementExtInfo.getChildNodes();
                    for(int i=0; i<childNodes.getLength(); i++) {
                        if (childNodes.item(i) instanceof org.w3c.dom.Element) {
                            org.w3c.dom.Element node = (org.w3c.dom.Element) childNodes.item(i);
                            Map<String, String> map = new HashMap<>();
                            for(int j=0; j<node.getChildNodes().getLength();j++) {
                                if (node.getChildNodes().item(j) instanceof org.w3c.dom.Element) {
                                    org.w3c.dom.Element childNode = (org.w3c.dom.Element) node.getChildNodes().item(j);
                                    if ("amount".equalsIgnoreCase(childNode.getTagName())) {
                                        map.put("amount", childNode.getTextContent());
                                    } else if ("hashed_card".equalsIgnoreCase(childNode.getTagName())) {
                                        map.put("hashed_card", childNode.getTextContent());
                                    } else if ("currency".equalsIgnoreCase(childNode.getTagName())) {
                                        map.put("currency", childNode.getTextContent());
                                    }
                                }
                            }
                            cards.add(map);
                        }
                    }
                }
            }
        }
        return cards;
    }
}
