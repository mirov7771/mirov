package ru.mtsbank.integration.dbo.balance.info.gates;

import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;

public interface MtsGate {

    Cards getCardList(Long rboId);
    Accounts getAccountList(Long rboId);
    Loans getLoanList(Long rboId);
    Deposits getDepositList(Long rboId);
    Offers getOffers(String phoneNumber);

}
