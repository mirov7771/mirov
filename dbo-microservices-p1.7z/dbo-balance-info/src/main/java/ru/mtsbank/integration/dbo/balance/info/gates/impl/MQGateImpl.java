package ru.mtsbank.integration.dbo.balance.info.gates.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.balance.info.gates.MQGate;
import ru.mtsbank.integration.mts.xsd.DBOCust.cardsvcinqrs.CardSvcInqRs;

import java.io.IOException;

@RequiredArgsConstructor
@Service
public class MQGateImpl implements MQGate {

    private final EsbGate esbGate;
    private final XmlUnmarshaler xmlUnmarshaler;

    @Override
    public CardSvcInqRs getCardBalance(String xml) throws IOException {
        return xmlUnmarshaler.parse(CardSvcInqRs.class, esbGate.sendInfoMessageWithAnswer(xml));
    }

}
