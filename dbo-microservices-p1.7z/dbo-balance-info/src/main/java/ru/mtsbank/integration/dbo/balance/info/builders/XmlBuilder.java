package ru.mtsbank.integration.dbo.balance.info.builders;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.mts.dbo.constants.MTS_MessageTypes;
import ru.mts.dbo.constants.MTS_MsgReceivers;
import ru.mts.dbo.constants.MTS_SPNames;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.Info;
import ru.mtsbank.integration.mts.xsd.DBOCust.cardsvcinqrq.*;

import java.util.Date;
import java.util.List;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@RequiredArgsConstructor
@Component
@Slf4j
public class XmlBuilder {

    private final XmlUnmarshaler xmlUnmarshaler;

    public String cardSvcInqRq(String uid, List<Info.Product.Prd> cardList){
        log.info("{} start creating CardSvcInqRq",uid);
        CardSvcInqRq cardSvcInqRq = new CardSvcInqRq();
        ServerInfoType serverInfo = new ServerInfoType();
        BankSvcRq bankSvcRq = new BankSvcRq();
        SvcInfo svcInfo = new SvcInfo();

        serverInfo.setMsgUID(uid);
        serverInfo.setRqUID(uid);
        serverInfo.setBpId(uid);
        serverInfo.setSPName(MTS_SPNames.MTS_EIP_UMP.getValue());
        serverInfo.setMsgReceiver(MTS_MsgReceivers.Processing.getValue());
        serverInfo.setServerDt(getXmlGregorianCalendar(new Date()));
        serverInfo.setMsgType(MTS_MessageTypes.CARD_SVC_INQ_RQ.getValue());

        svcInfo.setLogin("bus");
        svcInfo.setMethod("ext_info");
        ParamList paramList = new ParamList();
        for(int i=0;i<cardList.size();i++){
            ParamRec rec = new ParamRec();
            int x = i+1;
            rec.setName("hashed_card["+x+"]");
            rec.setValue(cardList.get(i).getHashPan());
            paramList.getParamRec().add(rec);
        }
        svcInfo.setParamList(paramList);
        bankSvcRq.setSvcInfo(svcInfo);

        cardSvcInqRq.setServerInfo(serverInfo);
        cardSvcInqRq.setBankSvcRq(bankSvcRq);
        String xml = xmlUnmarshaler.createXml(cardSvcInqRq);
        log.info("{} create CardSvcInqRq = {}",uid,xml);
        return xml;
    }

}
