package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Agreement {

    @JsonProperty("status")
    private String status;
    @JsonProperty("number")
    private String number;

}
