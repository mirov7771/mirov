package ru.mtsbank.integration.dbo.balance.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Cards {

    @JsonProperty("cards")
    private List<Card> cards;

    @JsonIgnoreProperties(ignoreUnknown = true)
    @Data
    public static class Card{
        @JsonProperty("hashPan")
        private String hashPan;
        @JsonProperty("productInfo")
        private ProductInfo productInfo;
        @JsonProperty("currency")
        private String currency;
        @JsonProperty("paymentSystem")
        private String paymentSystem;
        @JsonProperty("pan")
        private String pan;

        @JsonIgnoreProperties(ignoreUnknown = true)
        @Data
        public static class ProductInfo{
            @JsonProperty("status")
            private Info status;
            @JsonProperty("type")
            private Info type;

            @JsonIgnoreProperties(ignoreUnknown = true)
            @Data
            public static class Info{
                @JsonProperty("code")
                private String code;
            }
        }
    }

}
