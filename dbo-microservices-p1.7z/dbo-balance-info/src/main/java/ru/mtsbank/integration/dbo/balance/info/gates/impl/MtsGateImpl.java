package ru.mtsbank.integration.dbo.balance.info.gates.impl;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.rest.gate.RestGate;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;
import ru.mtsbank.integration.dbo.balance.info.gates.MtsGate;

@Service
public class MtsGateImpl implements MtsGate {

    private final RestGate restGate;
    private String moneyUrl;
    private String otherBankUrl;

    public MtsGateImpl(RestGate restGate
                      ,ApplicationConfig applicationConfig)
    {
        this.restGate = restGate;
        if (applicationConfig != null
                && applicationConfig.getMts() != null
                && applicationConfig.getMts().getMoney() != null)
        {
            moneyUrl = applicationConfig.getMts().getMoney().getGate();
            otherBankUrl = applicationConfig.getMts().getMoney().getOtherbank();
        }
    }

    @Override
    public Cards getCardList(Long rboId) {
        return restGate.call(Cards.class
                , moneyUrl
                ,"getCardList?bankClientId="+rboId
                ,null
                ,HttpMethod.GET.toString());
    }

    @Override
    public Accounts getAccountList(Long rboId) {
        return restGate.call(Accounts.class
                , moneyUrl
                ,"getAccountList?bankClientId="+rboId
                ,null
                ,HttpMethod.GET.toString());
    }

    @Override
    public Loans getLoanList(Long rboId) {
        return restGate.call(Loans.class
                , moneyUrl
                ,"getLoanList?bankClientId="+rboId
                ,null
                ,HttpMethod.GET.toString());
    }

    @Override
    public Deposits getDepositList(Long rboId) {
        return restGate.call(Deposits.class
                , moneyUrl
                ,"getDepositList?bankClientId="+rboId
                ,null
                , HttpMethod.GET.toString());
    }

    @Override
    public Offers getOffers(String phoneNumber) {
        return restGate.call(Offers.class
                , otherBankUrl
                ,"v1/getOffers/"+phoneNumber
                ,null
                ,HttpMethod.GET.toString());
    }

}
