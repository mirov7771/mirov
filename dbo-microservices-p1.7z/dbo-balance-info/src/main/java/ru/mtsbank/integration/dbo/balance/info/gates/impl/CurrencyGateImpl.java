package ru.mtsbank.integration.dbo.balance.info.gates.impl;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import ru.mts.dbo.config.ApplicationConfig;
import ru.mts.dbo.rest.gate.RestGate;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.CurrencyRate;
import ru.mtsbank.integration.dbo.balance.info.gates.CurrencyGate;

import java.io.IOException;

@Service
public class CurrencyGateImpl implements CurrencyGate {

    private final RestGate restGate;
    private String currencyUrl;

    public CurrencyGateImpl(RestGate restGate
                           ,ApplicationConfig applicationConfig)
    {
        this.restGate = restGate;
        if (applicationConfig != null
                && applicationConfig.getMts() != null
                && applicationConfig.getMts().getMoney() != null)
        {
            currencyUrl = applicationConfig.getMts().getMoney().getCurrency();
        }
    }

    @Override
    public CurrencyRate getCurrency(String currency) throws IOException {
        String rates = restGate.call(String.class
                , currencyUrl
                ,currency+"/CASH/"
                ,null
                , HttpMethod.GET.toString());
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return objectMapper.readValue(rates, CurrencyRate.class);
    }

}
