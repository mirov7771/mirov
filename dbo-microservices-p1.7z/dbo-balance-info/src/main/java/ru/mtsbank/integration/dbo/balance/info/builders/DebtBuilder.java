package ru.mtsbank.integration.dbo.balance.info.builders;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.response.DebtRes;
import ru.mtsbank.integration.dbo.balance.info.controllers.dto.support.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Component
@Slf4j
public class DebtBuilder extends ResBuilder<DebtRes> {

    @Override
    public void build(DebtRes res
                     ,Long rboId
                     ,String phone
                     ,String uuid)
    throws ExecutionException, InterruptedException, IOException
    {
        uid = uuid;
        BigDecimal amount = BigDecimal.ZERO;
        CompletableFuture<Loans> callLoans = asyncCall.getLoans(rboId);
        CompletableFuture<Offers> callOffers = asyncCall.getOffers(phone);
        CompletableFuture.allOf(callLoans, callOffers);

        Loans loans = callLoans.get();
        Offers offers = callOffers.get();

        currencies = currencyBuilder.prepareCurrencies(null, null, null, loans, offers, uid);

        Info info = new Info();
        if (loans != null && !CollectionUtils.isEmpty(loans.getLoans())) {
            Info.Product lns = getLoans(loans);
            if (!Boolean.TRUE.equals(lns.isEmpty())){
                info.setLoans(lns);
                amount = amount.add(lns.getAmount());
            }
        }

        if (offers != null && !CollectionUtils.isEmpty(offers.getOfferList())) {
            Info.Product other = getOthers(offers, "debt");
            if (!Boolean.TRUE.equals(other.isEmpty())) {
                info.setOthers(other);
                amount = amount.add(other.getAmount());
            }
        }
        if (!Boolean.TRUE.equals(info.isEmpty()))
            res.setInfo(info);
        res.setAmount(amount);
        res.setRequestId(uid);
        log.info("{} full debt {}",uid, amount);
    }

}
