# Read Me First
The following was discovered as part of building this project:

* The original package name 'ru.mtsbank.integration.dbo.client.info.dbo-client-info' is invalid and this project uses 'ru.mtsbank.integration.dbo.client.info.dboclientinfo' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.2.5.RELEASE/maven-plugin/)

