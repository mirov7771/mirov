package ru.mtsbank.integration.dbo.client.info.controllers.dto.request;

import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;


@Getter
public class FullClientInfoReq extends BaseRequest {

}
