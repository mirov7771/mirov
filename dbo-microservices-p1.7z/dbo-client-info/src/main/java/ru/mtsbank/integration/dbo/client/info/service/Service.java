package ru.mtsbank.integration.dbo.client.info.service;

import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.FullClientInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.RequestInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.UpdateInfoReq;

public interface Service {

    BaseResponse fullClientInfo(FullClientInfoReq req);
    BaseResponse requestInfo(RequestInfoReq req);
    BaseResponse updateInfo(UpdateInfoReq req);

}
