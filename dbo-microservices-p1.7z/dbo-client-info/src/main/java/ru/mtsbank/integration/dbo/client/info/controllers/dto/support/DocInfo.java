package ru.mtsbank.integration.dbo.client.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter @Setter
public class DocInfo {

    @JsonProperty("docSeries")
    private String docSeries;
    @JsonProperty("docNumber")
    private String docNumber;
    @JsonProperty("issuedBy")
    private String issuedBy;
    @JsonProperty("issuedByCode")
    private String issuedByCode;
    @JsonProperty("startDate")
    private Date startDate;
    @JsonProperty("endDate")
    private Date endDate;

}
