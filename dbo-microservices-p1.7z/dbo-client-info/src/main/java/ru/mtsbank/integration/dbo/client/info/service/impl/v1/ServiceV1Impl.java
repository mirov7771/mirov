package ru.mtsbank.integration.dbo.client.info.service.impl.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.FullClientInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.RequestInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.UpdateInfoReq;
import ru.mtsbank.integration.dbo.client.info.service.Service;
import ru.mtsbank.integration.dbo.client.info.service.impl.v1.methods.FullClientInfoMethod;
import ru.mtsbank.integration.dbo.client.info.service.impl.v1.methods.RequestInfoMethod;
import ru.mtsbank.integration.dbo.client.info.service.impl.v1.methods.UpdateInfoMethod;

@Component("v1")
public class ServiceV1Impl implements Service {

    private final FullClientInfoMethod fullClientInfoMethod;
    private final RequestInfoMethod requestInfoMethod;
    private final UpdateInfoMethod updateInfoMethod;

    @Autowired
    public ServiceV1Impl(FullClientInfoMethod fullClientInfoMethod,
                         RequestInfoMethod requestInfoMethod,
                         UpdateInfoMethod updateInfoMethod)
    {
        this.fullClientInfoMethod = fullClientInfoMethod;
        this.requestInfoMethod = requestInfoMethod;
        this.updateInfoMethod = updateInfoMethod;
    }

    @Override
    public BaseResponse fullClientInfo(FullClientInfoReq req) {
        return fullClientInfoMethod.call(req);
    }

    @Override
    public BaseResponse requestInfo(RequestInfoReq req) {
        return requestInfoMethod.call(req);
    }

    @Override
    public BaseResponse updateInfo(UpdateInfoReq req) {
        return updateInfoMethod.call(req);
    }
}
