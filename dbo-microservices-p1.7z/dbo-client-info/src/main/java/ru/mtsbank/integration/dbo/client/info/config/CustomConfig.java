package ru.mtsbank.integration.dbo.client.info.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CustomConfig {

    private App app;

    @Data
    public static class App {
        @JsonProperty("accountName")
        private String accountName;
        @JsonProperty("location")
        private String location;
        @JsonProperty("privatekey")
        private String privatekey;
    }

}
