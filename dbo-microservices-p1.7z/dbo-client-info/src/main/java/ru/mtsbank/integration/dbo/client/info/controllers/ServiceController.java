package ru.mtsbank.integration.dbo.client.info.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.mts.dbo.dto.BaseResponse;
import ru.mts.dbo.dto.ErrorResponse;
import ru.mts.dbo.dto.builder.ResponseBuilder;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.FullClientInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.RequestInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.UpdateInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.response.FullClientInfoRes;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.response.RequestInfoRes;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.response.UpdateInfoRes;
import ru.mtsbank.integration.dbo.client.info.service.Service;

import javax.validation.Valid;
import java.util.Map;

import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

@Tag(name = "ClientInfo")
@RestController
@RequestMapping("dbo-client-info")
@Slf4j
public class ServiceController {

    @Autowired
    private Map<String, Service> services;

    @PostMapping(value = "{version}/requestInfo", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "получение инфо по клиенту для чата"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = RequestInfoRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> requestInfo(@PathVariable final String version
            , @RequestHeader(value = "rbo_id", required = false) String rboId
            , @RequestHeader(value = "authorization", required = false) String authorization
            , @Valid @RequestBody RequestInfoReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).requestInfo(req));
    }

    @PostMapping(value = "{version}/fullClientInfo", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "получение инфо по клиенту"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = FullClientInfoRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    })
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> fullClientInfo(@PathVariable final String version
                                                      ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                      ,@RequestHeader(value = "authorization", required = false) String authorization
                                                      ,@Valid @RequestBody FullClientInfoReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).fullClientInfo(req));
    }

    @PutMapping(value = "{version}/updateInfo", produces = APPLICATION_JSON_UTF8_VALUE)
    @Operation(summary = "обновление клиентских данны"
            , responses = {
            @ApiResponse(responseCode = "200", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = UpdateInfoRes.class))
            }),
            @ApiResponse(responseCode = "406", content = {
                    @Content(mediaType = "application/json;charset=UTF-8", schema = @Schema(implementation = ErrorResponse.class))
            })
    }, hidden = true)
    @Parameter(name = "version", schema = @Schema(type = "string", allowableValues = {"v1"}))
    public ResponseEntity<BaseResponse> updateInfo(@PathVariable final String version
                                                  ,@RequestHeader(value = "rbo_id", required = false) String rboId
                                                  ,@RequestHeader(value = "authorization", required = false) String authorization
                                                  ,@Valid @RequestBody UpdateInfoReq req)
    {
        if (req.getRboID() == null)
            req.setRboID(rboId, authorization);
        return ResponseBuilder.build(services.get(version).updateInfo(req));
    }

}
