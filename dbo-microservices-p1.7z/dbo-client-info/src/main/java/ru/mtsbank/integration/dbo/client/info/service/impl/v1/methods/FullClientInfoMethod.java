package ru.mtsbank.integration.dbo.client.info.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.client.info.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.FullClientInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.response.FullClientInfoRes;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.Address;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrq.CustSearchInqRq;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.*;

import java.text.SimpleDateFormat;
import java.util.*;

import static ru.mts.dbo.utils.Utils.getDate;

@Component("fullclientinfo")
@Slf4j
public class FullClientInfoMethod {

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private EsbGate esbGate;

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    public FullClientInfoRes call(FullClientInfoReq req) {
        log.info("Start fullclientinfo service");
        FullClientInfoRes res = new FullClientInfoRes();
        String uid = UUID.randomUUID().toString();
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS+SSSS");
            CustSearchInqRq rq = custSearchInqRqBuilder.createCustSearchInqRq(req.getRboID().toString(), uid);
            CustSearchInqRs rs = xmlUnmarshaler.parse(CustSearchInqRs.class, esbGate.sendSalesMessageWithAnswer(xmlUnmarshaler.createXml(rq)));
            if (rs == null
                    || rs.getBankSvcRs() == null
                    || rs.getBankSvcRs().getCustInfo() == null) {
                res.createError(500, "Сервис временно не доступен", 406, null, null, "fullclientinfo", uid);
            } else if (rs.getBankSvcRs().getCustInfo().getPersonInfo() == null
                    || rs.getBankSvcRs().getCustInfo().getPersonInfo().getPersonName() == null) {
                res.createError(1002, String.format("Не получены данные по клиенту с ID %s", req.getRboID()), 406, null, null, "fullclientinfo", uid);
            } else {
                CustInfoType custInfo = rs.getBankSvcRs().getCustInfo();
                PersonInfoTypeCustSearchInqRs personInfo = custInfo.getPersonInfo();
                res.setFamily(personInfo.getPersonName().getLastName());
                res.setName(personInfo.getPersonName().getFirstName());
                res.setFatherName(personInfo.getPersonName().getMiddleName());
                if (personInfo.getGender() != null)
                    res.setSex("MALE".equalsIgnoreCase(personInfo.getGender()) ? 0 : 1);
                res.setBirthPlace(personInfo.getBirthPlace());
                if (personInfo.getIdentityCard() != null) {
                    if (!CollectionUtils.isEmpty(personInfo.getIdentityCard())) {
                        for (IdentityCardType card : personInfo.getIdentityCard()) {
                            if (card.isPrimary()) {
                                res.setSerial(card.getIdSeries());
                                res.setNumber(card.getIdNum());
                                res.setIssueOrgCode(card.getIssuedByCode());
                                res.setIssueOrgName(card.getIssuedBy());
                                if (card.getIssueDt() != null) {
                                    Date issueDate = getDate(card.getIssueDt().getYear(), card.getIssueDt().getMonth(), card.getIssueDt().getDay());
                                    res.setIssueDate(sdf.format(issueDate));
                                }
                                break;
                            }
                        }
                    }
                }
                if (personInfo.getBirthday() != null) {
                    Date birthDate = getDate(personInfo.getBirthday().getYear(), personInfo.getBirthday().getMonth(), personInfo.getBirthday().getDay());
                    res.setBirthDate(sdf.format(birthDate));
                }
                if (personInfo.getContactInfo() != null) {
                    ContactInfoType contactInfoType = personInfo.getContactInfo();
                    res.setEmail(contactInfoType.getEmailAddr());
                    if (!CollectionUtils.isEmpty(contactInfoType.getPhoneNum())) {
                        for (FDXPhoneNum phoneNum : contactInfoType.getPhoneNum()) {
                            if (phoneNum.isPrimary()) {
                                res.setMobilePhone(phoneNum.getPhone());
                                break;
                            }
                        }
                    }
                    if (!CollectionUtils.isEmpty(personInfo.getContactInfo().getPostAddr())) {
                        List<Address> addresses = new ArrayList<>();
                        for(AddrType addr : personInfo.getContactInfo().getPostAddr()) {
                            Address address = new Address();
                            address.setCountryName(addr.getCountry());
                            address.setCountryCode(addr.getCountryCode());
                            address.setRegionName(addr.getRegion());
                            address.setRegionCode(addr.getRegionCode());
                            address.setRegionSocr(addr.getRegionCode());
                            address.setDistrictName(addr.getDistrict());
                            address.setCityName(addr.getCity());
                            address.setStreetName(addr.getStreet());
                            address.setType(addr.getAddrType());

                            if (addr.getHouseNum() != null)
                                address.setHouse(addr.getHouseNum().toString());
                            address.setBuilding(addr.getHouseExt());
                            address.setBlock(addr.getHouseBlock());
                            if (addr.getUnitNum() != null)
                                address.setFlat(addr.getUnitNum().toString());
                            address.setZipCode(addr.getPostalCode());

                            address.setAddr(addr.getAddr());
                            addresses.add(address);
                        }
                        res.setAddresses(addresses);

                        for (AddrType addr : personInfo.getContactInfo().getPostAddr()) {
                            if (addr.getAddrType().equalsIgnoreCase("REGISTRATION") || addr.getAddrType().equalsIgnoreCase("REAL_LIVE")) {
                                Address address = new Address();
                                address.setCountryName(addr.getCountry());
                                address.setCountryCode(addr.getCountryCode());
                                address.setRegionName(addr.getRegion());
                                address.setRegionCode(addr.getRegionCode());
                                address.setRegionSocr(addr.getRegionCode());
                                address.setDistrictName(addr.getDistrict());
                                address.setCityName(addr.getCity());
                                address.setStreetName(addr.getStreet());
                                if (addr.getHouseNum() != null)
                                    address.setHouse(addr.getHouseNum().toString());
                                address.setBuilding(addr.getHouseExt());
                                address.setBlock(addr.getHouseBlock());
                                if (addr.getUnitNum() != null)
                                    address.setFlat(addr.getUnitNum().toString());
                                address.setZipCode(addr.getPostalCode());
                                res.setAddress(address);
                                break;
                            }
                        }
                    }
                }
                res.setRequestId(uid);
            }
        } catch (Exception e) {
            log.error("Error: "+e);
            res.createError(500, "Сервис временно недоступен", 406, null, null, "requestinfo", uid);
            e.printStackTrace();
        }
        log.info("End fullclientinfo service");
        return res;
    }

}
