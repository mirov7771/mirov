package ru.mtsbank.integration.dbo.client.info.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.client.info.builders.CustSearchInqRqBuilder;
import ru.mtsbank.integration.dbo.client.info.config.CustomConfig;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.RequestInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.response.RequestInfoRes;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.Fields;
import ru.mtsbank.integration.dbo.client.info.crypto.DboClientInfoCryptoImpl;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.CustSearchInqRs;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrs.FDXPhoneNum;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.UUID;

@Component("requestinfo")
@Slf4j
public class RequestInfoMethod {

    @Autowired
    private EsbGate esbGate;

    private final CustomConfig.App app;

    public RequestInfoMethod(CustomConfig customConfig) {
        this.app = customConfig.getApp();
    }

    @Autowired
    private CustSearchInqRqBuilder custSearchInqRqBuilder;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private DboClientInfoCryptoImpl dboClientInfoCrypto;

    public RequestInfoRes call(RequestInfoReq req) {
        log.info("Start requestinfo service");
        RequestInfoRes res = new RequestInfoRes();
        String uid = UUID.randomUUID().toString();
        try {
            String key = app.getPrivatekey();

            String custSearchXml = xmlUnmarshaler.createXml(custSearchInqRqBuilder.createCustSearchInqRq(req.getRboID().toString(), uid));
            String custSearchAnswerXml = esbGate.sendSalesMessageWithAnswer(custSearchXml);
            CustSearchInqRs custSearchInqRs = xmlUnmarshaler.parse(CustSearchInqRs.class, custSearchAnswerXml);

            Fields field = new Fields();
            if (custSearchInqRs != null
                    && custSearchInqRs.getBankSvcRs() != null
                    && custSearchInqRs.getBankSvcRs().getCustInfo() != null
                    && custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo() != null) {

                String id = custSearchInqRs.getBankSvcRs().getCustInfo().getCustId();
                field.setId(id);

                String display_name = "";
                if (custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getPersonName() != null) {
                    display_name = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getPersonName().getFirstName();
                    field.setDisplay_name(display_name);
                }

                String phone = "";
                if (custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getContactInfo() != null) {
                    List<FDXPhoneNum> phoneNumsList = custSearchInqRs.getBankSvcRs().getCustInfo().getPersonInfo().getContactInfo().getPhoneNum();
                    if (phoneNumsList != null && phoneNumsList.size() > 0) {
                        for (FDXPhoneNum fdxPhoneNum : phoneNumsList) {
                            if (fdxPhoneNum.isPrimary()
                                    && fdxPhoneNum.getPhoneType().equals("Mobile")) {
                                phone = fdxPhoneNum.getPhone();
                                field.setPhone(phone);
                                break;
                            }
                        }
                    }
                }

                String info = req.getMobileOs();
                String accountName = app.getAccountName();
                String location = app.getLocation();
                String appVersion = req.getAppVersion();
                field.setAccountName(accountName);
                field.setAppVersion(req.getAppVersion());
                field.setLocation(location);
                field.setInfo(info);

                String message = accountName + appVersion + display_name + id + info + location + phone;
                try {
                    log.info("Get hash from " + message);
                    res.setHash(dboClientInfoCrypto.cryptoString(message, key));
                } catch (NoSuchAlgorithmException | InvalidKeyException | UnsupportedEncodingException e) {
                    log.error("Error: " + e);
                    res.createError(500, "Сервис временно недоступен", 406, null, null, "requestinfo", uid);
                    e.printStackTrace();
                }
                res.setFields(field);
                res.setRequestId(uid);
            } else {
                res.createError(1002, String.format("Не получены данные по клиенту с ID %s", req.getRboID()), 406, null, null, "requestinfo", uid);
            }
        } catch (Exception e) {
            log.error("Error: "+e);
            res.createError(500, "Сервис временно недоступен", 406, null, null, "requestinfo", uid);
            e.printStackTrace();
        }
        log.info("End requestinfo service");
        return res;
    }

}
