package ru.mtsbank.integration.dbo.client.info.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.Address;

import java.util.Date;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class FullClientInfoRes extends BaseResponse {

    @JsonProperty("secondName")
    private String family;
    @JsonProperty("firstName")
    private String name;
    @JsonProperty("lastName")
    private String fatherName;
    @JsonProperty("mobilePhone")
    private String mobilePhone;
    @JsonProperty("email")
    private String email;
    @JsonProperty("sex")
    private Integer sex;
    @JsonProperty("birthDate")
    private String birthDate;
    @JsonProperty("birthPlace")
    private String birthPlace;
    @JsonProperty("serial")
    private String serial;
    @JsonProperty("number")
    private String number;
    @JsonProperty("issueOrgCode")
    private String issueOrgCode;
    @JsonProperty("issueOrgName")
    private String issueOrgName;
    @JsonProperty("issueDate")
    private String issueDate;
    @JsonProperty("addresses")
    private List<Address> addresses;
    @JsonProperty("address")
    private Address address;


}
