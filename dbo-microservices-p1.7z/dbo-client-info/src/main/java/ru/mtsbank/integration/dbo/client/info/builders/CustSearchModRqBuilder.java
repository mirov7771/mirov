package ru.mtsbank.integration.dbo.client.info.builders;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.UpdateInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.Address;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchmodrq.*;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import static ru.mts.dbo.utils.Utils.*;


@Component
public class CustSearchModRqBuilder {

    public CustSearchModRq custSearchModRq(UpdateInfoReq req, String uid) {
        CustSearchModRq custSearchModRq = new CustSearchModRq();

        ServerInfoType serverInfoType = new ServerInfoType();
        serverInfoType.setBpId(uid);
        serverInfoType.setRqUID(uid);
        serverInfoType.setMsgUID(uid);
        serverInfoType.setMsgType("CustSearchModRq");
        serverInfoType.setSPName("MTS_EIP_UMP");
        serverInfoType.setMsgReceiver("SIEBEL");
        serverInfoType.setServerDt(getXmlGregorianCalendar(new Date()));
        custSearchModRq.setServerInfo(serverInfoType);

        BankSvcRq bankSvcRq = new BankSvcRq();
        CustInfoType custInfo = new CustInfoType();
        custInfo.setCustId(req.getRboID().toString());
        PersonInfoType personInfoType = new PersonInfoType();
        if (req.getPersonInfo() != null){
            String firstName = req.getPersonInfo().getFirstName();
            String middleName = req.getPersonInfo().getMiddleName();
            String lastName = req.getPersonInfo().getLastName();
            PersonNameType personNameType = new PersonNameType();
            if (!StringUtils.isEmpty(lastName))
                personNameType.setLastName(lastName);
            if (!StringUtils.isEmpty(firstName))
                personNameType.setFirstName(firstName);
            if (!StringUtils.isEmpty(middleName))
                personNameType.setMiddleName(middleName);
            personInfoType.setPersonName(personNameType);
            if (!StringUtils.isEmpty(lastName) && !StringUtils.isEmpty(firstName)){
                String fullName = lastName+" "+firstName;
                if (!StringUtils.isEmpty(middleName))
                    fullName+= " "+middleName;
                personInfoType.setFullName(fullName);
            }
        }
        if (req.getContactInfo() != null){
            String email = req.getContactInfo().getEmail();
            String phoneNumber = req.getContactInfo().getPhoneNumber();
            ContactInfoType contactInfoType = new ContactInfoType();
            if (!StringUtils.isEmpty(email)){
                contactInfoType.setEmailAddr(email);
            }
            if (!StringUtils.isEmpty(phoneNumber)){
                FDXPhoneNum phoneNum = new FDXPhoneNum();
                phoneNum.setPhone(castPhone(phoneNumber));
                phoneNum.setPrimary(true);
                phoneNum.setPhoneType("Mobile");
                contactInfoType.getPhoneNum().add(phoneNum);
            }
            personInfoType.setContactInfo(contactInfoType);
        }
        if (req.getDocInfo() != null) {

            Date startDate = req.getDocInfo().getStartDate();
            Date endDate = req.getDocInfo().getEndDate();

            IdentityCardType id = new IdentityCardType();
            id.setIssuedBy(req.getDocInfo().getIssuedBy());
            id.setIssuedByCode(req.getDocInfo().getIssuedByCode());
            id.setIdNum(req.getDocInfo().getDocNumber());
            id.setIdSeries(req.getDocInfo().getDocSeries());
            id.setIdType("21");
            id.setIdTypeDetail("Общегражданский паспорт РФ");
            if (startDate != null)
                id.setIssueDt(getFdxDateFromDate(startDate));
            if (endDate != null)
                id.setExpDt(getFdxDateFromDate(endDate));
            personInfoType.getIdentityCard().add(id);
        }
        if (req.getAddresses() != null && !CollectionUtils.isEmpty(req.getAddresses())){
            for(Address address : req.getAddresses()){
                AddrType addr = new AddrType();
                addr.setCountry(address.getCountryName());
                addr.setCountryCode(address.getCountryCode());
                addr.setRegion(address.getRegionName());
                addr.setRegionCode(address.getRegionCode());
                addr.setDistrict(address.getDistrictName());
                addr.setCity(address.getCityName());
                addr.setStreet(address.getStreetName());
                addr.setAddrType(address.getType());

                if (address.getHouse() != null && isDigits(address.getHouse()))
                    addr.setHouseNum(new BigInteger(address.getHouse()));

                addr.setHouseExt(address.getBuilding());
                addr.setHouseBlock(address.getBlock());

                if (address.getFlat() != null && isDigits(address.getFlat()))
                    addr.setUnitNum(new BigInteger(address.getFlat()));

                addr.setPostalCode(address.getZipCode());

                if (isEmpty(address.getAddr())){
                    addr.setAddr(getFullAddr(address));
                } else {
                    addr.setAddr(address.getAddr());
                }

                personInfoType.getContactInfo().getPostAddr().add(addr);
            }
        }
        custInfo.setPersonInfo(personInfoType);
        bankSvcRq.setCustInfo(custInfo);
        custSearchModRq.setBankSvcRq(bankSvcRq);
        return custSearchModRq;
    }

    private FdxDate getFdxDateFromDate(Date date){
        GregorianCalendar gg = new GregorianCalendar();
        gg.setTime(date);
        FdxDate dt = new FdxDate();
        dt.setDay(gg.get(Calendar.DAY_OF_WEEK));
        dt.setMonth(gg.get(Calendar.MONTH) == 0 ? 12 : gg.get(Calendar.MONTH));
        dt.setYear(gg.get(Calendar.YEAR));
        return dt;
    }

    private String getFullAddr(Address address){
        StringBuilder sb = new StringBuilder();
        if (address.getZipCode() != null)
            sb.append(address.getZipCode());
        if (address.getCountryName() != null)
            sb.append(", ").append(address.getCountryName());
        if (address.getRegionName() != null)
            sb.append(", ").append(address.getRegionName());
        if (address.getCityName() != null)
            sb.append(", ").append(address.getCityName());
        if (address.getDistrictName() != null)
            sb.append(", ").append(address.getDistrictName());
        if (address.getLocalityName() != null)
            sb.append(", ").append(address.getLocalityName());
        if (address.getStreetName() != null)
            sb.append(", ").append(address.getStreetName());
        if (address.getHouse() != null)
            sb.append(", д. ").append(address.getHouse());
        if (address.getBlock() != null)
            sb.append(", к. ").append(address.getBlock());
        if (address.getBuilding() != null)
            sb.append(", стр. ").append(address.getBuilding());
        if (address.getFlat() != null)
            sb.append(", кв. ").append(address.getFlat());
        return sb.toString();
    }

}
