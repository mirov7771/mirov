package ru.mtsbank.integration.dbo.client.info.service.impl.v1.methods;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import ru.mts.dbo.gates.EsbGate;
import ru.mts.dbo.jaxb.XmlUnmarshaler;
import ru.mtsbank.integration.dbo.client.info.builders.CustSearchModRqBuilder;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.request.UpdateInfoReq;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.response.UpdateInfoRes;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchmodrs.CustSearchModRs;

import java.io.IOException;
import java.util.UUID;

@Component
@Slf4j
public class UpdateInfoMethod {

    @Autowired
    private CustSearchModRqBuilder custSearchModRqBuilder;

    @Autowired
    private XmlUnmarshaler xmlUnmarshaler;

    @Autowired
    private EsbGate esbGate;

    public UpdateInfoRes call(UpdateInfoReq req){
        log.info("Start UpdateInfo");
        UpdateInfoRes res = new UpdateInfoRes();
        String uid = UUID.randomUUID().toString();
        try {

            String answer = esbGate.sendSalesMessageWithAnswer(
                    xmlUnmarshaler.createXml(
                            custSearchModRqBuilder.custSearchModRq(req, uid)
                    )
            );
            if (!StringUtils.isEmpty(answer)){
                CustSearchModRs rs = xmlUnmarshaler.parse(CustSearchModRs.class, answer);
                if (rs != null
                        && rs.getBankSvcRs() != null
                        && rs.getBankSvcRs().getStatus() != null
                        && !StringUtils.isEmpty(rs.getBankSvcRs().getStatus().getStatusCode()))
                {
                    String statusCode = rs.getBankSvcRs().getStatus().getStatusCode();
                    if ("0".equals(statusCode)){
                        res.setRequestId(uid);
                    } else {
                        res.createError(1060
                                , String.format("Не удалось обновить данные по клиенту с ID %s", req.getRboID())
                                , 406
                                , statusCode
                                , rs.getBankSvcRs().getStatus().getStatusDesc()
                                ,"UpdateInfo"
                                , uid);
                    }
                }
            } else {
                res.createError(1002, String.format("Не удалось обновить данные по клиенту с ID %s", req.getRboID()), 406, null, null, "UpdateInfo", uid);
            }
        } catch (IOException e) {
            log.error("Error: "+e);
            res.createError(500, "Сервис временно недоступен", 406, null, null, "UpdateInfo", uid);
            e.printStackTrace();
        }
        log.info("End UpdateInfo");
        return res;
    }

}
