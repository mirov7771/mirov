package ru.mtsbank.integration.dbo.client.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class Address {

    @JsonProperty("countryName")
    private String countryName;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("regionName")
    private String regionName;
    @JsonProperty("regionCode")
    private String regionCode;
    @JsonProperty("regionSocr")
    private String regionSocr;
    @JsonProperty("districtName")
    private String districtName;
    @JsonProperty("localityName")
    private String localityName;
    @JsonProperty("cityName")
    private String cityName;
    @JsonProperty("streetName")
    private String streetName;
    @JsonProperty("house")
    private String house;
    @JsonProperty("building")
    private String building;
    @JsonProperty("block")
    private String block;
    @JsonProperty("flat")
    private String flat;
    @JsonProperty("zipCode")
    private String zipCode;
    @JsonProperty("type")
    private String type;
    @JsonProperty("addr")
    private String addr;

}
