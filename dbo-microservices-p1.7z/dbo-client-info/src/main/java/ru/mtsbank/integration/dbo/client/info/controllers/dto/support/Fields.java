package ru.mtsbank.integration.dbo.client.info.controllers.dto.support;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Setter
public class Fields {

    @JsonProperty("id")
    private String id;
    @JsonProperty("display_name")
    private String display_name;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("accountName")
    private String accountName;
    @JsonProperty("location")
    private String location;
    @JsonProperty("appVersion")
    private String appVersion;
    @JsonProperty("info")
    private String info;

}
