package ru.mtsbank.integration.dbo.client.info.crypto;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public interface DboClientInfoCrypto {

    String cryptoString(String text, String key) throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException;

}
