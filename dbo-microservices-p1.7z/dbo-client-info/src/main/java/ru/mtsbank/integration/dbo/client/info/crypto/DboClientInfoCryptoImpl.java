package ru.mtsbank.integration.dbo.client.info.crypto;

import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@Component
public class DboClientInfoCryptoImpl implements DboClientInfoCrypto {
    @Override
    public String cryptoString(String text, String key) throws NoSuchAlgorithmException, UnsupportedEncodingException, InvalidKeyException {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec keySpec = new SecretKeySpec(key.getBytes("UTF-8"), "HmacSHA256");
        mac.init(keySpec);
        byte[] hash = mac.doFinal(text.getBytes("UTF-8"));
        String res = "";
        for (byte element : hash) {
            res += Integer.toString((element & 0xff) + 0x100, 16).substring(1);
        }
        return res;
    }
}
