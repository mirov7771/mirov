package ru.mtsbank.integration.dbo.client.info.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import ru.mts.dbo.dto.BaseRequest;


@Getter
public class RequestInfoReq extends BaseRequest {

    @JsonProperty("mobileOS")
    private String mobileOs;
    @JsonProperty("appVersion")
    private String appVersion;

}
