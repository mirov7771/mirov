package ru.mtsbank.integration.dbo.client.info.controllers.dto.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseRequest;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.Address;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.ContactInfo;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.DocInfo;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.PersonInfo;

import java.util.List;

@Getter @Setter
public class UpdateInfoReq extends BaseRequest {

    @JsonProperty("contactInfo")
    private ContactInfo contactInfo;
    @JsonProperty("personInfo")
    private PersonInfo personInfo;
    @JsonProperty("docInfo")
    private DocInfo docInfo;
    @JsonProperty("addresses")
    private List<Address> addresses;

}
