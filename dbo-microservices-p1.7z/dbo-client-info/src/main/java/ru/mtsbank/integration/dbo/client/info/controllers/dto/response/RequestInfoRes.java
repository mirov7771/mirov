package ru.mtsbank.integration.dbo.client.info.controllers.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import ru.mts.dbo.dto.BaseResponse;
import ru.mtsbank.integration.dbo.client.info.controllers.dto.support.Fields;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter @Setter
public class RequestInfoRes extends BaseResponse {

    @JsonProperty("fields")
    private Fields fields;
    @JsonProperty("hash")
    private String hash;

}
