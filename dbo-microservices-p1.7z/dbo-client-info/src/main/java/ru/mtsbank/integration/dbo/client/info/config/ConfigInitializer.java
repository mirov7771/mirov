package ru.mtsbank.integration.dbo.client.info.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.mts.dbo.config.CustomConsulService;

@Configuration
public class ConfigInitializer {
    @Value("${consul_host}")
    private String consulHost;
    @Value("${consul_config_path}")
    private String consulPrefix;
    @Value("${consul_config_acl_token}")
    private String consulToken;
    @Value("${app.name}")
    private String appName;
    @Value("${app.key}")
    private String appKey;

    @Bean
    public CustomConfig getCustomConfig() {
        return new CustomConsulService()
                .init(CustomConfig.class,
                        consulHost,
                        consulPrefix,
                        consulToken,
                        appName,
                        appKey);
    }
}
