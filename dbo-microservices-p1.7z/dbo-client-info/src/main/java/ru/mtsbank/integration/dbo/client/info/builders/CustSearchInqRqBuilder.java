package ru.mtsbank.integration.dbo.client.info.builders;

import org.springframework.stereotype.Component;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrq.BankSvcRq;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrq.CustInfo;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrq.CustSearchInqRq;
import ru.mtsbank.integration.mts.xsd.DBOCust.custsearchinqrq.ServerInfoType;

import java.util.Date;
import java.util.UUID;

import static ru.mts.dbo.utils.Utils.getXmlGregorianCalendar;

@Component
public class CustSearchInqRqBuilder {
    public CustSearchInqRq createCustSearchInqRq(String custId, String uid) {

        CustSearchInqRq custSearchInqRq = new CustSearchInqRq();
        BankSvcRq bankSvcRq = new BankSvcRq();
        custSearchInqRq.setBankSvcRq(bankSvcRq);

        CustInfo custInfo = new CustInfo();
        custInfo.setCustId(custId);
        bankSvcRq.setCustInfo(custInfo);

        ServerInfoType serverInfoType = new ServerInfoType();
        serverInfoType.setBpId(UUID.randomUUID().toString());
        serverInfoType.setRqUID(uid);
        serverInfoType.setMsgUID(UUID.randomUUID().toString());
        serverInfoType.setMsgType("CustSearchInqRq");
        serverInfoType.setSPName("MTS_EIP_UMP");
        serverInfoType.setMsgReceiver("SIEBEL");
        serverInfoType.setServerDt(getXmlGregorianCalendar(new Date()));
        custSearchInqRq.setServerInfo(serverInfoType);
        return custSearchInqRq;
    }
}
